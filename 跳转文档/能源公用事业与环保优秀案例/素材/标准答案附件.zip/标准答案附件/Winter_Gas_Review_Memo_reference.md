# 2026年1月天然气调度与结算审阅意见

本次按2026年9月8日17:00的资料状态处理4个情景。历史计量保留6,660条，账单选择后保留222条。客户日度需求与供应结果各9,176条。

BASE请求量620,191.018MMBtu，已供应620,191.018MMBtu，Firm客户短缺0.000MMBtu。Prairie期末库存270,638.000MMBtu，Lake期末库存167,266.800MMBtu，毛利627,975.93美元，结论APPROVE，未通过项目为无。
COLD请求量700,537.778MMBtu，已供应700,537.778MMBtu，Firm客户短缺0.000MMBtu。Prairie期末库存239,800.000MMBtu，Lake期末库存151,200.000MMBtu，毛利912,206.43美元，结论REJECT，未通过项目为RESIDUAL_IMBALANCE。
NORTH_OUTAGE请求量641,859.587MMBtu，已供应640,703.572MMBtu，Firm客户短缺816.666MMBtu。Prairie期末库存252,800.000MMBtu，Lake期末库存150,800.000MMBtu，毛利788,758.10美元，结论REJECT，未通过项目为RESIDUAL_IMBALANCE。
COMBINED请求量720,116.626MMBtu，已供应714,001.796MMBtu，Firm客户短缺5,075.903MMBtu。Prairie期末库存241,017.000MMBtu，Lake期末库存152,852.400MMBtu，毛利922,906.16美元，结论REJECT，未通过项目为FIRM_SHORTFALL,RESIDUAL_IMBALANCE。

异常清单共73条，每条只记录一个差异，执行前需要按清单修订采购、储气和提交摘要，并确认两处储气库存及Firm客户供应安排。