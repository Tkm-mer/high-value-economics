"""Reproducible reference analysis. Python 3.12; see requirements.txt."""
import argparse
import importlib.util
import hashlib
import json
import os
import time
from pathlib import Path

os.environ.setdefault('OMP_NUM_THREADS', '4')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '4')
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score

_PROCESSING_PATH = Path(__file__).with_name('处理函数.py')
_processing_spec = importlib.util.spec_from_file_location('processing', _PROCESSING_PATH)
_processing = importlib.util.module_from_spec(_processing_spec)
_processing_spec.loader.exec_module(_processing)
ticks = _processing.ticks
fill_missing_values = _processing.fill_missing_values
add_class_labels = _processing.add_class_labels

HORIZONS = [6, 12, 24, 48]
COUNTERS = ['171_0','666_0','427_0','837_0','309_0','835_0','370_0','100_0']
HISTOGRAMS = {'167':10,'272':10,'291':11,'158':10,'459':20,'397':36}
COST = np.array([[0,7,8,9,10],[200,0,7,8,9],[300,200,0,7,8],
                 [400,300,200,0,7],[500,400,300,200,0]], dtype=float)

def write_json(path, value):
    def native(x):
        if isinstance(x,np.generic): return x.item()
        if isinstance(x,np.ndarray): return x.tolist()
        raise TypeError(type(x).__name__)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=native,allow_nan=False))

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(2**20),b''):h.update(b)
    return h.hexdigest()




def profile_readouts(d,split):
    sorted_d=d.sort_values(['vehicle_id','time_step'],kind='stable')
    deltas=sorted_d.groupby('vehicle_id',sort=False)[COUNTERS].diff()
    counts=sorted_d.groupby('vehicle_id').size()
    return {'split':split,'rows':len(d),'vehicles':int(d.vehicle_id.nunique()),
            'columns':len(d.columns),'duplicate_keys':int(d.duplicated(['vehicle_id','time_step']).sum()),
            'backward_adjacent_times':int(((d.vehicle_id.diff()==0)&(d.time_step.diff()<0)).sum()),
            'missing_cells':int(d.isna().sum().sum()),
            'counter_decreases':{c:int((deltas[c]<0).sum()) for c in COUNTERS},
            'readouts_per_vehicle':{k:float(v) for k,v in counts.describe().to_dict().items()},
            'time_min':float(d.time_step.min()),'time_max':float(d.time_step.max()),
            'on_tenth_grid':bool(np.allclose(d.time_step*10,np.rint(d.time_step*10),rtol=0,atol=1e-7))}

def select_positions(d, training):
    groups=d.groupby('vehicle_id',sort=True).indices
    selected=[]
    for vid,indices in groups.items():
        if training:
            rng=np.random.default_rng(314159+int(vid))
            selected.extend(sorted(rng.choice(indices,size=min(3,len(indices)),replace=False).tolist()))
        else:selected.append(indices[-1])
    return np.array(selected,dtype=int)

def prefix_features(d, positions, specs, vocab):
    """No endpoint or labels accepted; computations only use current/past rows."""
    if not d.index.equals(pd.RangeIndex(len(d))):d=d.reset_index(drop=True)
    if not d[['vehicle_id','time_step']].equals(d.sort_values(['vehicle_id','time_step'])[['vehicle_id','time_step']]):
        raise ValueError('Sort raw observations before selecting positions')
    grouped=d.groupby('vehicle_id',sort=False)
    current=d.iloc[positions]
    ff=fill_missing_values(d)
    f={}
    f['age']=current.time_step
    f['readouts_seen']=grouped.cumcount().iloc[positions]+1
    f['gap']=grouped.time_step.diff().iloc[positions]
    f['span']=current.time_step-grouped.time_step.transform('first').iloc[positions]
    cols=[c for c in d if c not in ['vehicle_id','time_step']]
    f['missing_fraction']=current[cols].isna().mean(axis=1)
    dt=grouped.time_step.diff()
    delta=grouped[COUNTERS].diff()
    for c in COUNTERS:
        f[c]=np.log1p(ff[c].iloc[positions].clip(lower=0))
        f[c+'_decrease']=(delta[c].iloc[positions]<0).astype(float)
        rate=(delta[c]/dt).where((delta[c]>=0)&(dt>0))
        f[c+'_rate']=np.log1p(rate.iloc[positions])
    for name,bins in HISTOGRAMS.items():
        hc=[f'{name}_{k}' for k in range(bins)]
        values=ff.loc[current.index,hc]
        total=values.sum(axis=1,min_count=bins)
        f[name+'_total']=np.log1p(total.clip(lower=0))
        f[name+'_zero_total']=(total==0).astype(float)
        for c in hc:f[c+'_share']=values[c]/total.where(total>0)
    s=specs.set_index('vehicle_id').reindex(current.vehicle_id.to_numpy())
    if specs.vehicle_id.duplicated().any() or not set(current.vehicle_id).issubset(set(specs.vehicle_id)):
        raise ValueError('Invalid specification keys')
    s.index=current.index
    for c,values in vocab.items():
        for v in values:f[f'{c}={v}']=(s[c]==v).astype(float)
        f[c+'_unknown']=(~s[c].isin(values)).astype(float)
    return pd.DataFrame(f,index=current.index).replace([np.inf,-np.inf],np.nan).reset_index(drop=True)

def cumulative_probabilities(p):
    return np.column_stack([p[:,4],p[:,3:].sum(1),p[:,2:].sum(1),p[:,1:].sum(1)])

def monotone_projection(values):
    result=[]
    for row in values:
        blocks=[]
        for value in row:
            blocks.append([float(value),1])
            while len(blocks)>1 and blocks[-2][0]>blocks[-1][0]:
                b=blocks.pop();a=blocks.pop()
                blocks.append([(a[0]*a[1]+b[0]*b[1])/(a[1]+b[1]),a[1]+b[1]])
        result.append([mean for mean,n in blocks for _ in range(n)])
    return np.asarray(result)

def class_probabilities(cdf):
    f=monotone_projection(np.clip(cdf,0,1))
    return np.column_stack([1-f[:,3],f[:,3]-f[:,2],f[:,2]-f[:,1],f[:,1]-f[:,0],f[:,0]])

def sigmoid(z):
    z=np.clip(z,-40,40)
    return 1/(1+np.exp(-z))

def calibration_fit(raw,labels):
    params=[]
    for k,lowest in enumerate([4,3,2,1]):
        p=np.clip(raw[:,k],1e-6,1-1e-6);x=np.log(p/(1-p));y=(labels>=lowest).astype(float)
        def loss(ab):
            z=ab[0]*x+ab[1]
            return float(np.mean(np.logaddexp(0,z)-y*z)+1e-4*((ab[0]-1)**2+ab[1]**2))
        fit=minimize(loss,[1.,0.],method='L-BFGS-B',bounds=[(0,10),(-15,15)])
        if not fit.success:raise RuntimeError(fit.message)
        params.append(fit.x.tolist())
    return params

def calibration_apply(raw,params):
    p=np.clip(raw,1e-6,1-1e-6);x=np.log(p/(1-p))
    return np.column_stack([sigmoid(x[:,k]*a+b) for k,(a,b) in enumerate(params)])

def actions(p,ids,capacity):
    if p.shape!=(len(ids),5) or not np.isfinite(p).all() or p.min()<-1e-10 or not np.allclose(p.sum(1),1,atol=1e-8):
        raise ValueError('Invalid class probabilities')
    # Explicit five-term sums avoid platform BLAS floating-point flag warnings.
    expected=(p[:,:,None]*COST[None,:,:]).sum(axis=1)
    if capacity is None:return expected.argmin(axis=1)
    alt=expected[:,1:].argmin(axis=1)+1
    gain=expected[:,0]-expected[np.arange(len(p)),alt]
    order=np.lexsort((np.asarray(ids),-gain))
    chosen=order[gain[order]>1e-12][:int(np.floor(capacity*len(p)))]
    result=np.zeros(len(p),dtype=int);result[chosen]=alt[chosen]
    return result

def weighted_cost(y,a,weight):
    weights=np.where(y>0,weight,1.)
    return float(np.dot(weights,COST[y,a])/weights.sum())

def paired_interval(y,a,b,weight,seed=20260909,replicates=2000):
    rng=np.random.default_rng(seed)
    difference=COST[y,a]-COST[y,b]
    w=np.where(y>0,weight,1.)
    estimates=[]
    for start in range(0,replicates,100):
        ix=rng.integers(0,len(y),size=(min(100,replicates-start),len(y)))
        estimates.extend(((difference[ix]*w[ix]).sum(1)/w[ix].sum(1)).tolist())
    return [float(v) for v in np.quantile(estimates,[.025,.975])]

def main(data,out):
    if out==data or data in out.parents:raise ValueError('Output must be outside the read-only input directory')
    if out.exists() and any(out.iterdir()):raise FileExistsError('Output must be new or empty')
    out.mkdir(parents=True,exist_ok=True)
    started=time.time()
    profiles=[];frames={};keys={};samples={}
    specs={s:pd.read_csv(data/f'{s}_specifications.csv') for s in ['train','validation','test']}
    for s,v in specs.items():
        if v.vehicle_id.duplicated().any():raise ValueError(f'Duplicate specification key: {s}')
    vocab={c:sorted(specs['train'][c].unique().tolist()) for c in specs['train'] if c!='vehicle_id'}
    endpoints=pd.read_csv(data/'train_tte.csv')
    for split in ['train','validation','test']:
        file=data/f'{split}_operational_readouts.csv'
        header=pd.read_csv(file,nrows=0).columns
        dtype={c:'float32' for c in header if c not in ['vehicle_id','time_step']}
        d=pd.read_csv(file,dtype=dtype)
        profiles.append(profile_readouts(d,split))
        d=d.sort_values(['vehicle_id','time_step'],kind='stable').reset_index(drop=True)
        positions=select_positions(d,split=='train')
        keys[split]=d.iloc[positions][['vehicle_id','time_step']].reset_index(drop=True)
        if set(d.vehicle_id)!=set(specs[split].vehicle_id):raise ValueError('Specification/readout population mismatch')
        if split=='train':
            lab=add_class_labels(endpoints,d[['vehicle_id','time_step']])
            lab.to_csv(out/'训练标签.csv.gz',index=False,compression='gzip')
            original_remaining=(lab.length_of_study_time_step-lab.time_step).to_numpy()
            event=lab.in_study_repair.to_numpy()==1
            original_class=np.select([original_remaining>48,(original_remaining>24)&event,
                (original_remaining>12)&event,(original_remaining>6)&event,(original_remaining>0)&event],
                [0,1,2,3,4],default=-1)
            changed=original_class!=lab.class_label.to_numpy()
            differences=lab.loc[changed,['vehicle_id','time_step','length_of_study_time_step','in_study_repair']].copy()
            differences['raw_float_remaining']=original_remaining[changed]
            differences['old_class']=original_class[changed]
            differences['new_class']=lab.loc[changed,'class_label']
            differences.to_csv(out/'原始标签差异.csv',index=False,float_format='%.17g')
            write_json(out/'标签修复影响.json',{'original_class_counts':pd.Series(original_class).value_counts().sort_index().to_dict(),
                'changed_rows':int(changed.sum()),'changed_vehicles':int(differences.vehicle_id.nunique()),
                'censored_changed':int((differences.in_study_repair==0).sum()),
                'event_changed':int((differences.in_study_repair==1).sum())})
            summary=[]
            for h in HORIZONS:
                y=lab[f'y_{h}']
                for value in [-1,0,1]:
                    mask=y==value
                    summary.append({'horizon':h,'label':value,'readouts':int(mask.sum()),
                                    'vehicles':int(lab.loc[mask,'vehicle_id'].nunique())})
            pd.DataFrame(summary).to_csv(out/'标签可用性.csv',index=False)
            window_extra=[]
            for h in HORIZONS:
                mask=(lab.class_label==-1)&(lab[f'y_{h}']!=-1)
                window_extra.append({'horizon':h,'readouts_retained_beyond_complete_case':int(mask.sum()),
                    'vehicles':int(lab.loc[mask,'vehicle_id'].nunique())})
            pd.DataFrame(window_extra).to_csv(out/'部分随访信息.csv',index=False)
            write_json(out/'终点审计.json',{
                'event_counts':endpoints.in_study_repair.value_counts().to_dict(),
                'class_counts':lab.class_label.value_counts().sort_index().to_dict(),
                'readouts_after_endpoint':int((lab.remaining_followup<0).sum()),
                'readouts_at_repair':int(((lab.remaining_followup==0)&(lab.in_study_repair==1)).sum()),
                'readouts_at_censoring':int(((lab.remaining_followup==0)&(lab.in_study_repair==0)).sum()),
                'censored_at_48':int(((lab.remaining_followup==48)&(lab.in_study_repair==0)).sum())})
            samples[split]=lab.iloc[positions].reset_index(drop=True)
        frames[split]=prefix_features(d,positions,specs[split],vocab)
        del d
        print('PREPARED',split,len(frames[split]),flush=True)
    overlaps={f'{a}_{b}':len(set(keys[a].vehicle_id)&set(keys[b].vehicle_id))
              for a,b in [('train','validation'),('train','test'),('validation','test')]}
    if any(overlaps.values()):raise ValueError('Vehicle overlap between releases')
    write_json(out/'数据审计.json',{'files':profiles,'vehicle_overlaps':overlaps,'spec_vocab':vocab})
    for split in ['train','validation','test']:
        keys[split].to_csv(out/f'{split}_snapshots.csv',index=False)
    labels_v=pd.read_csv(data/'validation_labels.csv').set_index('vehicle_id').loc[keys['validation'].vehicle_id,'class_label'].to_numpy()
    calibration=(keys['validation'].vehicle_id.to_numpy()%2)==0
    selection=~calibration
    lab=samples['train'];x=frames['train']
    kwargs=dict(max_iter=120,max_leaf_nodes=15,min_samples_leaf=30,l2_regularization=1.,
                learning_rate=.07,early_stopping=False,random_state=1729)
    model_raw={};model_params={};fit_counts=[]
    for name in ['complete_case','window_observed']:
        if name=='complete_case':
            mask=lab.class_label>=0
            part=lab.loc[mask]
            weights=1/part.groupby('vehicle_id').vehicle_id.transform('size').to_numpy()
            model=HistGradientBoostingClassifier(**kwargs).fit(x.loc[mask],part.class_label,sample_weight=weights)
            probs={s:cumulative_probabilities(model.predict_proba(frames[s])) for s in ['validation','test']}
            fit_counts.append({'model':name,'horizon':0,'rows':int(mask.sum()),'vehicles':int(part.vehicle_id.nunique()),
                               'positive_rows':int((part.class_label>0).sum())})
        else:
            probs={s:[] for s in ['validation','test']}
            for h in HORIZONS:
                mask=lab[f'y_{h}']>=0;part=lab.loc[mask]
                weights=1/part.groupby('vehicle_id').vehicle_id.transform('size').to_numpy()
                model=HistGradientBoostingClassifier(**kwargs).fit(x.loc[mask],part[f'y_{h}'],sample_weight=weights)
                for s in probs:probs[s].append(model.predict_proba(frames[s])[:,1])
                fit_counts.append({'model':name,'horizon':h,'rows':int(mask.sum()),'vehicles':int(part.vehicle_id.nunique()),
                                   'positive_rows':int((part[f'y_{h}']==1).sum())})
                print('FIT',name,h,flush=True)
            probs={s:np.column_stack(v) for s,v in probs.items()}
        params=calibration_fit(probs['validation'][calibration],labels_v[calibration])
        model_params[name]=params
        model_raw[name]={s:class_probabilities(calibration_apply(p,params)) for s,p in probs.items()}
        print('FIT',name,'finished',flush=True)
    prior=np.bincount(labels_v[calibration],minlength=5)/calibration.sum()
    model_raw['constant_prior']={s:np.tile(prior,(len(frames[s]),1)) for s in ['validation','test']}
    pd.DataFrame(fit_counts).to_csv(out/'训练样本比较.csv',index=False)
    selected={};selection_records=[]
    for capacity in [None,.1]:
        candidates=[]
        for name in ['complete_case','window_observed']:
            p=model_raw[name]['validation'][selection]
            a=actions(p,keys['validation'].vehicle_id.to_numpy()[selection],capacity)
            values=[weighted_cost(labels_v[selection],a,w) for w in [.5,1.,2.]]
            baseline=actions(model_raw['constant_prior']['validation'][selection],keys['validation'].vehicle_id.to_numpy()[selection],capacity)
            ratios=[v/weighted_cost(labels_v[selection],baseline,w) for v,w in zip(values,[.5,1.,2.])]
            candidates.append((max(ratios),name))
            selection_records.append({'capacity':capacity,'model':name,'costs':values,'ratios_to_constant_prior':ratios})
        selected['unlimited' if capacity is None else 'capacity_10pct']=min(candidates)[1]
    protocol={'horizons':HORIZONS,'train_snapshots':'up to 3 uniform readouts per vehicle, RNG 314159 + vehicle_id',
              'weighting':'within each fitted estimator, each retained vehicle has total weight 1',
              'validation_calibration':'even vehicle_id','validation_selection':'odd vehicle_id',
              'model_parameters':kwargs,'calibration_parameters':model_params,
              'probability_projection':'equal-weight isotonic projection across horizons',
              'decision':'minimize expected official cost; with capacity take positive savings, descending, ID breaks ties',
              'stress_weights':[.5,1.,2.],'selected_models':selected,'selection_records':selection_records,
              'input_hashes':{p.name:digest(p) for p in sorted(data.glob('*.csv')) if p.name!='test_labels.csv'},
              'code_sha256':digest(Path(__file__)),'processing_sha256':digest(_PROCESSING_PATH)}
    write_json(out/'评估方案.json',protocol)
    protocol_hash=digest(out/'评估方案.json')
    # Test outcomes are loaded only after model/decision registration has been written.
    labels_t=pd.read_csv(data/'test_labels.csv').set_index('vehicle_id').loc[keys['test'].vehicle_id,'class_label'].to_numpy()
    metric_rows=[];horizon_rows=[];break_even=[];confusions=[];ci_rows=[]
    for split,subset,y in [('validation_selection',selection,labels_v[selection]),('test',slice(None),labels_t)]:
        base='validation' if split.startswith('validation') else 'test'
        ids=keys[base].vehicle_id.to_numpy()[subset]
        for name,pall in model_raw.items():
            p=pall[base][subset]
            cdf=cumulative_probabilities(p)
            pred=pd.DataFrame({'vehicle_id':ids})
            for c in range(5):pred[f'p_{c}']=p[:,c]
            for k,h in enumerate(HORIZONS):
                binary=(y>=4-k).astype(int)
                horizon_rows.append({'split':split,'model':name,'horizon':h,'n':len(y),'positives':int(binary.sum()),
                    'mean_predicted':float(cdf[:,k].mean()),'observed':float(binary.mean()),
                    'brier':float(np.mean((cdf[:,k]-binary)**2)),
                    'auc':float(roc_auc_score(binary,cdf[:,k]))})
            for capacity in [None,.1]:
                mode='unlimited' if capacity is None else 'capacity_10pct'
                a=actions(p,ids,capacity);pred[mode]=a
                for w in [.5,1.,2.]:
                    metric_rows.append({'split':split,'model':name,'policy':mode,'positive_class_weight':w,
                        'mean_cost':weighted_cost(y,a,w),'alerts':int((a>0).sum()),'vehicles':len(y),
                        'total_cost':float(COST[y,a].sum()),'accuracy':float((a==y).mean())})
                for actual in range(5):
                    for proposed in range(5):
                        confusions.append({'split':split,'model':name,'policy':mode,'actual':actual,'action':proposed,
                                           'count':int(((y==actual)&(a==proposed)).sum())})
                baseline=np.zeros(len(y),dtype=int)
                difference=COST[y,a]-COST[y,baseline]
                d0=float(difference[y==0].sum());d1=float(difference[y>0].sum())
                root=-d0/d1 if d1!=0 else None
                break_even.append({'split':split,'model':name,'policy':mode,'delta_class0':d0,'delta_positive':d1,
                    'equal_cost_weight':root,'root_in_sensitivity_range':root is not None and .5<=root<=2})
                if name==selected[mode] or name=='constant_prior':
                    for w in [.5,1.,2.]:
                        ci=paired_interval(y,a,baseline,w)
                        ci_rows.append({'split':split,'model':name,'policy':mode,'comparator':'no_alert',
                            'positive_class_weight':w,'delta_mean_cost':weighted_cost(y,a,w)-weighted_cost(y,baseline,w),
                            'ci_low':ci[0],'ci_high':ci[1]})
            pred.to_csv(out/f'{split}_{name}_predictions.csv',index=False)
        for capacity in [None,.1]:
            mode='unlimited' if capacity is None else 'capacity_10pct'
            name=selected[mode]
            a=actions(model_raw[name][base][subset],ids,capacity)
            b=actions(model_raw['constant_prior'][base][subset],ids,capacity)
            for w in [.5,1.,2.]:
                ci=paired_interval(y,a,b,w)
                ci_rows.append({'split':split,'model':name,'policy':mode,'comparator':'constant_prior',
                    'positive_class_weight':w,'delta_mean_cost':weighted_cost(y,a,w)-weighted_cost(y,b,w),
                    'ci_low':ci[0],'ci_high':ci[1]})
        for w in [.5,1.,2.]:
            metric_rows.append({'split':split,'model':'no_alert','policy':'none','positive_class_weight':w,
                'mean_cost':weighted_cost(y,np.zeros(len(y),dtype=int),w),'alerts':0,'vehicles':len(y),
                'total_cost':float(COST[y,0].sum()),'accuracy':float((y==0).mean())})
    for name,rows in [('成本比较.csv',metric_rows),('窗口验证.csv',horizon_rows),('敏感性临界点.csv',break_even),
                      ('混淆矩阵.csv',confusions),('配对区间.csv',ci_rows)]:pd.DataFrame(rows).to_csv(out/name,index=False)
    assert digest(out/'评估方案.json')==protocol_hash
    write_json(out/'运行记录.json',{'elapsed_seconds':time.time()-started,'protocol_sha256':protocol_hash,
        'test_labels_sha256':digest(data/'test_labels.csv'),'selected_models':selected,
        'validation_calibration_vehicles':int(calibration.sum()),'validation_selection_vehicles':int(selection.sum())})
    print('COMPLETE',json.dumps(selected),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    main(args.data.resolve(),args.out.resolve())
