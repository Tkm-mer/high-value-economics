# Corrected reusable processing functions.
# Derived from cerionXLII/ComponentX, commit 314ff75d294ff0b3fdf4d956ac50b60223922e9a.
# Original code: BSD 3-Clause; attribution and license accompany the input materials.
import numpy as np
import pandas as pd

HORIZONS = [6, 12, 24, 48]

def ticks(values):
    a=np.asarray(values,dtype=float)*10
    if not np.isfinite(a).all() or not np.allclose(a,np.rint(a),rtol=0,atol=1e-7):
        raise ValueError('Expected finite time values on the verified 0.1 grid')
    return np.rint(a).astype(np.int64)

def fill_missing_values(df, medians=None):
    """Stable chronological within-vehicle fill; optional previously fitted values.

    Without medians, leading missing observations remain missing. This supports
    estimators with native missing-value handling; no target-batch fitting occurs.
    """
    if df.duplicated(['vehicle_id','time_step']).any():
        raise ValueError('Ambiguous vehicle/time key')
    out=df.sort_values(['vehicle_id','time_step'],kind='stable').copy()
    cols=[c for c in df if c not in ['vehicle_id','time_step']]
    out[cols]=out.groupby('vehicle_id',sort=False)[cols].ffill()
    if medians is not None:
        extra=set(medians.index)-set(cols)
        if extra:raise ValueError('Imputation state contains non-feature fields')
        out[cols]=out[cols].fillna(medians)
    return out

def add_class_labels(tte, readouts):
    """Future first-repair labels; censoring is resolved separately per horizon."""
    required=['vehicle_id','length_of_study_time_step','in_study_repair']
    if tte.vehicle_id.duplicated().any():raise ValueError('Duplicate endpoint key')
    if not tte.in_study_repair.isin([0,1]).all():raise ValueError('Invalid event flag')
    out=readouts.merge(tte[required],on='vehicle_id',how='left',validate='many_to_one',indicator=True)
    if (out['_merge']!='both').any():raise ValueError('Missing endpoint record')
    out=out.drop(columns='_merge')
    r=ticks(out.length_of_study_time_step)-ticks(out.time_step)
    e=out.in_study_repair.to_numpy()==1
    valid=(r>=0)&~(e&(r==0))
    out['remaining_followup']=r/10
    out['risk_set']=valid
    for h in HORIZONS:
        y=np.full(len(out),-1,dtype=np.int8)
        y[valid&e&(r<=h*10)]=1
        y[valid&((e&(r>h*10))|(~e&(r>=h*10)))]=0
        out[f'y_{h}']=y
    y=np.full(len(out),-1,dtype=np.int8)
    y[valid&((e&(r>480))|(~e&(r>=480)))]=0
    for lo,hi,k in [(240,480,1),(120,240,2),(60,120,3),(0,60,4)]:
        y[valid&e&(r>lo)&(r<=hi)]=k
    out['class_label']=y
    return out
