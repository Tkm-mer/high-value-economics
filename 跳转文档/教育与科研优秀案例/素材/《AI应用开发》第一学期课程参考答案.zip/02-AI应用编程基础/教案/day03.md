# AI 应用编程基础——Java 基础 - 教师教案（Day03：第 1—6 课时）

**总课时：** 6 课时 × 45 分钟
**授课对象：** 高职 / 应用型本科一年级学生，已学习 Day01（Java 起步、变量、运算符、流程控制）与 Day02（分支、循环、一维数组、查找排序）
**知识点覆盖：** 第 5 章（二维数组、方法与递归）+ 第 6 章（综合案例：大学生实训管理系统 + AI 辅助排错优化）
**基线版本：** JDK 25 LTS · IntelliJ IDEA 2026.1

**用户偏好说明：** 本教案采用 6 段结构（目标 / 重难点 / 教学过程 / 板书 / 作业 / 反思），无独立"教学准备"与"情感态度"小节，教学过程各环节直接以时长切分。

---

## 第 1 课时：二维数组的定义、初始化与遍历

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 说清楚"二维数组本质是数组的数组"，能描述其内存结构（外层数组存"每一行数组的地址"）。
2. 熟练掌握二维数组的**静态初始化**、**动态初始化**、**不规则二维数组**三种定义方式，并能选择合适场景使用。
3. 能用**普通 for 双重循环**与**增强 for 双重循环**两种方式遍历二维数组，读写任意 `arr[i][j]` 元素。

#### 1.1.2 过程与方法目标
1. 通过"班级成绩表"实例，将现实中的行列数据抽象为二维数组，训练**数据建模**能力。
2. 通过对比一维数组与二维数组的定义 / 遍历，训练**知识迁移**能力。

### 1.2 教学重难点
- **重点**：二维数组三种初始化方式 / 双重 for 循环遍历 / 通过 `arr.length` 与 `arr[i].length` 分别取"行数"和"列数"
- **难点**：不规则二维数组的理解（每行长度可不同）/ 外层数组存的是"引用"这一内存模型

### 1.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问："上一课我们用一维数组存了一个班学生的成绩，可是现实中一个学生有语文、数学、英语三门课，全班 40 个学生怎么存？"给学生 30 秒时间讨论。学生大概率会说"用两个数组"或"合并到一个数组"。教师引出："今天要学的是最自然的表达方式——**二维数组**。"

#### 新知讲授（18 分钟）

**（1）概念（3 分钟）**

板书：`二维数组 = 数组的数组`。类比：一维数组是"一排学生的成绩"，二维数组是"一排一排的成绩表"，每一行本身还是一个一维数组。

**（2）静态初始化（4 分钟）**

在 IDEA 现场敲：

```java
int[][] scores = {
    {88, 92, 76},   // 张三：语文 数学 英语
    {85, 89, 91},   // 李四
    {72, 68, 80}    // 王五
};
```

强调：`{}` 外面的大括号代表**整体**，里面每一个 `{}` 代表**一行**。行与行之间用逗号分隔。

**（3）动态初始化（3 分钟）**

```java
int[][] arr = new int[3][4];   // 3 行 4 列，全部默认为 0
arr[0][0] = 1;
arr[2][3] = 100;
```

对比表格：

| 初始化方式 | 语法 | 使用场景 |
|------|------|------|
| 静态初始化 | `int[][] a = {{...},{...}}` | 数据已知，如成绩表 |
| 动态初始化 | `int[][] a = new int[3][4]` | 只知道规模，先占位 |
| 不规则 | `int[][] a = new int[3][]` | 每行长度不同 |

**（4）不规则二维数组（4 分钟）**

```java
int[][] arr = new int[3][];   // 只定行数
arr[0] = new int[]{1, 2};
arr[1] = new int[]{3, 4, 5, 6};
arr[2] = new int[]{7};
```

用 Mermaid 图（或黑板）画外层数组指向三个长度不同的一维数组，强调**外层数组存的是引用**。

**（5）遍历（4 分钟）**

普通 for 循环：

```java
for (int i = 0; i < scores.length; i++) {
    for (int j = 0; j < scores[i].length; j++) {
        System.out.print(scores[i][j] + "\t");
    }
    System.out.println();
}
```

增强 for 循环：

```java
for (int[] row : scores) {
    for (int s : row) {
        System.out.print(s + "\t");
    }
    System.out.println();
}
```

强调：`scores.length` 是**行数**，`scores[i].length` 是**第 i 行的列数**——不是所有行都等长（不规则数组的时候）。

#### 示例演示（10 分钟）

现场编写并运行"班级成绩表"完整案例：

```java
public class ScoreTable {
    public static void main(String[] args) {
        String[] names = {"张三", "李四", "王五"};
        int[][] scores = {
            {88, 92, 76},
            {85, 89, 91},
            {72, 68, 80}
        };
        String[] subjects = {"语文", "数学", "英语"};

        System.out.print("姓名\t");
        for (String sub : subjects) System.out.print(sub + "\t");
        System.out.println("总分\t平均分");

        for (int i = 0; i < names.length; i++) {
            System.out.print(names[i] + "\t");
            int sum = 0;
            for (int j = 0; j < scores[i].length; j++) {
                System.out.print(scores[i][j] + "\t");
                sum += scores[i][j];
            }
            double avg = sum * 1.0 / scores[i].length;
            System.out.printf("%d\t%.2f%n", sum, avg);
        }
    }
}
```

运行结果对齐讲解：`\t` 制表符如何让输出对齐；`%.2f` 保留两位小数；`sum * 1.0` 强制转 double 避免整除。

#### 课堂练习（10 分钟）
1. 定义一个 `int[4][4]` 的二维数组，用双重 for 循环填入 1—16，然后打印成 4×4 矩阵。
2. 打印九九乘法表（下三角形式），要求用二维数组存储所有乘积后再遍历输出。
3. （挑战）定义一个不规则二维数组存储"每周每天要背的单词"（周一 2 个、周二 5 个……周日 1 个），用增强 for 循环遍历打印。

#### 小结（2 分钟）
- 二维数组 = 数组的数组，外层存引用。
- 三种初始化：静态、动态、不规则，各有适用场景。
- 遍历用双重循环，注意 `arr.length` 与 `arr[i].length` 的区别。
- 下节课：把"重复代码"抽出来——**方法**登场。

### 1.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│         第 1 课时 二维数组                         │
├────────────────────────────────────────────────────┤
│ 1. 概念：数组的数组，外层存引用                    │
│                                                    │
│ 2. 三种初始化                                      │
│    静态：int[][] a = {{1,2},{3,4}};                │
│    动态：int[][] a = new int[3][4];                │
│    不规则：int[][] a = new int[3][];               │
│                                                    │
│ 3. 遍历                                            │
│    for (int i = 0; i < a.length; i++)              │
│      for (int j = 0; j < a[i].length; j++)         │
│                                                    │
│ 4. 易错点                                          │
│    a.length ≠ a[i].length                          │
│    行 vs 列 顺序                                   │
└────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. 编写 `MatrixTranspose.java`：把一个 3×3 二维数组转置后输出（行变列、列变行）。
2. 编写 `WeeklyPlan.java`：用不规则二维数组存储一周每天的学习任务，输出格式为"周一：Java, Python"。
3. （挑战）编写 `Sudoku9x9.java`：用 9×9 二维数组存储一个数独题面（0 表示空格），打印时把 0 换成 `_`。

### 1.6 教学反思提示
- 学生是否理解"外层数组存的是引用"？可用画图 + 内存追踪法加深印象。
- `arr.length` 与 `arr[i].length` 混淆是普遍现象，多举反例（不规则数组）加强区分。

---

## 第 2 课时：方法（函数）的定义与调用 + 方法重载

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能按 `修饰符 返回值类型 方法名(参数列表) { 方法体 }` 的语法准确定义方法，理解 `public static` 与 `void` 的含义。
2. 区分**形参**与**实参**，掌握 Java **基本类型按值传递、引用类型传递地址副本**的机制，能预判方法调用后变量是否被修改。
3. 掌握**方法重载**的判定规则（同类中方法名相同、参数列表不同；与返回值、修饰符、参数名无关），能设计 3 个以上重载版本并说明编译器如何选中。

#### 2.1.2 过程与方法目标
1. 通过将重复代码"提取为方法"的重构演示，训练**代码复用意识**。
2. 通过分析 `System.out.println` 的多态表现，建立**从 JDK 源码学习设计模式**的习惯。

### 2.2 教学重难点
- **重点**：方法定义语法 / 形参实参传递 / 方法重载判定规则 / 单一职责原则
- **难点**：引用类型参数为什么"能改内容不能改指向" / 重载不看返回值这一容易踩坑的规则

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
展示上一节的"班级成绩表"代码，指出其中"计算一行总分"的逻辑写死在 main 里。提问："如果 5 个班都要算总分，代码要复制 5 遍吗？"引出**方法**——重复代码的救星。

#### 新知讲授（20 分钟）

**（1）方法定义语法（4 分钟）**

板书：

```text
修饰符  返回值类型  方法名(参数列表) {
    方法体
    return 返回值;
}
```

关键说明：
- 目前所有方法都写 `public static`（第 9 章会解释 `static` 的深层含义，现在只需照写）。
- `void` 表示没有返回值。
- 方法必须写在**类内、main 外**，与 main 平级。

**（2）第一个方法示例（3 分钟）**

```java
public class MethodDemo {
    public static void main(String[] args) {
        int result = sum(10, 20);
        System.out.println("和 = " + result);
    }
    public static int sum(int a, int b) {
        return a + b;
    }
}
```

**（3）void 方法（2 分钟）**

```java
public static void greet(String name) {
    System.out.println("你好, " + name);
}
```

**（4）形参 vs 实参 + 参数传递机制（6 分钟）**

对比表：

| 概念 | 位置 | 举例 |
|------|------|------|
| 形参 | 方法定义时的括号内 | `sum(int a, int b)` |
| 实参 | 方法调用时的括号内 | `sum(10, 20)` |

**基本类型按值传递**——现场敲一遍让学生预测输出：

```java
public static void change(int x) { x = 100; }
public static void main(String[] args) {
    int num = 5;
    change(num);
    System.out.println(num);   // 输出？答案：5
}
```

**引用类型传递地址副本**——修改内容能生效：

```java
public static void reset(int[] arr) { arr[0] = 0; }
public static void main(String[] args) {
    int[] a = {1, 2, 3};
    reset(a);
    System.out.println(a[0]);   // 输出？答案：0
}
```

板书画内存图：`num` 是变量本身副本，`arr` 是"地址副本"——地址指向的仍是同一个堆上的数组。

**（5）单一职责原则（2 分钟）**

强调："一个方法只做一件事"，如"读取用户输入 + 校验 + 计算 + 打印"应拆成 4 个方法。这条原则从入门就要建立，AI 代码审查最爱指出的问题就是"方法太长、职责太杂"。

**（6）方法重载（3 分钟）**

定义：同一个类中，方法名相同、参数列表不同即为重载。判定只看**方法名 + 参数列表**（个数、类型、顺序），与返回值、修饰符、参数名无关。

```java
public static int add(int a, int b) { return a + b; }
public static double add(double a, double b) { return a + b; }
public static int add(int a, int b, int c) { return a + b + c; }
public static int add(int[] arr) {
    int s = 0;
    for (int x : arr) s += x;
    return s;
}
```

反例：

```java
public static int add(int a, int b) { return a + b; }
public static double add(int a, int b) { return a + b; }   // ❌ 只有返回值不同，编译报错
```

举例 `System.out.println`，它重载了十几种参数类型——正是有了重载，`println` 才能"什么都能打印"。

#### 示例演示（8 分钟）

演示：把第 1 课时的"班级成绩表"重构为多个方法：

```java
public class ScoreTableRefactored {
    public static void main(String[] args) {
        int[][] scores = {{88, 92, 76}, {85, 89, 91}, {72, 68, 80}};
        String[] names = {"张三", "李四", "王五"};
        printHeader();
        for (int i = 0; i < names.length; i++) {
            printRow(names[i], scores[i]);
        }
    }
    public static void printHeader() {
        System.out.println("姓名\t语文\t数学\t英语\t总分\t平均分");
    }
    public static void printRow(String name, int[] row) {
        System.out.print(name + "\t");
        int sum = sum(row);
        for (int s : row) System.out.print(s + "\t");
        System.out.printf("%d\t%.2f%n", sum, sum * 1.0 / row.length);
    }
    public static int sum(int[] row) {
        int s = 0;
        for (int x : row) s += x;
        return s;
    }
}
```

指着代码问："如果新增一列'物理'，需要改动几处？"（答案：只改数据、不用改方法。）

#### 课堂练习（10 分钟）
1. 编写方法 `public static int max(int a, int b)` 返回两数最大值，并重载出接收 3 个 int、`int[]` 的版本。
2. 编写方法 `public static void swap(int[] arr, int i, int j)`，交换数组两个位置的元素，在 main 中调用验证。
3. （挑战）编写方法 `public static boolean contains(int[] arr, int target)` 判断数组是否包含某元素。

#### 小结（2 分钟）
- 方法 = 命名的可复用代码块。
- 参数传递：基本类型按值 / 引用类型按地址副本。
- 重载：同类同名参数列表不同；不看返回值。
- 下节课：方法可以调用**自己**——递归。

### 2.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│      第 2 课时 方法定义 + 重载                     │
├────────────────────────────────────────────────────┤
│ 1. 语法                                            │
│    修饰符 返回值类型 方法名(参数列表) { ... }      │
│                                                    │
│ 2. 参数传递                                        │
│    基本类型：按值传递（改不了）                    │
│    引用类型：地址副本（能改内容）                  │
│                                                    │
│ 3. 重载规则                                        │
│    方法名 + 参数列表 不同                          │
│    与返回值、修饰符无关                            │
│                                                    │
│ 4. 单一职责                                        │
│    一个方法只做一件事                              │
└────────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. 编写 `MathToolkit.java`：提供 `add / sub / mul / div` 四个方法，都做重载（int 版、double 版），并在 main 中调用测试。
2. 编写 `ArrayUtils.java`：提供 `printArray`（重载 `int[] / double[] / String[]` 三个版本）与 `reverse(int[])`（原地反转）两个方法。
3. （挑战）设计一个 `boolean isPalindrome(String s)` 方法判断字符串是否回文，并重载出忽略大小写的版本 `boolean isPalindrome(String s, boolean ignoreCase)`。

### 2.6 教学反思提示
- 学生对"引用类型按地址副本"的理解常常停留在"传的是地址"，需要画图强调**副本**这一层。
- 重载"不看返回值"是编译器规则，容易被理所当然误解，务必用编译报错的反例演示一次。

---

## 第 3 课时：递归

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 理解**递归 = 方法自己调用自己**，能背出递归的三要素（终止条件、规模缩小、递归表达式）。
2. 独立写出阶乘、斐波那契、欧几里得 gcd 三个经典递归实现，并能解释调用栈的展开过程。
3. 能识别递归与循环的适用边界，理解 `StackOverflowError` 的产生原因。

#### 3.1.2 过程与方法目标
1. 通过手动画出调用栈，训练**追踪程序执行流**的能力。
2. 通过对比"递归斐波那契" vs "迭代斐波那契"的性能差异，建立**算法效率意识**。

### 3.2 教学重难点
- **重点**：递归三要素 / 阶乘 / 斐波那契 / 递归与循环的对比
- **难点**：调用栈展开的可视化 / 递归斐波那契为什么慢（重复子问题）

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
放一张俄罗斯套娃 / 两面镜对照的图片，问："如果一个方法可以调用别的方法，那它能不能调用它自己？"暂停 10 秒，然后答："可以，这叫**递归**。"

#### 新知讲授（15 分钟）

**（1）第一个递归：阶乘（5 分钟）**

阶乘定义：`n! = n × (n-1)!`，`0! = 1`。

```java
public static long factorial(int n) {
    if (n <= 1) return 1;              // ① 递归终止条件
    return n * factorial(n - 1);       // ② 递归调用
}
```

板书画调用栈展开：

```text
factorial(5) = 5 * factorial(4)
             = 5 * 4 * factorial(3)
             = 5 * 4 * 3 * factorial(2)
             = 5 * 4 * 3 * 2 * factorial(1)
             = 5 * 4 * 3 * 2 * 1 = 120
```

强调：每次调用都会在栈上"叠一层"，直到碰到终止条件才开始一层层"回卷"。

**（2）递归三要素（3 分钟）**

| 要素 | 说明 | 阶乘中的体现 |
|------|------|------|
| 终止条件 | 什么时候不再递归 | `n <= 1 return 1` |
| 规模缩小 | 每次问题变小 | `n - 1` |
| 递归表达式 | 大问题 = 小问题 + 一点点操作 | `n * factorial(n-1)` |

**忘写终止条件的后果**：现场演示删掉 `if` 那一行，程序立刻抛 `StackOverflowError`，因为栈无限增长。

**（3）斐波那契（4 分钟）**

```java
public static long fib(int n) {
    if (n <= 1) return n;
    return fib(n - 1) + fib(n - 2);
}
```

看似优雅，但**指数级重复计算**——`fib(40)` 就明显卡顿。板书画 `fib(5)` 的调用树，让学生数一下 `fib(2)` 被调用了多少次（答：3 次）。

**（4）迭代版斐波那契对比（3 分钟）**

```java
public static long fibIterative(int n) {
    if (n <= 1) return n;
    long prev = 0, curr = 1;
    for (int i = 2; i <= n; i++) {
        long next = prev + curr;
        prev = curr;
        curr = next;
    }
    return curr;
}
```

强调：能用循环解决的，不要滥用递归。

#### 示例演示（12 分钟）

**演示 1：欧几里得 gcd（递归）**

```java
public static int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}
```

现场跑 `gcd(48, 18)`，板书展开：`gcd(48,18) -> gcd(18,12) -> gcd(12,6) -> gcd(6,0) -> 6`。

**演示 2：性能对比**

```java
public class FibBenchmark {
    public static void main(String[] args) {
        int n = 40;
        long t1 = System.currentTimeMillis();
        long r1 = fib(n);
        long t2 = System.currentTimeMillis();
        long r2 = fibIterative(n);
        long t3 = System.currentTimeMillis();
        System.out.println("递归结果：" + r1 + "，用时：" + (t2 - t1) + " ms");
        System.out.println("迭代结果：" + r2 + "，用时：" + (t3 - t2) + " ms");
    }
    // fib、fibIterative 见上文
}
```

预期输出：递归约 300—800 ms，迭代 0 ms。当场展示"低效算法 vs 高效算法"的鸿沟。

**递归 vs 循环 对比表**：

| 维度 | 递归 | 循环 |
|------|------|------|
| 可读性 | 分治问题（树、目录）优雅 | 顺序处理直观 |
| 性能 | 有方法栈开销 | 通常更快 |
| 内存 | 栈深度受限 | 稳定 |
| 建议 | 表达优雅、深度可控时 | 追求性能、深度较大时 |

#### 课堂练习（12 分钟）
1. 用递归实现 `sum(int n)` = 1+2+…+n，并画出 `sum(4)` 的调用栈展开图。
2. 用递归判断字符串是否回文：`boolean isPalindrome(String s, int i, int j)`。
3. 用递归打印一个正整数的每一位（例如 `printDigits(12345)` 输出 `1 2 3 4 5`）。

#### 小结（3 分钟）
- 递归 = 方法自己调用自己。
- 三要素：终止条件、规模缩小、递归表达式。
- 慎用递归：栈开销、重复计算（斐波那契是典型反例）。
- 下节课：进入本日下半段——用前 5 章的知识拼一个**大学生实训管理系统**。

### 3.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│         第 3 课时 递归                             │
├────────────────────────────────────────────────────┤
│ 1. 三要素                                          │
│    1.终止条件（base case）                         │
│    2.规模缩小                                      │
│    3.递归表达式                                    │
│                                                    │
│ 2. 阶乘                                            │
│    factorial(n) = n * factorial(n-1), 0!=1         │
│                                                    │
│ 3. 陷阱                                            │
│    忘终止 → StackOverflowError                     │
│    fib(n) → 指数级重复子问题                       │
│                                                    │
│ 4. 递归 vs 循环                                    │
│    优雅 vs 高效，能循环则循环                      │
└────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. 用递归实现 `power(int base, int exp)` 计算 `base^exp`。
2. 用递归实现"汉诺塔"打印移动步骤（预习也可，进阶）。
3. （挑战）让通义灵码把递归 gcd 改写为迭代版，并用 20 组随机数据对比两种实现结果是否一致。

### 3.6 教学反思提示
- 递归对新手最难的是"想象调用栈的展开与回卷"，多用板书画图，或使用 IDEA 的 Debug + Frames 视图现场展示栈帧。
- 递归斐波那契的性能悬崖是很好的 aha 时刻，不要跳过 benchmark 对比环节。

---

## 第 4 课时：大学生实训管理系统——需求分析与命令行菜单主循环

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能从功能需求出发，画出**流程图**、设计**数据结构**（四并列一维数组）与**菜单主循环骨架**。
2. 掌握用 `while(true) + switch` 构建命令行系统的常见模式，能用 JDK 14+ 的 **箭头形 switch** 简化 case 结构。
3. 会用 `Scanner` 读取多种类型的用户输入，理解 `nextInt / next / nextDouble` 的行为差异。

#### 4.1.2 过程与方法目标
1. 通过"需求 → 流程图 → 数据结构 → 骨架代码"的完整设计过程，训练**先设计后编码**的工程习惯。
2. 通过课堂拼装骨架代码到 IDEA 中运行，训练**问题分解**能力。

### 4.2 教学重难点
- **重点**：功能需求梳理 / 四并列数组的数据结构设计 / 菜单主循环骨架 / Scanner 使用
- **难点**：静态变量的作用范围（`static` 数组 + `static Scanner`）/ 后面几节的方法定义为什么全写 `static`

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问："从今天起，我们不再学新语法，改用前 5 章学的东西**拼出一个真正的小系统**。"给学生播 1 分钟：想象自己是辅导员，需要一个软件管理 50 个学生的实训信息——你希望它能干什么？收集学生回答（添加、查看、查找、删除、统计…），把关键词写到黑板上。

#### 新知讲授（18 分钟）

**（1）功能需求梳理（4 分钟）**

在黑板上把学生给出的答案整理成 7 条：

1. 添加学生（学号、姓名、年龄、Java 成绩）
2. 查看所有学生（表格形式）
3. 按学号查找
4. 修改成绩
5. 删除学生
6. 统计（总人数、平均分、最高最低分、及格率）
7. 退出

**（2）系统流程图（3 分钟）**

板书画流程图：

```text
启动 → 显示菜单 → 用户选择
             ↓
        1/2/3/4/5/6 → 执行对应操作 → 回到菜单
             ↓
             7 → 退出
```

**（3）数据结构设计（4 分钟）**

关键问题："学生信息由 4 个字段组成，怎么存 50 个学生？"

采用**四个并列的一维数组**：

```java
static String[] ids     = new String[50];   // 学号
static String[] names   = new String[50];   // 姓名
static int[]    ages    = new int[50];      // 年龄
static double[] scores  = new double[50];   // 成绩
static int      count   = 0;                // 当前实际学生数
```

板书强调：**四个数组按同一下标对齐** —— `ids[3]、names[3]、ages[3]、scores[3]` 属于同一个学生。

预告："这种写法有明显缺点：任何字段增删都要动 4 个地方。第 7 章会用**类**优雅地解决——但现在先用数组，正好巩固前 5 章。"

**（4）菜单主循环骨架（4 分钟）**

```java
public static void main(String[] args) {
    while (true) {
        printMenu();
        System.out.print("请输入操作编号：");
        int op = sc.nextInt();
        switch (op) {
            case 1 -> addStudent();
            case 2 -> listStudents();
            case 3 -> findStudent();
            case 4 -> modifyScore();
            case 5 -> deleteStudent();
            case 6 -> printStats();
            case 7 -> {
                System.out.println("再见！");
                return;
            }
            default -> System.out.println("无效编号，请重新输入。");
        }
    }
}
```

讲解要点：
- `while(true)` + `return` 退出：菜单循环的标准模式。
- **箭头形 switch**（JDK 14+）：比传统 `case 1:` 简洁、不用 `break`、天然防击穿。
- 方法都写 `static`，因为 `main` 是 static 的，它只能直接调用类里的静态方法。

**（5）Scanner 基础（3 分钟）**

| 方法 | 读取内容 | 特点 |
|------|------|------|
| `nextInt()` | 一个 int | 不吃换行符 |
| `nextDouble()` | 一个 double | 同上 |
| `next()` | 一个"单词"（空白分隔） | 遇到空白停止 |
| `nextLine()` | 一整行 | 会连换行符一起吃 |

⚠️ 混用 `nextInt` 和 `nextLine` 是典型坑（下一节详讲）。

#### 示例演示（14 分钟）

现场把骨架代码敲进 IDEA：

```java
import java.util.Scanner;

public class StudentSystem {
    static String[] ids     = new String[50];
    static String[] names   = new String[50];
    static int[]    ages    = new int[50];
    static double[] scores  = new double[50];
    static int      count   = 0;

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            System.out.print("请输入操作编号：");
            int op = sc.nextInt();
            switch (op) {
                case 1 -> System.out.println("[TODO] 添加学生");
                case 2 -> System.out.println("[TODO] 查看所有");
                case 3 -> System.out.println("[TODO] 查找");
                case 4 -> System.out.println("[TODO] 修改");
                case 5 -> System.out.println("[TODO] 删除");
                case 6 -> System.out.println("[TODO] 统计");
                case 7 -> {
                    System.out.println("再见！");
                    return;
                }
                default -> System.out.println("无效编号，请重新输入。");
            }
        }
    }

    static void printMenu() {
        System.out.println();
        System.out.println("========== 大学生实训管理系统 ==========");
        System.out.println("1. 添加学生");
        System.out.println("2. 查看所有学生");
        System.out.println("3. 按学号查找");
        System.out.println("4. 修改成绩");
        System.out.println("5. 删除学生");
        System.out.println("6. 统计信息");
        System.out.println("7. 退出");
        System.out.println("=========================================");
    }
}
```

**运行 & 演示**：跑一遍，输入 1、2、7，看到 `[TODO]` 打印，最后正常退出。**强调这是"骨架先行、功能后填"的工程做法**——这也是 AI 编程助手最推荐的开发节奏。

#### 课堂练习（8 分钟）
1. 把上面骨架代码复制到 IDEA 中运行，输入 1—8 各测一次，观察 `default` 分支。
2. 修改菜单：将退出编号从 `7` 改成 `0`，把 `switch` 相应位置调整。
3. （挑战）在 `printMenu` 里加一行动态显示"当前学生数：X"，用 `count` 变量。

#### 小结（3 分钟）
- 需求分析 → 流程图 → 数据结构 → 骨架代码，工程化四步走。
- 四并列数组临时代替"类"，用同下标对齐。
- 箭头形 switch 是 JDK 14+ 的标准写法。
- 下节课：把每个 `[TODO]` 变成真代码——增删改查。

### 4.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│    第 4 课时 实训管理系统骨架                      │
├────────────────────────────────────────────────────┤
│ 1. 需求 7 条                                       │
│    增 查 找 改 删 统 退                            │
│                                                    │
│ 2. 数据结构（并列 4 数组）                         │
│    ids[]  names[]  ages[]  scores[]                │
│    count 记录当前学生数                            │
│                                                    │
│ 3. 主循环                                          │
│    while(true) { printMenu(); switch(op){...} }    │
│                                                    │
│ 4. 静态变量                                        │
│    main 是 static，只能调 static                   │
└────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. 完成"课堂练习 3"，让菜单顶部显示当前学生数。
2. 补充一个 `case 0 -> printMenu();` 让用户输入 0 时重新刷新菜单。
3. （挑战）设计一个"欢迎登录"环节：在 `main` 开始时让用户输入姓名，主循环里每次菜单都称呼这个名字。

### 4.6 教学反思提示
- 学生第一次接触"没学完整语法就搭系统"，注意鼓励——骨架跑起来是成功的一半。
- 静态变量的作用范围学生易困惑，可用一句"static = 属于类、不属于对象"先按住，第 9 章展开。

---

## 第 5 课时：大学生实训管理系统——数组存储学生信息 + 增删改查功能

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 独立编写**添加学生**方法，包含数组容量检查、学号唯一性校验、四数组同步写入。
2. 掌握**通用工具方法 `indexOf`** 的封装，理解"查找是增删改的基石"这一设计思路。
3. 完成**查看、查找、修改、删除、统计**五个方法，特别是**数组元素删除**（后续元素前移 + `count--`）的正确实现。

#### 5.1.2 过程与方法目标
1. 通过"先写 indexOf，再写增删改查"的顺序，训练**先复用后扩展**的开发节奏。
2. 通过 `printStats` 案例，训练一遍循环内同时求**总分、最大、最小、及格数**的**一次遍历多任务**技巧。

### 5.2 教学重难点
- **重点**：`addStudent` 完整流程 / `indexOf` 复用 / `deleteStudent` 元素前移逻辑 / `printStats` 一次循环多个统计量
- **难点**：`String.equals` vs `==` 的正确使用 / 删除时 `j < count - 1` 边界正确写法

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
回顾上节骨架：7 个 `[TODO]`。今天要一次性把这些坑全填上。"我们不新开代码，就在骨架里长血肉。"

#### 新知讲授（20 分钟）

**（1）添加学生 `addStudent`（4 分钟）**

```java
static void addStudent() {
    if (count >= ids.length) {
        System.out.println("班级已满，无法继续添加。");
        return;
    }
    System.out.print("学号：");
    String id = sc.next();
    if (indexOf(id) != -1) {
        System.out.println("该学号已存在。");
        return;
    }
    System.out.print("姓名：");
    String name = sc.next();
    System.out.print("年龄：");
    int age = sc.nextInt();
    System.out.print("Java 成绩：");
    double score = sc.nextDouble();

    ids[count]    = id;
    names[count]  = name;
    ages[count]   = age;
    scores[count] = score;
    count++;
    System.out.println("添加成功。");
}
```

关键点：
- **容量检查在最前面**，防止越界。
- **学号唯一性**由 `indexOf` 保证。
- 四数组按 `count` 下标同步写入。
- 全部成功后 `count++`。

**（2）通用工具 `indexOf`（3 分钟）**

```java
static int indexOf(String id) {
    for (int i = 0; i < count; i++) {
        if (ids[i].equals(id)) return i;
    }
    return -1;
}
```

⚠️ **`String` 比较必须用 `equals`**，`==` 只比较**引用地址**，第 11 章会详解。这是初学者最容易翻船的地方。

**（3）查看所有 `listStudents`（3 分钟）**

```java
static void listStudents() {
    if (count == 0) {
        System.out.println("暂无学生。");
        return;
    }
    System.out.println("学号\t姓名\t年龄\t成绩");
    for (int i = 0; i < count; i++) {
        System.out.println(ids[i] + "\t" + names[i] + "\t" + ages[i] + "\t" + scores[i]);
    }
}
```

**（4）查找 `findStudent` + 修改 `modifyScore`（3 分钟）**

```java
static void findStudent() {
    System.out.print("请输入要查找的学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) { System.out.println("未找到。"); return; }
    System.out.println("学号：" + ids[i]);
    System.out.println("姓名：" + names[i]);
    System.out.println("年龄：" + ages[i]);
    System.out.println("成绩：" + scores[i]);
}

static void modifyScore() {
    System.out.print("请输入学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) { System.out.println("未找到。"); return; }
    System.out.print("请输入新成绩：");
    scores[i] = sc.nextDouble();
    System.out.println("修改成功。");
}
```

指出：**只要有了 `indexOf`，后续所有"按学号操作"都是一行调用。**

**（5）删除学生 `deleteStudent`（4 分钟）**

数组删除的关键：**把后面的元素向前挪一位**，然后 `count--`。

```java
static void deleteStudent() {
    System.out.print("请输入要删除的学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) { System.out.println("未找到。"); return; }
    for (int j = i; j < count - 1; j++) {
        ids[j]    = ids[j + 1];
        names[j]  = names[j + 1];
        ages[j]   = ages[j + 1];
        scores[j] = scores[j + 1];
    }
    ids[count - 1] = null;
    names[count - 1] = null;
    ages[count - 1] = 0;
    scores[count - 1] = 0;
    count--;
    System.out.println("删除成功。");
}
```

板书画图：假设 count=5，删除下标 1 的学生，箭头显示 `arr[2]→arr[1]，arr[3]→arr[2]，arr[4]→arr[3]`，最后 `arr[4] = null`，`count = 4`。

⚠️ **循环边界必须是 `j < count - 1`**——写成 `j <= count - 1` 会导致 `arr[count]` 越界，写成 `j < count` 会访问 `arr[count]`（同样问题）。

**（6）统计 `printStats`（3 分钟）**

```java
static void printStats() {
    if (count == 0) { System.out.println("暂无数据。"); return; }
    double sum = 0, max = scores[0], min = scores[0];
    int passCount = 0;
    for (int i = 0; i < count; i++) {
        sum += scores[i];
        if (scores[i] > max) max = scores[i];
        if (scores[i] < min) min = scores[i];
        if (scores[i] >= 60) passCount++;
    }
    System.out.println("总人数：" + count);
    System.out.printf("平均分：%.2f%n", sum / count);
    System.out.println("最高分：" + max);
    System.out.println("最低分：" + min);
    System.out.printf("及格率：%.2f%%%n", passCount * 100.0 / count);
}
```

"**一次遍历、多个变量累加**"是数组统计的经典模式，比循环 4 次更高效。

#### 示例演示（14 分钟）

把 `[TODO]` 换成上面的所有方法，得到**完整的 `StudentSystem.java`**（约 130 行）。现场跑：

1. 添加 3 个学生：`1001 张三 20 88.5` / `1002 李四 21 72.0` / `1003 王五 19 55.0`
2. 选择 2：查看所有 → 显示 3 行表格
3. 选择 3：查找 `1002` → 显示李四
4. 选择 4：修改 `1003` 成绩为 65.0
5. 选择 5：删除 `1002`
6. 选择 2：查看所有 → 现在只有张三、王五
7. 选择 6：统计 → 平均分、最高最低、及格率
8. 选择 7：退出

**重点确认**：删除后再查看，绝不能出现 `null` 或第 3 行错位——这是删除逻辑正确的核心指标。

#### 课堂练习（5 分钟）
1. 用课堂演示中的完整代码运行一遍全部菜单。
2. 尝试添加超过 50 个学生（可以循环脚本添加），观察容量检查是否生效。
3. （挑战）修改 `listStudents`，让输出使用 `String.format` 对齐列宽（例如 `%-8s`）。

#### 小结（3 分钟）
- 增删改查的共同基石：`indexOf`。
- 数组"删除" = 元素前移 + `count--`，注意边界 `j < count - 1`。
- 字符串比较用 `equals`，不用 `==`。
- 下节课：让 AI 来找茬 —— 排错、审查、优化。

### 5.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│    第 5 课时 增删改查完整实现                      │
├────────────────────────────────────────────────────┤
│ 1. indexOf(id) → 复用基石                          │
│    equals 不能写 ==                                │
│                                                    │
│ 2. add：容量检查 + 唯一性 + 同步四数组             │
│                                                    │
│ 3. delete：元素前移 + count--                      │
│    for (j = i; j < count-1; j++)                   │
│      arr[j] = arr[j+1]                             │
│                                                    │
│ 4. stats：一次遍历 4 个累加量                      │
│    sum / max / min / passCount                     │
└────────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. 把课堂完成的 `StudentSystem.java` 保存并跑通全部 7 个菜单。
2. 给"学号"加校验：必须是 4 位纯数字（可先用 `id.length() == 4` 简单校验）。
3. 新增菜单项"按成绩从高到低查看所有学生"，用第 4 章的排序算法（注意：交换成绩时四个数组要**同步**交换）。

### 5.6 教学反思提示
- 学生对四数组同步修改（尤其删除时前移）容易漏改一两个数组，鼓励用"抄写第一个数组的循环 → 复制粘贴改数组名"的机械方式减少出错。
- `String.equals` 与 `==` 的区别可以在这里第一次亲手踩坑：故意写 `==`，运行，让学生看到"总是找不到"的怪象。

---

## 第 6 课时：使用 AI 编程工具排错、审查及优化（Day 一 / 二 / 三 收官）

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 掌握用通义灵码 / Claude 对代码进行**排错**（发现语法与逻辑 Bug）的**提示词模板**与**表格化反馈解读**。
2. 学会向 AI 发起**代码 Review 请求**，从命名、职责、边界、UX、扩展性 5 个维度获取反馈并分类采纳。
3. 掌握"**小步慢跑 + 测试驱动**"的 AI 协作节奏，能对 AI 的建议做到"每一条都自己验证"。

#### 6.1.2 过程与方法目标
1. 通过在自己的代码中"故意注入 3 个 Bug"再让 AI 找出的实验，训练**批判性使用 AI** 的意识。
2. 通过一次完整的"审查 → 排错 → 重构"三步对话样本，训练**结构化沟通**能力。

### 6.2 教学重难点
- **重点**：三份提示词模板 / AI 反馈的分类采纳（立即采纳 / 需要讨论 / 不采纳）/ 小步慢跑对话节奏
- **难点**：识别 AI 幻觉（先跑通再优化）/ 区分"AI 说得对"与"我真的懂了"

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
把上一节的完整代码打开，故意加入 3 个 Bug（学生亲眼看着注入），提问："如果我告诉你程序偶尔崩溃、偶尔查不到人、偶尔越界，你会先查哪里？"给学生 30 秒思考，然后说："我们请通义灵码来帮忙。"

#### 新知讲授（18 分钟）

**（1）三个 Bug 注入（3 分钟）**

在班级面前把这三处改错：

1. `deleteStudent()` 里 `j < count - 1` 改成 `j <= count - 1`（多复制一次 → 越界或残留）。
2. `indexOf` 里 `.equals(id)` 改成 `==`（引用比较导致总是找不到）。
3. `printStats` 里去掉 `if (count == 0)` 判空（`count == 0` 时 `sum / count` 会 `ArithmeticException`）。

保存，程序仍能编译通过——**这就是最难的 Bug：能跑但结果不对**。

**（2）排错提示词（5 分钟）**

打开通义灵码，粘贴代码，附上标准提示词模板：

```text
你是资深 Java 讲师。下面是一段学生管理系统代码，帮我：
1. 逐行审查是否有语法错误、逻辑错误、异常边界问题；
2. 用「Bug 编号 - 位置 - 原因 - 修复建议」的表格给出反馈；
3. 用 IDEA Debug 步骤复现其中最严重的 1 个 Bug。

[粘贴代码]
```

AI 通常会准确定位 `==` 与 `equals`、`j <= count-1` 的越界，并给出正确写法。让学生现场对照 AI 输出，对比"AI 找到的" vs "老师注入的"，往往还能捞出老师没想到的第 4 条建议——这就是 AI 协作的价值。

**（3）审查提示词（5 分钟）**

排完错后，接着做 Review：

```text
请从以下维度对上面这段代码做代码 Review：
1. 命名规范；
2. 方法长度与单一职责；
3. 边界处理（空数组、非法输入、数组越界）；
4. 用户体验（提示信息是否清晰）；
5. 未来可扩展性。
最后给出 1—10 分打分及最重要的 3 条改进建议。
```

常见反馈整理：
- 输入未做类型校验，输入字母会导致 `Scanner` 崩。
- `Scanner sc` 从未关闭。
- 4 个并列数组紧耦合，任何字段增删都要动 4 处——**这是第 7 章引入"类"的动机**。

强调：AI 的反馈按**能立即采纳 / 需要讨论 / 不采纳**三类分组，不要盲目全采纳。

**（4）重构提示词（5 分钟）**

```text
请重构这段代码，做以下改动，保持功能不变：
1. 提取一个 readInt(String prompt) 方法，读取整数并对非法输入循环重试；
2. 把菜单选项从数字改为字母 a/b/c/…（可选）；
3. 优化输出格式，使用 String.format 生成对齐的表格；
4. 加入更清晰的中文提示信息。
最后附上"重构前后对比"清单。
```

**引入 AI 的正确姿势（板书 4 条）**：

1. **先自己写完能跑的版本** ——AI 优化空版本是幻觉重灾区。
2. **每次只让 AI 做一件事**——排错、审查、优化分开。
3. **对每一处 AI 建议自己动手验证**——不盲目复制。
4. **让 AI 解释理由**——`... 并说明理由`，学到的远超结果本身。

#### 示例演示（12 分钟）

**一次完整的小步慢跑对话样本**（在班级前实操）：

```text
👤 帮我审查上面的代码。
🤖 [给出 5 条建议]
👤 请只保留其中最关键的一条，帮我改代码。
🤖 [仅修改一处，给出 diff]
👤 好，接着帮我加入学号格式校验（4 位数字）。
🤖 [新增 isValidId 方法]
👤 请用 3 组测试用例验证 isValidId。
🤖 [给出通过用例]
```

关键：**每一轮只推进一小步、每次都让 AI 举例验证**——这是使用 AI 编程助手的最佳实践。

现场把 AI 生成的 `readInt` 方法接进代码：

```java
static int readInt(String prompt) {
    while (true) {
        System.out.print(prompt);
        if (sc.hasNextInt()) {
            return sc.nextInt();
        } else {
            System.out.println("输入非法，请重新输入整数。");
            sc.next();   // 消耗掉非法 token
        }
    }
}
```

把 `main` 里 `int op = sc.nextInt();` 替换成 `int op = readInt("请输入操作编号：");`，重新运行，故意输入字母 `abc`，看到程序不再崩溃而是提示重输——这就是 AI 建议的具体价值。

#### 课堂练习（8 分钟）

Day 一 / 二 / 三 全阶段收官练习：

1. 把自己的 `StudentSystem.java` 发给通义灵码，运行**排错**提示词，把 AI 找到的所有问题列表整理到 markdown 中。
2. 再运行**审查**提示词，把 5 维反馈按"立即采纳 / 需要讨论 / 不采纳"三类分类。
3. 挑选自己认为最关键的一条，让 AI 单独帮你重构，运行验证。
4. （挑战）用 AI 加入学号 4 位数字校验 + 年龄 15—40 校验 + 成绩 0—100 校验，用 3 组正常 + 3 组非法用例验证。

#### 小结（4 分钟）——第一阶段（Day01—Day03）大盘回顾

Day01（Java 起步 + 变量运算符 + 流程控制入门）：
- 主要工具：JDK 25、IntelliJ IDEA、通义灵码。
- 关键语法：数据类型、字面量、类型转换、算术 / 关系 / 逻辑运算符、`if/else`、`switch`。

Day02（分支循环深入 + 一维数组 + 查找排序）：
- 三种循环：`for` / `while` / `do-while`；`break` / `continue`。
- 一维数组的定义、遍历、常见操作（最大 / 最小 / 反转 / 复制）。
- 查找：顺序查找；排序：冒泡、选择、插入。

Day03（二维数组 + 方法 + 递归 + 综合案例 + AI 辅助）：
- 二维数组三种初始化 + 双重循环遍历。
- 方法定义 / 参数传递 / 方法重载 / 单一职责。
- 递归三要素 + 阶乘 / 斐波那契 / gcd + 递归 vs 循环。
- **完整实训管理系统**：需求 → 骨架 → 增删改查 → AI 排错审查优化。

**你现在拥有的能力**：
- 能独立读懂并写出 200 行左右的 Java 命令行程序。
- 能与 AI 编程助手协作完成排错 / Review / 重构。
- 已经建立了"先设计后编码、每一步都验证"的工程节奏。

**Day04 面向对象阶段预告**：
- 第 7 章：**类与对象、封装、构造方法**——用"类"取代 4 个并列数组，`StudentSystem` 会瘦身一半。
- 第 8 章：**继承、多态、抽象类、接口**——Java 面向对象三大支柱。
- 第 9 章：常见 API + 集合基础，`ArrayList` 让"数组容量、删除前移"这些烦恼一次性消失。

一句话：**你今天写的代码，明天会因为 OOP 而变得优雅一半、健壮一倍。**

### 6.4 板书设计

```text
┌────────────────────────────────────────────────────┐
│   第 6 课时 AI 辅助排错 / 审查 / 优化              │
├────────────────────────────────────────────────────┤
│ 1. 三个提示词模板                                  │
│    排错：Bug 编号 - 位置 - 原因 - 修复             │
│    审查：命名 / 职责 / 边界 / UX / 扩展 + 打分     │
│    重构：只做 N 项，保持功能不变                   │
│                                                    │
│ 2. 正确姿势 4 条                                   │
│    1.先自己写能跑的版本                            │
│    2.每次只做一件事                                │
│    3.每条建议自己验证                              │
│    4.让 AI 说理由                                  │
│                                                    │
│ 3. 反馈分类                                        │
│    立即采纳 / 需要讨论 / 不采纳                    │
│                                                    │
│ 4. Day01—03 → Day04 预告                           │
│    过程式 → 面向对象                               │
└────────────────────────────────────────────────────┘
```

### 6.5 课后作业（Day 收官作业汇总）

**必做（对应 Day03 每讲）**：
1. 完成第 1—5 讲每讲的课后作业（矩阵转置 / MathToolkit / 递归 gcd / 菜单欢迎登录 / 学号校验）。
2. 把整段 `StudentSystem.java` 上传通义灵码，跑一次**排错 + 审查 + 重构**完整对话，整理成 markdown 报告（分三节：AI 找到的 Bug、审查建议分类、重构 diff）。

**选做（Day03 综合挑战）**：
3. 把删除学生的 4 组数组前移改写为一个 `removeAt(int index)` 方法，减少重复代码。
4. 让 AI 帮你把统计功能里的"及格率"改为可配置的"任意分数线通过率"。
5. 尝试用第 4 章的排序算法为 `listStudents` 增加"按成绩排序"选项，注意四数组同步交换。

**Day04 预习**：
6. 阅读第 7 章前 3 页，猜一下"类"如何解决"4 个并列数组"的丑陋。

### 6.6 教学反思提示
- 第一阶段收官讲情绪重要：**先总结再展望**，让学生对已获得的能力有实感。
- 若时间允许，让 2—3 位学生上台演示自己与 AI 的对话，全班一起点评，比老师单口讲效果好得多。
- 强调"AI 是搭档不是替身"，Day04 起会有更多 OOP 内容需要独立思考，AI 只在概念清晰后才能真正帮上忙。
