# AI 应用编程基础——Java 基础 - 教师教案（Day05：第 1—7 课时）

**总课时：7 课时 × 45 分钟**
**授课对象：计算机、软件工程、AI 相关专业本科一、二年级学生**
**知识点覆盖：多态、`final`、静态成员、`Math` 工具类、抽象类、接口、枚举、Record、异常处理入门（第 9 章 + 第 10 章）**
**教材依据：《AI 应用编程基础——Java 基础》第 9 章、第 10 章**
**版本基线：JDK 25 LTS · IntelliJ IDEA 2026.1**

---

## 第 1 课时：多态

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 说出多态的定义与三要素：**继承 / 实现关系**、**子类重写父类方法**、**父类引用指向子类对象**。
2. 区分**编译期声明类型**与**运行期实际类型**，理解**动态绑定**只对方法起作用、字段仍然是静态绑定。
3. 能正确使用**向上转型**（自动）与**向下转型**（强制），并用 `instanceof` 及 JDK 16+ 的**模式匹配（pattern for instanceof）** 做安全强转。
4. 能用一个父类型形参 / 一个父类型数组承接多个子类对象，写出符合**开闭原则**的代码。

#### 1.1.2 过程与方法目标
1. 通过 `Animal / Dog / Cat` 三类的对比演示，让学生**先猜输出、再看结果**，感受动态绑定。
2. 通过\"给数组新增一个 `Bird` 子类\"的现场重构，让学生亲眼看到\"新增子类零改动\"的可扩展性。

### 1.2 教学重难点
- **重点**：多态三要素 / 父类引用调子类方法 / `instanceof` + 强制转型
- **难点**：编译期看声明类型、运行期看实际类型的\"双重视角\"；字段不参与多态

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
提问：\"上一次课我们让 `Dog extends Animal` 并重写了 `makeSound()`，现在如果我写 `Animal a = new Dog(); a.makeSound();`——**打印的是父类的\"动物在叫\"还是子类的\"汪汪汪\"？**\"
让学生举手投票，然后现场跑一遍代码，答案是\"汪汪汪\"。这就是**多态**——本节课要讲清楚为什么。

#### 新知讲授（20 分钟）

**（1）定义 + 三要素（5 分钟）**

黑板写：
- 多态 = 同一个方法调用，因**实际类型**不同而表现不同行为。
- 三要素：① 继承或实现；② 重写；③ 父类引用指向子类对象。

**（2）动态绑定：编译期 vs 运行期（8 分钟）**

用一张对照表：

| 视角 | 看什么 | 决定什么 |
|------|--------|----------|
| 编译期 | **声明类型**（`Animal a`） | 能调用哪些方法（能否通过编译） |
| 运行期 | **实际类型**（`new Dog()`） | 具体执行哪个版本的方法 |

**（3）多态的限制 + 向下转型 + `instanceof`（7 分钟）**

强调编译期只认声明类型的成员：

```java
Animal a = new Dog();
a.makeSound();     // ✔ 父类里有
// a.watchHome(); // ❌ Dog 独有，编译报错
```

要用子类独有的方法必须**向下转型**，且要先 `instanceof` 判断。介绍 JDK 16+ 的**模式匹配**写法。

#### 示例演示（10 分钟）

现场敲下面这段并跑通：

```java
public class Animal {
    public void makeSound() { System.out.println("动物在叫"); }
}
public class Dog extends Animal {
    @Override public void makeSound() { System.out.println("汪汪汪"); }
    public void watchHome() { System.out.println("看家"); }
}
public class Cat extends Animal {
    @Override public void makeSound() { System.out.println("喵喵喵"); }
}
public class PolymorphismDemo {
    public static void main(String[] args) {
        Animal[] animals = { new Dog(), new Cat(), new Dog() };
        for (Animal a : animals) {
            a.makeSound();
            if (a instanceof Dog d) {
                d.watchHome();
            }
        }
    }
}
```

跑完之后**现场重构**：加一个 `Bird extends Animal`，只在数组里加一个 `new Bird()`，`for` 循环**一行都不改**，让学生感受可扩展性。

再补一段**字段不参与多态**的反例：

```java
class Parent { int x = 1; }
class Child extends Parent { int x = 2; }

Parent p = new Child();
System.out.println(p.x);   // 输出 1（字段静态绑定）
```

#### 课堂练习（8 分钟）
1. 定义 `Shape` 父类和 `Circle`、`Rectangle` 两个子类，各自重写 `area()`。用 `Shape[]` 一次算出总面积。
2. 在上题基础上加一个 `printSpecial(Shape s)`：如果是 `Circle` 打印半径，如果是 `Rectangle` 打印长宽（用 `instanceof` 模式匹配）。

#### 小结（3 分钟）
- 多态 = 继承 + 重写 + 父类引用指向子类对象。
- 编译期看声明，运行期看实际。
- 想调子类独有方法：`instanceof` + 向下转型（JDK 16+ 用模式匹配更清爽）。
- 字段静态绑定，不参与多态。

### 1.4 板书设计

```text
┌────────────────────────────────────────────────┐
│                多态 Polymorphism               │
├────────────────────────────────────────────────┤
│ 三要素：                                       │
│   1. 继承 / 实现                               │
│   2. 子类重写                                  │
│   3. 父类引用 → 子类对象                       │
│                                                │
│ Animal a = new Dog();  // 向上转型（自动）     │
│ a.makeSound();          // 运行期调 Dog 的     │
│                                                │
│ 编译期看声明类型 / 运行期看实际类型            │
│                                                │
│ 向下转型：                                     │
│   if (a instanceof Dog d) { d.watchHome(); }   │
│                                                │
│ 字段：静态绑定（不参与多态）                   │
└────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. 定义 `Shape` 及 `Circle / Rectangle / Triangle` 三子类，重写 `area()`，用 `Shape[]` 遍历求和。
2. 用 `instanceof` 模式匹配对上题中\"半径 > 5 的圆\"单独打印\"大圆\"。
3. **挑战**：写一个方法 `Shape maxAreaShape(Shape[] arr)` 返回面积最大的形状。

### 1.6 教学反思提示
- 学生最容易在\"字段不参与多态\"这里踩坑，建议一定要现场敲一遍反例。
- `instanceof` 模式匹配是 JDK 16+ 的语法糖，如果学生用的是老版本 JDK 会编译报错，需提前统一环境到 JDK 25。

---

## 第 2 课时：`final` 关键字 + 静态变量与静态方法

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 说出 `final` 修饰**变量、方法、类**三种用法的含义，并能正确使用。
2. 理解 `final` 修饰引用类型时\"引用不可变、内容可改\"的规则。
3. 能区分\"类变量 / 类方法\"与\"实例变量 / 实例方法\"，能用类名访问静态成员。
4. 能用 `public static final` 组合定义常量，能写出符合规范的工具类（`private` 构造 + `static` 方法）。
5. 能写出静态代码块并说明其执行时机。

#### 2.1.2 过程与方法目标
1. 通过 `String` 类为什么被声明为 `final` 的讨论，引出 `final` 类的意义。
2. 通过\"给 `Student` 类做一个计数器\"的场景，让学生自己发现\"每个对象一份 vs 全体共享一份\"的区别。

### 2.2 教学重难点
- **重点**：`final` 三种用法 / `static` 成员归属于类 / 常量的推荐写法
- **难点**：`final` 修饰引用类型时的\"引用与内容\"区分；静态方法不能访问实例成员的原因

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问：\"如果我想定义圆周率 π，希望它**永远不能被改**，怎么写？\" 引出 `final`。
再问：\"如果我想统计\"当前一共创建了多少个 `Student` 对象\"，这个计数变量应该放在哪里？放在实例里每个对象一份，怎么共享？\" 引出 `static`。

#### 新知讲授（20 分钟）

**（1）`final` 的三种用法（8 分钟）**

| 修饰对象 | 效果 | 示例 |
|----------|------|------|
| 变量 | 一旦赋值，不可再改 | `final int MAX = 100;` |
| 方法 | 不可被子类重写 | `public final void hello() {}` |
| 类 | 不可被继承 | `public final class String {}` |

重点强调**引用类型**的 `final`：

```java
final int[] arr = {1, 2, 3};
arr[0] = 10;         // ✔ 内容可改
// arr = new int[5]; // ❌ 引用不能变
```

常量推荐写法：`public static final double PI = 3.14159...`——全大写、下划线分词。

**（2）静态变量与静态方法（8 分钟）**

对比表：

| 维度 | 静态成员（`static`） | 实例成员 |
|------|----------------------|----------|
| 归属 | 类 | 对象 |
| 内存 | 方法区一份 | 每对象一份 |
| 访问 | 类名. 或 对象.（推荐类名） | 对象. |
| 静态是否能访问实例 | ❌ 不能 | 实例方法能访问静态成员 |

用 `Student.totalCount` 演示\"共享\"：`new` 三个学生 → 计数为 3。

**（3）工具类范式 + 静态代码块（4 分钟）**

```java
public final class MathUtils {
    private MathUtils() {}   // 私有构造，禁止 new
    public static int max(int a, int b) { return a > b ? a : b; }
}
```

静态代码块 `static { ... }`：**类加载时执行一次**，用来初始化静态资源（如从环境变量读数据库 URL）。

#### 示例演示（10 分钟）

现场敲两段：

**示例 1：`Student` 计数器**

```java
public class Student {
    static int totalCount;
    String name;
    public Student(String name) {
        this.name = name;
        totalCount++;
    }
}
public class Demo {
    public static void main(String[] args) {
        new Student("张三");
        new Student("李四");
        new Student("王五");
        System.out.println(Student.totalCount);   // 3
    }
}
```

**示例 2：常量 + 工具类**

```java
public class Constants {
    public static final double PI = 3.14159265358979;
    public static final int MAX_STUDENT = 50;
}
double area = Constants.PI * 5 * 5;
```

演示：把 `PI = 3.14` 再赋一遍 → 编译报错，让学生亲眼看到 `final` 的\"锁\"。

#### 课堂练习（8 分钟）
1. 定义 `MathConstants` 类，含 `PI / E / MAX_INT` 三个 `public static final` 常量；用一段代码调用它们。
2. 给 `Book` 类加一个 `static int totalBooks`，每 `new` 一本 +1；写一个静态方法 `getTotalBooks()`。

#### 小结（4 分钟）
- `final`：变量不可改、方法不可重写、类不可继承。
- `static`：属于类、全体共享、用类名访问、只能访问静态成员。
- 常量组合：`public static final`。
- 工具类：`final class` + `private` 构造 + `static` 方法。

### 2.4 板书设计

```text
┌────────────────────────────────────────────────┐
│         final  +  static                       │
├────────────────────────────────────────────────┤
│ final 变量：不可改                             │
│ final 方法：不可重写                           │
│ final 类：不可继承（如 String）                │
│                                                │
│ final 引用：引用不变，内容可改                 │
│                                                │
│ static → 属于类，非属于对象                    │
│   Student.totalCount   ← 推荐类名调用          │
│                                                │
│ static 方法 只能访问 static 成员               │
│                                                │
│ 常量：public static final XXX_YYY = ...        │
│                                                │
│ 工具类范式：final class + private 构造 + static│
└────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. 写一个 `StringUtils` 工具类，包含 `isEmpty(String)`、`reverse(String)` 两个静态方法，遵循\"工具类范式\"。
2. 定义 `Order` 类含 `final String orderId`（构造时赋值）、`static int nextId`（自增生成 ID）。
3. **挑战**：给 `Order` 加一个静态代码块，从环境变量读取 `ORDER_PREFIX`，若未设置默认 `"ORD"`；`orderId` 由 `"前缀 + nextId"` 组成。

### 2.6 教学反思提示
- \"字段静态绑定\"（第 1 课时）和\"字段/静态方法访问规则\"是学生最爱混的两点，可提前预告下一课时的 `Math` 就是纯静态工具类，让学生带着案例回头看规则。

---

## 第 3 课时：`Math` 工具类

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 说出 `java.lang.Math` 的定位（JDK 自带的**静态工具类**、无需 `import`）与常用方法（`abs / max / min / pow / sqrt / cbrt / ceil / floor / round / random`）。
2. 能用 `Math.random()` 生成任意区间的随机整数（含 `min ~ max` 的通用公式）。
3. 能区分 `Math.random()` 与 `java.util.Random`，并知道推荐用后者。
4. 能用 `Math.PI / Math.E` 常量完成常见数学公式（圆面积、球体积、幂运算）。

#### 3.1.2 过程与方法目标
1. 通过\"猜数字\"小游戏，把随机数、循环、`Scanner` 串联起来，做一个完整的小项目。
2. 通过\"为什么 `Math.round(3.6)` 返回 `long`\" 的追问，让学生动手查 `Math` 类源码/文档，养成\"看官方 API\"的习惯。

### 3.2 教学重难点
- **重点**：常用 `Math` 方法 / 随机整数区间公式 / `Math.PI / Math.E`
- **难点**：`Math.round` 的两种重载与返回值类型；`(int)` 强转与 `Math.floor` 的差异

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
承接上一节的\"工具类范式\"，提问：\"我们自己写的 `MathUtils` 只有一个 `max` 方法，JDK 早就给我们准备好一个功能完整的工具类叫 `Math`，且**不用 import**——为什么？\" 引出 `java.lang` 包默认导入。

#### 新知讲授（18 分钟）

**（1）常用方法一览（8 分钟）**

用一张大表快速过一遍：

| 方法 | 说明 | 示例 |
|------|------|------|
| `Math.abs(x)` | 绝对值 | `Math.abs(-3)` → 3 |
| `Math.max(a, b)` | 较大值 | `Math.max(3, 5)` → 5 |
| `Math.min(a, b)` | 较小值 | `Math.min(3, 5)` → 3 |
| `Math.pow(a, b)` | a 的 b 次方（返回 `double`） | `Math.pow(2, 10)` → 1024.0 |
| `Math.sqrt(x)` | 平方根 | `Math.sqrt(9)` → 3.0 |
| `Math.cbrt(x)` | 立方根 | `Math.cbrt(27)` → 3.0 |
| `Math.ceil(x)` | 向上取整（`double`） | `Math.ceil(3.2)` → 4.0 |
| `Math.floor(x)` | 向下取整（`double`） | `Math.floor(3.8)` → 3.0 |
| `Math.round(x)` | 四舍五入 | `Math.round(3.6)` → 4 |
| `Math.random()` | `[0.0, 1.0)` | 随机小数 |
| `Math.PI` | 圆周率 | 3.14159... |
| `Math.E` | 自然常数 | 2.71828... |

强调三个易错点：
- `Math.pow` 返回 `double`，即使参数都是 `int`。
- `Math.round(float)` 返回 `int`，`Math.round(double)` 返回 `long`。
- `Math.ceil / floor` 返回 `double`，不是 `int`——要 `int` 得强转。

**（2）随机整数公式（5 分钟）**

黑板推导：

```text
Math.random()          → [0.0, 1.0)
* 100                  → [0.0, 100.0)
(int) 强转             → 0 ~ 99  （向 0 截断）
(int)(Math.random()*100) + 1  → 1 ~ 100
(int)(Math.random()*(max-min+1)) + min  → min ~ max
```

**（3）`java.util.Random`（5 分钟）**

```java
import java.util.Random;
Random r = new Random();
int n = r.nextInt(100);        // 0 ~ 99
int n2 = r.nextInt(100) + 1;   // 1 ~ 100
```

告诉学生：**多次生成随机数用 `Random`**（性能更好、语义更清晰）；单次简单场景用 `Math.random()` 也无妨。

#### 示例演示（15 分钟）

**示例 1：圆面积、球体积**

```java
public class MathDemo {
    public static void main(String[] args) {
        double r = 5;
        double area = Math.PI * Math.pow(r, 2);
        double volume = 4.0 / 3 * Math.PI * Math.pow(r, 3);
        System.out.printf("面积 = %.2f，体积 = %.2f%n", area, volume);
    }
}
```

**示例 2：数字猜猜看**（完整地敲一遍，让学生跟做）

```java
import java.util.Scanner;
public class GuessGame {
    public static void main(String[] args) {
        int target = (int) (Math.random() * 100) + 1;
        Scanner sc = new Scanner(System.in);
        int guess, times = 0;
        do {
            System.out.print("请输入 1—100 的数字：");
            guess = sc.nextInt();
            times++;
            if (guess > target) System.out.println("大了");
            else if (guess < target) System.out.println("小了");
        } while (guess != target);
        System.out.println("恭喜，第 " + times + " 次猜中。");
        sc.close();
    }
}
```

#### 课堂练习（6 分钟）
1. 用 `Math.random()` 生成 10 个 `[50, 100]` 的随机整数并求平均值。
2. 输入一个正整数 `n`，用 `Math.sqrt` 判断它是否是完全平方数。

#### 小结（3 分钟）
- `Math` 是纯静态工具类，无需 `import`。
- 常用方法 12 个左右背下来。
- 随机整数区间公式：`(int)(Math.random() * (max - min + 1)) + min`。
- 多次生成用 `Random` 更好。

### 3.4 板书设计

```text
┌────────────────────────────────────────────────┐
│           java.lang.Math                       │
├────────────────────────────────────────────────┤
│ 纯静态工具类，无需 import                      │
│                                                │
│ 常用：abs / max / min / pow / sqrt / cbrt      │
│       ceil / floor / round / random            │
│ 常量：Math.PI  Math.E                          │
│                                                │
│ 随机整数：                                     │
│   (int)(Math.random()*(max-min+1)) + min       │
│                                                │
│ 大量随机：new Random().nextInt(n)              │
│                                                │
│ 陷阱：                                         │
│   pow 返回 double                              │
│   round(double) 返回 long                      │
│   ceil/floor 返回 double                       │
└────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. 完成\"猜数字\"游戏并加**最多猜 10 次**限制，超过则输出正确答案。
2. 写一个 `LotteryUtils` 静态工具类，方法 `int[] generateRedBalls()` 返回 6 个 1—33 的不重复红球号（提示：用 `Set` 或 `while` 判重）。
3. **挑战**：让通义灵码写一个\"双色球号码生成器\"（6 红 + 1 蓝），并解释\"不重复\"是怎么做到的。

### 3.6 教学反思提示
- 学生常犯的错误：`(int) Math.random() * 100`——少了括号，结果永远是 `0`，因为强转优先级高于乘。
- 演示时可以故意漏括号一次，让学生找 bug，加深印象。

---

## 第 4 课时：抽象类与抽象方法

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 说清抽象类的动机：父类只描述\"共同规范\"，不给具体实现。
2. 掌握 `abstract` 关键字修饰**类**和**方法**的语法。
3. 说出抽象类的四条关键规则：不能实例化、子类必须重写抽象方法（或本身也是抽象）、可有构造方法（只能被 `super` 调用）、可有成员变量和普通方法。
4. 能识别\"含抽象方法的类必须是抽象类\"（反之不必）。
5. 能用**模板方法模式**：父类定义骨架 + 子类填充细节。

#### 4.1.2 过程与方法目标
1. 从第 1 课时的 `Animal.makeSound()` 打印\"动物在叫\"这一\"没意义\"的默认实现切入，自然引出抽象方法。
2. 通过\"泡饮料\"的模板方法示例，让学生动手写 `Tea` 子类，体会\"骨架 - 细节\"分离。

### 4.2 教学重难点
- **重点**：`abstract class` / `abstract` 方法 / 子类必须重写规则 / 模板方法模式
- **难点**：\"抽象类可以没有抽象方法，但有抽象方法一定是抽象类\"；抽象类的构造方法能否被调用

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
回顾第 1 课时的 `Animal.makeSound()` 里那一句 `System.out.println("动物在叫");`——\"世界上根本不存在\"动物\"这种具体生物，只存在猫、狗、鸟。这个方法体是多余的。有没有办法**只声明方法名，不给方法体**？\" 引出 `abstract`。

#### 新知讲授（18 分钟）

**（1）语法（6 分钟）**

```java
public abstract class Animal {
    protected String name;
    public Animal(String name) { this.name = name; }
    public abstract void makeSound();   // 没有方法体
    public void eat() { System.out.println(name + " 在吃饭"); }
}
```

三条要点：
- 类前 `abstract`：抽象类。
- 方法前 `abstract` + 无方法体 + 分号：抽象方法。
- 有抽象方法 → 类必须 `abstract`（反过来不成立）。

**（2）关键规则（6 分钟）**

| 规则 | 说明 |
|------|------|
| 不能实例化 | `new Animal("x")` 编译报错 |
| 子类必须重写全部抽象方法 | 否则子类也得声明为 `abstract` |
| 可以有构造方法 | 只能被子类 `super(...)` 调用 |
| 可以有成员变量、普通方法、静态方法 | 与普通类一样 |

演示子类 `Dog extends Animal` 必须 `@Override makeSound()` 才能编译通过。

**（3）模板方法模式（6 分钟）**

抽象类的经典用途：**父类定义骨架，子类填细节**。

```java
public abstract class Beverage {
    public final void prepare() {   // final：不许子类改流程
        boilWater();
        brew();               // 抽象：交给子类
        pourInCup();
        addCondiments();      // 抽象：交给子类
    }
    void boilWater() { System.out.println("烧水"); }
    void pourInCup() { System.out.println("倒进杯子"); }
    protected abstract void brew();
    protected abstract void addCondiments();
}
```

`Coffee` 子类：

```java
public class Coffee extends Beverage {
    protected void brew() { System.out.println("冲咖啡"); }
    protected void addCondiments() { System.out.println("加糖和奶"); }
}
```

#### 示例演示（12 分钟）

现场敲 `Beverage / Coffee` 并跑通，然后**让学生动手写 `Tea` 子类**（`brew` → 泡茶叶；`addCondiments` → 加柠檬），运行看到统一流程。

再演示三种**不能编译**的错法（一定要让学生看到红色报错）：
1. `new Animal("x")` → \"Animal is abstract; cannot be instantiated\"
2. 子类漏了 `makeSound()` → \"class must be declared abstract or implement makeSound()\"
3. 抽象方法带方法体 → \"abstract methods cannot have a body\"

#### 课堂练习（8 分钟）
1. 把第 1 课时的 `Shape` 改成 `abstract class`，`area()` 改成抽象方法；`Circle / Rectangle` 各自实现。
2. 定义抽象类 `Employee`，含 `name`、`baseSalary` 字段和抽象方法 `calcSalary()`；子类 `Manager`（底薪 + 20% 提成）、`Engineer`（底薪 + 项目奖金）。

#### 小结（3 分钟）
- 抽象类：`abstract class`，不能 `new`。
- 抽象方法：无方法体 + 分号；含抽象方法 → 类必须 abstract。
- 子类必须重写全部抽象方法。
- 抽象类可以有构造方法、字段、普通方法。
- 典型用途：模板方法模式。

### 4.4 板书设计

```text
┌────────────────────────────────────────────────┐
│         抽象类  abstract                       │
├────────────────────────────────────────────────┤
│ abstract class Animal {                        │
│    abstract void makeSound();  // 无方法体     │
│    void eat() { ... }         // 普通方法      │
│ }                                              │
│                                                │
│ 规则：                                         │
│   1. 不能 new                                  │
│   2. 子类必须重写抽象方法                      │
│   3. 可以有构造（super 调用）                  │
│   4. 可以有字段和普通方法                      │
│                                                │
│ 模板方法：                                     │
│   final prepare() {                            │
│     boilWater();                               │
│     brew();          ← 抽象                    │
│     addCondiments(); ← 抽象                    │
│   }                                            │
└────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. 定义抽象类 `Shape`，含抽象方法 `area()` 和 `perimeter()`，普通方法 `describe()` 打印两者结果；子类 `Circle`、`Square`、`Rectangle` 各自实现。
2. 用模板方法模式模拟\"银行业务办理\"：抽象类 `BankBusiness` 骨架为 `queue → verify → doWork → feedback`，`doWork` 抽象；子类 `Deposit`、`Withdraw`、`Transfer` 各自实现。
3. **挑战**：为什么模板方法里 `prepare()` 要加 `final`？把它去掉，让子类重写 `prepare()` 并跳过 `brew()`，说明这为什么破坏了模板方法的意图。

### 4.6 教学反思提示
- 模板方法模式对初学者略抽象，重点让学生记住\"骨架 - 细节\"这四个字。
- 强调抽象类构造方法的存在感——很多学生以为不能 `new` 就没构造方法，这是错的。

---

## 第 5 课时：接口

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 说清接口的定位：只描述\"**能做什么**\"，不管\"**怎么做**\"，是一份协议 / 契约。
2. 掌握 `interface` 的定义、`implements` 的实现、`extends` 多接口继承的语法。
3. 会写\"一个类实现多个接口\"以突破 Java 单继承的限制。
4. 说出接口五种成员：抽象方法、常量、`default` 方法（JDK 8+）、`static` 方法（JDK 8+）、`private` 方法（JDK 9+），并知道各自默认修饰符。
5. 能用\"经验法则\"判断场景该用抽象类还是接口。

#### 5.1.2 过程与方法目标
1. 用 USB 接口的物理类比引入\"协议\"这一概念。
2. 通过 `Duck extends Animal implements Flyable, Swimmable` 演示\"单继承 + 多实现\"。

### 5.2 教学重难点
- **重点**：`interface / implements` 语法 / 多接口实现 / 抽象类 vs 接口对比
- **难点**：`default` 方法解决的痛点；\"is-a\"（用抽象类）与\"can-do\"（用接口）的语义区分

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
类比：USB 接口只规定针脚含义（\"能连什么设备\"），键盘、鼠标、U 盘只要符合规范都能插。**接口不关心你是什么，只关心你能做什么**。

再对比：抽象类是\"父亲\"（继承关系，`is-a`）；接口是\"技能证书\"（能干这件事，`can-do`）。一个人只有一个父亲，但可以有多本证书。

#### 新知讲授（20 分钟）

**（1）语法（6 分钟）**

```java
public interface Runnable {
    void run();   // 默认 public abstract
}

public class MyTask implements Runnable {
    @Override public void run() { System.out.println("任务在跑"); }
}
```

- 关键字 `interface`（不是 `class`）。
- 抽象方法默认 `public abstract`，写不写都一样。
- 实现类用 `implements`。

**（2）多实现（4 分钟）**

Java **单继承** + **多实现**：

```java
public interface Flyable { void fly(); }
public interface Swimmable { void swim(); }

public class Duck extends Animal implements Flyable, Swimmable {
    public Duck(String name) { super(name); }
    @Override public void makeSound() { System.out.println("嘎嘎"); }
    @Override public void fly() { System.out.println(name + " 飞起来了"); }
    @Override public void swim() { System.out.println(name + " 游起来了"); }
}
```

**（3）接口的成员（6 分钟）**

| 成员类型 | 修饰符（默认） | 说明 |
|----------|----------------|------|
| 抽象方法 | `public abstract` | 实现类必须重写 |
| 常量 | `public static final` | 必须赋初值 |
| `default` 方法（JDK 8+） | `default` | 有方法体，实现类可选择性重写 |
| `static` 方法（JDK 8+） | `static` | 只能通过接口名调用 |
| `private` 方法（JDK 9+） | `private` | 供接口内部复用 |

`default` 的意义：**给已有接口加新方法而不破坏所有实现类**。`List / Map` 在 JDK 8 靠此加了 `forEach / stream`。

**（4）抽象类 vs 接口对比（4 分钟）**

| 维度 | 抽象类 | 接口 |
|------|--------|------|
| 关键字 | `abstract class` | `interface` |
| 继承 | `extends`，单继承 | `implements`，可多实现 |
| 字段 | 任意 | 只能 `public static final` |
| 构造方法 | 有 | 无 |
| 方法默认修饰符 | 任意 | `public abstract` |
| 场景 | 有共同**状态**的 is-a | 有共同**行为规范**的 can-do |

#### 示例演示（12 分钟）

现场敲 `Duck` 完整示例，然后**扩展**：

```java
public interface Comparable<T> {
    int compareTo(T other);
}

public class Student implements Comparable<Student> {
    String name; int score;
    public Student(String name, int score) { this.name = name; this.score = score; }
    @Override public int compareTo(Student other) {
        return Integer.compare(this.score, other.score);
    }
}
```

再演示 `default` 方法：

```java
public interface Greetable {
    default void greet() { System.out.println("Hello from interface"); }
}
public class Foo implements Greetable {}
public class Demo {
    public static void main(String[] args) { new Foo().greet(); }
}
```

`Foo` 不用重写就能用 `greet()`——这就是 `default` 的价值。

#### 课堂练习（6 分钟）
1. 定义接口 `Runnable`（跑）、`Swimmable`（游）、`Flyable`（飞）。`Duck` 三者都实现；`Fish` 只实现 `Swimmable`；`Cat` 只实现 `Runnable`。写 `main` 演示。
2. 抽象类还是接口？说理由：\"车辆\"这一大类 / \"可比较\"的行为 / \"支付方式\"（微信、支付宝、银行卡）。

#### 小结（3 分钟）
- 接口 = 协议 = 能做什么。
- 单继承 + 多实现。
- 成员：抽象方法 / 常量 / `default` / `static` / `private`。
- 抽象类 vs 接口：`is-a` 用抽象类，`can-do` 用接口。

### 5.4 板书设计

```text
┌────────────────────────────────────────────────┐
│              接口  interface                   │
├────────────────────────────────────────────────┤
│ interface Flyable { void fly(); }              │
│ class Duck extends Animal                      │
│       implements Flyable, Swimmable { ... }    │
│                                                │
│ 成员：                                         │
│   抽象方法  public abstract  （默认）          │
│   常量      public static final （默认）       │
│   default   有方法体，可选重写                 │
│   static    接口名调用                         │
│   private   接口内部复用                       │
│                                                │
│ 抽象类 vs 接口：                               │
│   is-a  → 抽象类   can-do → 接口               │
│   单继承           多实现                      │
└────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. 定义 `USBDevice` 接口（`connect / disconnect / transfer`），三个实现 `Mouse / Keyboard / UDisk`；在 `main` 中用 `USBDevice[]` 遍历调用。
2. 定义 `Payable` 接口，含抽象方法 `pay(double amount)`；实现类 `WechatPay / Alipay / BankCard` 各自打印不同支付方式。
3. **挑战**：给 `Payable` 加一个 `default boolean supports(double amount)`，实现类 `BankCard` 单笔最多 5 万——重写这个 default 方法体现\"选择性重写\"。

### 5.6 教学反思提示
- 学生最爱纠结\"到底该用抽象类还是接口\"，用\"是什么 / 能做什么\"这句话反复强调。
- `default` 方法讲的时候一定要说\"为什么 JDK 8 才加\"，让学生理解\"兼容性\"这一软件工程原则。

---

## 第 6 课时：枚举与 Record

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 说出枚举的动机：取值\"有限且固定\"的场景（性别、季节、订单状态）。
2. 掌握 `enum` 的定义、`values() / valueOf() / name() / ordinal()` 常用方法。
3. 能给枚举加**字段、构造方法、实例方法**，实现\"带业务信息的枚举\"（如 `OrderStatus(code, label)`）。
4. 说出 `record` 的动机：消除 DTO 的样板代码。
5. 掌握 `record` 的语法，说出它自动生成的**成员**：`private final` 字段、全参构造、访问器（`x()` 而非 `getX()`）、`equals / hashCode / toString`。
6. 能写紧凑构造器（Compact Constructor）做参数校验，能给 `record` 加自定义方法。

#### 6.1.2 过程与方法目标
1. 从\"月份传 13 不报错\"这一 bug 引入枚举。
2. 从\"一个 60 行的 `PointDTO`\"引入 `record`——一行等价。
3. 全天收官：把多态 / 抽象类 / 接口 / 枚举 / Record 串成一张思维导图。

### 6.2 教学重难点
- **重点**：`enum` 语法与带字段的枚举 / `record` 语法与自动生成的成员
- **难点**：枚举的\"本质是特殊类，每个枚举值是实例\"；`record` 的紧凑构造器语法（无形参列表）

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
展示两段有\"坏味道\"的代码：
- `public static final int SPRING = 1;` 一堆常量——传 `13` 编译不报错。
- 60 行的 `PointDTO`：字段 + 构造 + 4 个 getter + `equals / hashCode / toString`。

问：\"能不能让编译器帮我防住？能不能一行搞定 DTO？\" → 引出 `enum` 和 `record`。

#### 新知讲授（20 分钟）

**（1）`enum`（10 分钟）**

基础语法：

```java
public enum Season { SPRING, SUMMER, AUTUMN, WINTER }

Season s = Season.SPRING;
System.out.println(s);           // SPRING
System.out.println(s.name());    // SPRING
System.out.println(s.ordinal()); // 0

switch (s) {
    case SPRING -> System.out.println("春天");
    case SUMMER -> System.out.println("夏天");
    default -> System.out.println("其他");
}
```

带字段的枚举（订单状态）：

```java
public enum OrderStatus {
    CREATED(1, "已创建"),
    PAID(2, "已支付"),
    SHIPPED(3, "已发货"),
    COMPLETED(4, "已完成"),
    CANCELLED(-1, "已取消");
    private final int code;
    private final String label;
    OrderStatus(int code, String label) {
        this.code = code;
        this.label = label;
    }
    public int getCode() { return code; }
    public String getLabel() { return label; }
}
```

强调：**每个枚举值都是这个类的一个实例**——`CREATED` 就是 `new OrderStatus(1, "已创建")`（编译器自动生成）。

常见方法：`values()`（返回数组）、`valueOf(String)`（按名字取）。

**（2）`record`（10 分钟）**

一行等价 60 行：

```java
public record Point(int x, int y) {}
```

自动生成：
- `private final int x, y;`
- `public Point(int x, int y)` 全参构造
- `public int x()`、`public int y()` **访问器（注意不是 `getX`）**
- `equals / hashCode / toString`（基于所有字段）

用法：

```java
Point p1 = new Point(3, 4);
System.out.println(p1);          // Point[x=3, y=4]
System.out.println(p1.x());      // 3
Point p2 = new Point(3, 4);
System.out.println(p1.equals(p2));   // true
```

紧凑构造器 + 自定义方法：

```java
public record Range(int start, int end) {
    public Range {                      // 注意没有形参列表
        if (start > end) throw new IllegalArgumentException("start > end");
    }
}
public record Point(int x, int y) {
    public double distanceTo(Point o) {
        int dx = x - o.x, dy = y - o.y;
        return Math.sqrt(dx*dx + dy*dy);
    }
}
```

规则：不可变、可实现接口但不能继承类、字段自动 `final`。适合 DTO / VO / Map key。

#### 示例演示（10 分钟）

组合示例：**用 `record` + `enum` 建模一个订单**：

```java
public record Order(String orderId, long userId, long amount, OrderStatus status) {
    public Order {
        if (amount <= 0) throw new IllegalArgumentException("amount 必须 > 0");
    }
    public boolean isFinalized() {
        return status == OrderStatus.COMPLETED || status == OrderStatus.CANCELLED;
    }
}

public class OrderDemo {
    public static void main(String[] args) {
        Order o = new Order("ORD001", 1001L, 5000L, OrderStatus.PAID);
        System.out.println(o);
        System.out.println("已终结？" + o.isFinalized());
    }
}
```

一段代码把 `record`、`enum`、构造校验、自定义方法全串起来。

#### 课堂练习（6 分钟）
1. 定义 `WeekDay` 枚举（周一—周日），加 `isWeekend()` 方法。
2. 定义 `record Money(long cents, String currency)`，加 `add(Money other)` 方法（同币种才允许相加，否则抛异常）。

#### 小结（3 分钟）

**本讲要点：**

- 枚举 `enum` 本质是**继承 `Enum` 的特殊类**，构造器私有、实例在类装载时创建，天然单例。
- 常用 API：`values()` 返回全部实例、`valueOf(String)` 按名字取、`name()` / `ordinal()` 分别拿到名字和序号。
- `record` 一行等价 60 行——自动生成 `final` 字段、全参构造、访问器 `x()`（不是 `getX()`）、`equals` / `hashCode` / `toString`。
- 紧凑构造器 `public Point { ... }` **没有形参列表**，用于校验参数。
- 场景：DTO / VO / Map key / 值对象——凡是"一堆字段捆一起、不可变"的地方都可以用。

**下一讲预告：** 第 7 课时 **异常处理入门**——教材第 10.5 节。今天讲的 `record` 紧凑构造器里我们已经写过 `throw new IllegalArgumentException(...)`，下一讲就系统讲**异常是什么、`try-catch-finally` 怎么用、常见坑在哪**。

### 6.4 板书设计

```text
┌────────────────────────────────────────────────┐
│            enum  +  record                     │
├────────────────────────────────────────────────┤
│ enum Season { SPRING, SUMMER, ... }            │
│   本质：继承 Enum 的特殊类                     │
│   values() / valueOf() / name() / ordinal()    │
│                                                │
│ 带字段：                                       │
│   OrderStatus(1, "已创建")                     │
│                                                │
│ record Point(int x, int y) {}                  │
│   自动：final 字段 + 全参构造 + x()/y()        │
│         + equals/hashCode/toString             │
│                                                │
│ 紧凑构造：                                     │
│   public Point { 校验; }   // 无形参列表       │
│                                                │
│ 场景：DTO / VO / Map key / 值对象              │
└────────────────────────────────────────────────┘
```

### 6.5 课后作业（枚举 + Record 专项）

1. **多态 + 抽象类**：把 `Shape` 改成抽象类，`Circle / Square / Rectangle` 三子类，用 `Shape[]` 一次算总面积并打印最大形状。
2. **接口 + 多实现**：写 `Duck / Fish / Cat` 分别实现 `Runnable / Swimmable / Flyable` 中的合适子集。
3. **枚举实战**：把作业 1 的形状类型定义为枚举 `ShapeType { CIRCLE, SQUARE, RECTANGLE }`，给 `Shape` 加 `getType()` 抽象方法。
4. **Record 实战**：定义 `record Money(long cents, String currency)` + `add / subtract` 方法。
5. **综合**：定义 `record Order(String id, long userId, long amount, OrderStatus status)`，紧凑构造器校验 `amount > 0`，方法 `isFinalized()`。
6. **AI 实战**：向通义灵码提问「JDK 8 的 `default` 方法解决了什么问题？举一个 `List` 接口在 JDK 8 前后的对比」，把答案抄录并加自己一段点评。

### 6.6 教学反思提示
- 本讲信息密度较大，务必留 3 分钟做"枚举 + Record 一张图"回顾。
- `record` 的"访问器叫 `x()` 不叫 `getX()`"是学生最容易踩的坑，一定强调。
- 紧凑构造器无形参列表这一细节是常见语法错误来源，务必让学生亲手写一遍。
- 提醒学生：紧凑构造器里我们写了 `throw new IllegalArgumentException(...)`，下一讲会把\"异常到底是什么\"讲清楚。

---

## 第 7 课时：异常处理入门（Day05 收官）

### 7.1 教学目标

**知识目标：**
1. 说清楚**异常是什么**——`Throwable` 层级、`Error` 与 `Exception` 的区别、`RuntimeException` 与受检异常的区别。
2. 能写规范的 `try-catch-finally` 结构，读懂"出错跳到 catch、finally 一定执行"的执行流。
3. 会用**多 catch**和**多重 catch（`|`）** 处理多种异常，理解"从上到下匹配、父类写在子类之后"的规则。
4. 分得清 `throws`（方法签名声明）与 `throw`（语句手动抛），能给方法加合理的 `throws` 或 `throw`。

**能力目标：**
1. 能给一段"字符串转数字 + 除法"的代码补上完整的 `try-catch-finally`。
2. 看到红色报错时能自主分析：异常类型是什么？出在哪一行？属于代码 Bug 还是外部因素？
3. 能识别并改掉 4 个常见反模式：吞异常、`catch Exception` 一把梭、`finally` 里 `return`、把 `NullPointerException` 也 catch 掉。

**素养目标：**
1. 树立"崩溃优于静默错误"的意识，理解"看到红色报错是好事，比默默算错强 100 倍"。
2. 用 AI（通义灵码）辅助排查异常：把堆栈粘给 AI 让它讲清楚"哪一行、什么类型、常见原因"。

### 7.2 教学重难点

**重点：** `try-catch-finally` 三段的执行顺序；`RuntimeException` 与受检异常的判别；多 catch 的匹配规则。
**难点：** "什么时候用异常、什么时候用普通判断"的分寸感；`finally` 覆盖 `return` 的隐蔽坑；`NullPointerException` 应"回去修 Bug"而不是 catch。

### 7.3 教学过程设计（45 分钟）

#### 导入（3 分钟）

**回顾式提问：** 上一讲我们在 `record Range` 的紧凑构造器里写了什么？

```java
public record Range(int start, int end) {
    public Range {
        if (start > end) throw new IllegalArgumentException("start > end");
    }
}
```

**追问：** 这个 `throw new IllegalArgumentException(...)` 到底做了什么？程序会崩吗？调用方能拦住吗？——今天就把这些问题讲清楚。

**引入教材：** 打开教材第 10.5 节"异常处理入门"，本节我们只做入门级介绍，够你在第 11、12 章"不再看到红色报错就懵"。

#### 讲解（22 分钟）

**（1）异常是什么（5 分钟）**

**板书 `Throwable` 层级图：**

```text
Throwable
├── Error         // JVM 层面严重错误，OutOfMemoryError（不用管）
└── Exception
    ├── RuntimeException          // 运行时异常，编译器不强制
    │   ├── NullPointerException
    │   ├── ArrayIndexOutOfBoundsException
    │   ├── ArithmeticException
    │   └── NumberFormatException
    └── IOException 等             // 受检异常，编译器强制处理
```

**核心口诀（写在板书上）：**

- **`RuntimeException`** = 编译器不强制处理 = 多为**代码 Bug**（空指针、越界、除 0）——修 Bug 比 catch 更重要。
- **受检异常** = 编译器强制"要么 catch 要么 throws" = 多为**外部不可控**（文件、网络、数据库）。

**（2）`try-catch-finally` 语法（8 分钟）**

现场敲教材第 388—403 行的 `DivDemo`：

```java
public class DivDemo {
    public static void main(String[] args) {
        int[] arr = {10, 0, 5};
        for (int i = 0; i < arr.length; i++) {
            try {
                int result = 100 / arr[i];
                System.out.println("100 / " + arr[i] + " = " + result);
            } catch (ArithmeticException e) {
                System.out.println("出错了：" + e.getMessage());
            } finally {
                System.out.println("--- 第 " + i + " 次循环结束 ---");
            }
        }
        System.out.println("程序正常结束");
    }
}
```

运行给学生看，重点关注**第 1 次循环**（`i=1`，除数为 0）的输出：

```text
出错了：/ by zero
--- 第 1 次循环结束 ---
```

**四条关键结论（板书）：**
1. `try` 放"可能出错的代码"。
2. `catch` **只捕获匹配类型**的异常并处理，程序不崩。
3. `finally` **无论是否异常都会执行**，常用于关闭资源。
4. 出异常后 `try` 剩余代码**不再执行**，直接跳 catch。

**（3）多 catch 与异常匹配（4 分钟）**

现场敲第 429—440 行的 args 解析示例，追问：

- 三个 catch 顺序**能不能反**？——不能，父类要写在子类之后，否则子类永远不匹配。
- 三种异常**都想一起处理**怎么办？——多重 catch：`catch (NumberFormatException | ArithmeticException e)`。

**（4）`throws` 与 `throw`（5 分钟）**

回到导入的问题："上一讲 `record Range` 里的 `throw` 是什么？"

**板书对比：**

| 关键字 | 位置 | 作用 |
|--------|------|------|
| `throws` | 方法签名 | 声明：本方法可能抛出某种受检异常，调用者你自己处理 |
| `throw`  | 方法体内 | 手动**抛出**一个异常对象 |

现场敲第 461—467 行的 `parsePositive`：

```java
public static int parsePositive(String s) throws NumberFormatException {
    int n = Integer.parseInt(s);           // 底层可能抛
    if (n <= 0) {
        throw new IllegalArgumentException("必须为正数：" + n);  // 手动抛
    }
    return n;
}
```

**追问：** 调用方 `main` 有几种选择？——三选一：`try-catch` 处理、继续 `throws` 上抛、一路冒泡到 JVM（打印堆栈后退出）。

#### 示例演示（8 分钟）

**综合示例：安全的字符串转整数除法**——把导入的疑问彻底闭环。

```java
import java.util.Scanner;

public class SafeDivDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("请输入被除数：");
            int a = Integer.parseInt(sc.nextLine());
            System.out.print("请输入除数：");
            int b = Integer.parseInt(sc.nextLine());
            System.out.println(a + " / " + b + " = " + (a / b));
        } catch (NumberFormatException e) {
            System.out.println("输入格式错误：不是合法整数");
        } catch (ArithmeticException e) {
            System.out.println("除数不能为 0");
        } finally {
            sc.close();
            System.out.println("Scanner 已关闭");
        }
    }
}
```

**三种输入现场演示：**
1. `10` / `2` → 正常，打印 `10 / 2 = 5`，然后关闭 Scanner。
2. `10` / `0` → catch `ArithmeticException`，然后 finally 关闭。
3. `abc` / `2` → catch `NumberFormatException`，然后 finally 关闭。

**关键强调：** 无论走哪条路径，`finally` 都会关闭 Scanner——这就是"清理资源"的经典写法。

#### 课堂练习（6 分钟）
1. 把 `SafeDivDemo` 改成用**多重 catch（`|`）** 合并两种异常。
2. **常见坑辨析题**：下列代码哪里错了？为什么？

```java
try {
    return doSomething();
} catch (Exception e) {
    // 什么都不做
} finally {
    return -1;
}
```

（答案要点：吞异常 + `finally` 里 `return` 覆盖 `try` 的返回值——双重反模式。）

#### 小结（3 分钟）— Day05 全天总结

**本讲要点：**

- 异常 = 运行时意外，Java 把它建模为 `Throwable` 的子类对象。
- 两类：`RuntimeException`（Bug，改代码）、受检异常（外部因素，编译器强制处理）。
- `try-catch-finally`：try 放风险代码、catch 按类型匹配、finally 一定执行（关资源）。
- `throws` 声明、`throw` 抛出；多 catch 从上到下匹配、父类写后面。
- **四个坑**：吞异常、`catch Exception` 一把梭、`finally` 里 return、把 NPE 也 catch 掉。

**本日 7 讲串一张图：**

```text
第 1 讲 多态 ─────┐
第 2 讲 final/static ─┤─── 面向对象三大特性最后一块拼图
第 3 讲 Math ─────┘

第 4 讲 抽象类  ─── is-a、共同状态
第 5 讲 接口    ─── can-do、多实现
第 6 讲 enum/record ─── 特殊类家族的两个成员
第 7 讲 异常处理  ─── 让程序"不再一崩了之"
```

**核心口诀：**
- 多态 = 父引 + 重写 + 动态绑定。
- `final` 三用：变量 / 方法 / 类。
- `static` = 属于类、共享一份。
- 抽象类 vs 接口：`is-a` / `can-do`。
- 枚举：有限固定值；Record：不可变数据载体。
- 异常：`try` 放险、`catch` 分型、`finally` 兜底。

**Day06 预告：** 明天讲**第 11 章 String 与包装类**——包括不可变字符串、`StringBuilder`、`Integer.parseInt` 等。今天讲的 `final`、`record` 都会再出现（`String` 本身就是 `final class`），而 `Integer.parseInt` 抛的 `NumberFormatException` 我们今天已经"预习"过了。

### 7.4 板书设计

```text
┌──────────────────────────────────────────────────┐
│         Java 异常处理入门（第 10.5 节）          │
├──────────────────────────────────────────────────┤
│ Throwable                                        │
│   ├─ Error（不用管）                             │
│   └─ Exception                                   │
│        ├─ RuntimeException  → Bug，改代码        │
│        │    NPE / 越界 / 除 0 / NumberFormat     │
│        └─ 受检异常          → 外部因素，必须处理 │
│             IOException 等                       │
│                                                  │
│ try {  可能出错的代码  }                         │
│ catch (具体异常 e) { 处理 }                      │
│ catch (A | B e)          // 多重 catch           │
│ finally { 一定执行，关资源 }                     │
│                                                  │
│ throws  ── 方法签名，声明"我会抛"                │
│ throw   ── 语句，手动抛出对象                    │
│                                                  │
│ 四个坑：                                         │
│  ✗ catch 里啥都不做（吞异常）                    │
│  ✗ catch (Exception) 一把梭                      │
│  ✗ finally 里 return（覆盖 try 的 return）       │
│  ✗ NPE 也 catch（应回去修 Bug）                  │
└──────────────────────────────────────────────────┘
```

### 7.5 课后作业（Day05 综合作业）

1. **多态 + 抽象类**：把 `Shape` 改成抽象类，`Circle / Square / Rectangle` 三子类，用 `Shape[]` 一次算总面积并打印最大形状。
2. **接口 + 多实现**：写 `Duck / Fish / Cat` 分别实现 `Runnable / Swimmable / Flyable` 中的合适子集。
3. **枚举实战**：把作业 1 的形状类型定义为枚举 `ShapeType { CIRCLE, SQUARE, RECTANGLE }`，给 `Shape` 加 `getType()` 抽象方法。
4. **Record 实战**：定义 `record Money(long cents, String currency)` + `add / subtract` 方法（同币种校验用 `throw new IllegalArgumentException`）。
5. **异常处理**：把 `SafeDivDemo` 扩展成一个循环——反复读用户输入直到成功计算一次为止，用 `finally` 保证 Scanner 只在退出循环后关闭。
6. **异常辨析**：给出 6 段小代码，判断每段抛出的**异常类型**，并说明属于 `RuntimeException` 还是受检异常。
7. **AI 实战**：向通义灵码提问「JDK 8 的 `default` 方法解决了什么问题？举一个 `List` 接口在 JDK 8 前后的对比」，把答案抄录并加自己一段点评。
8. **AI 实战（异常）**：把下面这段代码粘给通义灵码，让它指出 3 个反模式并给出改写版本：

```java
try {
    Integer.parseInt(input);
} catch (Exception e) {
}
```

### 7.6 教学反思提示

- 学生最容易混淆的是 `throw` 与 `throws`——务必在板书上并列写、拼写差异用红笔圈出来。
- "`finally` 里 `return` 覆盖 `try` 的 `return`" 这一坑，光讲不够，一定让学生**跑一遍**看到实际输出才能记住。
- 强调"崩溃优于静默错误"这一意识——很多同学第一反应是 `catch (Exception e) {}` 把红字消掉，要在这里把这种思路彻底纠正。
- 如时间紧张，可以把课堂练习 2 放到课后完成，但**综合示例 `SafeDivDemo` 必须现场敲**，因为它是本讲和 Day06 `Integer.parseInt` 之间的桥梁。

---

**Day05 全天课时时间分配（每课时 45 分钟 × 7 = 315 分钟）：**

| 课时 | 主题 | 章节 |
|------|------|------|
| 1 | 多态 | 9.1 |
| 2 | `final` + `static` | 9.2 / 9.3 |
| 3 | `Math` 工具类 | 9.4 |
| 4 | 抽象类 | 10.1 |
| 5 | 接口 | 10.2 |
| 6 | 枚举 + Record | 10.3 / 10.4 |
| 7 | 异常处理入门（收官） | 10.5 |
