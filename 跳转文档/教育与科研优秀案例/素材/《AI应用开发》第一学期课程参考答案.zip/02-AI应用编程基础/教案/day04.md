# AI 应用编程基础——Java 基础 - 教师教案（Day04：第 1—6 课时）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01—Day03 面向过程语法学习的 Java 初学者（大一/大二本科生、非计算机专业亦可）**
**知识点覆盖：** 第 7 章 类与对象、封装、构造方法 + 第 8 章 继承、this / super、Object 类
**基线版本：** JDK 25 LTS · IntelliJ IDEA 2026.1

---

## 第 1 课时：面向对象的思想 + 类的定义与对象的创建

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能用自己的话说清 **面向过程** 与 **面向对象** 的根本差异，并各举 1 个日常例子；
2. 能准确背出面向对象的 **三大特性**（封装、继承、多态）及各自的一句话定义；
3. 能仿写一个 `Student` 类，包含 4 个成员变量和 2 个成员方法，并在 `main` 中用 `new` 创建 2 个对象；
4. 能画出对象创建后 **栈—堆** 的引用示意图，并说清 `s1`、`s2` 指向的是哪块内存；
5. 能列出 **成员变量 vs 局部变量** 至少 3 项差异（位置、默认值、生命周期）。

#### 1.1.2 过程与方法目标
1. 通过 "图纸 vs 房子" 的类比，从直觉上建立 **类 = 模板 / 对象 = 实例** 的心智模型；
2. 通过 Mermaid 内存图，把抽象的 "引用" 概念可视化为箭头；
3. 通过与 Day03 数组管理学生的对比，让学生自然感受 "把数据和行为绑在一起" 的好处。

### 1.2 教学重难点
- **重点**：面向过程 vs 面向对象的思维切换 / 类的定义语法（字段 + 方法） / `new` 创建对象与访问成员 / 栈—堆内存模型
- **难点**：为什么 `s1 = new Student()` 之后 `s1` 变量本身在栈上、对象内容在堆上 / 成员变量的默认值机制 / 局部变量必须显式初始化的原因

### 1.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
先做一个投票式提问：**"用你熟悉的方式描述一下 '张三同学'，你会怎么说？"** 大概率有同学答 "身高 180、爱打篮球、大二在读、姓张" ——这就是 **属性** 和 **行为**。板书写下 "张三 = 属性 + 行为"，随后追问：**"如果我们要管理 50 个学生，Day03 用了什么办法？"** 学生会回忆起 4 个平行数组 `ids / names / ages / scores`。抛出痛点：**"如果现在要加一个 '手机号' 字段，需要改多少地方？"** ——4 个数组的每处遍历都要动。今天我们就来学面向对象，看它如何优雅地解决这个问题。

#### 新知讲授（20 分钟）
按四小节推进：

1. **面向过程 vs 面向对象**（5 分钟）
   投影下方对比表格，逐行讲解：

   | 面向过程（PO） | 面向对象（OO） |
   |----------|----------|
   | 想 "怎么做" | 想 "谁来做" |
   | 一堆函数 + 一堆数据分散在各处 | 数据和操作数据的方法 **封装** 在一起 |
   | 修改数据结构，很多函数都要改 | 修改类内部实现，外部通常不受影响 |

   反复强化 "**谁来做**"—— OO 的核心是先找 **动作的执行者**，再把动作定义为它的方法。

2. **三大特性**（3 分钟）
   板书列出：**封装 / 继承 / 多态**。用一句话点题：
   - 封装 = 数据私有、行为公开（今天下节课讲）；
   - 继承 = 子类复用父类的字段与方法（第 4 讲讲）；
   - 多态 = 同一个方法调用、不同对象表现不同（下一天讲）。

3. **类与对象**（4 分钟）
   给出黄金类比：**"类是图纸，对象是按图纸造出来的房子"**。图纸只有一份，房子可以造很多栋；改图纸不会影响已建好的房子，但下一栋会按新图纸来。板书写下：
   ```text
   类（Class）  = 模板 / 蓝图
   对象（Object）= 类的实例（存在于内存）
   ```

4. **类的定义与对象的创建**（8 分钟）
   现场敲代码，逐行讲解一个最小的 `Student` 类：
   ```java
   public class Student {
       // 成员变量（字段 / field）
       String id;
       String name;
       int age;
       double score;
   
       // 成员方法（行为）
       public void study() {
           System.out.println(name + " 正在学习 Java...");
       }
   
       public void printInfo() {
           System.out.println("学号：" + id);
           System.out.println("姓名：" + name);
           System.out.println("年龄：" + age);
           System.out.println("成绩：" + score);
       }
   }
   ```
   然后在 `StudentTest` 中演示 `new` 和 `.` 语法：
   ```java
   Student s1 = new Student();
   s1.id = "2026001";
   s1.name = "张三";
   s1.age = 20;
   s1.score = 88.5;
   s1.printInfo();
   s1.study();
   ```
   强调三个要点：（1）`new Student()` 在 **堆** 上开辟空间；（2）`s1` 变量本身在 **栈** 上，存的是堆里对象的地址；（3）通过 `.` 访问字段和方法就是 "对象点属性 / 对象点方法"。

#### 示例演示（10 分钟）
现场画 Mermaid 内存图（板书 + 投影）：

```mermaid
flowchart LR
    subgraph 栈["栈（线程私有）"]
        s1["s1<br/>0x100"]
        s2["s2<br/>0x200"]
    end
    subgraph 堆["堆（对象存放）"]
        O1["Student #1<br/>id=2026001<br/>name=张三<br/>age=20<br/>score=88.5"]
        O2["Student #2<br/>id=2026002<br/>name=李四<br/>age=21<br/>score=92"]
    end
    s1 --> O1
    s2 --> O2
```

追问学生："**如果我写 `Student s3 = s1;`，会新造一个对象吗？**" 引导学生回答：**不会**，`s3` 只是又一个栈上的引用变量，箭头也指向堆里的 `#1` 对象。

接着投影 **成员变量 vs 局部变量** 的对比表，逐行讲：

| 维度 | 成员变量 | 局部变量 |
|------|---------|---------|
| 位置 | 类里、方法外 | 方法里（含参数） |
| 内存 | 堆（跟随对象） | 栈（方法调用结束销毁） |
| 默认值 | 有（`0 / 0.0 / null / false`） | 无，必须显式初始化 |
| 生命周期 | 对象存在期间 | 方法执行期间 |

用一段小代码演示 "不初始化就用局部变量" 会 **编译报错** —— IDE 会画红波浪线并提示 `variable x might not have been initialized`。

#### 课堂练习（8 分钟）
1. 定义 `Book` 类：字段 `isbn / title / author / price`（自选类型），一个 `printInfo()` 方法；`main` 中创建 2 本书并调用 `printInfo`。
2. 判断下列代码输出：
   ```java
   Student a = new Student();
   Student b = a;
   b.name = "王五";
   System.out.println(a.name);
   ```
   —— 答案是 `王五`（`a` 和 `b` 指向同一个对象）。
3. 说出下面哪几条正确：
   - a. `new Student()` 每次都会在堆上创建新对象 ✔
   - b. 局部变量的默认值是 `null` ✘
   - c. `int age;` 写在类里，默认值是 `0` ✔

#### 小结（3 分钟）
回顾三条主线：**类 = 模板 / 对象 = 实例 / 引用变量在栈、对象在堆**。预告下一课时 **封装** —— 数据私有化后如何用 `getter / setter` 优雅地访问。

### 1.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 1 课时：面向对象 & 类与对象                   │
├───────────────────────────────────────────────────┤
│  面向过程 → "怎么做"   面向对象 → "谁来做"        │
│                                                   │
│  三大特性：封装 / 继承 / 多态                     │
│                                                   │
│  类 = 图纸   对象 = 房子                          │
│                                                   │
│  Student s1 =     new Student();                  │
│          ↑              ↑                         │
│       栈上引用       堆上对象                     │
│                                                   │
│  成员变量：有默认值       局部变量：无默认值      │
└───────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：定义 `Teacher` 类，字段 `id / name / age / subject`，一个 `teach()` 方法输出「XX 老师正在讲授 XX 课程」；`main` 中创建 3 个 `Teacher` 并调用。
2. **必做**：画出下面代码执行完后的栈—堆图：
   ```java
   Student a = new Student(); a.name = "张三";
   Student b = new Student(); b.name = "李四";
   Student c = a; c.name = "王五";
   ```
   写出 `a.name / b.name / c.name` 的值。
3. **挑战题**：思考——如果 `Student` 类里有 `String` 类型的 `name`，那 `Student` 对象的 `name` 字段本身在堆上，`String "张三"` 又在哪里？（提示：字符串常量池）

### 1.6 教学反思提示
- 学生是否真正理解 "引用" 与 "对象" 的区别？可用 "赋值一个引用不会造新对象" 的追问快速检测；
- Mermaid 内存图讲解是否流畅？若学生画不出，需回到 Day03 数组内存图做一次对比。

---

## 第 2 课时：封装

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 能说清 **封装** 的三条价值（数据合法性、隐藏实现、降低耦合）；
2. 能背下四个访问修饰符（`private / 默认 / protected / public`）的可见范围表；
3. 能把一个 "字段裸露" 版本的类改写为 "封装版" —— 字段全 `private` + 一对 `getter / setter`；
4. 能在 `setter` 里写数据校验代码（如年龄 0—150、成绩 0—100）；
5. 能解释 `this.age = age;` 中 `this` 的作用及为何写这里。

#### 2.1.2 过程与方法目标
1. 通过 "把字段裸露给外部" 的反例演示（如 `s.age = -5;`），让学生感受到 **不封装 = 数据可被任意破坏** 的痛；
2. 通过 IDEA 一键生成 `getter / setter` 的现场演示，让学生体会 "重复劳动交给工具" 的开发效率意识。

### 2.2 教学重难点
- **重点**：`private` + `getter / setter` 的黄金写法 / `setter` 中的数据校验 / `this` 关键字消歧
- **难点**：为什么 `this.age = age;` 中形参和字段可以同名 / 何时需要 `this.` 何时可以省略

### 2.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
承接第 1 课时的 `Student` 类，现场敲一行代码：
```java
Student s = new Student();
s.age = -5;
```
问学生："**这样有问题吗？编译能过吗？**" 答：能过，但业务上不合理——"人不可能有负数岁"。追问："**怎么在赋值时挡住 `-5`？**" 引出：需要 **一个能拦截的入口** —— 这就是封装要做的事。

#### 新知讲授（18 分钟）
按三小节推进：

1. **封装的思想**（4 分钟）
   板书写下三条价值：
   - 保证 **数据合法性**（不能给年龄赋 `-5`）；
   - **隐藏实现细节**，方便日后重构（内部字段名改了、类型换了，外部代码不受影响）；
   - **减少耦合**，外部代码不直接依赖内部字段。
   一句话总结："**把数据藏在类里，只暴露必要的操作接口。**"

2. **访问修饰符**（6 分钟）
   投影四修饰符对比表，逐格讲：

   | 修饰符 | 同类 | 同包 | 子类 | 其他 |
   |--------|------|------|------|------|
   | `private` | ✔ | ✘ | ✘ | ✘ |
   | 默认（无） | ✔ | ✔ | ✘ | ✘ |
   | `protected` | ✔ | ✔ | ✔ | ✘ |
   | `public` | ✔ | ✔ | ✔ | ✔ |

   强调 **封装的黄金规则**：**成员变量 `private`，通过 `public` 的 `get / set` 方法访问**。加粗板书两次。

3. **封装版 `Student`**（8 分钟）
   现场把第 1 讲的 `Student` 改造：
   ```java
   public class Student {
       private String id;
       private String name;
       private int age;
       private double score;
   
       public String getId() { return id; }
       public void setId(String id) { this.id = id; }
   
       public String getName() { return name; }
       public void setName(String name) { this.name = name; }
   
       public int getAge() { return age; }
       public void setAge(int age) {
           if (age < 0 || age > 150) {
               System.out.println("年龄非法，已忽略。");
               return;
           }
           this.age = age;
       }
   
       public double getScore() { return score; }
       public void setScore(double score) {
           if (score < 0 || score > 100) {
               System.out.println("成绩非法，已忽略。");
               return;
           }
           this.score = score;
       }
   }
   ```
   讲清 3 件事：（1）四个字段全 `private`；（2）每个字段配一对 `get/set`；（3）`setAge / setScore` 里加了校验——这正是封装带来的 **合法性保障**。

   重点讲 **`this` 关键字**：`this.age = age;` 里 `this` 代表 **当前对象**。为什么能这么写？因为形参 `age` 和字段 `age` **同名**，如果不写 `this.` 就无法区分——Java 就近原则会认为两个 `age` 都是形参，等于 "把 `age` 赋给自己"，没有意义。写 `this.` 明确告诉编译器："**左边的 `age` 是当前对象的字段，右边的 `age` 是形参**。"

#### 示例演示（10 分钟）
现场演示 **IDEA 一键生成** `getter / setter`：
1. 光标停在类内 → `Alt + Insert`（macOS 是 `Cmd + N`） → 选 `Getter and Setter` → 全选 → OK。
2. IDEA 自动补齐所有 `getX / setX`。让学生跟着敲，感受 "写 4 个字段 → 一键生成 8 个方法" 的爽感。

然后写一段调用代码，演示 **校验生效**：
```java
Student s = new Student();
s.setId("2026001");
s.setName("张三");
s.setAge(-5);         // 输出 "年龄非法，已忽略。"
s.setAge(20);
s.setScore(88.5);
System.out.println(s.getName() + " 年龄 " + s.getAge());
// 张三 年龄 20
```

顺便讲一个 **AI 提示词技巧**，把它当作学生课后可以用的模板：
```text
帮我把下面这个 Java 类改成封装版本：
1. 所有字段私有；
2. 生成 getter / setter；
3. 在 setter 中加入合理校验（年龄 0—150，成绩 0—100）；
4. 加中文注释说明校验规则。

[粘贴原始类代码]
```

#### 课堂练习（8 分钟）
1. 把第 1 课时定义的 `Book` 类改成封装版：所有字段私有，`price / stock` 的 `setter` 中校验非负。
2. 判断下列写法是否合法，为什么：
   ```java
   public void setName(String name) {
       name = name;      // ❓
   }
   ```
   —— 不合法（业务上）：这是 **把形参赋给形参**，字段 `name` 根本没被改。必须写 `this.name = name;`。
3. 说出下列访问是否成功：`private` 字段能被同类的 `main` 方法访问吗？—— **能**，同类内 `private` 可见。

#### 小结（3 分钟）
回顾三句话：**字段 private / 对外 public 的 get/set / setter 里加校验**。预告下一课时 **构造方法** —— 让 `new` 对象时就一次性完成初始化。

### 2.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 2 课时：封装（Encapsulation）                 │
├───────────────────────────────────────────────────┤
│  为什么？                                         │
│    1.数据合法性                                   │
│    2.隐藏实现                                     │
│    3.降低耦合                                     │
│                                                   │
│  黄金规则：                                       │
│    字段 private + get/set public                  │
│                                                   │
│  访问修饰符：                                     │
│    private < 默认 < protected < public            │
│                                                   │
│  this.age = age;                                  │
│    ↑ 当前对象的字段                               │
│                                                   │
│  setter 里可加校验（age < 0 拒绝）                │
│                                                   │
│  IDEA：Alt + Insert → Getter and Setter           │
└───────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：把课堂上写的 `Teacher` 类改成封装版：`age` 校验 20—80，`subject` 校验非空字符串。
2. **必做**：写一个 `Account`（账户）类：字段 `id / balance`，`setBalance` 中校验非负；写一个 `deposit(double money)` 方法把钱存进去，也校验非负。
3. **挑战题**：思考——为什么 Java 惯例里 `getter` 叫 `getXxx`、`setter` 叫 `setXxx`？（提示：JavaBean 规范、Spring / Jackson 反射依赖此命名）

### 2.6 教学反思提示
- 学生是否理解 `this` 的必要性？可让学生把 `this.` 去掉后重新运行，观察字段没有被赋值的现象；
- IDEA 一键生成后，学生是否知道 `getter / setter` 的规范命名（首字母大写 + 驼峰）？

---

## 第 3 课时：构造方法

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 能说清 **构造方法** 的三大特点（方法名与类名相同、无返回值类型、可重载）；
2. 能编写无参构造和全参构造，并解释 `new Xxx(...)` 时括号里的参数如何传给构造方法；
3. 能用 **构造方法重载** 提供多种创建方式，并用 `this(...)` 复用同类另一个构造；
4. 能解释 "为什么写了带参构造后 `new Xxx()` 会编译报错"，并给出补救方案；
5. 能画出 `new Student("2026001", "张三", 20, 88.5)` 的调用流程（谁被调用、什么时候被调用）。

#### 3.1.2 过程与方法目标
1. 通过 "创建对象后需要一堆 `s.setXxx(...)`" 的痛点，自然引出构造方法的价值；
2. 通过 `this(...)` 复用调用，让学生体会 "构造方法之间也可以互相调用" 的技巧。

### 3.2 教学重难点
- **重点**：构造方法的语法特点 / 无参 vs 全参 / 构造方法的重载 / `this(...)` 的使用
- **难点**：为什么构造方法 "没有返回值类型，连 `void` 都不写" / 为什么 `this(...)` 必须放第一行 / 显式写构造后无参不再自动生成

### 3.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
承接第 2 课时的封装版 `Student`，现场敲一段初始化代码：
```java
Student s = new Student();
s.setId("2026001");
s.setName("张三");
s.setAge(20);
s.setScore(88.5);
```
问："**创建一个对象要写 5 行，有没有更简洁的写法？**" 学生若答不出，追问："**如果 `new Student(...)` 括号里能直接把 4 个字段传进去，能不能一步到位？**" 引出：**构造方法** 就是干这件事的。

#### 新知讲授（18 分钟）
按四小节推进：

1. **构造方法的特点**（4 分钟）
   板书写下 4 条：
   - 方法名 **与类名完全相同**；
   - **没有返回值类型**，连 `void` 都不写；
   - 可以有多个（**重载**）；
   - 每个类都 **默认有一个无参构造** —— 如果你没显式写。

   讲清 "为什么没有返回值类型"：构造方法的 **返回值就是 "新造的对象本身"**，是由 `new` 关键字统一约定的，不需要你再写 —— 写了反而变成普通方法（编译不报错，但不是构造）。

2. **无参构造**（3 分钟）
   ```java
   public Student() {
       System.out.println("一个 Student 对象被创建了。");
   }
   ```
   问："**没写这个构造之前，`new Student()` 也能运行，为什么？**" 答：编译器 **默认帮你补了一个空的无参构造**。这个默认构造对每个 **没显式写构造** 的类都存在。

3. **全参构造**（5 分钟）
   ```java
   public Student(String id, String name, int age, double score) {
       this.id = id;
       this.name = name;
       this.age = age;
       this.score = score;
   }
   ```
   调用：
   ```java
   Student s = new Student("2026001", "张三", 20, 88.5);
   ```
   强调 **`this.` 的必要性** —— 形参和字段同名，`this.id = id;` 才是 "把形参 `id` 赋给当前对象的字段 `id`"。

4. **构造方法重载 + `this(...)`**（6 分钟）
   同一个类可以有多个构造方法：
   ```java
   public Student() {}                                   // 无参
   
   public Student(String id, String name) {              // 部分参数
       this.id = id;
       this.name = name;
   }
   
   public Student(String id, String name, int age, double score) {   // 全参
       this(id, name);      // 调用同类另一个构造方法，必须放第一行
       this.age = age;
       this.score = score;
   }
   ```
   讲清两点：（1）**重载的判断标准** 是形参列表不同（个数、类型、顺序）；（2）**`this(...)` 必须放第一行**，因为构造方法之间要 "接力"，先跑完 "父级构造" 才能跑自己的初始化。

#### 示例演示（10 分钟）
现场演示 **"显式写构造后无参不再自动生成"** 这个大坑：
```java
public class Student {
    private String name;
    public Student(String name) { this.name = name; }
}

Student s = new Student();   // ❌ 编译报错：找不到无参构造
```
在 IDE 里让学生看到红波浪线，报错信息 `required: java.lang.String, found: no arguments`。**给出补救方案**：只要写了带参构造，通常也补上一个无参构造 —— 方便后续框架（如 Spring、Jackson）反射创建对象。

再演示 **完整版 `Student`**（含封装 + 构造）：
```java
public class Student {
    private String id;
    private String name;
    private int age;
    private double score;

    public Student() {}

    public Student(String id, String name, int age, double score) {
        this.id = id;
        this.name = name;
        setAge(age);       // 复用 setter 中的校验
        setScore(score);
    }

    // getter / setter 省略

    public void printInfo() {
        System.out.printf("[%s] %s，年龄 %d，成绩 %.2f%n", id, name, age, score);
    }
}
```

调用：
```java
Student s1 = new Student("2026001", "张三", 20, 88.5);
Student s2 = new Student("2026002", "李四", -5, 92);   // -5 被 setter 拒绝，age 默认 0
s1.printInfo();
s2.printInfo();
```
强调："**构造方法里调用 `setter`，可以复用 `setter` 里的校验逻辑，不用重复写 if。**"

演示 **IDEA 一键生成构造方法**：`Alt + Insert` → `Constructor` → 勾选要初始化的字段 → OK。

#### 课堂练习（8 分钟）
1. 给你的 `Book` 类增加 3 个构造方法：无参、`Book(String title)`、`Book(String title, String author, double price)`；后两个用 `this(...)` 逐层复用。
2. 判断下列代码是否可编译：
   ```java
   public class A {
       public A(int x) { }
   }
   public class Test { A a = new A(); }   // ❓
   ```
   —— 不可以，`A` 显式写了带参构造，默认无参构造消失。
3. 说出下列调用会走哪个构造方法：
   ```java
   new Student();
   new Student("2026001", "张三");
   new Student("2026001", "张三", 20, 88.5);
   ```

#### 小结（3 分钟）
回顾三句话：**构造方法名 = 类名 / 无返回类型 / 显式写了带参就手动补无参**。预告下一课时 **继承** —— 让子类白捡父类的字段和方法。

### 3.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 3 课时：构造方法（Constructor）               │
├───────────────────────────────────────────────────┤
│  特点：                                           │
│    1.方法名 == 类名                               │
│    2.无返回值类型（连 void 都不写）               │
│    3.可重载                                       │
│    4.未写时编译器默认给一个无参                   │
│                                                   │
│  写法：                                           │
│    public Student() {}                            │
│    public Student(String id, String name) {       │
│        this.id = id;                              │
│        this.name = name;                          │
│    }                                              │
│                                                   │
│  重载 + this(...) 复用：                          │
│    this(id, name);   // 必须放第一行              │
│                                                   │
│  ⚠ 显式写带参 → 无参消失                          │
│  建议：带参和无参都写                             │
│                                                   │
│  IDEA：Alt + Insert → Constructor                 │
└───────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：给 `Teacher` 类补上 3 个构造方法：无参、`Teacher(String id, String name)`、全参；用 `this(...)` 复用。
2. **必做**：写一个 `Rectangle`（矩形）类：字段 `width / height`；提供无参构造（默认宽高 = 1）、全参构造。写方法 `area()` 返回面积。
3. **挑战题**：用类改写 Day03 的 "学生管理系统" —— 把 4 个平行数组换成 `Student[] students`，添加、查找、修改各写一个静态方法。感受 "改字段只动一处" 的爽感。

### 3.6 教学反思提示
- 学生是否知道 "写了带参构造后必须手动补无参"？这个坑几乎每届都有人栽；
- `this(...)` 的 "第一行" 规则要不要现场演示违反后的编译错误？强化印象。

---

## 第 4 课时：继承的概念、语法 + 方法重写

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能用 "is-a 关系" 判断两个类之间是否适合用继承；
2. 能写出 `extends` 语法，定义 `Person → Student` 这样的父子类；
3. 能背下 Java 继承的三条限制（**只能单继承 / `private` 不能被子类直接访问 / 构造方法不能被继承**）；
4. 能用 `@Override` 注解正确重写父类方法，并说清重写的 "两同两小一大" 规则；
5. 能区分 **重写（Override）** 与 **重载（Overload）** 至少 3 项差异。

#### 4.1.2 过程与方法目标
1. 通过 "动物 → 狗 / 猫" 的例子，从直觉上体会 "子类是父类的一种特殊化"；
2. 通过 `Animal.makeSound()` 与 `Dog.makeSound()` 的对比，让学生看见 "同名方法在子类中被覆盖"。

### 4.2 教学重难点
- **重点**：`extends` 语法 / `protected` 修饰符 / 方法重写的 "两同两小一大" 规则 / `@Override` 注解的价值
- **难点**：为什么单继承（不能同时 `extends A, B`） / 私有字段 "存在但不可直接访问" 的双重理解 / 重写与重载的辨析

### 4.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
先做一个 "**分类游戏**"：请学生举例 —— **"什么东西 is-a 动物？"** 学生会答：狗、猫、鸟、鱼……追问："**这些动物都会 `eat()`（吃饭），我们要不要每个类都写一次 `eat()` 方法？**" 答：**不用**，把 `eat()` 写在 "动物" 这个共同父类里，让子类白捡就好。这就是 **继承**。板书写下：**"is-a 关系 → extends"**。

#### 新知讲授（20 分钟）
按四小节推进：

1. **继承的概念与语法**（5 分钟）
   板书语法：
   ```java
   public class 子类名 extends 父类名 {
       // 子类独有的字段和方法
   }
   ```
   讲两条重要规则：
   - Java **只支持单继承**：一个子类只能有一个直接父类；
   - 但支持 **多层继承**：C 继承 B，B 继承 A，C 间接继承 A 的所有能力。

   继承的三条好处：**代码复用 / 代码扩展 / 多态基础**。

2. **简单示例 + `protected`**（6 分钟）
   现场敲：
   ```java
   public class Person {
       protected String name;
       protected int age;
   
       public void eat() {
           System.out.println(name + " 在吃饭");
       }
   }
   
   public class Student extends Person {
       private String studentId;
   
       public void study() {
           System.out.println(name + "（学号 " + studentId + "）在学习");
       }
   
       public void setStudentId(String studentId) { this.studentId = studentId; }
   }
   ```
   讲清 **`protected`**：**"外部禁用、但子类可用"** —— 父类希望子类能直接读写、但不希望其他类乱碰的字段/方法，用 `protected`。

   继承的三条 **限制**（板书圈出）：
   - **只能单继承**（1 个直接父类），但可以实现多个接口；
   - **私有成员不能被子类直接访问**：父类的 `private` 字段虽然在子类对象里存在（占内存），但子类代码里不能直接 `this.xxx`，必须通过父类的 `public getter`；
   - **构造方法不能被继承**，但子类构造第一行会自动调用父类无参构造（下一课时讲）。

3. **方法重写（Override）**（5 分钟）
   板书定义：**子类 "覆盖" 父类中同名同参的方法，提供自己的实现。**

   现场敲经典例子：
   ```java
   public class Animal {
       public void makeSound() {
           System.out.println("动物在叫");
       }
   }
   public class Dog extends Animal {
       @Override
       public void makeSound() {
           System.out.println("汪汪汪");
       }
   }
   public class Cat extends Animal {
       @Override
       public void makeSound() {
           System.out.println("喵喵喵");
       }
   }
   ```
   调用：
   ```java
   new Animal().makeSound();   // 动物在叫
   new Dog().makeSound();      // 汪汪汪
   new Cat().makeSound();      // 喵喵喵
   ```

4. **重写规则 "两同两小一大"** + **`@Override` 注解**（4 分钟）
   板书三行：
   - **两同**：方法名相同、形参列表相同；
   - **两小**：子类返回值类型 ≤ 父类（协变返回）、抛出的检查异常 ≤ 父类；
   - **一大**：子类的访问修饰符 ≥ 父类（不能更严格）。

   `@Override` 注解 —— **强烈建议每次重写都加**。它让编译器帮你检查：方法名/参数拼写错误、父类里根本没这个方法 —— 都会 **编译报错**，及时暴露。

#### 示例演示（8 分钟）
现场演示 **`@Override` 拼错方法名的报错**：
```java
public class Dog extends Animal {
    @Override
    public void makesound() {   // 小写 s，故意拼错
        System.out.println("汪汪汪");
    }
}
```
学生会看到红波浪线，`method does not override or implement a method from a supertype`。**结论**：如果不写 `@Override`，这行代码是合法的 —— 会变成 `Dog` 独有的一个新方法，`makeSound()` 反而没被覆盖，是隐蔽的大 Bug。

投影 **重写 vs 重载** 对比表：

| 维度 | 重写（Override） | 重载（Overload） |
|------|-----------------|-----------------|
| 范围 | 父子类之间 | 同一个类里 |
| 方法名 | 相同 | 相同 |
| 参数列表 | **相同** | **不同** |
| 返回值 | 相同或兼容 | 无关 |
| 修饰符 | 不能更严格 | 无关 |

反复强调：**参数列表相同 → 重写；参数列表不同 → 重载**。

#### 课堂练习（8 分钟）
1. 定义 `Vehicle`（交通工具）父类，字段 `brand`，方法 `run()` 输出 "XX 在行驶"；子类 `Car` 重写 `run()` 输出 "XX 汽车在马路上跑"，子类 `Boat` 重写 `run()` 输出 "XX 船在水里跑"。
2. 判断下列代码：
   ```java
   public class Parent { public void hello() {} }
   public class Child extends Parent {
       @Override
       private void hello() {}   // ❓
   }
   ```
   编译能过吗？—— **不能**。子类 `private` 比父类 `public` 更严格，违反 "一大" 规则。
3. 说出下面两个方法是重写还是重载？
   ```java
   class A { public void f(int x) {} }
   class B extends A { public void f(long x) {} }
   ```
   —— **重载**（`B` 里既有继承来的 `f(int)` 又有自己的 `f(long)`，形参不同）。

#### 小结（3 分钟）
回顾三句话：**is-a 就 extends / 只支持单继承 / 重写要加 `@Override`**。预告下一课时 **`this` 与 `super` 关键字** —— 继承下的 "两个我" 如何各司其职。

### 4.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 4 课时：继承 + 方法重写                       │
├───────────────────────────────────────────────────┤
│  语法：class 子 extends 父                        │
│  规则：只能单继承 / 可以多层                      │
│                                                   │
│  三大限制：                                       │
│    1.单继承                                       │
│    2.private 不能被子类直接访问                   │
│    3.构造不被继承                                 │
│                                                   │
│  protected：外部不可、子类可                      │
│                                                   │
│  重写（Override）"两同两小一大"：                 │
│    两同 = 方法名、形参                            │
│    两小 = 返回类型、异常                          │
│    一大 = 访问修饰符                              │
│                                                   │
│  @Override 必写！编译器帮你查错                   │
│                                                   │
│  重写 vs 重载：形参相同 vs 形参不同               │
└───────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：定义 `Animal` 父类（字段 `name / age`，方法 `eat()`），子类 `Dog / Cat` 各重写 `makeSound()`，`main` 中创建 3 只动物并调用。
2. **必做**：给 Day03 里的 `Book` 类做个子类 `EBook`（电子书），新增字段 `downloadUrl`，重写一个 `printInfo()` 方法在末尾附加下载链接。
3. **挑战题**：查资料—— Java 为什么不支持多继承？（提示：菱形继承 / 钻石问题）用 200 字回答。

### 4.6 教学反思提示
- 学生是否理解 "重写要加 `@Override`" 的价值？可现场演示不加 `@Override` 时的 Bug 埋点；
- 单继承的限制学生能否举例说明？

---

## 第 5 课时：this 与 super 关键字

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 能背下 `this` 的 3 种用法（区分同名字段、调用同类构造、调用同类方法）；
2. 能背下 `super` 的 2 种用法（访问父类被隐藏的字段/方法、调用父类构造）；
3. 能解释 "子类构造第一行必是 `super(...)` 或 `this(...)`" 的规则；
4. 能诊断 "父类没有无参构造，子类构造未显式 `super(...)`" 这个初学者高频错误，并给出修复方案；
5. 能画出 `super` 视角下的对象内存图，理解 "`super` 不是另一个对象"。

#### 5.1.2 过程与方法目标
1. 通过对比 `this.` 与 `super.` 的使用场景，让学生建立 "两个视角" 的心智模型；
2. 通过 Mermaid 内存图，把 "父类部分 + 子类部分" 在同一对象中的关系画出来。

### 5.2 教学重难点
- **重点**：`this` 与 `super` 的 5 种典型用法 / 子类构造第一行的默认规则 / 父类无无参构造时的必须显式 `super(...)`
- **难点**：为什么 `super` "不是另一个对象" —— 它只是当前对象的 "父类视角" / `this(...)` 与 `super(...)` 二选一、不能同时出现

### 5.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
承接第 4 课时的 `Person → Student` 继承例子，追问："**Person 的构造方法带参了，Student 怎么办？**" 板书写下一个空白的：
```java
public class Person { public Person(String name) {} }
public class Student extends Person {
    public Student(String name, String studentId) {
        // 这里能写什么？
    }
}
```
学生若尝试直接写 `this.name = name;`，提示 "不行，`name` 是父类的字段，况且父类构造有初始化逻辑"。引出：**必须先调用父类构造把父类部分建好，再建自己的部分** —— 这就是 `super(...)` 的用武之地。

#### 新知讲授（20 分钟）
按四小节推进：

1. **`this` 关键字（复习 + 系统化）**（5 分钟）
   `this` 代表 **当前对象**，主要三种用法：
   - 区分成员变量与局部变量：`this.age = age;`
   - 调用同类其他构造方法：`this(...)`，**必须在构造第一行**；
   - 调用当前对象的其他方法：`this.study();`（`this.` 可省略）。

   现场敲一个综合例子：
   ```java
   public class Student {
       private String name;
       private int age;
       public Student() { this("匿名", 0); }
       public Student(String name, int age) {
           this.name = name;
           this.age = age;
           this.printInfo();
       }
       public void printInfo() {
           System.out.println(name + " / " + age);
       }
   }
   ```

2. **`super` 关键字**（6 分钟）
   `super` 代表 **父类的引用**，两种用法：

   （1）**访问父类被隐藏的字段/方法**：
   ```java
   public class Dog extends Animal {
       @Override
       public void makeSound() {
           super.makeSound();    // 先叫一声 "动物在叫"
           System.out.println("汪汪汪");
       }
   }
   ```
   典型用法：**"在父类基础上加料"**。

   （2）**调用父类构造方法**：`super(...)`，**必须在子类构造第一行**。

3. **子类构造与 `super`**（6 分钟）
   **关键规则**（板书圈出）：**子类构造第一行必定是 `super(...)` 或 `this(...)` 之一。如果都不写，编译器自动补 `super();`（调用父类无参构造）。**

   现场演示：
   ```java
   public class Person {
       public Person(String name) {
           System.out.println("Person(String) 被调用：" + name);
       }
   }
   public class Student extends Person {
       public Student(String name, String studentId) {
           super(name);   // 必须显式调用，因为父类没有无参构造
           System.out.println("Student 被创建：" + studentId);
       }
   }
   ```

   **大坑演示** —— 把 `super(name);` 那行删除：
   ```java
   public Student(String name, String studentId) {
       // super(); ←编译器想帮你补，但父类没有无参构造
       System.out.println("Student 被创建：" + studentId);
   }
   ```
   **编译报错**：`There is no default constructor available in 'Person'`。**结论**：**父类没无参构造 → 子类必须在第一行显式 `super(...)` 传参**。

4. **`this` vs `super` 对比**（3 分钟）
   投影对比表：

   | 关键字 | 指向 | 常见用途 |
   |--------|------|---------|
   | `this` | 当前对象 | 区分同名字段、调用同类构造、调用同类方法 |
   | `super` | 父类引用 | 访问父类字段/方法、调用父类构造 |

   补一句易混点：**`this(...)` 和 `super(...)` 都必须放构造第一行，二选一 —— 不能同时出现**。

#### 示例演示（8 分钟）
画 Mermaid 内存图，帮学生理解 "**`super` 不是另一个对象**"：
```mermaid
flowchart TB
    subgraph 对象["Student 对象（堆）"]
        P["Person 部分<br/>name / age"]
        S["Student 部分<br/>studentId"]
    end
    thisRef["this 指向整个对象"]
    superRef["super 视角只能看到 Person 部分"]
    thisRef --> 对象
    superRef --> P
```
反复强调："**`super` 只是 '当前对象的父类视角'，不是又造了一个 Person 对象**。" 内存里只有 **一个** `Student` 对象，只是它内部划分为 "父类部分" 和 "子类部分" 两块。

再演示一个 **多层构造调用链**：
```java
public class A {
    public A() { System.out.println("A"); }
}
public class B extends A {
    public B() { System.out.println("B"); }
}
public class C extends B {
    public C() { System.out.println("C"); }
    public static void main(String[] args) {
        new C();
    }
}
```
输出：
```text
A
B
C
```
讲清 "构造链是自顶向下"：`new C()` → 先跑 `A()` → 再 `B()` → 最后 `C()`。因为每个构造第一行都被自动补上了 `super()`。

#### 课堂练习（8 分钟）
1. 定义 `Person` 类，无无参构造，只有 `Person(String name)`。定义子类 `Student extends Person`，写一个 `Student(String name, String studentId)` 让代码可编译。
2. 判断下列代码输出：
   ```java
   public class A { public A() { System.out.println("A"); } }
   public class B extends A {
       public B() { this(1); System.out.println("B()"); }
       public B(int x) { System.out.println("B(int)"); }
   }
   // main: new B();
   ```
   —— 输出：`A / B(int) / B()`。`this(1)` 调 `B(int)`，`B(int)` 自动 `super()` 调 `A()`。
3. 说出 `this` 和 `super` 各自的 2 种典型用法。

#### 小结（3 分钟）
回顾三句话：**`this` = 当前对象 / `super` = 父类视角 / 二选一必须放第一行**。预告下一课时 **Object 类常用方法** —— 你写的每一个类都在悄悄继承它。

### 5.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 5 课时：this / super                          │
├───────────────────────────────────────────────────┤
│  this = 当前对象                                  │
│    1.this.age = age;                              │
│    2.this(...) 调本类构造 - 第一行                │
│    3.this.method()                                │
│                                                   │
│  super = 父类视角                                 │
│    1.super.field / super.method()                 │
│    2.super(...) 调父类构造 - 第一行               │
│                                                   │
│  规则：                                           │
│    子类构造第一行 = super(...) 或 this(...)       │
│    都不写 → 默认 super();                         │
│    父类无无参 → 必须显式 super(...)               │
│    this() 和 super() 不能同时出现                 │
│                                                   │
│  super 不是新对象！只是同一对象的父类部分         │
└───────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：写 `Person → Student → GraduateStudent`（研究生）三层继承链，研究生新增 `researchTopic`；每层构造用 `super(...)` 层层调用；`main` 中创建一个 `GraduateStudent`，输出构造链的调用顺序。
2. **必做**：给 `Dog extends Animal` 的 `makeSound()` 加一行 `super.makeSound();`，观察输出顺序。
3. **挑战题**：思考——如果 `this(...)` 和 `super(...)` 都必须放第一行，那能不能同时出现？为什么？（答：不能，两者互斥；如果调 `this(...)`，那 `this(...)` 里再自动调 `super(...)`，父类构造还是会被调，只是间接的。）

### 5.6 教学反思提示
- 学生是否理解 "`super` 不是另一个对象"？可用 Mermaid 图反复解释；
- 父类无无参构造的坑，学生能否主动识别？可给一段代码让他们诊断。

---

## 第 6 课时：Object 类常用方法（toString / equals / hashCode）

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 能说清 `Object` 是所有 Java 类的 **根父类**，不显式 `extends` 时默认继承 `Object`；
2. 能重写 `toString()` 方法，返回 "**类名 + 字段值**" 格式的字符串；
3. 能按标准模板重写 `equals(Object o)` 方法，正确处理 `null` 和类型判断；
4. 能背下 "**重写 `equals` 必须同时重写 `hashCode`**" 的规矩，并解释原因（`HashMap / HashSet` 依赖）；
5. 能用 `Objects.equals` 和 `Objects.hash` 简化 `equals / hashCode` 的实现；
6. 能通过 `getClass().getSimpleName()` 获取运行时类型名。

#### 6.1.2 过程与方法目标
1. 通过 `System.out.println(obj)` 默认输出 "**类名@十六进制哈希**" 的现场演示，让学生感受到 "不重写 `toString` 就没意义"；
2. 通过 `==` 与 `equals` 对同两个字段一样的对象比较结果不同，让学生看懂 "**引用相等 vs 内容相等**"。

### 6.2 教学重难点
- **重点**：`toString / equals / hashCode` 的标准重写模板 / `Objects.equals` 与 `Objects.hash` 的使用 / `==` 与 `equals` 的语义区别
- **难点**：为什么 `equals` 和 `hashCode` 必须成对重写 / `getClass() != o.getClass()` 与 `instanceof` 的选择

### 6.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
现场敲：
```java
Student a = new Student("2026001", "张三");
System.out.println(a);
```
输出大概是：`Student@1540e19d` —— 类名 + `@` + 十六进制哈希。问："**这个输出你看得懂吗？** 有意义吗？" 学生答 "看不懂"。再问："**如果两个学生学号名字都一样，`a == b` 是 `true` 吗？** `a.equals(b)` 呢？" 引出：**`Object` 里的 `toString / equals / hashCode` 需要被重写，才好用**。

#### 新知讲授（22 分钟）
按四小节推进：

1. **`Object` 是根父类**（3 分钟）
   板书画同心圆：`Object` 在最外层，所有 Java 类都是它的子类。**"你写 `class Student {}`，其实等价于 `class Student extends Object {}`。"** 所以每个类都自动有 `toString / equals / hashCode / getClass` 等方法。

2. **`toString`**（5 分钟）
   **默认实现**：`类名@十六进制哈希`，几乎没意义。**通常都要重写**。

   标准写法：
   ```java
   @Override
   public String toString() {
       return "Student{id='" + id + "', name='" + name + "', age=" + age + ", score=" + score + "}";
   }
   ```

   **`System.out.println(obj)` 的秘密**：它内部就是调用 `obj.toString()`。所以你重写了 `toString`，`println` 输出立刻好看。

   演示 **IDEA 一键生成**：`Alt + Insert` → `toString()` → 选字段 → OK。

3. **`equals`**（7 分钟）
   **两个符号的对比**：
   - `==`：比较 **引用地址**（是否同一个对象）；
   - `.equals(...)`：比较 **内容** —— 但 `Object` 的默认实现仍然是 `==`，所以 **不重写就等于没重写**。

   标准重写模板（背下来）：
   ```java
   @Override
   public boolean equals(Object o) {
       if (this == o) return true;                     // 同一个对象，秒返 true
       if (o == null || getClass() != o.getClass()) return false;  // 空或类型不同
       Student student = (Student) o;                  // 类型转换
       return age == student.age
           && Double.compare(student.score, score) == 0
           && Objects.equals(id, student.id)
           && Objects.equals(name, student.name);
   }
   ```

   `Objects.equals(a, b)` 是 `java.util.Objects` 提供的 **空安全比较**：两个都 `null` 也算相等，任何一个 `null` 时不抛 NPE。

4. **`hashCode`**（7 分钟）
   **两条约定**（板书圈出）：
   - `equals` 相等的对象，`hashCode` **必须相等**（反正不必）；
   - **重写 `equals` 就一定重写 `hashCode`**。

   为什么？—— 放到 `HashMap / HashSet`（第 12 章）时，先按 `hashCode` 找 "桶"，再在桶里用 `equals` 精确比。如果两个 "内容相等" 的对象 `hashCode` 不同，会被放进不同的桶，`HashSet` 就无法去重、`HashMap` 无法覆盖 key —— 这是初学者最容易踩的隐蔽 Bug。

   标准写法：
   ```java
   @Override
   public int hashCode() {
       return Objects.hash(id, name, age, score);
   }
   ```
   `Objects.hash(...)` 会把多个字段的哈希 **合成一个 int**。

   IDEA 会 **同时** 生成 `equals / hashCode`，一步到位：`Alt + Insert` → `equals() and hashCode()`。

#### 示例演示（8 分钟）
现场敲一份 **完整示例**，让学生看到所有效果：
```java
import java.util.Objects;

public class Student {
    private String id;
    private String name;

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{id='" + id + "', name='" + name + "'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student s = (Student) o;
        return Objects.equals(id, s.id) && Objects.equals(name, s.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    public static void main(String[] args) {
        Student a = new Student("2026001", "张三");
        Student b = new Student("2026001", "张三");
        System.out.println(a);            // Student{id='2026001', name='张三'}
        System.out.println(a == b);       // false（引用不同）
        System.out.println(a.equals(b));  // true（内容相同）
        System.out.println(a.hashCode() == b.hashCode());  // true
    }
}
```

顺便讲 **`getClass()`** —— 返回对象的 **运行时类型**：
```java
Student s = new Student();
System.out.println(s.getClass().getName());        // 完整类名
System.out.println(s.getClass().getSimpleName());  // 简单类名 Student
```
后续学反射时会大量用到。

再演示一个 **AI 提示词模板** 供课后使用：
```text
请帮我给下面这个 Java 类生成规范的：
1. toString（含所有字段）；
2. equals（基于 id 唯一标识判等）；
3. hashCode（与 equals 一致）；
4. 用 java.util.Objects 工具类实现，避免手写 null 判空。

[粘贴类代码]
```

#### 课堂练习（6 分钟）
1. 给你的 `Book` 类补上标准 `toString / equals / hashCode`；`main` 里创建 2 本 "内容完全一样" 的 `Book`，验证 `equals` 返回 `true`、`hashCode` 相同。
2. 判断下列代码输出：
   ```java
   String s1 = new String("hi");
   String s2 = new String("hi");
   System.out.println(s1 == s2);         // ❓
   System.out.println(s1.equals(s2));    // ❓
   ```
   —— `false / true`。`String` 的 `equals` 已经被 JDK 重写为按内容比较。
3. 说一句话：**为什么重写 `equals` 一定要重写 `hashCode`？**（答：`HashSet / HashMap` 依赖 `hashCode` 找桶；如果 `equals` 相等而 `hashCode` 不同，去重和 key 判断都会失败。）

#### 小结（本日收官，5 分钟）
用一张 **本日知识图谱** 总结全天：
- 上午（第 1—3 讲）：**类与对象、封装、构造方法** —— 学会 "**把数据和行为绑一起**"，用 `private + getter/setter + 构造` 优雅初始化对象；
- 下午（第 4—6 讲）：**继承 + this/super + Object 根方法** —— 学会 "**子类白捡父类能力**"，并让每个类都拥有 "**能自我描述、能自我判等**" 的基本人格。

板书写下 "**类是数据 + 行为的容器，继承是能力的传递，Object 让每个类都有基本人格。**"

**Day05 预告**：多态、`final`、静态成员、`Math` 工具类 —— 让 `Animal a = new Dog()` 这样的写法运行时表现为狗叫，感受面向对象的最后一大特性。

### 6.4 板书设计
```text
┌───────────────────────────────────────────────────┐
│  第 6 课时：Object 类常用方法                     │
├───────────────────────────────────────────────────┤
│  Object 是所有类的根父类                          │
│                                                   │
│  toString():                                      │
│    默认 = 类名@hash（没意义）                     │
│    重写 → println 立刻好看                        │
│                                                   │
│  == vs equals:                                    │
│    == 比引用                                      │
│    equals 比内容（默认还是 ==，要重写）           │
│                                                   │
│  equals 标准模板：                                │
│    1.this == o?                                   │
│    2.o == null || 类不同?                         │
│    3.强转 + 字段逐个比                            │
│    4.Objects.equals(...) 空安全                   │
│                                                   │
│  ⚠ 重写 equals 必须重写 hashCode                  │
│  hashCode → Objects.hash(...)                     │
│                                                   │
│  IDEA：一键 toString + equals + hashCode          │
└───────────────────────────────────────────────────┘
```

### 6.5 课后作业（Day04 汇总）
**必做（3 题）：**
1. 给你的 `Book` 类补上 `toString / equals / hashCode`；把两本 "内容一样" 的 `Book` 放进 `HashSet`，观察是否只保留 1 个。
2. 给 `Student` 类补上完整的 `toString / equals / hashCode`（`equals` 基于学号 `id` 判等）；在 `main` 中演示两个学号相同、姓名不同的对象 `equals` 为 `true` 的情况。
3. 用 `getClass().getSimpleName()` 打印一个 `Student` 对象的类名，观察输出。

**选做（1 题）：**
4. 用类改写 Day03 的 "学生实训管理系统" —— 用 `Student` 类替换 4 个平行数组，实现添加、查找、修改、删除功能。感受 "改字段只动 `Student` 类一处" 的爽感。

**思考题（1 题）：**
5. 让 AI 给你解释「为什么重写 `equals` 必须同时重写 `hashCode`」，并让它举一个 **违反此约定后 HashMap 出错** 的具体例子。整理成 200 字笔记贴到自己的 GitHub。

### 6.6 教学反思提示
- 学生是否理解 "`equals` 和 `hashCode` 是一对儿"？可现场演示不重写 `hashCode` 导致 `HashSet` 无法去重的 Bug；
- 全天 6 课时结束后，学生对 "面向对象" 的整体认知是否已经建立？回顾第 1 讲的 "谁来做" 心智模型是否内化。
