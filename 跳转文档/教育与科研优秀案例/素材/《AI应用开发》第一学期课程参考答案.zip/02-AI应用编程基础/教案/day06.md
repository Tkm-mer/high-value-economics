# AI 应用编程基础——Java 基础 - 教师教案（Day06：第 1—6 课时）

**总课时：6 课时 × 45 分钟（Day06 全天，全课程收官日）**
**授课对象：具备 Day01—Day05 基础（语法、方法、数组、面向对象、抽象/接口/枚举/Record）的初学者**
**知识点覆盖：第 11 章 String 与包装类 + 第 12 章 ArrayList / HashMap / HashSet 与泛型基础**
**版本基线：JDK 25 LTS · IntelliJ IDEA 2026.1**

> Day06 是本课程的最后一天，全课程知识点在今天完成收口。授课节奏应比前几天更**收**——不再引入全新语法糖，而是把\"字符串\"和\"容器\"这两块日常写代码 80% 时间会碰的工具讲透，最后用 12.6 的 `StudentSystemV2` 把前面所有章节的成果串成一条线。

---

## 第 1 课时：String 类的常用方法

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 说出 `String` 是 `final` 类、不可变（immutable）的三条依据（final 修饰、返回新对象、hashCode 可缓存）。
2. 区分字面量创建（`"Hello"`）与 `new String("Hello")` 的地址差异，能画出常量池与堆的示意图。
3. 熟练调用 12 个高频 API：`length / charAt / equals / equalsIgnoreCase / substring / indexOf / lastIndexOf / contains / startsWith / replace / split / strip`。
4. 能独立写出\"判断回文串\"\"字符类型统计\"两个经典例题。

#### 1.1.2 过程与方法目标
1. 通过\"`==` vs `equals`\" 的翻车演示，让学生亲眼看到字面量 pool 的行为，建立\"字符串比较只用 `equals`\"的肌肉记忆。
2. 用一张\"不改变原字符串\"备忘表统一收纳所有方法，避免死记硬背。

### 1.2 教学重难点
- **重点**：不可变本质 / 字符串常量池 / `equals` vs `==` / `substring` 与 `indexOf` 的边界处理
- **难点**：常量池位置（JDK 7+ 在堆中）与 `intern()` 的语义 / `substring(a, b)` 的左闭右开语义

### 1.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问：\"昨天我们讲了 Record，一个不可变的数据载体。今天要讲的 `String`，其实是全 Java 世界最著名的不可变类。为什么 Java 设计者要把它做成不可变？把它做成可变会有什么后果？\" 学生大概率会说\"改起来方便\"，反问：\"那你把 `HashMap` 里当 key 的字符串改了，桶还能找到它吗？\" 引出\"不可变=安全、可缓存、可共享\"三大好处。

#### 新知讲授（18 分钟）

**（1）String 的本质（3 分钟）**
上黑板写：
```java
public final class String { ... private final byte[] value; ... }
```
强调两个 `final`：类 `final`（不能被继承）+ 字段 `final`（引用不变）。JDK 9 起从 `char[]` 换成 `byte[]` + coder 字段，为 Latin-1 节省一半内存——这是学生们大概率没听过的细节，讲一嘴增加信息密度。

**（2）三种创建方式与内存图（5 分钟）**
在黑板上画出栈、堆、字符串常量池三块区域：
```text
栈：s1 → ┐              堆（常量池区）：
    s2 → ┼→ "Hello"     "Hello"
    s3 → new String(...) → 堆里另一块 → 内部 value → 指回池中 "Hello"
```
逐行讲：
```java
String s1 = "Hello";
String s2 = "Hello";
String s3 = new String("Hello");
System.out.println(s1 == s2);      // true
System.out.println(s1 == s3);      // false
System.out.println(s1.equals(s3)); // true
```
结论一句话钉在黑板上：**\"内容比较只用 `equals()`\"**。

**（3）常量池与 intern（2 分钟）**
`new String("abc").intern()` 会把当前串加入池中（若不存在），并返回**池里的引用**；已存在则直接返回池引用。位置在 JDK 7+ 起挪到了**堆里**（早期在 PermGen / Metaspace 里，是常见面试题）。

**（4）常用方法一览表（8 分钟）**
把教材 11.1.4 的表画到 PPT / 黑板上，讲的时候按\"查询类 → 判断类 → 转换类 → 分割类\"分组：
- 查询：`length / charAt / indexOf / lastIndexOf`
- 判断：`equals / equalsIgnoreCase / contains / startsWith / endsWith / isEmpty / isBlank`
- 转换：`toLowerCase / toUpperCase / trim / strip / replace / substring`
- 分割：`split`

**易错点标注：**
- `substring(a, b)` 是**左闭右开**：`"hello".substring(1, 4)` 返回 `"ell"`。
- `trim()` 只处理 ASCII 空白，`strip()`（JDK 11+）处理 Unicode 空白——写 CJK 项目请用 `strip`。
- `split("\\s+")` 中反斜杠要转义。
- `replace('a','b')` 是**全部替换**，与 SQL 的 `REPLACE()` 一致，不要以为只替换首个。

#### 示例演示（12 分钟）

**示例 1：回文串（5 分钟）**
现场手敲，讲清楚双指针的收敛条件：
```java
public static boolean isPalindrome(String s) {
    int left = 0, right = s.length() - 1;
    while (left < right) {
        if (s.charAt(left) != s.charAt(right)) return false;
        left++;
        right--;
    }
    return true;
}
```
测试：`isPalindrome("level")` → true；`isPalindrome("abc")` → false。追问学生：如果我要**忽略大小写**，改哪一行？答：把 `charAt` 前套 `Character.toLowerCase(...)`。

**示例 2：字符类型统计（4 分钟）**
```java
String s = "Hello 2026 Java!";
int letters = 0, digits = 0, spaces = 0, others = 0;
for (int i = 0; i < s.length(); i++) {
    char c = s.charAt(i);
    if (Character.isLetter(c)) letters++;
    else if (Character.isDigit(c)) digits++;
    else if (c == ' ') spaces++;
    else others++;
}
System.out.printf("字母 %d 数字 %d 空格 %d 其他 %d%n",
        letters, digits, spaces, others);
```
输出：`字母 9 数字 4 空格 2 其他 1`（叹号）。

**示例 3：反转字符串（3 分钟）**
```java
String r = new StringBuilder("hello").reverse().toString();
```
先卖个关子——为什么不能 `s.charAt(i) = ...`？因为**不可变**。这句是通往下一节的引子。

#### 课堂练习（6 分钟）
1. 写一段代码验证 `s1 == s3` 为 `false`、`s1.equals(s3)` 为 `true`。
2. 给出字符串 `"  Hello World  "`，分别用 `trim`、`strip` 输出并比较结果长度。
3. 用 `indexOf` + `substring` 从 `"user@nous.com"` 中提取用户名 `"user"`。

#### 小结（1 分钟）
一句话钉板：\"String 是 `final` + `byte[]`，所有\'修改\'都会返回新对象，比较用 `equals`，切片是左闭右开。\"

### 1.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 1 讲：String 常用方法                               │
│                                                        │
│ 1. 本质：public final class String                     │
│    - 内部 byte[] value（JDK 9+）                       │
│    - 不可变（immutable）                               │
│                                                        │
│ 2. 三种创建：                                          │
│    "Hello"        → 常量池                             │
│    new String(..) → 堆里另开                           │
│    intern()       → 加入 / 返回池中引用                │
│                                                        │
│ 3. 比较：字符串永远用 equals()，别用 ==                │
│                                                        │
│ 4. 常用方法四类：                                      │
│    查询 length/charAt/indexOf                          │
│    判断 equals/contains/startsWith/isBlank             │
│    转换 substring/strip/replace/toLowerCase            │
│    分割 split(regex)                                   │
│                                                        │
│ 5. 坑：substring 左闭右开；trim ≠ strip                │
└────────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. 用 `indexOf + substring` 而**不用 `split`**，把 `"a,b,c,d"` 拆成 `String[]`。
2. 实现 `boolean isPalindromeIgnoreCase(String s)`，忽略大小写和非字母字符（如 `"A man, a plan"`）。
3. 挑战题：不使用 `String.contains`，自己实现一个 `containsSlow(String s, String sub)`，用两层 `for`。

### 1.6 教学反思提示
- 学生最容易把\"字面量池只有一份\"和\"`new String` 也走池\"混淆，需要在黑板上把两条引用箭头画清楚。
- 若时间紧，`intern()` 可以只讲一句\"存在返回池，不存在放入池\"，不展开面试题。

---

## 第 2 课时：StringBuilder / StringBuffer 与 String 编程案例（StringUtils）

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 说出\"循环里 `+=` 拼接会产生 O(n) 个临时对象\"的具体原因，能画出对象数量增长曲线。
2. 熟练使用 `StringBuilder` 的 `append / insert / delete / reverse / replace / toString`，能写出链式调用。
3. 区分 `StringBuilder`（不加锁、快）与 `StringBuffer`（加 `synchronized`、慢、几乎不用）的使用场景。
4. 能读懂 11.4 综合案例 `StringUtils` 工具类，指出\"私有构造 + 静态方法 + `final` 类\"的设计意图。

#### 2.1.2 过程与方法目标
1. 用\"10000 次 `+=` vs 一个 `StringBuilder`\" 现场跑一次 `System.currentTimeMillis()` 对比，让性能差异被亲眼看见。
2. 用工具类的封装训练学生\"把重复逻辑抽出来\"的意识——这是所有工程化项目的第一步。

### 2.2 教学重难点
- **重点**：`+` vs `StringBuilder` 的场景选择 / 链式调用返回 `this` 的机制 / 工具类三件套（final class + private constructor + static methods）
- **难点**：为什么\"编译器会把 `s1 + s2` 优化成 `StringBuilder.append`\"但循环里的 `+=` 无法被优化

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
翻回第 1 讲最后那句：\"为什么不能 `s.charAt(i) = ...`？\"——因为不可变。那如果我真的要\"边构造边改\"呢？就需要一个**可变**版本的字符串。这就是 `StringBuilder` 的存在理由。

写一段挑衅性的代码在黑板上：
```java
String result = "";
for (int i = 0; i < 10000; i++) {
    result += i;
}
```
问：\"这段代码创建了大约多少个 `String` 对象？\" 让学生猜。答案：约 20000 个（每次 `+=` 拆成\"新 StringBuilder → append 两次 → toString 出新 String\"）。

#### 新知讲授（16 分钟）

**（1）StringBuilder 登场（4 分钟）**
```java
StringBuilder sb = new StringBuilder();
for (int i = 0; i < 10000; i++) {
    sb.append(i);
}
String result = sb.toString();
```
画一张\"可变缓冲区 + 长度指针\"的示意图：底层是 `char[]`（JDK 25 里仍是），`append` 时不够长就扩容（默认扩为 `old * 2 + 2`）。

**（2）核心方法（5 分钟）**
| 方法 | 说明 | 返回值 |
|------|------|--------|
| `append(x)` | 追加任意类型 | `this`（可链式） |
| `insert(i, x)` | 在下标 i 插入 | `this` |
| `delete(a, b)` | 删除 [a, b) | `this` |
| `reverse()` | 反转 | `this` |
| `replace(a, b, s)` | 替换 [a, b) 为 s | `this` |
| `toString()` | 转 `String` | 新 `String` |

**链式调用的原理**：每个方法都 `return this;`，所以可以像流水线一样接下去。

```java
String s = new StringBuilder()
        .append("Hello, ")
        .append(name)
        .append("!")
        .toString();
```

**（3）StringBuilder vs StringBuffer（3 分钟）**
| 类 | 线程安全 | 性能 | 版本 | 用场 |
|----|---------|------|------|------|
| `StringBuilder` | ❌ | 快 | JDK 5 | 默认选它 |
| `StringBuffer` | ✅（synchronized） | 慢 | JDK 1.0 | 多线程共享才用 |

**关键判断**：99% 的业务代码里\"字符串拼接\"都发生在单线程栈帧内，`StringBuilder` 就够了。

**（4）+ 与 StringBuilder 的选择（4 分钟）**
- **少量拼接**：`String greeting = "Hello, " + name + "!";` —— 编译器会自动优化成 `StringBuilder.append`。
- **循环拼接**：**必须**手写 `StringBuilder`，因为编译器无法把\"每轮生成的中间 String\"抹掉。

反编译提示：如果学生问\"为什么循环里的 `+=` 不能被优化\"，画一下伪代码：
```text
每次迭代都：new StringBuilder(result).append(i).toString()
                ^^^^^^^^^^^^^^^^^^^^^^
                每次都是全新的 StringBuilder
```

#### 示例演示（15 分钟）

**示例 1：性能对比现场跑（5 分钟）**
```java
long t1 = System.currentTimeMillis();
String r1 = "";
for (int i = 0; i < 100_000; i++) r1 += i;
long t2 = System.currentTimeMillis();

StringBuilder sb = new StringBuilder();
for (int i = 0; i < 100_000; i++) sb.append(i);
String r2 = sb.toString();
long t3 = System.currentTimeMillis();

System.out.println("+=       " + (t2 - t1) + " ms");
System.out.println("Builder  " + (t3 - t2) + " ms");
```
典型输出（现代机器）：`+= 2500 ms / Builder 5 ms`——**500 倍差距**。

**示例 2：StringUtils 综合案例（10 分钟）**
把教材 11.4 的 `StringUtils` 完整敲一遍，重点讲三个设计决策：

```java
public final class StringUtils {
    private StringUtils() {}     // ① 私有构造，阻止实例化

    public static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    public static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    public static String reverse(String s) {
        if (isEmpty(s)) return s;
        return new StringBuilder(s).reverse().toString();
    }

    public static String capitalize(String s) {
        if (isEmpty(s)) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public static int countOccurrences(String s, String sub) {
        if (isEmpty(s) || isEmpty(sub)) return 0;
        int count = 0, index = 0;
        while ((index = s.indexOf(sub, index)) != -1) {
            count++;
            index += sub.length();
        }
        return count;
    }

    public static String maskPhone(String phone) {
        if (isEmpty(phone) || phone.length() != 11) return phone;
        return phone.substring(0, 3) + "****" + phone.substring(7);
    }
}
```

**三件套**：
- `final class`：不允许被继承（工具类没有\"扩展点\"）。
- `private` 构造：不允许 `new`。
- 全部 `static`：直接 `StringUtils.reverse(...)` 调用。

这是**未来 Java 项目里所有工具类的标准写法**——Apache Commons、Google Guava 都是这个套路。

测试：
```java
System.out.println(StringUtils.reverse("hello"));                // olleh
System.out.println(StringUtils.capitalize("java"));              // Java
System.out.println(StringUtils.countOccurrences("abababab","ab")); // 4
System.out.println(StringUtils.maskPhone("13812341234"));        // 138****1234
```

#### 课堂练习（8 分钟）
1. 用 `StringBuilder` 的链式调用把 `["张三", "李四", "王五"]` 拼成 `"张三、李四、王五"`（最后一个后面不加顿号）。
2. 在 `StringUtils` 里再加一个 `maskEmail(String)`，把 `zhangsan@nous.com` 变成 `zh***@nous.com`。
3. 挑战：为什么 `StringBuilder` 没有实现 `equals`（默认用 Object 的）？—— 因为 `StringBuilder` 是\"缓冲区\"不是\"值\"，比较缓冲区没有意义。

#### 小结（2 分钟）
两句钉板：\"少量拼接用 `+`，循环里用 `StringBuilder`。工具类三件套：`final class + private ctor + static method`。\"

### 2.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 2 讲：StringBuilder + StringUtils                   │
│                                                        │
│ 1. 为什么需要：不可变导致循环 += 产生 2N 个临时对象    │
│                                                        │
│ 2. StringBuilder：可变缓冲区 + 扩容策略                │
│    append / insert / delete / reverse / replace        │
│    链式：return this;                                  │
│                                                        │
│ 3. Builder vs Buffer                                   │
│    Builder：默认选，不加锁，快                         │
│    Buffer： synchronized，几乎不用                     │
│                                                        │
│ 4. + vs Builder                                        │
│    简单：+                                             │
│    循环 / 边构造边判断：Builder                        │
│                                                        │
│ 5. 工具类三件套                                        │
│    final class + private ctor + static method          │
└────────────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. 用 `System.currentTimeMillis()` 分别测 `+`、`concat`、`StringBuilder` 拼接 10 万次的耗时，填表。
2. 给 `StringUtils` 加两个方法：`String join(List<String> parts, String sep)` 与 `String repeat(String s, int n)`。
3. 挑战题：`String.repeat(int)`（JDK 11+）是怎么实现的？让 AI 帮你反查一下源码并解释。

### 2.6 教学反思提示
- 性能对比一定要**现场跑**，学生看到 5ms vs 2500ms 的震撼是无可替代的。
- 工具类三件套是本节最重要的\"工程化观念\"，不要只讲 API。

---

## 第 3 课时：基本数据类型的包装类

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 说出 8 种基本类型对应的 8 种包装类，能拼写正确（`Byte / Short / Integer / Long / Float / Double / Character / Boolean`）。
2. 解释装箱、拆箱的机制，能读懂 `Integer i = 10;` 的字节码级含义（`Integer.valueOf(10)`）。
3. **理解 `Integer` 缓存陷阱**：`-128 ~ 127` 之间 `==` 返回 true，越界返回 false，并给出根因。
4. 熟练使用 `parseInt / valueOf / MAX_VALUE / MIN_VALUE`，以及 `Character.isDigit / isLetter / toLowerCase`。
5. 明白\"自动拆箱遇 `null` 抛 NPE\"，写出防御性判空。

#### 3.1.2 过程与方法目标
1. 用一个反直觉的\"127 vs 128\" 现场演示，让学生记住\"包装类比较永远用 `equals`\"。
2. 通过 \"从数据库拿数字\" 的场景引出 null 陷阱，让防御式编程落地。

### 3.2 教学重难点
- **重点**：装箱/拆箱的语法糖本质 / Integer 缓存池 / `parseInt` vs `valueOf` 的返回类型差别 / 拆箱 NPE
- **难点**：\"为什么 -128 到 127 特殊\"（JVM 缓存 + JLS 规定）

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接第 2 讲：\"我们讲了 `String` 是对象，可以放进集合。那 `int` 呢？\" 让学生尝试写：
```java
List<int> nums = new ArrayList<>();   // ❌ 编译错误
```
问：为什么不行？因为泛型只接受**引用类型**，`int` 不是。Java 为解决这个问题，为每种基本类型准备了一个\"对象版\"——包装类。

#### 新知讲授（18 分钟）

**（1）八对映射（3 分钟）**

| 基本类型 | 包装类 | 记忆点 |
|----------|--------|--------|
| `byte` | `Byte` | 首字母大写 |
| `short` | `Short` | 首字母大写 |
| `int` | **`Integer`** | 不是 `Int` |
| `long` | `Long` | 首字母大写 |
| `float` | `Float` | 首字母大写 |
| `double` | `Double` | 首字母大写 |
| `char` | **`Character`** | 不是 `Char` |
| `boolean` | `Boolean` | 首字母大写 |

**两个陷阱**：`int → Integer`（不是 Int），`char → Character`（不是 Char）。写错就编译不过。

**（2）装箱 / 拆箱（5 分钟）**
- **装箱**：基本 → 包装，`Integer i = Integer.valueOf(10);`
- **拆箱**：包装 → 基本，`int n = i.intValue();`

JDK 5 起**自动装箱 / 拆箱**：编译器加糖。
```java
Integer i = 10;      // 编译器补：Integer.valueOf(10)
int n = i + 5;       // 编译器补：i.intValue() + 5
List<Integer> list = new ArrayList<>();
list.add(1);         // 自动装箱
int x = list.get(0); // 自动拆箱
```

**（3）常用方法（4 分钟）**
以 `Integer` 为主：
```java
int n = Integer.parseInt("123");        // String → int
Integer boxed = Integer.valueOf(100);   // int → Integer
int primitive = boxed.intValue();       // Integer → int
int max = Integer.max(3, 5);            // 静态方法
String hex = Integer.toHexString(255);  // "ff"
int MAX = Integer.MAX_VALUE;            // 2^31 - 1
int MIN = Integer.MIN_VALUE;            // -2^31
```

**`parseInt` vs `valueOf` 的差别**：前者返回 `int`（基本），后者返回 `Integer`（包装）。**规则**：需要基本类型用 `parseXxx`，需要对象类型用 `valueOf`。

**`Character` 的判断方法**（写字符串题时会大量用）：
```java
Character.isDigit('5');     // true
Character.isLetter('A');    // true
Character.isWhitespace(' ');// true
Character.toLowerCase('A'); // 'a'
```

**（4）Integer 缓存陷阱（6 分钟）**——本讲最有\"表演性\"的地方
现场敲：
```java
Integer a = 127;
Integer b = 127;
System.out.println(a == b);   // true

Integer c = 128;
Integer d = 128;
System.out.println(c == d);   // false !!
```
让学生猜结果，绝大多数会说\"两个都 true\"。运行一次，反直觉的 `false` 打脸。

**根因**：`Integer.valueOf(int)` 内部：
```java
public static Integer valueOf(int i) {
    if (i >= IntegerCache.low && i <= IntegerCache.high)
        return IntegerCache.cache[i + (-IntegerCache.low)];
    return new Integer(i);
}
```
默认 low=-128, high=127，命中缓存返回同一对象；越界就 `new`。

**结论钉板**：**包装类比较用 `.equals()`，永远不用 `==`。**

#### 示例演示（12 分钟）

**示例 1：拆箱 NPE（4 分钟）**
```java
Map<String, Integer> scores = new HashMap<>();
scores.put("张三", 88);

Integer s = scores.get("李四");   // 不存在 → null
int score = s;                    // 💥 NullPointerException
```
在 Web 项目里，从数据库、JSON、Map 拿到的\"数字\"几乎都是**包装类**（因为可能是 `NULL`）。**规则**：**先判空，再拆箱**。
```java
int score = s == null ? 0 : s;   // 三目防御
// 或用 Optional / getOrDefault
int score2 = scores.getOrDefault("李四", 0);
```

**示例 2：String ↔ 基本类型小抄（4 分钟）**
```java
// String → 基本
int i = Integer.parseInt("123");
double d = Double.parseDouble("3.14");
boolean b = Boolean.parseBoolean("true");
long l = Long.parseLong("9999999999");

// 基本 → String
String s1 = String.valueOf(123);      // 最通用（能吞 null）
String s2 = Integer.toString(123);
String s3 = "" + 123;                 // 简单但会走 StringBuilder
```
**推荐**：`String.valueOf(x)`——它对 `null` 会返回 `"null"` 而不是抛 NPE。

**示例 3：完整跑一遍缓存实验（4 分钟）**
```java
public static void main(String[] args) {
    test(-129);
    test(-128);
    test(127);
    test(128);
}
static void test(int n) {
    Integer a = n;
    Integer b = n;
    System.out.printf("%5d: == %s  equals %s%n", n, a == b, a.equals(b));
}
```
输出：
```text
 -129: == false  equals true
 -128: == true   equals true
  127: == true   equals true
  128: == false  equals true
```
`equals` 全部正确，`==` 只在缓存范围内正确——这正是学生要记的一课。

#### 课堂练习（8 分钟）
1. 写代码验证：`Long a = 127L; Long b = 127L;` 的 `==` 结果。（`Long` 也有缓存）
2. 从 `Map<String, Integer>` 里取一个可能不存在的 key，安全地转成 `int`，默认 0。
3. 写一个 `boolean containsDigit(String s)`，判断字符串是否包含任何数字字符，只用 `Character.isDigit`。

#### 小结（2 分钟）
钉三条板书：\"包装类和基本类型的自动切换是编译期语法糖\"\"包装类比较永远用 `.equals()`\"\"拆箱前记得判空\"。

### 3.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 3 讲：包装类                                        │
│                                                        │
│ 1. 八对映射                                            │
│    int → Integer   char → Character                    │
│    其余首字母大写                                      │
│                                                        │
│ 2. 装箱 / 拆箱（JDK 5+ 自动）                          │
│    Integer i = 10;    → valueOf(10)                    │
│    int n = i + 5;     → i.intValue() + 5               │
│                                                        │
│ 3. 常用方法                                            │
│    Integer.parseInt("123") → int                       │
│    Integer.valueOf(100)    → Integer                   │
│    Character.isDigit / isLetter / toLowerCase          │
│                                                        │
│ 4. 陷阱                                                │
│    - 缓存池 -128 ~ 127：== 会给错觉                    │
│      → 永远用 equals()                                 │
│    - null 拆箱抛 NPE                                   │
│      → 先判空 / getOrDefault                           │
└────────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. 写代码测试 `Double a = 1.0; Double b = 1.0; a == b` 的结果，解释为什么和 `Integer` 不一样。（`Double` 无缓存池）
2. 实现 `int safeParseInt(String s, int defaultValue)`：能解析就返回，异常或 null 就返回默认值。
3. 挑战题：`Integer.valueOf` 的缓存边界能不能改？—— 提示：`-Djava.lang.Integer.IntegerCache.high=1000` 启动参数。

### 3.6 教学反思提示
- \"127 vs 128\" 的表演性演示是全讲的高潮，不要省。
- 若时间紧张，可跳过 `Long.valueOf` 也有缓存的旁枝，专注 Integer。

---

## 第 4 课时：ArrayList（含集合框架总览）

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 说出 Java 集合体系两大分支：`Collection`（`List / Set / Queue`）与 `Map`，并画出核心类的继承关系。
2. 掌握 `ArrayList` 的核心 API：`add / add(i,e) / get / set / remove / size / contains / indexOf / clear`。
3. 熟练使用三种遍历方式：`for-i` / 增强 for / `forEach + Lambda`。
4. **正确处理\"遍历时删除\"陷阱**：知道 `ConcurrentModificationException` 的成因，能用 `removeIf` 或 `Iterator.remove` 规避。
5. 简述 `ArrayList` 的底层：`Object[]` + 1.5 倍扩容 + 随机访问 O(1) / 中间插入 O(n)。

#### 4.1.2 过程与方法目标
1. 用\"定长数组 vs 动态数组\"的对比引入，让学生从旧知识（第 4 章数组）自然过渡。
2. 用一个\"边遍历边删除\"的翻车实验制造认知冲突，再引出正确写法。

### 4.2 教学重难点
- **重点**：`ArrayList` 常用 API / 三种遍历 / 遍历删除的正确写法 / 底层扩容原理
- **难点**：`fail-fast` 机制与 `ConcurrentModificationException` 的成因

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
上黑板写：
```java
int[] arr = new int[10];   // 定长
```
问：\"如果我不知道最终会有多少个元素，怎么办？\" 让学生说：\"再 new 一个大的，把老数组复制过去\"。**这就是 `ArrayList` 内部干的事**——它把\"手动扩容 + 挪元素\"封装好了，你只用 `add` 就行。

#### 新知讲授（18 分钟）

**（1）集合框架总览（4 分钟）**
黑板画一张继承树：
```text
       Iterable
          │
      Collection            Map
      ┌──┼──┐             ┌──┼──┐
     List Set Queue    HashMap  LinkedHashMap  TreeMap
    ┌──┴──┐  ┌──┴──┐
ArrayList  LinkedList  HashSet  LinkedHashSet  TreeSet
```
强调：
- `Collection`：单值容器。
- `Map`：键值对，**不在 `Collection` 里**。
- **本课程只讲 `ArrayList / HashMap / HashSet` 三个**——覆盖 90% 场景。

**（2）ArrayList 定义与创建（4 分钟）**
定义：**动态数组**，有序（按插入顺序）、可重复。
```java
ArrayList<String> list = new ArrayList<>();     // 具体类
List<String> list2 = new ArrayList<>();         // ✅ 推荐：接口引用
List<String> list3 = new ArrayList<>(20);       // 指定初始容量
```

**为什么推荐 `List<String> = new ArrayList<>()`**：面向接口编程——将来想换成 `LinkedList`，只改右边一行。

**（3）核心 API（6 分钟）**
| 方法 | 作用 | 返回 |
|------|------|------|
| `add(e)` | 尾部追加 | boolean |
| `add(i, e)` | 下标 i 插入 | void |
| `get(i)` | 取下标 i | E |
| `set(i, e)` | 修改下标 i，返回旧值 | E |
| `remove(int i)` | 按下标删 | E |
| `remove(Object o)` | 按对象删首个 | boolean |
| `size()` | 元素数 | int |
| `isEmpty()` | 是否空 | boolean |
| `contains(o)` | 是否含 | boolean |
| `indexOf(o)` | 首次下标，无返 -1 | int |
| `clear()` | 清空 | void |

**易混点**：`remove(int)` 和 `remove(Object)` 是**方法重载**。当 `List<Integer>` 时：
```java
List<Integer> l = new ArrayList<>(List.of(10, 20, 30));
l.remove(1);              // 删下标 1 → 剩 [10, 30]
l.remove(Integer.valueOf(10)); // 删对象 10 → 剩 [30]
```
写 `l.remove(10)` 时被识别为**按下标 10**（越界抛异常），这是笔试常考点。

**（4）三种遍历（4 分钟）**
```java
// 1. for-i：需要下标或反向遍历时用
for (int i = 0; i < list.size(); i++) System.out.println(list.get(i));

// 2. 增强 for：最常见
for (String s : list) System.out.println(s);

// 3. forEach + 方法引用（JDK 8+）
list.forEach(System.out::println);
```

#### 示例演示（12 分钟）

**示例 1：CRUD 演示（4 分钟）**
```java
List<String> names = new ArrayList<>();
names.add("张三");
names.add("李四");
names.add("王五");
names.add(1, "赵六");          // [张三, 赵六, 李四, 王五]
names.set(0, "张三三");        // [张三三, 赵六, 李四, 王五]
names.remove("李四");          // [张三三, 赵六, 王五]
System.out.println(names.size());  // 3
System.out.println(names);
```

**示例 2：遍历时删除的翻车与修复（6 分钟）**——本讲最重要

**错误 1：增强 for 里删**
```java
List<String> names = new ArrayList<>(List.of("张三", "李四", "张三丰"));
for (String n : names) {
    if (n.startsWith("张")) names.remove(n);   // 💥 ConcurrentModificationException
}
```
根因：增强 for 底层是 `Iterator`，`Iterator` 有一个 `modCount` 快照，`list.remove` 直接改了 modCount，下一次 `hasNext()` 检测到不一致就抛异常（**fail-fast** 机制）。

**错误 2：for-i 里正着删**
```java
for (int i = 0; i < names.size(); i++) {
    if (names.get(i).startsWith("张")) names.remove(i);
}
```
不会抛异常，但会**漏删**——删了第 i 个，第 i+1 个变成新的第 i 个，但下一轮循环 i++ 跳过去了。

**修复法 1：JDK 8+ 首选 `removeIf`**
```java
names.removeIf(n -> n.startsWith("张"));   // 一行搞定
```

**修复法 2：显式 `Iterator`**
```java
Iterator<String> it = names.iterator();
while (it.hasNext()) {
    if (it.next().startsWith("张")) it.remove();  // ✅ 用 Iterator 自己的 remove
}
```

**修复法 3：从后往前 for-i**
```java
for (int i = names.size() - 1; i >= 0; i--) {
    if (names.get(i).startsWith("张")) names.remove(i);
}
```

**示例 3：底层原理小抄（2 分钟）**
- 默认初始容量 10（首次 `add` 时才真正分配）。
- 满了扩为原容量的 **1.5 倍**（`oldCapacity + (oldCapacity >> 1)`）。
- `get(i)` 平均 O(1)，`add(0, e)` 平均 O(n)（要挪 n 个）。

#### 课堂练习（8 分钟）
1. 用 `ArrayList<Integer>` 存放 1—10，删除所有偶数，正确写法两种以上。
2. 判断一个 `List<String>` 是否有重复元素（提示：`HashSet` 的 `add` 返回 false 说明重复，但本讲还没讲 Set，先用 `contains` 双层循环）。
3. 挑战：为什么 `new ArrayList<>(1000)` 比 `new ArrayList<>()` 后 add 1000 次更快？——因为省了扩容次数。

#### 小结（2 分钟）
钉板：\"ArrayList 是动态数组，`get` 快、`add(i)` 慢；遍历删除用 `removeIf` 或 `Iterator.remove`。\"

### 4.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 4 讲：ArrayList                                     │
│                                                        │
│ 1. 集合体系                                            │
│    Collection: List / Set / Queue                      │
│    Map（独立）                                         │
│                                                        │
│ 2. ArrayList 定义                                      │
│    动态数组，有序、可重复                              │
│    List<T> l = new ArrayList<>();                      │
│                                                        │
│ 3. 核心 API                                            │
│    add(e) / get(i) / set(i,e) / remove(i)              │
│    remove(Object) / size / contains / indexOf          │
│                                                        │
│ 4. 遍历三种：for-i / for-each / forEach                │
│                                                        │
│ 5. 遍历删除                                            │
│    增强 for 里 remove → CME                            │
│    removeIf(Predicate) —— 首选                         │
│    Iterator.remove()                                   │
│    倒序 for-i                                          │
│                                                        │
│ 6. 底层：Object[] + 1.5 倍扩容                         │
└────────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. 用 `ArrayList<Student>`（复用 Day04 的 `Student`）实现\"添加、按索引删、按学号查\"三个功能。
2. 给 `List<Integer>`，返回一个新 `List<Integer>`，只包含大于平均值的元素。
3. 挑战题：查阅 JDK 25 的 `ArrayList` 源码，找到 `grow` 方法，把扩容代码抄下来。

### 4.6 教学反思提示
- 遍历删除的 3 个错误写法一定要**都演示一遍**，让学生亲眼见到 CME 才有印象。
- \"面向接口编程\"这个观念第一次出现，稍多讲一句，为将来 Spring 依赖注入埋伏笔。

---

## 第 5 课时：HashMap + HashSet（含 StudentSystemV2 综合案例）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 说出 `HashMap` 的存储模型：\"键 → 值\"，键不重复、值可重复、都可为 null。
2. 熟练使用 `put / get / getOrDefault / containsKey / remove / keySet / values / entrySet / forEach`。
3. 掌握三种遍历方式，能选对最合适的（**entrySet 性能最好**）。
4. 说出 `HashSet` 是\"底层就是一个 `HashMap`\"，重点用于**去重**与\"存在性判断 O(1)\"。
5. 能用 `Map<String, Student>` 重写 Day04 的学生管理系统（`StudentSystemV2`），感受面向对象 + 集合的组合威力。

#### 5.1.2 过程与方法目标
1. 用\"词频统计\"这一 Java 面试常青树案例，把 `getOrDefault` 用起来。
2. 用 `StudentSystemV2` 作为 12 章综合案例，把\"类 + 集合\"这条主线贯通。

### 5.2 教学重难点
- **重点**：`put / get / getOrDefault` / 三种遍历 / `HashSet` 去重与 `contains` O(1) / `Map<String, Student>` 建模思维
- **难点**：\"HashMap 的 key 必须重写 equals 和 hashCode\" / 底层数组 + 链表 / 红黑树结构

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接第 4 讲：\"我们能用 `ArrayList<Student>` 存学生了，但查\'学号 202501\'的学生要**遍历整个 list**，O(n)。当学生变成 10 万人时怎么办？\" 学生大概率答\"排序 + 二分\"。反问：\"如果学号是字符串呢？\" 引出：**用哈希表——键映射值，查找 O(1)**。

#### 新知讲授（18 分钟）

**（1）HashMap 定义与创建（3 分钟）**
```java
Map<String, Integer> scores = new HashMap<>();
scores.put("张三", 88);
scores.put("李四", 92);
scores.put("王五", 76);
scores.put("张三", 100);   // key 已存在 → 覆盖，返回旧值 88
```
特点：键**不可重复**（重复即覆盖），值可重复，键和值都可 null（`HashMap` 允许一个 null key）。

**（2）核心 API（6 分钟）**
| 方法 | 作用 | 返回 |
|------|------|------|
| `put(k, v)` | 加 / 覆盖 | 旧 v（无则 null） |
| `get(k)` | 取 v | v 或 null |
| `getOrDefault(k, dv)` | 取 v，无则 dv | v 或 dv |
| `containsKey(k)` | 是否含键 | boolean |
| `containsValue(v)` | 是否含值 O(n) | boolean |
| `remove(k)` | 删除，返旧 v | v 或 null |
| `size()` | 数量 | int |
| `keySet()` | 所有键 | `Set<K>` |
| `values()` | 所有值 | `Collection<V>` |
| `entrySet()` | 所有键值对 | `Set<Entry<K,V>>` |
| `putIfAbsent(k, v)` | 键不在时 put | 旧 v 或 null |
| `computeIfAbsent(k, fn)` | 键不在时用 fn 算 v | 计算后 v |

**（3）三种遍历（4 分钟）**
```java
// 1. 遍历 key
for (String k : scores.keySet()) {
    System.out.println(k + " → " + scores.get(k));  // 每次 get 又要哈希一次
}

// 2. 遍历 entry（推荐，一次哈希）
for (Map.Entry<String, Integer> e : scores.entrySet()) {
    System.out.println(e.getKey() + " → " + e.getValue());
}

// 3. forEach + Lambda（JDK 8+，最简洁）
scores.forEach((k, v) -> System.out.println(k + " → " + v));
```

**性能提示**：只要用到 value，就用 `entrySet` 或 `forEach`；只用 key 才用 `keySet`。

**（4）HashSet 的秘密（3 分钟）**
翻开 JDK 源码提一句：`HashSet` 内部有一个 `private transient HashMap<E,Object> map;`——它就是把值当 key 存进 map，value 用一个静态占位对象。所以 `HashSet` 的所有性能特性都跟 `HashMap` 一样。

```java
Set<String> set = new HashSet<>();
set.add("张三");
set.add("李四");
set.add("张三");    // 重复，静默忽略（add 返回 false）
System.out.println(set.size());   // 2
```
用途：**去重** + **O(1) 存在性判断**。

**（5）底层原理（2 分钟）**
- 数组 + 链表 + 红黑树（JDK 8+）
- `put` 时：`hashCode → (n-1) & hash → 桶下标`
- 单个桶里链表长度 > 8 且数组长度 ≥ 64 时链表转红黑树，查找从 O(n) 降到 O(log n)
- 负载因子 0.75 → 触发扩容（2 倍）

**key 要求**：必须**同时**重写 `equals` 与 `hashCode`。`equals` 相等的两个对象 `hashCode` 必须相等；反过来不一定成立。建议用**不可变**类做 key：`String / Integer / record`。

#### 示例演示（14 分钟）

**示例 1：词频统计（4 分钟）**
```java
String text = "the quick brown fox jumps over the lazy dog the fox";
Map<String, Integer> freq = new HashMap<>();
for (String w : text.split("\\s+")) {
    freq.put(w, freq.getOrDefault(w, 0) + 1);
}
freq.forEach((k, v) -> System.out.println(k + " = " + v));
```
输出（顺序不保证）：
```text
the = 3
fox = 2
dog = 1
...
```
说明 `getOrDefault(k, 0) + 1` 的惯用写法：**\"取不到当 0，然后 +1 再放回去\"**。这一行是词频统计的标准解法。

**变式**（用 `merge` 一行搞定）：
```java
freq.merge(w, 1, Integer::sum);
```

**示例 2：HashSet 去重（3 分钟）**
```java
List<Integer> nums = List.of(1, 2, 3, 2, 4, 1, 5);
Set<Integer> distinct = new HashSet<>(nums);
System.out.println(distinct);   // [1, 2, 3, 4, 5]（顺序不保证）
```
若要**保持插入顺序**去重，用 `LinkedHashSet`：
```java
Set<Integer> ordered = new LinkedHashSet<>(nums);   // [1, 2, 3, 4, 5]
```

**示例 3：StudentSystemV2 综合案例（7 分钟）**
把教材 12.6 的完整代码敲进 IDE，重点讲**三个升级点**：

```java
static Map<String, Student> db = new LinkedHashMap<>();   // key=学号

static void addStudent() {
    String id = sc.next();
    if (db.containsKey(id)) { System.out.println("学号已存在。"); return; }
    // ...
    db.put(id, new Student(id, name, age, score));
}

static void findStudent() {
    Student s = db.get(id);       // O(1) 查找
    if (s == null) { ... return; }
    s.printInfo();
}

static void deleteStudent() {
    if (db.remove(id) != null) System.out.println("删除成功。");
    else System.out.println("未找到。");
}
```

**对比 Day04 的数组版**：

| 操作 | Day04 数组版 | Day06 Map 版 |
|------|-------------|--------------|
| 添加 | 需要判满 + 扩容 | `db.put` |
| 查找 | for 循环遍历 O(n) | `db.get` O(1) |
| 删除 | 手动挪数组 O(n) | `db.remove` |
| 字段增删 | 改 4 个平行数组 | 只改 `Student` 类 |
| 代码行数 | ~200 | ~100 |

**这就是\"面向对象 + 集合\"的威力。** 学生此刻应该产生\"哇，原来可以这么简洁\" 的顿悟——这是 Day01 到 Day06 六天磨这一刀的时刻。

#### 课堂练习（8 分钟）
1. 用 `HashMap<String, Integer>` 统计一段字符串中每个字母出现次数（不区分大小写）。
2. 给 `List<String> names`，用 `HashSet` 判断是否有重复元素，一行代码。
3. 把 `StudentSystemV2` 的 `printStats` 方法加一个\"最高分学生的姓名\"输出。

#### 小结（2 分钟）
钉板：\"HashMap 是键值对，键不重复；`getOrDefault` 是词频统计三件套；HashSet 底层是 HashMap，用来去重和 O(1) 判存在；用 `Map<学号, Student>` 建模，让代码脱胎换骨。\"

### 5.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 5 讲：HashMap + HashSet                             │
│                                                        │
│ 1. HashMap                                             │
│    Map<K, V>，key 不重复，get O(1)                     │
│    put/get/getOrDefault/remove/containsKey             │
│    keySet/values/entrySet                              │
│                                                        │
│ 2. 遍历三种                                            │
│    keySet → 只需 key 时                                │
│    entrySet → 一次哈希                                 │
│    forEach((k,v) -> …) → 最简                          │
│                                                        │
│ 3. 词频统计惯用写法                                    │
│    map.put(w, map.getOrDefault(w, 0) + 1);             │
│    map.merge(w, 1, Integer::sum);                      │
│                                                        │
│ 4. HashSet：底层就是 HashMap                           │
│    add 返回 false 即重复                               │
│    用途：去重 / O(1) 存在性                            │
│                                                        │
│ 5. StudentSystemV2                                     │
│    Map<String, Student> db                             │
│    查找 O(1)、删除不挪数组                             │
│                                                        │
│ 6. 底层：数组 + 链表 + 红黑树 (JDK 8+)                 │
│    key 必须重写 equals + hashCode                      │
└────────────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. 词频统计升级版：读入教材第 1 章的一段英文文本，输出前 10 个高频词。
2. 给两个 `List<Integer>`，输出它们的**并集**（`addAll`）与**交集**（`retainAll`），用 `HashSet` 实现。
3. 把 `StudentSystemV2` 加两个功能：\"按成绩排序展示\"、\"按姓氏搜索\"（提示：`db.values().stream().sorted(...)`）。
4. 挑战：读一遍 JDK 25 的 `HashMap.put` 源码，画出\"计算 hash → 找桶 → 处理链表\"三步流程图。

### 5.6 教学反思提示
- `StudentSystemV2` 是**六天课程的高潮时刻**，要留够时间让学生对比\"数组版 vs 集合版\"的行数与可读性，不要匆匆略过。
- 底层原理不用讲深，把\"数组 + 链表 + 红黑树\"这一句话打进学生脑子即可，深追是 Day07 之后的事。

---

## 第 6 课时：泛型的基本使用（全课程收官讲）

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 说出泛型的三大价值：**编译期类型检查**、**自动类型推断**、**代码复用**。
2. 会写泛型类 `Box<T>`、泛型方法 `<T> T firstOrNull(List<T>)`、泛型接口 `Comparator<T>`。
3. 认识常见的类型参数命名习惯：`T / E / K / V / R / N`。
4. 简要理解通配符：`<?>` / `<? extends Number>` / `<? super Integer>`（了解即可，不深挖）。
5. 知道\"泛型编译期擦除\"这一 JDK 设计权衡，理解\"运行时 `List<String>` 和 `List<Integer>` 是同一个类\"。
6. **完成全课程知识体系回顾**：能画出 12 章知识点的主线图，说出后续学习路线。

#### 6.1.2 过程与方法目标
1. 用\"没有泛型的世界\"（JDK 5 之前）反向证明泛型的必要性。
2. 收官讲要有\"仪式感\"：完整回顾 Day01—Day06 全课程知识主线，给出明确的下一步学习路径（异常/IO → Lambda/Stream → 多线程 → JDBC → Spring Boot → Spring AI）。

### 6.2 教学重难点
- **重点**：泛型类 / 泛型方法 / 泛型接口的语法 / \"提前把错误从运行期变成编译期\"的价值
- **难点**：类型擦除的含义与副作用（`new T()` 不行、`instanceof T` 不行）

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
翻回第 4 讲开头的 `List<String> = new ArrayList<>();` 那一行，问：\"这里的尖括号是干什么的？把它删掉会怎么样？\" 现场演示：
```java
List list = new ArrayList();
list.add("hello");
list.add(123);           // 编译不报错
String s = (String) list.get(1);   // 💥 ClassCastException
```
**这是 JDK 5 之前 Java 集合的常态**——因为没有泛型，写代码等于在钢丝上跳舞。今天讲的\"尖括号\" 就是 Java 世界最伟大的语法糖之一。

#### 新知讲授（18 分钟）

**（1）泛型的价值（3 分钟）**
在黑板画一张对比表：

| 场景 | 没有泛型 | 有泛型 |
|------|----------|--------|
| 添加错类型 | 运行期崩 | **编译报错** |
| 取出元素 | 强转 `(String)` | 编译器自动推断 |
| 代码复用 | 每个类型写一份 | 一个泛型类通吃 |

**结论**：泛型把\"运行期崩\"提前到了\"编译期红波浪线\"——**一次质的飞跃**。

**（2）泛型类（5 分钟）**
```java
public class Box<T> {
    private T value;
    public void set(T v) { this.value = v; }
    public T get() { return value; }
}

Box<String> b1 = new Box<>();
b1.set("hi");
String s = b1.get();

Box<Integer> b2 = new Box<>();
b2.set(123);
int n = b2.get();     // 自动拆箱
```
`T` 只是一个**占位符**，用的时候把它替换成具体类型。同一个 `Box` 类，能装 `String` 也能装 `Integer`——这就是\"参数化类型\"。

**类型参数命名约定**：

| 字母 | 含义 |
|------|------|
| `T` | Type，任意类型 |
| `E` | Element，元素（集合里最常见） |
| `K, V` | Key, Value（Map） |
| `R` | Return，返回值 |
| `N` | Number，数值 |

**（3）泛型方法（4 分钟）**
方法自己声明类型参数：
```java
public class Utils {
    public static <T> T firstOrNull(List<T> list) {
        return list.isEmpty() ? null : list.get(0);
    }
}

String first = Utils.firstOrNull(List.of("a", "b"));   // T=String
Integer n = Utils.firstOrNull(List.of(1, 2, 3));       // T=Integer
```
**关键**：方法名前的 `<T>` 是\"声明类型参数\"（等价于函数参数列表里的 `int x`）；返回值 `T` 是\"使用类型参数\"。

**（4）泛型接口（3 分钟）**
`Comparator<T>` 是 Java 里最常见的泛型接口：
```java
public interface Comparator<T> {
    int compare(T a, T b);
}

public class ByAgeComparator implements Comparator<Student> {
    public int compare(Student a, Student b) {
        return Integer.compare(a.getAge(), b.getAge());
    }
}
```
用途：`list.sort(new ByAgeComparator())` 让 `List<Student>` 按年龄升序。

**（5）通配符（了解即可，3 分钟）**
```java
List<?>              // 未知类型，只能读，不能写（null 除外）
List<? extends Number>   // Number 或子类：Integer / Double / Long
List<? super Integer>    // Integer 或父类：Integer / Number / Object
```
记忆口诀：**PECS**（**P**roducer **E**xtends, **C**onsumer **S**uper）——**取出用 extends，放入用 super**。初学阶段先掌握\"泛型参数是什么类型，容器就只能放什么类型\"就够了。

#### 示例演示（10 分钟）

**示例 1：写一个通用容器（4 分钟）**
```java
public class Pair<K, V> {
    private final K key;
    private final V value;
    public Pair(K k, V v) { this.key = k; this.value = v; }
    public K getKey() { return key; }
    public V getValue() { return value; }
    @Override
    public String toString() { return "(" + key + ", " + value + ")"; }
}

Pair<String, Integer> p1 = new Pair<>("张三", 88);
Pair<Integer, String> p2 = new Pair<>(1, "冠军");
System.out.println(p1);   // (张三, 88)
System.out.println(p2);   // (1, 冠军)
```

**示例 2：泛型方法通吃（3 分钟）**
```java
public class Utils {
    public static <T> T last(List<T> list) {
        return list.isEmpty() ? null : list.get(list.size() - 1);
    }
}

String s = Utils.last(List.of("a", "b", "c"));   // "c"
Integer n = Utils.last(List.of(1, 2, 3));         // 3
Student stu = Utils.last(students);
```
一个方法，通吃所有类型——泛型的复用威力。

**示例 3：类型擦除的证据（3 分钟）**
```java
List<String> ls = new ArrayList<>();
List<Integer> li = new ArrayList<>();
System.out.println(ls.getClass() == li.getClass());   // true !!
```
`ls` 和 `li` 在运行时**是同一个类** `java.util.ArrayList`——泛型信息只存在于编译期，编译后被\"擦除\"。副作用：
- 不能 `new T()`（编译器不知道 T 是啥）。
- 不能 `if (obj instanceof T)`。
- 不能创建泛型数组 `new T[10]`。

日常开发只需要知道有这回事，不影响使用。

#### 收官时刻：全课程主线回顾（10 分钟）

**⭐ 这是全课程六天的最后 10 分钟，务必留足时间。**

上黑板画一张\"12 章主线图\"：

```text
Day01：语法奠基
   1. Java 与开发环境
   2. 变量、常量、数据类型
   3. 运算符与表达式
   4. 流程控制

Day02：数据结构与方法
   5. 数组
   6. 方法与递归

Day03：面向对象核心
   7. 类与对象、封装、构造器
   8. 继承、多态、Object

Day04：面向对象进阶
   9. 抽象类与模板方法
  10. 接口、枚举、Record

Day05：数据库交互（如已排入课表）
   （复习 + 项目实训）

Day06：常用类库与集合
  11. String、StringBuilder、包装类
  12. ArrayList、HashMap、HashSet、泛型 ← 你在这里
```

**核心知识点**逐一点名（快速念一遍：字面量、常量池、intern、equals vs ==、StringBuilder、valueOf、缓存池、ArrayList、扩容、fail-fast、removeIf、HashMap、getOrDefault、entrySet、HashSet 去重、泛型类、泛型方法、类型擦除……）。

**接下来的学习路径**（用教材 12.8 的六段式列出）：

1. **异常处理与 IO**：`try-catch-finally`、`Files`、`BufferedReader`
2. **Lambda 与 Stream API**：函数式编程入口，代码量减半
3. **多线程与并发**：`Thread`、`ExecutorService`、`CompletableFuture`
4. **数据库 JDBC**：连接 MySQL、执行 SQL、连接池
5. **Spring Boot / SSM 框架**：企业级 Web 应用开发
6. **Java 与 AI**：LangChain4j、Spring AI，用 Java 调用大模型 API

**赠言**：\"Java 世界很大，我们只走了一小步——但这一小步足够扎实。祝你在 Java 世界越走越远！\"

#### 课堂练习（3 分钟）
1. 写一个泛型方法 `<T> T last(List<T> list)`，返回最后一个元素，空列表返回 null。
2. 写一个泛型类 `Stack<E>`：`push(E) / pop() / peek() / isEmpty()`（内部用 `ArrayList<E>`）。

#### 小结（1 分钟）
一句话钉板：\"泛型把类型错误从运行期提前到编译期，代价是运行时会擦除类型。日常写业务代码，看到 `<>` 会用就够了。\"

### 6.4 板书设计
```text
┌────────────────────────────────────────────────────────┐
│ 第 6 讲：泛型基础 —— 全课程收官                        │
│                                                        │
│ 1. 泛型的价值                                          │
│    编译期检查 / 类型推断 / 代码复用                    │
│                                                        │
│ 2. 泛型类：public class Box<T> { T value; }            │
│                                                        │
│ 3. 泛型方法：public static <T> T last(List<T> l)       │
│                                                        │
│ 4. 泛型接口：Comparator<T>                             │
│                                                        │
│ 5. 通配符 (了解)                                       │
│    <?> / <? extends N> / <? super I>                   │
│                                                        │
│ 6. 类型擦除                                            │
│    List<String> 与 List<Integer> 运行时同类            │
│    → 不能 new T() / instanceof T                       │
│                                                        │
│ ─────────── 全课程 37 技术点主线 ───────────           │
│  语法 → OOP → 抽象/接口/枚举 → String → 集合 → 泛型    │
│                                                        │
│  下一站：异常/IO → Stream → 并发 → JDBC → Spring Boot  │
└────────────────────────────────────────────────────────┘
```

### 6.5 课后作业（Day06 汇总 + 全课程综合实验）

**Day06 必做（本日汇总）：**
1. 完成第 1—5 讲末尾的所有\"课后作业\"（约 12 题）。
2. 写一个泛型类 `Pair<K, V>`，支持 `getKey / getValue / toString`。
3. 写一个泛型方法 `<T> List<T> filter(List<T> list, Predicate<T> p)`，返回满足条件的元素子表（可 `for` + 判断实现）。

**全课程综合实验（选做，2 选 1）：**

- **综合实验 A：完整版学生管理系统**
  - 用 `Map<String, Student>` 建模，`Student` 用 `record` 或普通类。
  - 实现 CRUD + 按成绩排序 + 词频式统计（成绩段人数）。
  - 抽象出 `Storage` 接口，允许将来切换到文件存储。
  - 用 `StringUtils` 处理输入格式化（学号补零、姓名 trim）。
  - 用 `HashSet` 校验\"学号唯一\"。

- **综合实验 B：AI 词频分析器**
  - 输入一段英文文本（可从教材第 1 章拷贝）。
  - 用 `HashMap<String, Integer>` 统计词频。
  - 用 `List<Map.Entry<String, Integer>>` 排序后输出前 20 名。
  - 用 `StringUtils` 处理标点、大小写、空白。
  - 让 AI（Claude / 通义灵码 / Trae）帮你把它包装成一个\"文本分析器\"命令行工具。

### 6.6 教学反思提示
- 收官讲**必须留足 10 分钟做全课程回顾**，不要被泛型细节挤占——那张\"主线图\"是学生带走的最珍贵的东西。
- 类型擦除只讲现象，不要展开桥接方法、`Class<T>` 反射之类——那是高级话题。
- 最后的\"赠言\"环节可以让学生自己说一句\"这六天最大的收获\"，五句话内即可，为课程画一个温度感的句号。

---

**本课程正式完结。**

Java 12 章核心知识点，从 `Hello, World` 到 `Map<String, Student>`，从 `if-else` 到泛型类型擦除——六天走完。愿每一位学生带着这份骨架，走进异常处理、Stream、并发、JDBC、Spring Boot 与 AI 的下一站。

**祝你在 Java 世界越走越远！**
