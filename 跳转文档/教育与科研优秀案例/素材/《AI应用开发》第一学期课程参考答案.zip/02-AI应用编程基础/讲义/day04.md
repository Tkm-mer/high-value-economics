# AI 应用编程基础——Java 基础 - 学生讲义（Day04：类与对象 / 封装 / 构造方法 / 继承 / this·super / Object 类）

**总课时：6 讲**
**基线版本：** JDK 25 LTS · IntelliJ IDEA 2026.1
**适用对象：** 已完成 Day01—Day03 面向过程语法学习的 Java 初学者
**对应教材：** 第 7 章《类与对象、封装、构造方法》 + 第 8 章《继承、this / super、Object 类》

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 面向对象思想 + 类与对象 | 建立 "类 = 图纸 / 对象 = 房子" 心智模型；能写出第一个类并 `new` 出对象 |
| 第 2 讲 | 封装 | 掌握 `private` + `getter/setter` 黄金写法，能在 `setter` 中写校验 |
| 第 3 讲 | 构造方法 | 掌握无参 / 全参 / 重载 / `this(...)` 复用；识别 "带参构造覆盖默认无参" 的坑 |
| 第 4 讲 | 继承 + 方法重写 | 用 `extends` 复用父类字段方法；用 `@Override` 安全重写 |
| 第 5 讲 | this 与 super 关键字 | 理解 "两个视角" 的心智模型；掌握子类构造第一行的默认规则 |
| 第 6 讲 | Object 类常用方法 | 规范重写 `toString / equals / hashCode`，明白 "为什么必须成对" |

---

## 第 1 讲：面向对象思想 + 类与对象

### 1.1 引入：一个 "痛点问题"（5 分钟）

【口播】上节课我们用 Day03 的四个平行数组管理 50 个学生：`ids / names / ages / scores`。当时觉得挺顺畅——直到 **需求变了**：教务处说，"学生要加一个手机号字段"。

【板书】把问题写在黑板上：
```text
需求变更：Student 加一个 phone 字段。
Day03 方案要改多少地方？
   ① 加一个 String[] phones = new String[50];
   ② 添加学生的方法多一个 phones[i] = ...
   ③ 查找、修改、删除方法都要动
   ④ 展示方法要多打一行 phones[i]
```

改一处字段，全代码都要动 —— 这就是 **面向过程** 的痛点：数据是散的，方法是散的，改一处牵动全身。

我们今天要学的 **面向对象**，就是把 "**属于同一个东西的数据和行为**" 打包在一起 —— 学生的身份证号、姓名、年龄、成绩，就该属于 **同一个 `Student` 对象**；添加、查找、修改，就该是这个对象的 **方法**。这样以后要加字段，**只动 `Student` 类里的一处**。

好，我们正式开始今天的旅程。

### 1.2 面向过程 vs 面向对象：两种思维方式（8 分钟）

【口播】说到 "面向对象"，你可能觉得抽象。别急，我们先来对比一下 **两种解题思维**。

**场景**：把大象放进冰箱。

**面向过程思维（想 "怎么做"）**：
```text
1. 打开冰箱门
2. 把大象塞进去
3. 关上冰箱门
```
每一步都是一个 **函数**，函数之间靠调用顺序串起来。

**面向对象思维（想 "谁来做"）**：
```text
冰箱.开门()
冰箱.装入(大象)
冰箱.关门()
```
"冰箱" 是一个对象，"开门 / 装入 / 关门" 是它的 **方法**。你不再关心 "怎么做"，只关心 "**谁来做这件事**"。

【板书】画两栏对比表：

| 面向过程 | 面向对象 |
|----------|----------|
| 想 "怎么做" | 想 "谁来做" |
| 一堆函数 + 一堆数据分散在各处 | 数据和操作数据的方法 **封装** 在一起 |
| 修改数据结构，很多函数都要改 | 修改类内部实现，外部通常不受影响 |
| C 语言、早期 Java Util 风格 | Java、C++、Python、Kotlin 都是这个范式 |

【口播】反复强化一句话：**面向对象的核心是先找 "动作的执行者"，再把动作定义为它的方法**。以后你写代码之前，先问自己：**"谁在做这件事？"** —— 找到了，就把它建成类。

#### 面向对象的三大特性（先给结论，后面慢慢展开）

【板书】写下三个关键词：

- **封装**：数据私有、行为公开（第 2 讲讲）；
- **继承**：子类白捡父类的字段和方法（第 4 讲讲）；
- **多态**：同一个方法调用、不同对象表现不同（Day05 讲）。

今天上午三讲讲 "封装"，下午三讲讲 "继承"，明天讲 "多态"。三大特性齐了，Java 面向对象的地基就打稳了。

### 1.3 核心概念：类与对象（8 分钟）

【口播】现在给出 Java 面向对象的两个最核心的名词：**类（Class）** 和 **对象（Object）**。

【板书】黄金类比：

```text
类（Class）  = 图纸 / 蓝图
对象（Object）= 按图纸造出来的房子（实例）
```

**图纸只有一份，房子可以造很多栋**。图纸描述了 "房子有几个房间、每间多大、门在哪儿"；每栋房子按图纸建，但各自独立存在 —— 你搬进 A 栋，不会影响 B 栋。

再举一个更贴近编程的例子：

- **类 `Student`**：描述 "一个学生有 `id / name / age / score` 四个属性，能 `study` 和 `printInfo`"；
- **对象 `s1 = new Student()`**：按 `Student` 图纸造出来的一个具体学生，可以给它 `id = "2026001"、name = "张三"`；
- **对象 `s2 = new Student()`**：又造一个，`id = "2026002"、name = "李四"`。

`s1` 和 `s2` 是两个 **独立的对象**，各自占一块内存、各自的字段值互不干扰。

#### 类的定义语法

【板书】写下最小骨架：
```java
public class 类名 {
    // 成员变量（字段 / field）：描述 "有什么"
    数据类型 字段名;

    // 成员方法（method）：描述 "能做什么"
    修饰符 返回类型 方法名(参数列表) {
        方法体;
    }
}
```

【口播】记住两条：
- **成员变量** 描述 "**这个对象有什么**"（属性）；
- **成员方法** 描述 "**这个对象能做什么**"（行为）。

#### 对象的创建：`new` 关键字

【板书】三步走：
```java
类名 变量名 = new 类名();
变量名.字段名 = 值;
变量名.方法名();
```

`new` 干了三件事：
1. 在 **堆内存** 里开辟一块空间，按类的图纸摆好所有字段；
2. 给字段赋 **默认值**（`int→0`、`double→0.0`、`boolean→false`、引用类型→`null`）；
3. 返回这块内存的 **地址**，赋给栈上的变量。

### 1.4 第一个类：`Student`（10 分钟）

【口播】理论说得再多不如现场写一遍。打开 IDEA，新建一个类 `Student.java`。

```java
public class Student {
    // 成员变量（字段）
    String id;
    String name;
    int age;
    double score;

    // 成员方法（行为）
    public void study() {
        System.out.println(name + " 正在学习 Java...");
    }

    public void printInfo() {
        System.out.println("学号：" + id);
        System.out.println("姓名：" + name);
        System.out.println("年龄：" + age);
        System.out.println("成绩：" + score);
    }
}
```

【板书】划重点：
1. 类名 **首字母大写**（大驼峰），文件名 **必须与类名相同**（`Student.java`）；
2. 字段暂时不加修饰符 —— 下一讲我们会全部改成 `private`；
3. 方法里可以直接用字段名（`name`、`id`）—— 因为方法运行时 "属于某个对象"，字段就是这个对象自己的。

再写一个测试类 `StudentTest.java`：

```java
public class StudentTest {
    public static void main(String[] args) {
        // 创建第一个对象
        Student s1 = new Student();
        s1.id = "2026001";
        s1.name = "张三";
        s1.age = 20;
        s1.score = 88.5;
        s1.printInfo();
        s1.study();

        System.out.println("----------");

        // 创建第二个对象
        Student s2 = new Student();
        s2.id = "2026002";
        s2.name = "李四";
        s2.age = 21;
        s2.score = 92;
        s2.printInfo();
        s2.study();
    }
}
```

**运行输出**：
```text
学号：2026001
姓名：张三
年龄：20
成绩：88.5
张三 正在学习 Java...
----------
学号：2026002
姓名：李四
年龄：21
成绩：92.0
李四 正在学习 Java...
```

【口播】看，`s1` 和 `s2` 是两个 **各自独立** 的对象——`s1.name` 是 "张三"，`s2.name` 是 "李四"，改一个不影响另一个。这就是 "对象封装了自己的数据"。

### 1.5 内存图：栈 vs 堆（8 分钟）

【口播】现在讲一个 **超级重要** 的知识点：`new` 出来的对象到底在哪儿？

【板书】画 Mermaid 内存图：

```mermaid
flowchart LR
    subgraph 栈["栈（每个线程一个，方法调用相关）"]
        s1["s1<br/>地址 0x100"]
        s2["s2<br/>地址 0x200"]
    end
    subgraph 堆["堆（全线程共享，new 出来的对象放这里）"]
        O1["Student #1<br/>id=2026001<br/>name=张三<br/>age=20<br/>score=88.5"]
        O2["Student #2<br/>id=2026002<br/>name=李四<br/>age=21<br/>score=92"]
    end
    s1 --> O1
    s2 --> O2
```

【口播】三条铁律：

1. **`s1` 这个变量本身在栈上**，占 4 字节（或 8 字节）—— 它保存的是 **堆上对象的地址**，我们叫它 **引用（reference）**；
2. **对象内容在堆上** —— `new Student()` 就是在堆里开辟一块 "能装下 4 个字段" 的空间；
3. **`s1.name = "张三"`** 的执行过程：先按 `s1` 里的地址跳到堆，找到 `Student` 对象，再把它的 `name` 字段设为 "张三"。

#### 追问：`Student s3 = s1;` 会造新对象吗？

【口播】重要陷阱，来看这段代码：

```java
Student s1 = new Student();
s1.name = "张三";
Student s3 = s1;      // 关键这行
s3.name = "王五";
System.out.println(s1.name);   // 会输出什么？
```

**输出：`王五`**。

【板书】原因：
```text
栈：  s1 → 0x100
      s3 → 0x100    ← s3 和 s1 都是同一个地址
堆：0x100: Student {name = "王五"}
```

**`Student s3 = s1;`** **只是把栈上 `s1` 里存的地址拷贝一份给 `s3`** —— 两个引用箭头指向 **同一个对象**。所以通过 `s3` 改 `name`，`s1.name` 也变了。

**要记住的规律**：**赋值一个引用变量，不会造新对象；只有 `new` 才会造。**

### 1.6 成员变量 vs 局部变量（6 分钟）

【口播】Java 里的变量根据 "写在哪儿" 分两大类：

【板书】对比表：

| 维度 | 成员变量 | 局部变量 |
|------|---------|---------|
| **位置** | 类里、方法外 | 方法里（含方法参数） |
| **内存** | 堆（跟随对象） | 栈（方法调用结束销毁） |
| **默认值** | 有（`0 / 0.0 / null / false`） | **无**，必须显式初始化才能用 |
| **生命周期** | 对象存在期间 | 方法执行期间 |
| **访问修饰符** | 可以有（`private / public / ...`） | 不能有（只能写 `final`） |

演示代码 —— **不初始化局部变量就用**：
```java
public static void main(String[] args) {
    int x;
    System.out.println(x);   // ❌ 编译报错：variable x might not have been initialized
}
```

而成员变量不用手动初始化就能用：
```java
public class Demo {
    int x;   // 默认 = 0
    public static void main(String[] args) {
        Demo d = new Demo();
        System.out.println(d.x);   // 输出 0，编译通过
    }
}
```

【板书】要记的默认值表：

| 类型 | 默认值 |
|------|--------|
| `byte / short / int / long` | `0` |
| `float / double` | `0.0` |
| `char` | `'\u0000'`（不可见空字符） |
| `boolean` | `false` |
| 引用类型（`String / 数组 / 自定义类`） | `null` |

### 1.7 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|------|------|------|
| `s3 = s1;` 后改 `s3.name`，`s1.name` 也变了 | 复制引用不复制对象，两个变量指同一个对象 | 想造新对象必须 `new` |
| 局部变量 `int x;` 打印时编译报错 | 局部变量无默认值 | 显式赋值 `int x = 0;` |
| `Student s;` 之后 `s.name = "..."` 抛 `NullPointerException` | `s` 是引用，默认 `null`，还没指向任何对象 | 先 `s = new Student();` |
| 文件名 `student.java` 里写 `public class Student` 编译报错 | 公有类名必须与文件名 **完全一致**（大小写敏感） | 改文件名或改类名 |

### 1.8 练习（5 分钟）

1. **仿写练习**：定义 `Book` 类，字段 `isbn / title / author / price`（类型自选），方法 `printInfo()`；写测试类创建 2 本书并调用。
2. **判断输出**：
   ```java
   Student a = new Student(); a.age = 20;
   Student b = a; b.age = 30;
   System.out.println(a.age);
   ```
   答案：`30`。
3. **多选**：下列说法哪些正确？
   - a. `new Student()` 每次都会在堆上创建新对象 ✔
   - b. 局部变量的默认值是 `null` ✘（局部变量根本没有默认值）
   - c. `int age;` 写在类里，`new` 出来后默认值是 `0` ✔
   - d. `Student s;` 之后可以直接 `s.name = "..."` ✘（`s` 是 `null`，会抛 NPE）
4. **画图作业**：画出下列代码执行完后的栈—堆图：
   ```java
   Student a = new Student(); a.name = "张三";
   Student b = new Student(); b.name = "李四";
   Student c = a; c.name = "王五";
   ```
   写出 `a.name / b.name / c.name` 的值。

---

## 第 2 讲：封装

### 2.1 引入：`s.age = -5;` 的合法性问题（5 分钟）

【口播】上一讲我们的 `Student` 类有一个 **重大安全隐患**。看这段代码：

```java
Student s = new Student();
s.age = -5;         // 编译通过、运行通过
s.score = 200;      // 也通过
s.printInfo();      // 输出：年龄 -5，成绩 200.0
```

【板书】问题在哪儿？

- **年龄不可能是负数**（业务规则）；
- **成绩不可能超过 100**（业务规则）；
- 但因为字段是 "**裸露** 在类外" 的，谁都能直接写、写什么都行。

**根本原因**：**没有一道 "关卡" 拦截非法数据**。

我们希望能做到：**读字段自由；改字段时经过一道 "校验闸门"**，非法值被挡住。这就是 **封装** 要做的事。

### 2.2 封装思想：三条价值（5 分钟）

【口播】封装（Encapsulation）是面向对象三大特性之一，一句话概括：**"**把数据藏在类里，只暴露必要的操作接口。**"** 它带来三条实实在在的好处：

【板书】列三条：

1. **保证数据合法性** —— 通过 setter 拦截非法值（如 `-5` 岁）；
2. **隐藏实现细节** —— 内部字段名改了、类型换了，外部不受影响。举例：将来我把 `score` 从 `double` 改成 `BigDecimal`，只要 `getter/setter` 签名不变，用它的代码一行都不用动；
3. **降低耦合** —— 外部代码不直接依赖内部字段；类的作者能自由重构。

### 2.3 访问修饰符：4 挡权限（8 分钟）

【口播】要实现 "藏起来"，就得学 Java 的 **4 个访问修饰符**。

【板书】权限表（**从严到宽**）：

| 修饰符 | 同类 | 同包 | 子类 | 其他 |
|--------|------|------|------|------|
| `private` | ✔ | ✘ | ✘ | ✘ |
| **默认**（不写） | ✔ | ✔ | ✘ | ✘ |
| `protected` | ✔ | ✔ | ✔ | ✘ |
| `public` | ✔ | ✔ | ✔ | ✔ |

**记忆技巧**：从 `private` 到 `public` 是 **权限逐渐放宽**：先只允许自己类里用，然后同包，然后子类，最后所有地方。

【板书】**封装的黄金规则**：

```text
成员变量 → private
读写接口 → public 的 getter / setter
```

字段 `private` 后，外部就没法直接 `s.age = -5` 了（编译报错）；想改，必须通过 `s.setAge(-5)` —— 而 `setAge` 里可以写代码 **拦截**。

### 2.4 封装版 `Student`（12 分钟）

【口播】把第 1 讲的 `Student` 改造一遍，一步到位：

```java
public class Student {
    // 字段全部 private
    private String id;
    private String name;
    private int age;
    private double score;

    // 每个字段配一对 public 的 get / set
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) {
        if (age < 0 || age > 150) {
            System.out.println("年龄非法（应在 0—150），已忽略。");
            return;
        }
        this.age = age;
    }

    public double getScore() { return score; }
    public void setScore(double score) {
        if (score < 0 || score > 100) {
            System.out.println("成绩非法（应在 0—100），已忽略。");
            return;
        }
        this.score = score;
    }

    public void printInfo() {
        System.out.printf("[%s] %s，年龄 %d，成绩 %.2f%n", id, name, age, score);
    }
}
```

【板书】重点讲三处：

1. **所有字段前加 `private`** —— 外部彻底看不见了；
2. **每个字段都写一对 `getXxx / setXxx`** —— 方法名严格遵循 **JavaBean 规范**（首字母大写、驼峰）；
3. **`setAge / setScore` 里加校验** —— 这是封装最核心的价值 "**闸门**"。

#### `this` 关键字：形参和字段同名怎么办？

【口播】看这行代码 `public void setAge(int age)` —— 形参名 `age`，字段名也叫 `age`，冲突了吗？

【板书】Java 处理规则：**方法内直接写 `age` 时，按 "就近原则" 会指向 "**离得近**" 的那个** —— 也就是形参 `age`。所以下面两行代码含义完全不同：

```java
public void setAge(int age) {
    age = age;         // ❌ 把形参赋给自己，字段没变
    this.age = age;    // ✔ this = 当前对象，this.age 明确指字段
}
```

**`this` = "当前对象"**，是 Java 提供给 **方法内部** 使用的 **隐藏引用**。它让编译器 **明确区分** "谁是字段、谁是形参"。

**惯用写法**：只要形参和字段同名，就写 `this.字段 = 形参`。这是 Java 社区的标准姿势，未来所有框架代码你都会看到。

### 2.5 IDEA 一键生成 getter / setter（3 分钟）

【口播】4 个字段要写 8 个方法，手写太慢。IDEA 有一键生成：

【板书】操作步骤：
```text
1. 光标停在类内（不要在方法里）
2. 按 Alt + Insert（macOS：Cmd + N）
3. 弹出菜单选 "Getter and Setter"
4. Ctrl + A 全选字段 → OK
```

【口播】瞬间 8 个方法生成好。**注意校验代码还是要你手动加** —— IDEA 只帮你写模板，不会替你写业务逻辑。

### 2.6 效果验证：校验拦截生效（3 分钟）

```java
public static void main(String[] args) {
    Student s = new Student();
    s.setId("2026001");
    s.setName("张三");
    s.setAge(-5);         // 输出："年龄非法（应在 0—150），已忽略。"
    s.setAge(20);         // 正常写入
    s.setScore(200);      // 输出："成绩非法（应在 0—100），已忽略。"
    s.setScore(88.5);
    s.printInfo();        // [2026001] 张三，年龄 20，成绩 88.50
}
```

【口播】看，`-5` 和 `200` 都被拦下来了。字段值保持为默认值 `0` 或上一次的合法值。

### 2.7 AI 提示词模板（1 分钟）

【板书】把 "字段裸类" 交给 AI 让它一键封装的提示词：
```text
帮我把下面这个 Java 类改成封装版本：
1. 所有字段私有；
2. 生成 getter / setter；
3. 在 setter 中加入合理校验（年龄 0—150，成绩 0—100）；
4. 加中文注释说明校验规则。

[粘贴原始类代码]
```

### 2.8 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|------|------|------|
| `s.age = 20;` 编译报错 `age has private access` | `age` 是 `private`，外部不可见 | 通过 `s.setAge(20)` 访问 |
| `setAge` 里写 `age = age;`，`s.getAge()` 一直是 `0` | 形参赋给形参，字段未被赋值 | 写 `this.age = age;` |
| `getUsername` 而不是 `getUserName` 导致 Spring / Jackson 认不出来 | JavaBean 规范：字段 `userName` → getter 必须是 `getUserName` | 保持字段和方法命名一致（IDEA 自动帮你搞定） |
| 校验代码写在字段声明的 `public` 层 | 字段没有代码块，校验只能写在 setter 里 | 校验一定放 setter |
| `setAge` 里非法值就抛异常，导致后续代码全崩 | 拒绝非法值有 2 种策略：忽略 or 抛异常，要视业务定 | 学生阶段先用 "打印警告 + return"，工作中常抛 `IllegalArgumentException` |

### 2.9 练习（5 分钟）

1. 把 `Book` 类改成封装版：`price / stock` 的 setter 校验非负；`isbn / title` 的 setter 校验非空。
2. 判断下列代码合法性：
   ```java
   public void setName(String name) {
       name = name;
   }
   ```
   —— 语法合法（形参赋自己），但业务错误。改成 `this.name = name;`。
3. 说说：`private` 字段能被同类的 `main` 方法访问吗？
   —— 能。`private` 是 **类级别** 可见，同一类内部无限制。
4. 写一个 `Account`（账户）类：字段 `id / balance`；`setBalance` 校验非负；再写 `deposit(double money)` / `withdraw(double money)` 两个方法（都要校验金额非负、余额充足）。

---

## 第 3 讲：构造方法

### 3.1 引入：5 行初始化，太啰嗦了（5 分钟）

【口播】上一讲我们做完封装，创建对象变成了这样：

```java
Student s = new Student();
s.setId("2026001");
s.setName("张三");
s.setAge(20);
s.setScore(88.5);
```

**5 行代码** 才创建出一个学生。想创建 3 个 —— 15 行；100 个 —— 500 行。有没有一步到位的写法？

【板书】理想中的样子：
```java
Student s = new Student("2026001", "张三", 20, 88.5);
```

一行搞定。**这就是构造方法（Constructor）要做的事**。

### 3.2 构造方法的四大特点（5 分钟）

【口播】构造方法长这样：

```java
public Student(String id, String name, int age, double score) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.score = score;
}
```

【板书】四大特点，逐条讲：

1. **方法名 == 类名**（严格相等，大小写一致）；
2. **没有返回值类型** —— 连 `void` 都 **不能写**（写了就变成普通方法）；
3. **可以重载** —— 一个类可以有多个构造方法，参数列表不同；
4. **每个类都默认有一个无参构造** —— 如果你 **一个构造都没写**，编译器帮你补一个空的。

【口播】第 2 条最容易迷惑："为什么没有返回值？" —— 因为构造方法的 **返回值是新造的对象本身**，这是 `new` 关键字统一约定的。你写了返回值反而变成 "普通方法"，还得手动 `return`，`new` 时就不再调用它了。

### 3.3 三种典型构造方法（10 分钟）

#### （1）无参构造

```java
public Student() {
    // 什么都不做，或者做一些默认初始化
}
```

【口播】"我啥参数都不给，也想 `new` 出来一个空的 `Student` 慢慢填字段"，就写无参构造。它有多重要？—— **Spring / Jackson / Hibernate 等主流框架用反射造对象，都要求类有一个 `public` 无参构造**。写业务代码时，无参几乎是标配。

#### （2）全参构造

```java
public Student(String id, String name, int age, double score) {
    this.id = id;
    this.name = name;
    this.age = age;
    this.score = score;
}
```

【口播】把所有字段一次性赋值。**注意 `this.` 的必要性** —— 形参名和字段名同名时（这是常见惯例），必须写 `this.字段 = 形参` 明确区分。

#### （3）重载：一类多构造

【口播】一个类里可以有 **多个构造方法**，只要 **形参列表不同**（个数、类型、顺序）。这叫 **构造方法重载**。

```java
public class Student {
    private String id;
    private String name;
    private int age;
    private double score;

    // 无参
    public Student() {}

    // 部分参数
    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // 全参
    public Student(String id, String name, int age, double score) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.score = score;
    }
}
```

调用：
```java
new Student();                                     // 走无参
new Student("2026001", "张三");                    // 走 2 参
new Student("2026001", "张三", 20, 88.5);          // 走全参
```

Java 会 **按形参个数和类型** 自动挑选合适的构造方法。

### 3.4 用 `this(...)` 复用构造代码（6 分钟）

【口播】刚才三个构造方法里有 **重复代码** —— 都在写 `this.id = id;` `this.name = name;`。有没有办法只写一次？

【板书】**`this(...)` 可以在一个构造方法里调用同类的另一个构造方法**：

```java
public class Student {
    private String id;
    private String name;
    private int age;
    private double score;

    public Student() {}

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Student(String id, String name, int age, double score) {
        this(id, name);            // 复用两参构造，先赋 id / name
        this.age = age;
        this.score = score;
    }
}
```

【板书】两条铁律：

1. **`this(...)` 必须放构造方法的第一行** —— 因为要 "先把 id / name 建好，再往下走"；
2. **调用链不能循环** —— `A → B → A` 编译不过。

### 3.5 显式写带参构造 → 无参消失（大坑）（6 分钟）

【口播】现在讲一个 **初学者第一次栽跟头 100% 会栽** 的坑。

看代码：
```java
public class Student {
    private String name;
    public Student(String name) { this.name = name; }
}

// 别的类里：
Student s = new Student();   // ❌ 编译报错！
```

**报错**：`required: java.lang.String, found: no arguments`

【板书】原因：**编译器只在你 "一个构造都没写" 时才自动补无参构造**。**你一旦显式写了任意一个构造方法**（哪怕是带参），**默认的无参就消失了**。

**修复方案**：**手动补一个无参构造**：
```java
public class Student {
    private String name;
    public Student() {}                             // 补上
    public Student(String name) { this.name = name; }
}
```

【口播】记一条规矩：**只要你写了带参构造，就顺手把无参也写上**。将来上 Spring / MyBatis / Jackson，无参构造是 **框架要求的入场券**，缺了它，好几个大坑等着你。

### 3.6 构造方法 + 封装的完整版（4 分钟）

【口播】现在把封装的校验和构造方法结合起来 —— 这是 Java 类的 **标准姿势**：

```java
public class Student {
    private String id;
    private String name;
    private int age;
    private double score;

    public Student() {}

    public Student(String id, String name, int age, double score) {
        this.id = id;
        this.name = name;
        setAge(age);           // 复用 setter 里的校验
        setScore(score);
    }

    // getter / setter（含校验）省略

    public void printInfo() {
        System.out.printf("[%s] %s，年龄 %d，成绩 %.2f%n", id, name, age, score);
    }

    public static void main(String[] args) {
        Student s1 = new Student("2026001", "张三", 20, 88.5);
        Student s2 = new Student("2026002", "李四", -5, 92);
        // s2 的 age 因为校验失败，还是默认值 0
        s1.printInfo();     // [2026001] 张三，年龄 20，成绩 88.50
        s2.printInfo();     // [2026002] 李四，年龄 0，成绩 92.00
    }
}
```

**要点**：**构造方法里调用 setter，可以复用 setter 中的校验逻辑**，不用重复写 `if`。这是很好的编码习惯。

### 3.7 IDEA 一键生成构造方法（1 分钟）

```text
Alt + Insert → Constructor → 勾选要初始化的字段 → OK
```

生成后自动带 `this.xxx = xxx;` 模板，你只需检查是否要加校验。

### 3.8 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|------|------|------|
| 写了 `public Student(String name)` 后，`new Student()` 编译报错 | 显式写带参 → 默认无参消失 | 手动补无参构造 |
| `public void Student() {}` 里的 `void` 让它变成了普通方法 | 构造方法不能有返回类型（含 `void`） | 去掉 `void` |
| `this(id, name)` 写在第 3 行编译报错 | `this(...)` 必须是构造方法的第一行 | 挪到第一行 |
| Spring 报错 `No default constructor found` | 类只有带参构造，Spring 无法反射创建 | 补一个 `public` 无参 |
| `public Student(String id, String name, String name)` 编译报错 | 形参名不能重复（重载和形参名无关） | 改一个形参名 |
| 无参构造里啥字段都没赋，`new` 出来打印字段全是 `null / 0` | 字段用了 Java 默认值 | 需要就在无参里显式赋默认值 |

### 3.9 练习（5 分钟）

1. 给 `Book` 类补上 3 个构造方法：无参、`Book(String title)`、`Book(String title, String author, double price)`；后两个用 `this(...)` 逐层复用。
2. 判断下列代码是否编译通过：
   ```java
   public class A {
       public A(int x) { }
   }
   class Test { A a = new A(); }   // ❓
   ```
   —— 不通过。`A` 显式写了带参构造，默认无参消失。
3. 说出 `new Student("2026001", "张三")` 会调用哪个构造方法？—— 两参那个。
4. 用类改写 Day03 的 "学生管理系统" —— 把 4 个平行数组换成 `Student[] students`。感受 "加字段只改 `Student` 类一处" 的爽快。

---

## 第 4 讲：继承 + 方法重写

### 4.1 引入：一个 "复制粘贴" 的痛（5 分钟）

【口播】我们已经会写 `Student` 类了。现在教务处又给一个需求：**再加一个 `Teacher` 类**。字段：`id / name / age / phone`；方法：`eat() / sleep()`。

【板书】写起来发现问题：

```java
public class Student {
    private String id;
    private String name;
    private int age;
    private String phone;
    public void eat()   { System.out.println(name + " 在吃饭"); }
    public void sleep() { System.out.println(name + " 在睡觉"); }
    // + study()
}

public class Teacher {
    private String id;
    private String name;
    private int age;
    private String phone;
    public void eat()   { System.out.println(name + " 在吃饭"); }
    public void sleep() { System.out.println(name + " 在睡觉"); }
    // + teach()
}
```

**四个字段一模一样、`eat / sleep` 一模一样** —— 只是复制粘贴。这带来两个大问题：

1. **改动成本高**：以后 `eat` 要加 "吃完打嗝" 的逻辑，两个类都要改；
2. **概念上不合理**：`Student` 和 `Teacher` 都 **是一种 "人"（Person）**，共同的东西应该抽象到 "人" 里去。

【口播】面向对象给出的答案就是 **继承（Inheritance）** —— **把共同的字段和方法提到父类里，子类白捡**。

### 4.2 继承的语法：`extends`（6 分钟）

【板书】写下语法骨架：

```java
public class 子类名 extends 父类名 {
    // 子类特有的字段和方法
}
```

【板书】重构上面的例子：

```java
// 父类
public class Person {
    protected String id;
    protected String name;
    protected int age;
    protected String phone;

    public void eat()   { System.out.println(name + " 在吃饭"); }
    public void sleep() { System.out.println(name + " 在睡觉"); }
}

// 子类：Student is-a Person
public class Student extends Person {
    private String studentId;
    public void study() { System.out.println(name + " 在学习"); }
}

// 子类：Teacher is-a Person
public class Teacher extends Person {
    private String subject;
    public void teach() { System.out.println(name + " 在讲 " + subject); }
}
```

**测试**：
```java
Student s = new Student();
s.name = "张三";              // ← 父类字段，子类白捡
s.eat();                       // ← 父类方法，子类白捡
s.study();                     // ← 子类自己的方法
```

【口播】看，`Student` 里根本没写 `name` 字段和 `eat` 方法，但是它 **直接就能用** —— 这就是继承带来的 **代码复用**。

### 4.3 判断是否用继承：**is-a 关系**（3 分钟）

【口播】继承不是随便用的。**要满足 "is-a 关系"** —— "子类 **是一种** 父类"。

【板书】判断技巧：

| ✔ 合理的继承（is-a） | ✘ 不合理的继承（has-a） |
|---|---|
| `Student is a Person` | `Student has a Book`（学生 "有" 书，不是 "是" 书） |
| `Dog is an Animal` | `Car has an Engine`（车 "有" 引擎，不是 "是" 引擎） |
| `EBook is a Book` | `House has a Room` |

**记忆口诀**：**"is-a" 用继承，"has-a" 用组合**（组合 = 一个类里放另一个类的字段）。

### 4.4 继承的三条限制（6 分钟）

【板书】Java 的继承有三条 **必须记住** 的限制：

#### 限制 1：**只能单继承**

```java
class C extends A, B { }      // ❌ 编译报错，Java 不允许
```

Java 只允许一个类 **有一个直接父类**。但可以 **多层继承**：
```java
class A { }
class B extends A { }
class C extends B { }         // ✔ C 间接继承 A
```

【口播】为什么不支持多继承？—— 因为 "**菱形继承**" 会导致歧义：如果 `C` 同时继承 `A` 和 `B`，而 `A` 和 `B` 都有一个同名方法 `hello()`，`C.hello()` 该走哪个？—— 无法确定。Java 通过 "只准单继承" 来规避这个问题（多重能力可以通过 **接口** 实现，后续讲）。

#### 限制 2：**父类的 `private` 成员不能被子类直接访问**

【板书】看代码：
```java
public class Person {
    private int salary;        // 私有
    protected String name;     // 保护
}
public class Student extends Person {
    public void show() {
        System.out.println(name);      // ✔ protected 可访问
        System.out.println(salary);    // ❌ private 不可访问
    }
}
```

**特别注意**：`private` 字段 **实际上存在** 于子类对象中（占内存），只是子类的代码 **没权限直接读写**。要想访问，得通过父类提供的 `public getSalary()` 方法。

【口播】所以父类设计时，**希望子类能读写的字段用 `protected`，只对外提供 `public` 方法的字段就 `private`**。

#### 限制 3：**构造方法不能被继承**

【板书】父类的构造方法是父类专属的 "**自我构建蓝图**"，不能直接给子类用。但是子类构造 **可以调用父类构造** —— 通过 `super(...)`。这是下一讲的重点。

### 4.5 方法重写（Override）（10 分钟）

【口播】继承让我们 **白捡** 父类方法。但有时候父类的实现不够满意，子类想 **重新写一份**。这就是 **方法重写（Override）**。

【板书】经典例子：

```java
public class Animal {
    public void makeSound() {
        System.out.println("动物在叫");
    }
}

public class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("汪汪汪");
    }
}

public class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("喵喵喵");
    }
}
```

调用：
```java
new Animal().makeSound();      // 动物在叫
new Dog().makeSound();         // 汪汪汪
new Cat().makeSound();         // 喵喵喵
```

【口播】`Dog.makeSound()` 覆盖了 `Animal.makeSound()`。当我们通过 `Dog` 对象调用 `makeSound()` 时，走的是 **子类的实现**。

#### 重写规则："两同两小一大"

【板书】记住这五个字：

1. **两同**：
   - 方法名 **相同**
   - 形参列表 **相同**
2. **两小**：
   - 子类的返回值类型 ≤ 父类（可以是父类返回类型的 **子类**，叫 "**协变返回**"）
   - 子类抛出的检查异常 ≤ 父类
3. **一大**：
   - 子类的访问修饰符 ≥ 父类（**不能更严格**）

【口播】重点讲 "**一大**"：如果父类是 `public`，子类不能变成 `protected`；如果父类是 `protected`，子类可以升级到 `public`。**修饰符只能升不能降**。

举例：
```java
class Parent { public void hello() {} }
class Child extends Parent {
    @Override
    private void hello() {}        // ❌ 编译报错：不能更严格
}
```

#### `@Override` 注解：编译器帮你查错

【口播】重写时 **强烈建议加 `@Override` 注解**。它让编译器帮你检查：**你以为在重写、其实拼错了方法名** 的时候，`@Override` 会直接编译报错。

现场演示 **拼错方法名的大坑**：

```java
public class Dog extends Animal {
    @Override
    public void makesound() {          // 小写 s，拼错了！
        System.out.println("汪汪汪");
    }
}
```

**编译报错**：`method does not override or implement a method from a supertype`

【板书】**关键**：如果 **不加 `@Override`**，上面的代码 **合法** —— 会变成 `Dog` 里独有的一个新方法 `makesound`，而父类的 `makeSound` **根本没被覆盖**。你以为在重写、其实创建了个新方法，这是极其隐蔽的 Bug。

**结论**：**只要是重写，就加 `@Override`**。这是 Java 社区的黄金习惯。

### 4.6 重写 vs 重载：一字之差、天壤之别（4 分钟）

【口播】"重写（Override）" 和 "重载（Overload）" 名字太像，学生经常混。

【板书】对比表：

| 维度 | 重写（Override） | 重载（Overload） |
|------|-----------------|-----------------|
| **发生范围** | 父子类之间 | **同一个类里** |
| **方法名** | 相同 | 相同 |
| **参数列表** | **相同** | **不同** |
| **返回值** | 相同或兼容（协变） | 无关 |
| **修饰符** | 不能更严格 | 无关 |
| **注解** | 建议加 `@Override` | 无 |

**记忆口诀**：**参数列表相同 → 重写；参数列表不同 → 重载**。

现场检验：
```java
class A { public void f(int x)  {} }
class B extends A {
    public void f(long x) {}       // 重写还是重载？
}
```
—— **重载**。`B` 里同时存在两个 `f` 方法（继承自 `A` 的 `f(int)` 和自己的 `f(long)`），形参列表不同。

### 4.7 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|------|------|------|
| 子类里访问父类 `private` 字段编译报错 | `private` 只在父类内部可见 | 改用 `protected`，或通过父类的 `getter` |
| `class C extends A, B` 编译报错 | Java 不支持多继承 | 用接口 + 组合替代 |
| `@Override` 拼错方法名报错 | 父类没有这个签名的方法 | 检查方法名 / 形参是否与父类一致 |
| 不加 `@Override`，重写方法拼错，程序运行时行为异常 | 编译器无法帮你查错，方法被 "静默新增" | 永远加 `@Override` |
| 子类重写方法用 `private`，编译报错 | 子类访问修饰符不能更严格（一大） | 改成 `public` 或 `protected` |
| `class Dog extends Animal` 但 `Dog` 里字段 `name` 没赋值 | 父类字段 `protected String name` 默认 `null` | 通过父类构造 / 直接赋值 / 子类构造赋值 |

### 4.8 练习（5 分钟）

1. **必做**：定义 `Vehicle`（交通工具）父类，字段 `brand`，方法 `run()` 输出 "XX 在行驶"；子类 `Car` 重写 `run()` 输出 "XX 汽车在马路上跑"，`Boat` 重写 `run()` 输出 "XX 船在水里跑"。加 `@Override`。
2. **判断题**：下列代码能编译吗？
   ```java
   public class Parent { public void hello() {} }
   public class Child extends Parent {
       @Override
       private void hello() {}
   }
   ```
   —— 不能。子类 `private` 比父类 `public` 更严格，违反 "一大" 规则。
3. **辨析题**：下面是重写还是重载？
   ```java
   class A { public int f(int x) { return x; } }
   class B extends A { public String f(int x) { return "" + x; } }
   ```
   —— 都不是。方法名和形参列表相同，但 **返回类型不兼容**（`String` 不是 `int` 的子类），**编译报错**。
4. **思考题**：为什么 Java 不支持多继承？—— 菱形继承会导致方法调用歧义。

## 第 5 讲：this 与 super 关键字

### 5.1 引入：一个"同名"的困扰（4 分钟）

【口播】上一讲我们写 `Student extends Person`，`super(...)`、`this.name` 已经悄悄出现好几次了。今天我们把它们摊开讲清楚——这两个关键字看上去简单，却是**构造方法链**、**字段隐藏**、**方法重写** 背后最核心的两根柱子。

【板书】先看一段"看起来正常、其实有 bug"的代码：

```java
public class Student {
    private String name;
    private int age;

    public Student(String name, int age) {
        name = name;         // ← 我以为这行赋给字段了
        age = age;           // ← 其实赋给了形参自己
    }
}
```

运行后 `student.getName()` 永远是 `null`——因为 `name = name` 在方法作用域内**形参 `name` 就近覆盖了字段 `name`**，两边都是形参。要区分"当前对象的字段"和"局部变量"，就得请出 `this`。

### 5.2 this：当前对象的自我引用（8 分钟）

【板书】`this` 代表**当前正在执行方法/构造方法的这个对象**。它有三个用途：

#### 用法 1：区分成员变量和同名局部变量

```java
public class Student {
    private String name;
    private int age;

    public Student(String name, int age) {
        this.name = name;    // this.name = 字段 ; name = 形参
        this.age = age;
    }
}
```

【口播】这是 `this` 最高频的场景。IDEA 自动生成的构造和 setter 里，`this.` 前缀几乎无处不在——就是为了避开"同名坑"。

#### 用法 2：在构造方法里调用同类的其他构造 —— `this(...)`

```java
public class Student {
    private String name;
    private int age;

    public Student() {
        this("匿名", 18);    // ← 复用全参构造，必须是第一行
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
}
```

**硬性规则**：`this(...)` **必须写在构造方法第一行**，且**只能调一次**。这样才能保证对象初始化的"起点"是唯一的。

#### 用法 3：调用当前对象的其他方法/字段

```java
public void study() {
    this.printInfo();    // 等价于 printInfo();
    System.out.println(this.name + " 在学习");
}
```

`this.` 在非同名场景下可以省略，但**加上更清晰**——尤其在长方法里，看到 `this.` 立刻知道"这是当前对象的东西"。

### 5.3 super：父类视角的引用（8 分钟）

【口播】`this` 是"我自己"，`super` 就是"我作为父类的那一面"。同样有三个用途：

#### 用法 1：访问父类被隐藏的字段/方法

```java
public class Animal {
    public void makeSound() {
        System.out.println("动物在叫");
    }
}

public class Dog extends Animal {
    @Override
    public void makeSound() {
        super.makeSound();              // 先执行父类版本
        System.out.println("汪汪汪");     // 再补一句
    }
}
```

调用 `new Dog().makeSound();` 的输出：
```text
动物在叫
汪汪汪
```

【板书】这就是**"扩展而非替换"** 的写法——子类不完全推翻父类，而是在父类基础上加料。这在实际项目中非常常见（比如 GUI 的 `paintComponent` 里第一行几乎永远是 `super.paintComponent(g);`）。

#### 用法 2：访问被子类字段"遮蔽"的父类字段

```java
public class Parent {
    protected String name = "父亲";
}
public class Child extends Parent {
    private String name = "儿子";      // 遮蔽父类的 name

    public void show() {
        System.out.println(this.name);   // 儿子
        System.out.println(super.name);  // 父亲
    }
}
```

【口播】提醒：**字段遮蔽虽然合法，但极其容易造成混淆**，实际开发中要避免子类和父类同名字段。这里只是演示 `super.` 的能力，不是推荐写法。

#### 用法 3：调用父类构造 —— `super(...)`（重点）

```java
public class Person {
    protected String name;
    public Person(String name) {
        this.name = name;
    }
}

public class Student extends Person {
    private String studentId;

    public Student(String name, String studentId) {
        super(name);              // ← 必须在第一行
        this.studentId = studentId;
    }
}
```

**硬性规则**：`super(...)` **必须写在子类构造方法第一行**，用于选择"父类以哪种方式初始化"。

### 5.4 子类构造第一行的隐式规则（8 分钟）

【口播】这是 Day04 最容易踩的坑，也是面试常考点。**记住这句话**：

【板书】**子类构造方法的第一行，必定是 `super(...)` 或 `this(...)` 二选一。什么都不写，编译器自动补 `super();`——调用父类的无参构造。**

三种情形：

| 场景 | 你写的代码 | 编译器实际编译的代码 |
|---|---|---|
| ① 不写任何调用 | `public Student() { ... }` | 第一行自动补 `super();` |
| ② 显式 `super(...)` | `public Student() { super("张三"); ... }` | 保持不变 |
| ③ 用 `this(...)` 复用同类构造 | `public Student() { this("默认",18); ... }` | 保持不变；`this(...)` 最终仍会走到某个 `super(...)` |

**关键陷阱**：如果**父类没有无参构造**（因为你写了带参构造覆盖了默认的无参构造，见第 3 讲），子类**必须**在第一行显式 `super(有参...)`，否则编译报错：

```java
public class Person {
    public Person(String name) { ... }   // 只有带参构造
}

public class Student extends Person {
    public Student() {
        // 编译报错：There is no default constructor available in 'Person'
    }

    // 正确写法：
    public Student(String name) {
        super(name);        // 显式调用父类带参构造
    }
}
```

【口播】这条规则背后的哲学是：**子类对象在物理上包含一份父类字段**，所以在真正初始化子类字段之前，必须先让父类那份"活起来"。构造链就像盖房子，**必须先打地基（父类），再盖上层（子类）**。

### 5.5 this 与 super 完整对比（3 分钟）

| 维度 | `this` | `super` |
|---|---|---|
| 指向 | 当前对象 | 当前对象的**父类视角** |
| 访问字段 | `this.age` | `super.age`（父类字段） |
| 调用方法 | `this.study()` | `super.study()`（父类被重写前的版本） |
| 调用构造 | `this(...)`：调同类其他构造 | `super(...)`：调父类构造 |
| 位置限制 | `this(...)` 必须构造第一行 | `super(...)` 必须构造第一行 |
| 二者互斥 | 同一个构造里 `this(...)` 和 `super(...)` **不能共存** | 同上 |
| 静态方法内 | ❌ 不能用（`this` 是"对象" 的概念，静态方法没有对象） | ❌ 同样不能用 |

【板书】**记忆口诀**：`this` 是"我"，`super` 是"我爸"；两个只能选一个当"第一行"。

### 5.6 内存直观理解（3 分钟）

【口播】`super` 常被误解为"另一个对象"，其实**不是**。看下面这张图：

```mermaid
flowchart TB
    subgraph 对象["堆中的 Student 对象（一整块内存）"]
        P["Person 部分<br/>name / age"]
        S["Student 部分<br/>studentId"]
    end
    thisRef["this 视角<br/>能看到 P + S 全部字段"]
    superRef["super 视角<br/>只能看到 P 那半边"]
    thisRef --> 对象
    superRef --> P
```

【板书】**一个 `Student` 对象在堆里是"父类部分 + 子类部分"连成一整块**。`this` 能看整块；`super` 是给你戴上一副"只能看父类部分"的眼镜，用来在字段/方法冲突时精确指名父类的那一份。**内存里始终只有一个对象**。

### 5.7 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|---|---|---|
| `this(...)` 或 `super(...)` 不在第一行编译报错 | Java 规定它们必须是构造第一行 | 把 `this(...)` / `super(...)` 移到第一行 |
| 同一个构造里既写了 `this(...)` 又写了 `super(...)` 编译报错 | 二者互斥，只能选一个当第一行 | 只留一个；用 `this(...)` 时，被调的那个构造里会去调 `super(...)` |
| 子类构造编译报错 `There is no default constructor` | 父类没有无参构造，编译器自动补的 `super();` 找不到 | 子类第一行显式写 `super(有参...)`，或给父类补个无参构造 |
| 静态方法里写 `this.xxx` 编译报错 | 静态方法属于类不属于对象，没有 `this` | 改成通过对象引用访问，或去掉 `static` |
| 子类构造里想在 `super(...)` 前先执行一段逻辑 | Java 语法禁止 | 把逻辑做成 `static` 方法在参数位置调用：`super(computeName(...))` |
| `super.xxx` 拿不到爷爷类的字段 | `super` 只往上一层 | 无法直接跳级；重新设计继承层次 |

### 5.8 练习（5 分钟）

1. **必做**：给上一讲的 `Person / Student` 类，把 `Person` 改成"只有带参构造 `Person(String name)`"，然后修改 `Student` 让它能编译通过。写出你修改的那一行代码。
2. **辨析题**：下面代码为什么编译失败？
   ```java
   public class Student extends Person {
       public Student(String name, int age) {
           this.name = name;         // 第 1 行
           super(name);              // 第 2 行
       }
   }
   ```
   —— `super(...)` 必须在**第一行**，被第 1 行挤到第 2 行就违规了。
3. **思考题**：`this(...)` 和 `super(...)` 为什么规定必须"二选一 + 第一行"？—— 保证对象初始化只有唯一的入口路径，避免父类字段还没初始化就被子类代码访问。
4. **AI 实战**：让 AI 举一个"父类只有带参构造，子类忘写 `super(...)`"的完整报错例子，并让它解释编译器提示的 `no default constructor` 到底在说什么。
5. **手绘题**：为 `Student extends Person`，画一张类似 5.6 节的内存图，标出 `this` 和 `super` 各自能"看到"的范围。

## 第 6 讲：Object 类常用方法「Day04 收官」

### 6.1 引入：为什么每个类都自带这些方法？（4 分钟）

【口播】做个小实验：新建一个空类 `Book`，什么都不写：

```java
public class Book { }
```

然后在 `main` 里：
```java
Book b = new Book();
System.out.println(b);              // 输出：Book@1b6d3586
System.out.println(b.equals(b));    // 输出：true
System.out.println(b.hashCode());   // 输出：某个 int
System.out.println(b.getClass());   // 输出：class Book
```

【板书】`Book` 里明明什么方法都没写，为什么这些方法都能调？—— 因为 Java 里**所有类都默认继承一个"共同的祖先"：`java.lang.Object`**。你不写 `extends`，编译器自动给你补 `extends Object`。这一讲就来看这个"祖先"送给我们的四件套：`toString / equals / hashCode / getClass`。

【口播】这四件套里，前三个几乎是**每个业务类都要重写**的——不重写，程序能跑，但一放进集合、一打印、一比较就出问题。第六讲学完，我们就能给自己的 `Student` 补上一整套"规范装备"。

### 6.2 toString：把对象变成人话（5 分钟）

【板书】**用途**：把对象转成字符串，供打印、日志、调试使用。

**关键事实**：`System.out.println(obj)` 内部就是调用 `obj.toString()`；字符串拼接 `"" + obj` 也是。

**默认实现**：`getClass().getName() + "@" + Integer.toHexString(hashCode())`——即 `Book@1b6d3586` 这种鬼样子，**几乎没意义**。

**规范重写**：

```java
public class Student {
    private String id;
    private String name;
    private int age;
    private double score;

    @Override
    public String toString() {
        return "Student{id='" + id + "', name='" + name +
               "', age=" + age + ", score=" + score + "}";
    }
}
```

调用：
```java
Student s = new Student("2026001", "张三", 20, 95.5);
System.out.println(s);
// 输出：Student{id='2026001', name='张三', age=20, score=95.5}
```

【口播】**IDEA 一键生成**：光标停在类里，按 `Alt + Insert` → 选 `toString()` → 勾选要包含的字段 → 回车。生成的代码就是上面这种风格，非常规范。**永远不要手写**，IDEA 生成更可靠。

### 6.3 equals：内容相等 vs 引用相等（8 分钟）

【板书】先区分 Java 里两个"相等"：

| 运算 | 比较的东西 | 例子 |
|---|---|---|
| `==` | **引用地址**（是不是同一个对象） | `a == b` |
| `.equals()` | **业务内容**（默认实现仍是 `==`，需重写才有意义） | `a.equals(b)` |

【口播】看一段代码：

```java
Student a = new Student("2026001", "张三");
Student b = new Student("2026001", "张三");

System.out.println(a == b);          // false（堆里两个对象）
System.out.println(a.equals(b));     // ??? 
```

—— `a.equals(b)` 的结果取决于**有没有重写 `equals`**：
- **没重写** → 走 `Object.equals`，内部是 `this == obj`，输出 `false`。
- **重写了** → 按你写的规则比字段，输出 `true`。

#### 标准重写模板

【板书】记住这五步模板：

```java
import java.util.Objects;

@Override
public boolean equals(Object o) {
    if (this == o) return true;                          // 1. 同一对象直接 true
    if (o == null || getClass() != o.getClass())         // 2. 类型不一致直接 false
        return false;
    Student s = (Student) o;                             // 3. 向下转型
    return age == s.age                                  // 4. 逐字段比较
        && Double.compare(s.score, score) == 0
        && Objects.equals(id, s.id)
        && Objects.equals(name, s.name);
}
```

**要点讲解**：

1. **第 1 行"自反捷径"**：`this == o` 直接返回 true，避免后续无谓的字段比较。
2. **第 2 行"类型守卫"**：`o == null` 挡住空引用；`getClass() != o.getClass()` 挡住"父子类混比"（比如 `Student.equals(某个 GraduateStudent)` 会直接 false）。
3. **`Objects.equals(a, b)`**：`java.util.Objects` 提供的**空安全比较**——两个都 null 也算相等，比手写 `a == null ? b == null : a.equals(b)` 优雅。
4. **`Double.compare` 而非 `==`**：浮点数用 `==` 有 NaN 陷阱，`Double.compare` 才是官方推荐。

【口播】**同样用 IDEA 生成**：`Alt + Insert` → `equals() and hashCode()` → 选字段 → 一路回车。生成的代码就是这个模板。

### 6.4 hashCode：与 equals 绑死的兄弟（6 分钟）

【口播】`hashCode()` 返回一个 int，代表对象的"哈希摘要"。它自己看上去用不到，但**放进 `HashMap / HashSet`（Day12 会详讲）时，集合先用 `hashCode` 快速定位桶，再用 `equals` 精确匹配**——两者是配对使用的。

【板书】**Java 官方合约（Contract）**：

1. `a.equals(b)` 为真 → `a.hashCode() == b.hashCode()` **必须**为真。
2. `a.hashCode() == b.hashCode()` 为真 **不要求** `a.equals(b)` 为真（哈希冲突正常）。
3. 同一个对象只要没修改字段，多次调用 `hashCode()` 必须返回相同值。

**推论**：**只要重写了 `equals`，就必须一起重写 `hashCode`**，否则违反合约 → 放进 HashSet 会出现"内容一样的对象被存了两份"的严重 bug。

#### 标准重写

```java
@Override
public int hashCode() {
    return Objects.hash(id, name, age, score);
}
```

`Objects.hash(...)` 内部会把每个字段的哈希组合起来，一行搞定。**参与哈希的字段和 `equals` 参与比较的字段应保持一致**——这是"合约"的具体体现。

#### 反例：违反合约会怎样？

```java
class Book {
    String isbn;
    Book(String isbn) { this.isbn = isbn; }

    @Override
    public boolean equals(Object o) {
        return o instanceof Book b && Objects.equals(isbn, b.isbn);
    }
    // ❌ 故意不重写 hashCode
}

Set<Book> set = new HashSet<>();
set.add(new Book("978-7"));
set.add(new Book("978-7"));
System.out.println(set.size());     // 期望 1，实际 2
```

【口播】两个"内容相同"的 `Book` 因为默认 `hashCode` 返回了不同的地址哈希，被扔进了不同的桶，`HashSet` 根本不知道它们"其实相等"。**这是重写 `equals` 却漏写 `hashCode` 的经典事故**。**IDEA 生成时永远一起生成两个**，别偷懒。

### 6.5 getClass：运行时的类型标签（3 分钟）

【板书】`getClass()` 返回一个 `Class<?>` 对象，代表当前对象**运行时的真实类型**：

```java
Student s = new Student("2026001", "张三");
System.out.println(s.getClass().getName());        // Student（含包名时是 com.xxx.Student）
System.out.println(s.getClass().getSimpleName());  // Student
```

【口播】三个使用场景：

1. **在 `equals` 里做类型守卫**（我们 6.3 节已经用过了）。
2. **日志/调试**里打印对象的真实类型：`log.info("class = {}", obj.getClass().getSimpleName());`
3. **反射入口**（后续课程）：拿到 `Class` 对象后可以反射读字段、调方法、创建实例。

**扩展常识**：`getClass()` 返回的是**运行时类型**（多态时也不会骗你）——即使把 `Student` 声明成 `Person` 类型，`getClass()` 仍然返回 `Student.class`。这一点在下一天（Day05 多态）会重点用到。

### 6.6 一次完整示例（5 分钟）

【板书】把 `toString / equals / hashCode` 全部装到 `Student` 上：

```java
import java.util.Objects;

public class Student {
    private String id;
    private String name;

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student{id='" + id + "', name='" + name + "'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student s = (Student) o;
        return Objects.equals(id, s.id) && Objects.equals(name, s.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }

    public static void main(String[] args) {
        Student a = new Student("2026001", "张三");
        Student b = new Student("2026001", "张三");
        System.out.println(a);                             // Student{id='2026001', name='张三'}
        System.out.println(a == b);                        // false
        System.out.println(a.equals(b));                   // true
        System.out.println(a.hashCode() == b.hashCode());  // true
    }
}
```

**输出**：
```text
Student{id='2026001', name='张三'}
false
true
true
```

【口播】看这最后三行：`==` 是 false（两个不同对象），`equals` 是 true（内容一致），`hashCode` 也一致（合约成立）。**这就是"规范业务类"的样子**。以后每写一个业务实体类，都应该有这三件套。

### 6.7 AI 提示词参考（2 分钟）

【板书】把 IDEA 生成的代码交给 AI 复查/生成的模板：

```text
请帮我给下面这个 Java 类生成规范的：
1. toString（含所有字段）；
2. equals（基于 id 唯一标识判等）；
3. hashCode（与 equals 参与字段保持一致）；
4. 使用 java.util.Objects 工具类实现，避免手写 null 判空。

[粘贴类代码]
```

### 6.8 pitfall 表（3 分钟）

| 现象 | 原因 | 修复 |
|---|---|---|
| 打印对象输出 `Xxx@1b6d3586` | 没重写 `toString` | 用 IDEA `Alt+Insert` 生成 `toString()` |
| 两个"内容相同"的对象 `.equals()` 返回 false | 没重写 `equals`，走的是 `==` | 用 IDEA 生成 `equals()` |
| 重写 `equals` 后放进 `HashSet` 还是存了两份 | 没同时重写 `hashCode` | 一起生成 `equals` + `hashCode`，参与字段保持一致 |
| `equals(Object o)` 写成 `equals(Student o)` | 签名不匹配，没重写只是重载 | 参数类型必须是 `Object`，加 `@Override` 编译器会报错提示 |
| `getClass() != o.getClass()` 换成 `o instanceof Student` 后父子类比较返回 true | `instanceof` 允许子类"冒充"父类；`getClass()` 严格 | 严格业务判等用 `getClass()`；框架层多态判等再考虑 `instanceof` |
| 修改了对象的字段后从 `HashMap` 里取不出来了 | 字段变了 → `hashCode` 变了 → 定位不到原来的桶 | **不要把可变对象当 HashMap/HashSet 的 key**，用不可变对象或不参与哈希的字段 |

### 6.9 练习（5 分钟）

1. **必做**：给你的 `Student` 类（含 `id / name / age / score` 四个字段）用 IDEA 一键生成 `toString / equals / hashCode`，参与 `equals` 的字段选 `id` 一个即可（业务上 id 就是唯一标识）。写出生成后的三段代码。
2. **选做**：把 4.1 节的 `Vehicle → Car / Boat` 三个类都补上 `toString`。运行 `System.out.println(new Car("宝马"));`，观察输出。
3. **辨析题**：以下 `equals` 有什么问题？
   ```java
   @Override
   public boolean equals(Student o) {           // ← 参数类型
       return this.id.equals(o.id);
   }
   ```
   —— 参数不是 `Object` 而是 `Student`，**这是重载不是重写**。加 `@Override` 会直接编译报错——这就是 `@Override` 的价值。
4. **合约验证**：手写一个只重写 `equals` **不**重写 `hashCode` 的 `Book` 类，把两个内容一样的 `Book` 放进 `HashSet`，观察 `set.size()`。—— 应输出 `2`，实证"重写 `equals` 必须一起重写 `hashCode`"的必要性。
5. **AI 实战**：让 AI 讲解"为什么 `equals` 里推荐用 `getClass() != o.getClass()` 而不是 `instanceof`"，并让它举一个用 `instanceof` 导致对称性被破坏的例子（`a.equals(b) == true` 但 `b.equals(a) == false`）。

---

## Day04 小结

【板书】这一天我们从"面向过程的痛点"出发，把面向对象的**基础支柱**全部搭建起来：

| 模块 | 关键词 | 你已经会做的事 |
|---|---|---|
| **类与对象** | `class` / `new` / 引用类型 | 从数据角度设计一个业务实体，new 出对象访问字段/方法 |
| **封装** | `private` / `getter/setter` / 校验 | 用私有字段 + 公有方法保护数据；在 setter 中写业务规则 |
| **构造方法** | 无参 / 全参 / 重载 / `this(...)` | 用重载让"构造姿势"多样；用 `this(...)` 复用避免重复代码 |
| **继承** | `extends` / is-a / protected | 复用父类字段方法；识别 is-a vs has-a；理解单继承限制 |
| **方法重写** | `@Override` / 两同两小一大 | 安全地重写父类方法；用 `@Override` 抓拼写错 |
| **this / super** | 当前对象 / 父类视角 / 构造第一行 | 精确指名字段来源；构造链中正确接力父类 |
| **Object 四件套** | `toString / equals / hashCode / getClass` | 给业务类补上"标准装备"；理解 `equals`+`hashCode` 合约 |

【口播】记住三条**贯穿全天**的心智模型：

1. **类是图纸，对象是房子**——一份图纸能盖任意多的房子，每个房子有自己的内存。
2. **封装 = 把数据放进保险箱**——字段设 private，出入必须走 getter/setter，校验在门口。
3. **继承 = 复用 + 定制**——白捡父类方法，不满意就重写；构造链的"第一行"必须交代清楚父类怎么初始化。

## Day05 预告

【板书】明天 Day05 我们会站在今天的基础上，进入面向对象的"高级篇"：

| 讲次 | 主题 | 预习提示 |
|---|---|---|
| L1 | **多态**：父类引用指向子类对象、动态绑定 | 你已经会重写方法了，但"`Animal a = new Dog();` 调用 `a.makeSound()` 到底走谁"这个问题今天没解开——那就是多态 |
| L2 | **`final` 关键字**：final 类、final 方法、final 变量 | 想想"不允许被继承的类"、"不允许被重写的方法"什么时候需要 |
| L3 | **`static` 静态成员**：类变量 / 类方法 / 静态代码块 | `Math.max(1, 2)` 为什么不用 `new Math()`？—— 就是 static |
| L4 | **抽象类**：`abstract class` / 抽象方法 | "只画图纸不盖房"的类；强制子类实现某些方法 |
| L5 | **接口**：`interface` / 多实现 / 默认方法 | Java 单继承的补丁——一个类不能 `extends` 多个父类，但可以 `implements` 多个接口 |
| L6 | **枚举与 Record**：`enum` / `record` | 定义"有限选项"（如星期一到星期日）、"纯数据载体"的现代化写法 |

【口播】**今天晚上把 Day04 的作业完整做完**——尤其是 `Student` 补三件套那道。明天多态一开讲，我们会立刻用到今天写的所有 `Student / Person / Animal` 类。**这些代码不要删，Day05 直接接着用。**

## 作业汇总

### 必做作业

1. **`Student` 类全面改造**（Day04 收官作业）：
   - 字段：`private` 的 `id / name / age / score`。
   - 至少 3 个构造方法：无参、全参、`Student(String id, String name)` 使用 `this(...)` 复用全参。
   - 4 组 `getter/setter`，其中 `setAge` 校验 0—150，`setScore` 校验 0—100。
   - 让 `Student extends Person`（`Person` 里放 `name / age` + 全参构造），在 `Student` 构造第一行用 `super(name, age)` 传给父类。
   - 用 IDEA 生成规范的 `toString / equals / hashCode`，`equals` 仅按 `id` 判等。
   - 写 `main` 方法验证：创建两个 id 相同的 `Student`，测试 `==` / `equals` / `hashCode` / 放进 `HashSet` 只留一份。

### 选做作业

2. **重写 `equals` 与 `hashCode` 的对比实验**：手写两个版本的 `Book` 类：
   - 版本 A：只重写 `equals`，不重写 `hashCode`。
   - 版本 B：两个都规范重写。
   - 各自往 `HashSet` 放 3 本"内容完全相同"的书，输出 `set.size()`，写一段 100 字左右的观察记录。
3. **`toString` 优化**：为 Day04 全体自定义类（`Student / Person / Animal / Dog / Cat / Vehicle / Car / Boat`）补上规范 `toString`，让打印一个对象就能看清所有字段。
4. **AI 复查**：把你写的 `Student` 完整代码交给 AI，用 6.7 节的提示词模板请它复查，逐条对照 AI 的建议改进代码，并写下你**接受**了哪些建议、**拒绝**了哪些建议、**为什么**。
