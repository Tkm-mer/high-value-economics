# AI 应用编程基础——Java 基础 - 学生讲义（Day02：第 1—6 讲）

**总课时：6 讲**
**适用对象：Java 零基础学员（大一 / AI 应用方向）**
**基线环境：JDK 25 LTS + IntelliJ IDEA 2026.1**
**对应教材：** 第 3 章《流程控制：分支与循环》 + 第 4 章《一维数组：定义、遍历、查找与排序》

## 本日概览

| 讲次 | 主题 | 关键知识点 |
|------|------|-----------|
| 第 1 讲 | 顺序结构 + 分支 if | 顺序执行 / `if` / `if-else` / `if-else if` / 布尔表达式 / 区间判断 |
| 第 2 讲 | 分支 switch | 传统 `switch` + `break` + 穿透 / `switch` 表达式 (`->`) / 支持类型 |
| 第 3 讲 | 循环 + Debug | `for` / `while` / `do-while` / `break` / `continue` / IDEA Debug 五键 |
| 第 4 讲 | 一维数组基础 | 定义 / 三种初始化 / `.length` / 普通 for / 增强 for / 越界与空指针 |
| 第 5 讲 | 数组案例 + 查找 | 综合统计 / `printf` / 顺序查找 O(n) / 二分查找 O(log n) 三大坑 |
| 第 6 讲 | 排序 + 收官 | 冒泡（含 `swapped` 优化）/ 选择 / 时间复杂度 / 稳定性 |

> 💡 阅读建议：讲义是"讲授脚本"，代码块都可以直接跑，遇到 `⚠️` 请停下来动手验证；每讲末尾都有练习，不做完不要往下翻。

---

## 第 1 讲：顺序结构 + 分支 if

### 1.1 从"起床—刷牙—上课"说起

好，我们打开 IDEA 的空 `main` 方法。你觉得 Java 是怎么执行的？答案很简单——**它默认从上往下、一行接一行地执行**。这就是**顺序结构**，也是所有代码最底层的执行方式。

```java
public class SeqDemo {
    public static void main(String[] args) {
        System.out.println("第一步：起床");   // 1
        System.out.println("第二步：刷牙");   // 2
        System.out.println("第三步：上课");   // 3
    }
}
```

输出：
```text
第一步：起床
第二步：刷牙
第三步：上课
```

顺序结构听起来很朴素，但它是"选择"和"循环"的底盘——**只有理解了默认从上到下，你才能理解"跳过某几行"或"重复某几行"**。

现在换个场景：昨晚喝了奶茶，今天早上要**判断**要不要刷两遍牙。程序不能永远直线执行，它得学会"看情况选路"。这就是**分支结构**。

### 1.2 if 三种形态

Java 里的分支主要有 `if` 和 `switch` 两种，本讲讲 `if`（下讲讲 `switch`）。

**形态 1：单分支 `if`——只有 "是" 才执行**

```java
if (条件) {
    // 条件为 true 才执行
}
```

例子：判断是否成年。

```java
int age = 20;
if (age >= 18) {
    System.out.println("已成年");
}
// 输出：已成年
```

如果 `age = 15`，什么都不输出——因为条件为 `false`，直接跳过大括号里的代码。

**形态 2：双分支 `if-else`——非黑即白**

```java
if (条件) {
    // true 分支
} else {
    // false 分支
}
```

例子：判断奇偶。

```java
int n = 7;
if (n % 2 == 0) {
    System.out.println("偶数");
} else {
    System.out.println("奇数");
}
// 输出：奇数
```

**形态 3：多分支 `if-else if`——多路选一**

这是最常用的一种。看成绩分档：

```java
int score = 85;
if (score >= 90) {
    System.out.println("优秀");
} else if (score >= 80) {
    System.out.println("良好");
} else if (score >= 60) {
    System.out.println("及格");
} else {
    System.out.println("不及格");
}
// 输出：良好
```

### 1.3 多分支两大规则

看似简单，但学员最容易在这里翻车。记住两个铁律：

**规则 1：从上到下依次判断，命中一个立即结束**

程序看到 `score >= 90` 是 `false`，才会看 `score >= 80`。一旦 `score >= 80` 为 `true`，**后面的 `else if` 就全部跳过**——这叫短路。

**规则 2：条件区间要互不重叠且覆盖完整**

看下面这段**错误代码**：

```java
// ❌ 错误示范：先松后严
int score = 95;
if (score >= 60) {
    System.out.println("及格");
} else if (score >= 80) {
    System.out.println("良好");
} else if (score >= 90) {
    System.out.println("优秀");
}
// 输出：及格  （学员崩溃：95 分怎么变及格了？）
```

因为 95 先命中了 `>= 60`，后面的"良好"和"优秀"永远走不到。**多分支要从严到宽写**——先看最高的门槛。

### 1.4 布尔表达式

`if` 圆括号里必须是一个"能算出 true 或 false 的表达式"。常见的比较和逻辑运算符：

| 运算符 | 含义 | 示例 |
|--------|------|------|
| `==` | 等于（不是 `=`！） | `x == 5` |
| `!=` | 不等于 | `x != 5` |
| `>` `<` `>=` `<=` | 大于/小于/大于等于/小于等于 | `score >= 60` |
| `&&` | 逻辑与（都为真） | `x > 0 && x < 100` |
| `\|\|` | 逻辑或（有一个真即可） | `day == 6 \|\| day == 7` |
| `!` | 逻辑非（取反） | `!isDone` |

> ⚠️ **注意：** `==` 是"等于"判断，`=` 是"赋值"。在 `if (x = 5)` 里你其实做了赋值，编译错误——Java 幸好不接受这种写法（C 语言会）。

### 1.5 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 高分档永远走不到 | `if-else if` 区间顺序反了，先命中松条件 |
| `if (x = 5)` 编译报错 | 写成赋值而非比较；应为 `x == 5` |
| `if (score >= 60 && score < 80)` 边界重叠 / 遗漏 | 区间边界没想清楚，`80` 到底属于良好还是及格？必须画数轴 |
| `else if` 写成 `else` `if`（中间空格） | 中间空格没关系，但是新起一行的 `if` 就会脱钩；对齐要小心 |
| `if (a == b || c)` 得到意外结果 | `c` 本身不是布尔表达式；应写 `a == b \|\| a == c` |

### 1.6 练习

1. 输入年龄，输出"儿童（0—6）/ 少年（7—17）/ 成年（18—59）/ 老年（≥60）"。
2. 输入一个整数，判断"正数 / 负数 / 零"。
3. 输入年、月，输出该月天数——注意 2 月的闰年判断（闰年 = 能被 4 整除但不能被 100 整除，或能被 400 整除）。
4. **挑战**：输入 BMI 值（体重 / 身高²），按 `<18.5` 偏瘦、`18.5—24` 正常、`24—28` 超重、`≥28` 肥胖分四档输出。

---

## 第 2 讲：分支 switch（含 switch 表达式）

### 2.1 从"7 个 else if 太丑了"说起

上一讲你会写 `if-else if` 了。但如果我给你一个变量 `day`（1—7），要输出"周一 / 周二 / …… / 周日"，你写出来大概是这样：

```java
if (day == 1) System.out.println("周一");
else if (day == 2) System.out.println("周二");
else if (day == 3) System.out.println("周三");
// ...再写 4 行
else System.out.println("其他");
```

7 行 `else if`，眼睛看花了。当"**变量等于某个具体值**"的多路判断出现时，Java 有更清爽的写法——`switch`。

### 2.2 传统 switch 语法

```java
int day = 3;
switch (day) {
    case 1:
        System.out.println("周一");
        break;
    case 2:
        System.out.println("周二");
        break;
    case 3:
        System.out.println("周三");
        break;
    default:
        System.out.println("其他");
        break;
}
// 输出：周三
```

三条铁律：
1. `case` 标签后必须是**编译期常量**（字面量、`final` 常量或枚举值）——不能是 `case x:` 这样的变量。
2. **`break` 必不可少！** 否则会"穿透"到下一个 `case`。
3. `default` 兜底所有未列出的情况，习惯放最后。

### 2.3 穿透：漏 `break` 的翻车现场

看下面这段**故意漏 break** 的代码：

```java
int day = 1;
switch (day) {
    case 1:
        System.out.println("周一");   // ← 漏 break
    case 2:
        System.out.println("周二");   // ← 也漏
    case 3:
        System.out.println("周三");
        break;
    default:
        System.out.println("其他");
}
// 输出：
// 周一
// 周二
// 周三
```

`day = 1` 命中 `case 1`，但因为没有 `break`，程序继续往下执行到 `case 2` 的语句、再到 `case 3` 的语句，直到遇到 `break` 才停。这叫 **case 穿透**。

> ⚠️ **注意：** 漏 `break` 是 `switch` 最常见的 Bug 之一，也是新语法（下一节）诞生的直接原因。

有时候我们**故意**穿透——多个值走同一段逻辑：

```java
int day = 6;
switch (day) {
    case 1: case 2: case 3: case 4: case 5:
        System.out.println("工作日"); break;
    case 6: case 7:
        System.out.println("周末"); break;
}
// 输出：周末
```

### 2.4 switch 表达式（JDK 14+）

从 JDK 14 开始，`switch` 有了一种更现代的写法——**箭头写法** `->`：

```java
int day = 3;
String name = switch (day) {
    case 1 -> "周一";
    case 2 -> "周二";
    case 3 -> "周三";
    case 6, 7 -> "周末";    // 多值合并
    default -> "其他";
};
System.out.println(name);
// 输出：周三
```

四大优势：

| 优势 | 传统写法 | 表达式写法 |
|------|---------|-----------|
| 是否需要 `break` | 需要（漏则穿透） | 不需要（自动阻断） |
| 能否返回值 | 不能（是语句） | 可以（是表达式） |
| 多值合并 | 靠穿透 | `case 1, 2, 3 ->` |
| 编译器检查 | 不强制覆盖所有情况 | 强制覆盖（不写 `default` 且不穷举则报错） |

### 2.5 switch 支持的类型

| 类型 | 支持？ | 备注 |
|------|--------|------|
| `byte` / `short` / `int` / `char` | ✅ | 经典整型和字符 |
| `String` | ✅ | JDK 7+ |
| 枚举 `enum` | ✅ | 后续章节讲 |
| `long` | ✅ | JDK 25+ 起支持 |
| `float` / `double` / `boolean` | ❌ | 浮点精度问题；布尔用 `if` 更清楚 |

### 2.6 什么时候用 switch？

| 场景 | 推荐 |
|------|------|
| 判断区间（如 `score >= 80`） | `if-else if` |
| 判断具体等值（如 `day == 3`） | `switch` |
| 分支多且都是等值 | `switch` 表达式（新语法最清爽） |
| 只需要 2 路判断 | `if-else` |

### 2.7 完整示例：简易计算器

```java
public class Calc {
    public static void main(String[] args) {
        double a = 10, b = 3;
        char op = '+';
        double result = switch (op) {
            case '+' -> a + b;
            case '-' -> a - b;
            case '*' -> a * b;
            case '/' -> b == 0 ? 0 : a / b;
            default -> throw new IllegalArgumentException("未知运算符：" + op);
        };
        System.out.println(a + " " + op + " " + b + " = " + result);
    }
}
```

输出：
```text
10.0 + 3.0 = 13.0
```

改 `op = '*'` 再跑，输出变为 `10.0 * 3.0 = 30.0`。

### 2.8 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 传统 switch 输出多行意外结果 | 漏写 `break` 导致穿透 |
| `case x:` 编译报错 | `case` 后只能是常量，不能是变量 |
| 用 `switch` 判断 `double` 报错 | `switch` 不支持浮点 |
| 表达式写法漏 `default` 报错 | 表达式必须覆盖所有情况，缺 `default` 或未穷举枚举都会报错 |
| `case 1, 2 -> ...` 在旧项目报错 | 多值合并是 JDK 14+ 特性，需检查 JDK 版本 |

### 2.9 练习

1. 输入 1—12 的月份，用**传统 switch** 输出对应英文名（`Jan / Feb / ...`）。
2. 输入等级字符（`'A' / 'B' / 'C' / 'D'`），用 **switch 表达式** 返回对应的分数区间字符串。
3. 输入数字 1—7，用 switch 表达式和多值合并写法输出"工作日"或"周末"。
4. **挑战**：将成绩分档（优 / 良 / 及格 / 不及格）用 `switch` 表达式改写——提示：先把分数按 10 整除得到 0—10 的档位，再对档位做 `switch`。

---

## 第 3 讲：循环 for / while / do-while + break / continue + Debug 调试

### 3.1 从"求 1—100 的和"说起

问：写代码求 `1 + 2 + 3 + ... + 100` 的和，你打算打 100 行 `sum += n` 吗？当然不。计算机最擅长**重复劳动**，只要给它一个规则，它可以自动重复一亿次。这就是**循环**。

Java 有三种循环：`for`、`while`、`do-while`。它们的核心都是"**只要条件为真就重复**"，区别在于**判断时机**。

### 3.2 for 循环——已知次数的首选

```java
for (初始化; 循环条件; 迭代) {
    // 循环体
}
```

三段式的执行流程：**初始化 → 判断条件（真则进入）→ 循环体 → 迭代 → 再判断……** 直到条件为假才退出。

例子 1：打印 1—10

```java
for (int i = 1; i <= 10; i++) {
    System.out.println(i);
}
```

例子 2：求 1—100 的和

```java
int sum = 0;
for (int i = 1; i <= 100; i++) {
    sum += i;
}
System.out.println("1 到 100 的和 = " + sum);   // 5050
```

`i` 是循环变量，`i++` 每轮加 1；条件 `i <= 100` 为假时循环结束。

### 3.3 while 循环——先判断再执行

```java
while (循环条件) {
    // 循环体
}
```

例子：数字反复除 2 直到小于 1，统计次数（相当于 `log2(n)`）。

```java
int n = 100;
int count = 0;
while (n >= 1) {
    n /= 2;
    count++;
}
System.out.println("除的次数：" + count);   // 7
```

### 3.4 do-while 循环——至少执行一次

```java
do {
    // 循环体
} while (循环条件);
```

**先执行、再判断**——不管条件真假，循环体至少跑一次。经典应用：猜数字游戏（用户至少猜一次）。

```java
import java.util.Scanner;

public class GuessNumber {
    public static void main(String[] args) {
        int target = 42;
        Scanner sc = new Scanner(System.in);
        int guess;
        do {
            System.out.print("请输入猜测数字：");
            guess = sc.nextInt();
            if (guess < target) System.out.println("小了");
            else if (guess > target) System.out.println("大了");
        } while (guess != target);
        System.out.println("恭喜猜中！");
        sc.close();
    }
}
```

### 3.5 三种循环对比

| 结构 | 适用场景 | 是否至少执行 1 次 |
|------|---------|-------------------|
| `for` | 已知循环次数 | 否 |
| `while` | 未知次数、依赖条件 | 否 |
| `do-while` | 至少执行一次 | 是 |

### 3.6 break 与 continue

**`break`：结束整个循环，直接跳出**

```java
for (int i = 1; i <= 10; i++) {
    if (i == 5) break;
    System.out.println(i);
}
// 输出：1 2 3 4
```

**`continue`：跳过本次循环剩余部分，进入下一轮**

```java
for (int i = 1; i <= 10; i++) {
    if (i % 2 == 0) continue;
    System.out.println(i);
}
// 输出：1 3 5 7 9
```

> 💡 **技巧：** `break` 像"跳出电梯"，`continue` 像"这一层不停，直接去下一层"。

### 3.7 循环嵌套：九九乘法表

```java
public class MultiTable {
    public static void main(String[] args) {
        for (int i = 1; i <= 9; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j + " * " + i + " = " + (i * j) + "\t");
            }
            System.out.println();   // 每行结束换行
        }
    }
}
```

输出（前 3 行）：
```text
1 * 1 = 1
1 * 2 = 2	2 * 2 = 4
1 * 3 = 3	2 * 3 = 6	3 * 3 = 9
```

**理解嵌套的关键**：外层跑 1 圈 = 内层跑完 1 遍。所以外层 9 轮 × 内层平均 5 轮 = 约 45 次打印。

### 3.8 IDEA Debug 上场

写循环最容易出 Bug——变量总在变，你光看代码想不清楚。**Debug** 就是让你**用眼睛看到**变量在每一行的变化。

**第一步：打断点**——在代码行号左侧点击，出现红色圆点，程序运行到这一行会暂停。

**第二步：启动 Debug**——右键 → `Debug 'XxxTest.main()'`，或按 `Shift + F9`。程序会跳到断点处停下，底部 Debug 面板出现：

- **Variables**：当前所有变量的实时值。
- **Frames**：方法调用栈。
- **Console**：程序标准输出。

**第三步：单步调试快捷键**

| 快捷键 | 名称 | 功能 |
|--------|------|------|
| `F8` | Step Over | 单步执行，**不**进入方法内部 |
| `F7` | Step Into | 单步执行，**进入**方法内部 |
| `Shift + F8` | Step Out | 跳出当前方法，回到调用处 |
| `F9` | Resume | 继续运行到下一个断点 |
| `Ctrl + F2` | Stop | 终止调试 |

> 💡 **技巧：** 大多数情况用 `F8`（不进入方法）就够了；只有你想看方法内部实现时才用 `F7`；`F9` 是循环里最常按的键——一按一轮。

### 3.9 Debug 实战：找出 Bug

**错误代码**（求 1—100 偶数和，期望 2550，实际输出 100）：

```java
public class BugDemo {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 1; i <= 100; i++) {
            if (i % 2 == 0) {
                sum = i;                  // ❌ 这里应该是 sum += i
            }
        }
        System.out.println("偶数和 = " + sum);   // 输出：100
    }
}
```

**Debug 步骤**：
1. 在 `sum = i;` 这一行打断点。
2. `Shift + F9` 启动 Debug。
3. 反复按 `F9`——每按一次，程序跑到下一次断点命中（即下一个偶数）。观察右侧 Variables 面板中的 `sum` ——你会发现它每次都被**覆盖成最新的偶数**（2、4、6、...、100），**根本没在累加**。
4. 定位到 Bug → 改成 `sum += i;` → 重新运行 → 输出 `2550`。

### 3.10 Debug 三个心法

1. **假设 vs 事实**——Debug 就是不断验证你对代码行为的假设。你以为 `sum = 2550`，Variables 面板告诉你只有 `100`，就找到了 Bug 的入口。
2. **二分定位**——不知道 Bug 藏哪？在中间打断点，看那一刻数据是否已经错了；再逐次缩小范围。
3. **让 AI 参与**——把出错代码 + 期望行为 + 实际行为发给通义灵码 / Trae：

```text
下面这段 Java 代码本来要计算 1—100 的偶数之和，但输出是 100 而不是 2550。
请：
1. 逐行分析问题所在；
2. 给出正确代码；
3. 教我怎么用 IDEA Debug 复现这个错误。

[粘贴代码]
```

### 3.11 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 死循环 | 忘了写迭代（`i++`），或者条件永远为真 |
| `for(int i=1; i<=10; i--)` 死循环 | 迭代方向和条件不匹配，`i--` 让 `i` 越来越小 |
| `while` 循环一次都没进 | 条件初始就是 `false`，`do-while` 才能强制跑一次 |
| `break` 意外只跳出内层循环 | `break` 默认只作用于**最内层**；跳出多层需要标签（少用） |
| Debug 时按 F7 跳到 `System.out.println` 里出不来 | 误用了 Step Into；用 `Shift + F8` 跳出，或用 F8 |

### 3.12 练习

1. 用 `for` 循环打印 1—100 之间的所有质数（提示：质数只能被 1 和自身整除）。
2. 用 `while` 循环计算：给定整数 `n`，反复整除 2 直到小于 1，输出整除的次数。
3. 用嵌套循环打印 5 层等腰星号三角形：
```text
    *
   ***
  *****
 *******
*********
```
4. **Debug 实战**：故意写"求 5 门课平均分"的 `sum / count` 整数除法版本（少了 `* 1.0`），用 IDEA Debug 观察 Variables，定位问题，写一段修复笔记。
5. **挑战**：猜数字升级版——`(int)(Math.random() * 100) + 1` 生成 1—100 随机数，最多猜 7 次，每次给"大了 / 小了"提示，猜中或次数用尽都要输出结果。

---

## 第 4 讲：一维数组的定义与初始化 + 遍历与操作

### 4.1 从"5 个成绩变量"说起

上一讲你会写循环了。假设我给你 5 个学生的成绩 `90 85 78 92 88`，你要求平均分——你打算怎么定义变量？

```java
int s1 = 90, s2 = 85, s3 = 78, s4 = 92, s5 = 88;   // 累不累？
```

那 100 个学生呢？1000 个呢？**这时候需要一个新工具：数组**。

数组（Array）是**一段连续内存空间**，用来存放**同种数据类型**的多个元素。用它，你可以一次定义"一批同类型变量"，用下标区分。

### 4.2 定义语法

推荐写法：**类型加中括号在前**。

```java
int[] scores;        // 推荐（Java 风格）
int scores2[];       // 也合法，但不推荐（C 风格）
```

只声明还不能用，得**初始化**（分配内存）。

### 4.3 三种初始化方式

**方式 1：静态初始化（完整写法）**

```java
int[] scores = new int[]{90, 85, 78, 92};
```

**方式 2：静态初始化（简写）**——只能在**声明的同时**使用

```java
int[] scores = {90, 85, 78, 92};   // ✅
```

> ⚠️ **注意：** 简写只能"声明 + 赋值"一体，不能拆开写。以下代码**报错**：
> ```java
> int[] scores;
> scores = {90, 85, 78, 92};   // ❌ 编译错误
> scores = new int[]{90, 85, 78, 92};   // ✅ 必须用完整写法
> ```

**方式 3：动态初始化**——先定长度，元素为默认值，再逐个赋值

```java
int[] scores = new int[4];    // 长度 4，元素默认为 0
scores[0] = 90;
scores[1] = 85;
scores[2] = 78;
scores[3] = 92;
```

### 4.4 数组的默认值

动态初始化时，各元素被自动填成"零值"，取决于数组类型：

| 元素类型 | 默认值 |
|---------|--------|
| 整数（`byte` / `short` / `int` / `long`） | `0` |
| 小数（`float` / `double`） | `0.0` |
| `char` | `'\u0000'`（空字符） |
| `boolean` | `false` |
| 引用类型（`String`、对象等） | `null` |

### 4.5 访问元素与长度

**索引从 0 开始**——第一个元素是 `arr[0]`，最后一个是 `arr[arr.length - 1]`。

```java
int[] scores = {90, 85, 78, 92};
System.out.println(scores[0]);                        // 90
System.out.println(scores[scores.length - 1]);        // 92
System.out.println(scores.length);                    // 4
```

> ⚠️ **注意：** `数组名.length` 是**属性**（没有括号），不是方法。字符串的长度是方法 `str.length()`——两者别混淆。

### 4.6 内存示意：栈 & 堆

```text
栈里：                       堆里：
┌────────────────┐            ┌────────────────────────┐
│ scores         │  ────►     │ [90, 85, 78, 92]       │
│ 0x1234（地址） │            │ length = 4             │
└────────────────┘            └────────────────────────┘
```

变量 `scores` 存的是**堆里数组对象的地址**（一串数字），数组数据本身在**堆**里连续存放。**数组变量本身只是"指路牌"**——两个变量可以指向同一个数组（下节课讲方法参数传递时会用到）。

### 4.7 遍历方式一：普通 for

```java
int[] scores = {90, 85, 78, 92};
for (int i = 0; i < scores.length; i++) {
    System.out.println("下标 " + i + " → " + scores[i]);
}
```

输出：
```text
下标 0 → 90
下标 1 → 85
下标 2 → 78
下标 3 → 92
```

**优点**：拿得到下标 `i`，可以修改元素（`scores[i] = ...`）。

### 4.8 遍历方式二：增强 for（for-each）

**不需要下标**时首选：

```java
for (int score : scores) {
    System.out.println(score);
}
```

**代价**：
- 拿不到索引。
- **不能修改数组元素**——`score` 只是数组元素值的一份拷贝。

> ⚠️ **注意：** 下面代码**看着能改数组，实际不改**：
> ```java
> for (int s : scores) {
>     s *= 2;   // 只改了拷贝 s，数组本身不变
> }
> ```

### 4.9 常见操作四件套

**求和 / 平均值**：

```java
int[] scores = {90, 85, 78, 92};
int sum = 0;
for (int s : scores) sum += s;
double avg = sum * 1.0 / scores.length;   // sum * 1.0 避免整数除法
System.out.println("总和：" + sum + "，平均：" + avg);
// 输出：总和：345，平均：86.25
```

**求最大值 / 最小值**：

```java
int max = scores[0];
for (int i = 1; i < scores.length; i++) {
    if (scores[i] > max) max = scores[i];
}
System.out.println("最大值：" + max);   // 92
```

**反转数组（就地）**：双指针夹逼——`left` 从 0，`right` 从 `length - 1`，往中间靠。

```java
int left = 0, right = scores.length - 1;
while (left < right) {
    int tmp = scores[left];
    scores[left] = scores[right];
    scores[right] = tmp;
    left++;
    right--;
}
for (int s : scores) System.out.print(s + " ");
// 输出：92 78 85 90
```

### 4.10 两个常见异常

**ArrayIndexOutOfBoundsException（下标越界）**：

```java
int[] arr = {1, 2, 3};
System.out.println(arr[5]);   // 崩溃！数组只有 3 个元素，索引 0-2
```

**NullPointerException（空指针）**：

```java
int[] arr = null;
System.out.println(arr[0]);   // 崩溃！变量还是 null，没指向任何数组
```

### 4.11 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 简写赋值编译错误 | `int[] a; a = {1,2,3};` 不允许；简写只能在声明时用 |
| `arr.length()` 报错 | 数组是属性 `arr.length`，字符串才是方法 `str.length()` |
| 增强 for 修改元素无效 | `for (int x : arr) x = ...` 只改拷贝，数组不变；要改用普通 for |
| `scores[scores.length]` 越界 | 最后一个元素是 `scores[length - 1]`，`length` 本身越界 |
| `int[] a; System.out.println(a[0])` 空指针 | 变量还是 `null`，未初始化就访问 |

### 4.12 练习

1. 定义长度为 10 的 `int` 数组，用 `for` 循环填入 1—10，再用增强 for 输出。
2. 数组 `{5, 3, 9, 1, 7}`，输出最小值、最小值的下标、总和。
3. 判断一个整型数组是否是 **回文数组**（正读和反读一样，如 `{1, 2, 3, 2, 1}`）。
4. 数组 `{2, 4, 6, 8, 10}`，输出每个元素乘 2 后的新数组。
5. **挑战**：定义 `String[]` 存放 5 个人名，故意让其中一个元素为 `null`，用 `if (name != null)` 判空规避 NPE，再遍历打印。

---

## 第 5 讲：数组编程案例 + 元素查找（顺序 + 二分）

### 5.1 从"班级成绩表"说起

上一讲你会数组遍历了。这一讲把它用起来——**综合练习 + 查找算法**。这一讲代码比较密，跟着敲。

### 5.2 综合案例：班级成绩统计

给一个班的成绩数组，一次算出**总分 / 平均分 / 最高 / 最低 / 及格率**。

```java
public class GradeStats {
    public static void main(String[] args) {
        int[] scores = {88, 92, 76, 45, 67, 89, 100, 55};

        int sum = 0;
        int max = scores[0];
        int min = scores[0];
        int passCount = 0;

        for (int s : scores) {
            sum += s;
            if (s > max) max = s;
            if (s < min) min = s;
            if (s >= 60) passCount++;
        }

        double avg = sum * 1.0 / scores.length;
        double passRate = passCount * 100.0 / scores.length;

        System.out.println("总分：" + sum);
        System.out.printf("平均分：%.2f%n", avg);
        System.out.println("最高分：" + max);
        System.out.println("最低分：" + min);
        System.out.printf("及格率：%.2f%%%n", passRate);
    }
}
```

输出：
```text
总分：612
平均分：76.50
最高分：100
最低分：45
及格率：75.00%
```

### 5.3 printf 格式化输出

Java 除了 `println`，还有一个更强的输出方法 `printf`，用于**按模板**输出。

| 占位符 | 含义 | 示例 |
|--------|------|------|
| `%d` | 整数 | `printf("%d", 100)` → `100` |
| `%f` | 小数（默认 6 位） | `printf("%f", 3.14)` → `3.140000` |
| `%.2f` | 小数保留 2 位 | `printf("%.2f", 3.14159)` → `3.14` |
| `%s` | 字符串 | `printf("%s", "hi")` → `hi` |
| `%n` | 换行（跨平台） | 相当于 `\n`，但推荐用 `%n` |
| `%%` | 输出一个百分号 | `printf("%d%%", 90)` → `90%` |

> ⚠️ **注意：** `printf` **不会自动换行**！要换行必须用 `%n` 或 `\n`。

### 5.4 附加案例：随机点名器

```java
import java.util.Random;

public class RandomCall {
    public static void main(String[] args) {
        String[] students = {"张三", "李四", "王五", "赵六", "钱七"};
        Random random = new Random();
        int index = random.nextInt(students.length);   // 生成 [0, length) 的整数
        System.out.println("被点到的同学：" + students[index]);
    }
}
```

每次运行输出一个随机学生名字。`random.nextInt(n)` 生成 `[0, n)` 范围内的随机整数——刚好对应数组下标范围。

### 5.5 顺序查找（Linear Search）

思路：从头到尾一个个比对，找到即返回下标，找不到返回 `-1`。

```java
public static int linearSearch(int[] arr, int target) {
    for (int i = 0; i < arr.length; i++) {
        if (arr[i] == target) {
            return i;
        }
    }
    return -1;
}
```

**时间复杂度**：最坏情况下要看完整个数组，即 O(n)。
**适用场景**：数组无序、长度不大（几十到几千）。
**优点**：简单万能。

### 5.6 二分查找（Binary Search）

**前提**：数组**必须已经有序**（一般是升序）。无序数组用二分等于"抓阄"。

**思路**：每次和数组的**中间元素**比较，缩小一半范围。

```java
public static int binarySearch(int[] arr, int target) {
    int left = 0, right = arr.length - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;   // 防止 (left+right) 溢出
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] < target) {
            left = mid + 1;         // 目标在右半部分
        } else {
            right = mid - 1;        // 目标在左半部分
        }
    }
    return -1;
}
```

**时间复杂度**：O(log n)。**100 万数据最多 20 次比较**——比顺序查找（可能要 100 万次）快 5 万倍。

### 5.7 二分查找的三大坑

**坑 1：`mid = (left + right) / 2` 大数下溢出**

如果 `left = right = 20 亿`，`left + right = 40 亿` **超出 `int` 最大值**（约 21 亿），发生溢出得到负数，`mid` 就错了。

正确写法：`mid = left + (right - left) / 2;`——**减法不会溢出**。

**坑 2：`while (left <= right)` 中 `<=` 不能写成 `<`**

如果写成 `while (left < right)`，数组只剩一个元素时（`left == right`）就退出，那**这最后一个元素就没被检查**——可能漏答案。

**坑 3：忘了要求"数组必须有序"**

二分查找依赖"左半 < mid < 右半"的假设。数组无序，这个假设崩，找什么都是错的。

### 5.8 顺序 vs 二分：对比一张图

| 特性 | 顺序查找 | 二分查找 |
|------|---------|---------|
| 时间复杂度 | O(n) | O(log n) |
| 是否要求有序 | 否 | 是 |
| 实现难度 | 简单 | 中等 |
| 100 万数据最坏比较次数 | 100 万 | 约 20 |
| 适用场景 | 短数组 / 无序 | 长数组 / 已排序 |

### 5.9 完整对照示例

```java
public class SearchDemo {
    public static void main(String[] args) {
        int[] arr = {12, 25, 33, 47, 58, 66, 79, 88, 92};
        System.out.println("顺序查找 66 → 下标 " + linearSearch(arr, 66));
        System.out.println("二分查找 66 → 下标 " + binarySearch(arr, 66));
        System.out.println("二分查找 100 → 下标 " + binarySearch(arr, 100));
    }

    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) return i;
        }
        return -1;
    }

    public static int binarySearch(int[] arr, int target) {
        int left = 0, right = arr.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid] == target) return mid;
            else if (arr[mid] < target) left = mid + 1;
            else right = mid - 1;
        }
        return -1;
    }
}
```

输出：
```text
顺序查找 66 → 下标 5
二分查找 66 → 下标 5
二分查找 100 → 下标 -1
```

> 💡 **建议：** 复用第 3 讲的 Debug 技能——在 `mid = ...` 那一行打断点，`F9` 一路按下去。你能亲眼看到 `left / right / mid` 每一轮如何折半——**这是理解二分查找最好的方式**。

### 5.10 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 二分查找结果错乱 | 数组没排序，或 `<=` 写成 `<` |
| 大数据集下二分越界 | 用了 `(left + right) / 2` 溢出；改用 `left + (right - left) / 2` |
| `printf` 输出连成一行 | 忘了 `%n`，`printf` 不自动换行 |
| 及格率显示 `75.0`，想要 `75.00%` | 用 `%.2f%%` 保留两位小数并加百分号 |
| 顺序查找找不到时忘了返回 `-1` | 循环结束应显式 `return -1;` |

### 5.11 练习

1. 从键盘输入 8 个成绩，输出总分、平均分（保留 2 位）、最高、最低、及格率（保留 1 位并带 `%`）。
2. 实现 `linearSearch` 返回 target 在数组中的**首次出现下标**和**出现次数**（打印两个值即可）。
3. 对有序数组 `{1, 3, 5, 7, 9, 11, 13, 15}` 做二分查找，找 7 和找 4，分别输出结果。
4. **挑战**：给一个升序数组，实现"查找 target 应插入的位置"（找到返回下标；找不到返回它本该插入的位置）。提示：改二分查找退出时返回 `left`。
5. **AI 实战**：让通义灵码帮你实现"二分查找的递归版本"，对比迭代版和递归版的可读性，写一段自己的评价（100 字内）。

---

## 第 6 讲：元素排序（冒泡 + 选择）—— Day02 收官讲

### 6.1 从"上一讲留下的问题"说起

上一讲的**二分查找**有一个铁律：**数组必须有序**。那怎么把一个无序数组变成有序？——**排序**。

Java 的 `Arrays.sort()` 一行代码就能排完，但**我们要学的是"里面到底怎么排"**，因为排序是所有算法思维的入门课。理解冒泡和选择，你就理解了：**"两层循环 + 比较 + 交换"** 这一模式，后续所有排序（快排、归并、堆排）都是它的变体。

### 6.2 冒泡排序（Bubble Sort）

**思路**：像水底气泡浮到水面——**相邻两个元素比较**，大的往后**交换**。一轮下来，最大值到最后位置。n 轮排完。

**核心动作**：`if (arr[j] > arr[j+1]) swap(j, j+1);`

**完整代码（含优化）**：

```java
public static void bubbleSort(int[] arr) {
    int n = arr.length;
    for (int i = 0; i < n - 1; i++) {              // 外层 n-1 轮
        boolean swapped = false;
        for (int j = 0; j < n - 1 - i; j++) {      // 内层每轮少比较一个
            if (arr[j] > arr[j + 1]) {
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
                swapped = true;
            }
        }
        if (!swapped) break;   // 优化：本轮没交换 → 已经有序
    }
}
```

**两个关键细节**：

1. **内层 `j < n - 1 - i` 中的 "- i"**：因为**每轮排好一个最大值**（沉到最后），下一轮的最后 `i` 个位置已经有序，不用再比较。
2. **`swapped` 标志**：如果一整轮下来**一次交换都没有**，说明数组本来就有序，直接跳出——**最好情况变 O(n)**。

**时间复杂度**：
- 最坏（逆序）：O(n²)
- 平均：O(n²)
- 最好（已有序，`swapped` 优化后）：O(n)

**稳定性**：**稳定**——相同元素不换位（因为 `>` 而非 `>=`）。

### 6.3 冒泡执行过程可视化

对 `{5, 2, 4, 6, 1, 3}` 进行冒泡：

| 轮次 | 起始状态 | 本轮结束 |
|------|---------|---------|
| 第 1 轮 | `5 2 4 6 1 3` | `2 4 5 1 3 6`（6 到最后） |
| 第 2 轮 | `2 4 5 1 3 6` | `2 4 1 3 5 6`（5 到倒数第二） |
| 第 3 轮 | `2 4 1 3 5 6` | `2 1 3 4 5 6`（4 到位） |
| 第 4 轮 | `2 1 3 4 5 6` | `1 2 3 4 5 6`（2 到位） |
| 第 5 轮 | `1 2 3 4 5 6` | 无交换，`swapped=false`，跳出 |

### 6.4 选择排序（Selection Sort）

**思路**：每轮**从未排序区选出最小值**，和未排序区的**第一个元素交换**位置。

**核心动作**：先扫一遍找最小值下标，最后**只交换一次**。

```java
public static void selectionSort(int[] arr) {
    int n = arr.length;
    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;                          // 假设当前位置最小
        for (int j = i + 1; j < n; j++) {          // 从未排序区找真正的最小值
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        if (minIndex != i) {                       // 找到更小的就交换
            int tmp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = tmp;
        }
    }
}
```

**关键点**：**一轮只交换一次**（不像冒泡一路交换），比较次数一样多，但**交换次数最少**（最多 n-1 次）。

**时间复杂度**：始终 O(n²)——没有像冒泡那样的"已有序早退"优化。
**稳定性**：**不稳定**——长距离交换可能改变相同元素的相对顺序。例如 `{5a, 5b, 3}`，选最小值 3 与 5a 交换 → `{3, 5b, 5a}`，两个 5 顺序变了。

### 6.5 选择执行过程可视化

对 `{5, 2, 4, 6, 1, 3}` 进行选择：

| 轮次 | 起始 | 找到最小值 | 交换后 |
|------|------|-----------|--------|
| 第 1 轮（i=0） | `5 2 4 6 1 3` | 1（下标 4） | `1 2 4 6 5 3` |
| 第 2 轮（i=1） | `1 2 4 6 5 3` | 2（下标 1，不动） | `1 2 4 6 5 3` |
| 第 3 轮（i=2） | `1 2 4 6 5 3` | 3（下标 5） | `1 2 3 6 5 4` |
| 第 4 轮（i=3） | `1 2 3 6 5 4` | 4（下标 5） | `1 2 3 4 5 6` |
| 第 5 轮（i=4） | `1 2 3 4 5 6` | 5（下标 4，不动） | `1 2 3 4 5 6` |

### 6.6 冒泡 vs 选择

| 对比项 | 冒泡排序 | 选择排序 |
|--------|---------|---------|
| 比较次数 | O(n²) | O(n²) |
| 交换次数 | 多（每次触发条件都换） | 少（每轮最多 1 次） |
| 最好情况 | O(n)（已有序 + swapped 优化） | 始终 O(n²) |
| 稳定性 | 稳定 | 不稳定 |
| 直观性 | 直观（气泡上浮） | 也直观（选最小放前） |

### 6.7 一次完整调用（可直接运行）

```java
public class SortDemo {
    public static void main(String[] args) {
        int[] arr1 = {5, 2, 4, 6, 1, 3};
        bubbleSort(arr1);
        System.out.print("冒泡排序结果：");
        for (int x : arr1) System.out.print(x + " ");
        System.out.println();

        int[] arr2 = {5, 2, 4, 6, 1, 3};
        selectionSort(arr2);
        System.out.print("选择排序结果：");
        for (int x : arr2) System.out.print(x + " ");
    }

    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < n - 1 - i; j++) {
                if (arr[j] > arr[j + 1]) {
                    int tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    }

    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) minIndex = j;
            }
            if (minIndex != i) {
                int tmp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = tmp;
            }
        }
    }
}
```

输出：
```text
冒泡排序结果：1 2 3 4 5 6
选择排序结果：1 2 3 4 5 6
```

### 6.8 Debug 让排序过程可见

排序是**"最适合 Debug 学习"** 的算法：

1. 在内层 `if (arr[j] > arr[j + 1])` 打断点。
2. `Shift + F9` 启动 Debug。
3. Variables 面板 → 展开 `arr` → 你能看到数组每个元素的实时值。
4. 按 `F9` 一轮一轮观察数组变化——你会**亲眼看到"最大值一步步冒到最后"**。

**这个可视化过程比听老师讲十遍都管用**。强烈建议：这道题作为 Debug 训练必做。

### 6.9 生产中怎么排？

日常工作中你**不会手写冒泡 / 选择**，直接用标准库：

```java
import java.util.Arrays;

int[] arr = {5, 2, 4, 6, 1, 3};
Arrays.sort(arr);          // 内部是双轴快排 / 归并排序的混合
System.out.println(Arrays.toString(arr));   // [1, 2, 3, 4, 5, 6]
```

那我们学冒泡 / 选择干什么？—— **学的是思想**：两层循环 + 比较 + 交换，是所有排序、乃至很多算法（去重、合并、找 TopK）的基本骨架。

### 6.10 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 冒泡数组不变 | `>` 写成 `<` 变降序，或交换的三行少了 `int tmp` 中间变量 |
| 冒泡结束还有元素没排好 | 外层次数 `n - 1` 写成 `n - 2` 就少排一轮 |
| 选择排序反复交换但结果错 | 找 minIndex 时循环起点写成 `j = 0` 而不是 `j = i + 1`，把已排好的部分也搅了 |
| `swapped` 优化在乱序数组上没效果 | 优化只对"接近有序"的数据有加速，最坏情况一样 O(n²) |
| 直接把 `arr` 赋给另一个变量再排"以为不改原数组" | 数组是引用！两个变量指向同一堆内存，改一个就改了两个；要用 `arr.clone()` |

### 6.11 练习

1. 对 `{9, 4, 7, 2, 6}` 用冒泡排序 **降序** 排列（提示：`>` 改成 `<`）。
2. 手写选择排序，不看讲义完整跑通。
3. 冒泡排序中加一行 `System.out.println(Arrays.toString(arr))` 到外层循环末尾，观察每一轮结束后的数组状态。
4. **数组去重**：对 `{1, 2, 2, 3, 4, 4, 5}` 去重输出 `{1, 2, 3, 4, 5}`。
5. **排序 + 二分组合**：先冒泡排序，再让用户输入 target 做二分查找，找不到时输出"该数应插入的位置"（用第 5 讲挑战题的思路）。

---

### 6.12 本讲小结

- **冒泡**：相邻比较 + 交换，最大值往后冒，`swapped` 优化下最好 O(n)。
- **选择**：找最小值放前面，交换次数最少，但比较次数不省。
- 两者都是 O(n²) 教学入门算法，实际生产用 `Arrays.sort()`。
- 学它们不是为了自己用，是为了**理解算法思维**。

---

## Day02 全天总结

### 一张图串六讲

```text
第 1 讲 顺序 + if      ─┐
第 2 讲 switch          ┤─ 分支结构：从"按条件选一条路"到"按值查表"
第 3 讲 循环 + Debug   ─┘  再到"按条件重复做一件事"+ 调试武器

第 4 讲 数组基础  ─── 同类型批量存储，索引从 0 开始
第 5 讲 案例 + 查找 ─── 遍历套路、顺序 O(n)、二分 O(log n)
第 6 讲 排序（收官）─── 冒泡 + 选择，两层循环 + 比较 + 交换
```

### 6 讲全局回顾

| 讲次 | 主题 | 一句话总结 |
|------|------|-----------|
| L1 | 顺序 + `if` | 从上到下 / 按条件选路，注意区间顺序 |
| L2 | `switch` | 等值判断利器，`break` 或 `->` |
| L3 | 循环 + Debug | 三种循环 / `break` / `continue` / IDEA 五键 |
| L4 | 数组基础 | 同类型批量存储，索引从 0 开始，`.length` |
| L5 | 数组案例 + 查找 | `printf` / 顺序 O(n) / 二分 O(log n) 三大坑 |
| L6 | 排序 | 冒泡 + 选择，两层循环 + 比较 + 交换 |

### 核心口诀

- **`if-else`** 判连续区间**从紧到宽**排；**`switch`** 判离散等值。
- **循环** 三选一：次数已知 `for`、次数未知 `while`、"至少执行一次" `do-while`。
- **Debug 五键**：断点 F9、单步 F8、进入 F7、跳出 Shift+F8、恢复 F9。
- **数组**：`int[] a = new int[n]`，索引 `[0, n-1]`，越界抛 `ArrayIndexOutOfBoundsException`。
- **顺序查找 O(n)**、**二分查找 O(log n)**（必须先排序）。
- **冒泡** 相邻比较 + 交换、**选择** 找最小放前面；生产环境用 `Arrays.sort()`。

### Day03 预告

明天进入 **第 5 章 二维数组、方法与递归**。你将学会：

- **二维数组**——把"表格数据"（如成绩表）用 `int[][]` 存起来。
- **方法（函数）**——把重复代码封装起来，参数、返回值、值传递 vs 引用传递。
- **递归**——方法自己调用自己，写出斐波那契、汉诺塔的优雅解法。

**方法是"代码复用"的第一步，也是从"会写脚本"到"会构建程序"的分水岭**。今晚请务必完成 Day02 作业，明天早上带着代码来上课。

### Day02 作业汇总

按讲次汇总，方便一次列清单：

**L1（顺序 + if）**

1. 输入年龄，输出"儿童 / 少年 / 成年 / 老年"。
2. 输入整数判断正数 / 负数 / 零。
3. 输入年、月输出该月天数（含闰年判断）。
4. **挑战**：BMI 分档输出。

**L2（switch）**

5. 传统 switch 输出月份英文名。
6. switch 表达式输出等级对应分数区间。
7. 多值合并输出"工作日"或"周末"。
8. **挑战**：用 `switch` 表达式改写成绩分档。

**L3（循环 + Debug）**

9. 打印 100 以内所有质数。
10. 反复整除 2 直到小于 1，输出次数。
11. 打印 5 层等腰星号三角形。
12. **Debug 实战**：故意写整除 Bug，Debug 定位并写修复笔记。
13. **挑战**：猜数字升级版（最多 7 次）。

**L4（数组基础）**

14. 长度 10 数组填入 1—10，两种方式遍历输出。
15. 输出最小值 + 下标 + 求和。
16. 判断回文数组。
17. 每个元素乘 2 输出新数组。
18. **挑战**：`String[]` 判空规避 NPE。

**L5（数组案例 + 查找）**

19. 输入 8 个成绩，输出总分 / 平均 / 最高 / 最低 / 及格率。
20. 顺序查找返回首次下标 + 出现次数。
21. 二分查找有序数组找 7 和找 4。
22. **挑战**：二分查找 target 应插入的位置。
23. **AI 实战**：让 AI 实现递归版二分查找并对比。

**L6（排序 + 收官）**

24. 冒泡降序排序 `{9, 4, 7, 2, 6}`。
25. 手写选择排序。
26. 冒泡加日志观察每轮状态。
27. 数组去重。
28. **综合**：先冒泡排序 + 二分查找 + 查找 target 插入位置。

**Day02 结课！明天见 Day03。**
