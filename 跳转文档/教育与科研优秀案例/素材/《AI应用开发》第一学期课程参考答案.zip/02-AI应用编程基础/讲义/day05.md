# AI 应用编程基础——Java 基础 - 学生讲义（Day05：第 1—7 讲）

**总课时：7 讲**
**适用对象：计算机、软件工程、AI 相关专业本科一、二年级学生**
**对应教材：** 第 9 章《多态、final、静态成员、Math 工具类》 + 第 10 章《抽象类、接口、枚举、Record 与异常处理入门》
**版本基线：JDK 25 LTS · IntelliJ IDEA 2026.1**

## 本日概览

| 讲次 | 主题 | 覆盖章节 |
|------|------|----------|
| 第 1 讲 | 多态：父类引用指向子类对象 | 9.1 |
| 第 2 讲 | `final` 关键字 + 静态变量 / 静态方法 | 9.2、9.3 |
| 第 3 讲 | `Math` 工具类 | 9.4 |
| 第 4 讲 | 抽象类与抽象方法 | 10.1 |
| 第 5 讲 | 接口 | 10.2 |
| 第 6 讲 | 枚举与 Record | 10.3、10.4 |
| 第 7 讲 | 异常处理入门（本日收官） | 10.5 |

**本日主线：** 上午三讲把"面向对象三大特性"最后一块拼图——**多态**——补齐，并把 `final / static / Math` 这一组工具类基本功打扎实；下午三讲跳到"约束和契约"层面——**抽象类**告诉子类必须做什么、**接口**规定能做什么、**枚举与 Record** 用一行代码消灭样板；最后一讲**异常处理入门**——让程序在意外面前"不再一崩了之"，为明天的 String / 包装类打预防针。到 Day05 结束，Java 面向对象体系的"骨架"就成型了。

---

## 第 1 讲：多态：一次调用，多种表现

### 1.1 上课先问一句

上一天我们已经能写出 `class Dog extends Animal`，让 `Dog` 重写父类的 `makeSound()`。现在我给你一段代码：

```java
Animal a = new Dog();
a.makeSound();
```

请你先在脑子里跑一遍：这句 `a.makeSound()` 打印的是父类那句\"动物在叫\"，还是 `Dog` 里重写过的\"汪汪汪\"？

——大多数人第一次会回答\"动物在叫\"，理由是\"`a` 声明为 `Animal`\"。**实际输出是\"汪汪汪\"。** 这个\"意料之外\"就是我们本讲要讲清楚的一件事：**多态（polymorphism）**。

### 1.2 什么是多态

多态一句话说清楚：**同一个方法调用，因为对象的实际类型不同而表现出不同行为。**

实现多态需要三件事同时成立，我们叫它\"三要素\"：

1. **继承或实现关系**。要么 `Dog extends Animal`，要么 `Duck implements Flyable`。
2. **子类重写父类方法**。`Dog` 必须自己写一份 `makeSound()`。
3. **父类引用指向子类对象**。也就是 `Animal a = new Dog();` 这一句。

三个条件缺一不可。想清楚了这三条，再去看下面的对比表，就懂了：

| 视角 | 看什么 | 决定什么 |
|------|--------|----------|
| 编译期 | 声明类型（`Animal a`） | \"能不能调用这个方法\"（编译能否通过） |
| 运行期 | 实际类型（`new Dog()`） | \"具体执行哪个版本的方法\" |

编译期看\"你手里的门牌号\"，运行期看\"你屋里真正住的是谁\"。这种\"运行期才确定调哪个版本\"的机制，学名叫**动态绑定（dynamic binding）**。

### 1.3 完整例子：Animal / Dog / Cat

我们把上面那句话写成一整段代码，跑一次，再一起分析：

```java
public class Animal {
    public void makeSound() {
        System.out.println("动物在叫");
    }
}

public class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("汪汪汪");
    }
    public void watchHome() {
        System.out.println("看家");
    }
}

public class Cat extends Animal {
    @Override
    public void makeSound() {
        System.out.println("喵喵喵");
    }
}

public class PolymorphismDemo {
    public static void main(String[] args) {
        Animal[] animals = { new Dog(), new Cat(), new Dog() };
        for (Animal a : animals) {
            a.makeSound();
        }
    }
}
```

运行输出：

```text
汪汪汪
喵喵喵
汪汪汪
```

请注意这段代码里 `for` 循环的形参是 `Animal a`——**这个循环体一辈子都不用改**。以后你新增一个 `Bird extends Animal`，只要往数组里塞一个 `new Bird()`，`for` 里的 `a.makeSound()` 就会自动帮你调 `Bird` 的版本。

这就是多态最大的价值：**开闭原则**——对扩展开放，对修改封闭。

### 1.4 多态的一个重要限制

多态是有代价的。**编译期只认声明类型的成员**，子类独有的方法你**通过父类引用调不到**：

```java
Animal a = new Dog();
a.makeSound();       // ✔ Animal 里有
// a.watchHome();    // ❌ Dog 独有，编译报错
```

编译器只看 `a` 的门牌号是 `Animal`——`Animal` 类里没有 `watchHome()`，所以\"编译期\"这一步就过不去。

想调用子类独有的方法，必须**先把父类引用转回子类引用**，这叫**向下转型**。

### 1.5 向上转型 vs 向下转型

- **向上转型**：子 → 父。**自动完成、绝对安全**。`Animal a = new Dog();`
- **向下转型**：父 → 子。**必须强制、可能出错**。

```java
Animal a = new Dog();
Dog d = (Dog) a;      // ✔ 实际就是 Dog
d.watchHome();

Animal a2 = new Cat();
Dog d2 = (Dog) a2;    // ❌ 运行时抛 ClassCastException
```

**安全做法**：先 `instanceof` 判断，再强转：

```java
if (a instanceof Dog) {
    Dog d = (Dog) a;
    d.watchHome();
}
```

**JDK 16+** 的模式匹配（pattern for `instanceof`）更清爽——判断和声明变量一步到位：

```java
if (a instanceof Dog d) {
    d.watchHome();
}
```

从 Day04 起我们用的就是 JDK 25，所以尽量用后面这种写法。

### 1.6 字段不参与多态（重要！）

多态**只对方法起作用**。**字段是静态绑定**，看声明类型：

```java
class Parent { int x = 1; }
class Child extends Parent { int x = 2; }

Parent p = new Child();
System.out.println(p.x);   // 输出 1，不是 2
```

为什么？因为字段访问在编译期就把\"从谁那儿取 x\"绑死了，运行期不再改。这个规则背后是 JVM 的字段解析机制——不用深究，**结论记住就行**：字段静态绑定，方法动态绑定。

**日常开发的启示**：**不要在子类里定义与父类同名的字段**，这几乎百分之百是个 bug 温床。父类字段用 `protected`，子类通过继承直接用。

### 1.7 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `Animal a = new Dog(); a.watchHome();` 编译报错 | 编译期只认声明类型 `Animal`，`Animal` 里没有 `watchHome` |
| `Dog d = (Dog) new Cat();` 运行时报 `ClassCastException` | 向下转型对象实际类型不匹配 |
| `Parent p = new Child(); p.x` 输出父类的 `x` | 字段静态绑定，不参与多态 |
| `if (a instanceof Dog d)` 编译报错 | 使用的 JDK 版本低于 16；升级到 JDK 25 或改用旧写法 |
| 忘写 `@Override` 却把方法名拼错了 | 变成了子类新方法，多态调不到；养成加 `@Override` 的习惯 |

### 1.8 练习 / 思考

1. 定义 `Shape` 父类和 `Circle`、`Rectangle` 两个子类，各自重写 `area()`。用 `Shape[]` 一次求出总面积并打印。
2. 在上题基础上加一个静态方法 `printSpecial(Shape s)`：如果是 `Circle` 打印半径，如果是 `Rectangle` 打印长宽（用模式匹配写法）。
3. **思考题**：为什么下面这段代码 `p.x` 打印 `1` 而不是 `2`？如果我想拿到子类的 `x`，只能怎么写？

```java
class Parent { int x = 1; }
class Child extends Parent { int x = 2; }
Parent p = new Child();
System.out.println(p.x);
```

4. **AI 实战**：让 AI 编程助手为你解释「JDK 16 的 pattern for instanceof 相对旧写法节省了几行代码？如何理解\"声明与判断合一\"？」，并让它给一个只在旧 JDK 能编译、在新 JDK 有更好写法的对比示例。

---

## 第 2 讲：`final` 关键字 + 静态变量 / 静态方法

### 2.1 从两个问题开始

我先问两个真实开发中经常遇到的问题：

**问题 1：** 我想定义一个 π 值，它一旦定义就**永远不能被别人改**——怎么写？
**问题 2：** 我想统计\"当前一共创建了多少个 `Student` 对象\"。这个计数变量既不该放在某一个学生对象里（那样每个学生一份，互不相干），也不该放在外面（那样封装被破坏）。它应该属于\"类本身\"——怎么写？

这两个问题分别引出本讲的两个关键字：**`final`**（不可变的）和 **`static`**（属于类的）。它们常常搭配使用，最常见的组合是 `public static final XXX = ...` 用来定义常量。

### 2.2 `final` 的三种用法

`final` 意为\"最终的、不可变的\"，可以修饰**变量、方法、类**：

| 修饰对象 | 效果 | 示例 |
|----------|------|------|
| 变量 | 一旦赋值，不可再改 | `final int MAX = 100;` |
| 方法 | 不可被子类重写 | `public final void hello() {}` |
| 类 | 不可被继承 | `public final class String {}` |

#### 2.2.1 `final` 变量

```java
final int MAX_SCORE = 100;
// MAX_SCORE = 200;   // ❌ 编译错误
```

命名习惯：**全大写、下划线分词**，如 `MAX_SCORE`、`DEFAULT_TIMEOUT`。

`final` 变量必须赋初值——可以在声明时赋，也可以在构造方法里赋（对字段而言）：

```java
class Order {
    final String orderId;
    public Order(String id) {
        this.orderId = id;   // ✔ 构造方法里赋值也算
    }
}
```

**修饰引用类型时的关键规则**：**引用不可再指向新对象，但对象内容可以改**。

```java
final int[] arr = {1, 2, 3};
arr[0] = 10;          // ✔ 修改内容
// arr = new int[5]; // ❌ 引用不能变
```

这一条特别容易搞错。记住：**`final` 锁的是\"这个变量存的地址\"，不是\"地址指向的那块内存\"**。

#### 2.2.2 `final` 方法

`final` 方法**不能被子类重写**。用于\"这个方法的实现是固定的，子类不许改\"：

```java
public class Parent {
    public final void hello() { System.out.println("Hi"); }
}
public class Child extends Parent {
    // @Override public void hello() {}  // ❌ 编译报错
}
```

一个典型例子：等会儿讲抽象类时看到的**模板方法模式**，模板方法本身就是 `final` 的——固定流程不许改。

#### 2.2.3 `final` 类

`final` 类**不能被继承**：

```java
public final class String { ... }        // JDK 里 String 就是 final 类
public class MyString extends String { } // ❌ 编译报错
```

JDK 把 `String / Integer / Long` 等所有**不可变类**都标记为 `final`——防止别人写子类\"篡改\"这些类的行为，破坏它们不可变的约定。

#### 2.2.4 常量的推荐写法

`final` 最常见的用法：搭 `public static` 一起定义常量：

```java
public class Constants {
    public static final double PI = 3.14159265358979;
    public static final int MAX_STUDENT = 50;
}

double area = Constants.PI * r * r;
```

命名全大写、下划线分词。这个组合我们几乎每天都会用到——包括马上要讲的 `Math.PI`、`Integer.MAX_VALUE`。

### 2.3 `static` 静态变量与静态方法

`static` 意为\"静态的、属于类的\"。被 `static` 修饰的成员**属于类本身**，不属于某一个具体对象——所有对象**共享同一份**。

#### 2.3.1 静态变量（类变量）

```java
public class Student {
    static int totalCount;    // 静态变量，全体 Student 共享
    String name;              // 实例变量，每对象一份

    public Student(String name) {
        this.name = name;
        totalCount++;         // 每 new 一个就 +1
    }
}
```

调用测试：

```java
new Student("张三");
new Student("李四");
new Student("王五");
System.out.println(Student.totalCount);   // 3
```

**访问方式：推荐用类名访问**，如 `Student.totalCount`。虽然 `对象.静态变量` 也能编译通过，但语义混乱——静态变量并不属于对象。

#### 2.3.2 静态方法（类方法）

```java
public class MathUtils {
    public static int max(int a, int b) {
        return a > b ? a : b;
    }
}

int m = MathUtils.max(3, 5);   // 直接类名调用，无需 new
```

**静态方法的三条硬规则**：

1. 只能访问**静态**成员。因为静态方法可能在**任何对象存在之前**就被调用（比如 `main` 就是静态方法），此时实例字段还不存在。
2. **不能使用 `this` 和 `super`**。原因同上——没有\"当前对象\"这个概念。
3. 常用于**工具类**（Utils），配合 `private` 构造方法防止实例化：

```java
public final class MathUtils {
    private MathUtils() {}   // 私有构造，禁止外部 new
    public static int max(int a, int b) { return a > b ? a : b; }
}
```

`final class` + `private` 构造 + `static` 方法——这三件套是**工具类的标准写法**。JDK 里的 `java.lang.Math` 就是这么设计的（我们下一讲就会看到）。

#### 2.3.3 静态代码块

`static { ... }` 是**静态代码块**，**类被加载时执行一次**，用来初始化静态资源：

```java
public class DbConfig {
    public static final String URL;
    static {
        URL = System.getenv().getOrDefault("DB_URL", "jdbc:mysql://localhost:3306/test");
        System.out.println("DbConfig 已初始化");
    }
}
```

第一次访问 `DbConfig` 任意成员时，JVM 会加载这个类，然后立刻执行 `static { ... }` 里的代码——**只执行一次**。

#### 2.3.4 静态 vs 实例 对比表

| 维度 | 静态成员 | 实例成员 |
|------|----------|----------|
| 归属 | 类 | 对象 |
| 内存 | 方法区（一份） | 每对象一份 |
| 访问 | 类名. 或 对象.（推荐类名） | 对象. |
| 静态方法能否访问实例成员 | ❌ 不能 | 实例方法**能**访问静态成员 |

背下这张表。特别是最后一行——\"静态不能访问实例，但实例可以访问静态\"。

### 2.4 综合示例：Order 类

把上面所有点串起来：

```java
public class Order {
    private static int nextId = 1;              // 静态变量：ID 生成器
    public static final String PREFIX = "ORD";  // 静态常量
    private final String orderId;               // final 实例字段：一旦创建不可改
    private String customer;                    // 实例字段：可改

    public Order(String customer) {
        this.orderId = PREFIX + nextId;
        this.customer = customer;
        nextId++;
    }

    public static int getNextId() { return nextId; }   // 静态方法
    public String getOrderId() { return orderId; }     // 实例方法
}

public class OrderDemo {
    public static void main(String[] args) {
        Order o1 = new Order("张三");
        Order o2 = new Order("李四");
        System.out.println(o1.getOrderId());     // ORD1
        System.out.println(o2.getOrderId());     // ORD2
        System.out.println(Order.getNextId());   // 3
    }
}
```

看清了没？`nextId` 全体共享（每次 `new` 都 +1）；`orderId` 每对象一份且**不可改**——这就是 `final + static` 的经典搭配。

### 2.5 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `final int[] arr = ...; arr = new int[5];` 报错 | `final` 锁的是引用，不是内容——引用不能重新指向 |
| `static void foo() { this.x = 1; }` 报错 | 静态方法没有\"当前对象\"，不能用 `this` |
| 静态方法里访问实例字段报错 | 静态方法执行时，实例字段可能还不存在 |
| `final int x;` 声明了不赋值也不在构造里赋值 | 编译报错\"变量可能未初始化\"，`final` 必须初始化 |
| 常量名用小写（如 `final int max`） | 语法合法但违反命名习惯，团队代码审查会打回 |

### 2.6 练习 / 思考

1. 定义 `MathConstants` 类，包含 `PI`、`E`、`MAX_INT` 三个 `public static final` 常量，用一段代码调用它们。
2. 给 `Book` 类加一个 `static int totalBooks`，每 `new` 一本 +1；写一个静态方法 `getTotalBooks()` 返回当前值。
3. 写一个 `StringUtils` 工具类，遵循\"final class + private 构造 + static 方法\"范式，包含 `isEmpty(String)` 和 `reverse(String)` 两个方法。
4. **思考题**：为什么 `String` 类被声明为 `final class`？如果它不是 `final` 的，会带来什么安全问题？
5. **AI 实战**：让 AI 编程助手解释「Java 静态代码块和实例代码块的执行顺序」，并用一个包含继承（Parent → Child）的例子验证它给出的顺序是否正确。

---

## 第 3 讲：`Math` 工具类

### 3.1 承接一下上一讲

上一讲我们自己写了一个 `MathUtils`，遵循\"final class + private 构造 + static 方法\"三件套的范式。这是自己造轮子——真实开发中你几乎不用自己写这么一个类，因为 **JDK 早在 1.0 时代就送了你一个功能完整的、名字更短的工具类：`java.lang.Math`**。

再补一句：`Math` 位于 `java.lang` 包，而 **`java.lang` 是默认导入的**——所以我们**不用写 `import java.lang.Math;`**，直接 `Math.xxx(...)` 就能用。

本讲要做三件事：
1. 把常用方法过一遍——列一张表，告诉你什么场景用什么。
2. 讲清\"随机数\"这一常考、常错的话题。
3. 用\"猜数字\"小游戏做综合演练。

### 3.2 常用方法一览

12 个高频方法，一张大表看清楚：

| 方法 | 说明 | 示例 |
|------|------|------|
| `Math.abs(x)` | 绝对值 | `Math.abs(-3)` → 3 |
| `Math.max(a, b)` | 较大值 | `Math.max(3, 5)` → 5 |
| `Math.min(a, b)` | 较小值 | `Math.min(3, 5)` → 3 |
| `Math.pow(a, b)` | a 的 b 次方 | `Math.pow(2, 10)` → 1024.0 |
| `Math.sqrt(x)` | 平方根 | `Math.sqrt(9)` → 3.0 |
| `Math.cbrt(x)` | 立方根 | `Math.cbrt(27)` → 3.0 |
| `Math.ceil(x)` | 向上取整 | `Math.ceil(3.2)` → 4.0 |
| `Math.floor(x)` | 向下取整 | `Math.floor(3.8)` → 3.0 |
| `Math.round(x)` | 四舍五入 | `Math.round(3.6)` → 4 |
| `Math.random()` | `[0.0, 1.0)` 的随机小数 | 随机值 |
| `Math.PI` | 圆周率常量 | 3.14159... |
| `Math.E` | 自然常数 | 2.71828... |

**三个必须记住的返回值类型陷阱：**

1. `Math.pow(int, int)` 返回 **`double`**——即使参数都是 `int`。所以 `int r = Math.pow(2, 10);` 编译报错，得写成 `int r = (int) Math.pow(2, 10);`。
2. `Math.round(float)` 返回 **`int`**，`Math.round(double)` 返回 **`long`**——两个重载，返回类型不一样。
3. `Math.ceil / Math.floor` 都返回 **`double`**——想要 `int` 得手动强转。

### 3.3 生成随机整数（重点）

`Math.random()` 返回 `[0.0, 1.0)` 的 `double`。**它自己不会给你整数**——你要通过乘法和强转\"造\"出想要的区间。

黑板推导：

```text
Math.random()                                → [0.0, 1.0)
Math.random() * 100                          → [0.0, 100.0)
(int)(Math.random() * 100)                   → 0 ~ 99   （强转向 0 截断）
(int)(Math.random() * 100) + 1               → 1 ~ 100
(int)(Math.random() * (max - min + 1)) + min → min ~ max
```

**最后一行公式** 是常考的——请你现在就在草稿纸上推导一次：`max = 10, min = 5`，代进去看看能不能生成 5~10 的整数。

```java
int n = (int) (Math.random() * 100);          // 0 ~ 99
int n2 = (int) (Math.random() * 100) + 1;     // 1 ~ 100
int max = 10, min = 5;
int n3 = (int) (Math.random() * (max - min + 1)) + min;   // 5 ~ 10
```

### 3.4 更推荐：`java.util.Random`

如果你要**连续生成大量随机数**，用 `java.util.Random` 更好——性能更好、语义更清晰、还可以设置\"种子\"来复现随机序列：

```java
import java.util.Random;

Random r = new Random();
int n = r.nextInt(100);        // 0 ~ 99
int n2 = r.nextInt(100) + 1;   // 1 ~ 100
```

**经验法则**：单次简单场景用 `Math.random()` 无所谓；多次或需要控制的场景用 `Random`。

### 3.5 示例：圆面积、球体积

```java
public class MathDemo {
    public static void main(String[] args) {
        double r = 5;
        double area = Math.PI * Math.pow(r, 2);
        double volume = 4.0 / 3 * Math.PI * Math.pow(r, 3);
        System.out.printf("面积 = %.2f，体积 = %.2f%n", area, volume);
    }
}
```

输出：

```text
面积 = 78.54，体积 = 523.60
```

**特别注意** `4.0 / 3` 里的 `4.0`——如果写成 `4 / 3` 结果是**整数除法** = 1，体积就全错了。

### 3.6 综合示例：猜数字游戏

一段完整可运行的小游戏，把随机数、循环、`Scanner` 全串起来：

```java
import java.util.Scanner;

public class GuessGame {
    public static void main(String[] args) {
        int target = (int) (Math.random() * 100) + 1;   // 1 ~ 100
        Scanner sc = new Scanner(System.in);
        int guess, times = 0;
        do {
            System.out.print("请输入 1—100 的数字：");
            guess = sc.nextInt();
            times++;
            if (guess > target) {
                System.out.println("大了");
            } else if (guess < target) {
                System.out.println("小了");
            }
        } while (guess != target);
        System.out.println("恭喜，第 " + times + " 次猜中。");
        sc.close();
    }
}
```

跑一次：

```text
请输入 1—100 的数字：50
大了
请输入 1—100 的数字：25
小了
请输入 1—100 的数字：37
大了
请输入 1—100 的数字：31
恭喜，第 4 次猜中。
```

### 3.7 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `(int) Math.random() * 100` 永远是 0 | 强转优先级高于乘法：先 `(int) 0.xxx` = 0，再 `0 * 100 = 0`。必须整体括号：`(int)(Math.random() * 100)` |
| `int r = Math.pow(2, 10);` 编译报错 | `Math.pow` 返回 `double`，要 `int` 得强转 |
| `Math.round(3.6)` 是 `int` 还是 `long`？ | 传 `double` → `long`；传 `float`（如 `3.6f`）→ `int` |
| `Math.ceil(3.0) == 3.0` 而不是 `4.0` | 参数本身就是整数时向上取整就是自己 |
| `4 / 3 * Math.PI` 结果偏小 | 整数除法丢掉小数——写 `4.0 / 3` 或 `4 / 3.0` |

### 3.8 练习 / 思考

1. 用 `Math.random()` 生成 10 个 `[50, 100]` 的随机整数并求平均值。
2. 输入一个正整数 `n`，用 `Math.sqrt` 判断它是否是完全平方数（提示：判断 `sqrt(n)` 强转成 `int` 后平方是否等于原数）。
3. 完成\"猜数字\"游戏并加**最多 10 次**限制，超过 10 次输出正确答案。
4. **挑战**：写一个 `LotteryUtils.generateRedBalls()`，返回 6 个 `1—33` 的**不重复**红球号（提示：`java.util.Set<Integer>` 判重直到集合大小达到 6，然后转成 `int[]`）。
5. **AI 实战**：让 AI 编程助手写一个\"双色球号码生成器\"（6 红 + 1 蓝），并让它解释\"不重复\"是怎么做到的，检查它给的写法有没有边界 bug（例如死循环、越界）。

---

## 第 4 讲：抽象类与抽象方法

### 4.1 一个让你不舒服的方法

回到第 1 讲的 `Animal.makeSound()`：

```java
public class Animal {
    public void makeSound() {
        System.out.println("动物在叫");
    }
}
```

有没有觉得**\"动物在叫\"这几个字很没意义**？世界上根本不存在\"动物\"这种具体生物，只存在猫、狗、鸟。`Animal` 存在的意义只是\"归纳共性 + 让子类去重写\"。既然如此，**为什么还要给 `makeSound()` 写一个默认方法体？**

理想情况应该是：**父类只声明\"我子类应该有这个方法\"，但**不给实现**——具体怎么叫，让每一个子类自己去写**。

这正是 Java 的 **`abstract`（抽象）** 机制。

### 4.2 抽象方法与抽象类

**抽象方法**：只声明方法签名，**不写方法体**，用 `abstract` 修饰、以 `;` 结尾。

**抽象类**：包含抽象方法的类**必须**声明为 `abstract`；反过来，抽象类**不一定**要包含抽象方法（但通常都会）。

```java
public abstract class Animal {
    protected String name;
    public Animal(String name) { this.name = name; }

    public abstract void makeSound();      // 抽象方法：没有 { }，以 ; 结尾

    public void eat() {                     // 普通方法：抽象类也能有
        System.out.println(name + " 在吃饭");
    }
}
```

**记住三个关键点**：
1. `abstract class Xxx { ... }` — 类前有 `abstract`。
2. `abstract void yyy();` — 方法前有 `abstract`，**没有方法体**，末尾是分号。
3. \"含抽象方法 → 类必须抽象\"，反之不必。

### 4.3 抽象类的四条关键规则

| 规则 | 含义 |
|------|------|
| **不能实例化** | `new Animal("x")` 编译报错——抽象类只是模板 |
| **子类必须重写所有抽象方法**，否则子类也必须声明为 `abstract` | 强制子类给出实现 |
| **可以有构造方法**，但只能被子类的 `super(...)` 调用 | 用于初始化父类字段 |
| **可以有成员变量、普通方法、静态方法** | 与普通类一样 |

来看第一条规则被违反时的效果：

```java
Animal a = new Animal("狗");   // ❌ 编译错误：Animal is abstract; cannot be instantiated
```

第二条规则——子类必须重写抽象方法：

```java
public class Dog extends Animal {
    public Dog(String name) { super(name); }
    @Override public void makeSound() { System.out.println("汪汪汪"); }
}
```

如果 `Dog` 里忘了写 `makeSound()`，编译器会怼你：**\"class must be declared abstract or implement makeSound()\"**——要么你也声明为 `abstract`，要么实现它，二选一。

第三条规则——抽象类**有构造方法**。它不是给 `new` 用的，而是给子类的 `super(...)` 用的：

```java
public Dog(String name) {
    super(name);   // ✔ 调抽象类的构造方法
}
```

第四条规则不用多说，前面例子里 `eat()` 就是抽象类里的普通方法。

### 4.4 抽象类的经典用途：模板方法模式

抽象类最主要的价值不是\"防止实例化\"——那只是副产品。它真正的价值是**规范一个流程**：**父类定义骨架，子类填充细节**。这叫**模板方法模式**（Template Method Pattern）。

举一个泡饮料的例子——不管你泡咖啡还是泡茶，流程都是：**烧水 → 冲泡 → 倒进杯子 → 加调料**。其中\"烧水\"和\"倒进杯子\"两步对所有饮料都一样；\"冲泡\"和\"加调料\"两步各不相同。

```java
public abstract class Beverage {
    /** 模板方法：固定流程，final 防止子类改流程 */
    public final void prepare() {
        boilWater();
        brew();               // 交给子类
        pourInCup();
        addCondiments();      // 交给子类
    }

    void boilWater() { System.out.println("烧水"); }
    void pourInCup() { System.out.println("倒进杯子"); }
    protected abstract void brew();
    protected abstract void addCondiments();
}
```

子类只填两个空：

```java
public class Coffee extends Beverage {
    @Override protected void brew() {
        System.out.println("冲咖啡");
    }
    @Override protected void addCondiments() {
        System.out.println("加糖和奶");
    }
}

public class Tea extends Beverage {
    @Override protected void brew() {
        System.out.println("泡茶叶");
    }
    @Override protected void addCondiments() {
        System.out.println("加柠檬");
    }
}
```

调用：

```java
public class BeverageDemo {
    public static void main(String[] args) {
        new Coffee().prepare();
        System.out.println("---");
        new Tea().prepare();
    }
}
```

输出：

```text
烧水
冲咖啡
倒进杯子
加糖和奶
---
烧水
泡茶叶
倒进杯子
加柠檬
```

看清没有？**流程被父类锁死**（因为 `prepare()` 是 `final`——子类不能改流程），**细节交给子类**（`brew` 和 `addCondiments` 是 `abstract`——子类必须填）。这就是\"骨架 - 细节\"分离——面向对象设计的一个金句。

### 4.5 抽象类 vs 普通类 对比

| 维度 | 普通类 | 抽象类 |
|------|--------|--------|
| 关键字 | `class` | `abstract class` |
| 能否 `new` | 能 | ❌ 不能 |
| 能否包含抽象方法 | ❌ 不能 | 能 |
| 是否必须被继承 | 不强制 | 通常都被继承 |
| 构造方法 | 直接给 `new` 用 | 只能被 `super(...)` 调用 |

### 4.6 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `new Animal("x")` 编译报错 | 抽象类不能实例化，只能被继承 |
| 子类没重写抽象方法，编译报错 | 子类要么实现所有抽象方法，要么自己也是抽象类 |
| `abstract void foo() { }` 编译报错 | 抽象方法**不能有方法体**（一个也不行，包括空 `{}`） |
| \"抽象类没有构造方法\" | ❌ 有。子类必须用 `super(...)` 调它 |
| `abstract` 方法加 `private` / `final` / `static` | 编译报错——都与\"必须被重写\"的语义冲突 |

### 4.7 练习 / 思考

1. 把第 1 讲的 `Shape` 改成 `abstract class`，`area()` 改成抽象方法，`Circle / Rectangle / Triangle` 各自实现。用 `Shape[]` 求总面积。
2. 定义抽象类 `Employee`（`name / baseSalary` + 抽象方法 `calcSalary()`），子类 `Manager`（底薪 + 20% 提成）、`Engineer`（底薪 + 项目奖金）。
3. 用模板方法模式模拟\"银行业务办理\"：抽象类 `BankBusiness` 骨架 `queue → verify → doWork → feedback`，其中 `doWork` 抽象；子类 `Deposit / Withdraw / Transfer` 各自实现。
4. **思考题**：模板方法 `prepare()` 里为什么加 `final`？如果去掉，让子类重写 `prepare()` 时跳过 `brew()`——这为什么破坏了\"模板方法\"的意图？
5. **AI 实战**：让 AI 编程助手用一个非饮料的场景（比如\"考试流程\"或\"网页请求处理\"）再写一个模板方法示例，检查它是否正确使用 `final` 锁定骨架、`abstract` 声明可变细节。

---

## 第 5 讲：接口

### 5.1 一个比喻：USB 接口

你有没有想过——为什么你的电脑 USB 口，键盘能插、鼠标能插、U 盘能插、手机充电线也能插？**USB 只规定了物理形状和信号协议**，不关心你到底是谁、内部构造如何。**只要你符合规范，就能连**。

**这就是接口（interface）：一份协议，一个契约。它不问你是什么，只问你能做什么。**

对比一下抽象类：
- 抽象类是**父亲**——是"我是什么"的问题，代表**继承关系（is-a）**。狗是动物、圆是形状。一个人只能有一个亲生父亲，所以 Java 单继承。
- 接口是**技能证书**——是"我能做什么"的问题，代表**能力关系（can-do）**。会飞、可比较、可序列化。一个人可以有多本证书，所以 Java 可以多实现。

这个"父亲 vs 证书"的类比请务必记住——本讲后面所有内容都是它的展开。

### 5.2 接口的定义与实现

**定义接口：用 `interface` 关键字（不是 `class`）**

```java
public interface Runnable {
    void run();           // 抽象方法。默认修饰符 public abstract
}
```

**实现接口：用 `implements` 关键字**

```java
public class MyTask implements Runnable {
    @Override
    public void run() {
        System.out.println("任务在运行");
    }
}
```

三个语法要点：

1. `interface` 代替 `class`。
2. 接口里的**抽象方法默认就是 `public abstract`**——你写不写这两个修饰符都一样，通常省略。
3. 类实现接口用 `implements`（复数或不同接口用逗号隔开）。

### 5.3 单继承 + 多实现（Java 的"折中方案"）

C++ 允许一个类**多继承**多个父类，但会引发"菱形继承"等复杂问题。Java 的设计是：

> **一个类只能有一个父类（`extends`），但可以实现多个接口（`implements`）。**

组合起来写：

```java
public interface Flyable { void fly(); }
public interface Swimmable { void swim(); }

public class Duck extends Animal implements Flyable, Swimmable {
    public Duck(String name) { super(name); }

    @Override public void makeSound() { System.out.println("嘎嘎"); }
    @Override public void fly() { System.out.println(name + " 飞起来了"); }
    @Override public void swim() { System.out.println(name + " 游起来了"); }
}
```

`Duck` 一次得到了三重身份：
- 是一只 `Animal`（继承来的，`is-a` 关系）
- 能 `Flyable`（实现的，`can-do` 关系）
- 能 `Swimmable`（实现的，`can-do` 关系）

调用时可以从任一角度看它：

```java
Duck d = new Duck("唐老鸭");
d.makeSound();

Animal a = d;         // 向上转型：把它当 Animal 看
a.makeSound();

Flyable f = d;        // 把它当 Flyable 看
f.fly();

Swimmable s = d;      // 把它当 Swimmable 看
s.swim();
```

**这就是接口的强大之处**：同一个对象，可以从多个不同视角\"塑造\"其能力——这是策略模式、依赖注入、面向接口编程等所有软件工程模式的基石。

### 5.4 接口的五种成员（重点）

JDK 从 1.0 一路演化到 21，接口能包含的成员越来越多。到今天有五种：

| 成员类型 | 默认修饰符 | 出现版本 | 说明 |
|----------|-----------|---------|------|
| **抽象方法** | `public abstract` | JDK 1.0 | 实现类必须重写 |
| **常量** | `public static final` | JDK 1.0 | 必须赋初值 |
| **`default` 方法** | `public` | JDK 8 | 有方法体，实现类可选择重写 |
| **`static` 方法** | `public` | JDK 8 | 只能通过接口名调用 |
| **`private` 方法** | `private` | JDK 9 | 供接口内部复用，不对外 |

举个 5 种成员都用到的示例：

```java
public interface Calculator {
    // 常量（默认 public static final）
    int MAX_VALUE = 1000;

    // 抽象方法（默认 public abstract）
    int compute(int a, int b);

    // default 方法：JDK 8+
    default int computeSafe(int a, int b) {
        if (a > MAX_VALUE || b > MAX_VALUE) {
            log("值超出上限");
            return -1;
        }
        return compute(a, b);
    }

    // static 方法：JDK 8+
    static Calculator identity() {
        return (a, b) -> a;
    }

    // private 方法：JDK 9+
    private void log(String msg) {
        System.out.println("[Calc] " + msg);
    }
}
```

**`default` 方法解决了什么问题？**

在 JDK 8 之前，给一个已有接口加新方法是**噩梦**——所有实现类都得跟着改，否则编译不过。JDK 8 加了 `default`，接口可以提供**默认实现**，实现类可以选择：**要么用默认实现、要么自己重写**。因此 JDK 8 才能给 `List / Map / Collection` 加上 `forEach / stream` 这些"武器"，同时**不破坏几十亿行历史代码**。

### 5.5 接口的继承

**接口可以继承接口（用 `extends`）**——甚至可以继承多个：

```java
public interface Duck extends Flyable, Swimmable { }
```

`Duck` 接口本身自动拥有 `fly()` 和 `swim()` 两个抽象方法。实现 `Duck` 接口的类必须同时实现这两个方法。

### 5.6 抽象类 vs 接口 对比表（必背）

| 维度 | 抽象类 | 接口 |
|------|--------|------|
| 关键字 | `abstract class` | `interface` |
| 继承 / 实现 | `extends`，**单**继承 | `implements`，可**多**实现 |
| 字段 | 任意 | 只能 `public static final` |
| 构造方法 | 有 | 无 |
| 方法默认修饰符 | 任意 | `public abstract`（含 `default` / `static`） |
| 关注点 | 有共同**状态**的 `is-a` | 有共同**行为规范**的 `can-do` |

### 5.7 综合示例：`Comparable` 接口

一个真实场景。JDK 自带 `Comparable<T>` 接口：

```java
public interface Comparable<T> {
    int compareTo(T other);
}
```

规则：返回负数表示 `this < other`，0 表示相等，正数表示 `this > other`。

我们让 `Student` 按分数排序：

```java
import java.util.Arrays;

public class Student implements Comparable<Student> {
    String name;
    int score;

    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }

    @Override
    public int compareTo(Student other) {
        return Integer.compare(this.score, other.score);
    }

    @Override public String toString() { return name + "(" + score + ")"; }

    public static void main(String[] args) {
        Student[] arr = {
            new Student("张三", 85),
            new Student("李四", 72),
            new Student("王五", 91)
        };
        Arrays.sort(arr);           // 因为 Student 实现了 Comparable，可以直接排
        System.out.println(Arrays.toString(arr));
        // [李四(72), 张三(85), 王五(91)]
    }
}
```

一句话：只要你实现 `Comparable`，`Arrays.sort` / `List.sort` 都能给你排序——**这就是"面向接口编程"的威力**。

### 5.8 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 接口里的字段被赋新值失败 | 接口字段默认 `public static final`，是常量 |
| 忘写 `implements` 直接 `extends Runnable` | `implements` 才对，只有接口之间才能 `extends` |
| `default` 方法一定要重写吗？ | ❌ 不用。可选重写。这是它的价值所在 |
| 一个类实现两个接口，两个接口都有同名 `default` 方法 | 编译报错。要么在实现类里重写、要么用 `Interface.super.method()` 指定 |
| 接口的抽象方法加 `protected` | 编译报错——接口成员**必须是 `public`**（`private` 除外） |
| `implements Comparable`（没加泛型）导致 `compareTo(Object)` 里要强转 | 一定要写泛型：`Comparable<Student>`，然后 `compareTo(Student)` |

### 5.9 练习 / 思考

1. 定义三个接口 `Runnable / Swimmable / Flyable`。让 `Duck` 三者都实现、`Fish` 只实现 `Swimmable`、`Cat` 只实现 `Runnable`。用一段 `main` 分别演示。
2. 定义 `USBDevice` 接口（`connect / disconnect / transfer`），实现 `Mouse / Keyboard / UDisk`；用 `USBDevice[]` 遍历调用。
3. 定义 `Payable` 接口，含抽象方法 `pay(double amount)`；实现类 `WechatPay / Alipay / BankCard` 各自打印不同支付方式。
4. **思考题**：对于以下三个场景，你会选抽象类还是接口？说理由。
   - "车辆"这一大类（有共同的字段如轮子数、油量）
   - "可比较"的行为（不涉及字段）
   - "支付方式"（微信、支付宝、银行卡，行为差异大）
5. **AI 实战**：让 AI 编程助手对比"JDK 7 的 List 接口"和"JDK 8 之后的 List 接口"，让它列出 `default` 方法带来的新能力（如 `forEach / removeIf / replaceAll`），并解释为什么这些方法必须是 `default` 而不能是抽象方法。

---

## 第 6 讲：枚举与 Record

### 6.1 从两段"闻着不对"的代码说起

**代码 1：** 表示"季节"这个只有四种取值的东西：

```java
public class SeasonConstants {
    public static final int SPRING = 1;
    public static final int SUMMER = 2;
    public static final int AUTUMN = 3;
    public static final int WINTER = 4;
}

public class WeatherReport {
    public void report(int season) {
        // ...
    }
}

// 调用
weatherReport.report(SeasonConstants.SPRING);
weatherReport.report(13);   // ❓ 编译能过。但 13 是什么鬼？
```

问题很明显：**`int` 不能表达"只有四个合法值"这一约束**。传 `13` 编译器不会报错，只有运行到判定逻辑时才可能出问题。

**代码 2：** 一个用来在系统间传输的 `Point` 数据对象（DTO）：

```java
public class PointDTO {
    private int x;
    private int y;
    public PointDTO() {}
    public PointDTO(int x, int y) { this.x = x; this.y = y; }
    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
    @Override public boolean equals(Object o) { /* 大段代码 */ }
    @Override public int hashCode() { /* 大段代码 */ }
    @Override public String toString() { /* 大段代码 */ }
}
```

**60 多行代码，就为了描述"两个 int"这么点儿信息**。业界给这种代码起了个名字——"样板代码"（boilerplate）——就是那种"必须写、写着累、错也没人夸"的痛。

**这两段代码分别要用 `enum` 和 `record` 解决。** 学完本讲，第一段变成 15 行且类型安全，第二段变成**一行**。

### 6.2 `enum`：让"有限取值"成为编译期约束

**语法极简：**

```java
public enum Season {
    SPRING, SUMMER, AUTUMN, WINTER
}
```

这四个大写标识符就是这个类型的**全部合法值**——写第五个编译器直接不认。使用起来：

```java
Season s = Season.SPRING;
System.out.println(s);              // SPRING（默认 toString 就是名字）
System.out.println(s.name());       // SPRING（枚举值的名字字符串）
System.out.println(s.ordinal());    // 0（在声明顺序中的位置，从 0 开始）

switch (s) {
    case SPRING -> System.out.println("春天");
    case SUMMER -> System.out.println("夏天");
    default -> System.out.println("其他");
}

for (Season each : Season.values()) {   // values() 返回所有枚举值
    System.out.println(each);
}
```

**枚举本质**：`enum` 定义的其实是一个**继承自 `java.lang.Enum` 的特殊类**。每一个枚举值都是这个类的**一个静态常量实例**。所以 `Season.SPRING` 就是**一个 `Season` 类型的对象**。这是理解后面"带字段的枚举"的关键。

### 6.3 带字段的枚举（重点）

枚举可以带**字段、构造方法、实例方法**——就像一个普通类。真实项目里几乎所有的枚举都有字段。看订单状态：

```java
public enum OrderStatus {
    CREATED(1, "已创建"),
    PAID(2, "已支付"),
    SHIPPED(3, "已发货"),
    COMPLETED(4, "已完成"),
    CANCELLED(-1, "已取消");

    private final int code;
    private final String label;

    OrderStatus(int code, String label) {   // 构造方法必须是包私有或 private
        this.code = code;
        this.label = label;
    }

    public int getCode() { return code; }
    public String getLabel() { return label; }
}
```

- `CREATED(1, "已创建")` **实际就是** `new OrderStatus(1, "已创建")`——编译器帮你生成的。
- 构造方法**不能是 `public`**——因为不允许外部再 `new`。
- 每个枚举值都是不变的常量实例。

调用：

```java
OrderStatus s = OrderStatus.PAID;
System.out.println(s.getCode());    // 2
System.out.println(s.getLabel());   // 已支付

OrderStatus fromCode = OrderStatus.valueOf("PAID");  // 通过名字取
System.out.println(fromCode);        // PAID
```

**枚举常用 API：**

| 方法 | 说明 |
|------|------|
| `values()` | 返回所有枚举值的数组（按声明顺序） |
| `valueOf(String)` | 按名字取枚举值，不存在抛 `IllegalArgumentException` |
| `name()` | 返回枚举值的字符串名 |
| `ordinal()` | 返回声明顺序的下标（0 开始）——**不要**用它作业务标识 |

**警告**：不要把 `ordinal()` 当业务码存到数据库。你以后一改声明顺序，历史数据全乱。**业务码应该显式在字段里存**（就像上面的 `code`）。

### 6.4 `record`：一行等价 60 行

**`record`** 是 JDK 14 预览、JDK 16 正式加的语法糖，专门解决\"不可变数据载体\"的样板代码问题。

**一行等价 60 行：**

```java
public record Point(int x, int y) {}
```

编译器**自动**给你生成：
- `private final int x;` 和 `private final int y;` — **字段（`private final`）**
- `public Point(int x, int y)` — **全参构造方法**
- `public int x()` 和 `public int y()` — **访问器（注意方法名是 `x()` 而不是 `getX()`）**
- `public boolean equals(Object)` — **基于全部字段的 `equals`**
- `public int hashCode()` — **基于全部字段的 `hashCode`**
- `public String toString()` — 格式为 `Point[x=3, y=4]`

用起来：

```java
Point p1 = new Point(3, 4);
System.out.println(p1);           // Point[x=3, y=4]
System.out.println(p1.x());       // 3
System.out.println(p1.y());       // 4

Point p2 = new Point(3, 4);
System.out.println(p1.equals(p2));   // true（基于字段值判断）
System.out.println(p1.hashCode() == p2.hashCode());   // true

Map<Point, String> map = new HashMap<>();
map.put(p1, "起点");
System.out.println(map.get(new Point(3, 4)));   // 起点（equals + hashCode 都对）
```

**特别提醒**：访问器是 `x()` 不是 `getX()`。这是 `record` 的规范，跟 JavaBean 的 getter 命名不一样。改不了。

### 6.5 record 的紧凑构造器 + 自定义方法

`record` 不只是"记录字段"——它能加**紧凑构造器（compact constructor）** 做参数校验，也能加**自定义方法**。

**紧凑构造器**（`compact constructor`）：

```java
public record Range(int start, int end) {
    public Range {                                    // 注意：没有形参列表！
        if (start > end) {
            throw new IllegalArgumentException("start 不能大于 end");
        }
    }
}

new Range(1, 10);        // ✔
new Range(10, 1);        // ❌ 抛 IllegalArgumentException
```

**关键语法**：紧凑构造器的写法是 `public 类名 {` ——**没有形参列表**、也**不需要手动赋值给字段**（编译器在校验通过后自动帮你 `this.start = start; this.end = end;`）。这个语法非常特殊，千万别写成 `public Range(int start, int end) {`——那是"规范构造器"，你要手动赋值。

**自定义方法**：

```java
public record Point(int x, int y) {
    public double distanceTo(Point other) {
        int dx = x - other.x;
        int dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}

new Point(3, 4).distanceTo(new Point(0, 0));   // 5.0
```

**`record` 的三条硬约束**：

1. **不可变**：字段自动 `final`，没有 setter。想改？创建新对象。
2. **不能继承普通类**（除了隐式继承 `java.lang.Record`），但**可以实现接口**。
3. 字段列表在类名后的括号里声明——不能在 `{}` 里加实例字段（可以加 `static` 字段）。

**适用场景**：DTO、VO、值对象、`Map` 的 key、方法多个返回值的载体、领域中的\"不可变小对象\"。

### 6.6 综合示例：用 `record + enum` 建模一个订单

把本讲学的全部串在一起：

```java
public record Order(String orderId, long userId, long amount, OrderStatus status) {
    public Order {
        if (amount <= 0) throw new IllegalArgumentException("amount 必须 > 0");
        if (orderId == null || orderId.isBlank())
            throw new IllegalArgumentException("orderId 不能为空");
    }

    public boolean isFinalized() {
        return status == OrderStatus.COMPLETED || status == OrderStatus.CANCELLED;
    }
}

public class OrderDemo {
    public static void main(String[] args) {
        Order o = new Order("ORD001", 1001L, 5000L, OrderStatus.PAID);
        System.out.println(o);
        // Order[orderId=ORD001, userId=1001, amount=5000, status=PAID]

        System.out.println("是否终结：" + o.isFinalized());   // false

        // 一段代码写出了：不可变数据 + 参数校验 + 枚举状态 + 业务方法
    }
}
```

一段代码里同时用到了 `record` 的紧凑构造器、访问器、`toString`、`enum` 的类型安全、`enum` 值的 `==` 比较、`record` 自定义方法——**这就是本日的收官技巧组合拳**。

### 6.7 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `p.getX()` 访问 `record` 字段编译报错 | 访问器叫 `x()` 不是 `getX()`——`record` 独有的命名规范 |
| 紧凑构造器写成 `public Range(int start, int end) { ... }` 后字段没被赋值 | 那是**规范构造器**，需要你手动 `this.start = start; this.end = end;`。紧凑构造器**没有形参列表** |
| 想给 `record` 加 setter | ❌ 不行。`record` 是不可变的 |
| 想让 `record` 继承 `Point` 抽象类 | ❌ 不行。`record` 只能实现接口，不能继承类 |
| 枚举构造方法写成 `public` | 编译报错——枚举构造方法只能是包私有或 `private` |
| 用 `ordinal()` 作为业务码存进数据库 | ❌ 严重反模式。改一次声明顺序，历史数据错乱。业务码要显式存字段 |
| 枚举用 `==` 比较是否可以？ | ✔ 可以。同名枚举值全局只有一个实例，`==` 和 `equals` 等价，且 `==` 更快 |

### 6.8 练习 / 思考

1. 定义 `WeekDay` 枚举（周一到周日 7 个值），加 `boolean isWeekend()` 方法。
2. 定义 `Level` 枚举（`DEBUG / INFO / WARN / ERROR`），带 `int severity` 字段（1、2、3、4）；写一个 `shouldLog(Level threshold)` 方法。
3. 定义 `record Money(long cents, String currency)`，加 `add(Money other)` 方法——只有同币种才能相加，否则抛异常。
4. 定义 `record Person(String name, int age)`，紧凑构造器校验 `age >= 0`；加一个 `isAdult()` 方法（`age >= 18`）。
5. **AI 实战**：让 AI 编程助手写一个\"HTTP 响应\"的 `record ResponseDTO(int code, String message, Object data)`，含紧凑构造器校验 `code >= 100 && code < 600`，以及方法 `isSuccess()`（2xx 范围）。检查它的紧凑构造器写法是否正确（**不带形参列表**）。

---

## 第 7 讲：异常处理入门

### 7.1 上课先问一句

回到上一讲写的 `record Range`：

```java
public record Range(int start, int end) {
    public Range {
        if (start > end) throw new IllegalArgumentException("start > end");
    }
}
```

**问：** 这个 `throw new IllegalArgumentException(...)` 到底做了什么？

- 程序会崩吗？——**会。** 如果没有人处理，JVM 打印一段红字然后退出。
- 调用方能拦住吗？——**能。** 用 `try-catch` 就能拦住，程序继续跑。
- 那"拦住"和"不拦住"，哪个是对的？——**看情况。** 今天讲清楚这个"情况"到底是什么。

### 7.2 异常是什么

先看一个所有人都遇到过的场景：

```java
int a = 10;
int b = 0;
System.out.println(a / b);
```

运行——控制台喷出一段红字：

```text
Exception in thread "main" java.lang.ArithmeticException: / by zero
    at Demo.main(Demo.java:4)
```

这**不是 IDE 出了 Bug**，这是 Java 遇到"我算不下去了"的意外时，主动"造出一个对象"抛给你——这个对象就叫**异常（Exception）**。

**`Throwable` 家族树：**

```text
Throwable
├── Error         → JVM 层严重故障（OutOfMemoryError、StackOverflowError）
│                    不用你处理，出了就退出
└── Exception     → 应用层可以处理的异常
    ├── RuntimeException           → 运行时异常，编译器不强制
    │   ├── NullPointerException          （NPE，最常见）
    │   ├── ArrayIndexOutOfBoundsException（数组越界）
    │   ├── ArithmeticException           （除 0）
    │   ├── NumberFormatException         （字符串转数字失败）
    │   ├── ClassCastException            （类型转换失败）
    │   └── IllegalArgumentException      （非法参数——上一讲用过）
    └── IOException / SQLException 等     → 受检异常，编译器强制处理
```

**两句话记住区别：**

- **`RuntimeException`**（运行时异常）= 编译器**不强制**你处理 = 通常是**你的代码 Bug**——NPE、越界、除 0 都是你自己写错了。**修 Bug 比 catch 更重要**。
- **受检异常**（Checked Exception）= 编译器**强制**你处理，不写就编不过 = 通常是**外部因素**——文件不存在、网络断了、数据库连不上。这些你没法"修 Bug"消除，只能预先想好怎么应对。

**核心心智模型：**
> **看到红色报错是好事，比默默算错强 100 倍。** 我们今天学的不是"消除红字"，而是"红字出现时怎么优雅地应对"。

### 7.3 `try-catch-finally` 三段结构

现在把除 0 的例子改造成"程序不崩"的版本：

```java
public class DivDemo {
    public static void main(String[] args) {
        int[] arr = {10, 0, 5};
        for (int i = 0; i < arr.length; i++) {
            try {
                int result = 100 / arr[i];
                System.out.println("100 / " + arr[i] + " = " + result);
            } catch (ArithmeticException e) {
                System.out.println("出错了：" + e.getMessage());
            } finally {
                System.out.println("--- 第 " + i + " 次循环结束 ---");
            }
        }
        System.out.println("程序正常结束");
    }
}
```

运行输出：

```text
100 / 10 = 10
--- 第 0 次循环结束 ---
出错了：/ by zero
--- 第 1 次循环结束 ---
100 / 5 = 20
--- 第 2 次循环结束 ---
程序正常结束
```

**四条关键结论：**

1. **`try` 块**放"可能出错"的代码。
2. **`catch (类型 e)`** 只捕获匹配类型的异常，处理完程序继续跑，**不会崩**。
3. **`finally` 块**无论有没有出异常都会执行，最常用于**关闭资源**（Scanner、文件、数据库连接）。
4. `try` 里一旦抛异常，**剩余代码不再执行**，直接跳到 `catch`。

**画一张执行流示意图：**

```text
                ┌─── 无异常 ──→ try 全部执行完 ──┐
       try {…}  ┤                                  ├──→ finally {…}  ──→ 继续往下
                └─── 抛异常 ──→ 跳到匹配的 catch ──┘
```

### 7.4 多 catch 与多重 catch

一段代码常常同时可能抛多种异常。比如：读命令行参数、转数字、做除法：

```java
public class MultiCatchDemo {
    public static void main(String[] args) {
        try {
            int a = Integer.parseInt(args[0]);
            int b = Integer.parseInt(args[1]);
            System.out.println(a + " / " + b + " = " + (a / b));
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("请传入两个参数");
        } catch (NumberFormatException e) {
            System.out.println("参数必须是整数");
        } catch (ArithmeticException e) {
            System.out.println("除数不能为 0");
        }
    }
}
```

**两条重要规则：**

1. **多个 catch 从上到下匹配**——一旦匹配到就进那一块，后面的不再检查。
2. **父类 catch 必须写在子类之后**——否则子类永远匹配不到。反例：

```java
try { ... }
catch (Exception e) { ... }              // ✗ 父类写在前
catch (NumberFormatException e) { ... }  // 编译不过：unreachable code
```

**如果几种异常处理方式一样**，可以合并成 **多重 catch**（Java 7 起）：

```java
try {
    int a = Integer.parseInt(args[0]);
    int b = Integer.parseInt(args[1]);
    System.out.println(a / b);
} catch (NumberFormatException | ArithmeticException e) {
    System.out.println("输入错误：" + e.getMessage());
}
```

用 `|` 把多种异常并列在一个 catch 里——**少写、清晰、还能减重复**。

### 7.5 `throws` 与 `throw`

拼写只差一个字母，含义完全不同。**并列写在一起对比记忆：**

| 关键字 | 位置 | 作用 |
|--------|------|------|
| `throws` | **方法签名**上 | 声明"本方法可能抛某类异常，调用者你处理"——只对受检异常有编译强制意义 |
| `throw`  | **方法体内**的一条语句 | **手动**抛出一个异常对象，程序执行到这里立刻中断当前调用 |

举例：

```java
public static int parsePositive(String s) throws NumberFormatException {
    int n = Integer.parseInt(s);           // 这里底层可能抛（NumberFormatException）
    if (n <= 0) {
        throw new IllegalArgumentException("必须为正数：" + n);  // 这里是我手动抛
    }
    return n;
}
```

调用方 `main` 三种应对方式：

```java
// 方式 1：try-catch 处理
try { int x = parsePositive(input); }
catch (NumberFormatException | IllegalArgumentException e) { ... }

// 方式 2：继续 throws，让更上层的方法处理
public static void main(String[] args) throws Exception { ... }

// 方式 3：什么都不做，一路冒泡到 JVM，打印堆栈退出
```

**回到上一讲的疑问：** `record Range` 里的 `throw new IllegalArgumentException(...)`——`IllegalArgumentException` 是 `RuntimeException` 子类，**编译器不强制**调用方处理，所以调用者可以：

- 用 `try-catch` 优雅拦住（推荐做法：给用户友好提示）；
- 或者不管它，让程序崩掉（快速失败，暴露 Bug）。

### 7.6 综合示例：安全的字符串转整数除法

**把导入的疑问彻底闭环——一个既能挡输入格式错、又能挡除 0、还能保证 Scanner 被关闭的"全套"版本：**

```java
import java.util.Scanner;

public class SafeDivDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.print("请输入被除数：");
            int a = Integer.parseInt(sc.nextLine());
            System.out.print("请输入除数：");
            int b = Integer.parseInt(sc.nextLine());
            System.out.println(a + " / " + b + " = " + (a / b));
        } catch (NumberFormatException e) {
            System.out.println("输入格式错误：不是合法整数");
        } catch (ArithmeticException e) {
            System.out.println("除数不能为 0");
        } finally {
            sc.close();
            System.out.println("Scanner 已关闭");
        }
    }
}
```

**三种输入的运行效果：**

| 输入 | 输出 | 走的路径 |
|------|------|----------|
| `10` `2` | `10 / 2 = 5` + `Scanner 已关闭` | try 全部执行 → finally |
| `10` `0` | `除数不能为 0` + `Scanner 已关闭` | try 抛 → catch (Arithmetic) → finally |
| `abc` `2` | `输入格式错误：不是合法整数` + `Scanner 已关闭` | try 抛 → catch (NumberFormat) → finally |

**关键：无论走哪条路径，`finally` 都保证 Scanner 被关闭——这就是"清理资源"的经典写法。**

### 7.7 pitfall / 注意

| 现象 / 反模式 | 原因 | 正确做法 |
|---------------|------|----------|
| `catch (Exception e) { }` 里面什么都不写 | **吞异常**——出错了没人知道，问题被永久隐藏 | 至少打印 `e.printStackTrace()` 或写日志 |
| `catch (Exception e)` 一把梭捕获所有异常 | 把 NPE、越界这些**代码 Bug 也捕获**了，隐藏了真问题 | 只捕获你能处理的**具体类型** |
| `finally` 块里写 `return -1;` | `finally` 的 `return` 会**覆盖 try 里的 `return`**——非常隐蔽的坑 | `finally` 里**永远不要写 `return`**，只做清理 |
| 把 `NullPointerException` 也 catch 掉 | NPE 一定是 Bug，应该**回去修**——catch 只会让 Bug 静默存活 | 让它崩出来，看堆栈定位到出错行 |
| `catch (NumberFormatException e) catch (Exception e)` 父类写在前 | 编译报错：unreachable code | 父类必须写在**子类之后** |
| 用异常做**流程控制**（比如用 catch 判断字符串是不是数字） | 异常创建开销大、语义反直觉 | 能用 `if / 校验方法`判断的**不要用异常** |

### 7.8 练习 / 思考

1. 把 `SafeDivDemo` 改成用**多重 catch（`|`）** 合并两个 catch。
2. 把 `SafeDivDemo` 扩展成一个循环——反复读用户输入直到成功计算一次为止，用 `finally` 保证 Scanner 在退出循环后关闭。
3. **辨析题**：下列代码哪里错了？为什么？（提示：两个反模式）

```java
try {
    return doSomething();
} catch (Exception e) {
    // 什么都不做
} finally {
    return -1;
}
```

4. **异常类型判断**：判断下列代码抛出的**异常类型**，属于 `RuntimeException` 还是受检异常：

```java
// (a)
String s = null;
s.length();

// (b)
int[] arr = new int[3];
arr[5] = 1;

// (c)
Integer.parseInt("abc");

// (d)
Object o = "hello";
Integer i = (Integer) o;
```

5. **AI 实战**：把下面这段代码粘给 AI 编程助手（例如通义灵码），让它指出**3 个反模式**并给出改写版本，判断它讲的与本讲 pitfall 表格是否一致：

```java
try {
    Integer.parseInt(input);
} catch (Exception e) {
}
```

---

## Day05 全天总结

### 一张图串七讲

```text
第 1 讲 多态          ─┐
第 2 讲 final / static ┤─ 完成面向对象三大特性（封装、继承、多态）
第 3 讲 Math          ─┘  的最后拼图 + 工具类基本功

第 4 讲 抽象类  ─── is-a、"我是什么"、共同状态
第 5 讲 接口    ─── can-do、"我能做什么"、多实现
第 6 讲 enum/record ─── 特殊类家族的两个成员（值 / 数据）
第 7 讲 异常处理 ─── 让程序在意外面前"不再一崩了之"
```

### 核心口诀

- **多态** = 父类引用 + 子类重写 + 动态绑定。
- **`final`** 三用：变量不可改 / 方法不可重写 / 类不可继承。
- **`static`** = 属于类 / 全体共享 / 类名访问 / 静态方法只能访问静态成员。
- **`Math`** 是纯静态工具类，随机整数公式：`(int)(Math.random()*(max-min+1)) + min`。
- **抽象类 vs 接口**：`is-a` 用抽象类、`can-do` 用接口；单继承 vs 多实现。
- **枚举**：有限、固定、类型安全，常带字段。
- **Record**：一行不可变数据载体，访问器 `x()` 而非 `getX()`。
- **异常**：`try` 放险、`catch` 分型、`finally` 兜底；`RuntimeException` 修 Bug、受检异常必处理；四大坑（吞、一把梭、finally return、catch NPE）永远不犯。

### Day06 预告

明天讲 **第 11 章 String 与包装类**，包括：不可变字符串、`String / StringBuilder / StringBuffer` 的选择、`Integer.parseInt` 等包装类、自动装箱拆箱与陷阱。今天讲过的 `final`（`String` 本身就是 `final class`）、`record`（`String` 的常用替代场景）都会再次出现；而**第 7 讲的异常**在明天几乎每一段代码里都要用——`Integer.parseInt` 抛 `NumberFormatException`、`substring` 越界抛 `StringIndexOutOfBoundsException`、拆箱 `null` 抛 `NullPointerException`，都是今天 pitfall 表格里点名过的运行时异常。

### Day05 作业汇总

请在下次课前完成以下 8 道综合作业（前 5 道覆盖第 1—6 讲，第 6—7 道针对第 7 讲异常处理，第 8 道是 AI 实战）：

1. **多态 + 抽象类**：把 `Shape` 改成抽象类，`Circle / Square / Rectangle` 三子类，用 `Shape[]` 一次算总面积并打印最大形状。
2. **接口 + 多实现**：写 `Duck / Fish / Cat`，分别实现 `Runnable / Swimmable / Flyable` 中的合适子集，用 `main` 演示。
3. **枚举实战**：把作业 1 的形状类型定义为枚举 `ShapeType { CIRCLE, SQUARE, RECTANGLE }`，给 `Shape` 加抽象方法 `ShapeType getType()`，各子类实现。
4. **Record 实战**：定义 `record Money(long cents, String currency)`，加 `add / subtract` 方法（同币种校验，币种不一致时 `throw new IllegalArgumentException`——顺带巩固第 7 讲的 `throw`）。
5. **综合**：定义 `record Order(String id, long userId, long amount, OrderStatus status)`，紧凑构造器校验 `amount > 0`（不合法就 `throw`），方法 `isFinalized()`。运行并观察 `toString` 自动生成的效果，再写一段 `try-catch` 演示紧凑构造器抛异常时如何优雅处理。
6. **异常处理入门（必做）**：把 `SafeDivDemo` 扩展为循环——反复读取用户输入直到成功计算一次为止，同时用 `finally` 保证 Scanner 在退出循环后关闭。要求：使用**多重 catch（`|`）** 合并 `NumberFormatException` 和 `ArithmeticException`，运行截图三种输入路径（正常 / 非数字 / 除 0）。
7. **异常辨析（必做）**：给出一段代码同时演示以下四种运行时异常并用 `try-catch` 优雅处理：`NullPointerException`、`ArrayIndexOutOfBoundsException`、`ClassCastException`、`ArithmeticException`。要求每种异常单独一个 `catch`，父子类顺序正确。
8. **AI 实战**：让 AI 编程助手回答"JDK 8 的 `default` 方法解决了什么问题？举一个 `List` 接口在 JDK 8 前后的对比"，把答案抄录并加自己一段点评（≥ 100 字），判断它讲的是否与本讲一致。
