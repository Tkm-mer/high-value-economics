# AI 应用编程基础——Java 基础 - 学生讲义（Day03：第 1—6 讲）

**总课时：** 6 讲 × 45 分钟
**适用对象：** 已完成 Day01（Java 起步、变量运算符、流程控制）和 Day02（分支循环、一维数组、查找排序）的学生
**基线版本：** JDK 25 LTS · IntelliJ IDEA 2026.1
**开发工具：** IntelliJ IDEA 2026.1 + 通义灵码 / Claude
**对应教材：** 第 5 章《二维数组、方法与递归》 + 第 6 章《综合案例：大学生实训管理系统》

## 本日概览

| 讲次 | 主题 | 章节 | 关键词 |
|------|------|------|------|
| 第 1 讲 | 二维数组：定义、初始化、遍历 | 5.1 | 数组的数组、静态 / 动态初始化、双重循环 |
| 第 2 讲 | 方法（函数）的定义与调用 + 方法重载 | 5.2、5.3 | 形参实参、按值 / 引用传递、重载判定 |
| 第 3 讲 | 递归 | 5.4 | 三要素、阶乘、斐波那契、gcd、栈溢出 |
| 第 4 讲 | 大学生实训管理系统——需求分析与主循环 | 6.1、6.2 | 需求、流程图、四并列数组、菜单骨架 |
| 第 5 讲 | 大学生实训管理系统——增删改查功能 | 6.3、6.4 | indexOf、元素前移、字符串比较、一次遍历多统计 |
| 第 6 讲（收官）| AI 辅助排错、审查、优化 + Day01—03 收官 | 6.5 | 三份提示词模板、小步慢跑、Day04 预告 |

> **说明**：本讲义采用"讲授脚本"风格，读起来像老师在讲台上按节奏说话——概念、代码、坑、思考，一层层展开。跟着读、跟着敲，效果最好。

---

## 第 1 讲：二维数组——从"一排学生"到"整张成绩表"

### 1.1 为什么需要二维数组

上一课我们用一维数组存了"一个班学生的语文成绩"。现在问题来了：一个学生有语文、数学、英语三门课，全班 40 个学生，成绩怎么存？

如果只用一维数组，你可能会想到"一个班开三个数组，`chinese[]`、`math[]`、`english[]`"——能行，但当你有 8 门课时，你会开 8 个数组吗？更进一步，如果要保存的是**成绩表**（行是学生、列是科目），最自然的表达就是**二维数组**。

在 Java 里，二维数组其实**并不是真正的"二维"**，它的本质是——**元素为一维数组的数组**，简称"数组的数组"。你可以理解成："外层数组的每一格里，存的不是一个数字，而是**另一个数组**"。

### 1.2 三种初始化方式

第一种——**静态初始化**，数据已知时最方便：

```java
int[][] scores = {
    {88, 92, 76},   // 张三：语文 数学 英语
    {85, 89, 91},   // 李四
    {72, 68, 80}    // 王五
};
```

大括号里嵌大括号，外层大括号包"整体"，内层每个大括号代表"一行"。行与行之间用逗号分开。

第二种——**动态初始化**，只知道规模、还没数据时使用：

```java
int[][] arr = new int[3][4];   // 3 行 4 列，全部默认值为 0
arr[0][0] = 1;
arr[2][3] = 100;
```

第三种——**不规则二维数组**（每行长度可以不同）：

```java
int[][] arr = new int[3][];   // 只定行数
arr[0] = new int[]{1, 2};
arr[1] = new int[]{3, 4, 5, 6};
arr[2] = new int[]{7};
```

对比表：

| 初始化方式 | 语法 | 适用场景 |
|------|------|------|
| 静态 | `int[][] a = {{1,2},{3,4}};` | 数据已知：成绩表、常量矩阵 |
| 动态 | `int[][] a = new int[3][4];` | 只知道尺寸，先占位 |
| 不规则 | `int[][] a = new int[3][];` | 每行长度不同：一周任务清单 |

### 1.3 二维数组的内存模型

这里是**最容易被跳过、但真正决定你能不能理解引用类型**的一段。

```java
int[][] scores = {
    {88, 92, 76},
    {85, 89, 91},
    {72, 68, 80}
};
```

内存里其实有 **4 个数组对象**：
- 1 个"外层数组"，长度 3，每个格子里存的是**一个引用**（可以理解成地址）；
- 3 个"内层数组"，各自长度 3，存的是真实的 int 数字。

用图表示：

```text
scores（外层数组，长度 3）
  ├─ [0] → {88, 92, 76}     ← 内层数组 1
  ├─ [1] → {85, 89, 91}     ← 内层数组 2
  └─ [2] → {72, 68, 80}     ← 内层数组 3
```

这就是为什么"不规则二维数组"能存在——每一行是**独立**的一维数组，长度自然可以不同。

### 1.4 遍历二维数组

**普通 for 双重循环**（能拿到下标 i、j，最灵活）：

```java
for (int i = 0; i < scores.length; i++) {
    for (int j = 0; j < scores[i].length; j++) {
        System.out.print(scores[i][j] + "\t");
    }
    System.out.println();
}
```

注意两个 `.length`：
- `scores.length` = **外层数组长度 = 行数**（这里是 3）
- `scores[i].length` = **第 i 行内层数组的长度 = 该行的列数**

**增强 for 双重循环**（更简洁，但拿不到下标）：

```java
for (int[] row : scores) {
    for (int s : row) {
        System.out.print(s + "\t");
    }
    System.out.println();
}
```

外层的 `int[] row` 说明：每次拿到的是**一整行数组**，因为二维数组的元素本身就是一维数组。

### 1.5 完整示例：班级成绩表

我们把一节课学的所有东西拼成一个完整可运行的程序：

```java
public class ScoreTable {
    public static void main(String[] args) {
        String[] names = {"张三", "李四", "王五"};
        int[][] scores = {
            {88, 92, 76},
            {85, 89, 91},
            {72, 68, 80}
        };
        String[] subjects = {"语文", "数学", "英语"};

        // 表头
        System.out.print("姓名\t");
        for (String sub : subjects) System.out.print(sub + "\t");
        System.out.println("总分\t平均分");

        // 逐行输出
        for (int i = 0; i < names.length; i++) {
            System.out.print(names[i] + "\t");
            int sum = 0;
            for (int j = 0; j < scores[i].length; j++) {
                System.out.print(scores[i][j] + "\t");
                sum += scores[i][j];
            }
            double avg = sum * 1.0 / scores[i].length;
            System.out.printf("%d\t%.2f%n", sum, avg);
        }
    }
}
```

运行输出：

```text
姓名    语文    数学    英语    总分    平均分
张三    88      92      76      256     85.33
李四    85      89      91      265     88.33
王五    72      68      80      220     73.33
```

几个细节：
- `\t` 是制表符，让输出对齐。
- `sum * 1.0 / scores[i].length` 用来把整数 `sum` 提升到 `double`，避免"整除"（`256 / 3` 会得 85 而不是 85.33）。
- `%.2f%n` 表示保留两位小数、换行（`%n` 是跨平台换行，比 `\n` 稳）。

### 1.6 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `scores[i].length` 越界 | 误把"列数"当固定值，或不规则数组的行长度不一 |
| 打印结果没对齐 | 忘了 `\t`；或者字段本身就比一个制表位长 |
| `256 / 3 == 85` 而不是 85.33 | 两个 int 相除是整除，需要 `sum * 1.0` 或 `(double)sum` |
| `arr[3][4]` 报 `ArrayIndexOutOfBoundsException` | 下标从 0 开始，`new int[3][4]` 合法下标为 `[0..2][0..3]` |
| 二维遍历行列顺序反了 | 打印出来是"转置"效果，容易在 debug 时被误导 |

### 1.7 练习 / 思考

1. **矩阵转置**：定义一个 3×3 数组，把它转置后打印（行变列、列变行）。
2. 用二维数组打印九九乘法表（下三角）。
3. 定义一个不规则二维数组存"一周每天要背的单词"（周一 2 个、周二 5 个……周日 1 个），增强 for 遍历打印。
4. （思考）为什么二维数组`可以不规则`？请用"外层数组存引用"这个概念解释。

---

## 第 2 讲：方法（函数）的定义与调用 + 方法重载

### 2.1 从"重复的代码"说起

回到上一节的成绩表：算每一行的总分，我们在循环里写了 `sum += scores[i][j]`。假设你要为 5 个班算总分——难道要复制 5 段一模一样的循环？如果哪天要换算法，5 段都要改，改错一处就出 bug。

**方法（Method）**就是为解决这个问题诞生的：**给一段可重复使用的代码起个名字，以后每次用名字调用就行。** 从此代码的**基本单位**从"一行语句"升级为"一个方法"。

### 2.2 方法的定义语法

```java
修饰符 返回值类型 方法名(参数列表) {
    方法体
    return 返回值;   // 如果返回值类型是 void 就不用写
}
```

我们的第一个方法：

```java
public class MethodDemo {
    public static void main(String[] args) {
        int result = sum(10, 20);
        System.out.println("和 = " + result);
    }

    // 定义方法
    public static int sum(int a, int b) {
        return a + b;
    }
}
```

几个约定，先记住：
- 目前所有方法都写 `public static`。`static` 是"静态"的意思，第 9 章会详解——现在只需要"照写"。
- `void` 表示"没有返回值"：

```java
public static void greet(String name) {
    System.out.println("你好, " + name);
    // 没有 return
}
```

- 方法必须写在**类里、main 外**，与 main 平级。

### 2.3 形参 vs 实参

- **形参（形式参数）**：定义方法时写在括号里的变量，例如 `int a, int b`。
- **实参（实际参数）**：调用方法时传入的具体值，例如 `sum(10, 20)` 里的 `10, 20`。

对比：

| 概念 | 出现位置 | 举例 |
|------|------|------|
| 形参 | 方法定义处 | `public static int sum(int a, int b)` |
| 实参 | 方法调用处 | `sum(10, 20)` |

### 2.4 参数传递机制——Java 的经典考点

**规则一：基本类型按值传递**。方法内修改形参，**不影响**实参。

```java
public static void change(int x) {
    x = 100;
}

public static void main(String[] args) {
    int num = 5;
    change(num);
    System.out.println(num);   // 输出 5，不是 100
}
```

因为传入方法的是 `num` 的**副本**——就像复印一份合同交给对方，对方在复印件上乱涂乱画，原件不变。

**规则二：引用类型传递"地址副本"**。方法内**能修改**引用指向的对象内容。

```java
public static void reset(int[] arr) {
    arr[0] = 0;
}

public static void main(String[] args) {
    int[] a = {1, 2, 3};
    reset(a);
    System.out.println(a[0]);   // 输出 0，被修改了
}
```

方法收到的是"地址副本"——**地址被复制了，但地址指向的东西是同一份**。就像把家门钥匙复制了一把给朋友，朋友和你打开的是同一扇门。

⚠️ 常见误解："引用类型传递就是传引用" ——不对。传递的是**地址的副本**。如果你在方法里做 `arr = new int[]{9}`，原来的 `a` 不会变——因为这只是改了副本指向的对象。

### 2.5 单一职责原则

**一个方法只做一件事**。这条原则从入门就要建立。

反例（一个方法做了 4 件事）：

```java
public static void doAll() {
    // 1. 读取输入
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    // 2. 校验
    if (n < 0) return;
    // 3. 计算
    long r = 1;
    for (int i = 1; i <= n; i++) r *= i;
    // 4. 打印
    System.out.println(r);
}
```

正例（拆成 4 个方法）：

```java
static int readInput() { ... }
static boolean isValid(int n) { ... }
static long factorial(int n) { ... }
static void print(long r) { ... }
```

好处显而易见：读起来清晰、测试单元小、AI 生成 / 审查更精准。

### 2.6 方法重载

**方法重载（Overload）**：在**同一个类**中，方法名**相同**、参数列表**不同**，视为不同方法。

**判定规则**：**只看方法名 + 参数列表**（个数、类型、顺序），**与返回值、修饰符、参数名无关**。

```java
public static int add(int a, int b) { return a + b; }
public static double add(double a, double b) { return a + b; }
public static int add(int a, int b, int c) { return a + b + c; }
public static int add(int[] arr) {
    int s = 0;
    for (int x : arr) s += x;
    return s;
}
```

以上 4 个 `add` 互为重载，编译器根据实参匹配对应版本。

**反例**：

```java
public static int    add(int a, int b) { return a + b; }
public static double add(int a, int b) { return a + b; }   // ❌ 编译报错：只有返回值不同
```

JDK 里最著名的重载：`System.out.println` 重载了十几种版本，所以它才能"什么都能打印"——int、double、boolean、String、Object……

### 2.7 综合示例：把成绩表重构成"方法组合"

回到第 1 讲的成绩表，我们用方法重构一下：

```java
public class ScoreTableRefactored {
    public static void main(String[] args) {
        int[][] scores = {{88, 92, 76}, {85, 89, 91}, {72, 68, 80}};
        String[] names = {"张三", "李四", "王五"};
        printHeader();
        for (int i = 0; i < names.length; i++) {
            printRow(names[i], scores[i]);
        }
    }

    public static void printHeader() {
        System.out.println("姓名\t语文\t数学\t英语\t总分\t平均分");
    }

    public static void printRow(String name, int[] row) {
        System.out.print(name + "\t");
        int sum = sum(row);
        for (int s : row) System.out.print(s + "\t");
        System.out.printf("%d\t%.2f%n", sum, sum * 1.0 / row.length);
    }

    public static int sum(int[] row) {
        int s = 0;
        for (int x : row) s += x;
        return s;
    }
}
```

对比一下第 1 讲的版本——main 从"业务纠缠"变成了"业务纲要"，如果要新增一门课，只用改数据，不用动方法。

### 2.8 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 方法找不到，编译报错 | 写在了另一个类里 / 方法名拼错 / 参数类型不匹配 |
| 传 int 给方法后原变量没变 | 基本类型按值传递（副本） |
| 传数组给方法，改了 `arr = new int[]{}` 原数组没变 | 只改了地址副本的指向，原引用未变 |
| 两个方法只有返回值不同，编译报错 | 重载不看返回值 |
| 忘写 return，`int` 方法编译报错 | 有返回值的方法必须保证所有路径都 return |

### 2.9 练习 / 思考

1. 写一个方法 `int max(int a, int b)`，重载出接收 3 个 int、`int[]` 的两个版本。
2. 写一个方法 `void swap(int[] arr, int i, int j)`，交换数组两个位置的元素，在 main 中验证。
3. 写一个方法 `boolean contains(int[] arr, int target)`，判断数组是否包含某元素。
4. （思考）如果 Java 允许 "只按返回值区分重载"，会发生什么歧义？举一个具体调用例子。

---

## 第 3 讲：递归——方法自己调用自己

### 3.1 一个奇怪的想法：能不能自己调用自己？

上一讲我们知道方法可以互相调用：`main` 调 `sum`，`sum` 里也可以调 `max`。那么，**一个方法能不能调用它自己？**

答案是能。这种"方法调用自身"的技术叫**递归（Recursion）**。它是很多分治问题（例如目录遍历、树结构处理）最优雅的表达方式。

小心：**优雅不代表正确**。递归写不好就会**栈溢出**（`StackOverflowError`），甚至指数级慢——本讲会用两个经典案例把这些陷阱都踩一遍。

### 3.2 第一个递归：阶乘

阶乘的数学定义：

```text
n! = n × (n-1)!    (n ≥ 1)
0! = 1
```

翻译成 Java：

```java
public static long factorial(int n) {
    if (n <= 1) return 1;              // ① 递归终止条件（base case）
    return n * factorial(n - 1);       // ② 递归调用
}
```

调用 `factorial(5)` 会像这样一层层展开：

```text
factorial(5) = 5 * factorial(4)
             = 5 * 4 * factorial(3)
             = 5 * 4 * 3 * factorial(2)
             = 5 * 4 * 3 * 2 * factorial(1)
             = 5 * 4 * 3 * 2 * 1
             = 120
```

想象在 JVM 里，每次调用都会把当前方法的一份"栈帧"压到调用栈上——`factorial(5)` 在栈底、`factorial(1)` 在栈顶。到达 `n <= 1` 后开始"回卷"，一层层弹出栈帧、把结果乘上去。

### 3.3 递归三要素

写任何递归，都要先在心里回答这 3 个问题：

| 要素 | 说明 | 在阶乘中的体现 |
|------|------|------|
| ① 终止条件（base case） | 什么时候不再递归 | `n <= 1 return 1` |
| ② 规模缩小 | 每次调用，问题都变小一点 | `n - 1` |
| ③ 递归表达式 | 大问题如何拆成"更小的问题 + 一点操作" | `n * factorial(n-1)` |

**如果忘写终止条件**——恭喜你，得到 `StackOverflowError`：栈无限增长，直到 JVM 崩溃。这是递归最常见的错误。

**如果规模不缩小**——例如把 `factorial(n - 1)` 写成 `factorial(n)`——同样栈溢出。

### 3.4 案例：斐波那契（既是经典，也是反面教材）

斐波那契数列：`0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...`，第 n 项等于前两项之和。

```java
public static long fib(int n) {
    if (n <= 1) return n;
    return fib(n - 1) + fib(n - 2);
}
```

看似完美，其实**指数级重复计算**：

```text
fib(5) = fib(4) + fib(3)
       = (fib(3) + fib(2)) + (fib(2) + fib(1))
       = ...
```

`fib(2)` 被算了 3 次，`fib(3)` 被算了 2 次，`fib(1)` 被算了 5 次…… 到 `fib(40)`，就要算几亿次。

**迭代版**（推荐）：

```java
public static long fibIterative(int n) {
    if (n <= 1) return n;
    long prev = 0, curr = 1;
    for (int i = 2; i <= n; i++) {
        long next = prev + curr;
        prev = curr;
        curr = next;
    }
    return curr;
}
```

对比 benchmark（可以运行下面这段自己看）：

```java
public class FibBenchmark {
    public static void main(String[] args) {
        int n = 40;
        long t1 = System.currentTimeMillis();
        long r1 = fib(n);
        long t2 = System.currentTimeMillis();
        long r2 = fibIterative(n);
        long t3 = System.currentTimeMillis();
        System.out.println("递归结果：" + r1 + "，用时：" + (t2 - t1) + " ms");
        System.out.println("迭代结果：" + r2 + "，用时：" + (t3 - t2) + " ms");
    }

    public static long fib(int n) {
        if (n <= 1) return n;
        return fib(n - 1) + fib(n - 2);
    }

    public static long fibIterative(int n) {
        if (n <= 1) return n;
        long prev = 0, curr = 1;
        for (int i = 2; i <= n; i++) {
            long next = prev + curr;
            prev = curr;
            curr = next;
        }
        return curr;
    }
}
```

在普通笔记本上，递归版一般要 300—800 ms，迭代版 0 ms。**同样的问题，算法不同就是几个数量级的差距。**

### 3.5 案例：欧几里得 gcd（递归恰到好处）

求两个数的最大公约数，欧几里得算法说：`gcd(a, b) = gcd(b, a % b)`，直到 `b == 0` 时 `a` 就是答案。

```java
public static int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}
```

调用 `gcd(48, 18)`：

```text
gcd(48, 18) → gcd(18, 12) → gcd(12, 6) → gcd(6, 0) → 6
```

短短几行，语义几乎是数学公式的直译——这就是"递归恰到好处"的场景。

### 3.6 递归 vs 循环

| 维度 | 递归 | 循环 |
|------|------|------|
| 可读性 | 分治问题（树、目录、数学定义）非常自然 | 顺序处理更直观 |
| 性能 | 有方法栈开销 | 通常更快 |
| 内存 | 栈深度受限（默认几百 KB） | 稳定 |
| 使用建议 | 表达优雅、栈深度可控 | 追求性能、深度较大 |

**一句话总结**：能用循环解决的，不要滥用递归。递归是"表达"武器，不是"性能"武器。

### 3.7 让 AI 帮你验证

在通义灵码里可以粘贴这段提示词，来对比两种实现：

```text
帮我用 Java 实现斐波那契数列的两种解法：
1. 递归版本（并标注它为什么慢）；
2. 迭代 / 动态规划版本；
3. 分别打印计算 fib(40) 所耗时间做对比。
```

AI 通常会准确解释"指数级重复子问题"这一术语，并给出记忆化 / 动态规划优化。你可以逐条对比它给出的解释和这份讲义。

### 3.8 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `StackOverflowError` | 忘写终止条件 / 规模没缩小 / 深度过大（>几千层） |
| `fib(45)` 卡死 | 指数级重复子问题，请改迭代或加记忆化 |
| 递归结果不对 | 递归表达式写错（例如漏乘、加错项） |
| 递归返回值忘 return | 编译报错或返回默认值 |
| 无谓深度递归（如求和） | 用循环 O(n) 即可，用不着栈 |

### 3.9 练习 / 思考

1. 用递归实现 `sum(int n) = 1+2+…+n`，画出 `sum(4)` 的调用栈展开图。
2. 用递归判断字符串是否回文：`boolean isPalindrome(String s, int i, int j)`。
3. 用递归打印一个正整数的每一位，例如 `printDigits(12345)` 输出 `1 2 3 4 5`。
4. 用递归实现 `power(int base, int exp)`。想一想能不能做到 `O(log n)` ？
5. （思考）为什么递归天然适合"文件目录遍历"？和循环相比它省了什么代码？

---

## 第 4 讲：大学生实训管理系统——需求分析与命令行菜单主循环

### 4.1 从"练手"迈到"造轮子"

到今天为止，我们学过 **变量运算符 → 分支循环 → 一维 / 二维数组 → 方法 → 递归**。零散的知识点已经够多了，但学生常有一个疑问："这些语法真的能拼出一个'完整程序'吗？"

答案是：能。**今天下半段的三讲**，我们不再学新语法，用手上工具搭一个真实场景的小系统——**大学生实训管理系统**。

我们的目标不是让代码"看起来完整"，而是走完**工程化的四步节奏**：

1. **需求分析**：想清楚要做什么。
2. **系统设计**：流程图 + 数据结构。
3. **骨架代码**：先跑起来 `main + 菜单`，功能都留 TODO。
4. **填充功能**：把每个 TODO 落地。

这一节先走完 1—3 步，第 5 讲走完第 4 步。

### 4.2 需求分析——功能一览

假设你是一位辅导员，需要一个软件管理一个班 50 名学生的实训信息。你希望它能干什么？

我们把常识梳理成 7 条：

1. **添加学生**（学号、姓名、年龄、Java 成绩）
2. **查看所有学生**（表格形式）
3. **按学号查找学生**
4. **修改成绩**
5. **删除学生**
6. **统计信息**（人数、平均分、最高最低分、及格率）
7. **退出**

7 条需求，也就是 7 个菜单项。你会发现：**先想清楚做什么，再动手写代码**，永远比"边写边想"快得多。

### 4.3 系统流程图

用一张图把执行流程画清楚：

```text
[启动]
   ↓
[显示菜单]
   ↓
[用户输入编号 op]
   ↓
   ├─ op = 1 → 添加学生 → 回到菜单
   ├─ op = 2 → 查看所有 → 回到菜单
   ├─ op = 3 → 查找     → 回到菜单
   ├─ op = 4 → 修改     → 回到菜单
   ├─ op = 5 → 删除     → 回到菜单
   ├─ op = 6 → 统计     → 回到菜单
   ├─ op = 7 → 退出（return）
   └─ 其它    → 提示无效
```

这张图对应到代码就是**主循环 + switch**。

### 4.4 数据结构设计——四个并列一维数组

一个学生有 4 个字段：学号、姓名、年龄、成绩。**50 名学生怎么存？**

在还没学"类"之前，我们采用**四个并列的一维数组**，按**同下标对齐**：

```java
static String[] ids     = new String[50];   // 学号
static String[] names   = new String[50];   // 姓名
static int[]    ages    = new int[50];      // 年龄
static double[] scores  = new double[50];   // 成绩
static int      count   = 0;                // 当前实际学生数
```

例如 `ids[3] = "1004"`, `names[3] = "赵六"`, `ages[3] = 20`, `scores[3] = 87.5`——四个数组的下标 3 位置，共同描述"赵六"这一个学生。

`count` 是一个**关键**变量：它记录当前**真实有效**的学生数，永远 ≤ 50。所有增、查、遍历都要用 `count` 而不是 `50`——否则你会看到一堆 null 和 0。

**为什么现在要这样丑陋地写？**

因为我们还没学"类"。这四个数组的丑陋恰恰**制造了动机**——第 7 章你会看到，`Student` 类如何用**一行**代替这 5 行，`Student[] students` 如何整齐地取代四个并列数组。**先感受痛苦，再享受进化。**

### 4.5 菜单主循环骨架

```java
public static void main(String[] args) {
    while (true) {
        printMenu();
        System.out.print("请输入操作编号：");
        int op = sc.nextInt();
        switch (op) {
            case 1 -> addStudent();
            case 2 -> listStudents();
            case 3 -> findStudent();
            case 4 -> modifyScore();
            case 5 -> deleteStudent();
            case 6 -> printStats();
            case 7 -> {
                System.out.println("再见！");
                return;
            }
            default -> System.out.println("无效编号，请重新输入。");
        }
    }
}
```

要点解读：
- `while (true)` 让菜单**永远循环**，直到 `return` 才退出。这是命令行系统的**标准模式**。
- **箭头形 switch**（JDK 14+）：写 `case 1 -> ...` 就够了，**不用写 `break`**，天然防"击穿"。旧写法 `case 1: xxx; break;` 我们不再推荐。
- 每一个 case 都调用一个"未来才会实现"的方法——这些方法我们先只写签名和一句 `System.out.println("[TODO]...")` ，让骨架**先跑起来**。
- 所有方法都写 `static`：因为 `main` 是 static 的，只能直接调 static 方法。

### 4.6 Scanner 快速回顾

`Scanner` 是 Java 读取输入的经典工具：

| 方法 | 读取内容 | 特点 |
|------|------|------|
| `nextInt()` | 一个 int | 只读数字，不吃换行符 |
| `nextDouble()` | 一个 double | 只读数字，不吃换行符 |
| `next()` | 一个"单词"（空白分隔） | 读到空白就停 |
| `nextLine()` | 一整行（含空格） | 会连同结尾换行符一起吃掉 |

⚠️ **典型坑**：`nextInt()` 后紧跟 `nextLine()`，会因为 `nextInt()` 没吃换行符，导致 `nextLine()` 读到一个空字符串。今天我们只用 `nextInt / next / nextDouble`，可以规避这个问题；如果一定要读整行，请多调一次 `sc.nextLine()` 消耗残留换行。

### 4.7 完整骨架代码（可直接跑）

把下面这段整段拷贝到 IDEA 的 `StudentSystem.java` 文件里：

```java
import java.util.Scanner;

public class StudentSystem {
    static String[] ids     = new String[50];
    static String[] names   = new String[50];
    static int[]    ages    = new int[50];
    static double[] scores  = new double[50];
    static int      count   = 0;

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            System.out.print("请输入操作编号：");
            int op = sc.nextInt();
            switch (op) {
                case 1 -> System.out.println("[TODO] 添加学生");
                case 2 -> System.out.println("[TODO] 查看所有");
                case 3 -> System.out.println("[TODO] 查找");
                case 4 -> System.out.println("[TODO] 修改");
                case 5 -> System.out.println("[TODO] 删除");
                case 6 -> System.out.println("[TODO] 统计");
                case 7 -> {
                    System.out.println("再见！");
                    return;
                }
                default -> System.out.println("无效编号，请重新输入。");
            }
        }
    }

    static void printMenu() {
        System.out.println();
        System.out.println("========== 大学生实训管理系统 ==========");
        System.out.println("1. 添加学生");
        System.out.println("2. 查看所有学生");
        System.out.println("3. 按学号查找");
        System.out.println("4. 修改成绩");
        System.out.println("5. 删除学生");
        System.out.println("6. 统计信息");
        System.out.println("7. 退出");
        System.out.println("=========================================");
    }
}
```

**预期运行效果**：菜单能反复出现，输入 1—6 打印 `[TODO]`，输入 7 打印"再见！"退出，其它数字提示无效。

**这就是"骨架先行、功能后填"**——AI 编程助手最推荐的开发节奏。骨架跑通那一刻，成就感来自"我看见了系统的形状"。

### 4.8 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 编译时报"找不到符号 sc" | 忘了 `import java.util.Scanner` 或 `Scanner sc = new Scanner(System.in);` |
| 输入非数字（例如 `abc`）程序崩溃 | `nextInt` 遇到非数字抛 `InputMismatchException`，第 6 讲会给出更健壮的写法 |
| switch 编译报错 "-> 意料之外" | JDK 版本低于 14，请确认是 JDK 25 或至少 17 |
| 主循环退不出去 | 忘了 case 7 里的 `return`，只写了 `break` |
| main 里调用 `printMenu()` 报静态错 | `printMenu` 不加 `static` |

### 4.9 练习 / 思考

1. 把上面骨架代码复制到 IDEA 中跑通，输入 1—8 各测一次，观察 default 分支。
2. 把退出编号从 `7` 改成 `0`，相应调整 switch。
3. 在 `printMenu` 顶部加一行"当前学生数：X"，动态显示 `count`。
4. （思考）为什么要把菜单打印**放在方法里**，而不是直接写在 `while(true)` 里？（提示：DRY / 单一职责）

---

## 第 5 讲：大学生实训管理系统——增删改查功能实现

### 5.1 今天要把 6 个 TODO 全部填上

昨天骨架跑通，`case 1—6` 里都是 `[TODO]`。今天要把这 6 个方法全部实现出来。顺序不是随便定的：

1. 先写**通用工具 `indexOf`**：因为查找是增、改、删的基石。
2. 再写**添加 `addStudent`**：容量检查 + 学号唯一性 + 四数组同步写入。
3. 然后是**查看 `listStudents`**：最简单，遍历打印。
4. **查找 `findStudent`** 和 **修改 `modifyScore`**：几乎都是 `indexOf` 的调用。
5. **删除 `deleteStudent`**：数组删除的经典套路——**元素前移 + count--**。
6. 最后**统计 `printStats`**：**一次遍历、多个累加量**。

写完你会拥有一个约 130 行、可交互、能真跑的命令行系统。

### 5.2 通用工具：`indexOf`

**"按学号找到对应下标"** 是几乎所有功能都要用的一步。抽出来：

```java
static int indexOf(String id) {
    for (int i = 0; i < count; i++) {
        if (ids[i].equals(id)) return i;
    }
    return -1;
}
```

两个细节，**都是常考点**：

1. 循环边界是 **`i < count`** 而不是 `i < ids.length`——因为数组分配了 50 格，但当前只有 `count` 个是有效的。
2. **字符串比较必须用 `equals`**，绝对不能用 `==`：`==` 比较的是**引用地址**，两个字符串"内容相同但对象不同"时 `==` 返回 false。这一节故意留下这个坑，第 11 章会详解 `String` 常量池。

**没找到**约定返回 **`-1`**——业界通用惯例。

### 5.3 添加学生：`addStudent`

```java
static void addStudent() {
    if (count >= ids.length) {
        System.out.println("班级已满，无法继续添加。");
        return;
    }
    System.out.print("学号：");
    String id = sc.next();
    if (indexOf(id) != -1) {
        System.out.println("该学号已存在。");
        return;
    }
    System.out.print("姓名：");
    String name = sc.next();
    System.out.print("年龄：");
    int age = sc.nextInt();
    System.out.print("Java 成绩：");
    double score = sc.nextDouble();

    ids[count]    = id;
    names[count]  = name;
    ages[count]   = age;
    scores[count] = score;
    count++;
    System.out.println("添加成功。");
}
```

关注三个"守卫"：
- **容量检查**放在最前面，避免越界。
- **唯一性检查**用 `indexOf`——复用即价值。
- **同步四数组** + **count++**：只要有一个数组写漏，后续查询就会错位。

### 5.4 查看所有学生：`listStudents`

```java
static void listStudents() {
    if (count == 0) {
        System.out.println("暂无学生。");
        return;
    }
    System.out.println("学号\t姓名\t年龄\t成绩");
    for (int i = 0; i < count; i++) {
        System.out.println(ids[i] + "\t" + names[i] + "\t" + ages[i] + "\t" + scores[i]);
    }
}
```

**空数据判断放最前**——好的 UX 都这样。

### 5.5 查找和修改

`findStudent`：

```java
static void findStudent() {
    System.out.print("请输入要查找的学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) {
        System.out.println("未找到。");
        return;
    }
    System.out.println("学号：" + ids[i]);
    System.out.println("姓名：" + names[i]);
    System.out.println("年龄：" + ages[i]);
    System.out.println("成绩：" + scores[i]);
}
```

`modifyScore`：

```java
static void modifyScore() {
    System.out.print("请输入学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) {
        System.out.println("未找到。");
        return;
    }
    System.out.print("请输入新成绩：");
    scores[i] = sc.nextDouble();
    System.out.println("修改成功。");
}
```

**看到没**——一旦 `indexOf` 抽出来，"按学号操作"就变成一行调用。**抽象带来自由**。

### 5.6 删除学生：数组删除的经典套路

数组的容量是**固定的**，"删除"其实是**把被删元素后面的所有元素前移一位**，然后 `count--`：

```text
删除下标 i 的元素（假设 count = 5，删下标 1）：
   下标：  0    1    2    3    4
   删前：  A    B    C    D    E     count=5
                ↑ 删除 B
   过程：       C ← D ← E              前移
   删后：  A    C    D    E    (E?)   count=4
                              ↑ 这里的旧值虽然还在，但已在有效范围外
```

代码：

```java
static void deleteStudent() {
    System.out.print("请输入要删除的学号：");
    String id = sc.next();
    int i = indexOf(id);
    if (i == -1) {
        System.out.println("未找到。");
        return;
    }
    for (int j = i; j < count - 1; j++) {
        ids[j]    = ids[j + 1];
        names[j]  = names[j + 1];
        ages[j]   = ages[j + 1];
        scores[j] = scores[j + 1];
    }
    // 清理"残留"：让 count 之外的位置回到默认值，方便调试
    ids[count - 1]   = null;
    names[count - 1] = null;
    ages[count - 1]  = 0;
    scores[count - 1] = 0;
    count--;
    System.out.println("删除成功。");
}
```

**最容易踩的坑**：循环条件是 `j < count - 1`，**不是** `j < count`、也**不是** `j <= count - 1`：
- 写成 `j < count`：`arr[j + 1] = arr[count]`——访问 count 位置（无效数据），逻辑错。
- 写成 `j <= count - 1`：同上，等价于 `j < count`。
- 正确的 `j < count - 1`：让 `j + 1` 最大只到 `count - 1`，恰好覆盖到最后一个有效元素。

**为什么最后要把 `ids[count-1]` 清成 null？** 严格说不是必须——反正 `count--` 后那个位置已经"逻辑上不存在"了。但清一下有两个好处：① 调试时看数组截图更干净；② 避免被 GC 意外持有的引用泄漏（第 9 章讲）。

### 5.7 统计信息：一次遍历，多个累加

```java
static void printStats() {
    if (count == 0) {
        System.out.println("暂无数据。");
        return;
    }
    double sum = 0, max = scores[0], min = scores[0];
    int passCount = 0;
    for (int i = 0; i < count; i++) {
        sum += scores[i];
        if (scores[i] > max) max = scores[i];
        if (scores[i] < min) min = scores[i];
        if (scores[i] >= 60) passCount++;
    }
    System.out.println("总人数：" + count);
    System.out.printf("平均分：%.2f%n", sum / count);
    System.out.println("最高分：" + max);
    System.out.println("最低分：" + min);
    System.out.printf("及格率：%.2f%%%n", passCount * 100.0 / count);
}
```

**一次循环、四个累加量**——这是数组统计的**高效模式**。如果你循环 4 次每次算一个量，速度是它的 4 倍慢。

注意两个初值：
- `sum = 0`：累加起点。
- `max = min = scores[0]`：**不要初始化为 0 或 Integer.MAX_VALUE**——如果全班都是负分或都是低分，会出错。**用第一个真实元素做初值最安全**（前提是空判断已放在最前面）。

### 5.8 完整代码（可直接跑，约 130 行）

```java
import java.util.Scanner;

public class StudentSystem {
    static String[] ids     = new String[50];
    static String[] names   = new String[50];
    static int[]    ages    = new int[50];
    static double[] scores  = new double[50];
    static int      count   = 0;

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            System.out.print("请输入操作编号：");
            int op = sc.nextInt();
            switch (op) {
                case 1 -> addStudent();
                case 2 -> listStudents();
                case 3 -> findStudent();
                case 4 -> modifyScore();
                case 5 -> deleteStudent();
                case 6 -> printStats();
                case 7 -> {
                    System.out.println("再见！");
                    return;
                }
                default -> System.out.println("无效编号，请重新输入。");
            }
        }
    }

    static void printMenu() {
        System.out.println();
        System.out.println("========== 大学生实训管理系统 ==========");
        System.out.println("当前学生数：" + count);
        System.out.println("1. 添加学生");
        System.out.println("2. 查看所有学生");
        System.out.println("3. 按学号查找");
        System.out.println("4. 修改成绩");
        System.out.println("5. 删除学生");
        System.out.println("6. 统计信息");
        System.out.println("7. 退出");
        System.out.println("=========================================");
    }

    static int indexOf(String id) {
        for (int i = 0; i < count; i++) {
            if (ids[i].equals(id)) return i;
        }
        return -1;
    }

    static void addStudent() {
        if (count >= ids.length) {
            System.out.println("班级已满，无法继续添加。");
            return;
        }
        System.out.print("学号：");
        String id = sc.next();
        if (indexOf(id) != -1) {
            System.out.println("该学号已存在。");
            return;
        }
        System.out.print("姓名：");
        String name = sc.next();
        System.out.print("年龄：");
        int age = sc.nextInt();
        System.out.print("Java 成绩：");
        double score = sc.nextDouble();

        ids[count]    = id;
        names[count]  = name;
        ages[count]   = age;
        scores[count] = score;
        count++;
        System.out.println("添加成功。");
    }

    static void listStudents() {
        if (count == 0) {
            System.out.println("暂无学生。");
            return;
        }
        System.out.println("学号\t姓名\t年龄\t成绩");
        for (int i = 0; i < count; i++) {
            System.out.println(ids[i] + "\t" + names[i] + "\t" + ages[i] + "\t" + scores[i]);
        }
    }

    static void findStudent() {
        System.out.print("请输入要查找的学号：");
        String id = sc.next();
        int i = indexOf(id);
        if (i == -1) { System.out.println("未找到。"); return; }
        System.out.println("学号：" + ids[i]);
        System.out.println("姓名：" + names[i]);
        System.out.println("年龄：" + ages[i]);
        System.out.println("成绩：" + scores[i]);
    }

    static void modifyScore() {
        System.out.print("请输入学号：");
        String id = sc.next();
        int i = indexOf(id);
        if (i == -1) { System.out.println("未找到。"); return; }
        System.out.print("请输入新成绩：");
        scores[i] = sc.nextDouble();
        System.out.println("修改成功。");
    }

    static void deleteStudent() {
        System.out.print("请输入要删除的学号：");
        String id = sc.next();
        int i = indexOf(id);
        if (i == -1) { System.out.println("未找到。"); return; }
        for (int j = i; j < count - 1; j++) {
            ids[j]    = ids[j + 1];
            names[j]  = names[j + 1];
            ages[j]   = ages[j + 1];
            scores[j] = scores[j + 1];
        }
        ids[count - 1] = null;
        names[count - 1] = null;
        ages[count - 1] = 0;
        scores[count - 1] = 0;
        count--;
        System.out.println("删除成功。");
    }

    static void printStats() {
        if (count == 0) { System.out.println("暂无数据。"); return; }
        double sum = 0, max = scores[0], min = scores[0];
        int passCount = 0;
        for (int i = 0; i < count; i++) {
            sum += scores[i];
            if (scores[i] > max) max = scores[i];
            if (scores[i] < min) min = scores[i];
            if (scores[i] >= 60) passCount++;
        }
        System.out.println("总人数：" + count);
        System.out.printf("平均分：%.2f%n", sum / count);
        System.out.println("最高分：" + max);
        System.out.println("最低分：" + min);
        System.out.printf("及格率：%.2f%%%n", passCount * 100.0 / count);
    }
}
```

### 5.9 一次完整的运行验证

按顺序敲入下列输入，观察输出：

```text
1 → 1001 张三 20 88.5
1 → 1002 李四 21 72.0
1 → 1003 王五 19 55.0
2  （应显示 3 行表格）
3 → 1002  （应显示李四信息）
4 → 1003  → 65.0  （王五成绩改到 65）
5 → 1002  （删除李四）
2  （应只剩 2 行：张三、王五；且没有 null 出现）
6  （应显示：总人数 2、平均分、及格率 100%）
7  （退出）
```

如果第 8 步中出现 `null` 或者结果错位——那就是"数组删除"的边界写错了，去看 5.6 节的循环条件。

### 5.10 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 查找永远返回 -1 | `ids[i].equals(id)` 写成 `ids[i] == id` |
| 删除后有 null 出现 / 结果错位 | 循环边界 `j <= count - 1` 或 `j < count`（都错） |
| 添加后统计里出现 0.0 | 只写了 `scores[count] = score;` 忘了 `count++` |
| `nextInt`后 `nextLine`读到空串 | `nextInt` 不吃换行符（本讲用 `next` 已规避） |
| `count / count` 报除 0 | 空数据时应先 `if (count == 0) return;` |

### 5.11 练习 / 思考

1. 把整段代码复制运行，按 5.9 的用例走完 8 步验证。
2. 给"学号"加校验：必须是 **4 位纯数字**，否则拒绝添加。（提示：`id.length() == 4` 加 `id.matches("\\d{4}")`）
3. 新增菜单项"按成绩从高到低查看所有学生"。注意排序时**四个数组要同步交换**。
4. 把 5.6 的删除操作抽出一个 `removeAt(int index)` 方法，减少重复代码。
5. （思考）"四并列数组"最痛的时刻是什么时候？（提示：如果要给学生新增一个"手机号"字段，你要动几处？）

---

## 第 6 讲：使用 AI 编程工具排错、审查及优化（Day 一 / 二 / 三 收官）

### 6.1 一个能跑的系统，不等于一个好系统

上一节我们做出了一个"看上去能跑"的实训管理系统。但真实软件工程告诉我们：**跑通只是起点，不是终点**。这一节我们请通义灵码 / Claude 出手，做三件事：

1. **排错（Debug）**：找出隐藏 Bug。
2. **审查（Review）**：从多维度评估代码质量。
3. **优化（Refactor）**：改进结构和用户体验，功能不变。

我们要学的不仅是"怎么让 AI 帮我"，更是"**怎么和 AI 高效协作**"——这是你未来 10 年最重要的编程技能之一。

### 6.2 故意注入 3 个 Bug（"练兵场"）

把 5.8 完整代码复制一份，作为"练兵版"，故意注入下面 3 个 Bug：

**Bug 1**：把 `deleteStudent` 里 `j < count - 1` 改成 `j <= count - 1`。
```java
for (int j = i; j <= count - 1; j++) {   // ❌
    ids[j] = ids[j + 1];   // 越界
    ...
}
```

**Bug 2**：把 `indexOf` 里的 `.equals(id)` 改成 `== id`。
```java
if (ids[i] == id) return i;   // ❌ 引用比较，会导致偶尔找不到
```

**Bug 3**：删掉 `printStats` 开头的 `if (count == 0) return;`——空数据时 `sum / count` 会 `ArithmeticException`。

⚠️ 三个都编译得过，程序也能启动——这就是最难排的 Bug："**它跑得起来，但答案是错的**"。

### 6.3 提示词模板 1：排错

打开通义灵码 / Claude，把练兵版代码整段贴过去，然后加上：

```text
你是资深 Java 讲师。下面是一段学生管理系统代码，请帮我：
1. 逐行审查是否有语法错误、逻辑错误、异常边界问题；
2. 用「Bug 编号 - 位置 - 原因 - 修复建议」的表格给出反馈；
3. 用 IDEA Debug 步骤复现其中最严重的 1 个 Bug。

[粘贴代码]
```

AI 通常会准确定位：
- `deleteStudent` 里循环边界会导致 `ArrayIndexOutOfBoundsException`。
- `indexOf` 里 `==` 应改为 `equals`。
- `printStats` 缺少 `count == 0` 的判空。

**关键**：不要盲信。你要**逐条打开 IDEA 复现一遍**——AI 找到的每一条都要用自己的调试验证。这个过程本身就是极好的学习。

### 6.4 提示词模板 2：代码审查

排完错，接着做 Review。这次目的不是找 Bug，是**提高代码质量**：

```text
请从以下维度对上面这段代码做代码 Review：
1. 命名规范；
2. 方法长度与单一职责；
3. 边界处理（空数组、非法输入、数组越界）；
4. 用户体验（提示信息是否清晰）；
5. 未来可扩展性。
最后给出 1—10 分打分及最重要的 3 条改进建议。
```

常见反馈（可以对照你自己的结果）：
- 输入未做类型校验，用户输入 `abc` 会崩溃。
- `Scanner sc` 从未 `close()`。
- 4 个并列数组紧耦合，任何字段增删都要动 4 处——**这是第 7 章引入"类"的动机**。
- 一些提示文本不够友好，比如"未找到" ← 可以改成"未找到学号为 XXXX 的学生"。

**AI 的反馈要按 3 类分组**：

| 分类 | 例子 | 处理 |
|------|------|------|
| 立即采纳 | 增加输入类型校验 | 直接改 |
| 需要讨论 | 改用 `Map<String, Student>` | 先想清楚为什么 |
| 暂不采纳 | "应该使用 Spring Boot" | 目前不合上下文 |

**不要盲目全采纳**——AI 的建议永远是**参考**，不是命令。

### 6.5 提示词模板 3：重构

第三步是**功能不变、结构优化**：

```text
请重构这段代码，做以下改动，保持功能不变：
1. 提取一个 readInt(String prompt) 方法，读取整数并对非法输入循环重试；
2. 优化输出格式，使用 String.format 生成对齐的表格；
3. 加入更清晰的中文提示信息。
最后附上"重构前后对比"清单。
```

AI 会返回一份新代码。**你的工作**是：
- 逐行 diff——不接受你没看懂的每一处。
- 跑一遍——确保所有原有功能仍然通过。
- 挑战 AI——例如"为什么用 `while (true)` 而不是 `do-while`？"，让 AI 说理由。

一个典型的 `readInt` 收获（你可以直接用到自己项目里）：

```java
static int readInt(String prompt) {
    while (true) {
        System.out.print(prompt);
        if (sc.hasNextInt()) {
            return sc.nextInt();
        } else {
            System.out.println("输入非法，请重新输入整数。");
            sc.next();   // 消耗掉非法 token，否则死循环
        }
    }
}
```

把 `main` 里 `int op = sc.nextInt();` 改成 `int op = readInt("请输入操作编号：");`，再输入 `abc`——不再崩溃，而是提示重输。

### 6.6 与 AI 协作的 4 条铁律

写在黑板上、写在心里：

1. **先自己写完能跑的版本**：让 AI 从零生成的代码常有幻觉，让 AI **改**一份已经能跑的代码，可靠得多。
2. **每次只让 AI 做一件事**：排错、审查、重构分开，AI 一次给你 20 条建议，你根本消化不完。
3. **对每一条 AI 建议都自己验证**：跑一次、看一遍、想一下"AI 说得对吗"。
4. **让 AI 解释理由**：所有请求后面加"并说明理由"。得到的解释往往比结果本身更重要。

### 6.7 一次完整的"小步慢跑"对话

```text
👤 帮我审查上面的代码。
🤖 [给出 5 条建议]
👤 请只保留其中最关键的一条，帮我改代码。
🤖 [仅修改一处，给出 diff]
👤 好，接着帮我加入学号格式校验（4 位数字）。
🤖 [新增 isValidId 方法]
👤 请用 3 组测试用例验证 isValidId。
🤖 [给出通过用例]
```

对话的**节奏感**是：一次一小步、每步都可复现、每步都跑一遍。这就叫**小步慢跑（Small Steps）**——软件工程界公认的最佳协作节奏，用在 AI 身上尤其有效。

### 6.8 pitfall / AI 协作陷阱

| 现象 | 原因 / 修法 |
|------|------|
| AI 生成的代码"看着对，跑不通" | 有幻觉（编造 API），一定要**先跑再信** |
| AI 建议全盘接受，越改越乱 | 一次改动太多，回退困难；改用**小步慢跑** |
| AI 给出深奥的重构，看不懂 | 让 AI 解释理由，或分步骤展开 |
| 复制别人的代码问 AI，被指出 Bug 但你不理解 | 让 AI 用 IDEA Debug 步骤复现给你看 |
| 依赖 AI 越来越多，自己写代码越来越慢 | 每周有一天"关灯写码"，只靠自己 |

### 6.9 练习 / Day 03 收官作业

**基础作业（每人必做）**：

1. 把自己的 `StudentSystem.java` 完整代码贴给通义灵码，跑一次 **排错提示词**，把 AI 找到的 Bug 用 markdown 表格整理出来。
2. 再跑一次 **审查提示词**，把 5 维反馈按"立即采纳 / 需要讨论 / 不采纳"分类。
3. 挑选自己认为最关键的 1 条建议，让 AI 单独帮你重构，运行验证。
4. 应用 6.5 节的 `readInt` 方法，让程序在输入非数字时不再崩溃。

**综合作业（第一阶段收官）**：

5. 完成第 1—5 讲每讲布置的作业（矩阵转置 / MathToolkit / 递归 gcd / 菜单 count 显示 / 学号 4 位校验）。
6. 用 AI 帮你把统计里的"及格率"改为**可配置的任意分数线通过率**（例如 70 分以上通过率）。
7. 用第 4 章的排序为 `listStudents` 增加"按成绩降序查看"选项，注意四数组同步交换。
8. （挑战）让 AI 把删除操作抽出 `removeAt(int index)` 方法，减少重复代码。

**Day04 预习**：

9. 阅读第 7 章前 3 页，猜一下"类（class）"如何解决**四个并列数组**的丑陋。
10. （思考）如果 `Student` 是一个类，那么"添加学生"会变成怎样的一行代码？

### 6.10 Day01—Day03 第一阶段全部知识点回顾

**Day01：Java 起步 + 变量运算符 + 流程控制入门**

- 环境：JDK 25 LTS、IntelliJ IDEA、通义灵码。
- 数据类型：整型（byte/short/int/long）、浮点（float/double）、字符 char、布尔 boolean、引用 String。
- 字面量、进制、类型转换（自动 vs 强制）。
- 运算符：算术 / 关系 / 逻辑 / 三元 / 位运算 / 复合赋值。
- 流程控制：if/else 三分支写法、switch（经典 + 箭头形）。

**Day02：分支循环深入 + 一维数组 + 查找排序**

- 三种循环：`for` / `while` / `do-while`；break / continue / 带标签跳出。
- 一维数组的定义（静态 / 动态）、遍历（普通 for / 增强 for）、常见操作（最大 / 最小 / 反转 / 复制）。
- 顺序查找、冒泡排序、选择排序、（可选：插入排序）。

**Day03：二维数组 + 方法 + 递归 + 综合案例 + AI 辅助**

- 二维数组：三种初始化 + 双重循环遍历 + 不规则数组。
- 方法：定义语法、形参 vs 实参、按值 / 按引用（地址副本）传递、方法重载、单一职责。
- 递归：三要素、阶乘、斐波那契（反面教材）、gcd、递归 vs 循环。
- 综合案例：大学生实训管理系统（需求 → 骨架 → 增删改查 → AI 排错优化）。
- AI 协作：三份提示词模板 + 4 条铁律 + 小步慢跑。

**你现在拥有的能力：**
- 能读懂并写出 200 行左右的 Java 命令行程序。
- 能用一维、二维数组建模现实数据。
- 能用方法组织代码、复用逻辑。
- 能与 AI 编程助手协作，做排错、审查、重构。
- 已经建立"先设计 → 骨架 → 填充 → AI 审查"的工程节奏。

### 6.11 Day04 面向对象阶段预告

**第 7 章：类与对象、封装、构造方法。**

- 用 `Student` 类替代四个并列数组：一行 `Student s = new Student("1001", "张三", 20, 88.5);` 代替 5 行赋值。
- 封装：`private` 字段 + `getter/setter`，从此别人不能瞎改你的成绩字段。
- 构造方法：让"创建对象"就等于"赋值完成"。

**第 8 章：继承、多态、抽象类、接口——Java 面向对象的三大支柱。**

- `extends`：让 `Undergraduate extends Student`，不用重写共有代码。
- 多态：`Student s = new Undergraduate()`，运行时按真实类型调用方法。
- 抽象类 / 接口：用于"定义规矩，不写实现"。

**第 9 章：常见 API + 集合基础。**

- 字符串常见方法：`length / equals / substring / split / trim`……
- `ArrayList`：从此不再需要担心"容量、删除时前移"这些烦恼。
- `HashMap`：`Map<String, Student>` 让"按学号查找"变成 O(1)。

**一句话**：你今天写的代码，明天会因为 OOP 而**变得优雅一半、健壮一倍**。

---

## Day03 全天总结

### 一张图串六讲

```text
第 1 讲 二维数组      ─── int[][] 表格建模：先分配外层，再逐行 new
第 2 讲 方法 + 重载   ─── 复用第一步：入参 / 出参 / 值传 vs 引用传
第 3 讲 递归           ─── 方法调用自己 = 拆问题；base case 是唯一护栏

第 4 讲 实训系统 v1   ─── 需求分析 + 主菜单主循环
第 5 讲 实训系统 v2   ─── 增删改查全实现（四并列数组的极限）
第 6 讲 AI 协作收官    ─── 排错 / 审查 / 重构三条铁律 + Day01—Day03 回顾
```

### 6 讲全局回顾

| 讲次 | 主题 | 一句话总结 |
|------|------|-----------|
| L1 | 二维数组 | `int[][] a = new int[m][n]`，行列都从 0 开始 |
| L2 | 方法 + 重载 | 抽相同、变不同，参数列表决定重载；值传递复制值，引用传递复制地址 |
| L3 | 递归 | 递推公式 + 出口条件；深度大心 `StackOverflowError` |
| L4 | 实训系统 v1 | 先设计菜单和数据结构，再动手；`while (true)` + `break` 收尾 |
| L5 | 实训系统 v2 | CRUD 完整实现；删除要\"前移+末位置空+计数减 1\" |
| L6 | AI 协作 | 三条铁律：只给上下文、看不懂就问、改动后必测 |

### 核心口诀

- **二维数组**：外层 `.length` = 行数，内层 `a[i].length` = 该行列数（不一定齐！）。
- **方法**：`修饰符 返回类型 方法名(参数列表) { 方法体 }`；`return` 就是出口。
- **值传递**：基本类型传副本，形参改动不影响实参；对象传"地址副本"，字段改动实参可见。
- **递归三件套**：出口条件、递推公式、参数向出口靠拢；缺一个就爆栈。
- **AI 三条铁律**：给完整上下文、看不懂就追问、改完必跑一遍再合并。

### Day04 预告

明天进入 **第一阶段收官 → 面向对象阶段**：**第 7 章：类与对象、封装、构造方法**。

- 用 `Student` 类替代四个并列数组：一行 `Student s = new Student("1001", "张三", 20, 88.5);` 代替 5 行赋值。
- 封装：`private` 字段 + `getter/setter`，从此别人不能瞎改你的成绩字段。
- 构造方法：让\"创建对象\"就等于\"赋值完成\"。

紧接着的 **第 8 章：继承、多态、抽象类、接口**——Java 面向对象的三大支柱：

- `extends`：让 `Undergraduate extends Student`，不用重写共有代码。
- 多态：`Student s = new Undergraduate()`，运行时按真实类型调用方法。
- 抽象类 / 接口：用于\"定义规矩，不写实现\"。

以及 **第 9 章：常见 API + 集合基础**：

- 字符串常见方法：`length / equals / substring / split / trim`……
- `ArrayList`：从此不再需要担心\"容量、删除时前移\"这些烦恼。
- `HashMap`：`Map<String, Student>` 让\"按学号查找\"变成 O(1)。

**一句话**：你今天写的代码，明天会因为 OOP 而**变得优雅一半、健壮一倍**。

### Day03 作业汇总

按讲次 + 收官整合，方便一次列清单（详细提示词参见 6.9 节）：

**L1（二维数组）**

1. 矩阵转置：把 `int[3][2]` 矩阵转成 `int[2][3]` 并打印。
2. 打印一张 `n × n` 的乘法表，注意行列不齐时的越界。

**L2（方法 + 重载）**

3. 写 `MathToolkit` 工具类：`max(int, int)` / `max(int, int, int)` / `max(int[])` 三重重载。
4. 用值传递 vs 引用传递写两段代码演示实参变化。

**L3（递归）**

5. 递归实现 `gcd(a, b)`，出口条件写清楚。
6. 递归斐波那契 + 迭代版，对比 `n=40` 的运行时间。

**L4—L5（实训系统）**

7. 给主菜单每次显示后加一行 `当前学生数：count`。
8. 学号 4 位校验：不合法时提示重输而不是直接返回。
9. 把删除逻辑抽成 `removeAt(int index)` 方法（可让 AI 协助）。

**L6（AI 协作 + 收官）**

10. 完整跑一次\"排错\"提示词，把 AI 找到的 Bug 用 markdown 表格整理。
11. 跑\"审查\"提示词，把 5 维反馈按\"立即采纳 / 需要讨论 / 不采纳\"分类。
12. 挑一条最关键的建议，让 AI 单独重构并运行验证。
13. 应用 6.5 节的 `readInt` 方法，让程序在输入非数字时不再崩溃。

**Day04 预习（必做）**

14. 阅读第 7 章前 3 页，猜一下\"类（class）\"如何解决**四个并列数组**的丑陋。
15. （思考）如果 `Student` 是一个类，那么\"添加学生\"会变成怎样的一行代码？

---

从 Day01 那句 `System.out.println("Hello, Java!")` 到 Day03 结束的一个 130 行命令行系统，你只用了三天。三天里你踩过 `nextInt / nextLine` 的换行坑、爆过 `StackOverflowError`、盯着 `null` 骂过删除循环、也第一次让 AI 给自己的代码打分。这些经历比语法本身更有价值。

**Day04 见——**那时我们要用一个叫做**类**的抽象工具，把今天丑陋的四个数组一并抹掉，换成一个整齐的 `Student` 对象数组。你会明白："原来我以前学的一切，都是为了理解**面向对象**做准备。"
