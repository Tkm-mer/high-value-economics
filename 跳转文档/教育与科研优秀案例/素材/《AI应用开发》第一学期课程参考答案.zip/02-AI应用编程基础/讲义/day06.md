# AI 应用编程基础——Java 基础 - 学生讲义（Day06：第 1—6 讲）

**总课时：6 讲（Day06 全天，全课程收官日）**
**适用对象：已完成 Day01—Day05 的初学者**
**版本基线：JDK 25 LTS · IntelliJ IDEA 2026.1**
**对应教材：** 第 11 章《String 与包装类》 + 第 12 章《常用容器与泛型基础》

## 本日概览

| 讲次 | 主题 | 核心产出 | 教材出处 |
|------|------|----------|----------|
| 第 1 讲 | String 类的常用方法 | 会用 `equals` 而不是 `==`；掌握 12 个 String API | 11.1 |
| 第 2 讲 | StringBuilder / StringBuffer + StringUtils 案例 | 循环拼接用 Builder；写一个工具类 | 11.2 + 11.4 |
| 第 3 讲 | 基本数据类型的包装类 | 装拆箱；Integer 缓存陷阱；null 拆箱 NPE | 11.3 |
| 第 4 讲 | ArrayList | 动态数组；遍历删除三种正确姿势 | 12.1 + 12.2 |
| 第 5 讲 | HashMap + HashSet + StudentSystemV2 | 词频统计；用 `Map<String, Student>` 重构 | 12.3 + 12.4 + 12.6 |
| 第 6 讲 | 泛型基础（全课程收官） | 泛型类 / 方法 / 接口；37 技术点主线回顾 | 12.5 + 12.8 |

> 今天是本课程最后一天。前五天磨的所有刀——变量、方法、类、封装、继承、多态、抽象、接口、Record——今天要在 `StringUtils`、`StudentSystemV2` 两个综合案例里齐刷刷用上一遍。第 6 讲末尾会有一次完整的\"37 技术点主线回顾\"和下一步学习路线，务必留够时间。

---

## 第 1 讲：String 类的常用方法

### 1.1 从 Record 到 String——不可变的老朋友

上一天我们讲了 Record，一个\"生下来就不可变\"的数据载体。今天要讲的 `String`，其实是全 Java 世界最著名的不可变类——**从 JDK 1.0 就存在了**，一直陪你写到今天。

`String` 属于 `java.lang` 包，无需 `import`。声明写在 `java.lang.String`，你去 IDE 里按住 `Ctrl` 点它，会跳到源码开头三行：

```java
public final class String
    implements java.io.Serializable, Comparable<String>, CharSequence {
    private final byte[] value;
    // ...
}
```

三个 `final` 盯紧：
- `public final class`——**这个类不能被继承**（你写不出 `class MyString extends String`）。
- `private final byte[]`——**内部字节数组的引用永不改变**。JDK 9 起从 `char[]` 换成 `byte[]` 是为了给 Latin-1 编码的字符串省一半内存。
- 所有\"修改\"方法都是**返回新对象**，从来不改自己。

一句话钉板：**任何看起来像\"改字符串\"的操作，其实都是\"造一个新字符串返回\"。原对象内容永远不变。**

### 1.2 三种创建方式与常量池

```java
String s1 = "Hello";                       // 字面量：走字符串常量池
String s2 = "Hello";                       // 与 s1 是同一个池对象
String s3 = new String("Hello");           // 显式 new：堆里另开一块
System.out.println(s1 == s2);              // true（同一地址）
System.out.println(s1 == s3);              // false（不同地址）
System.out.println(s1.equals(s3));         // true（内容相同）
```

内存布局是这样的：

```text
栈                    堆
────                  ────────────────────
s1 ──┐                 [常量池]
s2 ──┼──────────────→  "Hello"    ← 只有一份
s3 ─────→ new String ─→ 内部 value 指回池中 "Hello"
              │
              这是堆里另开的一个 String 壳子
```

`s1` 和 `s2` 都直接指向常量池那份 `"Hello"`——**相同字面量在池里只存一份，是 JVM 的优化**。而 `new String("Hello")` 会在堆里另开一块内存做壳子，只是它内部的 `byte[]` 仍指回池中那份。

**结论**：`==` 比的是引用地址，`equals` 比的是内容。**字符串比较必须用 `equals`**，`==` 只是在字面量场景下\"碰巧对\"，一换到 `new String` 或者用户输入就会翻车。

> 💡 **常量池位置**：JDK 7+ 起，字符串常量池挪到了**堆**里的一个特殊区域（StringTable）；早期在方法区 / PermGen。这是常见面试题。

如果需要把一个 `new String(...)` 也放进池中，用 `intern()`：

```java
String a = new String("abc").intern();
String b = "abc";
System.out.println(a == b);   // true
```

`intern()` 的语义：**如果池中已有相同内容的串，返回池中引用；没有则先放进池再返回**。

### 1.3 12 个高频 API 一览表

**所有方法都不改变原字符串**——记住这句，后面就不会写出 `s.trim()` 却不接收返回值的错误。

| 方法 | 作用 | 例子 → 结果 |
|------|------|-------------|
| `length()` | 长度 | `"hi".length()` → 2 |
| `charAt(i)` | 第 i 个字符 | `"hi".charAt(0)` → `'h'` |
| `equals(o)` | 内容相等 | `"a".equals("a")` → true |
| `equalsIgnoreCase(o)` | 忽略大小写 | `"A".equalsIgnoreCase("a")` → true |
| `toLowerCase() / toUpperCase()` | 大小写转换 | `"Hi".toLowerCase()` → `"hi"` |
| `trim() / strip()` | 去首尾空白 | `"  hi  ".strip()` → `"hi"` |
| `substring(a, b)` | **左闭右开**截取 | `"hello".substring(1, 4)` → `"ell"` |
| `indexOf(s)` | 首次出现下标 | `"hello".indexOf("l")` → 2 |
| `lastIndexOf(s)` | 最后一次出现下标 | `"hello".lastIndexOf("l")` → 3 |
| `contains(s)` | 是否包含 | `"hello".contains("ell")` → true |
| `startsWith / endsWith` | 前缀 / 后缀 | `"hello.jpg".endsWith(".jpg")` → true |
| `replace(a, b)` | **全部**替换 | `"aaa".replace('a','b')` → `"bbb"` |
| `split(regex)` | 按正则分割 | `"a,b,c".split(",")` → `[a, b, c]` |
| `isEmpty() / isBlank()` | 空 / 全空白判断 | `"   ".isBlank()` → true |

**分组记忆**：
- **查询类**：`length` / `charAt` / `indexOf` / `lastIndexOf`
- **判断类**：`equals` / `contains` / `startsWith` / `endsWith` / `isEmpty` / `isBlank`
- **转换类**：`substring` / `strip` / `replace` / `toLowerCase` / `toUpperCase`
- **分割类**：`split`（参数是正则）

> ⚠️ **两个易踩坑**：`substring(a, b)` 是**左闭右开**，`substring(1, 4)` 拿的是下标 1、2、3 三个字符。`split("\\s+")` 里反斜杠要写两次——第一层是 Java 字符串转义，第二层才是正则表达式的 `\s`。

`trim` 和 `strip` 的差别：
- `trim`（JDK 1.0）：只去 ASCII 空白（≤ 0x20 的字符）。
- `strip`（JDK 11+）：去 Unicode 空白（认识全角空格、`\u3000` 之类的 CJK 空白）。

**做中文项目请用 `strip`**。

### 1.4 三个经典例题

**例题 1：判断回文串**

```java
public static boolean isPalindrome(String s) {
    int left = 0, right = s.length() - 1;
    while (left < right) {
        if (s.charAt(left) != s.charAt(right)) return false;
        left++;
        right--;
    }
    return true;
}
```

双指针从两端向中间收敛，只要碰到一次不相等就返回 `false`。这是最经典的字符串题模板。

**例题 2：统计字母 / 数字 / 空格 / 其他字符出现次数**

```java
String s = "Hello 2026 Java!";
int letters = 0, digits = 0, spaces = 0, others = 0;
for (int i = 0; i < s.length(); i++) {
    char c = s.charAt(i);
    if (Character.isLetter(c)) letters++;
    else if (Character.isDigit(c)) digits++;
    else if (c == ' ') spaces++;
    else others++;
}
System.out.printf("字母 %d 数字 %d 空格 %d 其他 %d%n",
        letters, digits, spaces, others);
// 输出：字母 9 数字 4 空格 2 其他 1
```

注意用的是 `Character.isLetter / isDigit`——这些是**包装类的静态方法**，能识别 Unicode（比如中文字符也会被 `isLetter` 认作字母）。

**例题 3：反转字符串——但不能 `s.charAt(i) = ...`**

```java
String r = new StringBuilder("hello").reverse().toString();
System.out.println(r);   // olleh
```

为什么不能 `s.charAt(i) = 'x'`？因为 `charAt` 返回的是 `char`（值），而且 String 内部的 `byte[]` 是 `final` 的。**要\"改\"字符串，只能借助可变缓冲区**——这是下一讲 `StringBuilder` 的出场理由。

### 1.5 String 为什么要不可变

一句话讲清好处：

- **安全**：作为 `Map` 的 key、方法参数时，接收方永远不担心被改。
- **可缓存 hashCode**：`String.hashCode()` 只算一次就存起来（内部有 `hash` 字段），下次直接返回，快。
- **常量池共享**：省内存。
- **线程安全**：多线程共读同一个 String，永远不用加锁。

**代价**：频繁\"修改\"会产生大量临时对象——这就是 `StringBuilder` 存在的理由。

### 1.6 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `s == "abc"` 有时 true 有时 false | `==` 比引用；字面量走池是 true，`new String` 不走池是 false。**永远用 `equals`**。 |
| `"  ".trim()` 之后没变 | `trim` 返回新串，原串没变。必须 `s = s.trim();`。 |
| `substring(0, s.length() + 1)` 抛异常 | 越界。`substring` 的 end 参数最大能取到 `length()`，再大就 `StringIndexOutOfBoundsException`。 |
| `"a.b.c".split(".")` 结果为空 | `.` 在正则里是\"任意字符\"，要写 `split("\\.")`。 |
| `replace('a', 'b')` 只替换首个？ | 不是，是**全部**替换。有些同学会以为像 SQL 的 `REPLACE` 一样只替换首个，其实全替。 |
| `s.trim()` 处理不了全角空格 | `trim` 只去 ASCII 空白，中文项目用 `strip`（JDK 11+）。 |

### 1.7 练习 / 思考

1. 用 `indexOf + substring` 而**不用 `split`**，把 `"a,b,c,d"` 拆成 `String[]`。
2. 实现 `boolean isPalindromeIgnoreCase(String s)`，忽略大小写和非字母字符（如 `"A man, a plan, a canal: Panama"` 应返回 true）。
3. 从 `"user@nous.com"` 中提取用户名 `"user"`，用 `indexOf + substring` 两步搞定。
4. 思考：`String s = "a" + "b" + "c";` 与 `String s = "abc";` 在字节码层面一样吗？（提示：编译期常量折叠。）

---

## 第 2 讲：StringBuilder / StringBuffer 与 StringUtils 综合案例

### 2.1 为什么需要一个可变版本的字符串

上一讲我们卡在\"如何反转字符串\"这个问题上——因为 `String` 不可变，你只能借助 `StringBuilder`。今天就把这个\"可变缓冲区\"讲清楚。

先看一段挑衅性的代码：

```java
String result = "";
for (int i = 0; i < 10000; i++) {
    result += i;
}
```

看起来平平无奇？其实这段代码在 JVM 里**创建了大约 20000 个 String 对象**——每次 `+=` 都被编译器展开成 `result = new StringBuilder(result).append(i).toString();`，也就是\"新建一个 StringBuilder → 拼接 → 转回 String\"，每一轮迭代都全套走一遍，扔掉的都是一次性对象。

**同样的功能，改用 `StringBuilder`**：

```java
StringBuilder sb = new StringBuilder();
for (int i = 0; i < 10000; i++) {
    sb.append(i);
}
String result = sb.toString();
```

**只有一个可变缓冲区**（`sb`），一路 `append` 就行，最后一次性 `toString()` 出结果。**性能差可达 500 倍**。

### 2.2 StringBuilder 的核心方法

`StringBuilder` 内部维护一个 `char[]` 和一个长度指针，容量不够就自动扩容（默认扩为 `oldCapacity * 2 + 2`）。

| 方法 | 说明 | 返回 |
|------|------|------|
| `append(x)` | 追加任意类型（int / boolean / Object 都行） | `this`（可链式） |
| `insert(i, x)` | 在下标 i 处插入 | `this` |
| `delete(a, b)` | 删除区间 [a, b) 的字符 | `this` |
| `reverse()` | 反转 | `this` |
| `replace(a, b, s)` | 用 s 替换 [a, b) | `this` |
| `toString()` | 转回 `String`（结果不可变） | 新 `String` |
| `length()` / `charAt(i)` / `setCharAt(i, c)` | 同 String 用法 | — |

**链式调用**——每个方法都 `return this;`，可以像流水线一样接下去：

```java
String name = "张三";
String greeting = new StringBuilder()
        .append("Hello, ")
        .append(name)
        .append("! 今天是 ")
        .append(2026)
        .append(" 年。")
        .toString();
System.out.println(greeting);
// 输出：Hello, 张三! 今天是 2026 年。
```

### 2.3 StringBuilder vs StringBuffer

| 类 | 线程安全 | 性能 | 引入版本 | 典型用场 |
|----|----------|------|----------|----------|
| `StringBuilder` | ❌ | 快 | JDK 5 | **默认选它** |
| `StringBuffer` | ✅（`synchronized`） | 慢 | JDK 1.0 | 多线程共享才用 |

**几乎所有业务代码里，字符串拼接都发生在单线程的方法栈内**——`StringBuilder` 就够了。`StringBuffer` 是历史遗留，几乎只在老代码里能见到，写新代码不建议用。

### 2.4 `+` 与 `StringBuilder` 的选择

**规则**：

- **少量、明确的拼接**：直接用 `+`。编译器会自动优化成 `StringBuilder.append`：
  ```java
  String s = "Hello, " + name + "!";
  // ↑ 编译后等价于：
  // new StringBuilder().append("Hello, ").append(name).append("!").toString();
  ```
- **循环、大量拼接、需要边构造边判断**：**必须手写 `StringBuilder`**。

> ⚠️ **为什么循环里的 `+=` 无法被优化**：编译器只能一行一行地优化，看到 `result += i;` 时它只能把这**一行**变成 `new StringBuilder(result).append(i).toString()`——**每轮迭代都是全新的 StringBuilder**，白白扔掉。跨迭代复用同一个 StringBuilder 是编译器做不到的语义变换（否则改变了原语义）。

### 2.5 现场跑一遍性能对比

```java
public class BuildPerf {
    public static void main(String[] args) {
        long t1 = System.currentTimeMillis();
        String r1 = "";
        for (int i = 0; i < 100_000; i++) r1 += i;
        long t2 = System.currentTimeMillis();

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 100_000; i++) sb.append(i);
        String r2 = sb.toString();
        long t3 = System.currentTimeMillis();

        System.out.println("+=       " + (t2 - t1) + " ms");
        System.out.println("Builder  " + (t3 - t2) + " ms");
        System.out.println("长度相等？" + (r1.length() == r2.length()));
    }
}
```

典型输出（现代机器）：

```text
+=       2534 ms
Builder  4 ms
长度相等？true
```

**500 倍以上的差距**。这不是理论——**跑一遍**，你就会永远记住循环里禁用 `+=`。

### 2.6 综合案例：写一个字符串工具类 StringUtils

工业界的每一个 Java 项目都会有一个 `StringUtils`（要么自己写，要么用 Apache Commons Lang / Google Guava）。今天我们照着 Apache 的套路，用今天学的 `String` + `StringBuilder` 写一个精简版。

```java
public final class StringUtils {
    private StringUtils() {}     // ① 私有构造，禁止实例化

    /** 空判断：null 或 "" 返回 true */
    public static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    /** 空白判断：null 或全空白返回 true（JDK 11+） */
    public static boolean isBlank(String s) {
        return s == null || s.isBlank();
    }

    /** 反转 */
    public static String reverse(String s) {
        if (isEmpty(s)) return s;
        return new StringBuilder(s).reverse().toString();
    }

    /** 首字母大写 */
    public static String capitalize(String s) {
        if (isEmpty(s)) return s;
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** 统计子串出现次数（不重叠） */
    public static int countOccurrences(String s, String sub) {
        if (isEmpty(s) || isEmpty(sub)) return 0;
        int count = 0, index = 0;
        while ((index = s.indexOf(sub, index)) != -1) {
            count++;
            index += sub.length();   // 跳过刚刚匹配到的，避免重叠计数
        }
        return count;
    }

    /** 手机号脱敏：138****1234 */
    public static String maskPhone(String phone) {
        if (isEmpty(phone) || phone.length() != 11) return phone;
        return phone.substring(0, 3) + "****" + phone.substring(7);
    }
}
```

测试：

```java
public static void main(String[] args) {
    System.out.println(StringUtils.reverse("hello"));                    // olleh
    System.out.println(StringUtils.capitalize("java"));                  // Java
    System.out.println(StringUtils.countOccurrences("abababab", "ab"));  // 4
    System.out.println(StringUtils.maskPhone("13812341234"));            // 138****1234
    System.out.println(StringUtils.isBlank("  \t\n "));                  // true
    System.out.println(StringUtils.isEmpty(null));                       // true
}
```

**工具类三件套**——记住这个套路，未来所有 `XxxUtils` 都长这样：

1. **`final class`**：不允许被继承（工具类没有\"扩展点\"，继承没意义）。
2. **`private` 构造函数**：不允许 `new`。
3. **全部 `static` 方法**：直接 `StringUtils.reverse(...)` 调用。

Apache Commons 的 `org.apache.commons.lang3.StringUtils`、Google Guava 的 `com.google.common.base.Strings`——所有正牌工业级工具类都是这个模板。

### 2.7 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 循环里 `+=` 拼接十万次奇慢 | 每轮都新建一个 StringBuilder 并 toString，产生 O(n) 个临时对象。改用一个 StringBuilder。 |
| `new StringBuilder(10)` 是容量还是内容？ | **容量**。`new StringBuilder(10)` 是初始容量 10 的空缓冲；`new StringBuilder("10")` 才是内容 `"10"`。 |
| `sb.append(sb)` 会栈溢出？ | 不会，但会把自己复制一遍进去。想清楚语义。 |
| `sb.equals(sb2)` 结果奇怪 | `StringBuilder` **没重写 `equals`**，用的是 Object 的引用比较。要比较内容用 `sb.toString().equals(sb2.toString())`。 |
| 工具类被继承了 | 忘了写 `final class`。生产环境务必加上。 |
| 忘了 `toString()` 直接打印 sb 也能出结果？ | `println` 会隐式调用 `toString()`，看似能打印但拿到的仍是 `Object.toString` 时会崩——`StringBuilder` 重写了 `toString`，恰好没问题。 |

### 2.8 练习 / 思考

1. 用 `StringBuilder` 的链式调用把 `["张三", "李四", "王五"]` 拼成 `"张三、李四、王五"`（最后一个不加顿号）。
2. 在 `StringUtils` 里再加一个 `maskEmail(String)`：`zhangsan@nous.com` → `zh***@nous.com`（用户名保留前 2 位，域名不变）。
3. 用 `System.currentTimeMillis()` 分别测 `+`、`concat`、`StringBuilder` 拼接 10 万次的耗时，填下表：

   | 方法 | 耗时 (ms) |
   |------|-----------|
   | `+` | |
   | `concat` | |
   | `StringBuilder` | |

4. 思考：为什么 `StringBuilder` 不实现 `equals`？（提示：它是\"缓冲区\"不是\"值\"。）

---

## 第 3 讲：基本数据类型的包装类

### 3.1 为什么需要包装类

上一讲我们把\"字符串世界\"讲完了。翻回第 4 讲末尾我们会用到 `ArrayList<String>`——但如果我要存整数呢？试着写：

```java
List<int> nums = new ArrayList<>();   // ❌ 编译错误
```

**编译不过**。原因很简单：**Java 泛型只接受引用类型**，`int / double / boolean` 这些基本类型不是对象，进不了泛型尖括号。

Java 的解决方案：**为每种基本类型提供一个\"对象版\"**，这就是包装类。

### 3.2 八对映射

| 基本类型 | 包装类 | 记忆点 |
|----------|--------|--------|
| `byte` | `Byte` | 首字母大写 |
| `short` | `Short` | 首字母大写 |
| `int` | **`Integer`** | ⚠️ 不是 `Int` |
| `long` | `Long` | 首字母大写 |
| `float` | `Float` | 首字母大写 |
| `double` | `Double` | 首字母大写 |
| `char` | **`Character`** | ⚠️ 不是 `Char` |
| `boolean` | `Boolean` | 首字母大写 |

**两个反直觉的**：`int → Integer`（不是 `Int`），`char → Character`（不是 `Char`）。写错就编译不过——是笔试常考点。

### 3.3 装箱与拆箱

- **装箱（boxing）**：基本类型 → 包装类。
- **拆箱（unboxing）**：包装类 → 基本类型。

**JDK 5 之前手动**：

```java
Integer i = Integer.valueOf(10);   // 手动装箱
int n = i.intValue();              // 手动拆箱
```

**JDK 5+ 自动装拆箱**——编译器帮你偷偷插入 `valueOf` / `intValue`：

```java
Integer i = 10;                    // 编译后：Integer.valueOf(10)
int n = i + 5;                     // 编译后：i.intValue() + 5

List<Integer> list = new ArrayList<>();
list.add(1);                        // 自动装箱
int x = list.get(0);                // 自动拆箱
```

**记住**：`Integer i = 10;` 不是\"直接把 10 塞给 Integer\"，而是编译器帮你写了 `Integer.valueOf(10)`。这一层\"糖\"看起来薄，但对下面要讲的**缓存陷阱**有决定性影响。

### 3.4 常用方法

以 `Integer` 为例（其他 `Long / Double` 等模式一样）：

```java
int n = Integer.parseInt("123");         // String → int
Integer boxed = Integer.valueOf(100);    // int → Integer
int primitive = boxed.intValue();        // Integer → int
int max = Integer.max(3, 5);             // 静态比较：5
int min = Integer.min(3, 5);             // 静态比较：3
String hex = Integer.toHexString(255);   // "ff"
String bin = Integer.toBinaryString(10); // "1010"
int MAX = Integer.MAX_VALUE;             // 2^31 - 1 = 2147483647
int MIN = Integer.MIN_VALUE;             // -2^31   = -2147483648
```

**`parseInt` vs `valueOf` 的差别**——初学最容易混：

| 方法 | 返回类型 |
|------|----------|
| `Integer.parseInt("123")` | **基本类型 `int`** |
| `Integer.valueOf("123")` | **包装类 `Integer`** |
| `Integer.valueOf(100)` | **包装类 `Integer`**（重载） |

**记忆**：需要 primitive 用 `parseXxx`，需要 wrapper 用 `valueOf`。

`Character` 的静态判断方法（写字符串题会大量用）：

```java
Character.isDigit('5');       // true
Character.isLetter('A');      // true（也认中文字符）
Character.isLetterOrDigit('a');// true
Character.isWhitespace(' ');  // true
Character.isUpperCase('A');   // true
Character.toLowerCase('A');   // 'a'
Character.toUpperCase('a');   // 'A'
```

### 3.5 Integer 缓存陷阱——本讲的表演时刻

先猜结果，再看答案：

```java
Integer a = 127;
Integer b = 127;
System.out.println(a == b);   // ?

Integer c = 128;
Integer d = 128;
System.out.println(c == d);   // ?
```

直觉答案：\"两个都 true\"。**实际输出**：

```text
true
false
```

**反直觉**。为什么？

打开 JDK 源码看 `Integer.valueOf`：

```java
public static Integer valueOf(int i) {
    if (i >= IntegerCache.low && i <= IntegerCache.high)
        return IntegerCache.cache[i + (-IntegerCache.low)];
    return new Integer(i);
}
```

`IntegerCache` 默认 `low = -128, high = 127`——**这个范围内的 Integer 提前建好了缓存**，所有 `Integer.valueOf(-128..127)` 返回**同一个对象**；越界就 `new` 一个新对象。

所以：
- `127` 走缓存，`a` 和 `b` 是**同一对象**，`==` 为 true。
- `128` 越界，`c` 和 `d` 是**两个不同对象**，`==` 为 false。

**这就是为什么包装类比较永远用 `.equals()`**：

```java
Integer c = 128, d = 128;
System.out.println(c.equals(d));   // true
System.out.println(c == d);         // false
```

一句话钉板：**包装类之间用 `equals` 比较，`==` 只在缓存范围内\"碰巧对\"，出了缓存就翻车。**

### 3.6 null 拆箱 NPE

**Web 项目 90% 的 NPE 都出在这里**。看这段代码：

```java
Map<String, Integer> scores = new HashMap<>();
scores.put("张三", 88);

Integer s = scores.get("李四");   // 查不到 → 返回 null
int score = s;                    // 💥 NullPointerException
```

`scores.get("李四")` 返回 `null`（因为不存在这个 key）。然后 `int score = s;` 会被编译器插入 `s.intValue()`——**对 `null` 调 `intValue()` 就是 NPE**。

**为什么数据库 / JSON 拿的数字都是包装类**：数据库里的字段可能是 `NULL`，如果 Java 端用 `int` 就没法表示\"没值\"这个概念——`0` 是有值、只是零。所以工业代码里从数据库/接口取的数字几乎都是 `Integer / Long / BigDecimal`。

**防御式写法**：

```java
// 方法 1：三目
int score = s == null ? 0 : s;

// 方法 2：getOrDefault（Map 专用）
int score2 = scores.getOrDefault("李四", 0);

// 方法 3：Optional（更现代）
int score3 = Optional.ofNullable(s).orElse(0);
```

**规则**：**拆箱前必判空**。这是本讲最重要的实战经验。

### 3.7 String 与基本类型互转小抄

```java
// String → 基本
int i = Integer.parseInt("123");
double d = Double.parseDouble("3.14");
boolean b = Boolean.parseBoolean("true");
long l = Long.parseLong("9999999999");

// 基本 → String
String s1 = String.valueOf(123);      // 最通用，能吞 null → "null"
String s2 = Integer.toString(123);
String s3 = "" + 123;                  // 简洁但内部走 StringBuilder，多一次转换
```

**推荐**：**`String.valueOf(x)`**——对 `null` 会返回 `"null"` 而不抛 NPE，是最安全的选择。

### 3.8 完整跑一遍缓存实验

```java
public class IntegerCacheDemo {
    public static void main(String[] args) {
        test(-129);
        test(-128);
        test(127);
        test(128);
    }

    static void test(int n) {
        Integer a = n;
        Integer b = n;
        System.out.printf("%5d: == %-5s  equals %s%n",
                n, a == b, a.equals(b));
    }
}
```

**输出**：

```text
 -129: == false  equals true
 -128: == true   equals true
  127: == true   equals true
  128: == false  equals true
```

**`equals` 全对；`==` 只在 [-128, 127] 内对**——这一屏字，是本讲要带走的最重要一张图。

### 3.9 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `Integer a = 128, b = 128; a == b` 竟然是 false | 越出缓存池（-128 ~ 127），是两个不同的 Integer 对象。用 `equals`。 |
| `int n = someMap.get(key);` NPE | Map 里没有 key 时返回 null，自动拆箱 null 抛 NPE。改用 `getOrDefault` 或先判空。 |
| `Integer x = null; if (x == 1)` NPE | `x == 1` 会自动拆 `x`，对 null 拆箱抛 NPE。 |
| `List<int>` 编译不过 | 泛型不接受基本类型，用 `List<Integer>`。 |
| `Integer.parseInt("12.3")` 崩 | `NumberFormatException`——`parseInt` 只吃整数。要小数用 `Double.parseDouble`。 |
| `Integer.parseInt("")` 崩 | 空串也不行。工程代码要 `try-catch` 或先判 `isEmpty`。 |
| `int` 溢出没提示 | `Integer.MAX_VALUE + 1` 直接绕回 `Integer.MIN_VALUE`，不报错。要检测溢出用 `Math.addExact`。 |

### 3.10 练习 / 思考

1. 写代码验证 `Long a = 127L; Long b = 127L;` 的 `a == b` 结果（`Long` 也有缓存池 -128 ~ 127）。
2. 写代码验证 `Double a = 1.0; Double b = 1.0;` 的 `a == b` 结果——为什么和 `Integer` 不一样？（提示：`Double` 无缓存池）。
3. 实现 `int safeParseInt(String s, int defaultValue)`：能解析就返回解析值；异常或 null 就返回默认值。
4. 从 `Map<String, Integer>` 里安全地取一个 key，转成 `int`（不存在时默认 0），三种写法都写一遍。
5. 挑战：`Integer.valueOf` 的缓存边界能改吗？（提示：`-Djava.lang.Integer.IntegerCache.high=1000` 启动参数。）

---

## 第 4 讲：ArrayList（含集合框架总览）

### 4.1 从定长数组到动态数组

回到 Day02 的第 5 章：

```java
int[] arr = new int[10];
```

数组一旦声明，**长度就固定了**。如果你不知道最终会有多少个元素怎么办？只能\"猜大一点\"或者\"新建一个更大的然后手工复制\"——两种做法都很难受。

`ArrayList` 就是把这个\"手动扩容 + 挪元素\"的活封装好了：**你只管 `add`，它自己会扩容**。

### 4.2 集合框架总览

Java 的集合家族分两大分支：

```text
        Iterable
            │
        Collection                    Map (独立体系)
        ┌───┼───┐                    ┌───┼───────┬─────┐
       List Set Queue           HashMap  LinkedHashMap  TreeMap
      ┌─┴──┐  ┌──┴──┐
ArrayList LinkedList  HashSet  LinkedHashSet  TreeSet
```

- **`Collection`**：单值容器（`List` / `Set` / `Queue`）。
- **`Map`**：键值对，**不属于 `Collection`**——常有同学把 `HashMap.put` 和 `List.add` 混着写，记住它俩是**两个体系**。

本课程只讲**最常用的三个**：`ArrayList`、`HashMap`、`HashSet`——覆盖 90% 的日常场景。

### 4.3 ArrayList 的定义与创建

**定义**：动态数组，**有序**（按插入顺序）、**可重复**、允许 `null`。

```java
ArrayList<String> list = new ArrayList<>();     // 具体类引用
List<String>      list2 = new ArrayList<>();    // ✅ 推荐：接口引用
List<String>      list3 = new ArrayList<>(20);  // 指定初始容量
```

**为什么推荐 `List<String> list = new ArrayList<>();`**：**面向接口编程**。将来想换成 `LinkedList`，只改右边一行——左边所有 `list.` 的代码都不用动。这是 Spring / JavaEE 世界的通行原则。

### 4.4 核心 API

| 方法 | 作用 | 返回 |
|------|------|------|
| `add(e)` | 尾部追加 | boolean（总是 true） |
| `add(i, e)` | 下标 i 处插入 | void |
| `get(i)` | 取下标 i 的元素 | E |
| `set(i, e)` | 修改下标 i 的元素，返回旧值 | E（旧值） |
| `remove(int i)` | **按下标**删除 | E（被删的） |
| `remove(Object o)` | **按对象**删除首个匹配 | boolean |
| `size()` | 元素数 | int |
| `isEmpty()` | 是否空 | boolean |
| `contains(o)` | 是否包含 | boolean |
| `indexOf(o)` | 首次出现下标，无返 -1 | int |
| `clear()` | 清空 | void |

**易混点：`remove(int)` 和 `remove(Object)` 是方法重载**。当 `List<Integer>` 时——**猜猜下面会发生什么**：

```java
List<Integer> l = new ArrayList<>(List.of(10, 20, 30));
l.remove(1);                        // 按下标删除下标 1
// 结果：[10, 30]

l.remove(Integer.valueOf(10));      // 按对象删除 10
// 结果：[30]
```

`l.remove(1)` 会被识别为 **按下标 `1` 删除**——因为编译期优先匹配基本类型的 `remove(int)`。所以要按值删 Integer，必须**显式装箱** `Integer.valueOf(10)`。这是笔试常考点，也是**踩过一次坑就永远记住**的知识点。

### 4.5 三种遍历

```java
List<String> list = new ArrayList<>(List.of("张三", "李四", "王五"));

// 1. for-i：需要下标或反向遍历时用
for (int i = 0; i < list.size(); i++) {
    System.out.println(i + ": " + list.get(i));
}

// 2. 增强 for：最常见
for (String s : list) {
    System.out.println(s);
}

// 3. forEach + Lambda / 方法引用（JDK 8+，最简）
list.forEach(System.out::println);
```

**选择规则**：
- 需要**下标**或**倒序**：`for-i`
- 只是**依次处理每个元素**：增强 for
- 只想**打印或调用一个已有方法**：`forEach + ::`

### 4.6 遍历删除翻车三部曲——本讲最重要

这是**每个初学者都会犯的错**，一定要亲手跑一遍。

**❌ 错误 1：增强 for 里删**

```java
List<String> names = new ArrayList<>(List.of("张三", "李四", "张三丰"));
for (String n : names) {
    if (n.startsWith("张")) names.remove(n);
    // 💥 ConcurrentModificationException
}
```

**根因**：增强 for 底层是 `Iterator`。`Iterator` 有一个内部字段 `expectedModCount`，指向创建时 List 的 `modCount`。而 `list.remove` 直接改了 `modCount`，Iterator 下一次 `next()` 检查发现 `expectedModCount != modCount`，抛异常——这就是 **fail-fast** 机制，Java 集合库\"宁可炸也不给你留错误数据\"的设计哲学。

**❌ 错误 2：for-i 正着删（不炸，但会漏删）**

```java
for (int i = 0; i < names.size(); i++) {
    if (names.get(i).startsWith("张")) names.remove(i);
}
```

不会炸，但会**漏删**：删了下标 0 的\"张三\"，`i++` 变成 1，下一轮取 `names.get(1)`——但\"张三丰\"已经被前移到下标 1 了，你却直接跳到下标 2 去了，**\"张三丰\" 被跳过**。

**✅ 正解 1：JDK 8+ 首选 `removeIf` —— 一行搞定**

```java
names.removeIf(n -> n.startsWith("张"));
```

**这是 JDK 8 之后处理\"条件删除\"的标准写法**，简洁、正确、性能好。

**✅ 正解 2：显式 `Iterator.remove()`**

```java
Iterator<String> it = names.iterator();
while (it.hasNext()) {
    if (it.next().startsWith("张")) {
        it.remove();          // 用 Iterator 自己的 remove，会同步 modCount
    }
}
```

`Iterator.remove()` 内部会更新自己的 `expectedModCount`，所以不会触发 fail-fast。

**✅ 正解 3：从后往前 for-i**

```java
for (int i = names.size() - 1; i >= 0; i--) {
    if (names.get(i).startsWith("张")) names.remove(i);
}
```

**倒着走**——即使删了某个下标，前面的元素下标也不会变，所以不会漏。

### 4.7 底层原理小抄

- 默认初始容量 **10**（首次 `add` 时才真正分配 `Object[]`）。
- 满了扩为 **1.5 倍**：`newCap = oldCap + (oldCap >> 1)`。
- `get(i)` 是 **O(1)**（数组随机访问）。
- `add(0, e)` 是 **O(n)**（要挪 n 个元素后移一位）。
- 尾部 `add(e)` **均摊 O(1)**（大多数时候 O(1)，偶尔扩容 O(n)）。

**性能建议**：如果你**已知最终大小**，构造时就指定容量：

```java
List<Student> students = new ArrayList<>(10000);   // 一次分配够
```

这样能省掉大约 log₁.₅(10000) ≈ 22 次扩容和大数组复制。

### 4.8 一个完整的 CRUD 演示

```java
List<String> names = new ArrayList<>();
names.add("张三");
names.add("李四");
names.add("王五");
System.out.println(names);              // [张三, 李四, 王五]

names.add(1, "赵六");                    // 下标 1 插入
System.out.println(names);              // [张三, 赵六, 李四, 王五]

String old = names.set(0, "张三三");     // 替换
System.out.println("旧值 = " + old);     // 旧值 = 张三
System.out.println(names);              // [张三三, 赵六, 李四, 王五]

names.remove("李四");                    // 按对象删
System.out.println(names);              // [张三三, 赵六, 王五]

names.remove(0);                        // 按下标删
System.out.println(names);              // [赵六, 王五]

System.out.println(names.contains("赵六"));   // true
System.out.println(names.indexOf("王五"));    // 1
System.out.println(names.size());              // 2
```

### 4.9 pitfall / 注意

| 现象 | 原因 |
|------|------|
| 增强 for 里 `remove` 抛 CME | fail-fast 检测到并发修改。用 `removeIf` 或 `Iterator.remove`。 |
| for-i 正向删除\"跳元素\" | 删除后后续元素前移，`i++` 跳过它。倒着删。 |
| `list.remove(1)` 删的是元素还是下标？ | `List<Integer>` 时优先匹配 `remove(int)` —— 是**下标**。删元素用 `remove(Integer.valueOf(1))`。 |
| `List.of(...)` 返回的 List 不能 add | `List.of` 返回**不可变** List（JDK 9+）。要改用 `new ArrayList<>(List.of(...))` 包一层。 |
| 频繁 `add(0, e)` 很慢 | 每次都要挪整个数组。头插密集场景考虑 `LinkedList` 或 `ArrayDeque`。 |
| 遍历时同一个 List 被别的线程修改 | 也会 CME。多线程场景用 `CopyOnWriteArrayList` 或加锁。 |
| `list.contains(x)` 慢 | 遍历比对，O(n)。频繁查存在性用 `HashSet`（下一讲）。 |

### 4.10 练习 / 思考

1. 用 `ArrayList<Integer>` 存放 1—10，删除所有偶数，用**三种正确写法**都写一遍：`removeIf` / `Iterator.remove` / 倒序 for-i。
2. 给 `List<Integer>`，返回一个**新**的 `List<Integer>`，只包含大于平均值的元素。原 List 不能被修改。
3. 用 `ArrayList<Student>`（复用 Day04 的 `Student` 类）实现\"添加、按索引删、按学号查\"三个功能。
4. 判断一个 `List<String>` 是否有重复元素（不用 `HashSet`，只用 `contains` 双层循环——为下一讲的 `HashSet` 优化做铺垫）。
5. 挑战：查阅 JDK 25 的 `ArrayList` 源码，找到 `grow` 方法，把扩容部分的代码抄下来。

---

## 第 5 讲：HashMap + HashSet + StudentSystemV2 综合案例

### 5.1 从 O(n) 到 O(1)：为什么需要哈希表

上一讲我们能用 `ArrayList<Student>` 存学生了。但**查\"学号 202501\"的学生**要怎么做？

```java
for (Student s : students) {
    if (s.getId().equals("202501")) return s;
}
```

`O(n)`——**当学生 10 万人时，每次查询都要遍历 10 万次**。有更好的办法吗？

如果你想到\"用学号做下标\"——**恭喜，你发明了哈希表**。可惜学号是字符串，不能直接当下标。但可以：**把字符串通过 `hashCode()` 变成整数下标**。

Java 里已经封装好了这个数据结构：**`HashMap`**，平均查找时间 `O(1)`。

### 5.2 HashMap 定义与创建

```java
Map<String, Integer> scores = new HashMap<>();
scores.put("张三", 88);
scores.put("李四", 92);
scores.put("王五", 76);
scores.put("张三", 100);   // key 已存在 → 覆盖 88，返回旧值
```

**特点**：
- **键不可重复**（重复即覆盖）
- **值可重复**
- 允许 **一个 null key** 和多个 null value
- **无序**（`HashMap` 不保证遍历顺序；要保持插入顺序用 `LinkedHashMap`）

### 5.3 核心 API

| 方法 | 作用 | 返回 |
|------|------|------|
| `put(k, v)` | 添加或覆盖 | 旧 v（无则 null） |
| `get(k)` | 取 v | v 或 null |
| `getOrDefault(k, dv)` | 取 v，无则用默认值 dv | v 或 dv |
| `containsKey(k)` | 是否含键 | boolean |
| `containsValue(v)` | 是否含值（O(n)，慢） | boolean |
| `remove(k)` | 删除，返旧 v | v 或 null |
| `size()` | 键值对数 | int |
| `isEmpty()` | 是否空 | boolean |
| `keySet()` | 所有键的视图 | `Set<K>` |
| `values()` | 所有值的视图 | `Collection<V>` |
| `entrySet()` | 所有键值对的视图 | `Set<Entry<K,V>>` |
| `putIfAbsent(k, v)` | 只在键不在时 put | 旧 v 或 null |
| `merge(k, v, fn)` | 键在则合并、不在则 put | 合并后的值 |
| `forEach((k,v) -> ...)` | Lambda 遍历 | — |

### 5.4 三种遍历——选对能快一倍

```java
Map<String, Integer> scores = new HashMap<>();
scores.put("张三", 88);
scores.put("李四", 92);

// 1. 遍历 keySet（如果同时要用 value，每次 get 又要哈希一次，性能差）
for (String k : scores.keySet()) {
    System.out.println(k + " → " + scores.get(k));
}

// 2. 遍历 entrySet（推荐，只哈希一次）
for (Map.Entry<String, Integer> e : scores.entrySet()) {
    System.out.println(e.getKey() + " → " + e.getValue());
}

// 3. forEach + Lambda（JDK 8+，最简洁）
scores.forEach((k, v) -> System.out.println(k + " → " + v));
```

**性能提示**：**只要要用到 value，就用 `entrySet` 或 `forEach((k,v)->…)`**。**只需要 key** 才用 `keySet`。这条规则能让代码在 10 万级 map 上快近一倍。

### 5.5 词频统计——`getOrDefault` 的经典用法

```java
String text = "the quick brown fox jumps over the lazy dog the fox";
Map<String, Integer> freq = new HashMap<>();
for (String w : text.split("\\s+")) {
    freq.put(w, freq.getOrDefault(w, 0) + 1);
}
freq.forEach((k, v) -> System.out.println(k + " = " + v));
```

**输出**（顺序不保证）：

```text
the = 3
fox = 2
dog = 1
quick = 1
brown = 1
jumps = 1
over = 1
lazy = 1
```

**关键行**：

```java
freq.put(w, freq.getOrDefault(w, 0) + 1);
```

翻译：\"取出 w 对应的次数（不存在当 0），加 1，再放回去。\"

**JDK 8+ 简化版**——用 `merge` 一行搞定：

```java
freq.merge(w, 1, Integer::sum);
```

`merge(k, v, fn)` 的语义：如果 key 不在就 `put(k, v)`；如果已在就 `put(k, fn(oldValue, v))`。**词频统计从此变成一行**——这就是好 API 的力量。

### 5.6 HashSet 的秘密：底层就是 HashMap

翻开 JDK 源码看 `HashSet`：

```java
public class HashSet<E> ... {
    private transient HashMap<E, Object> map;
    private static final Object PRESENT = new Object();

    public boolean add(E e) {
        return map.put(e, PRESENT) == null;
    }
    // ...
}
```

**`HashSet` 内部就是一个 `HashMap`**——把\"值\"当 key 存进去，value 用一个占位对象 `PRESENT`。所以：
- `HashSet.add(x)` = `HashMap.put(x, PRESENT)`
- `HashSet.contains(x)` = `HashMap.containsKey(x)`
- 性能特性完全一样（O(1) 平均）。

**用法**：

```java
Set<String> set = new HashSet<>();
set.add("张三");
set.add("李四");
boolean added = set.add("张三");   // false（已存在）
System.out.println(set.size());     // 2
System.out.println(set);            // [张三, 李四]（顺序不保证）
```

**两大用途**：
1. **去重**
   ```java
   List<Integer> nums = List.of(1, 2, 3, 2, 4, 1, 5);
   Set<Integer> distinct = new HashSet<>(nums);
   System.out.println(distinct);   // [1, 2, 3, 4, 5]（顺序不保证）
   ```
2. **O(1) 存在性判断**——比 `List.contains` 快数量级：
   ```java
   Set<String> validIds = new HashSet<>(List.of("A001", "A002", "B003"));
   if (validIds.contains(inputId)) { /* ... */ }
   ```

**要保持插入顺序**：用 `LinkedHashSet`：

```java
Set<Integer> ordered = new LinkedHashSet<>(List.of(3, 1, 2, 1, 3));
System.out.println(ordered);   // [3, 1, 2]
```

### 5.7 底层原理（了解即可）

- 内部结构：**数组 + 链表 + 红黑树**（JDK 8+）。
- `put` 流程：`hash(key) → (n-1) & hash → 桶下标 → 链表 / 树中比对`。
- 当**单个桶里链表长度 > 8 且数组长度 ≥ 64** 时，链表**转红黑树**，查找从 O(n) 降到 O(log n)。
- **负载因子 0.75**：当 `size > capacity * 0.75` 时扩容为 2 倍。
- **key 必须重写 `equals` + `hashCode`**——两者要成对重写，`equals` 相等的两个对象 `hashCode` **必须**相等（反过来不一定）。**建议用不可变类做 key**：`String / Integer / record`（Day04 讲的 Record 天然符合要求）。

### 5.8 综合案例：StudentSystemV2

Day04 我们写过一个用**数组**存学生的管理系统。今天用 `Map<String, Student>` 重构，感受一下差距。

```java
import java.util.*;

public class StudentSystemV2 {
    // Day04 定义过的 Student 类（复用），核心字段：id / name / age / score
    record Student(String id, String name, int age, double score) {
        void printInfo() {
            System.out.printf("%-8s %-6s %3d %6.2f%n", id, name, age, score);
        }
    }

    static Map<String, Student> db = new LinkedHashMap<>();   // key = 学号
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1.添加 2.查询 3.删除 4.列出 5.统计 0.退出");
            switch (sc.next()) {
                case "1" -> add();
                case "2" -> find();
                case "3" -> delete();
                case "4" -> listAll();
                case "5" -> stats();
                case "0" -> { return; }
                default  -> System.out.println("无效输入。");
            }
        }
    }

    static void add() {
        System.out.print("学号 姓名 年龄 分数：");
        String id = sc.next();
        if (db.containsKey(id)) { System.out.println("学号已存在。"); return; }
        String name = sc.next();
        int age = sc.nextInt();
        double score = sc.nextDouble();
        db.put(id, new Student(id, name, age, score));
        System.out.println("添加成功。");
    }

    static void find() {
        System.out.print("学号：");
        Student s = db.get(sc.next());          // O(1) 查找
        if (s == null) System.out.println("未找到。");
        else s.printInfo();
    }

    static void delete() {
        System.out.print("学号：");
        if (db.remove(sc.next()) != null) System.out.println("删除成功。");
        else System.out.println("未找到。");
    }

    static void listAll() {
        if (db.isEmpty()) { System.out.println("空。"); return; }
        System.out.printf("%-8s %-6s %3s %6s%n", "学号", "姓名", "年龄", "分数");
        db.values().forEach(Student::printInfo);
    }

    static void stats() {
        if (db.isEmpty()) return;
        double avg = db.values().stream().mapToDouble(Student::score).average().orElse(0);
        Student max = db.values().stream().max(Comparator.comparingDouble(Student::score)).orElseThrow();
        System.out.printf("人数=%d  平均分=%.2f  最高=%s(%.2f)%n",
                db.size(), avg, max.name(), max.score());
    }
}
```

**对比 Day04 的数组版**：

| 操作 | Day04 数组版 | Day06 Map 版 |
|------|-------------|--------------|
| 添加 | 判满 + 扩容 + 顺序写 | `db.put(id, ...)` 一行 |
| 查询 | for 遍历 O(n) | `db.get(id)` **O(1)** |
| 删除 | 手动挪数组 O(n) | `db.remove(id)` **一行** |
| 字段增删 | 改 4 个平行数组 | 只改 `Student` 类 |
| 代码行数 | ~200 | **~80** |

**这就是\"面向对象 + 集合\"的复合威力**——把\"结构\"交给 `Student` 类、把\"容器\"交给 `Map`、把\"排序统计\"交给 `Stream`（一个 Day06 之后的赠送话题），行数减半、性能量级提升。

**这是全课程的关键顿悟时刻**。前五天磨的每一把刀，今天都在这里发出了光。

### 5.9 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `map.get(key)` 拆箱抛 NPE | 键不存在时返回 null，自动拆箱 null 就 NPE。用 `getOrDefault(k, 0)`。 |
| 自定义类做 key，`get` 拿不到 | 只重写了 `equals` 没重写 `hashCode`。**两者必须成对**。 |
| 两个内容相等的 key `put` 覆盖了 | 这是**特性不是 bug**：内容 equal 的 key 视为同一个。 |
| 遍历时 put/remove 抛 CME | Map 也是 fail-fast，遍历时不能修改。要改用 `Iterator.remove` 或 Java 8+ 的 `entrySet().removeIf`。 |
| `keySet()` 遍历 + `get()` 拿 value 慢 | 每次 get 又要哈希一次。改用 `entrySet` 或 `forEach((k,v)->…)`。 |
| 用可变对象（如 `List`）当 key | 修改后 `hashCode` 变了，桶找不到，`get` 直接返回 null。**永远用不可变类当 key**。 |
| `HashSet` 存自定义类，重复没被去 | 没重写 `equals + hashCode`。用 `record` 天然解决。 |

### 5.10 练习 / 思考

1. 词频统计升级版：读入教材第 1 章的一段英文文本，输出**前 10 个高频词**（提示：`db.entrySet().stream().sorted(...).limit(10)`）。
2. 给两个 `List<Integer>`，用 `HashSet` 输出**并集**（`addAll`）与**交集**（`retainAll`）。
3. 把 `StudentSystemV2` 加两个功能：\"按成绩降序展示\"、\"按姓氏搜索\"（提示：`db.values().stream().filter(...).sorted(...)`）。
4. 用 `HashMap<Character, Integer>` 统计一个字符串每个字符出现次数，不区分大小写。
5. 挑战：读一遍 JDK 25 的 `HashMap.put` 源码，画出\"计算 hash → 找桶 → 处理链表/树\"的三步流程。

## 第 6 讲：泛型基础「Day06 & 全课程收官」

### 6.1 为什么需要泛型——从一个能编译却会崩溃的 bug 说起

昨天你在写 `ArrayList<Student>`、`HashMap<String, Student>` 的时候，尖括号 `<>` 里塞的类型参数其实一直没人给你正名。今天这一讲，我们把它单独拎出来讲清楚。

先看一段 JDK 5 之前风格的代码（**现在仍然能编译**，只要你把 `<>` 去掉）：

```java
import java.util.*;

public class NoGeneric {
    public static void main(String[] args) {
        List list = new ArrayList();     // 不带 <>，等价于 List<Object>
        list.add("hello");
        list.add(123);                    // 编译期什么都能加
        list.add(new Student("s01", "张三", 20, 88));

        String s = (String) list.get(1);  // 运行时才崩：ClassCastException
        System.out.println(s);
    }
}
```

运行输出：

```text
Exception in thread "main" java.lang.ClassCastException:
class java.lang.Integer cannot be cast to class java.lang.String
    at NoGeneric.main(NoGeneric.java:10)
```

**代码能编译，但一运行就爆炸**——这是 Java 1.0—1.4 时代最令人痛苦的坑：容器什么都能装，取出来要强转，转错才发现。

给它加上泛型 `<String>`：

```java
List<String> list = new ArrayList<>();
list.add("hello");
// list.add(123);                        // ❌ 编译期直接红线，根本上不了车
String s = list.get(0);                   // 无需强转，编译器已知是 String
```

**泛型的核心价值**：把"类型不匹配"这类错误从**运行期**提前到**编译期**——多写几个尖括号，换来的是"IDE 一编译就发现问题"。

这是继"面向对象"之后，Java 类型系统的第二次质变。

### 6.2 泛型类——自己写一个 `Box<T>`

标准语法：**类名后面加 `<类型参数>`**。

```java
public class Box<T> {                    // T 是"类型占位符"
    private T value;                     // T 用作字段类型

    public void set(T value) {           // T 用作方法参数
        this.value = value;
    }

    public T get() {                     // T 用作返回类型
        return value;
    }
}
```

调用者在 `new` 的时候把 `T` 具体化：

```java
public class BoxDemo {
    public static void main(String[] args) {
        Box<String> b1 = new Box<>();    // T ← String
        b1.set("hello");
        String s = b1.get();             // 编译器知道 get() 返回 String
        System.out.println(s.toUpperCase());   // 直接调 String 方法

        Box<Integer> b2 = new Box<>();   // T ← Integer
        b2.set(42);
        // b2.set("hi");                 // ❌ 编译报错
        int n = b2.get();                // 自动拆箱（复习 Day06 第 3 讲）
        System.out.println(n + 1);
    }
}
```

运行输出：

```text
HELLO
43
```

**类型参数的命名惯例**（不是语法要求，是行业习惯，读别人代码能一眼看懂）：

| 字母 | 含义 | 典型场景 |
|------|------|----------|
| `T` | Type，任意类型 | 通用容器：`Box<T>`、`Optional<T>` |
| `E` | Element，元素 | 集合元素：`List<E>`、`Set<E>` |
| `K` | Key，键 | Map 的键：`HashMap<K, V>` |
| `V` | Value，值 | Map 的值：`HashMap<K, V>` |
| `R` | Return，返回 | 函数式接口：`Function<T, R>` |
| `N` | Number，数字 | 数值型泛型 |

一个类可以有**多个类型参数**，用逗号隔开——你昨天用的 `HashMap<K, V>` 就是这么定义的：

```java
public class Pair<K, V> {                // 两个类型参数
    private K key;
    private V value;
    public Pair(K key, V value) { this.key = key; this.value = value; }
    public K getKey()   { return key; }
    public V getValue() { return value; }
}

Pair<String, Integer> p = new Pair<>("age", 20);
```

### 6.3 泛型方法——把 `<T>` 写在方法自己身上

如果**不想让整个类都泛型化**，只是**某个方法**需要类型灵活，就写成"泛型方法"。语法是：**方法返回类型前面单独声明 `<T>`**。

```java
import java.util.List;

public class Utils {
    // <T> 声明"这个方法自己带一个类型参数 T"
    public static <T> T firstOrNull(List<T> list) {
        return list.isEmpty() ? null : list.get(0);
    }

    // 多个类型参数也行
    public static <K, V> void printPair(K k, V v) {
        System.out.println(k + " => " + v);
    }
}

public class GenericMethodDemo {
    public static void main(String[] args) {
        String s = Utils.firstOrNull(List.of("a", "b", "c"));   // T 自动推断为 String
        Integer n = Utils.firstOrNull(List.of(1, 2, 3));         // T 自动推断为 Integer
        System.out.println(s);
        System.out.println(n);

        Utils.printPair("age", 20);       // K=String, V=Integer
        Utils.printPair(1, true);         // K=Integer, V=Boolean
    }
}
```

运行输出：

```text
a
1
age => 20
1 => true
```

**关键点**：编译器根据传入的**实参**自动推断 `T` 是什么——你几乎从不需要显式写 `Utils.<String>firstOrNull(...)`。

**泛型类 vs 泛型方法怎么选**：

| 场景 | 用泛型类 | 用泛型方法 |
|------|----------|-----------|
| 类的**字段**类型要灵活 | ✅ | ❌ |
| 类里绝大多数方法都用同一个 T | ✅ | ❌ |
| 只是**某个工具方法**需要类型灵活 | ❌ | ✅ |
| `static` 方法要用泛型 | ❌（静态方法不能用类的 T） | ✅（唯一选择） |

最后一行特别重要：**`static` 方法用不了类的类型参数**，所以工具类里的静态方法几乎都是"泛型方法"写法。

### 6.4 泛型接口——`Comparator<T>` 的真实身份

昨天你在 `stats()` 里写过 `Comparator.comparingDouble(Student::score)`，`Comparator` 就是一个泛型接口。它的定义大致是：

```java
public interface Comparator<T> {
    int compare(T a, T b);
}
```

自己实现时把 `T` 具体化：

```java
public class ByAgeComparator implements Comparator<Student> {
    // 实现时 T 全部换成 Student
    @Override
    public int compare(Student a, Student b) {
        return Integer.compare(a.age(), b.age());
    }
}
```

**这就是你昨天 Day05 学的接口 + 今天的泛型的合体产物**——JDK 用它做了几百个接口（`Comparable<T>`、`Iterable<T>`、`Function<T,R>`、`Predicate<T>`……）。看到 `<T>` 别怕，就是这一节讲的东西。

### 6.5 通配符 `?`（了解即可）

有时候我们想写一个方法，"接收任意类型的 `List`"，但又不想给它加类型参数。这时就用**通配符 `?`**：

```java
public static void printAll(List<?> list) {   // <?> = 未知类型的 List
    for (Object o : list) {                    // 只能按 Object 读
        System.out.println(o);
    }
    // list.add("x");                          // ❌ 未知类型，写不进去
}
```

三种通配符：

| 写法 | 含义 | 记忆 |
|------|------|------|
| `List<?>` | 未知类型 | **只读**，不能 add（除了 null） |
| `List<? extends Number>` | Number 或其**子类** | 上界通配符，"只读 Number" |
| `List<? super Integer>` | Integer 或其**父类** | 下界通配符，"能写 Integer" |

**PECS 口诀**（Producer Extends, Consumer Super）：你**读**它就用 `extends`，你**写**它就用 `super`。

**初学阶段先记住一句话就够了**：`List<?>` 是"任意 List 的只读视图"。真正大量用通配符是在写公共库、框架的时候，日常业务代码 90% 只用 `List<具体类型>`。

### 6.6 编译期擦除——泛型不存在的秘密

Java 泛型有一个很**违反直觉**的设计：**编译完之后，尖括号里的类型信息全部会被"擦除"**，运行时的 `List<String>` 和 `List<Integer>` **是同一个类**。

现场验证：

```java
import java.util.*;

public class EraseDemo {
    public static void main(String[] args) {
        List<String>  a = new ArrayList<>();
        List<Integer> b = new ArrayList<>();
        System.out.println(a.getClass());
        System.out.println(b.getClass());
        System.out.println(a.getClass() == b.getClass());
    }
}
```

运行输出：

```text
class java.util.ArrayList
class java.util.ArrayList
true
```

**两者在 JVM 眼里就是同一个 `ArrayList.class`**——尖括号里的类型只在**源码级**存在，编译到字节码就消失了。

**为什么这么设计**：JDK 5 引入泛型时，为了让**新代码能用旧的 JDK 1.4 class 文件**（向下兼容），只能把泛型做成"编译期戏法"。副作用是：

- **不能** `new T()`（运行时不知道 T 是什么）
- **不能** `T[] arr = new T[10]`（同上）
- **不能** `if (obj instanceof List<String>)`（类型信息已擦除）

日常开发只需知道有这个机制。真到框架层要绕过它，会有 `Class<T>`、`TypeToken` 之类的补救手段——那是后话。

### 6.7 pitfall / 注意

| 现象 | 原因 |
|------|------|
| `List list = new ArrayList()` 编译不报错，运行崩 | 没写泛型，等价于 `List<Object>`。**永远带上 `<>`**。 |
| 泛型类型不匹配红线 | 编译期检查，这是**特性不是 bug**——救了你一命。 |
| `new T()` / `new T[10]` 编译不过 | 类型擦除，运行时没有 T 这个类。传 `Class<T>` 进来手动 `.newInstance()` 才行（进阶话题）。 |
| `List<String>` 不能赋值给 `List<Object>` | 泛型**不协变**。想接受"任意 List" 用 `List<?>`。 |
| 想在 `static` 方法里用类的 `T` | 语法错误。静态方法要用泛型，得自己声明 `<T>`。 |
| `if (x instanceof List<String>)` 编译不过 | 类型擦除，运行期无法判断。改成 `x instanceof List<?>`。 |
| `.class` 拿到的是原始类型 | `new ArrayList<String>().getClass()` 返回 `ArrayList.class`，不是 `ArrayList<String>.class`。 |

### 6.8 练习 / 思考

1. 写一个泛型方法 `<T> T last(List<T> list)`，返回列表最后一个元素；列表为空返回 `null`。用 `List<String>` 和 `List<Integer>` 各测试一次。
2. 写一个泛型类 `Pair<K, V>`（就是本讲 6.2 演示的那个），加一个 `swap()` 方法返回 `Pair<V, K>`。
3. 写一个泛型方法 `<T> boolean contains(List<T> list, T target)`，判断 target 是否在 list 里（用 `equals` 比较）。
4. 观察 `HashMap<K, V>` 的源码签名（IDE 里 `Ctrl` 点进去看），说出 K、V 各在哪些方法出现。
5. 挑战：写一个 `Stack<T>` 泛型类，内部用 `ArrayList<T>` 存储，实现 `push`、`pop`、`peek`、`isEmpty` 四个方法。

---

## Day06 小结

今天一天，你把 Java 标准库中最"每天都会用到"的七个知识点全部收入囊中：

1. **`String`**——不可变、常量池、`equals` 而非 `==`、12 个高频 API。
2. **`StringBuilder / StringBuffer`**——可变字符串，循环拼接的正确选择；用它写出了 `StringUtils` 工具类。
3. **包装类**——八对映射、自动装拆箱、Integer 缓存 `[-128, 127]`、null 拆箱 NPE。
4. **`ArrayList`**——动态数组、三种遍历、遍历删除的三个正确姿势、扩容 1.5 倍的底层原理。
5. **`HashMap`**——O(1) 查找、`getOrDefault` 词频统计、自定义 key 必须 `equals + hashCode` 同时重写。
6. **`HashSet`**——底层就是 `HashMap` 的 keySet，去重就是不允许重复 key。
7. **泛型**——尖括号里塞的到底是什么，怎么自己写泛型类、泛型方法、泛型接口。

**综合案例**：把 Day04 的"4 个平行数组"版学生管理系统重写成 `Map<String, Student>` 版，代码量从 200 行降到 80 行，查询/删除从 O(n) 降到 O(1)——这就是"面向对象 + 集合"的复合威力。

---

## 全课程汇总：Day01 → Day06 的六天旅程

| Day | 主题 | 你学到了什么 | 关键案例 |
|-----|------|-------------|---------|
| Day01 | Java 基础与开发环境 | JDK / JRE / JVM 三件套；变量、数据类型、运算符；`Scanner` 输入 | HelloWorld、简单计算器 |
| Day02 | 流程控制与数组 | `if / switch / for / while / do-while`、break / continue、一维/二维数组 | 九九乘法表、成绩统计 |
| Day03 | 方法与综合案例 | 方法定义、参数传递（值传递）、方法重载、递归、可变参数 | 猜数字游戏、递归计算 |
| Day04 | 面向对象基础 | 类与对象、构造器、封装、this、static、final、包与访问控制 | StudentSystem V1（数组版）|
| Day05 | 继承、多态与接口 | `extends`、`super`、方法重写、多态、抽象类、接口、枚举、Record | 图形面积计算、支付接口 |
| Day06 | 集合与泛型（本 Day）| String / StringBuilder / 包装类 / ArrayList / HashMap / HashSet / 泛型 | StringUtils、StudentSystemV2 |

**一根主线**贯穿六天：

> **数据结构从"变量"到"数组"到"对象"到"集合"，行为从"顺序"到"分支"到"循环"到"方法"到"重写"，能力从"能跑"到"能读"到"能改"到"能重构"。**

如果你把六天的作业**全部做完**，此刻你已具备：

- **看懂大部分 Java 开源库源码**的基本语法功底；
- **独立完成命令行小工具**（文件处理、数据统计、简易 CRUD）的能力；
- **进入下一阶段（异常 / IO / 多线程 / Spring）**的合格入场券。

---

## 后续学习建议

Java 基础只是敲门砖，真正的工程能力在下面这条路上：

1. **异常处理**——`try-catch-finally`、`throws`、自定义异常、`try-with-resources`。写任何 IO / 网络代码之前必学。
2. **IO 与文件**——`File`、`InputStream / OutputStream`、`Reader / Writer`、JDK 7+ 的 `Files` / `Path` / `Paths`。学完你就能把 `StudentSystemV2` 的数据**存到文件里**，重启后还在。
3. **Lambda 与 Stream API**——函数式编程入口。学完之后，你今天写的 `for` 循环遍历 `Map` 大部分能改成 3 行 `stream().filter(...).map(...).collect(...)`。
4. **多线程与并发**——`Thread`、`Runnable`、`ExecutorService`、`CompletableFuture`、`synchronized` / `Lock`、`ConcurrentHashMap`。这是"能写单机脚本"和"能写服务端程序"的分水岭。
5. **网络编程**——`Socket`、HTTP 客户端（`HttpClient`，JDK 11+ 自带）、JSON 处理（Jackson / Gson）。
6. **数据库（JDBC）**——连 MySQL / PostgreSQL、执行 SQL、连接池（HikariCP）。学完就能把学生数据从 `HashMap` 搬进真正的数据库。
7. **Spring Boot 入门**——Java 后端事实标准。IoC、DI、`@RestController`、Spring Data JPA，写一个 REST 版的学生管理系统。
8. **Java 与 AI**——LangChain4j、Spring AI，用 Java 直接调用大模型 API，把你今天写的 `StudentSystemV2` 升级成"能对话的学生助手"。

**推荐节奏**：先花 1—2 周把 1—3 项吃透（都在 JDK 标准库里），再进入 4—6 的工程栈，最后 7、8 是"能落地做项目"的门槛。

---

## 终章作业

### 必做：使用集合重写学生管理系统 `StudentSystemV3`

在今天 5.8 节的 `StudentSystemV2` 基础上，做以下升级：

1. 把 `Student` 从 `record` 改回**普通类**（含私有字段 + getter / setter + 全参构造器 + `toString()`），亲手体验 record 帮你省了多少代码。
2. 用 `Map<String, Student>` 存学生（学号为 key）、用 `HashSet<String>` 记录"已使用的姓名"实现"姓名不允许重复"的校验。
3. 新增两个功能菜单项：
   - **"按成绩降序展示"**：遍历 `db.values()`，收集到 `ArrayList` 里，用 `Comparator.comparingDouble(Student::getScore).reversed()` 排序（提示：`list.sort(...)`）。
   - **"按姓氏查找"**：输入一个汉字，输出所有姓这个字的学生。
4. 每次退出前把所有学生**打印一份完整清单**（表头 + 每行学生信息）。
5. 提交产物：`StudentSystemV3.java` 单文件 + 一段运行截图或输出日志。

**评分要点**：`equals + hashCode` 用对（姓名去重）、`Map` 遍历方式选对（`entrySet` 或 `values`）、遍历时如果要删除用 `Iterator.remove()`——这三点就是今天七个知识点在一个项目里全部**同时出现**的地方。

### 选做：用泛型实现一个自己的 `Pair<K, V>`

对照今天 6.2、6.3 节的写法，实现下面这个类：

```java
public class Pair<K, V> {
    // TODO 1：两个私有字段 key、value
    // TODO 2：全参构造器 Pair(K key, V value)
    // TODO 3：getKey()、getValue()
    // TODO 4：swap()，返回 Pair<V, K>（key 变 value，value 变 key）
    // TODO 5：重写 equals、hashCode、toString（提示：Objects.hash / Objects.equals）
    // TODO 6：静态泛型方法 <A, B> Pair<A, B> of(A a, B b)，简化创建
}
```

写完请在 `main` 里跑：

```java
Pair<String, Integer> p1 = Pair.of("age", 20);
Pair<Integer, String> p2 = p1.swap();
System.out.println(p1);
System.out.println(p2);

Set<Pair<String, Integer>> set = new HashSet<>();
set.add(Pair.of("age", 20));
set.add(Pair.of("age", 20));   // 内容相同，equals + hashCode 正确的话 set.size() 应该是 1
System.out.println(set.size());
```

**预期输出**：

```text
Pair{key=age, value=20}
Pair{key=20, value=age}
1
```

如果第三行输出 `2`，说明 `equals + hashCode` 没写对——回头看今天第 5 讲最后的 pitfall 表。

---

**六天，六个 Day，从 `System.out.println("Hello, World")` 到手写泛型 `Pair<K, V>`——恭喜你走完了 Java 基础的完整通关路线。**

**下一站见。**
