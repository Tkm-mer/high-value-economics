# 《AI 生产力赋能》 - 学生讲义（Day02：Linux 初体验 + Docker 初体验）

**总课时：6 讲**
**适用对象：AI 初学者（大一/大二本科生、非计算机专业亦可）**
**先修：** Day01（AI 认知 + 生产力赋能）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Linux 概述 + WSL 2 安装 Ubuntu | 拥有一个可用的 Linux 环境 |
| 第 2 讲 | Linux 常用命令（上） | 熟练 20+ 目录/文件/搜索/权限命令 |
| 第 3 讲 | Linux 常用命令（下）+ 工具安装 | 装齐 Git/Node/Python + 写完 `morning.sh` |
| 第 4 讲 | Docker 介绍 | 弄懂镜像/容器/仓库；对比 Docker vs 虚拟机 |
| 第 5 讲 | Docker 安装 + 镜像加速 | `docker run hello-world` 通过 |
| 第 6 讲 | Docker 部署 MySQL + Compose | 拥有一个可连接的 MySQL 容器 |

---

## 第 1 讲：Linux 概述 + WSL 2 安装 Ubuntu

### 1.1 Linux 是什么

**Linux 是一款免费、开源的操作系统内核**（1991 年由芬兰大学生 Linus Torvalds 开发）。基于这个内核，加上一整套软件工具，形成了各种"发行版（Distribution）"：

| 发行版 | 特点 | 主要面向 |
|---|---|---|
| **Ubuntu** | 最流行的桌面 / 服务器发行版，社区活跃 | 初学者、开发者、云服务器 |
| Debian | 稳如老狗，Ubuntu 的上游 | 服务器 |
| CentOS Stream / Rocky / Alma | RHEL 系，企业友好 | 企业服务器 |
| Fedora | 前沿新技术试验田 | 开发者 |
| Arch | 极简，滚动更新，DIY | 极客 |
| Alpine | 极小（5MB），Docker 容器常用 | 容器镜像 |

**本课程统一使用 Ubuntu 26.04 LTS**（Resolute Wombat，2026 年 4 月发布），因为它是最新的 LTS，支持年限最长。命令与 24.04 LTS 完全通用；如果学校镜像或云服务器暂时只有 24.04，把版本号替换即可。

### 1.2 为什么要学 Linux

- **服务器几乎全跑 Linux**：全球 90%+ 的云服务器、几乎所有的超算，都是 Linux
- **开发工具原生支持 Linux**：Docker、Git、Node、Python、Kubernetes 等在 Linux 上最原生、最流畅
- **AI 时代的必修课**：Claude Code、Hermes Agent、大部分开源大模型工具，命令行首选 Linux / macOS
- **命令行思维**：一旦你学会用命令行，效率会**指数级提升**

### 1.3 Windows 上体验 Linux 的三种方式

```mermaid
flowchart TB
    A["Windows 用户想用 Linux"] --> B["方式一：WSL 2<br/>轻量、无缝、推荐"]
    A --> C["方式二：VMware / VirtualBox<br/>虚拟机，完整桌面"]
    A --> D["方式三：双系统<br/>硬盘分区，性能最好"]
    B --> B1["✅ 5 分钟装好<br/>✅ 与 Windows 共存<br/>❌ 桌面 GUI 略弱"]
    C --> C1["✅ 完整 Linux 桌面<br/>❌ 占资源<br/>❌ 略慢"]
    D --> D1["✅ 性能最好<br/>❌ 折腾<br/>❌ 需要重启切换"]
```

**本教程强烈推荐 WSL 2**：只要你是 Windows 10 / 11，一条命令就能装好。

### 1.4 使用 WSL 2 安装 Ubuntu

**前置条件**：Windows 10 版本 2004 及以上（或 Windows 11 任何版本）。

**第一步**：以管理员身份打开 PowerShell。

（开始菜单搜 "PowerShell" → 右键 → "以管理员身份运行"）

**第二步**：执行安装命令：

```powershell
# 默认安装 WSL 2 + Ubuntu
wsl --install

# 或指定发行版
wsl --install -d Ubuntu-26.04
```

系统会自动开启相关组件、下载并安装 Ubuntu。**装完后需要重启**。

**第三步**：重启后，开始菜单里会出现 "Ubuntu" 应用，第一次打开会让你设置用户名和密码：

```
Enter new UNIX username: your_name
New password: ******
Retype new password: ******
```

> **注意**：输入密码时屏幕不会显示任何字符（既不显示星号也不显示光标移动），**这是 Linux 的安全设计，不是卡了**。

**第四步**：检查安装：

```bash
# 查看系统版本
lsb_release -a

# 查看内核
uname -a
```

### 1.5 使用虚拟机安装 Ubuntu（备选）

如果你想要一个**完整的 Linux 桌面**（有开始菜单、有窗口、能装浏览器），可以用虚拟机：

1. 下载 **VMware Workstation Player**（个人免费）或 **VirtualBox**（免费开源）。
2. 到 `https://ubuntu.com/download/desktop` 下载 Ubuntu Desktop 26.04 LTS 的 ISO 文件（约 5GB）。
3. 在虚拟机软件里"新建虚拟机"→ 加载 ISO → 分配 4GB 内存、40GB 硬盘 → 一路下一步 → 装完开机。
4. 装完后建议装 **VMware Tools / VirtualBox Guest Additions**，能让屏幕自适应、支持粘贴板共享。

### 1.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `WslRegisterDistribution failed` | Windows 版本太旧或没开虚拟化，去 BIOS 里开启 VT-x / AMD-V |
| 想删掉重装 Ubuntu | PowerShell 执行 `wsl --unregister Ubuntu-26.04` 然后重新安装 |
| 想设默认版本为 WSL 2 | `wsl --set-default-version 2` |
| 输入密码不显示任何字符 | 正常，Linux 安全设计，继续输入即可 |
| WSL 里内网访问不通 | Windows 防火墙可能阻挡，或需要 `wsl --shutdown` 后重启 |

### 1.7 练习/思考

1. 完成 WSL 2 + Ubuntu 26.04 的安装，截图记录 `lsb_release -a` 与 `whoami` 的输出。
2. 查询你的电脑主板型号，写下"如何进入 BIOS + 如何开启虚拟化"的步骤（150 字以内）。
3. 装完 WSL 后，尝试执行 `wsl --set-default-version 2`，解释 WSL 1 与 WSL 2 的区别。

---

## 第 2 讲：Linux 常用命令（上）——文件/查看/搜索/权限

命令行的核心是"**记得住的少量高频命令 + 会查手册**"。以下命令都值得**动手敲一遍**。

### 2.1 目录与文件操作

```bash
# 打印当前目录（Print Working Directory）
pwd
# 输出示例：/home/your_name

# 列出目录内容（LiSt）
ls              # 简洁列表
ls -l           # 详细列表（权限、大小、日期）
ls -la          # 加上隐藏文件（以 . 开头）
ls -lh          # 大小以人类可读格式（1K、234M、2G）

# 切换目录（Change Directory）
cd /home            # 进入 /home
cd ~                # 进入自己的 home 目录 (~)
cd ..               # 回到上一级
cd -                # 回到上一次所在目录

# 创建目录
mkdir myproject
mkdir -p a/b/c      # -p 递归创建，缺失的父目录自动补齐

# 创建文件
touch hello.txt

# 复制、移动、删除
cp source.txt dest.txt          # 复制文件
cp -r src_dir dst_dir           # 复制目录 (-r 递归)
mv old.txt new.txt              # 重命名 / 移动
rm file.txt                     # 删除文件
rm -rf some_dir                 # 递归强制删除目录（危险！）
```

> **`rm -rf` 的危险性**：Linux 没有"回收站"，`rm -rf /` 会把整个系统删光。**养成每次执行前看两遍路径的习惯**。

### 2.2 查看文件内容

```bash
# 查看短文件
cat hello.txt

# 查看长文件（分页，q 退出，空格翻页）
less big_file.log

# 只看开头 / 结尾几行
head -n 20 file.log
tail -n 20 file.log

# 实时查看日志追加
tail -f /var/log/syslog
```

### 2.3 搜索与管道

```bash
# 在文件中搜索
grep "error" app.log
grep -i "error" app.log         # 忽略大小写
grep -r "TODO" ./src            # 递归搜目录

# 查找文件
find . -name "*.md"             # 当前目录下所有 .md
find /home -type d -name ".git" # 查找所有 .git 目录

# 管道（|）：把上一个命令的输出交给下一个命令
ls -l | grep "^d"               # 只显示目录
history | grep git              # 历史命令中找 git
```

### 2.4 权限与用户

```bash
# 查看权限（ls -l 中 -rwxr-xr-x 那部分）
ls -l script.sh

# 修改权限
chmod +x script.sh              # 给所有人加执行权限
chmod 755 script.sh             # 数字模式：rwxr-xr-x

# 以管理员身份执行（super user do）
sudo apt update
sudo systemctl restart nginx

# 切换用户 / 查看当前用户
whoami
su your_name
```

Linux 的权限用 `rwx` 表示读、写、执行，分别对应数字 4、2、1：

- 7 = rwx（读写执行）
- 6 = rw-（读写）
- 5 = r-x（读+执行）
- 4 = r--（只读）

三位数分别代表 **owner / group / others**：`755` 就是"我全能，其他人只能读+执行"。

### 2.5 综合示例：建学习目录

跟着敲一遍（这一段综合运用了 8 个上面学过的命令）：

```bash
cd ~                            # 进 home
mkdir -p study/{ai,linux,docker,notes}
cd study/notes
touch day1.md
echo "# Day1" > day1.md
echo "- WSL 2 装好" >> day1.md
echo "- lsb_release -a" >> day1.md

cat day1.md
ls -la ..

find ~ -name "*.md" | head -5
grep -r "WSL" ~/study
```

### 2.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 用 `rm -rf ~/` 把 home 目录清空 | Linux 没有回收站，看两遍再敲回车 |
| `cd 长路径名` 太累 | 用 Tab 自动补全（半个词按 Tab 就补） |
| 忘记 `mkdir -p` 直接 `mkdir a/b/c` 报错 | 加 `-p` 会自动补上缺失的父目录 |
| `grep` 中文乱码 | 确认终端是 UTF-8，Windows Terminal 默认就是 |
| `chmod 777` 一把梭 | 太宽松有安全风险，务实一点用 `755` / `644` |

### 2.7 练习/思考

1. 在 home 目录下创建如下结构（用 `mkdir -p` 一条命令搞定，最后用 `tree` 或 `ls -R` 展示结果）：
   ```
   ~/study/
   ├── ai/
   ├── linux/
   ├── docker/
   └── notes/
       └── day1.md
   ```
2. 在 `~/study/notes/day1.md` 里写下你今日学到的 5 个 Linux 命令与用法（用 Markdown）。
3. 用 `find + grep` 组合，查出 `~/` 下所有含关键词 "hello" 的 `.md` 文件路径。

---

## 第 3 讲：Linux 常用命令（下）+ 工具安装 + 综合脚本

### 3.1 网络与进程

```bash
# 查看 IP
ip addr
ip a                            # 简写

# 测试网络
ping -c 4 baidu.com

# 下载文件
curl -O https://example.com/file.zip
wget https://example.com/file.zip

# 查看进程
ps aux | grep node              # 找 node 相关进程
top                             # 实时进程监视（q 退出）
htop                            # 更友好的版本（需要单独安装）

# 结束进程
kill 12345                      # 12345 是 PID
kill -9 12345                   # 强制杀
```

### 3.2 包管理（apt）

Ubuntu 用 `apt` 管理软件包，是最重要的命令之一：

```bash
# 更新软件源索引
sudo apt update

# 升级已装软件
sudo apt upgrade -y

# 搜索软件
apt search htop

# 安装软件
sudo apt install -y htop tree curl wget git

# 卸载
sudo apt remove htop

# 完全卸载（连配置一起删）
sudo apt purge htop
```

**`apt update` 与 `apt upgrade` 的区别**：`update` 是"看看有啥新版本"（只更新索引），`upgrade` 才是"真的升级软件"。

### 3.3 命令行进阶技巧

```bash
# 命令历史
history                # 看历史命令
!123                   # 执行历史中的第 123 条
Ctrl + R               # 交互式搜索历史（超实用！）

# 快捷键
Ctrl + C               # 中断当前命令
Ctrl + D               # 退出终端 / 结束输入
Ctrl + L               # 清屏 (= clear)
Ctrl + A / Ctrl + E    # 光标到行首 / 行尾
Tab                    # 自动补全（超重要）

# 重定向
echo "hello" > out.txt      # 覆盖写入
echo "world" >> out.txt     # 追加写入
cat < in.txt                # 从文件读取

# 组合命令
mkdir foo && cd foo         # && 前一个成功才执行后一个
apt update ; apt upgrade    # ; 无论前一个是否成功，都执行后一个
```

**重点掌握 `Ctrl + R`**：它是命令行效率的分水岭。按下后开始输入历史命令的关键字（如 `docker run`），会实时匹配你以前敲过的命令，回车直接执行。

#### 3.3.1 tmux——一屏多个终端会话

以后你会**同时开好几件事**：一个终端跑 Claude Code、一个跑测试、一个看日志、一个 SSH 到服务器。开一堆窗口不好管理，`tmux` 让你在**一个终端里横竖切分**，并且**断开也不丢**（关掉终端窗口，进程仍在）。

```bash
sudo apt install -y tmux

# 新建会话
tmux new -s work        # 创建叫 work 的会话

# 会话内最常用 5 个快捷键（前缀键默认 Ctrl+B，先按 Ctrl+B，松手，再按下面的键）
#   Ctrl+B  %      → 左右分屏
#   Ctrl+B  "      → 上下分屏
#   Ctrl+B  方向键 → 在窗格间切换
#   Ctrl+B  d      → detach（脱离会话，进程仍在后台跑）
#   Ctrl+B  x      → 关闭当前窗格

# 重新连回会话
tmux ls                 # 列出所有会话
tmux attach -t work     # 连回 work
```

**为什么现在就要学它**：Day03 我们用 Claude Code 时，会一边开 Claude 一边看代码/跑测试，tmux 会让你舒服 10 倍。

### 3.4 编辑器：nano 与 vim

**nano**（简单、推荐初学者）：

```bash
nano hello.txt
# 编辑内容
# Ctrl + O 保存 → 回车确认
# Ctrl + X 退出
```

**vim**（强大、程序员标配）：

```bash
vim hello.txt
# 按 i 进入插入模式
# 编辑内容
# Esc 退出插入模式
# :wq 保存并退出
# :q! 不保存强制退出
```

**vim 最小闭环**：`i` → 编辑 → `Esc` → `:wq`。学到这个先够用。

### 3.5 一条命令装齐基础工具

```bash
sudo apt update
sudo apt install -y \
    git curl wget \
    build-essential \
    tree htop \
    unzip zip \
    vim nano \
    jq
```

各工具用途简述：

| 工具 | 作用 |
|------|------|
| git | 版本控制，几乎所有 AI 项目都要用 |
| curl / wget | 命令行下载文件 |
| build-essential | 编译工具链（gcc、make），装很多软件的依赖 |
| tree | 树形显示目录结构 |
| htop | 更好看的进程监视器 |
| jq | JSON 命令行处理神器（AI API 返回都是 JSON） |

### 3.6 安装 Git 并配置

```bash
# 上一步已经装了 git，这里配置个人信息
git config --global user.name "Your Name"
git config --global user.email "you@example.com"

# 让 Git 输出彩色
git config --global color.ui auto

# 检查配置
git config --list
```

#### 3.6.1 配置 GitHub SSH Key（推送必备）

用 HTTPS 每次推送都要输密码/Token，很麻烦。**用 SSH Key 一次配置终身受用**，也是业界标配。

```bash
# 第一步：生成 ed25519 密钥（比 RSA 更短更安全，GitHub 官方推荐）
ssh-keygen -t ed25519 -C "you@example.com"
# 一路回车：默认路径 ~/.ssh/id_ed25519（私钥）+ id_ed25519.pub（公钥）
# passphrase 可以留空（个人电脑），也可以加一层口令保护

# 第二步：复制公钥内容
cat ~/.ssh/id_ed25519.pub
# 输出形如：ssh-ed25519 AAAAC3Nz... you@example.com

# 第三步：粘到 GitHub → Settings → SSH and GPG keys → New SSH key

# 第四步：验证连通
ssh -T git@github.com
# 首次会问 yes/no，输 yes
# 成功输出：Hi <你的用户名>! You've successfully authenticated...
```

以后 `git clone git@github.com:xxx/yyy.git` 就再也不用输密码了。

> **私钥 `~/.ssh/id_ed25519` 严禁外泄**！只把 `.pub` 结尾的公钥贴出去。

### 3.7 安装 Node.js（LTS 版本）

Node.js 是 Claude Code、许多 AI CLI 工具的运行时。**推荐用 nvm**（Node Version Manager）方便切换版本：

```bash
# 安装 nvm
# 拉最新 tag 再装（避免硬编码版本号）
NVM_LATEST=$(curl -s https://api.github.com/repos/nvm-sh/nvm/releases/latest | grep tag_name | cut -d '"' -f 4)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/${NVM_LATEST}/install.sh | bash

# 加载 nvm（新开一个终端也可以）
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# 安装 LTS 版本 Node
nvm install --lts
nvm use --lts

# 验证
node -v
npm -v
```

### 3.8 安装 Python 与 pip

Ubuntu 通常自带 Python 3，但需要额外装 pip：

```bash
sudo apt install -y python3 python3-pip python3-venv

# 验证
python3 --version
pip3 --version

# 用虚拟环境隔离依赖（强烈推荐！）
python3 -m venv .venv
source .venv/bin/activate
pip install requests
deactivate
```

### 3.9 安装 uv（Python 现代包管理器，可选但推荐）

`uv` 是 Rust 写的极速 Python 包管理工具，比 pip 快 10—100 倍：

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh

# 重启终端后
uv --version
uv init myproj
cd myproj
uv add requests
uv run main.py
```

### 3.10 让 WSL 与 Windows 互通

- **访问 Windows 文件**：在 WSL 里 `cd /mnt/c/Users/<你的 Windows 用户名>/Desktop`
- **从 Windows 访问 WSL 文件**：Windows 资源管理器地址栏输入 `\\wsl$` → 进入 Ubuntu → 你的 home
- **在当前目录打开 VS Code**：`code .`（第一次会自动安装 WSL Server）

### 3.11 综合练习：写一个"每日启动"脚本

在 home 目录建一个 `morning.sh`：

```bash
nano ~/morning.sh
```

写入：

```bash
#!/bin/bash
# 每日启动脚本
echo "===== $(date '+%Y-%m-%d %H:%M:%S') ====="
echo "欢迎回来，$(whoami)！"

echo ""
echo "→ 系统负载："
uptime

echo ""
echo "→ 磁盘使用："
df -h | grep -E "^/dev"

echo ""
echo "→ 今日待办（TODO.md 内容）："
cat ~/TODO.md 2>/dev/null || echo "(尚未创建 ~/TODO.md)"

echo ""
echo "祝你有个高效的一天！"
```

赋予执行权限并运行：

```bash
chmod +x ~/morning.sh
~/morning.sh
```

要想每次开终端自动跑一遍，加到 `~/.bashrc` 末尾：

```bash
echo "~/morning.sh" >> ~/.bashrc
```

### 3.12 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `curl … nvm install.sh` 卡住 | GitHub raw 国内不稳，走 GitHub 代理或加 hosts |
| `nvm: command not found` | nvm 装完了但新终端没加载，重开终端或执行 `source ~/.bashrc` |
| Python 用 `pip install` 报权限错 | 不要用 sudo pip，用 venv 或 `--user` |
| 写完 `morning.sh` 直接跑报 `permission denied` | 忘了 `chmod +x` |
| shebang 写成 `#!bin/bash` 缺斜杠 | 必须 `#!/bin/bash`，一定要有前导斜杠 |

### 3.13 练习/思考

1. 完成 Git、Node.js LTS、Python 3、jq、htop、tree 全部安装，把 `--version` 输出粘到 `~/study/notes/day2.md`。
2. 把 `morning.sh` 加到你的 `~/.bashrc` 末尾，每次打开终端自动跑一遍。
3. 安装 uv，用 `uv init myproj && uv add requests && uv run main.py` 走一遍新版 Python 包管理流程。
4. 编写 `~/hello.sh`：接收一个参数（人名），输出 `Hello, XXX! 现在是 YYYY-MM-DD HH:MM:SS`。提示：`$1` 是第一个参数，`date '+%Y-%m-%d %H:%M:%S'` 是格式化日期。

---

## 第 4 讲：Docker 介绍

### 4.1 一句话理解 Docker

**Docker = 一种"把软件和它的运行环境一起打包"的技术。**

用一个通俗类比：

- **过去**：装一个 MySQL，要下载安装包、装依赖、改配置、创建用户 …… 每台机器都不一样，环境问题层出不穷（"我这里能跑"）。
- **现在**：`docker run mysql:8.4`，30 秒后你就有一个可用的 MySQL，无论你的机器是 Windows / Mac / Ubuntu / CentOS。

### 4.2 三个核心概念：镜像、容器、仓库

```mermaid
flowchart LR
    A["Docker Hub / 镜像仓库<br/>(存放镜像)"] -->|"docker pull"| B["镜像 Image<br/>(只读模板，如 mysql:8.4)"]
    B -->|"docker run"| C["容器 Container<br/>(镜像的运行实例)"]
    C -->|"docker commit / build"| B
```

| 概念 | 类比 | 说明 |
|------|------|------|
| **镜像（Image）** | 光盘 / 模板 | 只读，包含应用 + 运行环境。名字通常是 `名称:标签`，如 `mysql:8.4`、`ubuntu:26.04`。 |
| **容器（Container）** | 光盘启动出来的一台电脑 | 镜像的运行实例，可以启动、停止、删除。同一个镜像可以创建 N 个容器。 |
| **仓库（Registry）** | 应用商店 | 存放镜像的地方。官方 = **Docker Hub**（`hub.docker.com`），国内可用镜像加速器。 |

### 4.3 Docker 与虚拟机的区别

```mermaid
flowchart TB
    subgraph VM["虚拟机（VM）"]
        V1["Guest OS 1<br/>App 1"]
        V2["Guest OS 2<br/>App 2"]
        V3["Guest OS 3<br/>App 3"]
        H["Hypervisor（VMware/VirtualBox）"]
        HOS["Host OS"]
        HW1["硬件"]
        V1 --- H
        V2 --- H
        V3 --- H
        H --- HOS
        HOS --- HW1
    end

    subgraph DK["Docker 容器"]
        C1["App 1"]
        C2["App 2"]
        C3["App 3"]
        D["Docker Engine"]
        HOS2["Host OS（内核共享）"]
        HW2["硬件"]
        C1 --- D
        C2 --- D
        C3 --- D
        D --- HOS2
        HOS2 --- HW2
    end
```

- **虚拟机**：每个 VM 都有完整的 Guest OS，启动慢（分钟级），资源占用大（几 GB / 个）。
- **容器**：共享宿主机内核，启动快（秒级），资源占用小（几十 MB / 个），一台机器可以跑几十上百个容器。

### 4.4 Docker 的典型使用场景

1. **快速搭建开发环境**：一条命令跑起 MySQL / Redis / MongoDB / Elasticsearch 等中间件。
2. **应用交付**：把自己的应用打包成镜像，交付到任何机器都是同一份运行环境。
3. **CI/CD**：GitHub Actions、GitLab CI 中大量使用容器构建、测试、部署。
4. **微服务**：一个服务一个容器，用 Docker Compose / Kubernetes 编排。
5. **AI 模型部署**：如用 Ollama 镜像本地跑大模型、用 vLLM 镜像部署推理服务。

### 4.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 把"镜像"和"容器"混为一谈 | 镜像 = 光盘（模板）；容器 = 光盘启动的电脑（运行实例） |
| 以为容器 = 虚拟机 | 容器共享宿主机内核，只是"进程 + 隔离"，不是完整 OS |
| 只有一个镜像标签就当"没有版本管理" | 镜像名是 `名称:标签`，如 `mysql:8.4`，永远显式指定 tag 而不是用 `latest` |
| 把镜像仓库理解成"网盘" | 更接近"应用商店"，有版本、有元数据、有拉取次数统计 |

### 4.6 练习/思考

1. 用自己的话（300 字以内）向不懂技术的家人解释 Docker，可用类比。
2. 登录 Docker Hub（`https://hub.docker.com/`），找出下列镜像的最新 stable tag：`mysql`、`nginx`、`redis`、`postgres`。
3. 查资料写 200 字回答："Docker 用的是 Linux 内核的哪些底层特性来实现容器隔离？"（提示：cgroups / namespaces）

---

## 第 5 讲：Docker 安装 + 国内镜像加速

### 5.1 三种安装方式

| 场景 | 推荐方式 |
|------|----------|
| Windows + WSL 2 | **Docker Desktop for Windows**（图形界面，最省心） |
| macOS | Docker Desktop for Mac |
| 纯 Linux 服务器 / WSL 2 内部 | 直接装 **Docker Engine**（无图形） |

### 5.2 方式一：Docker Desktop（Windows / macOS 推荐）

1. 到 `https://www.docker.com/products/docker-desktop/` 下载对应版本。
2. Windows 双击安装包，**勾选 "Use WSL 2 based engine"**，一路下一步。
3. 装完后启动 Docker Desktop，等待右下角托盘图标变为绿色鲸鱼。
4. 在 PowerShell / WSL 里都可以直接使用 `docker` 命令：

```bash
docker --version
docker info
```

### 5.3 方式二：Ubuntu / WSL 内部安装 Docker Engine

如果你在 WSL 里想单独装 Docker Engine（不装 Docker Desktop），按以下步骤：

```bash
# 卸载可能的旧版本
sudo apt remove -y docker docker-engine docker.io containerd runc 2>/dev/null

# 安装依赖
sudo apt update
sudo apt install -y ca-certificates curl gnupg lsb-release

# 添加 Docker 官方 GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
    sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# 添加 Docker 软件源
echo "deb [arch=$(dpkg --print-architecture) \
    signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu \
    $(lsb_release -cs) stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 安装
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin

# 启动 & 开机自启
sudo systemctl enable docker
sudo systemctl start docker

# 让当前用户免 sudo 使用 docker
sudo usermod -aG docker $USER
newgrp docker

# 验证
docker version
docker run hello-world
```

`docker run hello-world` 输出「Hello from Docker!」即安装成功。

**加组后必须 `newgrp docker` 或者重开终端**才生效。

### 5.4 配置国内镜像加速（强烈推荐）

在国内直接从 Docker Hub 拉取镜像很慢，配置一个加速器（如阿里云、中科大、DaoCloud）：

```bash
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.baidubce.com"
  ]
}
EOF

sudo systemctl daemon-reload
sudo systemctl restart docker
```

Docker Desktop 用户在设置 → Docker Engine 里改 JSON 即可。

### 5.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `docker: command not found` | 装成功但需要重开终端 / 或 PATH 未刷新 |
| `permission denied` on `/var/run/docker.sock` | 忘了 `sudo usermod -aG docker $USER` + `newgrp docker` |
| `docker run hello-world` 卡在拉镜像 | 国内网络到 Docker Hub 慢，配 registry-mirrors |
| Docker Desktop 无法启动 | Windows 未开虚拟化、WSL 2 未启用、Hyper-V 未开 |
| `daemon.json` 写错 JSON 语法 | Docker daemon 起不来，改回来 `systemctl restart docker` |

### 5.6 练习/思考

1. 完成 Docker 安装 + hello-world 通过 + 至少 1 个镜像加速器配置。截图 `docker version` 和 `docker info` 输出。
2. 写 100 字对比"Docker Desktop 和 Docker Engine 的差异，你为什么选它？"
3. 查资料整理 5 个国内常用的公共镜像加速器地址，测试各自拉取速度并排序。

---

## 第 6 讲：Docker 快速入门——部署 MySQL 并进行连接测试

### 6.1 第一个容器：hello-world

```bash
docker run hello-world
```

**发生了什么？**

1. Docker 客户端向本地 daemon 发送 `run` 请求；
2. daemon 检查本地是否有 `hello-world` 镜像，没有则从 Docker Hub 拉取；
3. 从镜像创建一个容器并运行；
4. 容器打印一行 "Hello from Docker!"，然后退出。

### 6.2 Docker 命令速查

```bash
# 镜像相关
docker pull mysql:8.4                # 拉取镜像
docker images                        # 查看本地镜像
docker rmi <image_id>                # 删除镜像

# 容器相关
docker ps                            # 查看运行中的容器
docker ps -a                         # 查看所有容器（含已停止）
docker start <container>             # 启动一个已存在的容器
docker stop <container>              # 停止容器
docker restart <container>           # 重启
docker rm <container>                # 删除容器（需先停止）
docker rm -f <container>             # 强制删除
docker logs -f <container>           # 查看日志（-f 跟随）
docker exec -it <container> bash     # 进入容器交互终端

# 系统相关
docker system df                     # 查看磁盘占用
docker system prune -f               # 清理未使用的镜像、容器、网络
```

### 6.3 部署 MySQL 容器

**目标**：跑一个 MySQL 8.4，端口映射到宿主机的 3306，密码 `root123`，数据持久化到本地。

**命令**：

```bash
docker run -d \
  --name mysql-demo \
  -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=root123 \
  -e MYSQL_DATABASE=demo \
  -v mysql_data:/var/lib/mysql \
  --restart unless-stopped \
  mysql:8.4
```

**参数逐个解释**：

| 参数 | 含义 |
|------|------|
| `-d` | 后台运行（detached） |
| `--name mysql-demo` | 给容器起一个名字，方便后续操作 |
| `-p 3306:3306` | 端口映射：宿主机 3306 → 容器 3306 |
| `-e MYSQL_ROOT_PASSWORD=root123` | 环境变量：设置 root 密码 |
| `-e MYSQL_DATABASE=demo` | 环境变量：启动时自动创建一个名为 demo 的数据库 |
| `-v mysql_data:/var/lib/mysql` | 数据卷：把容器内的 MySQL 数据目录挂到 Docker 卷 `mysql_data`，容器删除数据也不会丢 |
| `--restart unless-stopped` | Docker 重启后自动拉起容器 |
| `mysql:8.4` | 用哪个镜像 |

**验证**：

```bash
# 看容器是否在运行
docker ps

# 看启动日志（Ctrl + C 退出跟随）
docker logs -f mysql-demo
# 出现 "ready for connections" 即启动完成
```

### 6.4 连接测试

**方式一：进入容器用 mysql 客户端**

```bash
docker exec -it mysql-demo mysql -u root -p
# 输入密码：root123
```

进入 SQL 命令行后：

```sql
-- 查看数据库
SHOW DATABASES;

-- 使用 demo 数据库
USE demo;

-- 建表
CREATE TABLE student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    score INT
);

-- 插入数据
INSERT INTO student (name, score) VALUES
    ('张三', 92),
    ('李四', 85),
    ('王五', 78);

-- 查询
SELECT * FROM student;

-- 退出
EXIT;
```

**方式二：宿主机的图形化客户端**

- 下载 **DBeaver Community**（免费开源，跨平台）：`https://dbeaver.io/`
- 或 **Navicat**、**HeidiSQL**、**MySQL Workbench**（都可）。

连接参数：

```
主机：127.0.0.1
端口：3306
用户名：root
密码：root123
数据库：demo
```

点"测试连接" → 成功！你就有了一个可用的本地 MySQL 开发环境。

**方式三：命令行客户端（宿主机）**

```bash
# 在 WSL 中
sudo apt install -y mysql-client
mysql -h 127.0.0.1 -P 3306 -u root -p
```

### 6.5 容器的日常操作

```bash
# 停止
docker stop mysql-demo

# 再启动（数据仍在，因为用了数据卷）
docker start mysql-demo

# 重启
docker restart mysql-demo

# 查看容器内配置文件
docker exec -it mysql-demo cat /etc/my.cnf

# 备份数据库
docker exec mysql-demo mysqldump -u root -proot123 demo > demo_backup.sql

# 恢复数据库
cat demo_backup.sql | docker exec -i mysql-demo mysql -u root -proot123 demo

# 彻底清理（容器 + 数据）
docker rm -f mysql-demo
docker volume rm mysql_data
```

### 6.6 用 Docker Compose 简化：一份 YAML 起一整套服务

反复敲很长的 `docker run` 太累。**Docker Compose** 允许你把多个容器的配置写在一个 `docker-compose.yml` 文件中。

#### 6.6.0 前置：自定义 Docker 网络（容器名互相解析）

多容器互访的最佳实践是**建一个自定义网络**（`bridge` 类型），然后把容器挂到同一张网上——这样它们可以**用容器名当主机名互相访问**，不用记 IP：

```bash
# 创建一个叫 aiedu 的自定义网络
docker network create aiedu

# 查看
docker network ls

# 让容器加入
docker run -d --name mysql-demo --network aiedu ... mysql:8.4
docker run -d --name pma       --network aiedu ... phpmyadmin
# 这样 pma 里就可以直接用 mysql-demo:3306 连数据库
```

> Docker Compose 里同一个 `docker-compose.yml` 的所有服务**默认在同一个自动创建的网络里**，所以下面的例子中 phpmyadmin 直接写 `PMA_HOST: mysql` 就能通——它解析到的正是同一 Compose 网络里的 `mysql` 容器。

创建 `~/study/docker/mysql/docker-compose.yml`：

```yaml
services:
  mysql:
    image: mysql:8.4
    container_name: mysql-demo
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: root123
      MYSQL_DATABASE: demo
    volumes:
      - mysql_data:/var/lib/mysql

  # 顺便加一个 phpMyAdmin 网页版数据库管理工具
  phpmyadmin:
    image: phpmyadmin:latest
    container_name: pma
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      PMA_HOST: mysql
      PMA_PORT: 3306
    depends_on:
      - mysql

volumes:
  mysql_data:
```

启动：

```bash
cd ~/study/docker/mysql
docker compose up -d           # 后台启动
docker compose ps              # 看状态
docker compose logs -f         # 看日志
docker compose down            # 停止并删除容器（数据卷保留）
```

启动完成后，浏览器打开 `http://localhost:8080`，用 `root / root123` 登录，就有网页版数据库管理工具。

**Compose 亮点**：`PMA_HOST: mysql` 中的 `mysql` 是**同一 Compose 项目里其他服务的名字**，Docker 会自动做 DNS 解析——**这就是"服务发现"**。

### 6.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Error: bind: address already in use` (3306) | 本机可能已经装了 MySQL 服务。改端口映射：`-p 3307:3306` |
| 容器里的时区不对 | 启动命令里加 `-e TZ=Asia/Shanghai` |
| 想让 Docker 自动开机启动 MySQL | `--restart unless-stopped` 已经做到了 |
| 镜像太大，磁盘紧张 | `docker system prune -a` 一键清理未使用的镜像 |
| `docker rm` 后数据丢了 | 忘了配 `-v mysql_data:/var/lib/mysql`；有数据卷就不怕 |

### 6.8 练习/思考

1. 用 `docker run` 命令启动一个 MySQL 8.4 容器，进入容器创建一张 `student` 表并插入 5 条数据。
2. 用 DBeaver（或任何一款 GUI 客户端）从宿主机连接容器 MySQL，成功查询 `student` 表。
3. 把这个部署写成 `docker-compose.yml`，并额外增加一个 Redis（`redis:7.4`）容器；用 `docker compose up -d` 一次拉起两个服务。
4. 尝试 `docker stop mysql-demo && docker start mysql-demo`，确认 `student` 表的数据依然在（说明数据卷起了作用）。
5. **进阶**：在容器上映射一个自定义的 `my.cnf` 文件（`-v ./my.cnf:/etc/mysql/conf.d/my.cnf`），把默认字符集改为 `utf8mb4`。

---

## Day02 收官

今天你完成了三件大事：

1. **拥有了一个 Linux 环境**（WSL 2 + Ubuntu 26.04）；
2. **掌握了 30+ 常用命令**并写完了 `morning.sh` 综合脚本；
3. **拥有了一个 Docker 环境**，并跑起了真实可连接的 MySQL 数据库。

**Day03 预告**：请出两位 AI 主角——**Claude Code**（AI 编程助手）和 **Hermes Agent**（AI 通用智能体）。有了 Linux + Docker 的底座，它们就可以在你的电脑里"住下"并干活了。
