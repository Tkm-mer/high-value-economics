# 《AI 生产力赋能》 - 学生讲义（Day03：Claude Code + Hermes Agent 初体验）

**总课时：6 讲**
**适用对象：AI 初学者（大一/大二本科生、非计算机专业亦可）**
**先修：** Day01（AI 认知）+ Day02（Linux + Docker）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Claude Code 是什么 + 安装 | `claude --version` 输出版本号 |
| 第 2 讲 | Claude Code 简单入门使用（上） | 让 Claude 熟悉项目 / 写脚本 / 修 Bug / 写文档 |
| 第 3 讲 | Claude Code 简单入门使用（下） | 让 Claude 跑测试 / Git / MCP / 综合项目 |
| 第 4 讲 | Hermes Agent 是什么 + 安装 | `hermes --version` 输出版本号 |
| 第 5 讲 | Hermes Agent 简单入门（上） | memory / 代码 / Web / Computer Use |
| 第 6 讲 | Hermes Agent 简单入门（下） + 结课 | Cron / Delegate / Skills / 综合项目 |

---

## 第 1 讲：Claude Code 是什么 + 安装与初始配置

### 1.1 Claude Code 是什么

**Claude Code** 是 Anthropic 官方推出的 AI 编程 CLI 工具。区别于 Cursor、Copilot 这种"IDE 插件"，Claude Code 直接跑在**终端**里，特点是：

- **在你项目目录里工作**：读你的代码、跑你的命令、改你的文件；
- **自主执行多步任务**：你说"帮我把项目里所有的 print 换成 logger"，它会自己搜索、编辑、验证；
- **调用工具与 MCP**：可接入外部工具（数据库、浏览器、GitHub 等）；
- **面向真实开发流程**：适合写脚本、修 bug、重构、写文档、跑测试。

### 1.2 一图看懂 Claude Code 与其他形态的区别

```mermaid
flowchart TB
    A["AI 编程工具的三种形态"] --> B["Chat 类<br/>ChatGPT/Claude 网页版<br/>只出主意，代码需要你复制"]
    A --> C["IDE 插件类<br/>Copilot/Cursor<br/>编辑器内补全 + 对话"]
    A --> D["CLI Agent 类<br/>Claude Code/Codex/Hermes Agent<br/>终端里跑，直接改文件、执行命令"]
```

三种形态的**主动权**依次递增，**风险**也依次递增（CLI Agent 能执行命令，需要人来把关）。

### 1.3 前置条件

- **Node.js 18+**（Day02 已经装好了 LTS）；
- **Anthropic 账号**（或使用 API Key）。到 `https://console.anthropic.com/` 注册；
- 一个可以联网访问 Anthropic 的网络环境；
- 一个 shell（bash / zsh / PowerShell 都行）。

### 1.4 安装

> **2026-07 版本注意**：Claude Code 官方已经**逐步弃用 npm 全局安装**（`npm install -g` 装完首次启动会看到弃用提示），推荐用**官方 native installer**：

**方式一（当前官方推荐）：native installer**

```bash
# macOS / Linux / WSL：
curl -fsSL https://claude.ai/install.sh | bash

# Windows PowerShell：
irm https://claude.ai/install.ps1 | iex
```

装完后：

```bash
claude --version
claude migrate-installer   # 若之前用 npm 装过，一键迁移到 native
```

**方式二（旧方式）：npm 全局安装（仍可用，不推荐）**

```bash
npm install -g @anthropic-ai/claude-code
```

**方式三：一次性运行**

```bash
npx @anthropic-ai/claude-code
```

**方式四：官方页面**

到 `https://claude.com/product/claude-code` 获取平台专属安装脚本与更新说明。

### 1.5 首次登录与初始化

在任意目录敲：

```bash
claude
```

首次启动会引导你完成：

1. **登录**：默认打开浏览器登录 Anthropic 账号（OAuth）。如果你在纯服务器上没法开浏览器，可以选择"用 API Key 登录"，把 `sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` 粘进去即可。
2. **选择工作目录**：Claude Code 会把当前目录当成工作区。**建议在项目根目录启动**。
3. **首次会话**：进入交互式对话界面。

> 提示：登录信息会保存在 `~/.claude/` 或 `~/.anthropic/` 下，之后无需重复登录。

### 1.6 常用配置

进入 Claude Code 后，输入 `/help` 查看所有斜杠命令。以下是最常用的几个：

| 命令 | 作用 |
|------|------|
| `/help` | 查看帮助 |
| `/model` | 切换使用的 Claude 模型（如 Sonnet / Opus / Haiku） |
| `/config` | 打开配置菜单 |
| `/mcp` | 管理 MCP 服务（外部工具） |
| `/cost` | 查看本次会话消耗的 token 和费用 |
| `/clear` | 清空当前上下文，重新开始一段对话 |
| `/exit` | 退出 |

**推荐初始配置**：

- 默认模型选 `sonnet`（速度 / 智力平衡好）；复杂任务再切 `opus`。
- 在项目根目录放一个 `CLAUDE.md`（或 `AGENTS.md`），写清楚项目结构、编码规范、常用命令，Claude 会自动读取。

**`CLAUDE.md` 示例**：

```markdown
# 项目说明（给 Claude 看的）

- 本项目是一个 Python + FastAPI 的博客后端。
- 依赖用 uv 管理，命令：`uv sync`。
- 启动开发服务：`uv run uvicorn app.main:app --reload`。
- 测试：`uv run pytest`。
- 代码风格：ruff + black，Python 3.12+。

## 目录结构
- app/          业务代码
- tests/        测试
- migrations/   数据库迁移

## 编码规范
- 所有函数必须有类型注解。
- 每个 API 变动都要更新 tests/。
- 中文注释可用，但 API 文档统一用英文。
```

### 1.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `command not found: claude` | npm 全局路径没进 PATH。`npm config get prefix` 后把 `<prefix>/bin` 加入 PATH |
| 登录卡住 / 打不开浏览器 | 用 API Key 模式登录，或在能开浏览器机器登录后把 `~/.claude/` 拷过来 |
| API Key 被截图分享 | 严重安全事故，立即到 Anthropic Console 吊销并重新生成 |
| 网络不通 Anthropic | 用班级公共代理或 OpenRouter 网关（进阶） |
| 每次都要重新登录 | 保存的 `~/.claude/` 目录被删除或权限不对，检查文件系统 |

### 1.8 练习/思考

1. 完成 Claude Code 的安装与登录，`claude --version` 输出版本号。
2. 在 `~/study/` 下一个已有项目根写一份 `CLAUDE.md`（≥ 20 行），涵盖项目简介、依赖、启动命令、编码规范。
3. 查阅官网文档，写 200 字回答"Claude Code 与 Codex CLI 有哪些主要差异？"

---

## 第 2 讲：Claude Code 简单入门使用（上）——熟悉项目 / 写脚本 / 修 Bug / 写文档

### 2.1 三种交互模式

```bash
# 交互式（默认）
claude

# 一次性命令
claude -p "帮我总结一下 README.md"

# 无头 / 脚本模式（进阶）
# 可以把 claude 嵌入自己的 bash / python 脚本中做自动化
```

### 2.2 一句话交任务模板

给 Claude 交任务的高质量套路：

```
【目标】XXX
【约束】不依赖第三方库 / 支持中文 UTF-8 / 兼容 Python 3.10+
【验收】写完自己跑一遍示例，展示输出
```

还有一个万能"**先扫再动**"口令，用来防止 Claude 冒进乱改文件：

```
请先扫描一下当前目录，总结项目结构、主要文件用途和你注意到的问题。
再告诉我你打算怎么做，我确认后你再动手。
```

### 2.3 实战 1：让 Claude 熟悉你的项目

新建一个空目录，或用第 2 章的 `~/study/`：

```bash
cd ~/study
claude
```

第一句话通常是：

```
请扫描一下当前目录，总结项目结构、主要文件用途和你注意到的问题。
```

Claude 会用它的工具（`ls`、`cat`、`grep` 等）阅读你的项目，然后输出总结。

### 2.4 实战 2：让 Claude 写一个小脚本

**任务**：写一个 Python 脚本，把 CSV 文件转成 Markdown 表格。

```
写一个 Python 脚本 csv2md.py，接收一个 CSV 文件路径作为参数，
输出一份 Markdown 格式的表格到 stdout。
要求：
1. 用 Python 标准库 csv 模块，不依赖第三方库。
2. 支持中文，UTF-8。
3. 表头自动生成，列宽自适应。
4. 写完后用一个示例 CSV 文件验证一下。
```

Claude 会：

1. 先在你目录下创建 `csv2md.py`；
2. 创建一个示例 `demo.csv`；
3. 执行 `python3 csv2md.py demo.csv`；
4. 展示输出并总结。

如果你不满意，可以直接说："请把宽度对齐做得更好看" 或 "遇到含逗号的字段要正确处理"，Claude 会改。

### 2.5 实战 3：读代码、改 Bug

假如你有一段 Python 代码抛异常：

```
我运行 python3 main.py 报错：
Traceback (most recent call last):
  File "main.py", line 10, in <module>
    total = sum(x for x in items)
TypeError: unsupported operand type(s) for +: 'int' and 'str'

请分析原因，并修改代码。修改后请把 main.py 的完整内容展示给我看。
```

Claude 会自己 `cat main.py`、分析、修改、可能还会加个 try/except 或类型转换。

### 2.6 实战 4：写文档 / README

```
请为当前项目生成一份完整的 README.md，包含：
- 项目简介
- 依赖与安装
- 快速开始
- 目录结构
- 常用命令
- License

风格参考 Vercel 官方 README，简洁明快。写完后直接保存到 README.md。
```

### 2.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Claude 上来就大规模改文件 | 用"先扫再动"口令；每次让它先说方案再动手 |
| 一次性把 10 个需求全塞过去 | 拆开，每个任务清晰、可验证 |
| 生成代码但不跑测试 | 强制要求"写完立刻用示例验证并展示输出" |
| Traceback 只贴半截 | Claude 猜不到根因，把**完整**报错栈贴过去 |
| README 千篇一律 | 给"风格参考"（如 Vercel、React 官方 README）会明显更好 |

### 2.8 练习/思考

1. 让 Claude 帮你写一个"猜数字"命令行小游戏（Python）。
2. 让 Claude 把 Day02 的 `morning.sh` 重构成 Python 版本，并写 3 条 pytest。
3. 找一个你自己写的旧脚本，让 Claude"扫一遍并指出 3 个可以优化的点"，实施后前后对比。

---

## 第 3 讲：Claude Code 简单入门使用（下）——测试 / Git / MCP / 综合项目 / 最佳实践

### 3.1 实战 5：跑测试 / 修测试

```
请运行 pytest，看看测试结果。如果有失败的测试，请分析原因并尝试修复，
不要修改测试用例本身（除非测试用例明显写错了），修完再跑一次直到全绿。
```

Claude 会自主循环：跑测试 → 看输出 → 分析 → 改代码 → 再跑 → 直到全绿。

### 3.2 实战 6：让 Claude 用 git

```
请把当前的修改提交到一个新分支 feature/csv2md，
commit message 用 Conventional Commits 格式，中文正文英文标题。
```

Claude 会自己执行：

```bash
git checkout -b feature/csv2md
git add .
git commit -m "feat: add csv to markdown converter

添加 csv2md.py 脚本，支持 UTF-8 中文与逗号转义。"
```

### 3.3 安全与权限：Claude 会问你要不要执行

Claude Code 默认对"有副作用"的操作（写文件、执行命令）会**弹出确认提示**，你有三个选项：

- **Yes**：只允许这一次；
- **Yes, always for this command**：以后同类命令自动允许；
- **No**：拒绝，让 Claude 改用别的办法。

#### 3.3.1 四档权限模式（超重要）：Ask / Auto-Accept / Plan / Bypass

Claude Code 在会话内可以**按 Shift+Tab 循环切换四种权限档位**，屏幕底部会显示当前档位。这是 Claude Code 最核心的工作范式，请务必记住：

| 档位 | 状态标识 | 行为 | 何时用 |
|---|---|---|---|
| **① Ask（默认）** | 无特殊标识 | 每次危险操作都停下来问你 | 陌生代码库、生产环境、第一次让它做某类任务 |
| **② Auto-Accept** | `⏵⏵ auto-accept edits on` | 自动同意所有编辑与常规命令 | 你已经了解意图、想让它连续跑完一整段流水线 |
| **③ Plan** | `⏸ plan mode on` | **只读**：Claude 只出规划、不做任何写操作 | 想让它先"想清楚方案"，你审后再动手 |
| **④ Bypass** | `⚡ bypass permissions on`（红色警告） | 跳过一切确认，直接执行 | **仅**沙盒（Docker 容器 / WSL 隔离目录），首次进入会强制你打 `y` 确认接受风险 |

**推荐工作流**：先按 `Shift+Tab` 进 Plan 模式让它出方案 → 看方案 OK 后按 `Shift+Tab` 切到 Auto-Accept → 让它把方案一次性执行完。Bypass 只在**一次性、可丢弃、无副作用外泄**的沙盒里用。

**等价 CLI 参数**：启动时加 `--permission-mode plan` / `auto-accept` / `bypassPermissions`（老名 `--dangerously-skip-permissions` 仍可用，功能等同 Bypass 档）。**⚠️ 生产环境永远不要用 Bypass**。

**如何判断哪些操作能选 Always allow？**

- 读文件（`cat` / `grep` / `find`）：可以 Always；
- 跑测试 / 编译 / lint：可以 Always；
- 写文件（新建 / 修改）：慎重，看目录范围；
- `rm` / `curl 未知 URL` / `sudo`：**每次单独确认**。

#### 3.3.2 常用斜杠命令（Slash Commands）

在会话内输入以 `/` 开头的命令，是 Claude Code 内置的"元操作"入口。**必学 6 条**：

| 命令 | 作用 |
|---|---|
| `/init` | **首次进项目**必跑，让 Claude 扫描仓库并生成 `CLAUDE.md`（长期上下文文件） |
| `/compact` | 上下文太长时压缩历史，保留要点，防止爆 token |
| `/clear` | 清空当前对话（保留 `CLAUDE.md`） |
| `/review` | 让 Claude 复盘刚才做的改动（给出优缺点、遗漏） |
| `/cost` | 查看本次会话累计消耗的 Token / 美元 |
| `/help` | 查看所有可用斜杠命令 |

### 3.4 让 Claude 用工具：MCP 简介

**MCP（Model Context Protocol）** 是一种"给 AI 装外挂"的协议，让 Claude 能调用外部工具，比如：

- **文件系统**（默认已具备）
- **GitHub**（读 issue、开 PR）
- **数据库**（查询 MySQL / Postgres）
- **浏览器**（自动化 UI 操作）
- **搜索引擎**

添加一个 MCP 服务的通用方式：

```bash
# 例：给 Claude Code 添加 GitHub MCP
claude mcp add github --command "npx" --args "@modelcontextprotocol/server-github"
```

或在 `~/.claude/config.json` 里配置。**入门阶段先用好文件系统 + 命令行工具即可**，MCP 是进阶话题。

### 3.5 一个综合小项目：用 Claude Code 从零搭一个静态博客

**任务**：在 `~/study/blog` 目录，让 Claude 用 **Astro** 或 **Hugo** 搭一个静态博客，写一篇 "Hello World" 文章，本地跑起来。

给 Claude 的提示词：

```
我想在当前目录搭一个静态博客网站，用 Astro（更现代，有 SSR 能力）。
步骤：
1. 用 npm create astro@latest 生成项目，选择最小模板，TypeScript strict。
2. 生成后在 src/content/blog/ 下创建 hello-world.md，包含标题、日期、正文。
3. 修改首页展示这篇文章的入口。
4. 跑 npm run dev，验证 http://localhost:4321 能访问。
5. 全部完成后，简要说明目录结构和后续维护方式。
```

Claude 会一步步执行，你只需在关键处按 Enter 确认。

### 3.6 使用心得与最佳实践

1. **给足上下文**：一次说清目标、约束、验收标准，比来回追问效率高得多。
2. **让 Claude 先看再动手**："先扫一下项目结构告诉我你的理解，我确认后再动手。"
3. **善用 `/clear`**：每完成一个独立任务清一次上下文，避免"回话污染"。
4. **保留 `CLAUDE.md`**：越是长期维护的项目，越受益于一份项目说明书。
5. **验证是硬要求**：让 Claude 每次改完都跑一次编译 / 测试 / lint，闭环。
6. **不迷信输出**：AI 生成的代码要 code review。

### 3.7 常见错误与解决

| 现象 | 原因 / 建议 |
|---|---|
| `command not found: claude` | npm 全局路径没进 PATH。运行 `npm config get prefix`，把 `<prefix>/bin` 加入 PATH。 |
| 登录卡住 / 打不开浏览器 | 用 API Key 模式登录，或在能开浏览器的机器登录一次，把 `~/.claude/` 拷过来。 |
| 频繁触发权限确认烦 | 用 `/config` 把常用工具设为 "always allow"，或用 `--dangerously-skip-permissions`（沙盒里）。 |
| 输出太长被截断 | 让 Claude "把结果写入文件 X 而不是直接输出"。 |
| 费用飙升 | `/cost` 查看用量；日常任务用 Sonnet；只在必要时用 Opus。 |
| 网络不通 | 检查代理；国内直连 Anthropic 可能不稳，需要代理或走网关。 |

### 3.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 一路 `--dangerously-skip-permissions` | 只能在 Docker 容器 / WSL 隔离目录里用，生产环境永远不要 |
| 让 Claude 直接推 `main` 分支 | 强制"开新分支 + Conventional Commits" |
| MCP 装了一堆用不上 | 入门阶段用好文件系统 + 命令行工具即可，别贪多 |
| 测试跑不通 Claude 就改测试用例 | 提示词里加"不要修改测试用例本身" |

### 3.9 练习/思考

1. 完成第 5 章 5.3 节的"三步作业"：Claude 写猜数字 → 写 5 条 pytest → 生成 README.md。
2. 给你的项目写 `CLAUDE.md`，再开一次会话验证 Claude 是否明显更贴合你的风格。
3. **进阶**：跟 Claude 一起完成一次真实场景任务——给一个 GitHub 开源项目提一个改动（哪怕只是拼写错误），包括 fork / 修改 / 跑测试 / 开 PR。
4. **挑战**：给 Claude 加一个 MCP（GitHub / 文件系统之外任选一个），写文档记录添加过程和用途。

---

## 第 4 讲：Hermes Agent 是什么 + 安装与初始配置

### 4.1 Hermes Agent 是什么

**Hermes Agent** 是 Nous Research 出品的**通用型 AI 智能体 CLI**（Command Line AI Agent）。与 Claude Code 相比，它的定位更"通用"：

- **不绑定单一模型厂商**：可以配置 OpenRouter、Anthropic、OpenAI、Google、xAI、DeepSeek、自建 vLLM 等任意后端；
- **工具箱丰富**：内置终端、文件、Web 浏览、桌面控制（Computer Use）、跨会话记忆、技能（Skills）、定时任务（Cron）、多智能体协作等；
- **面向"全场景生产力"**：不只写代码，也能收发邮件、发 Telegram、控制智能家居、订阅博客、跑爬虫；
- **多平台 Gateway**：一份配置把 Hermes 接到 **Telegram / Discord / Slack / WhatsApp / Signal / SMS** 上，把手机变成 AI 遥控器；
- **开源可扩展**：写自己的 skill、plugin、custom provider 都很容易。

一句话：**Claude Code 是"AI 编程助手"，Hermes Agent 是"AI 个人助理 / 数字员工"**。两者可以并用。

### 4.2 核心概念一览

```mermaid
flowchart TB
    U["用户"] -->|"自然语言指令"| A["Hermes Agent"]
    A -->|"选择合适的工具"| T1["终端 terminal"]
    A --> T2["文件 read_file / write_file / patch"]
    A --> T3["Web browser_navigate / web_search"]
    A --> T4["桌面 computer_use"]
    A --> T5["记忆 memory / session_search"]
    A --> T6["技能 skills"]
    A --> T7["定时 cron"]
    A --> T8["委派 delegate_task"]
    A -->|"多步执行 + 校验"| U
```

| 概念 | 一句话说明 |
|------|-----------|
| **Provider（模型服务商）** | 你使用哪家 API：openrouter / anthropic / openai / xai / 自建 |
| **Model** | 具体的模型：如 `claude-sonnet-4`、`gpt-5`、`deepseek-chat` |
| **Tool（工具）** | Agent 可以调用的能力：终端、文件、浏览器、桌面… |
| **Skill（技能）** | 可复用的"任务操作指南"（Markdown 说明书），命中场景时自动加载 |
| **Memory（记忆）** | 跨会话的个人偏好和环境事实 |
| **Cron（定时任务）** | 让 Agent 按计划自动执行 |
| **Delegate（委派）** | 让主 Agent 派发若干子 Agent 并行做子任务 |
| **Profile（配置档）** | 一套独立的配置（models / skills / memories），可以按工作场景切换 |

### 4.3 前置条件

- **操作系统**：Linux / macOS / Windows（Windows 强烈建议 WSL 2）；
- **Python 3.10+** 或用官方一键安装脚本；
- 至少 1 个 AI 模型的 API Key（OpenRouter 一个 Key 就能访问几乎所有主流模型，推荐初学者用）。

### 4.4 安装

Hermes Agent 提供多种安装方式，最新最全的安装说明始终以 **官方文档 `https://hermes-agent.nousresearch.com/docs`** 为准。以下是最常见的两种：

**方式一：官方一键脚本（推荐）**

```bash
# macOS / Linux / WSL
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
```

**方式二：pipx / pip 安装（如果偏好 Python 生态）**

```bash
# 用 pipx（干净、隔离，推荐）
python3 -m pip install --user pipx
python3 -m pipx ensurepath

pipx install hermes-agent

# 或直接用 pip
pip install --user hermes-agent
```

装完后：

```bash
hermes --version
```

> **提示**：若命令找不到，检查 `~/.local/bin` 是否在 PATH 中（`echo $PATH`），或按脚本提示重启 shell。

### 4.5 首次运行与配置向导

```bash
hermes setup
```

`hermes setup` 会带你走一遍**首次配置向导**，主要问三件事：

1. **选择默认 Provider**：openrouter / anthropic / openai / 其他。**初学者推荐 openrouter**：一个 API Key 通吃几十个模型。
2. **填入 API Key**：到你选的 Provider 官网生成，粘贴到向导里。
3. **选择默认 Model**：如 `anthropic/claude-sonnet-4`、`openai/gpt-5`、`deepseek/deepseek-chat`。

配置文件默认存在 `~/.hermes/config.yaml`，之后可以随时用命令行修改：

```bash
# 查看当前配置
hermes config show

# 修改默认模型
hermes config set model.provider openrouter
hermes config set model.default anthropic/claude-sonnet-4

# 查看所有可用工具
hermes tools

# 列出已安装技能
hermes skills list
```

### 4.6 关键目录结构

```
~/.hermes/
├── config.yaml           # 全局配置
├── memories/             # 跨会话记忆
├── skills/               # 你自己的技能
├── plugins/              # 你的插件
├── profiles/             # 其他 profile
│   └── work/             # 例如：工作 profile
├── cron/                 # 定时任务定义
└── sessions.db           # 会话历史（SQLite）
```

### 4.7 启动第一次会话

```bash
hermes
```

进入交互式界面，第一句可以是：

```
你好，请介绍一下你自己，你能做什么？我该如何最有效地使用你？
```

Hermes 会用中文回答（如果你配置了中文偏好），并让你了解它的能力边界。

### 4.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `command not found: hermes` | `~/.local/bin` 不在 PATH，`pipx ensurepath` 后重启终端 |
| OpenRouter 注册需要国际信用卡 | 国内学生可用 DeepSeek：`hermes config set model.provider deepseek` |
| API Key 泄露 | 立即到 Provider 控制台吊销并重新生成 |
| 配置文件手动改错 YAML 语法 | 用 `hermes config show` 检查，或删掉重跑 `hermes setup` |

### 4.9 练习/思考

1. 完成 Hermes Agent 安装、`hermes setup`、`hermes --version` 输出版本号。
2. `hermes tools` 输出所有工具，抽 5 个自己觉得有趣的写 100 字用途预测（下节验证）。
3. 查阅官方文档 `https://hermes-agent.nousresearch.com/docs`，写 200 字回答"Hermes 与 Claude Code 各自的差异化优势是什么？"

---

## 第 5 讲：Hermes Agent 简单入门使用（上）——记忆 / 代码 / Web / Computer Use

### 5.1 交互式 vs 一次性命令

```bash
# 交互式（默认）
hermes

# 一次性命令
hermes "总结当前目录下所有 .md 文件的核心要点"

# 从管道输入
cat error.log | hermes "分析这份日志，指出根因和修复建议"
```

### 5.2 实战 1：让 Hermes 熟悉你

```
请通过 memory 工具记住以下事实：
1. 我叫小明，大二学生，正在学 Python 和 Web 开发；
2. 我的偏好：回复用中文，代码简洁风格；
3. 我的操作系统：Windows 11 + WSL 2 Ubuntu 26.04；
4. 我常用的项目路径：~/study/。

保存好后简要复述你记住的内容。
```

Hermes 会调用 `memory` 工具，写入 `~/.hermes/memories/`。**下次开新会话，这些事实会自动注入上下文**，让 Hermes 一开口就对你了如指掌。

### 5.3 实战 2：让 Hermes 干活（代码 / 文件）

```
在 ~/study/py/ 目录下：
1. 建一个新的 Python 项目 word-counter；
2. 写一个脚本：读取 txt 文件，输出词频前 10；
3. 顺手写 3 个 pytest 单元测试；
4. 全部搞定后跑一次测试给我看，最后总结所做的工作。
```

Hermes 会用 `terminal`、`write_file`、`read_file` 等一系列工具完成整个流程，中途遇到需要确认的地方会问你。

### 5.4 实战 3：让 Hermes 上网

Hermes 内置浏览器工具（`browser_navigate`、`web_search` 等），可以：

```
帮我在网上查一下 Python 3.13 相比 3.12 有哪些新特性。
用 web_search 找 3 篇高质量文章，读完后:
1. 输出 5 条核心变化（每条一句话）；
2. 给我一个从 3.12 迁移到 3.13 的注意事项清单；
3. 附上参考链接。
```

或让它去具体网站抓信息：

```
打开 https://ollama.com/library ，列出当前 top 10 的模型名称和大小。
```

### 5.5 实战 4：让 Hermes 操控你的桌面（Computer Use）

Hermes 支持 **Computer Use**：在后台用截图 + 点击 + 键盘操作驱动你的桌面**而不打断你**。适合场景：

- "帮我打开浏览器搜一下 XX"
- "去 Notion 里给我建一个页面标题叫 XX"
- "把飞书里最新的一封邮件截图给我"

首次使用需要开权限：

```bash
hermes computer-use doctor    # 健康检查，会告诉你缺什么权限
```

按提示开启 macOS / Windows 的辅助功能权限，然后：

```
用 computer_use 工具帮我打开 Firefox，
然后访问 https://arxiv.org/list/cs.AI/new ，
把首页前 5 篇论文的标题告诉我。
```

Hermes 会用一个"影子光标"完成操作，不抢你的键鼠焦点。

### 5.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 新开会话 memory 没生效 | 确认真的写入了 `~/.hermes/memories/`；或用 `hermes memory` 查看 |
| `memory` 里塞了太多临时状态 | 只放"稳定偏好"，不放"今天吃了火锅"这类瞬时信息 |
| Computer Use 完全没反应 | 跑 `hermes computer-use doctor`，按提示开权限 |
| `web_search` 返回不了新结果 | 换关键词 / 让 Hermes 用 `browser_navigate` 直接访问网页 |
| Hermes 抓取大网页超时 | 让它"只取标题和链接，不下载全文" |

### 5.7 练习/思考

1. 让 Hermes 用 `memory` 记住你的 5 条个人偏好（姓名、身份、常用系统、常用语言、回复风格），新开一个会话验证是否自动生效。
2. 让 Hermes 完成一次"代码 + 测试 + 提交"闭环：任意小项目，写代码、写测试、跑通、`git commit`。
3. **进阶**：让 Hermes 用 `web_search` 收集"你关心的技术话题" 3 篇文章并输出结构化摘要。
4. **挑战**：跑 `hermes computer-use doctor` 通过检查，让 Hermes 帮你打开一个网页并在后台完成一次简单操作。

---

## 第 6 讲：Hermes Agent 简单入门使用（下）——Cron / Delegate / Skills / 综合项目 + 结课

### 6.1 实战 5：让 Hermes 定时干活（Cron）

假设你想每天早 8 点收到一份"今日 AI 新闻摘要"：

```
帮我创建一个定时任务：
- 每天早上 8:00 执行；
- 内容：抓取 hackernews 上"AI"相关的 Top 10 帖子，摘要成中文并按重要性排序；
- 结果发送到我的 Telegram（如果没接入就存到 ~/daily-ai-brief/YYYY-MM-DD.md）。
```

Hermes 会调用 `cronjob` 工具创建任务，存在 `~/.hermes/cron/`。查看：

```bash
hermes cron list                # 列出所有任务及运行状态
hermes cron status              # 查看 cron 调度器是否在运行
```

#### 6.1.1 端到端：把 Hermes 接到 Telegram（推荐第一个 Gateway）

`hermes cron` 的结果默认落到本地目录/文件；如果想在**手机**上收到消息、且可以**在手机上直接和 Hermes 对话**，最简单的方式是接 Telegram。整个流程只有 4 步：

```bash
# 第一步：在 Telegram 里找 @BotFather → /newbot → 起名字 →
#         BotFather 会返回一串 token，形如：123456789:AAE...

# 第二步：把 token 交给 Hermes（交互式向导会问你选哪个平台、粘贴 token）
hermes gateway setup

# 第三步：把 Gateway 装成后台常驻服务并启动
hermes gateway install     # 一次性安装为 systemd/launchd 服务
hermes gateway start       # 启动
hermes gateway status      # 确认运行状态

# 第四步：在 Telegram 里给你自己的 bot 发一条 "hi" ——
#   Hermes 会在后台自动响应；cron 任务的结果也会自动推送到你与 bot 的对话里
```

调整前面创建的 Cron：

```
把上面的每日 AI 新闻任务改成 deliver=telegram，
以后每天早 8 点直接在 Telegram 收到摘要。
```

日常运维命令：

```bash
hermes gateway restart     # 改了配置后重启
hermes gateway stop        # 停止服务
tail -f ~/.hermes/logs/gateway.log   # 排错必看
```

> Hermes 的 Gateway 还支持 **Discord / Slack / WhatsApp / iMessage / Signal / Matrix / SMS / 飞书 / 钉钉 / 企业微信** 等 20+ 平台——配置方式相同，都是 `hermes gateway setup` 里选目标平台，然后 `install` + `start`。

### 6.2 实战 6：让 Hermes 委派子任务（Delegate）

对于"多个独立子任务"，主 Agent 可以派发若干子 Agent 并行做：

```
请调用 delegate_task 并行执行 3 个子任务：
1. 研究 vLLM 的架构；
2. 研究 sglang 的架构；
3. 研究 TGI 的架构。
每个子任务产出一份 300 字的摘要，最后主 Agent 汇总一份对比表给我。
```

子 Agent 会各自完成，只有最终摘要回到主上下文，**节省 token、不污染主对话**。

### 6.3 技能（Skills）：Hermes 的"操作手册库"

Hermes 内置了大量 Skill（`hermes skills list` 查看），比如：

- `github-pr-workflow`：GitHub PR 生命周期规范
- `test-driven-development`：TDD 强制流程
- `youtube-content`：YouTube 视频转脚本 / 摘要 / 博文
- `google-workspace`：Gmail / Calendar / Sheets 操作
- `obsidian`：读写 Obsidian 笔记
- `chinese-knowledge-base`：写结构化中文知识库

**Skill 会在场景匹配时自动加载**，也可以主动让 Hermes 加载：

```
请加载 chinese-knowledge-base 技能，然后按它的规范帮我写一份
"高等数学极限概念"的中文知识库（≥ 3000 字），保存到 ~/study/notes/limits.md。
```

**创建自己的 Skill**：

```
请帮我创建一个 skill 叫 daily-standup，
内容包括：每天早上让 AI 问我 5 个问题（昨天做了什么 / 今天做什么 / 卡壳 / 心情 / 明天可用时间）
并保存到 ~/standup/YYYY-MM-DD.md。
```

Hermes 会用 `skill_manage` 工具在 `~/.hermes/skills/` 下创建对应目录。

### 6.4 常用 CLI 命令速查

```bash
# 会话
hermes                          # 启动新会话
hermes -c                       # 恢复上次会话（--continue 缩写）
hermes --resume <session_id>    # 恢复指定会话
# 会话内输入 /new 也可重开一个新会话

# 配置
hermes config show              # 查看当前配置
hermes config edit              # 用编辑器打开 config.yaml
hermes config set <key> <value> # 修改单个键
hermes setup                    # 交互式配置向导

# 工具、技能、模型
hermes tools                    # 列出所有工具
hermes skills list              # 列出已安装技能
hermes model                    # 交互式切换 Provider / 模型
hermes auth list                # 查看已配置的凭证池

# Cron
hermes cron list                # 列出所有任务
hermes cron status              # 检查调度器是否在运行
hermes cron remove <job_id>     # 删除任务

# 记忆
hermes memory status            # 查看外部记忆插件状态
hermes memory setup             # 首次配置外部记忆
hermes memory off               # 禁用外部记忆（保留内置 MEMORY.md）

# Profile（多套配置切换）
hermes profile list
hermes profile use work         # 切换到名为 work 的 profile
```

### 6.5 与 Claude Code 对比

| 维度 | Claude Code | Hermes Agent |
|------|-------------|--------------|
| 定位 | AI 编程助手 | 通用 AI 智能体 |
| Provider | 仅 Anthropic | 任意（OpenRouter / OpenAI / Anthropic / 自建…） |
| 工具广度 | 侧重编码 | 编码 + 浏览器 + 桌面 + 邮件 + 定时任务… |
| 定制性 | 中（CLAUDE.md、MCP） | 高（Skills、Plugins、Profiles、自建 Provider） |
| 学习曲线 | 低 | 中 |
| 典型用户 | 开发者 | 开发者 + 知识工作者 + 极客 |

**建议做法**：编码任务优先 Claude Code；日常自动化 / 跨场景任务 Hermes Agent。两者可以互补使用。

### 6.6 综合项目：让 Hermes 帮你搭一个"个人 AI 工作台"

**任务清单**（花 30—60 分钟完成）：

1. `memory` 里保存你的基本偏好（姓名、身份、常用目录、语言、代码风格）。
2. 创建一个 skill `weekly-review`：让 Hermes 每周日 21:00 主动问你"本周三件成功事 / 三件失败事 / 下周三件目标"，写入 `~/reviews/YYYY-Www.md`。
3. 创建一个 cron 任务：每天 9:00 抓取一份天气 + 你订阅的 RSS 摘要，输出到 `~/daily-brief/`。
4. 建一个 `~/study/notes` 目录，用 `obsidian` skill（或 markdown）把本课程的 6 章要点整理进去。
5. 与 Hermes 一起做一次"跨天知识回看"：让它读第一章记住的关键概念，出 20 道混合题（选择 + 简答）测试你。

### 6.7 常见错误与解决

| 现象 | 原因 / 建议 |
|---|---|
| `command not found: hermes` | 检查 PATH 是否含 `~/.local/bin`；重启终端。 |
| `Invalid API Key` | `hermes config set` 重新填 Key；确认 Provider 匹配。 |
| 模型返回慢 / 超时 | 换 Provider（OpenRouter 通常最稳）；或切换更小的模型。 |
| Computer Use 不生效 | `hermes computer-use doctor`；开系统辅助功能权限。 |
| Cron 任务没触发 | `hermes cron list` 看状态；WSL / macOS 需保持 Hermes daemon 运行。 |
| Skill 没自动加载 | 描述任务时命中关键词更明确；或显式 "请加载 XX skill"。 |
| 费用担心 | 主 model 用便宜的（DeepSeek / Sonnet）；`config set` 里限制 delegate 数量。 |

### 6.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Cron 设完就撒手 | Cron 需要 daemon 后台运行，WSL 关机就不跑；重要任务建议部署云服务器 |
| Delegate 派了 3 个但耗时反而更长 | Delegate 只在"独立可并行子任务"下有优势，链式任务不用 |
| Skill 写得像故事而不是清单 | Skill 是给 AI 看的"操作手册"，要清单化、命令化，不要文学化 |
| 一个 Provider 用崩了没退路 | 配好 2 个以上 Provider 作 fallback；OpenRouter 本身就是聚合器，最稳 |

### 6.9 结课语

到这里，《AI 生产力赋能》课程 6 大章、18 课时的内容全部结束了。

回顾一下我们走过的路：

- **Day01 第 1 章**：建立 **AI 时代的世界观**；
- **Day01 第 2 章**：掌握**日常 AI 生产力工具**；
- **Day02 第 3 章**：拥有一个 **Linux 环境**；
- **Day02 第 4 章**：拥有一个 **Docker 环境**；
- **Day03 第 5 章**：拥有一个 **AI 编程助手 Claude Code**；
- **Day03 第 6 章**：拥有一个 **AI 智能体 Hermes Agent**。

这只是入门。真正的**赋能**不来自看完这份教程，而来自**未来 3—6 个月你用 AI 完成的每一件小事**。祝你在 AI 时代成为"放大器人格"——用 AI 把自己的能力放大 10 倍。

### 6.10 练习/思考（本课程收官作业）

1. 完成 Hermes Agent 的安装、`hermes setup` 配置，`hermes --version` 输出版本号。
2. 让 Hermes 用 `memory` 记住你的 5 条个人偏好，新开一个会话验证是否自动生效。
3. 用 Hermes 完成一次"代码 + 测试 + 提交"闭环：任意小项目，写代码、写测试、跑通、`git commit`。
4. 创建一个每天定时执行的 cron 任务（如"每天 22:00 让我用 3 句话总结今天做了什么，写入 `~/diary/YYYY-MM-DD.md`"）。
5. 从 `hermes skills list` 里挑一个感兴趣的技能加载并试用（推荐 `youtube-content` / `arxiv` / `obsidian`）。
6. **进阶**：写一个自己的 Skill（哪怕 20 行），比如 `daily-english-flashcard`——每天让 Hermes 从你不熟悉的 300 个单词里抽 10 个出题。
7. **反思题**：对比 Claude Code 与 Hermes Agent，在你自己的学习 / 工作流中，各自最适合承担什么角色？
8. **课程总结**：写一份 500 字以上的课程总结——3 天 6 章你的最大收获、感觉最有用的 3 个工具、最想深入的 1 个方向。

---

