# 《AI 生产力赋能》 - 教师教案（Day02：Linux 初体验 + Docker 初体验）

**总课时：6 课时 × 45 分钟**
**授课对象：AI 初学者（大一/大二本科生、非计算机专业亦可）**
**知识点覆盖：** 第 3 章 Linux 初体验 + 第 4 章 Docker 初体验

---

## 第 1 课时：Linux 概述 + WSL 2 安装 Ubuntu

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能说出 Linux 是什么（内核 + 发行版），并列举 6 个主流发行版及其面向场景；
2. 能说出学 Linux 的 4 个理由（服务器全跑 Linux / 开发工具原生支持 / AI 工具首选 / 命令行思维）；
3. 掌握 Windows 上体验 Linux 的 3 种方式并知道各自的取舍；
4. **动手完成 WSL 2 + Ubuntu 26.04 的安装**，能用 `lsb_release -a` 和 `uname -a` 查看系统信息。

#### 1.1.2 过程与方法目标
1. 通过一张 Mermaid 决策图，让学生自己判断该选 WSL 2 / 虚拟机 / 双系统；
2. 通过"密码不显示 = 不是卡了"等细节讲解，训练"读文档 + 冷静判断"的心态。

### 1.2 教学重难点
- **重点**：Ubuntu 定位／`wsl --install` 一条命令／首次登录密码不回显／`WslRegisterDistribution failed` 的原因
- **难点**：BIOS 里开启 VT-x/AMD-V 虚拟化的操作因主板而异，需示范找主板型号→查官网教程

### 1.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
问全班："**手上用 Windows 的举手 / 用 Mac 的举手 / 用 Linux 的举手？**" 然后引出："**服务器 90%+ 是 Linux，但你的开发机是 Windows/Mac，怎么办？** 今天教你零成本拥有一台 Linux。"

#### 新知讲授（15 分钟）
1. **Linux 是什么**（4 分钟）：内核（1991 Linus Torvalds）+ 发行版。投影表格：

| 发行版 | 特点 | 主要面向 |
|---|---|---|
| Ubuntu | 最流行，社区活跃 | 初学者、开发者、云服务器 |
| Debian | 稳如老狗 | 服务器 |
| CentOS Stream / Rocky / Alma | RHEL 系 | 企业服务器 |
| Fedora | 前沿新技术 | 开发者 |
| Arch | 极简、DIY | 极客 |
| Alpine | 5MB，容器友好 | Docker 镜像 |

**统一使用 Ubuntu 26.04 LTS**（Resolute Wombat，2026-04 发布）。命令与 24.04 LTS 通用；学生若手头只有 24.04 镜像，替换版本号即可。

2. **为什么学 Linux**（3 分钟）：4 条——服务器全跑 Linux；开发工具（Docker/Git/Node/Python）原生支持；AI 工具（Claude Code/Hermes Agent）首选 Linux/macOS；命令行思维效率指数级提升。

3. **三种体验方式**（8 分钟）：投影 Mermaid 决策图。
   - **WSL 2**：Windows 10/11 原生支持，5 分钟装好，共存无冲突（本课程推荐）；
   - **虚拟机**（VMware/VirtualBox）：完整 Linux 桌面，占资源；
   - **双系统**：性能最好，需要重启切换。

#### 示例演示（15 分钟）
**现场操作** WSL 2 安装（教师投影 PowerShell 窗口）：

1. 管理员身份打开 PowerShell（开始菜单搜 "PowerShell" → 右键 → "以管理员身份运行"）；

2. 执行：
```powershell
# 默认安装 WSL 2 + Ubuntu
wsl --install

# 或指定发行版
wsl --install -d Ubuntu-26.04
```

3. **重启电脑**（讲解为什么必须重启：内核组件生效）；

4. 开始菜单打开 "Ubuntu" → 设置用户名和密码：
```
Enter new UNIX username: your_name
New password: ******
Retype new password: ******
```
**输入密码时屏幕不显示任何字符，这是 Linux 的安全设计，不是卡了。**

5. 检查安装：
```bash
# 查看系统版本
lsb_release -a

# 查看内核
uname -a
```

**常见问题现场答疑**：
- `WslRegisterDistribution failed` → 一般是 Windows 版本太旧或没开虚拟化，去 BIOS 里开启 VT-x / AMD-V；
- 想删掉重装：PowerShell 执行 `wsl --unregister Ubuntu-26.04`；
- 设默认版本为 WSL 2：`wsl --set-default-version 2`。

#### 课堂练习（8 分钟）
所有同学**同步操作**：
1. 打开 PowerShell 管理员，执行 `wsl --install`；
2. 已经装过的同学，执行 `wsl -l -v` 查看状态；
3. 装完的同学，尝试用 `pwd` 和 `whoami` 打印当前目录与用户名。

教师巡视，重点帮遇到 `WslRegisterDistribution failed` 的同学处理。

#### 小结（3 分钟）
今天最重要的一步：**在 Windows 上有了一个 Linux**。下一课时开始学 20+ 常用命令。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  1. Linux 概述 + WSL 2                       │
├──────────────────────────────────────────────┤
│  Linux = 内核 + 发行版                       │
│  统一使用：Ubuntu 26.04 LTS                  │
│                                              │
│  3 种方式：                                  │
│   (1)WSL 2  推荐                             │
│   (2)VMware/VirtualBox                       │
│   (3)双系统                                  │
│                                              │
│  WSL 2 三步走：                              │
│   (1)管理员 PowerShell                       │
│   (2)wsl --install                           │
│   (3)重启 → 设用户名密码                     │
│                                              │
│  ⚠ 密码不回显 ≠ 卡了                         │
│  ⚠ 报错 → 去 BIOS 开虚拟化                   │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 WSL 2 + Ubuntu 26.04 的安装，截图 `lsb_release -a` 与 `whoami` 输出。
2. **必做**：查询你的电脑主板型号，写下"如何进入 BIOS + 如何开启虚拟化"的步骤（150 字以内）。
3. **挑战题**：装完 WSL 后，尝试执行 `wsl --set-default-version 2`，若原本装的是 WSL 1 转成 WSL 2 并解释区别。

### 1.6 教学反思提示
- WSL 安装环节最容易出的两个问题：Windows 版本太旧 + 未开虚拟化。上课前应提前调查学生的 Windows 版本，让老版本同学提前升级或改用虚拟机。
- 有一部分学生的电脑是学校统一采购机型，BIOS 设置密码，需要提前联系机房管理员。

---

## 第 2 课时：Linux 常用命令（上）——文件/查看/搜索/权限

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 熟练使用目录与文件操作：`pwd` / `ls` / `cd` / `mkdir` / `touch` / `cp` / `mv` / `rm`；
2. 熟练使用查看文件内容：`cat` / `less` / `head` / `tail -f`；
3. 熟练使用搜索与管道：`grep` / `find` / `|`（pipe）；
4. 理解并使用权限：`ls -l` 看权限、`chmod +x` / `chmod 755` 改权限、`sudo` 提权。

#### 2.1.2 过程与方法目标
1. 通过"敲一遍所有命令"的方式建立肌肉记忆；
2. 通过 `rm -rf` 危险性讲解，建立"每次执行 rm 前看两遍路径"的习惯。

### 2.2 教学重难点
- **重点**：`ls -la` / `cd -` / `mkdir -p` / `grep -r` / `find -name` / `chmod 755` 的常用组合
- **难点**：Linux 权限位 `rwx` ↔ 数字 `421` 的换算；管道 `|` 的工作原理

### 2.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**Linux 的核心是记得住的少量高频命令 + 会查手册**"。今天要动手敲 20+ 个命令，全部**在 WSL 里敲一遍**。

#### 新知讲授（18 分钟）
1. **目录与文件操作**（7 分钟）：
```bash
pwd                     # 打印当前目录
ls / ls -l / ls -la / ls -lh
cd /home / cd ~ / cd .. / cd -
mkdir myproject
mkdir -p a/b/c          # -p 递归创建
touch hello.txt
cp source.txt dest.txt
cp -r src_dir dst_dir
mv old.txt new.txt      # 重命名/移动
rm file.txt
rm -rf some_dir         # ⚠ 危险！
```
**⚠️ `rm -rf` 的危险性**：Linux 没有回收站，`rm -rf /` 会把整个系统删光。**养成每次执行前看两遍路径**。

2. **查看文件内容**（3 分钟）：
```bash
cat hello.txt
less big_file.log       # q 退出，空格翻页
head -n 20 file.log
tail -n 20 file.log
tail -f /var/log/syslog # 实时追踪日志
```

3. **搜索与管道**（4 分钟）：
```bash
grep "error" app.log
grep -i "error" app.log         # 忽略大小写
grep -r "TODO" ./src            # 递归

find . -name "*.md"
find /home -type d -name ".git"

ls -l | grep "^d"               # 只显示目录
history | grep git              # 历史命令找 git
```
管道 `|` 的核心：**上一个命令的输出交给下一个命令**。

4. **权限**（4 分钟）：
```bash
ls -l script.sh                 # 看权限：-rwxr-xr-x
chmod +x script.sh              # 加执行权限
chmod 755 script.sh             # 数字模式：rwxr-xr-x

sudo apt update                 # 提权执行
whoami
```
权限位换算：`r=4 w=2 x=1`，三位分别代表 **owner/group/others**：`755 = rwx r-x r-x`。

#### 示例演示（12 分钟）
现场演示"**建立一个个人学习目录并搜索内容**"闭环：

```bash
cd ~                            # 进 home
mkdir -p study/{ai,linux,docker,notes}
cd study/notes
touch day1.md
echo "# Day1" > day1.md
echo "- WSL 2 装好" >> day1.md
echo "- lsb_release -a" >> day1.md

cat day1.md
ls -la ..

find ~ -name "*.md" | head -5

grep -r "WSL" ~/study
```

再演示 `chmod`：
```bash
touch script.sh
ls -l script.sh                 # -rw-r--r--
chmod +x script.sh
ls -l script.sh                 # -rwxr-xr-x
```

#### 课堂练习（10 分钟）
学生同步操作：
1. 在 home 目录用 **1 条 `mkdir -p`** 创建如下结构：
```
~/study/
├── ai/
├── linux/
├── docker/
└── notes/
    └── day1.md
```
2. 用 `tree ~/study`（若没装先跳过）或 `ls -R ~/study` 展示结构；
3. 在 `~/study/notes/day1.md` 里写下今日学到的 5 个 Linux 命令；
4. 用 `grep -r "cd" ~/study/notes` 搜索包含 cd 的行。

#### 小结（2 分钟）
上半课时是"操作 + 查看 + 搜索"，下半课时（第 3 课时）是"网络 + 进程 + 包管理 + 编辑器 + 工具安装"。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  2. Linux 常用命令（上）                     │
├──────────────────────────────────────────────┤
│  目录：pwd  ls  cd  mkdir -p  touch          │
│  文件：cp  cp -r  mv  rm  rm -rf             │
│  查看：cat  less  head  tail -f              │
│  搜索：grep -i -r  find -name                │
│  管道：|                                     │
│                                              │
│  权限：ls -l → -rwxr-xr-x                    │
│         chmod +x / chmod 755                 │
│         sudo（root 提权）                    │
│  换算：r=4  w=2  x=1                         │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：在 `~/study/` 下每敲一个新命令就在 `notes/day1.md` 里记一句心得，交至少 10 条。
2. **必做**：写一段说明——"如果我不小心敲了 `rm -rf ~/`，会发生什么？下次怎么避免？"
3. **挑战题**：用 `find + grep` 组合，查出 `~/` 下所有含关键词 "hello" 的 `.md` 文件路径。

### 2.6 教学反思提示
- 学生最容易忘的两个是 `cd -`（回上一次目录）和 `mkdir -p`（递归建），下一节课要考核抽查。
- 权限位的换算部分可以给出"7 = 111（二进制）"的图解，视觉化理解。

---

## 第 3 课时：Linux 常用命令（下）+ 工具安装 + 综合脚本

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 熟练使用网络与进程：`ip a` / `ping` / `curl` / `wget` / `ps` / `top` / `kill`；
2. 熟练使用包管理：`sudo apt update / upgrade / install / remove`；
3. 掌握命令行进阶：`Ctrl + R` 交互式搜索历史 / 重定向 `>` `>>` / 组合 `&&` `;`；
4. 会用 `nano` 或 `vim` 编辑文件；
5. 掌握"一条命令装齐开发工具"（git/curl/wget/build-essential/tree/htop/jq/vim/nano）；
6. 完成 Git、Node.js（nvm）、Python + venv、uv（可选）的安装与配置；
7. **动手完成"每日启动脚本 morning.sh"**：能显示时间/用户/系统负载/磁盘/待办。

#### 3.1.2 过程与方法目标
1. 通过"一条命令装齐"感受包管理的力量；
2. 通过写一个真实脚本，把"命令 → 脚本 → 可执行程序"打通。

### 3.2 教学重难点
- **重点**：`apt update` 与 `apt upgrade` 的区别；`Ctrl+R` 搜历史；nvm 安装 Node LTS；shebang `#!/bin/bash`
- **难点**：vim 的模式切换（`i` 插入 / `Esc` 命令 / `:wq` 保存退出）；`export NVM_DIR` 的 shell 环境变量概念

### 3.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**上一课时你会用 Linux 走路，这一课时给你装辅助装备。**"引出：一条 apt install 命令 = 装齐 10 个开发工具。

#### 新知讲授（18 分钟）
1. **网络与进程**（5 分钟）：
```bash
ip addr / ip a
ping -c 4 baidu.com
curl -O https://example.com/file.zip
wget https://example.com/file.zip
ps aux | grep node
top                             # q 退出
htop                            # 更友好
kill 12345
kill -9 12345                   # 强制杀
```

2. **包管理 apt**（4 分钟）：
```bash
sudo apt update                 # 更新索引
sudo apt upgrade -y             # 升级已装软件
apt search htop                 # 搜索
sudo apt install -y htop tree curl wget git
sudo apt remove htop
sudo apt purge htop             # 连配置一起删
```
`update` ≠ `upgrade`：一个是"看看有啥新版本"，一个是"真的升级"。

3. **进阶技巧**（4 分钟）：
```bash
history / !123 / Ctrl+R         # 历史
Ctrl+C / Ctrl+D / Ctrl+L
Ctrl+A / Ctrl+E / Tab
echo "hello" > out.txt          # 覆盖
echo "world" >> out.txt         # 追加
mkdir foo && cd foo             # && 前一个成功才执行
apt update ; apt upgrade        # ; 无论前一个如何都执行
```
**重点强调 `Ctrl+R`**——交互式搜索历史，是命令行效率的分水岭。

**tmux 多会话**（口述 2 分钟，示例演示环节现场敲）：以后同时跑 Claude Code / 测试 / 日志 / SSH 会很常见，`tmux` 让一个终端里横向管理多个会话：
```bash
sudo apt install -y tmux
tmux new -s work                # 新建名为 work 的会话
# Ctrl+B → % 竖分屏 / " 横分屏 / o 切窗格 / d 挂起
# 挂起后重连：tmux attach -t work
tmux ls
```
关键点：**关掉终端后 tmux 里的进程照常跑**——SSH 服务器远程开发的必备工具。Day03 让 Claude Code 并行多 Agent 时也会用到。

4. **编辑器**（3 分钟）：
```bash
# nano（推荐初学者）
nano hello.txt
# Ctrl+O 保存 → 回车 → Ctrl+X 退出

# vim（程序员标配）
vim hello.txt
# 按 i 进入插入模式 → 编辑 → Esc → :wq 保存并退出
# :q! 不保存强制退出
```

5. **工具安装**（2 分钟，示例演示带过）：
```bash
sudo apt update
sudo apt install -y \
    git curl wget \
    build-essential \
    tree htop \
    unzip zip \
    vim nano \
    jq
```

#### 示例演示（15 分钟）
现场演示，学生同步敲：

1. **Git 安装与配置**（3 分钟）：
```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git config --global color.ui auto
git config --list
```

**⭐ SSH Key 生成 + GitHub 配置**（3 分钟，Day03 clone/push 私仓时必须要）：
```bash
# 1) 生成 ed25519 密钥（比 RSA 更短更安全）
ssh-keygen -t ed25519 -C "you@example.com"
# 一路回车（不设 passphrase 简单些）
cat ~/.ssh/id_ed25519.pub
# 2) 复制上面输出的公钥，登录 github.com → Settings → SSH and GPG keys →
#    New SSH key → 粘贴 → Add SSH key
# 3) 验证
ssh -T git@github.com
# 首次会问 yes/no，回答 yes；成功会返回 "Hi <你的用户名>! You've successfully authenticated"
```
**板书**：`ed25519 → 添加到 GitHub → ssh -T 验证 → 成功后 clone/push 免密`。

2. **Node.js 用 nvm 安装**（4 分钟）：
```bash
NVM_LATEST=$(curl -s https://api.github.com/repos/nvm-sh/nvm/releases/latest | grep tag_name | cut -d '"' -f 4)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/${NVM_LATEST}/install.sh | bash

export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

nvm install --lts
nvm use --lts
node -v
npm -v
```

3. **Python + venv**（3 分钟）：
```bash
sudo apt install -y python3 python3-pip python3-venv
python3 --version
pip3 --version

python3 -m venv .venv
source .venv/bin/activate
pip install requests
deactivate
```

4. **写一个 morning.sh**（5 分钟）：
```bash
nano ~/morning.sh
```
写入：
```bash
#!/bin/bash
# 每日启动脚本
echo "===== $(date '+%Y-%m-%d %H:%M:%S') ====="
echo "欢迎回来，$(whoami)！"

echo ""
echo "→ 系统负载："
uptime

echo ""
echo "→ 磁盘使用："
df -h | grep -E "^/dev"

echo ""
echo "→ 今日待办（TODO.md 内容）："
cat ~/TODO.md 2>/dev/null || echo "(尚未创建 ~/TODO.md)"

echo ""
echo "祝你有个高效的一天！"
```
保存退出后：
```bash
chmod +x ~/morning.sh
~/morning.sh
```

#### 课堂练习（7 分钟）
1. 用 `apt` 安装 `htop`、`tree`、`jq`；各跑一次基础命令；
2. 输出 `node -v` 和 `python3 --version` 版本号；
3. 编写 `~/hello.sh`：接收一个人名参数，输出 `Hello, XXX! 现在是 YYYY-MM-DD HH:MM:SS`。
   提示：`$1` 是第一个参数，`date '+%Y-%m-%d %H:%M:%S'` 是格式化日期。

#### 小结（2 分钟）
今天下午我们进入 Docker——**"把软件和它的运行环境一起打包"**，从此告别"我这里能跑"。

### 3.4 板书设计
```
┌────────────────────────────────────────────────┐
│  3. 常用命令（下）+ 工具安装                   │
├────────────────────────────────────────────────┤
│  网络：ip a  ping  curl -O  wget               │
│  进程：ps aux  top  htop  kill (-9)            │
│  包：  apt update / upgrade / install / remove │
│  进阶：Ctrl+R  >  >>  &&  ;                    │
│  编辑：nano（Ctrl+O/X） / vim（i/Esc/:wq）     │
│                                                │
│  开发环境栈：                                  │
│   Git（user.name / user.email）                │
│   Node.js（nvm install --lts）                 │
│   Python + venv                                │
│   uv（可选，Rust 写的极速包管理）              │
│                                                │
│  综合脚本：morning.sh                          │
│   #!/bin/bash                                  │
│   → 时间 用户 负载 磁盘 待办                   │
└────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成 Git、Node.js LTS、Python 3、jq、htop、tree 全部安装，把 `--version` 输出粘到 `~/study/notes/day2.md`。
2. **必做**：把 `morning.sh` 加到你的 `~/.bashrc` 末尾（`~/morning.sh`），每次打开终端自动跑一遍。
3. **挑战题**：安装 uv（`curl -LsSf https://astral.sh/uv/install.sh | sh`），用 `uv init myproj && uv add requests && uv run main.py` 走一遍新版 Python 包管理流程。
4. **挑战题**：装 Oh My Zsh，感受插件与主题的差异。

### 3.6 教学反思提示
- nvm 安装脚本因为 raw.githubusercontent.com 可能不通，需要提前告知学生备用镜像或走 GitHub 代理。
- vim 部分对初学者压力较大，建议在示例演示中让学生只学"打开 - 按 i - 编辑 - Esc - :wq"这最小闭环，其他放到后续自学。

---

## 第 4 课时：Docker 介绍——镜像 / 容器 / 仓库 / 与虚拟机的区别

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能用"打包软件和运行环境"一句话解释 Docker；
2. 能说出 3 个核心概念：**镜像（Image）/ 容器（Container）/ 仓库（Registry）** 及各自类比；
3. 能画出 Docker 与虚拟机的架构对比图并说清 3 项差异（启动速度/资源占用/隔离层次）；
4. 能列举 5 类 Docker 典型使用场景（开发环境/应用交付/CI-CD/微服务/AI 模型部署）。

#### 4.1.2 过程与方法目标
1. 通过"过去 vs 现在"的场景对比，理解 Docker 解决的痛点（"我这里能跑"）；
2. 通过 Mermaid 架构图，建立"共享内核 vs 每个 VM 一个 Guest OS"的直观差异。

### 4.2 教学重难点
- **重点**：**镜像 = 光盘 / 容器 = 光盘启动的电脑 / 仓库 = 应用商店** 的类比
- **难点**：容器共享宿主机内核 vs 虚拟机 Hypervisor 隔离层的区别；镜像标签 `名称:标签`（如 `mysql:8.4`）的语义

### 4.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
提问："**你有没有帮同学 debug 过'我这里能跑，你那里不能跑'的问题？**" 引出 Docker 的核心价值——把环境打包，走到哪都一样。

举例：过去装 MySQL 要下载安装包 → 装依赖 → 改配置 → 建用户，每台机器都不一样。现在：**`docker run mysql:8.4`，30 秒就有一个可用的 MySQL**，无论你的机器是 Windows / Mac / Ubuntu / CentOS。

#### 新知讲授（20 分钟）
1. **三个核心概念**（10 分钟）：投影 Mermaid 图。

```mermaid
flowchart LR
    A["Docker Hub / 镜像仓库<br/>(存放镜像)"] -->|"docker pull"| B["镜像 Image<br/>(只读模板，如 mysql:8.4)"]
    B -->|"docker run"| C["容器 Container<br/>(镜像的运行实例)"]
    C -->|"docker commit / build"| B
```

投影表格逐行讲：

| 概念 | 类比 | 说明 |
|---|---|---|
| **镜像（Image）** | 光盘 / 模板 | 只读，包含应用 + 运行环境。名字通常是 `名称:标签`，如 `mysql:8.4`、`ubuntu:26.04`。 |
| **容器（Container）** | 光盘启动出来的一台电脑 | 镜像的运行实例，可启停删。同一个镜像可创建 N 个容器。 |
| **仓库（Registry）** | 应用商店 | 存放镜像的地方。官方 = **Docker Hub**（`hub.docker.com`），国内可用镜像加速器。 |

2. **Docker vs 虚拟机**（10 分钟）：投影架构图对比。

```mermaid
flowchart TB
    subgraph VM["虚拟机（VM）"]
        V1["Guest OS 1<br/>App 1"]
        V2["Guest OS 2<br/>App 2"]
        H["Hypervisor"]
        HOS["Host OS"]
        HW1["硬件"]
        V1 --- H
        V2 --- H
        H --- HOS
        HOS --- HW1
    end

    subgraph DK["Docker 容器"]
        C1["App 1"]
        C2["App 2"]
        D["Docker Engine"]
        HOS2["Host OS（内核共享）"]
        HW2["硬件"]
        C1 --- D
        C2 --- D
        D --- HOS2
        HOS2 --- HW2
    end
```

- **虚拟机**：每个 VM 都有完整 Guest OS，启动慢（分钟级），资源占用大（几 GB / 个）；
- **容器**：共享宿主机内核，启动快（秒级），资源占用小（几十 MB / 个），**一台机器可跑几十上百个容器**。

#### 示例演示（10 分钟）
现场投影 `hub.docker.com`，搜索 `mysql`、`nginx`、`redis`，让学生看到"镜像仓库长啥样"、"tag（版本标签）如何选"。

打开 `https://ollama.com/library` 演示"AI 模型也是这样发布的"——一个个模型都是一个个镜像。

用一张图说"典型使用场景"：

| 场景 | 例子 |
|---|---|
| 开发环境 | 一条命令跑 MySQL / Redis / MongoDB / Elasticsearch |
| 应用交付 | 把自己应用打包镜像，交付到任何机器都一样 |
| CI/CD | GitHub Actions / GitLab CI 大量用容器 |
| 微服务 | 一服务一容器 + Docker Compose / K8s 编排 |
| AI 模型部署 | Ollama 本地跑大模型，vLLM 部署推理服务 |

#### 课堂练习（8 分钟）
1. 用**自己的话**在纸上画一张"镜像 / 容器 / 仓库"的关系图（3 分钟）；
2. 抽 2 位同学到黑板画，教师纠偏（5 分钟）。

#### 小结（4 分钟）
今天讲完概念，下一课时**动手装 Docker**。装完后**下一课时就能 `docker run mysql:8.4` 跑起 MySQL**。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  4. Docker 介绍                              │
├──────────────────────────────────────────────┤
│  一句话：把软件 + 运行环境一起打包           │
│                                              │
│  三大核心：                                  │
│   仓库 Registry（应用商店）                  │
│   ↓ docker pull                              │
│   镜像 Image（光盘/模板，如 mysql:8.4）      │
│   ↓ docker run                               │
│   容器 Container（一台电脑）                 │
│                                              │
│  Docker vs VM：                              │
│   VM：每个都有 Guest OS，几 GB/分钟级        │
│   Docker：共享内核，几十 MB/秒级             │
│                                              │
│  5 大场景：                                  │
│   开发环境 / 应用交付 / CI-CD /              │
│   微服务 / AI 模型部署                       │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：用自己的话（300 字以内）向不懂技术的家人解释 Docker，可用类比。
2. **必做**：登录 Docker Hub，找出下列镜像的最新 stable tag：`mysql`、`nginx`、`redis`、`postgres`。
3. **挑战题**：查资料写一段 200 字回答："Docker 用的是 Linux 内核的哪些底层特性来实现容器隔离？"（提示：cgroups / namespaces）

### 4.6 教学反思提示
- 类比讲得越多学生越有感，但要避免"光盘"这个类比让学生误以为镜像"只能读、不能修改"——补充"用 Dockerfile 或 docker commit 可以基于镜像做新镜像"。
- 若学生问"容器安全吗"，可以引出下一课时"数据卷"，为持久化做铺垫。

---

## 第 5 课时：Docker 安装 + 国内镜像加速

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 能根据自己的操作系统选择合适的 Docker 安装方式（Docker Desktop / Docker Engine）；
2. 完成 Docker Desktop（Windows/macOS）或 Docker Engine（Ubuntu/WSL 内部）的安装；
3. `docker run hello-world` 成功输出，`docker version` 打印客户端 + 服务端版本；
4. 完成"当前用户免 sudo 使用 docker" 的配置（`sudo usermod -aG docker $USER`）；
5. 配置国内镜像加速器（阿里云 / 中科大 / DaoCloud / 网易 / 百度）。

#### 5.1.2 过程与方法目标
1. 通过"WSL 里的 Ubuntu 装 Docker Engine"完整走一遍，体验 apt 加软件源 + 安装 + 启动 + 免 sudo + 测试的标准五步流程；
2. 通过配置镜像加速前后对比，直观感受"国内网络到 Docker Hub 的痛点"。

### 5.2 教学重难点
- **重点**：Docker Desktop vs Docker Engine 的取舍；`docker run hello-world` 成功输出；镜像加速器 daemon.json
- **难点**：`sudo usermod -aG docker $USER` 加组后需 `newgrp docker` 或**退出终端重开**；WSL 里 systemd 是否启用（新版 WSL 已默认支持 `systemctl`）

### 5.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**上一节课讲了原理，这一节课**——**咱们真装一个 Docker，让镜像跑起来**。"

#### 新知讲授（8 分钟）
三种安装方式对比：

| 场景 | 推荐方式 |
|---|---|
| Windows + WSL 2 | **Docker Desktop for Windows**（图形界面，最省心） |
| macOS | Docker Desktop for Mac |
| 纯 Linux 服务器 / WSL 2 内部 | 直接装 **Docker Engine**（无图形） |

**本课程推荐**：Windows 学生用 Docker Desktop（勾选 "Use WSL 2 based engine"）；服务器用 Docker Engine。

#### 示例演示（26 分钟）
**演示 A：Docker Desktop 安装**（5 分钟，投影）
1. 打开 `https://www.docker.com/products/docker-desktop/`；
2. Windows 双击安装包 → 勾 "Use WSL 2 based engine" → 一路下一步；
3. 启动 Docker Desktop → 等右下角托盘图标变绿色鲸鱼；
4. PowerShell 或 WSL 里：
```bash
docker --version
docker info
```

**演示 B：Ubuntu/WSL 内部装 Docker Engine**（15 分钟，学生同步操作）：

```bash
# 卸载可能的旧版本
sudo apt remove -y docker docker-engine docker.io containerd runc 2>/dev/null

# 安装依赖
sudo apt update
sudo apt install -y ca-certificates curl gnupg lsb-release

# 添加 Docker 官方 GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
    sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# 添加 Docker 软件源
echo "deb [arch=$(dpkg --print-architecture) \
    signed-by=/etc/apt/keyrings/docker.gpg] \
    https://download.docker.com/linux/ubuntu \
    $(lsb_release -cs) stable" | \
    sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 安装
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io \
    docker-buildx-plugin docker-compose-plugin

# 启动 & 开机自启
sudo systemctl enable docker
sudo systemctl start docker

# 让当前用户免 sudo 使用 docker
sudo usermod -aG docker $USER
newgrp docker

# 验证
docker version
docker run hello-world
```

**关键讲解点**：
- `install -m 0755 -d /etc/apt/keyrings`：创建目录并设权限；
- `gpg --dearmor`：把 armored key 转为二进制 key，是 apt 新签名机制的要求；
- `lsb_release -cs`：取当前 Ubuntu 代号（如 `resolute`）；
- `usermod -aG docker $USER`：把当前用户加进 docker 组，之后不用 sudo；
- **⚠️ 加组后必须 `newgrp docker` 或者重开终端**才生效。

**演示 C：国内镜像加速**（6 分钟）：
```bash
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.baidubce.com"
  ]
}
EOF

sudo systemctl daemon-reload
sudo systemctl restart docker
```
Docker Desktop 用户：设置 → Docker Engine → 改 JSON。

配置前后对比：现场演示 `docker pull nginx` 拉取速度差异。

#### 课堂练习（5 分钟）
> ⚠️ 装 Docker 本身 5–10 分钟起步，**装完整流程放到课后作业**（见 5.5）。课堂 5 分钟只做**已经装好后的第一步验证**：
学生独立完成（教师现场巡视）：
1. `docker version` 能输出 Client + Server 两段版本号（说明服务已起）；
2. `docker run hello-world` 看到 "Hello from Docker!"；
3. 打开 `/etc/docker/daemon.json` 确认镜像加速器已配置。

> 没装完的同学：把课堂时间用来跟做教师演示的 5 步骤，装 Docker 与配加速留到课后完成。

#### 小结（3 分钟）
下一课时用它跑起一个真实的 MySQL，走完"部署 → 连接测试 → 数据持久化"完整链路。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  5. Docker 安装                              │
├──────────────────────────────────────────────┤
│  两条路：                                    │
│   (1)Docker Desktop（Win/Mac，图形）         │
│   (2)Docker Engine（Linux/WSL，纯 CLI）      │
│                                              │
│  Engine 五步：                               │
│   (1)卸旧 + 装依赖                           │
│   (2)加 GPG key                              │
│   (3)加 apt 软件源                           │
│   (4)apt install -y docker-ce…               │
│   (5)enable + start + usermod -aG            │
│                                              │
│  加组后必须 newgrp docker / 重开终端         │
│                                              │
│  国内加速：/etc/docker/daemon.json           │
│   ustc / 163 / baidu                         │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 Docker 安装 + hello-world 通过 + 至少 1 个镜像加速器配置。截图 `docker version` 和 `docker info` 输出。
2. **必做**：写 100 字对比"Docker Desktop 和 Docker Engine 的差异，你为什么选它？"
3. **挑战题**：查资料整理 5 个国内常用的公共镜像加速器地址，测试各自拉取速度并排序。

### 5.6 教学反思提示
- Docker Desktop 需要开 WSL 2 支持才能正常工作；有些学生的 Windows 家庭版早期不支持，需引导升级到 Pro/Home 最新版。
- 若课堂时间紧，可以只演示 Docker Engine 一条路，Docker Desktop 让学生课后按官网自学。

---

## 第 6 课时：Docker 快速入门——部署 MySQL 并进行连接测试

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 熟练使用镜像操作：`docker pull` / `docker images` / `docker rmi`；
2. 熟练使用容器生命周期：`docker ps` / `ps -a` / `start` / `stop` / `restart` / `rm(-f)` / `logs -f` / `exec -it`；
3. 用一条 `docker run` 启动 MySQL 8.4 容器，包含：`-d`、`--name`、`-p`、`-e`（环境变量）、`-v`（数据卷）、`--restart` 参数；
4. 3 种连接方式验证：容器内 `mysql` 客户端 / 宿主机 GUI 客户端（DBeaver）/ 宿主机命令行 `mysql-client`；
5. 用 `docker-compose.yml` 一次拉起 MySQL + phpMyAdmin，掌握 `up -d` / `ps` / `logs -f` / `down`。

#### 6.1.2 过程与方法目标
1. 通过"逐参数拆解 docker run"训练"读长命令"的能力；
2. 通过验证"删掉容器数据仍在"，直观理解数据卷的价值。

### 6.2 教学重难点
- **重点**：`docker run` 完整长命令的每个参数含义／`docker exec -it mysql-demo mysql -u root -p`／`docker-compose.yml` 5 大块（services / image / ports / environment / volumes）
- **难点**：为什么 `-v mysql_data:/var/lib/mysql` 能让数据不丢；phpMyAdmin 通过 `PMA_HOST: mysql` 是怎么找到 mysql 容器的（Docker 网络与服务名解析）

### 6.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**上一课时装完 Docker，今天真跑一个 MySQL 出来。**目标：45 分钟里，你要做完部署、连接、写表、备份、删除、Compose 一整套。"

#### 新知讲授（10 分钟）
1. **Docker 命令速查**（5 分钟）：投影表格 + 现场敲。

```bash
# 镜像
docker pull mysql:8.4
docker images
docker rmi <image_id>

# 容器
docker ps                       # 运行中
docker ps -a                    # 所有（含停止）
docker start / stop / restart <container>
docker rm <container>           # 需先停止
docker rm -f <container>        # 强制
docker logs -f <container>      # 跟随日志
docker exec -it <container> bash  # 进容器 shell

# 系统
docker system df
docker system prune -f
```

2. **`docker run` 参数总览**（5 分钟）：把 MySQL 命令拆开讲。

```bash
docker run -d \
  --name mysql-demo \
  -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=root123 \
  -e MYSQL_DATABASE=demo \
  -v mysql_data:/var/lib/mysql \
  --restart unless-stopped \
  mysql:8.4
```

| 参数 | 含义 |
|---|---|
| `-d` | detached，后台运行 |
| `--name mysql-demo` | 起名字 |
| `-p 3306:3306` | 宿主机 3306 → 容器 3306 |
| `-e MYSQL_ROOT_PASSWORD=root123` | 环境变量：root 密码 |
| `-e MYSQL_DATABASE=demo` | 启动时自动建 demo 库 |
| `-v mysql_data:/var/lib/mysql` | 数据卷持久化 |
| `--restart unless-stopped` | Docker 重启后自动拉起 |
| `mysql:8.4` | 镜像名:标签 |

#### 示例演示（22 分钟）
**演示 A：启动 MySQL 容器 + 验证**（5 分钟）：
```bash
docker run -d --name mysql-demo -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=root123 -e MYSQL_DATABASE=demo \
  -v mysql_data:/var/lib/mysql --restart unless-stopped mysql:8.4

docker ps
docker logs -f mysql-demo       # Ctrl+C 退出跟随
# 看到 "ready for connections" 即启动完成
```

**演示 B：容器内连接 + 写 SQL**（5 分钟）：
```bash
docker exec -it mysql-demo mysql -u root -p
# 输入密码：root123
```
进入 SQL 后：
```sql
SHOW DATABASES;
USE demo;
CREATE TABLE student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    score INT
);
INSERT INTO student (name, score) VALUES
    ('张三', 92),
    ('李四', 85),
    ('王五', 78);
SELECT * FROM student;
EXIT;
```

**演示 C：验证数据持久化**（3 分钟）：
```bash
docker stop mysql-demo
docker start mysql-demo
# 再进去 SELECT * FROM student; 数据仍在
```

**演示 D：Docker Compose 一次拉起 MySQL + phpMyAdmin**（9 分钟）：

**前置知识：Docker 自定义网络（容器互访的正确姿势）**（板书 1 分钟）：Compose 会自动为项目建一个 bridge 网络，把服务名映射为 DNS 名字。手写 `docker run` 时可以：
```bash
docker network create appnet
docker run -d --name mysql --network appnet -e MYSQL_ROOT_PASSWORD=root123 mysql:8.4
docker run -d --name pma  --network appnet -e PMA_HOST=mysql -p 8080:80 phpmyadmin
# 因为在同一网络，pma 可用容器名 "mysql" 直接访问 → 不用暴露 3306 端口
```
默认 `bridge` 网络不做名字解析，**必须自定义网络才能容器名互解**——这是学生最常踩的坑。

```bash
mkdir -p ~/study/docker/mysql
cd ~/study/docker/mysql
nano docker-compose.yml
```
写入：
```yaml
services:
  mysql:
    image: mysql:8.4
    container_name: mysql-demo
    restart: unless-stopped
    ports:
      - "3306:3306"
    environment:
      MYSQL_ROOT_PASSWORD: root123
      MYSQL_DATABASE: demo
    volumes:
      - mysql_data:/var/lib/mysql

  phpmyadmin:
    image: phpmyadmin:latest
    container_name: pma
    restart: unless-stopped
    ports:
      - "8080:80"
    environment:
      PMA_HOST: mysql
      PMA_PORT: 3306
    depends_on:
      - mysql

volumes:
  mysql_data:
```
先删掉之前的：`docker rm -f mysql-demo`。
再启动：
```bash
docker compose up -d
docker compose ps
docker compose logs -f
docker compose down
```
浏览器打开 `http://localhost:8080`，`root / root123` 登录。

**⚠️ Compose 亮点**：`PMA_HOST: mysql` 中的 `mysql` 是**同一 Compose 项目里其他服务的名字**，Docker 会自动做 DNS 解析——**这就是"服务发现"**。

#### 课堂练习（7 分钟）
1. 完成"启动 MySQL → 建 student 表 → 插 5 行 → SELECT" 全流程；
2. 停止容器再启动，验证数据仍在；
3. **进阶**：改端口为 `3307:3306`，用 `mysql -h 127.0.0.1 -P 3307 -u root -p` 连接（模拟本机已装 MySQL 的情况）。

#### 小结（3 分钟）
今日总结：Linux + Docker，你已经**有一台可以放 AI 工具的开发机**了。明天 Day03 我们请出两个 AI 主角——**Claude Code** 和 **Hermes Agent**。

### 6.4 板书设计
```
┌─────────────────────────────────────────────────────┐
│  6. Docker 部署 MySQL                               │
├─────────────────────────────────────────────────────┤
│  docker run 长命令 7 参：                           │
│   -d --name -p -e -v --restart <image>              │
│                                                     │
│  连接 3 方式：                                      │
│   (1)docker exec -it mysql-demo mysql -u root -p    │
│   (2)DBeaver（127.0.0.1:3306 root/root123）         │
│   (3)宿主机 mysql-client                            │
│                                                     │
│  Compose 5 块：                                     │
│   services / image / ports / env / volumes          │
│  一句：docker compose up -d                         │
│                                                     │
│  数据卷 mysql_data 让 rm 也不丢数据                 │
└─────────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成 MySQL 容器部署 + student 表 + 5 行数据插入。用 DBeaver（或任意 GUI）从宿主机连上查询。
2. **必做**：改写为 `docker-compose.yml`，额外加一个 `redis:7.4` 容器，一次 `up -d` 启动。
3. **必做**：`docker stop && docker start`，验证数据仍在，写出说明。
4. **挑战题**：映射一个自定义 `my.cnf`（`-v ./my.cnf:/etc/mysql/conf.d/my.cnf`），把默认字符集改为 `utf8mb4`。
5. **挑战题**：备份 → 删库 → 恢复：`docker exec mysql-demo mysqldump ... > demo_backup.sql` 后 `cat demo_backup.sql | docker exec -i mysql-demo mysql ...`。

### 6.6 教学反思提示
- 3306 端口本机可能已被占用（旧的 MySQL 服务），需提前教学生用 `-p 3307:3306` 换端口，避免"实操 5 分钟绕不出去"。
- Docker Compose 的服务名做 DNS 解析这一点，学生第一次不容易理解，可以用**"公司里叫工号"**的类比：`mysql` 就是服务号，Docker 给它自动配了 DNS。
