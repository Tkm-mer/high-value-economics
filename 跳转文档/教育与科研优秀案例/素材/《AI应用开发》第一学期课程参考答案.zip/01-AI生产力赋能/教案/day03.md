# 《AI 生产力赋能》 - 教师教案（Day03：Claude Code + Hermes Agent 初体验）

**总课时：6 课时 × 45 分钟**
**授课对象：AI 初学者（大一/大二本科生、非计算机专业亦可）**
**知识点覆盖：** 第 5 章 Claude Code 初体验 + 第 6 章 Hermes Agent 初体验

---

## 第 1 课时：Claude Code 是什么 + 安装与初始化

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 说清 Claude Code 的定位：跑在**终端**里、在项目目录里工作、自主执行多步任务的 AI 编程 CLI；
2. 能对比 AI 编程工具 3 种形态：Chat 类 / IDE 插件类 / CLI Agent 类，各自代表产品与差异；
3. 掌握 Claude Code 前置条件（Node.js 18+ / Anthropic 账号或 API Key / 联网 / shell）；
4. 完成 npm 全局安装 `@anthropic-ai/claude-code`、`claude --version` 输出版本号；
5. 完成首次登录（OAuth 或 API Key）、选择工作目录、进入交互式对话；
6. 掌握 6 个常用斜杠命令：`/help`、`/model`、`/config`、`/mcp`、`/cost`、`/clear`、`/exit`。

#### 1.1.2 过程与方法目标
1. 通过对比 3 种工具形态，理解"AI 编程 CLI 是新一代生产力工具"；
2. 通过写 `CLAUDE.md`，理解"给 AI 一份项目说明书"的价值。

### 1.2 教学重难点
- **重点**：Claude Code 定位／npm 全局安装／首次登录 2 种方式（OAuth vs API Key）／`CLAUDE.md` 的作用
- **难点**：无浏览器环境（纯服务器）下如何用 API Key 登录；`sonnet` vs `opus` 的取舍

### 1.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**回想一下：你写代码时怎么用 AI？**" 收集答案（复制粘贴到 ChatGPT？让 Copilot 补全？）。"今天你会见到第三种形态——**AI 直接在你的终端里干活**：它读你的代码、跑你的命令、改你的文件。"

#### 新知讲授（15 分钟）
1. **Claude Code 是什么**（5 分钟）：Anthropic 官方推出的 AI 编程 CLI。4 个特点：
   - 在你项目目录里工作：读代码 / 跑命令 / 改文件；
   - 自主执行多步任务："把项目里所有 print 换成 logger" 它会自己搜索、编辑、验证；
   - 调用工具与 MCP（外部工具：数据库、浏览器、GitHub）；
   - 面向真实开发流程：写脚本、修 bug、重构、写文档、跑测试。

2. **AI 编程工具三形态对比**（4 分钟）：投影 Mermaid 图。

```mermaid
flowchart TB
    A["AI 编程工具三种形态"] --> B["Chat 类<br/>ChatGPT/Claude 网页版<br/>只出主意，代码需要你复制"]
    A --> C["IDE 插件类<br/>Copilot/Cursor<br/>编辑器内补全 + 对话"]
    A --> D["CLI Agent 类<br/>Claude Code/Codex/Hermes Agent<br/>终端里跑，直接改文件、执行命令"]
```

三者差异：**主动权**依次递增；**风险**也依次递增（CLI Agent 能执行命令，需要人来把关）。

3. **前置条件与安装**（6 分钟）：
   - Node.js 18+（Day02 已装好 LTS）
   - Anthropic 账号（`https://console.anthropic.com/`）或 API Key
   - 可访问 Anthropic 的网络
   - 一个 shell（bash / zsh / PowerShell 都行）

安装方式（**2026-07 版本注意**：npm 全局安装已弃用，改推官方 native installer）：

```bash
# 方式一（当前官方推荐）：native installer
curl -fsSL https://claude.ai/install.sh | bash
# Windows PowerShell: irm https://claude.ai/install.ps1 | iex

# 方式二（旧方式，仍可用不推荐）：npm 全局
npm install -g @anthropic-ai/claude-code

# 方式三：一次性运行
npx @anthropic-ai/claude-code

# 已装过 npm 版可一键迁移：
claude migrate-installer
```

安装完毕：
```bash
claude --version
```

#### 示例演示（15 分钟）
现场演示（教师投影）：

1. **安装与验证**（3 分钟）：
```bash
# 官方推荐（native installer；npm 全局装已弃用）
curl -fsSL https://claude.ai/install.sh | bash
claude --version
```

2. **首次登录**（4 分钟）：
```bash
cd ~/study
claude
```
首次启动会：
- 默认打开浏览器登录 Anthropic 账号（OAuth）；
- 若纯服务器无浏览器 → 选"用 API Key 登录"，粘 `sk-ant-xxxxx`；
- 选工作目录（Claude Code 把当前目录当工作区，**建议项目根目录启动**）；
- 进入交互式对话。

登录信息保存在 `~/.claude/` 或 `~/.anthropic/` 下，之后不用重复登录。

3. **斜杠命令**（4 分钟）：
```
/help       # 查看帮助
/model      # 切换 Claude 模型（sonnet / opus / haiku）
/config     # 打开配置菜单
/mcp        # 管理 MCP 服务
/cost       # 查看 token 和费用
/clear      # 清空当前上下文
/exit       # 退出
```

4. **`CLAUDE.md` 项目说明书**（4 分钟）：投影示例：

```markdown
# 项目说明（给 Claude 看的）

- 本项目是一个 Python + FastAPI 的博客后端。
- 依赖用 uv 管理，命令：`uv sync`。
- 启动开发服务：`uv run uvicorn app.main:app --reload`。
- 测试：`uv run pytest`。
- 代码风格：ruff + black，Python 3.12+。

## 目录结构
- app/          业务代码
- tests/        测试
- migrations/   数据库迁移

## 编码规范
- 所有函数必须有类型注解。
- 每个 API 变动都要更新 tests/。
- 中文注释可用，但 API 文档统一用英文。
```

**推荐做法**：默认 `sonnet`（速度/智力平衡）；复杂任务切 `opus`；项目根放一份 `CLAUDE.md`。

#### 课堂练习（8 分钟）
学生同步操作：
1. 完成安装（推荐 `curl -fsSL https://claude.ai/install.sh | bash`；已用 npm 装过的跑 `claude migrate-installer` 迁移）；
2. `claude --version` 输出版本号；
3. 在 `~/study/hello-claude` 目录启动 `claude`，完成登录；
4. 输入 `/help` 看所有命令。

**⚠️ 有 API Key 分发限制的班级**：教师可提供**沙盒共享账号**或让学生用 OpenRouter 走网关（进阶）。

#### 小结（4 分钟）
今天完成"装机启动"，下一课时开始"6 个高频姿势"实战。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  1. Claude Code 安装                         │
├──────────────────────────────────────────────┤
│  定位：AI 编程 CLI                           │
│   跑在终端 + 项目目录 + 自主多步             │
│                                              │
│  3 形态对比：                                │
│   Chat / IDE 插件 / CLI Agent                │
│                                              │
│  安装 3 招：                                 │
│   (1)npm i -g @anthropic-ai/claude-code      │
│   (2)npx @anthropic-ai/claude-code           │
│   (3)官方脚本                                │
│                                              │
│  登录 2 招：                                 │
│   (1)OAuth（浏览器）                         │
│   (2)API Key（sk-ant-…）                     │
│                                              │
│  斜杠命令：/help /model /config /cost        │
│           /clear /exit                       │
│                                              │
│  CLAUDE.md：给 AI 的项目说明书               │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 Claude Code 安装、登录、`claude --version` 输出。
2. **必做**：在你 `~/study/` 下一个已有项目根写一份 `CLAUDE.md`（≥ 20 行），涵盖项目简介、依赖、启动命令、编码规范。
3. **挑战题**：查阅官网文档，写 200 字回答"Claude Code 与 Codex CLI 有哪些主要差异？"

### 1.6 教学反思提示
- API Key 是最容易泄漏的环节，请提前告知学生"不要把 `sk-ant-` 密钥截图分享到微信群"。
- 若学生反映网络不通 Anthropic，可让他们改用 OpenRouter 网关（进阶）或使用班级公共代理。

---

## 第 2 课时：Claude Code 简单入门使用（上）——熟悉项目 / 写脚本 / 修 Bug / 写文档

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 掌握 Claude Code 三种交互模式：交互式（Chat REPL）/ 一次性命令（`claude -p`）/ 无头脚本模式；
2. 能用一句话让 Claude 扫描项目、总结结构；
3. 会让 Claude 写一个"CSV → Markdown 表格"的 Python 小脚本并现场验证；
4. 会用报错信息 + 完整 Traceback 让 Claude 分析并修 Bug；
5. 会让 Claude 生成一份高质量的 `README.md`。

#### 2.1.2 过程与方法目标
1. 通过 4 个真实场景，感受"CLI Agent 的自主执行 + 你的把关"协作模式；
2. 训练"一句话说清目标、约束、验收标准"的表达能力。

### 2.2 教学重难点
- **重点**：一句话交任务的模板：`目标 + 约束 + 验收标准`；把报错完整贴给 AI；`README.md` 的经典结构
- **难点**：让 Claude"先扫再动"避免它上来就改文件；判断 Claude 生成代码的质量

### 2.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"**上一课时把 Claude 装上，今天让它干活。目标：每人体验 4 种高频姿势**。"

#### 新知讲授（8 分钟）
1. **三种交互模式**（3 分钟）：
```bash
# 交互式（默认）
claude

# 一次性命令
claude -p "帮我总结一下 README.md"

# 无头 / 脚本模式（进阶）
# 可以把 claude 嵌入自己的 bash / python 脚本中做自动化
```

2. **一句话交任务模板**（5 分钟）：
```
【目标】XXX
【约束】不依赖第三方库 / 支持中文 UTF-8 / 兼容 Python 3.10+
【验收】写完自己跑一遍示例，展示输出
```

给学生一个"**先扫再动**"的口令：
```
请先扫描一下当前目录，总结项目结构、主要文件用途和你注意到的问题。
再告诉我你打算怎么做，我确认后你再动手。
```

#### 示例演示（22 分钟）
**演示 1：让 Claude 熟悉你的项目**（4 分钟）：
```bash
cd ~/study
claude
```
第一句：
```
请扫描一下当前目录，总结项目结构、主要文件用途和你注意到的问题。
```
Claude 会自主用 `ls`、`cat`、`grep` 等工具阅读你的项目，然后输出总结。

**演示 2：写一个 CSV → Markdown 脚本**（8 分钟）：
```
写一个 Python 脚本 csv2md.py，接收一个 CSV 文件路径作为参数，
输出一份 Markdown 格式的表格到 stdout。
要求：
1. 用 Python 标准库 csv 模块，不依赖第三方库。
2. 支持中文，UTF-8。
3. 表头自动生成，列宽自适应。
4. 写完后用一个示例 CSV 文件验证一下。
```
Claude 会：
1. 创建 `csv2md.py`；
2. 创建示例 `demo.csv`；
3. 执行 `python3 csv2md.py demo.csv`；
4. 展示输出并总结。

如果不满意，直接追问："请把宽度对齐做得更好看" 或 "遇到含逗号的字段要正确处理"。

**演示 3：修 Bug**（5 分钟）：
```
我运行 python3 main.py 报错：
Traceback (most recent call last):
  File "main.py", line 10, in <module>
    total = sum(x for x in items)
TypeError: unsupported operand type(s) for +: 'int' and 'str'

请分析原因，并修改代码。修改后请把 main.py 的完整内容展示给我看。
```
Claude 会自己 `cat main.py`、分析、修改、可能加 try/except 或类型转换。

**演示 4：写文档**（5 分钟）：
```
请为当前项目生成一份完整的 README.md，包含：
- 项目简介
- 依赖与安装
- 快速开始
- 目录结构
- 常用命令
- License

风格参考 Vercel 官方 README，简洁明快。写完后直接保存到 README.md。
```

#### 课堂练习（8 分钟）
每人任选 1 个：
- 让 Claude 帮你写"猜数字"命令行小游戏（Python）；
- 让 Claude 帮你把某段"能跑但很丑"的代码重构（可以先拿 Day02 的 `morning.sh` 让它优化）；
- 让 Claude 给你之前的项目写 `README.md`。

要求："**先扫再动**"→"**给足上下文**"→"**验收要跑**"三步走。

#### 小结（4 分钟）
关键三个"要"：给足上下文、让 Claude 先看再动、每次改完都要验证。下一课时讲测试、Git、MCP、安全权限。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  2. Claude Code 入门（上）                   │
├──────────────────────────────────────────────┤
│  3 种交互：                                  │
│   (1)claude（REPL）                          │
│   (2)claude -p "…"（一次性）                 │
│   (3)无头脚本                                │
│                                              │
│  一句话模板：目标 + 约束 + 验收标准          │
│                                              │
│  4 个高频姿势：                              │
│   (1)熟悉项目：先扫再动                      │
│   (2)写脚本：csv2md.py                       │
│   (3)修 Bug：贴完整 Traceback                │
│   (4)写文档：README.md 六段结构              │
│                                              │
│  ⚠ 每次改完都要验证（跑一遍）                │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成"三步作业"：让 Claude 写猜数字游戏 → 写 5 条 pytest 测试 → 生成 README.md（第 2 步下一课时讲，也可以自己先试）。
2. **必做**：用 Claude 帮你把 Day02 的 `morning.sh` 重构成 Python 版本，并写 3 条 pytest。
3. **挑战题**：找一个你自己写的旧脚本，让 Claude"扫一遍并指出 3 个可以优化的点"，实施后前后对比。

### 2.6 教学反思提示
- 第一次让 Claude 修改文件时学生可能会被"权限确认弹窗"卡住，需现场演示"Yes / Yes always / No"三个选项如何选。
- 有的学生会"一次性把要求全丢过来"，教师需要示范"拆分需求 + 验收标准"的写法。

---

## 第 3 课时：Claude Code 简单入门使用（下）——测试 / Git / MCP / 综合项目 / 最佳实践

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 会用 Claude 运行 pytest、修失败测试、直到全绿；
2. 会让 Claude 用 Git 提交（新分支 + Conventional Commits）；
3. 理解 Claude Code 的**权限确认机制**（Yes / Yes always / No / `--dangerously-skip-permissions`）；
4. 理解 MCP（Model Context Protocol）是什么，会加 GitHub MCP；
5. 会用 Claude Code 从零搭一个 Astro 静态博客的综合项目；
6. 掌握 6 条最佳实践与 6 类常见错误的处理。

#### 3.1.2 过程与方法目标
1. 通过 pytest 全绿闭环，理解"AI 自主执行 + 验证"的价值；
2. 通过 MCP 讲解，建立"AI 可以装外挂"的架构认知。

### 3.2 教学重难点
- **重点**：让 Claude 跑测试 → 修测试 → 直到全绿；`git commit` 由 Claude 代跑；权限 3 选 1
- **难点**：`--dangerously-skip-permissions` 使用边界（只在沙盒容器 / WSL 隔离目录）；MCP 的通用配置模式

### 3.3 教学过程设计（45 分钟）
#### 导入（2 分钟）
"上一课时让 Claude 写代码，这一课时**让 Claude 自我验证 + 自我提交**，闭环。"

#### 新知讲授（10 分钟）
1. **跑测试 / 修测试**（3 分钟）：
```
请运行 pytest，看看测试结果。如果有失败的测试，请分析原因并尝试修复，
不要修改测试用例本身（除非测试用例明显写错了），修完再跑一次直到全绿。
```

2. **让 Claude 用 Git**（3 分钟）：
```
请把当前的修改提交到一个新分支 feature/csv2md，
commit message 用 Conventional Commits 格式，中文正文英文标题。
```
Claude 会自己 checkout / add / commit：
```bash
git checkout -b feature/csv2md
git add .
git commit -m "feat: add csv to markdown converter

添加 csv2md.py 脚本，支持 UTF-8 中文与逗号转义。"
```

3. **安全与权限**（3 分钟）：Claude Code 默认对"有副作用"的操作弹确认，3 选：
   - **Yes**：允许这一次；
   - **Yes, always for this command**：以后同类自动允许；
   - **No**：拒绝，让 Claude 换招。

   **三档权限模式（重点）**——会话内按 **Shift+Tab** 循环切换，屏幕底部会显示当前档位：

   | 档位 | 状态标识 | 何时用 |
   |---|---|---|
   | ① Ask（默认） | 无 | 陌生代码、首次任务、有风险的操作 |
   | ② Auto-Accept | `⏵⏵ auto-accept edits on` | 已了解意图、想让它一次跑完流水线 |
   | ③ Plan | `⏸ plan mode on` | **只读**：让它先出方案，你审后再动手 |

   推荐工作流：**Plan 出方案 → Shift+Tab 切 Auto → 一次执行完**。板书要强调"Shift+Tab"这一操作。

   **常用斜杠命令 6 条**（板书）：`/init`（首次进项目→生成 CLAUDE.md）、`/compact`（上下文压缩）、`/clear`（清空对话）、`/review`（复盘改动）、`/cost`（看 Token/美元）、`/help`。

   `--dangerously-skip-permissions` 跳过所有确认——**只在沙盒（Docker 容器 / WSL 隔离目录）**里用，**⚠️ 生产环境永远不要用**。

4. **MCP 简介**（2 分钟）：**Model Context Protocol** = 给 AI 装外挂。Claude 可以调外部工具：
   - 文件系统（默认）
   - GitHub（读 issue、开 PR）
   - 数据库（MySQL / Postgres）
   - 浏览器（UI 自动化）
   - 搜索引擎

   添加示例：
```bash
claude mcp add github --command "npx" --args "@modelcontextprotocol/server-github"
```
入门阶段先用好文件系统 + 命令行工具即可。

#### 示例演示（20 分钟）
**综合项目：让 Claude 从零搭一个 Astro 静态博客**（20 分钟）

在 `~/study/blog` 目录：
```bash
mkdir -p ~/study/blog && cd ~/study/blog
claude
```

给 Claude 的提示词：
```
我想在当前目录搭一个静态博客网站，用 Astro（更现代，有 SSR 能力）。
步骤：
1. 用 npm create astro@latest 生成项目，选择最小模板，TypeScript strict。
2. 生成后在 src/content/blog/ 下创建 hello-world.md，包含标题、日期、正文。
3. 修改首页展示这篇文章的入口。
4. 跑 npm run dev，验证 http://localhost:4321 能访问。
5. 全部完成后，简要说明目录结构和后续维护方式。
```

现场跟着 Claude 一步步走，每次弹权限确认时讲解为什么选 Yes / 为什么可以选 Always。最后打开浏览器 `http://localhost:4321` 展示成功。

#### 课堂练习（8 分钟）
每人：
1. 让 Claude 跑一次 pytest（如果没写测试就先写 3 条给猜数字游戏）；
2. 让 Claude 用 Git 提交你的 `csv2md.py`，用 Conventional Commits 格式。

#### 小结（5 分钟）
6 条最佳实践 + 6 类常见错误（投影表格快速过一遍）：

**最佳实践**：
1. 给足上下文
2. 让 Claude 先看再动手
3. 善用 `/clear` 避免回话污染
4. 保留 `CLAUDE.md`
5. 验证是硬要求（每次改完跑一次）
6. 不迷信输出，做 code review

**常见错误 & 解决**：

| 现象 | 原因 / 建议 |
|---|---|
| `command not found: claude` | npm 全局路径没进 PATH。运行 `npm config get prefix`，把 `<prefix>/bin` 加入 PATH。 |
| 登录卡住 | 用 API Key，或从能开浏览器机器拷 `~/.claude/`。 |
| 权限确认烦 | `/config` 里设 "always allow"，或沙盒里用 `--dangerously-skip-permissions`。 |
| 输出太长被截断 | 让 Claude "写到文件 X 而不是直接输出"。 |
| 费用飙升 | `/cost` 查用量；日常用 sonnet；只在必要时切 opus。 |
| 网络不通 | 检查代理；国内直连 Anthropic 不稳，需代理或网关。 |

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  3. Claude Code 入门（下）                   │
├──────────────────────────────────────────────┤
│  自我验证：pytest 直到全绿                   │
│  自我提交：git commit + Conventional Commits │
│                                              │
│  权限 3 选：                                 │
│   Yes / Yes always / No                      │
│   --dangerously-skip-permissions（仅沙盒）   │
│                                              │
│  MCP = AI 装外挂                             │
│   claude mcp add …                           │
│                                              │
│  最佳实践 6 条：                             │
│   上下文/先看再动/清上下文/                  │
│   CLAUDE.md/验证/code review                 │
│                                              │
│  常见错 6 类：                               │
│   PATH/登录/权限/截断/费用/网络              │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成第 5 章 5.3 节的"三步作业"：Claude 写猜数字 → 写 5 条 pytest → 生成 README.md。
2. **必做**：给你的项目写 `CLAUDE.md`，再开一次会话验证 Claude 是否明显更贴合你的风格。
3. **进阶必做**：跟 Claude 一起完成一次真实场景任务——给一个 GitHub 开源项目提一个改动（哪怕只是拼写错误），包括 fork / 修改 / 跑测试 / 开 PR。
4. **挑战题**：给 Claude 加一个 MCP（GitHub / 文件系统之外任选一个），写文档记录添加过程和用途。

### 3.6 教学反思提示
- 综合项目"Astro 博客" `npm create astro` 需要网络稳定，教室 wifi 抖动会翻车，建议提前让教师机预下载模板。
- 学生对"什么时候按 Always allow" 判断不准，可用一句话总结："**读文件、跑测试可以 Always；写文件、执行 rm、curl 到未知 URL 慎重**"。

---

## 第 4 课时：Hermes Agent 是什么 + 安装与初始配置

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 说清 Hermes Agent 的定位——通用 AI 智能体 CLI，与 Claude Code 是**互补而非替代**关系；
2. 列举 Hermes Agent 的 8 大核心概念：Provider / Model / Tool / Skill / Memory / Cron / Delegate / Profile；
3. 完成 Hermes Agent 的安装（一键脚本或 pipx / pip 之一）；
4. 完成 `hermes setup` 首次配置向导（选 Provider / 填 API Key / 选默认 Model）；
5. 掌握配置命令：`hermes config show / edit / set`；
6. 掌握启动会话：`hermes` / `hermes -c` / `hermes --resume <session_id>`。

#### 4.1.2 过程与方法目标
1. 通过 Claude Code vs Hermes Agent 对比表，建立"编程助手 vs 数字员工"的区分认知；
2. 通过读懂 `~/.hermes/` 目录结构，理解 Hermes 的"配置文件即代码"思路。

### 4.2 教学重难点
- **重点**：Hermes 8 大核心概念表／`hermes setup` 三问三答／`~/.hermes/config.yaml` 位置／`hermes config set` 语法
- **难点**：OpenRouter 一个 Key 通吃几十个模型的价值；Provider 与 Model 的 `openrouter/anthropic/claude-sonnet-4` 两级命名

### 4.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"上一课时的 Claude Code 是 **'AI 编程助手'**。这一课时的 Hermes Agent 更像 **'AI 个人助理 / 数字员工'**——除了写代码，它还能收发邮件、发 Telegram、控制智能家居、订阅博客、跑爬虫，甚至能**每天定时替你干活**（cron）。"

**一句话对比**：**Claude Code = AI 编程助手；Hermes Agent = AI 个人助理 / 数字员工**，两者可以并用。

#### 新知讲授（15 分钟）
1. **Hermes Agent 定位**（4 分钟）：4 个关键卖点：
   - **不绑定单一模型厂商**：OpenRouter / Anthropic / OpenAI / Google / xAI / DeepSeek / 自建 vLLM 任意后端；
   - **工具箱丰富**：终端、文件、Web 浏览、桌面 Computer Use、跨会话记忆、技能 Skills、定时 Cron、多 Agent 协作；
   - **面向全场景生产力**：不只写代码，也收发邮件 / Telegram / 智能家居 / 博客 / 爬虫；
   - **开源可扩展**：Skills / Plugins / Custom Providers 都可以自己写。

2. **8 大核心概念**（6 分钟）：投影表格。

| 概念 | 一句话说明 |
|---|---|
| **Provider（模型服务商）** | 用哪家 API：openrouter / anthropic / openai / xai / 自建 |
| **Model** | 具体模型：`claude-sonnet-4`、`gpt-5`、`deepseek-chat` |
| **Tool（工具）** | Agent 可调用的能力：终端、文件、浏览器、桌面…… |
| **Skill（技能）** | 可复用的"任务操作指南"，Markdown 说明书，命中场景自动加载 |
| **Memory（记忆）** | 跨会话的个人偏好和环境事实 |
| **Cron（定时任务）** | 按计划自动执行 |
| **Delegate（委派）** | 主 Agent 派若干子 Agent 并行做子任务 |
| **Profile（配置档）** | 一套独立配置（models / skills / memories），按场景切换 |

Mermaid 全景图：

```mermaid
flowchart TB
    U["用户"] -->|"自然语言指令"| A["Hermes Agent"]
    A -->|"选择合适的工具"| T1["终端 terminal"]
    A --> T2["文件 read_file / write_file / patch"]
    A --> T3["Web browser_navigate / web_search"]
    A --> T4["桌面 computer_use"]
    A --> T5["记忆 memory / session_search"]
    A --> T6["技能 skills"]
    A --> T7["定时 cron"]
    A --> T8["委派 delegate_task"]
    A -->|"多步执行 + 校验"| U
```

3. **前置条件与安装**（5 分钟）：
   - **系统**：Linux / macOS / Windows（Win 建议 WSL 2）
   - **Python 3.10+** 或用官方一键脚本
   - 至少 1 个 API Key（OpenRouter 一个 Key 通吃所有主流模型，初学者推荐）

安装：
```bash
# 方式一：官方一键脚本（推荐）
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash

# 方式二：pipx（干净、隔离，推荐）
python3 -m pip install --user pipx
python3 -m pipx ensurepath
pipx install hermes-agent

# 或直接用 pip
pip install --user hermes-agent
```
装完：
```bash
hermes --version
```
若命令找不到，检查 `~/.local/bin` 是否在 PATH 中。

#### 示例演示（18 分钟）
**演示 A：`hermes setup` 首次向导**（8 分钟）：
```bash
hermes setup
```
三问三答：
1. **选默认 Provider**：初学者推荐 **openrouter**——一个 Key 通吃几十个模型；
2. **填 API Key**：到 `https://openrouter.ai/keys` 生成，粘贴；
3. **选默认 Model**：`anthropic/claude-sonnet-4`、`openai/gpt-5`、`deepseek/deepseek-chat` 任选。

配置文件默认存在 `~/.hermes/config.yaml`。之后随时改：
```bash
# 查看当前配置
hermes config show

# 修改默认模型
hermes config set model.provider openrouter
hermes config set model.default anthropic/claude-sonnet-4

# 列出所有工具
hermes tools

# 列出已安装技能
hermes skills list
```

**演示 B：`~/.hermes/` 目录结构**（4 分钟）：
```
~/.hermes/
├── config.yaml           # 全局配置
├── memories/             # 跨会话记忆
├── skills/               # 你自己的技能
├── plugins/              # 你的插件
├── profiles/             # 其他 profile
│   └── work/             # 例如：工作 profile
├── cron/                 # 定时任务定义
└── sessions.db           # 会话历史（SQLite）
```

**演示 C：启动首次会话**（6 分钟）：
```bash
hermes
```
第一句：
```
你好，请介绍一下你自己，你能做什么？我该如何最有效地使用你？
```
Hermes 会用中文回答（若配了中文偏好），并让你了解能力边界。

#### 课堂练习（6 分钟）
> ⚠️ 装 Hermes + 首次向导起步 5–8 分钟，**装完整流程放到课后作业**（见 4.5）。课堂 6 分钟只做**已经装好后的配置验证**：
学生独立完成（教师现场巡视）：
1. `hermes --version` 输出 v0.18+；
2. `hermes tools` 快速浏览内置工具清单（不用背，感受一下"能力面"）；
3. `hermes config show` 截图当前 provider / model 配置到作业里。

> 没装完的同学：把课堂时间用来跟做教师演示的 `hermes setup --portal` 一键流程，其余留到课后完成。

#### 小结（3 分钟）
下一课时进入"6 大工作流"实战：记忆 / 代码 / Web / Computer Use / Cron / Delegate。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  4. Hermes Agent 安装                        │
├──────────────────────────────────────────────┤
│  定位：通用 AI 智能体 CLI                    │
│   编程 + 浏览器 + 桌面 + 邮件 + 定时         │
│                                              │
│  8 概念：                                    │
│   Provider Model Tool Skill                  │
│   Memory Cron Delegate Profile               │
│                                              │
│  安装：                                      │
│   (1)官方脚本 curl … install.sh | bash       │
│   (2)pipx install hermes-agent               │
│                                              │
│  首次三问：                                  │
│   Provider（推 openrouter）                  │
│   API Key                                    │
│   Model（推 anthropic/claude-sonnet-4）      │
│                                              │
│  ~/.hermes/config.yaml                       │
│  hermes config show / set                    │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 Hermes Agent 安装、`hermes setup`、`hermes --version` 输出。
2. **必做**：`hermes tools` 输出所有工具，抽 5 个自己觉得有趣的写 100 字用途预测（等下一课时验证）。
3. **挑战题**：查阅官方文档 `https://hermes-agent.nousresearch.com/docs`，写 200 字回答"Hermes 与 Claude Code 各自的差异化优势是什么？"

### 4.6 教学反思提示
- OpenRouter 注册需要国际信用卡或 Stripe 支持，国内学生可能受限，教师可提前准备 DeepSeek 备用方案（`hermes config set model.provider deepseek`）。
- `~/.local/bin` 不在 PATH 是最容易踩的坑，提前告知学生 pipx 安装后需要 `pipx ensurepath` 并重启终端。

---

## 第 5 课时：Hermes Agent 简单入门使用（上）——记忆 / 代码 / Web / Computer Use

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 掌握交互式 vs 一次性命令 vs 管道 3 种运行方式；
2. 会用 `memory` 工具让 Hermes 记住个人偏好，跨会话自动生效；
3. 会让 Hermes 完成"建项目 + 写代码 + 写测试 + 跑测试"闭环；
4. 会让 Hermes 用 `web_search` / `browser_navigate` 上网抓信息；
5. 理解 **Computer Use**：影子光标 / 不抢焦点 / 权限依赖，跑 `hermes computer-use doctor` 健康检查。

#### 5.1.2 过程与方法目标
1. 通过让 Hermes"记住你"，感受个性化 AI 助理的价值；
2. 通过 Computer Use 演示，理解"AI 在你后台干活"的新范式。

### 5.2 教学重难点
- **重点**：`memory` 5 条个人偏好写法／`web_search` + `browser_navigate` 抓信息／`hermes computer-use doctor`
- **难点**：Computer Use 权限（macOS 辅助功能 / Windows 无障碍）；后台影子光标 vs 真实光标

### 5.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
"上一课时装完 Hermes，今天让它'知道你'并'替你干活'。你要看到 4 个能力：记忆 / 代码 / 上网 / 操控桌面。"

#### 新知讲授（8 分钟）
1. **三种运行方式**（3 分钟）：
```bash
# 交互式（默认）
hermes

# 一次性命令
hermes "总结当前目录下所有 .md 文件的核心要点"

# 管道输入
cat error.log | hermes "分析这份日志，指出根因和修复建议"
```

2. **memory 工具**（3 分钟）：Hermes 有专门的 `memory` 工具，写入 `~/.hermes/memories/`，**下次开新会话会自动注入上下文**，让 Hermes 一开口就懂你。

3. **Computer Use 定位**（2 分钟）：在后台用截图 + 点击 + 键盘操作驱动你的桌面**而不打断你**（不抢焦点、不抢光标）。适合场景：帮你打开浏览器搜 XX、去 Notion 建页面、把飞书最新邮件截图……

#### 示例演示（22 分钟）
**演示 1：让 Hermes 记住你**（5 分钟）：
```
请通过 memory 工具记住以下事实：
1. 我叫小明，大二学生，正在学 Python 和 Web 开发；
2. 我的偏好：回复用中文，代码简洁风格；
3. 我的操作系统：Windows 11 + WSL 2 Ubuntu 26.04；
4. 我常用的项目路径：~/study/。

保存好后简要复述你记住的内容。
```
现场演示完后 `/exit`，再开 `hermes`，让学生看新会话是否记住。

**演示 2：让 Hermes 干活（代码 + 测试）**（7 分钟）：
```
在 ~/study/py/ 目录下：
1. 建一个新的 Python 项目 word-counter；
2. 写一个脚本：读取 txt 文件，输出词频前 10；
3. 顺手写 3 个 pytest 单元测试；
4. 全部搞定后跑一次测试给我看，最后总结所做的工作。
```
Hermes 会调用 `terminal`、`write_file`、`read_file` 一整套工具走完流程。

**演示 3：让 Hermes 上网**（5 分钟）：
```
帮我在网上查一下 Python 3.13 相比 3.12 有哪些新特性。
用 web_search 找 3 篇高质量文章，读完后：
1. 输出 5 条核心变化（每条一句话）；
2. 给我一个从 3.12 迁移到 3.13 的注意事项清单；
3. 附上参考链接。
```
或让它去具体网站抓：
```
打开 https://ollama.com/library ，列出当前 top 10 的模型名称和大小。
```

**演示 4：Computer Use 桌面操控**（5 分钟）：
```bash
hermes computer-use doctor    # 健康检查
```
按提示开权限（macOS：系统设置 → 隐私与安全 → 辅助功能；Windows：无障碍权限）。

然后：
```
用 computer_use 工具帮我打开 Firefox，
然后访问 https://arxiv.org/list/cs.AI/new ，
把首页前 5 篇论文的标题告诉我。
```
现场演示"影子光标"——Hermes 在后台点击、滚动，**你的鼠标不动**。

#### 课堂练习（7 分钟）
> ⚠️ 时长有限，**必做 1 项**（memory）；**选做 1 项**（web 抓取）；Computer Use 涉及权限配置，**放到课后作业**（见 5.5）尝试。
学生独立完成：
1. **必做**：用 `memory` 写自己的 3 条偏好（姓名、身份、回复风格），再 `hermes memory list` 验证。
2. **选做（时间够就做）**：让 Hermes 抓一个你关心的网页（豆瓣电影 / 知乎话题 / GitHub 项目）的 top 5 条目，截图交作业。

#### 小结（5 分钟）
下一课时讲最后 2 个大杀器：**Cron 定时** + **Delegate 委派**，以及 **Skills 技能系统** 和综合项目。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  5. Hermes 入门（上）                        │
├──────────────────────────────────────────────┤
│  3 种运行：                                  │
│   (1)hermes（交互式）                        │
│   (2)hermes "…"（一次性）                    │
│   (3)cat log | hermes "分析…"（管道）        │
│                                              │
│  4 大姿势：                                  │
│   (1)memory 记住你                           │
│   (2)代码 + 测试闭环                         │
│   (3)web_search / browser_navigate 上网      │
│   (4)Computer Use 后台操控                   │
│                                              │
│  Computer Use：                              │
│   hermes computer-use doctor                 │
│   开辅助功能权限 → 影子光标                  │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：让 Hermes 用 `memory` 记住你的 5 条偏好；新开会话验证自动生效，截图对比。
2. **必做**：让 Hermes 完成一次"代码 + 测试 + 提交"闭环（任意小项目 + `git commit`）。
3. **进阶必做**：让 Hermes 用 `web_search` 收集"你关心的技术话题" 3 篇文章并输出结构化摘要。
4. **挑战题**：跑 `hermes computer-use doctor` 通过检查，让 Hermes 帮你打开一个网页并**在后台**完成一次简单操作。

### 5.6 教学反思提示
- Computer Use 权限设置因系统而异，需要提前准备好 Windows/macOS/Linux 三张流程截图。若课堂时间紧，可只让学生看演示、不动手。
- `memory` 部分学生可能会写"临时状态"（比如"今天吃了火锅"）而不是"稳定偏好"，需示范"什么内容适合放 memory"。

---

## 第 6 课时：Hermes Agent 简单入门使用（下）——Cron / Delegate / Skills / 综合项目 + 结课

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 会用 `cronjob` 工具创建定时任务，会用 `hermes cron list` / `status` / `remove` 管理任务；
2. 会用 `delegate_task` 并行派发多个子 Agent，理解"节省 token、不污染主对话"的价值；
3. 理解 **Skills** 系统：`hermes skills list` 查看已装技能；场景匹配自动加载；也可显式"请加载 XX skill"；
4. 会用 `skill_manage` 让 Hermes 帮你创建自定义 Skill；
5. 完成综合项目"个人 AI 工作台"5 步任务；
6. 掌握 Hermes vs Claude Code 差异对比表 + 6 类常见错误的解决办法。

#### 6.1.2 过程与方法目标
1. 通过 Cron 演示"AI 每天定时替你干活"，感受"数字员工"的完整形态；
2. 通过 Delegate 演示"主 Agent 拆分 + 子 Agent 并行"，理解多智能体协作。

### 6.2 教学重难点
- **重点**：Cron 任务的自然语言创建；`delegate_task` 并行子任务；Skills 场景匹配与自建
- **难点**：Cron daemon 是否运行（`hermes cron status`）；Delegate 何时用（"3+ 独立子任务" vs "1 个可拆分任务"）

### 6.3 教学过程设计（45 分钟）
#### 导入（2 分钟）
"最后一课时。你会看到 Hermes 的**杀手锏**——每天替你干活的定时任务、并行的多智能体、能不断成长的技能系统。"

#### 新知讲授（12 分钟）
1. **Cron 定时任务**（4 分钟）：
```
帮我创建一个定时任务：
- 每天早上 8:00 执行；
- 内容：抓取 hackernews 上"AI"相关的 Top 10 帖子，摘要成中文并按重要性排序；
- 结果发送到我的 Telegram（如果没接入就存到 ~/daily-ai-brief/YYYY-MM-DD.md）。
```
Hermes 会调用 `cronjob` 工具创建任务，存在 `~/.hermes/cron/`。查看：
```bash
hermes cron list                # 列出所有任务及运行状态
hermes cron status              # 查看 cron 调度器是否在运行
hermes cron remove <job_id>     # 删除任务
```

**扩展：Gateway 端到端把 Hermes 接到 Telegram**（1 分钟口述，作业让学生完成）：
```bash
# 1) Telegram 里 @BotFather → /newbot → 拿到 token
# 2) 交给 Hermes
hermes gateway setup            # 交互式向导，选 Telegram、粘贴 token
# 3) 安装成常驻服务并启动
hermes gateway install
hermes gateway start
hermes gateway status
# 4) 在 Telegram 里给自己的 bot 发 "hi" 即可对话
```
接好之后 cron 任务的输出会自动推送到手机 Telegram。Gateway 还支持 Discord / Slack / WhatsApp / iMessage / 飞书 / 钉钉等 20+ 平台，`hermes gateway setup` 选择即可。

2. **Delegate 委派子任务**（3 分钟）：
```
请调用 delegate_task 并行执行 3 个子任务：
1. 研究 vLLM 的架构；
2. 研究 sglang 的架构；
3. 研究 TGI 的架构。
每个子任务产出一份 300 字的摘要，最后主 Agent 汇总一份对比表给我。
```
**优点**：子 Agent 各自完成，只有最终摘要回到主上下文——**节省 token、不污染主对话**。

3. **Skills 技能系统**（5 分钟）：Hermes 内置大量 Skill（`hermes skills list` 查看），比如：
   - `github-pr-workflow`：GitHub PR 生命周期规范
   - `test-driven-development`：TDD 强制流程
   - `youtube-content`：YouTube 视频转脚本/摘要/博文
   - `google-workspace`：Gmail / Calendar / Sheets 操作
   - `obsidian`：读写 Obsidian 笔记
   - `chinese-knowledge-base`：写结构化中文知识库

场景匹配时**自动加载**，也可显式：
```
请加载 chinese-knowledge-base 技能，然后按它的规范帮我写一份
"高等数学极限概念"的中文知识库（≥ 3000 字），保存到 ~/study/notes/limits.md。
```

自建 Skill：
```
请帮我创建一个 skill 叫 daily-standup，
内容包括：每天早上让 AI 问我 5 个问题（昨天做了什么 / 今天做什么 / 卡壳 / 心情 / 明天可用时间）
并保存到 ~/standup/YYYY-MM-DD.md。
```
Hermes 会用 `skill_manage` 工具在 `~/.hermes/skills/` 下建对应目录。

#### 示例演示（15 分钟）
**演示 A：Cron 创建 + 管理**（5 分钟）：
```
帮我创建一个 cron 任务：
每天 22:00 让我用 3 句话总结今天做了什么，写入 ~/diary/YYYY-MM-DD.md。
```
现场 `hermes cron list` 看创建成功；`hermes cron status` 看调度器状态。

**演示 B：Delegate 并行 3 子任务**（5 分钟）：
现场执行"vLLM / sglang / TGI 对比" delegate 任务，看输出汇总表。

**演示 C：Skill 使用**（5 分钟）：
```
请加载 chinese-knowledge-base 技能。加载后请告诉我这个 skill 的规范要点。
```
让 Hermes 说清 skill 是什么、怎么用。

#### 综合项目 + 课堂练习（12 分钟）
"**个人 AI 工作台**"任务清单（学生现场至少完成 1—2 项，其余作业）：

1. `memory` 里保存你的基本偏好（姓名 / 身份 / 常用目录 / 语言 / 代码风格）；
2. 创建 skill `weekly-review`：每周日 21:00 主动问你"本周三件成功事 / 三件失败事 / 下周三件目标"，写入 `~/reviews/YYYY-Www.md`；
3. 创建 cron 任务：每天 9:00 抓取一份天气 + RSS 摘要，输出到 `~/daily-brief/`；
4. 建 `~/study/notes` 目录，用 `obsidian` skill（或纯 Markdown）把本课程 6 章要点整理进去；
5. 与 Hermes 一起做"跨天知识回看"：让它读第一章记住的关键概念，出 20 道题（选择 + 简答）测试你。

#### 结课总结（4 分钟）
本课程 6 大章、18 课时全部结束。回顾：

- **Day01** 第 1 章：建立 **AI 时代的世界观**；第 2 章：掌握**日常 AI 生产力工具**；
- **Day02** 第 3 章：拥有一个 **Linux 环境**；第 4 章：拥有一个 **Docker 环境**；
- **Day03** 第 5 章：拥有一个 **AI 编程助手 Claude Code**；第 6 章：拥有一个 **AI 智能体 Hermes Agent**。

这只是入门。真正的**赋能**不来自看完这份教程，而来自**未来 3—6 个月你用 AI 完成的每一件小事**。祝你在 AI 时代成为"放大器人格"——用 AI 把自己的能力放大 10 倍。

**Claude Code vs Hermes Agent 对比表**（投影快速过一遍）：

| 维度 | Claude Code | Hermes Agent |
|---|---|---|
| 定位 | AI 编程助手 | 通用 AI 智能体 |
| Provider | 仅 Anthropic | 任意（OpenRouter / OpenAI / Anthropic / 自建…） |
| 工具广度 | 侧重编码 | 编码 + 浏览器 + 桌面 + 邮件 + 定时任务… |
| 定制性 | 中（CLAUDE.md、MCP） | 高（Skills、Plugins、Profiles、自建 Provider） |
| 学习曲线 | 低 | 中 |
| 典型用户 | 开发者 | 开发者 + 知识工作者 + 极客 |

**建议做法**：编码任务优先 Claude Code；日常自动化 / 跨场景任务 Hermes Agent。**两者可以互补使用**。

### 6.4 板书设计
```
┌──────────────────────────────────────────────┐
│  6. Hermes 入门（下）+ 结课                  │
├──────────────────────────────────────────────┤
│  Cron：hermes cron list / status / remove    │
│   自然语言："每天 22:00 写日记"              │
│                                              │
│  Delegate：并行 3 子任务 → 主汇总            │
│   省 token / 不污染主对话                    │
│                                              │
│  Skills：hermes skills list                  │
│   场景匹配自动加载 / 显式"请加载 XX"         │
│   skill_manage 自建                          │
│                                              │
│  综合项目：个人 AI 工作台                    │
│   memory / weekly-review / daily-brief /     │
│   obsidian 笔记 / 跨天回看                   │
│                                              │
│  结课：3—6 个月的每件小事才是真正赋能        │
└──────────────────────────────────────────────┘
```

### 6.5 课后作业（本课程收官作业）
1. **必做**：完成"个人 AI 工作台"综合项目**至少 3 项**（memory / cron / skill / 笔记 / 跨天回看 5 选 3）。
2. **必做**：从 `hermes skills list` 挑 1 个感兴趣技能加载并试用（推荐 `youtube-content` / `arxiv` / `obsidian`），写 200 字使用报告。
3. **必做**：写一份 **课程总结**（500 字以上）：3 天 6 章你的最大收获、感觉最有用的 3 个工具、最想深入的 1 个方向。
4. **进阶必做**：写一个自己的 Skill（哪怕 20 行），如 `daily-english-flashcard`——每天让 Hermes 从你不熟悉的 300 个单词里抽 10 个出题。
5. **反思题**：对比 Claude Code 与 Hermes Agent，在你自己的学习/工作流中，各自最适合承担什么角色？
6. **收官挑战**：3 个月后再回顾这份收官作业和你的 10 条生存法则自评表，看看你有没有真正把 AI 用起来。

### 6.6 教学反思提示
- Cron 任务需要 Hermes daemon 在后台运行才会触发，WSL 里学生的电脑关机就不会跑。上课时点明这一点，避免学生"以为设了任务就万事大吉"。
- Delegate 只在"独立可并行的多子任务"下才有优势，若只是单条链式任务，用 Delegate 反而慢。示例中的"vLLM / sglang / TGI" 3 个是天然独立的，是好选择。
- 若课程收官时间充裕，可让学生上来分享自己的 5 条 memory + 1 个 skill 的成果，形成"学习成果展"。
