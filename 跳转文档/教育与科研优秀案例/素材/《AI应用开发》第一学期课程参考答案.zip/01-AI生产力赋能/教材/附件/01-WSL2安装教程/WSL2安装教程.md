# WSL 2 安装与配置

## 1 WSL 2 安装

（1）启用 Windows 功能，选中“适用于 Linux 的 Windows 子系统”以及“Virtual Maching Platform”。
 <img src="./assets/image-20260719194902869.png" alt="image-20260719194902869" style="zoom:67%;" />

（2）执行`wsl --install`。如果本机尚未安装 wsl，则会自动安装 wsl。
<img src="./assets/image-20260719195122040.png" alt="image-20260719195122040" style="zoom:67%;" />

注意：

- 安装完后，必须重启。
- 若开启代理，则可能会出现 “已禁止（403）”错误。但不开启代理，则下载缓慢，解决方案是：
  - 1、执行 wsl.2.7.1.0.x64.msi 进行本地手动安装。
  - 2、先执行`wsl --install`，下载一小段时间后，取消，再开启代理，再重新执行`wsl --install`。
  - 3、执行`wsl --install`时添加`--web-download`参数。
- 如果执行完`wsl --install`，再开启代理就不会再有任何警告了。
- 使用`wsl --uninstall`可以卸载 wsl。

（3）配置代理。此步骤并非必须，如果不配置代理，下载速度也可以接受的话，就不用配置。

```bash
set HTTP_PROXY=http://127.0.0.1:7897
#重点是这个
set HTTPS_PROXY=http://127.0.0.1:7897

#查看
set HTTP_PROXY
```

列出所有可用 Linux 发行版，需要联网（访问 github，如果访问不了，或速度很慢，就按上一步配置代理）：

```bash
wsl --list --online
```

显示如下：
<img src="./assets/image-20260719195141828.png" alt="image-20260719195141828" style="zoom:67%;" />

（4）选择合适的发行版，并进行安装。如果下载速度非常慢，就需要按照第 2 步配置代理。

```bash
wsl --install Ubuntu
```

（5）安装完成后
<img src="./assets/image-20260719195210913.png" alt="image-20260719195210913" style="zoom:67%;" />

此处，配置用户名为 admin0，密码为 123456

同时显示一个欢迎页面。
<img src="./assets/image-20260719195221610.png" alt="image-20260719195221610" style="zoom:67%;" />

查看安装的发行版：
<img src="./assets/image-20260719195236740.png" alt="image-20260719195236740" style="zoom:67%;" />

（6）安装完成之后，可随时通过执行`wsl`进入到系统中，使用`exit`退出到 Windows Shell。
<img src="./assets/image-20260719195247214.png" alt="image-20260719195247214" style="zoom:67%;" />

（7）删除已安装的发行版：

```bash
wsl --unregister Ubuntu

# 查看，已注销的发行版将不再显示
wsl -l -v
```

### 1.1 常见问题

（1）提示：请求的操作已成功，直到重新启动系统前更改将不会生效。但是重启之后，依然同样的提示，使用 wsl 进入不了 linux shell。

解决方案：先禁用虚拟机平台，再重新开启。

```bash
dism.exe /online /disable-feature /featurename:VirtualMachinePlatform /norestart
#有可能会比较耗时，需要耐心等待，不要中断
dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart
```

（2）提示如下内容：
 正在下载: Ubuntu
 正在安装: Ubuntu
 当前计算机配置不支持 WSL2。
 请启用“虚拟机平台”可选组件，并确保在 BIOS 中启用虚拟化。
 通过运行以下命令启用“虚拟机平台”: wsl.exe --install --no-distribution
 有关信息，请访问 https://aka.ms/enablevirtualization
 错误代码: Wsl/InstallDistro/Service/RegisterDistro/CreateVm/HCS/HCS_E_HYPERV_NOT_INSTALLED

这个错误的原因是 CPU 未开启虚拟化。

解决方案：进入 UEFI/BIOS，执行如下操作：

- Intel 处理器：找到 Intel Virtualization Technology 或 Intel VT-x，将其设置为 Enabled。
- AMD 处理器：找到 SVM Mode，将其设置为 Enabled。

### 1.2 配置显示中文

```bash
sudo apt install language-pack-zh-hans

# 在出现的界面中，通过上下键找到 zh_CN.UTF-8，按空格键选中它（前面会出现 * 号），然后按 Tab 键选择 <Ok> 并回车
# 在下一个界面中，选择 zh_CN.UTF-8 作为默认语言环境
sudo dpkg-reconfigure locales

# 编辑 ~/.bashrc 文件，在文件末尾添加以下两行，确保每次启动终端都强制使用中文环境
export LANG=zh_CN.UTF-8

# 使环境变量生效
source ~/.bashrc
```

## 2 给 WSL 配置桥接网络，使用 WSL 和宿主机在同一个网络之内

（1）按`Win + R`键，输入`winver`并回车。在弹出的“关于 Windows”窗口中，检查系统版本是否为 **Windows 10/11 专业版、企业版或教育版**。

（2）启用 Hyper-V 功能。执行完后，输入 y，重启。

```bash
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All
```

（3）使用 Get-NetAdapter 获取网卡名称（正在使用的有效网卡名称），本示例获取的是有线网卡名称：以太网。

（4）创建桥接网络。其中`-NetAdapterName`指定网卡名称。

```bash
New-VMSwitch -Name "WSLBridge" -NetAdapterName "以太网" -AllowManagementOS $true
```

（5）再次使用`Get-NetAdapter`指令，或使用`Get-VMSwitch`查看桥接网络是否创建成功。
 ![image-20260719195311260](./assets/image-20260719195311260.png)
 其中：

- vEthernet（WSLBridge）即创建的桥接网络，Status 状态为 Up，表示正在启用中。
- 以太网，则是我宿主机，正在使用的有线网卡。
- vEthernet（Default Switch），是安装 wsl 时自动安装的 NAT 网络。保留不要删除。
- 使用 Get-VMSwitch，可以看到 WSLBridge 桥接的正是以太网这个网卡。

右键点击开始菜单，搜索“查看网络连接”，其中第一个是自动安装的 NAT 网络，第二个是安装的桥接网络。
![image-20260719195323700](./assets/image-20260719195323700.png)
如何删除创建的桥接网络呢？

- 使用`Get-VMSwitch`查看创建的桥接网络的名称。

- 使用`Remove-VMSwitch -Name "WSLBridge"`即可删除，其中 WSLBridge 即创建的桥接网络的名称。

（6）在`~`目录下创建.wslconfig，内容为：

```
[wsl2]
networkingMode=bridged
vmSwitch=WSLBridge
ipv6=true
```

（7）使用`wsl --shutdown`关于 wsl，执行`wsl`重新进入到 linux中，使用`hostname -I`查看，发现 wsl 的 ip 地址已经和宿主机在同一个网络中。

（8）注意：安装 wsl 时，默认创建的 NAT 网络不要删除，删除之后无法恢复。

（9）执行 ncpa.cpl 可查看我的本地所有网络连接。

## 3 给 WSL 配置镜像网络，使 WSL 和宿主机共享同一 IP

### 3.1 图形界面设置

这是微软引入的官方设置方法，最安全也最推荐。

- 在“开始”菜单中搜索并打开`WSL Settings`。
- 进入左侧的 **“网络 (Networking)”** 选项卡。
- 将“网络模式 (Networking mode)”更改为 **“镜像 (Mirrored)”**，然后关闭窗口即可。
- 使用`wsl --shutdown`，再重新进入 wsl，使用`hostname -I`查看 ip，发现 wsl 已经和宿主机共享同一 ip。

注意：

- **使用镜像网络时，wsl 可以共享宿主机网络的代理**。
- 若要暴露 WSL 内的服务给外部网络，则要配置宿主机防火墙，允许入站通过。

### 3.2 修改`.wslconfig` 文件

- 在文件管理器中，打开用户目录`%UserProfile%`。
- 新建一个名为 `.wslconfig` 的文件，输入以下内容，并保存。

```
[wsl2]
networkingMode=mirrored
```

------