# Ubuntu Server 26.04 LTS 安装教程

本示例使用 VMware 26h1 版本。

<img src="./assets/image-20260603192924489.png" alt="image-20260603192924489" style="zoom:67%;" />

1. 点击文件，新建虚拟机。选择自定义安装，有更细、更自由的控制粒度。

<img src="./assets/image-20260603193329799.png" alt="image-20260603193329799" style="zoom:67%;" />

2. 选择虚拟机的兼容性。

<img src="./assets/image-20260603193227116.png" alt="image-20260603193227116" style="zoom:67%;" />

3. 选择稍后安装操作系统。

<img src="./assets/image-20260603193359758.png" alt="image-20260603193359758" style="zoom:67%;" />

4. 选择操作系统类型，本示例选择 Ubuntu 64 位。

<img src="./assets/image-20260603193502124.png" alt="image-20260603193502124" style="zoom:67%;" />

5. 选择虚拟机安装位置。安装目录不要有中文名、空格或其它特殊特号。虚拟机名称可自定义。

<img src="./assets/image-20260603193631123.png" alt="image-20260603193631123" style="zoom:67%;" />

6. 选择 CPU 核心数，不能超过宿主机的逻辑核心总数。根据自己宿主机的硬件配置进行选择。

<img src="./assets/image-20260603193723411.png" alt="image-20260603193723411" style="zoom:67%;" />

7. 选择内存容量，根据宿主机的配置情况选择。

<img src="./assets/image-20260603193824757.png" alt="image-20260603193824757" style="zoom:67%;" />

8. 选择网络类型，本示例选择使用桥接网络。桥接网络：虚拟机和宿主机在同一局域网内，有自己的独立的 IP 地址，可直接连接到物理网络上。

<img src="./assets/image-20260603193855708.png" alt="image-20260603193855708" style="zoom:67%;" />

注意：如果要直连到物理网络，需要在 VMWare 的虚拟网络编辑器中配置通过哪个网卡直连到物理网络。

9. 选择 IO 控制器类型，默认即可。

<img src="./assets/image-20260603194035388.png" alt="image-20260603194035388" style="zoom:67%;" />

10. 选择磁盘类型，默认即可。

<img src="./assets/image-20260603194107339.png" alt="image-20260603194107339" style="zoom:67%;" />

11. 选择创建新磁盘。若使用已存在的虚拟磁盘，则可选择第 2 项。

<img src="./assets/image-20260603194141380.png" alt="image-20260603194141380" style="zoom:67%;" />

12. 选择创建磁盘大小，并创建为单个磁盘文件。注：磁盘文件并非立刻释放容量，而是根据实际占用空间逐渐释放。

<img src="./assets/image-20260603200327405.png" alt="image-20260603200327405" style="zoom:67%;" />

13. 选择虚拟磁盘存储位置。

<img src="./assets/image-20260603200411451.png" alt="image-20260603200411451" style="zoom:67%;" />

14. 虚拟机创建完成。

<img src="./assets/image-20260603200436404.png" alt="image-20260603200436404" style="zoom:67%;" />

15. 点击编辑虚拟机设置。在虚拟光驱中指定 ISO 光驱镜像，即操作系统安装光盘。设备状态，需要勾选“启动时连接”。

<img src="./assets/image-20260603200620344.png" alt="image-20260603200620344" style="zoom: 67%;" />

16. 在选项，高级中，选择虚拟机使用 UEFI 引导。

<img src="./assets/image-20260603200814029.png" alt="image-20260603200814029" style="zoom:67%;" />

在选项 -> 高级中，勾选启用侧通道缓解（若有）。注意：并不是所有电脑都会有此选项，只有 CPU 拥有 Hyper-V 特性的电脑才有。

17. 启用“加速 3D 图形”功能。有独立显卡、且安装了图形界面的话，可以勾选。

<img src="./assets/image-20260603201015867.png" alt="image-20260603201015867" style="zoom:67%;" />

对于没有独立显卡的主机，需要禁用 3D 硬件加速功能。否则，虚拟机开机会非常慢（黑屏卡顿，甚至卡死）。

对于某些 Linux 图形界面发行版，如 RHEL、RockyLinux、AlmaLinux 等发行版，在安装时，也必须取消勾选 3D 图形加速，否则会出现安装引导 GUI 显示不全，无法显示完整文字等情况。如有需要，可在系统安装完成之后，再手动开启。

对于纯命令行操作系统，本身并无图形界面，则无需开启。因为纯命令行操作系统，没有图形界面渲染的需要。

18. 点击编辑->虚拟网络编辑器。点击更改设置，此操作需要获取管理员权限。若无管理员权限，需要先点击“更改设置”，获取操作系统管理员权限。

<img src="./assets/image-20260603201538610.png" alt="image-20260603201538610" style="zoom:67%;" />

注意：选择桥接模式时，一定要选择正确的网卡，尤其是宿主机有多个网卡（包括各种虚拟网卡，或者 VPN 网卡）的情况下。

19. 点击虚拟机->电源->打开电源时进入固件，会直接进入 BIOS 或 UEFI，然后设置开机启动顺序。

<img src="./assets/image-20260603230509192.png" alt="image-20260603230509192" style="zoom:67%;" />

> 注：如果在进入 BIOS 或 UEFI 之后，图形界面操作卡顿，或操作无效，则需要彬 3D 图形加速，详见第 17 步。

20. 将光驱启动移动到第一位。使用 "+" 或 "-" 上下调整顺序。结束之后，按 F10 退出保存，并重启虚拟机。

<img src="./assets/image-20260603230906661.png" alt="image-20260603230906661" style="zoom:67%;" />

<img src="./assets/image-20260603230921693.png" alt="image-20260603230921693" style="zoom:67%;" />

<img src="./assets/image-20260603230931637.png" alt="image-20260603230931637" style="zoom:67%;" />

按 +、- 来调整启动顺序。然后点击 Commit changes and exit。然后回到首页，选择 Reset the system 即可。重启虚拟机也可以。

<img src="./assets/image-20260603230958893.png" alt="image-20260603230958893" style="zoom:67%;" />

<img src="./assets/image-20260603231008413.png" alt="image-20260603231008413" style="zoom:67%;" />

<img src="./assets/image-20260603231024333.png" alt="image-20260603231024333" style="zoom:67%;" />

21. 开机界面，选择第一项，Try or Install Ubuntu Server。

<img src="./assets/image-20260603231153139.png" alt="image-20260603231153139" style="zoom:67%;" />

22. Server 版安装界面默认是没有中文语言的，选择英文即可。

<img src="./assets/image-20260603231330982.png" alt="image-20260603231330982" style="zoom:67%;" />

23. 键盘配置。

<img src="./assets/image-20260603231401955.png" alt="image-20260603231401955" style="zoom:67%;" />

24. 选择第 1 项 Ubuntu Server。

<img src="./assets/image-20260603231435050.png" alt="image-20260603231435050" style="zoom:67%;" />

25. 网络配置。通过 DHCPv4 自动配置 IP 为 192.168.31.98。

<img src="./assets/image-20260603231510307.png" alt="image-20260603231510307" style="zoom:67%;" />

26. 代理配置。略过即可。

<img src="./assets/image-20260603233405386.png" alt="image-20260603233405386" style="zoom:67%;" />

27. 配置 Ubuntu 安装包镜像服务器。目前，在国内很多大学，及阿里都有镜像服务器，可自行搜索。此处选择官方默认的中文服务器。

<img src="./assets/image-20260603233456851.png" alt="image-20260603233456851" style="zoom:67%;" />

其它可选镜像：

- 清华大学镜像：https://mirrors.tuna.tsinghua.edu.cn/ubuntu
- 阿里镜像：[http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/))

28. 配置存储设备，分区在此步完成。分区是 Linux 系统一个比较重要的步骤。新手小白可直接选择自动分区。

<img src="./assets/image-20260603233618851.png" alt="image-20260603233618851" style="zoom:67%;" />

如果仅想体验使用 Linux，可以选择 Use an entire disk，自动分区即可（自动分区只会分一个根分区）。

如果有自定义分区需要，则选择 Custom storage layout，进行手动分区，按空格键选中。使用 Tab 键选中 Custome storage layout，按空格键选中。

> 注：在安装完操作系统之后，分区仍然是可以调整的。



29. 分区界面。在分区过程中，出现了问题也没有关系，随时可以点击 Reset 重置为初始状态。

<img src="./assets/image-20260603233712595.png" alt="image-20260603233712595" style="zoom:67%;" />

30. 首先使用空余空间创建一个 GPT 分区，用作引导分区。

<img src="./assets/image-20260603233834915.png" alt="image-20260603233834915" style="zoom:67%;" />

31. 紧接上一步，将 GPT 分区挂载为"/boot"分区，大小设置 300m ~ 500m 之间即可，大小设置可使用单位 m，或者 g。

Mount Point 挂载点，即 Linux 的特定分区，这个需要对 Linux 的分区有所了解。ext4 指的是分区类型，默认即可。

此处注意，使用 BIOS 固件和使用 UEFI 固件，是不同的，如果使用 UEFI，会额外自动创建一个 /boot/efi 分区。

<img src="./assets/image-20260603234014411.png" alt="image-20260603234014411" style="zoom:67%;" />

如果虚拟机使用 UEFI 引导，则此处会额外有一个 /boot/efi 分区。

<img src="./assets/image-20260603234049779.png" alt="image-20260603234049779" style="zoom:67%;" />

32. 将剩余所有空间（free space）创建为一个未格式化的 GPT 分区。尺寸留空即表示使用全部剩余空间，Format 选择 Leave unformatted，表示不进行格式化。

<img src="./assets/image-20260603234147355.png" alt="image-20260603234147355" style="zoom:67%;" />

33. 将所有剩余的空间（红色标注部分），创建为一个逻辑卷组。选择下方的 Create volume group（LVM），回车即可。

<img src="./assets/image-20260603234320651.png" alt="image-20260603234320651" style="zoom:67%;" />

34. 卷组名称，可自定义。使用空格选中要创建卷组的设备，此处选择 partition 3。下面的选项表示是否创建加密卷组，如果创建加密卷组，可以输入密码，并且以后每次在开启系统时，都需要输入此卷组的密码。

<img src="./assets/image-20260603234404235.png" alt="image-20260603234404235" style="zoom:67%;" />

35. 接下来就是要对创建的逻辑卷组剩余空间，进行分区。

<img src="./assets/image-20260603234503811.png" alt="image-20260603234503811" style="zoom:67%;" />

36. 选中空余空间（上图红色标注部分），回车，选择创建逻辑卷。这个步骤根据分区需要可能会重复多次，每次都是创建一个新的逻辑卷。"/usr"分区类似于 Windows 的 Program Files 及 User Data 目录。用于安装用户的程序，存储用户的数据等。

<img src="./assets/image-20260603234549483.png" alt="image-20260603234549483" style="zoom:67%;" />

37. 创建一个 10GB 的 /usr 分区。

<img src="./assets/image-20260603234647971.png" alt="image-20260603234647971" style="zoom:67%;" />

38. 创建交换分区，分区格式选择 swap。交换分区无需指定挂载点，空间无需设置太大，此交换分区类似于 Windows 系统的虚拟内存，用于提升内存性能的，但是目前内存都比较大，这个交换分区的意义已经不那么明显了。

<img src="./assets/image-20260603234739652.png" alt="image-20260603234739652" style="zoom:67%;" />

39. 创建根分区。如果没有为子分区设置空间，则所有子分区，共享根分区空间。即未单独分区的所有子分区共享根分区的空间。注意：根分区并非越大越好，反而是越小越好（分散到子分区中管理）。

<img src="./assets/image-20260603235013851.png" alt="image-20260603235013851" style="zoom:67%;" />

40. 创建 "/home" 分区，此分区类似于 Windows 系统中的我的文档目录。Size 留空表示使用所有剩余空间。

<img src="./assets/image-20260603235054963.png" alt="image-20260603235054963" style="zoom:67%;" />

41. 点击 Done，进行分区确认。

<img src="./assets/image-20260603235136243.png" alt="image-20260603235136243" style="zoom:67%;" />

42. 警告，点击 Continue 将对硬盘进行不可逆的操作。事实上，在安装完系统之后，可以随时对逻辑卷调整分区大小的。

<img src="./assets/image-20260603235225013.png" alt="image-20260603235225013" style="zoom:67%;" />

43. 创建系统登录用户。学习用途，无需设置复杂密码，本例此处设置为：123456

<img src="./assets/image-20260603235347667.png" alt="image-20260603235347667" style="zoom:67%;" />

44. 是否升级为专业版（Pro 版提供服务，但需要付费），选择忽略。

<img src="./assets/image-20260603235411547.png" alt="image-20260603235411547" style="zoom:67%;" />

45. 勾选安装 OpenSSH Server，这是一款必备应用，使用空格键选中。

<img src="./assets/image-20260603235430564.png" alt="image-20260603235430564" style="zoom:67%;" />

46. 选择安装其它流行的软件包，此步骤可选。这些软件包是类似 docker 原理的封装包，Ubuntu 独有。

<img src="./assets/image-20260603235525077.png" alt="image-20260603235525077" style="zoom:67%;" />

47. 开始安装。此过程中，可能会联网下载系统更新包。点击 View full log 可查看全部详细安装日志。

<img src="./assets/image-20260603235629814.png" alt="image-20260603235629814" style="zoom:67%;" />

48. 当出现 Reboot Now 表示安装完成，重启即可。

<img src="./assets/image-20260604000016412.png" alt="image-20260604000016412" style="zoom:67%;" />

建议，先关机，然后将 CDROM 切换为物理驱动器，并且取消“启动时连接”，然后再重启。

<img src="./assets/image-20260604000155483.png" alt="image-20260604000155483" style="zoom:67%;" />



49. 使用刚刚登记的账号和密码登录。以下是操作系统，升级、更新、清理等常用相关指令。

```bash
#清屏
clear

#更新软件包列表。apt 是较新的命令行前端，日常交互建议用 apt；老教程里的 apt-get 仍可用，但脚本之外优先 apt
sudo apt update

#升级更新系统软件包
sudo apt upgrade

#安装软件包
sudo apt install package-name

#卸载软件包
sudo apt remove package-name

#彻底卸载并清理干净，包括配置文件
sudo apt purge package-name

#自动删除过时或无依赖的软件包
sudo apt autoremove

#清理已下载的 .deb 包缓存
sudo apt clean
```



50. 必要的软件安装和系统配置

如果在安装过程中，已经勾选了 openssh-server，则此处无须重复安装。另外，open-vm-tools 是一个用于提升图形界面性能的工具包，主要用于带图形界面的发行版，对于命令行模式，可忽略。

```shell
sudo apt install openssh-server open-vm-tools
```

安装中文语言包，使操作系统能提供中文支持：

```shell
sudo apt install language-pack-zh-hans

# 在出现的界面中，通过上下键找到 zh_CN.UTF-8，按空格键选中它（前面会出现 * 号），然后按 Tab 键选择 <Ok> 并回车
# 在下一个界面中，选择 zh_CN.UTF-8 作为默认语言环境
sudo dpkg-reconfigure locales

# 编辑 ~/.bashrc 文件，在文件末尾添加以下两行，确保每次启动终端都强制使用中文环境
export LANG=zh_CN.UTF-8

# 使环境变量生效
source ~/.bashrc
```

> 注：虽然安装了中文包，但服务器的 tty 终端依然是不能显示中文的，这是因为系统的 tty 终端只能显示 ASCII 字符。虽然也有办法让 tty 终端显示中文，但比较麻烦，也完全没必要。最佳解决方案是：使用虚拟终端，如 putty、XShell、MobaXterm 等连接服务器即可，虚拟终端可以方便的设置 UTF-8 编码，事实上，绝大多数虚拟终端默认使用的就是 UTF-8 编码。另外，Ubuntu 桌面版，由于有图形界面，在图形界面内开启的模拟终端，不存在这个问题。

使用以下指令查看本地 ip 地址（ifconfig 已被弃用，如需使用，需安装 net-tools）：

```shell
#或者使用ip addr，或者ip a
ip addr show

#或者仅简略显示ip
hostname -I
```

查看网关：

```shell
ip route show
```

清空终端内容：

```shell
#使用clear清屏或使用快捷键Ctrl + L
clear
```

重启或关机：

```shell
reboot
poweroff
ls | more #分屏查看文件列表，使用空格键查看下一屏
```

Ubuntu 的默认初始 root 密码是随机的，即每次开机都有一个新的 root 密码。可以在终端输入命令 `sudo passwd` 来设置 root 用户密码。之后，就可以通过 `su root`，或者 `su -` 切换为 root 用户。

51. 设置 IP 地址及主机名

如果使用多台相同配置的虚拟机构建集群（通过复制），则必须手动指定 IP 地址及主机名，否则可能会出现网卡冲突、IP 地址冲突、主机名冲突等情况。

特别注意：如果想通过复制方式克隆多台主机，则在虚拟机启动时，一定要选择，**我复制了虚拟机**，而不要选择**我移动了虚拟机**。

> 注：在克隆虚拟机时，推荐通过 vmware 菜单，虚拟机->管理->克隆功能进行克隆。当然直接将整个虚拟机目录复制也可以，但是在启动虚拟机时，一定要选择“我复制了虚拟机”，这样才有克隆的效果。如果选择“我移动了虚拟机”，则会出现很多冲突问题。

（1）首先在虚拟机关闭状态下，修改网络适配器，点击高级。

<img src="./assets/image-20260604000814481.png" alt="image-20260604000814481" style="zoom:67%;" />

（2）在弹出的窗口中，点击生成，创建新的网卡虚拟 MAC 地址，以避免两个虚拟机的 MAC 地址相同。

<img src="./assets/image-20260604000857454.png" alt="image-20260604000857454" style="zoom:67%;" />

（3）启动虚拟机，进入终端，执行以下指令：

```bash
#查看当前ip地址，手动更改ip地址时，要在同一个局域网段。
ip addr

#查看网关
ip route 

#注意：网络配置文件名可能会不同。比如某些情况下为50-cloud-init.yaml
sudo vim /etc/netplan/00-installer-config.yaml  #手动更改ip配置。
```

网络配置文件名通常为 00-installer-config.yaml，某些情况下为 50-cloud-init.yaml，但二者只是文件名称的不同，在功能上、使用方式上完全相同。
默认配置为：

```yaml
# This is the network config written by 'subiquity'
network:
  ethernets:
    ens33:
      dhcp4: true
      dhcp6: true
      match:
        macaddress: 00:0c:29:2a:11:21
      set-name: ens33
  version: 2
```

虚拟机配置为桥接模式时，更改配置如下：

```yaml
 #桥接模式下  
 network:
   version: 2
   ethernets:
     ens33:
       dhcp4: false 				#不要自动分配ipv4的ip地址
       dhcp6: true
       match:
         macaddress: 00:0c:29:2a:11:21
       set-name: ens33
       addresses: [192.168.31.100/24]
       nameservers:
         addresses: [192.168.31.1] #设置DNS服务器地址，若不设置，则无法ping外网ip，DNS服务器可设置成网关地址或其它已知dns地址
       routes:
         - to: default
           via: 192.168.31.1 #设置网关地址
```

> 注：yaml 格式文档，前面的缩进，不能使用 tab，必须是空格。另外，冒号后面必须有一个空格，这是 yaml 格式规范。

修改完毕，保存并退出，执行下面的指令使配置生效：

```bash
sudo netplan apply

#检查ip地址修改是否生效
ip addr

#测试ping内网
ping 192.168.31.244

#测试ping外网
ping www.baidu.com
```

若 ping 不通外网，执行以下指令尝试：`sudo systemctl restart systemd-resolved`

（4）（可选）修改主机名。

修改 cloud.cfg 防止重启后主机名还原。

```shell
 sudo vim /etc/cloud/cloud.cfg
```

找到 preserve_hostname 配置项，将其值改为 true。

修改主机名

```shell
#其中snowpc1为自定义新主机名
sudo hostnamectl set-hostname snowpc01

#检测主机名更改是否生效
hostname
```

编辑`/etc/hosts`，配置 hosts

```shell
 sudo vim /etc/hosts
 
 #追加一行配置，ip地址需要跟刚才配置的对应。注意，将127.0.0.1也映射为新的主机名
 192.168.31.100 snowpc01
```

修改完毕，保存并退出，执行下面的指令使配置生效

```shell
 sudo netplan apply
```

52. 设置时区

使用指令`timedatectl`可查看当前时区及时间

```bash
timedatectl
```

显示结果如下：

<img src="./assets/image-20260604001925571.png" alt="image-20260604001925571" style="zoom:67%;" />

使用指令`timedatectl list-timezones`可查看所有时区。

使用指令`timedatectl set-timezone`可设置时区。

```shell
sudo timedatectl set-timezone Asia/Shanghai
```

> 注意：时区名称大小写不要写错。
