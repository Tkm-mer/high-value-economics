# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day02：IO 流 + 线程基础）

**总课时**：6 讲（其中 Day02 覆盖第 3 讲、第 4 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成 Day01（泛型 + 异常）
**参考教材**：`02-AI应用编程进阶/教材/chapters/03.md`（第 3 章 File 与 IO 流）、`04.md`（第 4 章 线程与并发（上））

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 3 讲 | File 与 IO 流 | 会用 `File`/`Path` 遍历目录；分清字节流 / 字符流 / 缓冲流；用对象序列化保存对象 |
| 第 4 讲 | 线程与并发（上） | 用 4 种方式启动线程；用 `synchronized` / `Lock` / 原子类解决共享变量安全；能上手 `Executors` 线程池 |

---

## 第 3 讲：File 与 IO 流

### 3.1 引入：File 只是"路径的名片"，不是文件内容

上一讲我们把异常搞定了，今天进入几乎所有实际项目都要用的 IO。先看一段代码给你打个预防针：

```java
File f = new File("D:/data/note.txt");
System.out.println(f.getName());     // 打印 note.txt —— 即使文件根本不存在
```

**划重点**：`new File(...)` 只是创建一个"路径信息对象"，它**不代表文件内容**，也不会去访问磁盘。它只描述路径、大小、修改时间——想读内容，必须用后面讲的 IO 流。

```mermaid
flowchart LR
    A[File 对象] --> B[路径信息]
    A --> C[元数据<br/>大小/时间/权限]
    A --> D[操作<br/>创建/删除/重命名/遍历]
    A -. 不包含 .-> E[❌ 文件内容]
```

#### File 的常用方法（一次背下来）

```java
File f = new File("D:/data/note.txt");

// 判断
f.exists();  f.isFile();  f.isDirectory();  f.canRead();  f.canWrite();

// 信息
f.getName();          // note.txt
f.getPath();          // D:/data/note.txt
f.getAbsolutePath();  // 绝对路径
f.length();           // 字节数
f.lastModified();     // 最后修改时间（毫秒）

// 操作
f.createNewFile();    // 创建空文件
f.delete();           // 删除
f.mkdir();            // 创建单层目录
f.mkdirs();           // 创建多层目录

// 遍历
for (File child : new File("D:/data").listFiles()) {
    System.out.println(child.getName());
}
```

#### 递归遍历一个目录

```java
public static void listAll(File dir, int depth) {
    if (dir == null || !dir.exists()) return;
    System.out.println("  ".repeat(depth) + dir.getName());
    if (dir.isDirectory()) {
        File[] children = dir.listFiles();
        if (children != null) {
            for (File c : children) listAll(c, depth + 1);
        }
    }
}
```

#### NIO 的 Path + Files（现代推荐）

`File` API 设计较老，Java 7 引入了 `java.nio.file.Path` + `Files`，写起来短得多：

```java
Path p = Path.of("D:/data/note.txt");
Files.exists(p);
Files.size(p);
Files.readString(p);                          // 一次读全部
Files.writeString(p, "hello");
Files.readAllLines(p);                        // 按行读
Files.createDirectories(Path.of("D:/data/out"));
Files.walk(Path.of("D:/data"))                // 惰性流式遍历
     .filter(Files::isRegularFile)
     .forEach(System.out::println);
```

**互动提问**：`Files.readString` 和 `BufferedReader.readLine()` 循环相比，哪个更适合读 500 MB 的日志文件？（答：**后者**。前者会一次性读进内存，大文件会 OOM。）

### 3.2 字节流：处理任意二进制

字节流处理**任意二进制数据**（图片、音频、视频、可执行文件）。抽象基类：

- `InputStream`：读入字节
- `OutputStream`：写出字节

常用具体类：

| 类 | 作用 |
|---|---|
| `FileInputStream` / `FileOutputStream` | 读写文件 |
| `ByteArrayInputStream` / `ByteArrayOutputStream` | 读写内存中的字节数组 |
| `BufferedInputStream` / `BufferedOutputStream` | 缓冲提速（见 3.4） |
| `ObjectInputStream` / `ObjectOutputStream` | 对象序列化（见 3.5） |

#### 单字节读写（仅示例，生产别用）

```java
try (
    FileInputStream  in  = new FileInputStream("src.png");
    FileOutputStream out = new FileOutputStream("dst.png")
) {
    int b;
    while ((b = in.read()) != -1) {   // 读到末尾返回 -1
        out.write(b);
    }
}
```

**为什么慢**：每读一个字节就是一次系统调用，复制一个 10 MB 的图片能跑好几秒。

#### 字节数组读写（推荐基本写法）

```java
try (
    FileInputStream  in  = new FileInputStream("src.png");
    FileOutputStream out = new FileOutputStream("dst.png")
) {
    byte[] buf = new byte[8192];
    int len;
    while ((len = in.read(buf)) != -1) {
        out.write(buf, 0, len);       // ⚠️ 一定要传 len，不能写整个 buf
    }
}
```

**划重点**：`out.write(buf, 0, len)`——最后一次 read 可能没读满 buf，多余字节会污染输出文件。

#### 一键复制（Java 9+）

```java
try (
    var in  = new FileInputStream("src.png");
    var out = new FileOutputStream("dst.png")
) {
    in.transferTo(out);               // 底层用 8 KB 缓冲自动搬运
}
```

### 3.3 字符流：处理文本 + 编码

#### 为什么必须有字符流

字节流按字节读写；处理**文本**时，一个中文字符在 UTF-8 下占 3 字节，很可能被拆到两次 `read()` 之间，造成**乱码**。字符流以 `char` 为单位、内置字符集，天生防乱码。

抽象基类：

- `Reader` / `Writer`

常用类：

| 类 | 作用 |
|---|---|
| `FileReader` / `FileWriter` | 文件字符读写 |
| `InputStreamReader` / `OutputStreamWriter` | **桥梁**：字节流转字符流（可指定编码） |
| `BufferedReader` / `BufferedWriter` | 缓冲字符流（`readLine` / `newLine`） |
| `PrintWriter` | 便捷写文本（`println` 等） |

#### 编码必须显式指定

`FileReader` 默认使用**平台编码**（Windows 下常是 GBK），跨机器就乱码。**应通过 `InputStreamReader` 显式指定 UTF-8**：

```java
try (
    Reader r = new InputStreamReader(new FileInputStream("note.txt"), StandardCharsets.UTF_8);
    Writer w = new OutputStreamWriter(new FileOutputStream("copy.txt"), StandardCharsets.UTF_8)
) {
    char[] buf = new char[1024];
    int len;
    while ((len = r.read(buf)) != -1) {
        w.write(buf, 0, len);
    }
}
```

#### 逐行读写（最常用）

```java
try (
    BufferedReader in  = new BufferedReader(new InputStreamReader(
        new FileInputStream("note.txt"), StandardCharsets.UTF_8));
    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
        new FileOutputStream("copy.txt"), StandardCharsets.UTF_8))
) {
    String line;
    while ((line = in.readLine()) != null) {
        out.write(line);
        out.newLine();                 // 跨平台换行
    }
}
```

#### 一行读写整个文件（Java 11+，小文件推荐）

```java
String text = Files.readString(Path.of("note.txt"), StandardCharsets.UTF_8);
Files.writeString(Path.of("copy.txt"), text, StandardCharsets.UTF_8);
```

### 3.4 缓冲流：性能翻天覆地

底层每次 `read()` / `write()` 都是**系统调用**，非常昂贵。缓冲流在内存中开一块字节 / 字符数组，尽量批量搬运：

```mermaid
flowchart LR
    A[程序] -- read/write --> B[Buffered流<br/>8KB 缓冲区]
    B -- 批量系统调用 --> C[底层流]
    C --> D[磁盘/网络]
```

一般能带来**数十倍**的吞吐提升。

#### 字节缓冲

```java
try (
    BufferedInputStream  in  = new BufferedInputStream(new FileInputStream("big.bin"));
    BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream("copy.bin"))
) {
    byte[] buf = new byte[8192];
    int len;
    while ((len = in.read(buf)) != -1) {
        out.write(buf, 0, len);
    }
}   // 关闭时自动 flush
```

#### 关于 `flush()` 与 try-with-resources

写缓冲流时数据可能**仍在缓冲区**，程序异常退出（未 close）会丢数据。要点：

- 显式 `flush()` 强制冲刷
- **try-with-resources** 关闭时自动 flush + close，是最佳实践

### 3.5 对象序列化：把 Java 对象存进文件

**序列化**：Java 对象 → 字节序列（可写入文件、网络传输）
**反序列化**：字节序列 → Java 对象

对象必须实现 `java.io.Serializable`（一个"标记接口"，没有方法）。

#### 完整示例

```java
public class User implements Serializable {
    private static final long serialVersionUID = 1L;   // 强烈建议显式声明
    private String name;
    private int    age;
    private transient String password;                 // transient：不序列化
    public User(String name, int age, String password) {
        this.name = name; this.age = age; this.password = password;
    }
    @Override public String toString() {
        return "User{name=" + name + ", age=" + age + ", password=" + password + "}";
    }
}
```

**写出对象**：

```java
try (var out = new ObjectOutputStream(new FileOutputStream("user.obj"))) {
    out.writeObject(new User("Tom", 20, "123456"));
}
```

**读回对象**：

```java
try (var in = new ObjectInputStream(new FileInputStream("user.obj"))) {
    User u = (User) in.readObject();
    System.out.println(u);   // password 为 null（transient 未存）
}
```

#### serialVersionUID 的作用（面试常考）

反序列化时 JVM 会比较**文件中的 UID** 与**当前类的 UID**：一致继续解析，不一致抛 `InvalidClassException`。

若不显式声明，JVM 自动生成 UID，任何字段/方法改动都会导致 UID 变化——**升级类结构后老数据就读不回来了**。所以每个 Serializable 类都建议显式：

```java
private static final long serialVersionUID = 1L;
```

#### 与 JSON 对比

| 特性 | Java 原生序列化 | JSON（Jackson / Gson） |
|---|---|---|
| 可读性 | 二进制不可读 | 文本可读 |
| 跨语言 | 不行 | 完美支持 |
| 性能 | 一般 | 通常更快 |
| 类结构变更容忍度 | 弱（依赖 UID） | 强 |
| 使用场景 | 老代码、RMI、本地缓存 | Web API、配置、跨服务通信 |

**建议**：新项目跨服务通信一律用 JSON；只有做 RMI 或本地缓存才考虑原生序列化。

### 3.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `out.write(buf)` 写多余字节 | 用 `out.write(buf, 0, len)`，`len` 是本次真实读到的字节数 |
| `FileReader` 读 UTF-8 中文乱码 | 默认平台编码；改用 `InputStreamReader + StandardCharsets.UTF_8` |
| 程序结束了文件是空的 | 缓冲流没 flush；用 try-with-resources 或显式 `flush()` |
| `Files.readString` 读 500 MB 日志 OOM | 大文件必须流式 `BufferedReader.lines()` / `Files.lines()` |
| 反序列化抛 `InvalidClassException` | 类改过又没写死 UID；每个 Serializable 类都要 `private static final long serialVersionUID = 1L` |
| 密码字段被序列化到文件 | 加 `transient` |
| 用 `File.mkdir()` 建多层目录失败 | 用 `mkdirs()`（有 s）；单层用 `mkdir()` |
| 忘记 `close`，文件句柄泄漏 | 永远用 try-with-resources |

### 3.7 练习/思考

1. 用 `File` 遍历指定目录，统计其中所有 `.java` 文件的行数总和。
2. 复制一张图片 `src.png` 到 `dst.png`，用 `BufferedInputStream` + `BufferedOutputStream`，并用 `System.currentTimeMillis()` 测量耗时；再改用 `transferTo` 对比。
3. 用 `BufferedReader` 按行读入 `words.txt`（每行一个单词），统计每个单词出现次数（用 `Map<String, Integer>`），把结果写入 `stat.txt`。
4. 定义 `Employee(String name, double salary, transient String password)`，序列化到文件，再反序列化并 `toString()`，观察 `password` 的值。
5. 说明 `flush()` 与 `close()` 的关系，为什么 try-with-resources 通常不需要显式调用 `flush`？
6. **拓展**：写一个方法 `long copy(File src, File dst)`，返回复制的字节数，并支持覆盖已有文件；对空文件、只读文件、目标路径不存在等场景做健壮性处理。

---

## 第 4 讲：线程与并发（上）

### 4.1 引入：一个应用为什么需要多个线程

我们上午写的 IO 都是**单线程串行**的：读完 A 再读 B。但真实项目里：

- 用户点击按钮下载 10 个文件——串行下要 10 倍时间
- 服务器处理 100 个客户端请求——串行意味着第 100 个人要等前 99 个
- 主线程渲染 UI，业务算力放子线程——不然界面会**卡死**

这就要引入**多线程**。

#### 进程 vs 线程（必背对比）

| 概念 | 说明 |
|---|---|
| 进程（Process） | 操作系统资源分配的最小单位，拥有独立地址空间。例如"一个 QQ.exe" |
| 线程（Thread） | CPU 调度的最小单位，同一进程内的多个线程**共享地址空间和资源** |

```mermaid
flowchart TB
    subgraph 进程A[进程 A]
        T1[线程 1<br/>栈]
        T2[线程 2<br/>栈]
        T3[线程 3<br/>栈]
        H[共享的堆内存]
    end
    T1 --- H
    T2 --- H
    T3 --- H
```

**划重点**：**栈 / 程序计数器**每线程独占；**堆 / 方法区**全进程共享。共享堆是效率来源，也是所有线程安全问题的根源。

#### Java 的主线程

每次 `java MyApp` 启动，JVM 都会创建一个 **main 线程** 来执行 `main` 方法：

```java
public class Main {
    public static void main(String[] args) {
        Thread t = Thread.currentThread();
        System.out.println("线程名 = " + t.getName());       // main
        System.out.println("是否守护 = " + t.isDaemon());    // false
    }
}
```

### 4.2 实现线程的 4 种方式

```mermaid
flowchart LR
    A[实现线程] --> B[1️⃣ 继承 Thread]
    A --> C[2️⃣ 实现 Runnable]
    A --> D[3️⃣ Callable + FutureTask]
    A --> E[4️⃣ 线程池]
```

#### 方式一：继承 Thread

```java
public class MyThread extends Thread {
    @Override public void run() {
        System.out.println("子线程运行：" + getName());
    }
}
new MyThread().start();       // ⚠️ 一定要用 start(), 不能直接 run()
```

**互动提问**：如果不小心写成 `t.run()` 会发生什么？（答：只是普通方法调用，还是在 main 线程执行，**根本没启动新线程**。这是初学者第一大坑。）

#### 方式二：实现 Runnable（推荐）

```java
public class MyTask implements Runnable {
    @Override public void run() {
        System.out.println("任务运行：" + Thread.currentThread().getName());
    }
}

new Thread(new MyTask(), "worker-1").start();

// Lambda 一步到位（最常用写法）
new Thread(() -> System.out.println("Lambda 任务"), "worker-2").start();
```

**为什么优于继承 Thread**：

- Java 单继承，继承 Thread 就不能再继承别的类
- 任务（Runnable）和执行器（Thread / 线程池）**解耦**，可复用
- 更符合面向接口编程

#### 方式三：Callable + FutureTask（要返回值）

`Runnable` 无返回值、不能抛受检异常；`Callable` 弥补了这两点：

```java
Callable<Integer> task = () -> {
    Thread.sleep(1000);
    return 42;
};

FutureTask<Integer> future = new FutureTask<>(task);
new Thread(future, "compute").start();

Integer result = future.get();     // 阻塞等待结果
System.out.println("结果 = " + result);
```

`Future` 常用方法：

| 方法 | 说明 |
|---|---|
| `get()` | 阻塞直到有结果 |
| `get(timeout, unit)` | 有超时的阻塞获取 |
| `cancel(boolean)` | 取消任务 |
| `isDone()` | 是否已完成 |

#### 方式四：线程池（生产首选，第 5 讲详解）

```java
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(() -> System.out.println("hi"));
pool.shutdown();
```

#### Thread 常用 API 一览

| 方法 | 说明 |
|---|---|
| `start()` | 启动线程 |
| `sleep(ms)` | 让当前线程休眠，**不释放锁** |
| `join()` | 等这个线程结束，我再往下走 |
| `interrupt()` | 中断线程（协作式） |
| `isInterrupted()` | 是否被打过中断标记 |
| `setDaemon(true)` | 设置守护线程（跟随主线程退出） |
| `setName(String)` | 名字（务必设有意义的名字，方便排查线程堆栈） |

### 4.3 线程安全问题的 4 种解法

#### 问题的根源

多个线程访问同一份可变数据，没有正确同步会结果错乱。经典例子——两个线程各加 10000 次：

```java
public class Counter {
    private int count = 0;
    public void increment() { count++; }
    public int  get()       { return count; }
}

Counter c = new Counter();
Runnable task = () -> { for (int i = 0; i < 10000; i++) c.increment(); };
Thread t1 = new Thread(task); Thread t2 = new Thread(task);
t1.start(); t2.start();
t1.join();  t2.join();
System.out.println(c.get());   // 期望 20000，实际经常 < 20000
```

**根本原因**：`count++` **不是原子操作**，等价于 3 步：

```text
1. 读 count 到 CPU
2. 加 1
3. 写回内存
```

3 步之间可以被别的线程插入，导致丢失更新。

#### 方案一：`synchronized`

保证**同一时刻只有一个线程能进入同步块**，其他线程排队等待。

```java
// 同步方法
public synchronized void increment() { count++; }

// 同步代码块（推荐，粒度更小）
private final Object lock = new Object();
public void increment() {
    synchronized (lock) { count++; }
}
```

**静态同步方法** 的锁是**类对象** `Counter.class`。

#### 方案二：`ReentrantLock`

更灵活的显式锁：

```java
private final Lock lock = new ReentrantLock();
public void increment() {
    lock.lock();
    try { count++; }
    finally { lock.unlock(); }        // ⚠️ 一定要放 finally
}
```

比 `synchronized` 强在：

- `tryLock()` / `tryLock(timeout, unit)`——**尝试**加锁，避免死锁
- `lockInterruptibly()`——可中断加锁
- `new ReentrantLock(true)`——公平锁
- `newCondition()`——多个条件变量，细粒度的 wait/notify

#### 方案三：原子类（性能最好）

`java.util.concurrent.atomic` 包基于 CAS 无锁，通常比 `synchronized` 快：

```java
private final AtomicInteger count = new AtomicInteger(0);
public void increment() { count.incrementAndGet(); }
```

常用：`AtomicInteger`、`AtomicLong`、`AtomicBoolean`、`AtomicReference<T>`、`LongAdder`（高并发累加更快）。

#### 方案四：并发集合

- `Collections.synchronizedList(list)`：给普通集合套上同步壳
- `ConcurrentHashMap`：分段锁，比 `Hashtable` 快很多
- `CopyOnWriteArrayList`：读多写少场景

**划重点**：**永远不要在多线程共享的场景直接用 `ArrayList` / `HashMap`**。

#### 死锁的直观例子

```java
Object A = new Object(), B = new Object();
new Thread(() -> { synchronized (A) { sleep(100); synchronized (B) {} } }).start();
new Thread(() -> { synchronized (B) { sleep(100); synchronized (A) {} } }).start();
```

两个线程互相持有对方需要的锁——永远卡住。**避免死锁的经验**：所有线程按同一顺序获取锁，能用 `tryLock` 就用 `tryLock`。

### 4.4 线程池入门

#### 为什么需要线程池

"每来一个任务 new 一个线程"有 4 大问题：

1. **创建/销毁开销大**：线程是操作系统资源
2. **数量不可控**：任务爆发时开几千个线程直接 OOM
3. **管理困难**：没法统一 shutdown / 监控 / 限流
4. **无法复用**：每个线程执行完就没了

线程池的核心思想：**预先创建一批线程，任务到来时复用**。

```mermaid
flowchart LR
    T[任务队列] --> P[线程池]
    P --> W1[Worker 1]
    P --> W2[Worker 2]
    P --> W3[Worker 3]
    W1 --> R[执行]
    W2 --> R
    W3 --> R
```

#### Executors 快速创建（教学用）

```java
ExecutorService fixed  = Executors.newFixedThreadPool(4);       // 固定大小
ExecutorService cached = Executors.newCachedThreadPool();       // 弹性大小
ExecutorService single = Executors.newSingleThreadExecutor();   // 单线程
ScheduledExecutorService sched = Executors.newScheduledThreadPool(2);
```

**⚠️ 生产不推荐 `Executors` 的默认工厂**：内部队列或线程数**无界**，容易 OOM。生产用第 5 讲的 `ThreadPoolExecutor` 自建。

#### 提交任务的两种方式

```java
pool.execute(() -> System.out.println("hi"));   // Runnable、无返回值
Future<Integer> f = pool.submit(() -> 1 + 1);   // Callable、有返回值
Integer r = f.get();
```

#### 关闭线程池（规范）

```java
pool.shutdown();     // 拒绝新任务，把已提交任务跑完
pool.shutdownNow();  // 尝试立即中断所有任务
pool.awaitTermination(10, TimeUnit.SECONDS);
```

**规范用法**：

```java
ExecutorService pool = Executors.newFixedThreadPool(4);
try {
    pool.submit(...);
} finally {
    pool.shutdown();
    if (!pool.awaitTermination(30, TimeUnit.SECONDS)) {
        pool.shutdownNow();
    }
}
```

#### 完整例子：并发下载

```java
public class DownloadDemo {
    public static void main(String[] args) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(3);
        List<String> urls = List.of("A", "B", "C", "D", "E", "F");

        List<Future<String>> futures = new ArrayList<>();
        for (String url : urls) {
            futures.add(pool.submit(() -> {
                Thread.sleep(500);
                return "已下载 " + url + " by " + Thread.currentThread().getName();
            }));
        }
        for (Future<String> f : futures) System.out.println(f.get());
        pool.shutdown();
    }
}
```

### 4.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 写 `t.run()` 不起新线程 | 那是普通方法调用，必须 `t.start()` |
| 一个 Thread `start()` 两次抛异常 | Thread 是一次性对象，用完就废；再启动请 new 新的或用线程池 |
| 主线程结束但 JVM 不退出 | 有非 daemon 线程还在跑；子线程 `setDaemon(true)` 或显式 shutdown 池 |
| `count++` 加 `synchronized` 但 `get()` 没加 | 读也要同步，或用 `AtomicInteger`；否则可能读到过期值 |
| `lock.lock()` 后异常没释放 | 必须 `try { ... } finally { lock.unlock(); }` |
| ArrayList 多线程 add 抛 CME | 换 `Collections.synchronizedList` 或 `CopyOnWriteArrayList` |
| `Executors.newCachedThreadPool` 生产 OOM | 无界线程数；生产用 `new ThreadPoolExecutor(...)` |
| `pool.shutdown()` 后 `submit` 抛 RejectedExecutionException | shutdown 后不再接收新任务；调整代码顺序 |
| 线程名默认 `Thread-0/1/2`，出问题排查难 | `new Thread(task, "worker-1")` 起有意义的名字 |
| 死锁 | 所有线程按同一顺序获取锁；能 `tryLock` 就 `tryLock` |

### 4.6 练习/思考

1. 分别用**继承 Thread**、**实现 Runnable**、**Lambda + Thread** 三种方式启动一个线程，打印当前线程名。
2. 编写代码验证 `t.run()` 与 `t.start()` 的区别（打印当前线程名即可看出）。
3. 用 `Callable + FutureTask` 计算 `1 + 2 + ... + 100`，主线程打印结果。
4. 修复 4.3 节的 `Counter`：分别用 `synchronized` 与 `AtomicInteger` 两种方案，运行验证结果稳定为 20000。
5. 使用 `Executors.newFixedThreadPool(3)` 并发下载 6 个 URL（`Thread.sleep` 模拟耗时），保证线程池被正确关闭。
6. **拓展**：以下代码有隐蔽 bug，请分析并修复：
   ```java
   ExecutorService pool = Executors.newFixedThreadPool(2);
   pool.submit(() -> { throw new RuntimeException("boom"); });
   pool.shutdown();
   ```
   （提示：`execute` 与 `submit` 对异常的处理方式不同；`submit` 返回的 `Future` 里藏着异常，不 `get()` 就永远看不到。）

---

## 本日收束

### 承前启后

- **第 3 讲 IO 流**——上午让你能操作**磁盘上的持久数据**：字节流 / 字符流 / 缓冲 / 序列化 / NIO.2 现代 API。IO 是 Java 与外部世界（文件、网络、进程）交换数据的唯一通道。
- **第 4 讲 线程基础**——下午让你能**并发处理任务**：`Thread` / `Runnable` / `Callable` / 线程池 / 同步。线程是 Java 让 CPU 多核干活的入口。

这两块看似独立，其实明天会**合流**——线程池负责调度，反射负责识别，IO 负责数据出入，加起来就是 Spring / MyBatis / Netty 这些框架的底座。

### 6 天旅程中的定位

| Day | 主题 | 今日贡献 |
|---|---|---|
| 01 | 泛型 + 异常 | 打地基：类型系统 + 错误处理 |
| **02** | **IO + 线程基础** | **打地基：数据 I/O + 并发起点** |
| 03 | 线程进阶 + 反射 | 用今天的线程池深入到"线程编排 + 类元数据" |
| 04 | 注解 + 集合精讲 | 注解 = 元数据；集合 = 数据结构 |
| 05 | 数据结构 + 内部类接口 | 集合的底层原理 |
| 06 | Lambda/Stream + Optional/日期 | 声明式数据处理 |

### 作业

1. **必做**：第 3 讲、第 4 讲末尾练习各选做 3 道，特别是 `Counter` 修复（`synchronized` 版 + `AtomicInteger` 版）和线程池下载。
2. **拓展**：任选一道拓展题深入完成。
3. **提交**：代码提交到 `ai-programming-advanced/day02/`，README 说明 `execute` 与 `submit` 处理异常的差异。

---

[⬅️ Day01](day01.md) | [返回目录](../教材/目录.md) | [Day03 ➡️](day03.md)
