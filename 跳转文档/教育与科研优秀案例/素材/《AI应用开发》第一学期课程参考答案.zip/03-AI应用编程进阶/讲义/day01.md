# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day01：泛型 + 异常）

**总课时**：6 讲（其中 Day01 覆盖第 1 讲、第 2 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成《AI 应用编程基础——Java 基础》的大学生 / 有 Java 基础的编程学习者
**参考教材**：`02-AI应用编程进阶/教材/chapters/01.md`（第 1 章 泛型）、`02.md`（第 2 章 异常处理）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 泛型 | 会写泛型类 / 接口 / 方法；掌握 `? extends T` / `? super T` 与 PECS；理解类型擦除的 5 项限制 |
| 第 2 讲 | 异常处理 | 熟练 `try-catch-finally` 与 try-with-resources；分清 `throw`/`throws`；能设计带 cause 的自定义业务异常 |

---

## 第 1 讲：泛型

### 1.1 引入：Java 5 之前的容器为什么危险

同学们，我们先看一段"上古 Java 代码"，看完你就明白泛型为什么必须存在：

```java
// Java 5 之前的写法
List list = new ArrayList();
list.add(1);
list.add("hello");                       // 编译器完全不管
Integer x = (Integer) list.get(1);       // 运行到这一行才炸：ClassCastException
```

三个痛点一次显现：

- **不安全**：`add("hello")` 编译期不报错，运行到 `get(1)` 才崩，问题现场往往和 bug 源头隔了十万八千里
- **不方便**：每次取值都要强转，代码噪声一大堆
- **不清晰**：读代码时看不出 `List` 里到底装了什么

**泛型（Generics）** 是 JDK 5 引入的语言特性，本质是**参数化类型**——把"类型"作为参数传给类 / 接口 / 方法，让编译器**在编译期**就把类型错误挡在门外：

```java
List<Integer> list = new ArrayList<>();
list.add(1);
// list.add("hello");                    // ✗ 编译不通过！问题永远进不了运行时
Integer x = list.get(0);                 // 不用强转
```

**划重点**：`<Integer>` 是编译期契约。装错东西编译期就报错；取出东西不用强转。这就是泛型的 KPI。

**泛型的三大好处**（考试可能考）：

```mermaid
flowchart LR
    A[泛型的好处] --> B[编译期类型检查<br/>提前发现错误]
    A --> C[避免强制类型转换<br/>代码更简洁]
    A --> D[代码复用<br/>一份实现支持多种类型]
```

**类型参数的命名约定**（团队规范，跟着写就行）：

| 名称 | 含义 |
|---|---|
| `T` | Type，一般类型 |
| `E` | Element，元素（多用于集合） |
| `K` / `V` | Key / Value，键值对 |
| `R` | Result / Return，返回值 |
| `N` | Number，数字 |

### 1.2 泛型类、泛型接口、泛型方法

#### 泛型类

**语法**：

```java
public class Box<T> {          // T 是类型参数，写在类名后
    private T content;
    public void set(T content) { this.content = content; }
    public T get() { return content; }
}

Box<String> box = new Box<>();  // 指定 T = String，右边 <> 是钻石运算符（Java 7+）
box.set("hello");
String s = box.get();
```

**多类型参数**——键值对容器：

```java
public class Pair<K, V> {
    private final K key;
    private final V value;
    public Pair(K key, V value) { this.key = key; this.value = value; }
    public K getKey()   { return key; }
    public V getValue() { return value; }
}

Pair<String, Integer> age = new Pair<>("Tom", 20);
Pair<Long, String>    log = new Pair<>(1732848000L, "AI 应用编程进阶——Java 进阶");
```

#### 泛型接口

```java
public interface Repository<ID, T> {
    T findById(ID id);
    void save(T entity);
    void deleteById(ID id);
}

// 实现时指定具体类型
public class UserRepository implements Repository<Long, User> {
    @Override public User findById(Long id) { /* ... */ return null; }
    @Override public void save(User entity) { /* ... */ }
    @Override public void deleteById(Long id) { /* ... */ }
}
```

也可以在实现类中继续把泛型往下传（写通用工具库时很常见）：

```java
public class MemoryRepository<ID, T> implements Repository<ID, T> {
    private final Map<ID, T> store = new HashMap<>();
    @Override public T findById(ID id) { return store.get(id); }
    @Override public void save(T entity) { /* 略 */ }
    @Override public void deleteById(ID id) { store.remove(id); }
}
```

#### 泛型方法

**关键点**：泛型方法在**方法签名的返回值前**声明自己的 `<T>`，**独立于类**——静态方法也能用。

```java
public class Utils {
    public static <T> void swap(T[] arr, int i, int j) {
        T tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }
}

Integer[] a = {1, 2, 3};
Utils.swap(a, 0, 2);         // {3, 2, 1}
String[] s = {"x", "y", "z"};
Utils.swap(s, 0, 1);         // {"y", "x", "z"}
```

**类型推断**——编译器根据参数自动推断：

```java
public static <E> Set<E> toSet(List<E> list) { return new HashSet<>(list); }
Set<String> set = Utils.toSet(List.of("a", "b", "a"));   // 编译器自动推断 E = String
```

#### 泛型类 vs 泛型方法（对比表）

| 对比项 | 泛型类 | 泛型方法 |
|---|---|---|
| 类型参数声明位置 | 类名后 `class Box<T>` | 方法返回值前 `<T> void swap(...)` |
| 生效范围 | 整个类 | 单个方法 |
| 何时确定类型 | 创建对象 `new Box<String>()` | 调用方法时由参数推断 |
| 静态方法能否使用 | 类上的 `T` **不能**用在静态方法 | 静态方法可以定义自己的 `<T>` |

**互动提问**：把上面那个 `swap` 里的 `static <T>` 中的 `<T>` 拿掉，编译器会怎么骂人？（答：`T cannot be resolved to a type`。因为类上没有 `T`，静态方法必须自己声明。）

### 1.3 通配符与 PECS 原则

先记一条前提：`List<Object>` **不是** `List<String>` 的父类型，两者之间**没有**继承关系。这和数组的协变（`Object[] = String[]` 合法）不一样。要表达"任意 List 的父类型"，必须用通配符 `?`。

#### 无界通配符 `?`

```java
public static void printAll(List<?> list) {   // 任意 List 都能传
    for (Object item : list) {
        System.out.println(item);
    }
}
printAll(List.of(1, 2, 3));
printAll(List.of("a", "b"));
```

#### 有界类型参数 `<T extends X>`（定义处）

```java
// T 必须是 Number 或 Number 的子类
public class NumberBox<T extends Number> {
    private T value;
    public NumberBox(T value) { this.value = value; }
    public double doubleValue() { return value.doubleValue(); }
}
NumberBox<Integer> a = new NumberBox<>(10);     // ✅
NumberBox<Double>  b = new NumberBox<>(3.14);   // ✅
// NumberBox<String> c = new NumberBox<>("x");  // ❌
```

多个上限用 `&` 连接（**类必须写在最前**）：

```java
public class Sorter<T extends Comparable<T> & Serializable> { /* 略 */ }
```

#### 上界通配符 `? extends T`（使用处 — 只读）

```java
// 求所有数字之和（可传 List<Integer>、List<Double>、List<Long> ...）
public static double sum(List<? extends Number> list) {
    double s = 0;
    for (Number n : list) { s += n.doubleValue(); }
    return s;
}
```

**注意**：`? extends Number` 的 list **不能 add**（除了 `null`），因为编译器不知道传进来的到底是 `List<Integer>` 还是 `List<Double>`。

#### 下界通配符 `? super T`（使用处 — 只写）

```java
public static void addIntegers(List<? super Integer> list) {
    list.add(1);
    list.add(2);
    // Integer x = list.get(0);   // ❌ 取出来只能视为 Object
}
List<Number> nums = new ArrayList<>(); addIntegers(nums);  // ✅
List<Object> objs = new ArrayList<>(); addIntegers(objs);  // ✅
```

#### PECS 原则（面试常考）

> **Producer Extends, Consumer Super** —— 生产者 `extends`，消费者 `super`

- 集合作为**数据源（Producer，往外拿）**：只读——用 `? extends T`
- 集合作为**数据槽（Consumer，往里放）**：只写——用 `? super T`
- 既读又写：直接用 `T`，不加通配符

```mermaid
flowchart LR
    A[需求] --> B{对集合做什么}
    B -->|只读取元素| C["? extends T<br/>（Producer）"]
    B -->|只放入元素| D["? super T<br/>（Consumer）"]
    B -->|既读又写| E["T<br/>（不用通配符）"]
```

**口诀**：**"出去 extends，进来 super"**——记住这 8 个字，`Collections.copy(dest, src)` 的签名 `<T> void copy(List<? super T> dest, List<? extends T> src)` 你就一眼看懂了。

### 1.4 泛型擦除与常见陷阱

#### 什么是擦除

Java 泛型只在**编译期**存在。编译后，类型参数会被"擦除"为其上限（无上限则擦为 `Object`），运行时并不知道泛型类型：

```java
// 源码
class Box<T> { T get() { ... } }

// 编译后 (概念上)
class Box    { Object get() { ... } }

// 有上限时
class NumberBox<T extends Number> { T get() { ... } }
class NumberBox                   { Number get() { ... } }
```

**用一行代码验证**（你可以立刻在 IntelliJ IDEA（下简称 IDEA） 里跑）：

```java
List<String>  ls = new ArrayList<>();
List<Integer> li = new ArrayList<>();
System.out.println(ls.getClass() == li.getClass());  // true！运行时是同一个 Class
```

#### 擦除带来的 5 项硬性限制

| 限制 | 原因 | 错误示例 |
|---|---|---|
| 不能用基本类型 | 擦除后是 Object | `Box<int>` ❌，`Box<Integer>` ✅ |
| 不能创建泛型数组 | 数组要在运行时知道元素类型 | `new T[10]` ❌ |
| 不能对泛型 `instanceof` | 运行时类型信息已丢失 | `x instanceof Box<String>` ❌ |
| 不能 `.class` | 同上 | `Box<String>.class` ❌ |
| 静态字段 / 静态方法不能用类的类型参数 | 静态成员属于类本身 | `static T value;` ❌ |

外加一条：**泛型异常类型不允许**——`class MyEx<T> extends Exception` ❌，异常表机制不支持泛型。

#### 三个高频陷阱

**陷阱 1**：把 `List<Integer>` 赋给 `List<Number>`

```java
List<Integer> ints = new ArrayList<>();
// List<Number> nums = ints;             // ❌ 编译错误
List<? extends Number> nums = ints;      // ✅ 用上界通配符
```

**陷阱 2**：向 `? extends T` 里 add

```java
void bad(List<? extends Number> list) {
    // list.add(1);      // ❌ 编译器不知道 list 到底是 List<Integer> 还是 List<Double>
    // list.add(1.1);    // ❌ 同理
}
```

**陷阱 3**：数组与泛型不兼容

```java
List<String>[] arr  = new List<String>[10];  // ❌ 编译错误
List<String>[] arr2 = new List[10];          // ⚠️ 编译警告：unchecked（能过，但不推荐）
```

### 1.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 定义时 `class Box<T>` 静态方法直接用 `T` | 类的 `T` 属于实例；静态方法必须自己声明 `static <T> ...` |
| `List<Object> = List<String>` 编译失败 | 泛型不协变；要"任意 List"请用 `List<?>` |
| `List<? extends T>` 里可以随便 add | 错。除了 `null` 什么都不能 add；只能读 |
| 反射看不到 `List<String>` 的 String | 类型擦除，运行时只有 `List`；要拿真类型需 `ParameterizedType` |
| `catch (T e)` 编译失败 | 异常表不支持泛型，改用 `catch (Exception e)` 后判断 |
| 忘记加 `<>` | Java 7+ 支持钻石运算符，右侧 `new ArrayList<>()` 就够 |

### 1.6 练习/思考

1. 定义一个泛型类 `Result<T>`，表示一次调用的结果，包含 `boolean success`、`T data`、`String message`，并提供 `ok(T data)`、`fail(String message)` 两个静态工厂方法（提示：静态方法要自己声明 `<T>`）。
2. 编写泛型方法 `<T extends Comparable<T>> T max(List<T> list)`，返回列表中的最大元素；空列表抛 `IllegalArgumentException`。
3. 下面两个方法签名有什么区别？分别在什么场景使用？
   ```java
   static <T extends Number> double sum(List<T> list);
   static double sum(List<? extends Number> list);
   ```
4. 解释以下代码为什么编译错误，并给出**两种**修复方案：
   ```java
   List<? extends Number> list = new ArrayList<>();
   list.add(1);
   ```
5. 泛型擦除导致 `new T[10]` 无法编译，请说出至少一种可用的替代方案（提示：`Array.newInstance`）。
6. **拓展**：实现一个简单的 `Cache<K, V>`，内部用 `HashMap<K, V>`，对外提供 `put / get / remove / size / clear`，并写一份 JUnit 5 测试。

---

## 第 2 讲：异常处理

### 2.1 引入：一个越界读取如何毁掉整个程序

先看一段"没有异常处理"的代码：

```java
public static void main(String[] args) {
    int[] arr = {1, 2, 3};
    System.out.println(arr[10]);    // 抛异常
    System.out.println("done");     // 不会执行
}
```

运行结果：

```text
Exception in thread "main" java.lang.ArrayIndexOutOfBoundsException: Index 10 out of bounds for length 3
    at Demo.main(Demo.java:3)
```

**异常（Exception）** 就是程序运行时发生的、破坏正常流程的事件。它一旦发生又没被处理，JVM 就打印堆栈、终止线程。今天这一讲要解决的核心问题就是：**怎么让程序在异常发生时还能优雅地活下去**。

#### Java 异常体系

```mermaid
classDiagram
    class Throwable
    class Error
    class Exception
    class RuntimeException
    class IOException
    class NullPointerException
    class ClassCastException
    class ArithmeticException

    Throwable <|-- Error
    Throwable <|-- Exception
    Exception <|-- RuntimeException
    Exception <|-- IOException
    RuntimeException <|-- NullPointerException
    RuntimeException <|-- ClassCastException
    RuntimeException <|-- ArithmeticException
```

三个关键节点必须分清：

| 类型 | 说明 | 处理方式 |
|---|---|---|
| `Error` | JVM 层的严重错误，如 `OutOfMemoryError`、`StackOverflowError` | 一般**不处理**，让程序失败 |
| `Exception`（受检异常） | 编译器强制处理，如 `IOException`、`SQLException` | **必须** try-catch 或 throws |
| `RuntimeException`（非受检异常） | 程序 bug 类，如 `NullPointerException`、`IllegalArgumentException` | **可选**处理，通常应通过修复代码消除 |

**互动提问**：你写 `Integer.parseInt("abc")` 抛 `NumberFormatException`，需要 try-catch 吗？（答：**不需要**，它是 `RuntimeException` 的子类；但业务上你应该处理，否则用户输入一个"abc"程序就崩了。）

#### 常见运行时异常速查（背下来）

| 异常 | 触发场景 |
|---|---|
| `NullPointerException` | 调用 null 引用的成员 |
| `ArrayIndexOutOfBoundsException` | 数组下标越界 |
| `ClassCastException` | 类型转换失败 |
| `NumberFormatException` | 字符串转数字失败 |
| `ArithmeticException` | 除零等算术错误 |
| `IllegalArgumentException` | 方法参数非法 |
| `IllegalStateException` | 对象状态非法（未初始化 / 已关闭） |
| `ConcurrentModificationException` | 迭代时并发修改集合 |

### 2.2 try-catch-finally 与 try-with-resources

#### 基本语法

```java
try {
    // 可能抛异常的代码
} catch (异常类型1 e1) {
    // 处理 1
} catch (异常类型2 e2) {
    // 处理 2
} finally {
    // 无论是否异常都会执行，通常用于释放资源
}
```

#### 完整示例

```java
public class DivideDemo {
    public static void main(String[] args) {
        try {
            int r = 10 / 0;
            System.out.println("结果 = " + r);            // 不会执行
        } catch (ArithmeticException e) {
            System.out.println("除零错误：" + e.getMessage());
        } finally {
            System.out.println("清理工作 —— 一定会执行");
        }
        System.out.println("继续后续流程");
    }
}
```

输出：

```text
除零错误：/ by zero
清理工作 —— 一定会执行
继续后续流程
```

#### 多个 catch 分支的顺序规则

**从上到下匹配，子类必须写在父类之前**，否则子类分支永远进不去，编译器会报错。

```java
try {
    // ...
} catch (FileNotFoundException e) {         // 子类
    System.out.println("文件不存在");
} catch (IOException e) {                   // 父类
    System.out.println("IO 错误");
} catch (Exception e) {                     // 更大的父类
    System.out.println("其他异常");
}
```

#### 多重捕获（multi-catch，Java 7+）

```java
try {
    // ...
} catch (IOException | SQLException e) {
    // 注意：e 只能当作二者的公共父类来用
    System.err.println("IO 或数据库异常：" + e.getMessage());
}
```

#### finally 的执行时机与坑

`finally` 除以下情况外**都会执行**：

- `try/catch` 之前 JVM 崩溃（`System.exit(0)` 或断电）
- 当前线程被强制中断并杀死

**最经典的坑**：`finally` 里 return / throw 会**覆盖**掉 try / catch 里的 return / throw：

```java
static int weird() {
    try {
        return 1;
    } finally {
        return 2;               // 最终返回 2！1 被吞掉！
    }
}
```

**划重点**：**⚠️ 生产代码永远不要在 `finally` 里 `return`。**

#### try-with-resources（现代 Java 的默认写法）

Java 7 引入。任何实现 `AutoCloseable` 接口的资源都可以放在 `try(...)` 头部，JVM **自动调用 `close()`**，你再也不用写 finally 关流：

```java
try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
    String line;
    while ((line = reader.readLine()) != null) {
        System.out.println(line);
    }
} catch (IOException e) {
    e.printStackTrace();
}
// reader 一定被关闭，即使发生异常
```

**多资源**——按声明相反顺序关闭：

```java
try (
    InputStream  in  = new FileInputStream("src.txt");
    OutputStream out = new FileOutputStream("dst.txt")
) {
    in.transferTo(out);
}
```

**下一讲（第 3 讲 IO 流）里所有的读写代码都会用 try-with-resources，请把这个语法记牢**。

### 2.3 throw vs throws：一字之差，天壤之别

#### `throw`：主动抛出异常（动词）

`throw` 在**方法体内**使用，抛出一个具体的异常**对象**。

```java
public void setAge(int age) {
    if (age < 0 || age > 150) {
        throw new IllegalArgumentException("age 必须在 0~150 之间：" + age);
    }
    this.age = age;
}
```

#### `throws`：声明可能抛出的异常（形容词）

`throws` 在**方法签名上**使用，告诉调用者"我可能抛这些异常，请你处理"。

```java
public void readConfig(String path) throws IOException {
    Files.readString(Path.of(path));    // readString 声明抛 IOException
}
```

调用者有两种选择——**继续 throws** 或 **就地 try-catch**：

```java
// 1. 继续 throws（把责任向上抛）
public void start() throws IOException { readConfig("app.yml"); }

// 2. 就地 try-catch
public void start() {
    try { readConfig("app.yml"); }
    catch (IOException e) { System.err.println("配置读取失败"); }
}
```

#### 对比表（背下来）

| 对比项 | `throw` | `throws` |
|---|---|---|
| 位置 | 方法体内 | 方法签名上 |
| 后跟 | 异常**对象** | 异常**类型**（可多个） |
| 作用 | 立刻抛出 | 声明可能抛出 |
| 是否执行 | 一定执行到 | 只是声明 |

#### 异常链——保留 cause 是纪律

在捕获异常并抛新异常时，**要保留原始 cause**，否则丢失调试线索，出 bug 你根本查不到根：

```java
try {
    // ...
} catch (IOException e) {
    throw new BusinessException("加载配置失败", e);        // ✅ 传入原始异常作为 cause
    // throw new BusinessException("加载配置失败");        // ❌ 丢失 cause
}
```

### 2.4 自定义异常与最佳实践

#### 什么时候值得自定义

- **业务语义清晰**：`UserNotFoundException` 比 `RuntimeException("user not found")` 好读一万倍
- **需要携带额外字段**：如 errorCode、请求 ID
- **需要与框架配合**：Spring 通过异常类型选择错误响应；MyBatis 通过异常判断事务回滚

#### 定义模板

**受检异常**（继承 `Exception`，调用方必须处理）：

```java
public class BusinessException extends Exception {
    private final String code;
    public BusinessException(String code, String message) {
        super(message); this.code = code;
    }
    public BusinessException(String code, String message, Throwable cause) {
        super(message, cause); this.code = code;
    }
    public String getCode() { return code; }
}
```

**非受检异常**（继承 `RuntimeException`，调用方可选处理）：

```java
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String resourceName, Object id) {
        super(resourceName + " 不存在：id = " + id);
    }
}
```

#### 使用示例

```java
public class UserService {
    public User findById(long id) {
        User u = userRepository.get(id);
        if (u == null) {
            throw new ResourceNotFoundException("User", id);
        }
        return u;
    }
}

// 调用方
try {
    User u = userService.findById(999L);
} catch (ResourceNotFoundException e) {
    System.err.println("未找到：" + e.getMessage());
}
```

#### 5 条异常设计军规

- **粒度合适**：`UserNotFoundException` 比通用的 `NotFoundException` 更好定位问题
- **优先非受检**：业务异常大多用 `RuntimeException`，避免每一层都写 throws 污染签名
- **保留 cause**：捕获后包装抛出时，务必 `new XxxException(msg, e)` 传入原因
- **不要吞异常**：`catch { /* 空 */ }` 是灾难的开始，最少也要 `log.error("...", e)`
- **不要用异常控制流程**：异常有性能开销（栈快照），也让代码更难读；能用 `if` 判断就别抛异常

### 2.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `finally` 里写 `return` | 会吞掉 try 的 return / 异常，禁止 |
| catch 分支父类写在子类前面 | 子类永远匹配不到，编译报错 |
| 忘记关流导致文件句柄泄漏 | 用 try-with-resources，别手动写 finally close |
| `catch (Exception e) { }` 空吞异常 | 出 bug 根本查不到，最少要打日志 |
| 抛新异常时丢弃原始 e | 调试线索断裂，务必传 cause |
| 用异常做流程控制（如"没找到就抛"） | 性能差、语义差，改用 `Optional` 或返回值 |
| 自定义受检异常泛滥 | 每一层都要 throws，签名污染；优先非受检 |
| 判断"是不是数字"用 try-catch parseInt | 性能差，改用 `matches("\\d+")` 或 `NumberUtils.isCreatable` |

### 2.6 练习/思考

1. 用 `try-catch-finally` 编写代码：读入一个字符串并尝试用 `Integer.parseInt` 转成整数；转换失败时打印"非法数字"；无论成功失败，最后都打印"程序结束"。
2. 写一个方法 `divide(int a, int b)`，当 `b == 0` 时抛出 `IllegalArgumentException`，否则返回 `a / b`；再写单元测试验证。
3. 说出下面代码的输出，并解释原因：
   ```java
   static int f() { try { return 1; } finally { return 2; } }
   System.out.println(f());
   ```
4. 定义自定义异常 `InsufficientBalanceException(long userId, BigDecimal need, BigDecimal have)`，携带用户 id、需要金额、实际余额三个字段，并让 `getMessage()` 输出一句完整的中文描述。
5. 使用 `try-with-resources` 读取文本文件 `note.txt` 的所有行并打印；再改成一次读入 `List<String>`（提示：`Files.readAllLines`）。
6. **拓展**：把 `NumberFormatException` 捕获后重新抛出为你自定义的 `ParseFailedException`，并保留原始异常作为 cause。写两版：一版丢失 cause，一版保留 cause，比较 `printStackTrace()` 输出的差别，说明为什么保留 cause 很重要。

---

## 本日收束

### 承前启后

今天两讲各自解决一个 Java 底层痛点：

- **第 1 讲 泛型**——解决"编译期类型契约"问题。集合、方法签名、Spring `ResponseEntity<T>`、MyBatis Mapper 返回值……几乎所有工程代码都靠泛型表达"我处理什么类型"。
- **第 2 讲 异常**——解决"运行期不可控错误"问题。IO 失败、网络中断、参数非法、并发冲突……异常是 Java 表达"出错了"的官方语言。

两者是**基础健壮性能力**：泛型让编译器帮你抓 bug，异常让运行期错误有据可查。明天进入 IO 与并发，你会看到所有 API 签名都同时用到泛型（`List<Path>`、`Callable<T>`）和异常（`throws IOException`）——今天听懂了，明天就轻松。

### 6 天旅程中的定位

| Day | 主题 | 今日贡献 |
|---|---|---|
| **01** | **泛型 + 异常** | **打地基：类型系统 + 错误处理** |
| 02 | IO + 线程基础 | 用到泛型（`List<String>`）、抛异常（`IOException`） |
| 03 | 线程进阶 + 反射 | 反射 API 全部返回泛型、抛异常 |
| 04 | 注解 + 集合精讲 | 集合是泛型的最大用户 |
| 05 | 数据结构 + 内部类接口 | `HashMap<K,V>`、`sealed` 均依赖泛型 |
| 06 | Lambda/Stream + Optional/日期 | `Stream<T>`、`Optional<T>` 是泛型皇冠 |

### 作业

1. **必做**：第 1 讲、第 2 讲末尾练习各选做 3 道。
2. **拓展**：两讲拓展题任选一道深入完成，写出思考过程。
3. **提交**：代码提交到自己的 GitHub 仓库 `ai-programming-advanced/day01/`，README 里简述实现思路和踩过的坑。

---

[⬅️ 返回目录](../教材/目录.md) | [Day02 ➡️](day02.md)
