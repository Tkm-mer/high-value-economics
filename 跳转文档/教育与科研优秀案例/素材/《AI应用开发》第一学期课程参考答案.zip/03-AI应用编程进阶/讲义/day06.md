# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day06：Lambda / Stream + Optional / 日期时间）

**总课时**：6 讲（其中 Day06 覆盖第 11 讲、第 12 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成 Day05（数据结构 + 内部类与接口增强）
**参考教材**：`02-AI应用编程进阶/教材/chapters/11.md`（第 11 章 Lambda、方法引用与 Stream）、`12.md`（第 12 章 Optional 与日期时间 API）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 11 讲 | Lambda / 方法引用 / Stream | 熟练用 Lambda + 函数式接口 + Stream 完成过滤、映射、分组、归约；理解懒执行与并行陷阱 |
| 第 12 讲 | Optional 与日期时间 API | 用 Optional 替代 null 判空；用 `java.time` 处理日期、时刻、时区、格式化，弃用老 `Date` / `SimpleDateFormat` |

---

## 第 11 讲：Lambda、方法引用与 Stream

### 11.1 引入：昨天的匿名类，今天用一行搞定

Day05 我们讲了匿名内部类：

```java
Collections.sort(list, new Comparator<String>() {
    @Override public int compare(String a, String b) {
        return a.length() - b.length();
    }
});
```

Java 8 起 **Lambda** 让这段冗余骨架消失：

```java
Collections.sort(list, (a, b) -> a.length() - b.length());
```

**划重点**：Lambda 让**行为像数据一样被传递**——这就是"函数式编程"的入门体验。搭配 **Stream API**，你能把"取数据 → 过滤 → 变形 → 聚合"写成一条流水线，比传统 for 循环表达力强 3–5 倍。

今天上午目标：
- 会写 Lambda、认识 5 个常用函数式接口
- 会用 4 种方法引用
- 会用 Stream 完成过滤 / 映射 / 分组 / 归约 / 收集

### 11.2 讲解：Lambda 表达式

#### 语法

```text
(参数列表) -> { 方法体 }
```

写法多样：

```java
() -> 42                                // 无参、单表达式
x  -> x * x                             // 单参数可省括号
(x, y) -> x + y                         // 多参数
(int x, int y) -> x + y                 // 显式类型
(x, y) -> {                             // 多行需要大括号 + return
    int r = x + y;
    return r;
}
```

#### 目标类型：函数式接口

Lambda 不是"随便一段代码"，必须能被赋给某个**函数式接口**——即**有且仅有一个抽象方法**的接口。

```java
@FunctionalInterface
public interface Operator {
    int apply(int a, int b);
}

Operator add = (a, b) -> a + b;
int v = add.apply(2, 3);        // 5
```

**划重点**：`@FunctionalInterface` 不是必需，但**加上后编译器会校验**"只有一个抽象方法"，防止别人后续误加。

#### 变量捕获（回顾昨天的 effectively final）

- 外部类**字段**：无限制，随便读写
- 所在方法**局部变量**：必须 `final` 或 effectively final
- 内部**无法修改**捕获的局部变量（编译错误）

```java
int base = 100;
Function<Integer, Integer> f = x -> x + base;   // ✅
// base = 200;                                   // 一旦改，f 那行会报错
```

**互动提问**：为什么要这个限制？（答：昨天讲过——局部变量在栈上生命周期短，Lambda 对象生命周期长；编译器实际把变量复制进对象，禁止修改是为了防止内外状态不一致。）

#### `this` 的含义

Lambda 里的 `this` 指**外部类**实例，不是 Lambda 自己：

```java
public class Demo {
    private String name = "demo";
    public Runnable r() {
        return () -> System.out.println(this.name);   // 打印 demo
    }
}
```

**划重点**：匿名内部类的 `this` 指匿名对象自身——这是 Lambda 与匿名内部类**语义差异**的关键点，面试常考。

### 11.3 讲解：JDK 内置函数式接口

`java.util.function` 提供了常用接口，避免每次都自定义。**必背 5 个 + 1 个**：

| 接口 | 抽象方法 | 语义 |
|---|---|---|
| `Function<T, R>` | `R apply(T t)` | 输入 T 输出 R |
| `Predicate<T>` | `boolean test(T t)` | 判定 |
| `Consumer<T>` | `void accept(T t)` | 消费（有副作用） |
| `Supplier<T>` | `T get()` | 提供者（无输入） |
| `BiFunction<T, U, R>` | `R apply(T t, U u)` | 二元函数 |
| `UnaryOperator<T>` / `BinaryOperator<T>` | 特化版 | 输入输出同类型 |

**基本类型特化**（避免装箱开销）：`IntFunction`、`IntPredicate`、`IntConsumer`、`IntSupplier`、`ToIntFunction` 等。

例子：

```java
Predicate<String> notEmpty = s -> s != null && !s.isEmpty();
Function<String, Integer> length = String::length;
Consumer<String> print = System.out::println;
Supplier<List<String>> newList = ArrayList::new;

if (notEmpty.test("abc")) print.accept("len = " + length.apply("abc"));
```

#### 组合运算

`Function` 有 `andThen` / `compose`，`Predicate` 有 `and` / `or` / `negate`：

```java
Function<Integer, Integer> plus1 = x -> x + 1;
Function<Integer, Integer> times2 = x -> x * 2;

Function<Integer, Integer> f = plus1.andThen(times2);    // (x + 1) * 2
Function<Integer, Integer> g = plus1.compose(times2);    // (x * 2) + 1

Predicate<Integer> positive = x -> x > 0;
Predicate<Integer> even     = x -> x % 2 == 0;
Predicate<Integer> both     = positive.and(even);         // > 0 且是偶数
Predicate<Integer> either   = positive.or(even);
Predicate<Integer> negPositive = positive.negate();
```

### 11.4 讲解:方法引用

**方法引用**是 Lambda 的语法简写：当 Lambda 只是"调用一个已存在的方法"时，可以用 `类名::方法名` 之类的形式。

| 类型 | 写法 | 等价 Lambda |
|---|---|---|
| 静态方法 | `Integer::parseInt` | `s -> Integer.parseInt(s)` |
| 特定对象的实例方法 | `System.out::println` | `s -> System.out.println(s)` |
| 类的实例方法 | `String::length` | `s -> s.length()` |
| 构造器 | `ArrayList::new` | `() -> new ArrayList<>()` |

#### 关键区别：接收者位置

- **类的实例方法** `String::length`：Lambda 的**第一个参数**充当接收者
- **特定对象的实例方法** `out::println`：接收者已固定，Lambda 参数全部作为方法实参

```java
List<String> list = Arrays.asList("apple", "banana", "kiwi");
list.stream().map(String::length).forEach(System.out::println);  // 5 6 4
```

**互动提问**：`str -> str.toUpperCase()` 用方法引用怎么写？（答：`String::toUpperCase`——是"类的实例方法"形式，第一个参数是接收者。）

### 11.5 讲解:Stream API 入门

Stream 是一条"元素流水线"：你在一个数据源上声明一系列**中间操作**，最后由**终结操作**触发执行。

```mermaid
flowchart LR
    S[Source<br/>集合/数组/生成器] --> M1[中间操作 filter]
    M1 --> M2[中间操作 map]
    M2 --> M3[中间操作 sorted]
    M3 --> T[终结操作 collect]
```

**划重点**：**懒执行**——只声明中间操作 Stream 什么都不做，遇到终结操作才真正跑。终结后 Stream 就报废，不能再用。

#### 创建 Stream

```java
Stream<Integer> s1 = Stream.of(1, 2, 3);
Stream<String>  s2 = List.of("a", "b").stream();
IntStream       s3 = IntStream.range(0, 10);
Stream<Integer> s4 = Stream.iterate(1, x -> x * 2).limit(5);   // 1, 2, 4, 8, 16
Stream<Double>  s5 = Stream.generate(Math::random).limit(3);
```

#### 中间操作（都返回 Stream）

```java
Stream<T> filter(Predicate<T> p)          // 过滤
<R> Stream<R> map(Function<T, R> f)       // 一对一映射
<R> Stream<R> flatMap(Function<T, Stream<R>> f)  // 一对多映射并展平
Stream<T> distinct()                      // 去重
Stream<T> sorted()                        // 自然序
Stream<T> sorted(Comparator<T> c)         // 定制序
Stream<T> limit(long n)                   // 前 n 个
Stream<T> skip(long n)                    // 跳过前 n 个
Stream<T> peek(Consumer<T> c)             // 观察（调试用）
```

#### 终结操作（触发执行）

```java
void forEach(Consumer<T>)
long count()
Optional<T> min(Comparator<T>) / max(Comparator<T>)
Optional<T> findFirst() / findAny()
boolean anyMatch(Predicate) / allMatch / noneMatch
T reduce(T identity, BinaryOperator<T>)
<R, A> R collect(Collector<T, A, R>)      // 最常用的收集器
List<T> toList()                          // JDK 16+，不可变
```

### 11.6 常用套路（80% 场景够用）

#### 过滤 + 映射 + 收集

```java
List<String> names = List.of("Tom", "Jerry", "Alice", "Bob");
List<String> longUpper = names.stream()
    .filter(n -> n.length() >= 4)
    .map(String::toUpperCase)
    .sorted()
    .toList();               // [ALICE, JERRY]
```

#### 求和 / 平均 / 最大 / 最小

```java
int sum = IntStream.rangeClosed(1, 100).sum();     // 5050
OptionalDouble avg = IntStream.of(1, 2, 3).average();
int max = IntStream.of(3, 1, 4).max().orElseThrow();
```

#### 分组（**Stream 的杀手锏**）

```java
Map<Integer, List<String>> byLen = names.stream()
    .collect(Collectors.groupingBy(String::length));
// {3=[Tom, Bob], 5=[Jerry, Alice]}
```

#### 分组 + 统计

```java
Map<Integer, Long> countByLen = names.stream()
    .collect(Collectors.groupingBy(String::length, Collectors.counting()));
```

#### Join 成字符串

```java
String csv    = names.stream().collect(Collectors.joining(","));
String pretty = names.stream().collect(Collectors.joining(", ", "[", "]"));
```

#### Reduce 归约

```java
int total = List.of(1, 2, 3, 4).stream().reduce(0, Integer::sum);
Optional<Integer> maxOpt = List.of(3, 1, 4).stream().reduce(Integer::max);
```

### 11.7 讲解：flatMap 与基本类型 Stream

#### flatMap：处理嵌套 Stream

```java
List<List<Integer>> nested = List.of(List.of(1, 2), List.of(3, 4), List.of(5));
List<Integer> flat = nested.stream()
    .flatMap(List::stream)
    .toList();
// [1, 2, 3, 4, 5]

// 拆词
List<String> lines = List.of("hello world", "hi java");
List<String> words = lines.stream()
    .flatMap(l -> Arrays.stream(l.split(" ")))
    .toList();
// [hello, world, hi, java]
```

**记忆口诀**：`map` 是"一进一出"，`flatMap` 是"一进多出再拉平"。

#### IntStream / LongStream / DoubleStream

避免装箱开销，提供 `sum / average / max / min` 等特化方法：

```java
int sum = list.stream().mapToInt(String::length).sum();
double avg = list.stream().mapToInt(String::length).average().orElse(0);
```

### 11.8 完整案例：日志统计（三段式）

给一段用户操作日志，统计每个用户的登录次数并按次数降序输出前 3。

```java
record Log(String user, String action) { }        // 回顾 Day05 的 record

List<Log> logs = List.of(
    new Log("alice", "login"),
    new Log("bob",   "login"),
    new Log("alice", "buy"),
    new Log("alice", "login"),
    new Log("carol", "login")
);

List<Map.Entry<String, Long>> top3 = logs.stream()
    .filter(l -> l.action().equals("login"))                           // 过滤
    .collect(Collectors.groupingBy(Log::user, Collectors.counting()))  // 分组统计
    .entrySet().stream()
    .sorted(Map.Entry.<String, Long>comparingByValue().reversed())     // 按值降序
    .limit(3)
    .toList();

top3.forEach(e -> System.out.println(e.getKey() + " -> " + e.getValue()));
```

**划重点**：这就是**流式声明式**编程——你只描述"想要什么"，不写"怎么循环怎么累加"。20 行 for 循环 → 5 行 Stream，可读性大幅提升。

### 11.9 讲解：并行 Stream 与陷阱

```java
long count = list.parallelStream()
                 .filter(x -> x.length() >= 3)
                 .count();
```

底层用 `ForkJoinPool.commonPool()` 并行分片处理。

**什么时候用**：数据量大 + 每个元素处理耗时 + 处理逻辑无状态、无副作用、可分割。

**什么时候别用**：
- 小数据集 → 拆分 / 合并开销大于收益
- 有共享可变状态 → 数据竞争
- 顺序敏感（如 `findFirst`）→ 并行不一定更快甚至更慢
- 阻塞 IO 任务 → 会占死 `commonPool`

**经典坑**：

```java
// ❌ 副作用不安全
List<Integer> result = new ArrayList<>();
list.parallelStream().forEach(result::add);   // ArrayList 非线程安全

// ✅ 用 collect
List<Integer> result = list.parallelStream().toList();
```

**划重点**：**默认串行**，只在有充分证据表明能受益时才并行——不要为了"看起来快"随便加 parallel。

### 11.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Stream 被终结后再用抛异常 | 一个 Stream 只能被终结一次；重新创建 |
| `filter/map` 写了但没执行 | 缺终结操作；Stream 懒执行 |
| Lambda 修改外部变量编译报错 | effectively final；把变量放数组 `int[]{0}` 或用 `AtomicInteger` |
| Lambda 里 `this` 不是 Lambda 自己 | Lambda 的 `this` 指外部类；这与匿名内部类不同 |
| `orElse` vs `orElseGet` 昂贵默认值时 | `orElse` 总求值；用 `orElseGet(Supplier)`（下一讲还会讲） |
| `Collectors.toList()` 返回可变、`Stream.toList()` 返回不可变 | JDK 16+ 用 `stream.toList()` 更简洁 |
| `parallelStream` 用了 `ArrayList::add` | 非线程安全；用 `collect` 或线程安全集合 |
| 大写 `M` 小写 `m` 搞混 | 大写月份、小写分钟（下一讲的 pattern 坑，先埋个伏笔） |
| `map` 内部有副作用 | Stream 是声明式的，副作用要用 `forEach`/`peek` |
| `peek` 在生产代码里生效不稳定 | peek 仅用于调试，不保证被调用（无终结时懒执行） |

### 11.11 练习/思考

1. 用 Lambda 而非匿名类完成：把 `List<Integer>` 按绝对值升序排列。
2. 定义 `Predicate<String> notBlank`，然后用 `and` / `negate` 组合出"不空且长度不超过 10"的谓词。
3. 给 `String[] arr`，用 Stream 得到"去重、按字典序、前 5 个的大写形式"。
4. 给 `List<Employee>`（含 `dept`、`salary` 字段），用 `groupingBy + averagingDouble` 计算各部门平均工资。
5. 用 `flatMap` 把 `List<List<Integer>>` 里的所有整数展开并求和。
6. 用 `IntStream.rangeClosed(1, 100)` 计算 1..100 中能被 3 或 5 整除的数字之和。
7. 说出下面 Stream 代码有什么问题并修复：
   ```java
   Stream<String> s = list.stream().filter(x -> x.length() > 3);
   long c1 = s.count();
   List<String> l = s.toList();       // ← Bug 在哪？
   ```
8. **拓展**：给一段 markdown 文本（多个 `# 标题`），用 Stream 提取所有一级标题并按出现顺序返回。

---

## 第 12 讲：Optional 与日期时间 API

### 12.1 引入：null 是十亿美元的错误

Java 里对象引用可能为 `null`，忘了判空就是经典的 NPE：

```java
User u = userService.findById(1);
String upper = u.getName().toUpperCase();   // 若 u 或 name 为 null → NPE
```

Tony Hoare（null 引用的发明人）后来自称这是"**十亿美元的错误**"。Java 8 引入 `Optional<T>` 作为**"值可能不存在"的显式容器**——把"可能 null"写进类型，强制调用者思考它。

下午目标：
- 用 Optional 优雅处理"可能为空"
- 用 `java.time` 处理日期、时刻、时区、格式化（并弃用老 `Date` / `SimpleDateFormat`）

### 12.2 讲解：Optional 的创建与判空

#### 创建

```java
Optional<String> a = Optional.of("abc");        // 非空，null 会抛 NPE
Optional<String> b = Optional.ofNullable(null); // 允许 null，得到 empty
Optional<String> c = Optional.empty();          // 空
```

**规则**：来源明确非空用 `of`，可能为 null 用 `ofNullable`。

#### 判空与取值

```java
opt.isPresent();          // true 表示有值
opt.isEmpty();            // JDK 11+，等价于 !isPresent
opt.get();                // ⚠️ 空则抛 NoSuchElementException，谨慎使用
opt.orElse("default");    // 空则返回默认值
opt.orElseGet(() -> compute());          // 空则调用 Supplier 生成默认值
opt.orElseThrow();                       // 空则抛 NoSuchElementException
opt.orElseThrow(() -> new BizException("miss"));
```

**划重点**：**`orElse` vs `orElseGet` 是超高频面试题**——`orElse` 的参数**总是被求值**（即使有值也算一次），`orElseGet` 只在空时才调用 Supplier。**对昂贵默认值必须选后者**。

```java
Optional.of("hi").orElse(expensiveNetworkCall());     // ❌ 网络还是被调用了
Optional.of("hi").orElseGet(() -> expensiveNetworkCall()); // ✅ 短路
```

### 12.3 讲解：Optional 的函数式操作

Optional 也支持流式链式，和上午的 Stream 呼应：

```java
opt.ifPresent(v -> System.out.println(v));
opt.ifPresentOrElse(v -> ..., () -> ...);        // JDK 9+

Optional<Integer> len = opt.map(String::length);
Optional<Character> first = opt
    .filter(s -> !s.isEmpty())
    .map(s -> s.charAt(0));

Optional<User> chief = user.flatMap(User::supervisor);   // supervisor 返回 Optional<User>
```

- `map`：值存在则映射；空则保持空
- `filter`：不满足条件转为空
- `flatMap`：映射函数**本身**返回 Optional 时用，避免嵌套 `Optional<Optional<...>>`

#### 与 Stream 混用

```java
Optional<User> u = Optional.of(user);
u.stream().flatMap(User::orders).forEach(System.out::println);   // JDK 9+
```

`Optional.stream()`（JDK 9+）把 0 或 1 元素当成流，方便融合 Stream 处理链。

### 12.4 讲解：Optional 使用规范（重要）

Optional 是有边界的工具，用错反而糟糕：

**✅ 推荐**
- 方法**返回值**：告诉调用方"可能没有"
- 局部处理链：`findUser(id).map(...).orElse(...)`

**❌ 不推荐**
- 类的**字段**：`Optional` 不 `Serializable`，也没设计成字段容器
- 方法**参数**：调用方直接判 null 或重载更好，别把"传或不传"推给类型系统
- Map 的 value：多此一举，Map 本身就有 `getOrDefault` / `computeIfAbsent`
- 集合返回值：直接返回空集合更好，不是 `Optional<List<>>`

**空 Optional 处理陷阱**：

```java
// ❌ 冗余
if (opt.isPresent()) return opt.get();
else                 return default;

// ✅ 一行
return opt.orElse(default);
```

**划重点**：**如果你写 `Optional.get()`，八成用错了**——`get()` 是"我保证有值"的最后手段，多数场景应该用 `orElse` / `orElseThrow` / `map`。

### 12.5 讲解：为什么弃用老日期 API

`java.util.Date` / `Calendar` / `SimpleDateFormat` 存在严重缺陷：

- `Date` 里的**月份从 0 开始**（0 = January）——魔鬼数字
- `Date` 构造函数与打印**时区依赖 JVM 时区**，容易踩坑
- 全部**可变**：多线程共用一个 `SimpleDateFormat` 就 boom（生产事故经典款）
- 时区、时间戳、日期、时刻的表达全部混杂在同一个 `Date` 上

Java 8 引入 `java.time` 完全重构（参考 Joda-Time），核心特点：

- **不可变**、**线程安全**
- 类型区分清晰：
  - `LocalDate`：只有日期（无时间无时区）
  - `LocalTime`：只有时间
  - `LocalDateTime`：日期+时间（无时区）
  - `Instant`：时间戳（UTC 时刻）
  - `ZonedDateTime`：带时区的日期时间
- Month 从 **1** 开始（人类友好）

### 12.6 讲解：LocalDate / LocalTime / LocalDateTime

#### 创建

```java
LocalDate today = LocalDate.now();
LocalDate d  = LocalDate.of(2025, 3, 14);
LocalDate d2 = LocalDate.of(2025, Month.MARCH, 14);
LocalDate parsed = LocalDate.parse("2025-03-14");      // ISO 格式

LocalTime nowT = LocalTime.now();
LocalTime t = LocalTime.of(10, 30, 45);

LocalDateTime dt  = LocalDateTime.now();
LocalDateTime dt2 = LocalDateTime.of(2025, 3, 14, 10, 30);
```

#### 读取字段

```java
LocalDate d = LocalDate.of(2025, 3, 14);
d.getYear();               // 2025
d.getMonth();              // MARCH
d.getMonthValue();         // 3
d.getDayOfMonth();         // 14
d.getDayOfWeek();          // FRIDAY
d.getDayOfYear();          // 73
d.lengthOfMonth();         // 31
d.isLeapYear();            // false
```

#### 修改（返回新对象）

```java
LocalDate d = LocalDate.of(2025, 3, 14);

LocalDate d1 = d.withYear(2026);            // 2026-03-14
LocalDate d2 = d.withDayOfMonth(1);         // 2025-03-01

LocalDate d3 = d.plusDays(10);              // 2025-03-24
LocalDate d4 = d.plusMonths(1).minusDays(2);// 2025-04-12
LocalDate d5 = d.plusYears(1);

// Adjuster：语义化修改
LocalDate lastDay = d.with(TemporalAdjusters.lastDayOfMonth());   // 2025-03-31
LocalDate nextMon = d.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
```

**划重点**：`java.time` 对象**不可变**——`plus` / `minus` / `with` 都**返回新实例**！忘记接返回值就白改：

```java
// ❌ Bug
LocalDate d = LocalDate.now();
d.plusDays(10);            // 结果被丢弃！
System.out.println(d);     // 还是今天

// ✅
d = d.plusDays(10);
```

#### 比较

```java
a.isBefore(b);   a.isAfter(b);   a.equals(b);   a.compareTo(b);
```

### 12.7 讲解：Instant / ZonedDateTime / 时区

#### Instant——机器视角的绝对时间

`Instant` 表示**从 1970-01-01T00:00:00Z 开始的时刻**。

```java
Instant now = Instant.now();               // 当前 UTC 时刻
long millis = now.toEpochMilli();
long seconds = now.getEpochSecond();
Instant fromMillis = Instant.ofEpochMilli(1_700_000_000_000L);
```

`Instant` vs `LocalDateTime`：

- `Instant` 是**时间线上的一个点**（本质是 UTC 时刻）
- `LocalDateTime` 是**墙上的时刻**，不含时区——脱离时区无法比较到底谁更早

#### ZonedDateTime——带时区

```java
ZoneId shanghai = ZoneId.of("Asia/Shanghai");
ZonedDateTime zdt = ZonedDateTime.now(shanghai);

// 时区转换：同一时刻在不同时区的墙上时间
ZonedDateTime nyTime = zdt.withZoneSameInstant(ZoneId.of("America/New_York"));
```

#### Instant ↔ LocalDateTime

```java
Instant now = Instant.now();

// Instant → LocalDateTime（需要指定时区）
LocalDateTime ldt = LocalDateTime.ofInstant(now, ZoneId.systemDefault());

// LocalDateTime → Instant（同样要指定时区）
Instant inst = ldt.atZone(ZoneId.systemDefault()).toInstant();
```

**划重点**：**`LocalDateTime` 不知道自己在哪个时区**，转 `Instant` 或存数据库时必须给它一个 `ZoneId`。数据库层建议存 `Instant`（UTC），展示层再按用户时区渲染。

### 12.8 讲解：Duration 与 Period

- **Duration**：基于时间（秒 / 纳秒），适合小时、分钟、秒级差值
- **Period**：基于日期（年 / 月 / 日），适合日期级差值

```java
Duration d = Duration.between(t1, t2);          // 两个 LocalTime / LocalDateTime / Instant
long seconds = d.getSeconds();
long millis  = d.toMillis();

Period p = Period.between(startDate, endDate);   // 两个 LocalDate
int years  = p.getYears();
int months = p.getMonths();
int days   = p.getDays();
```

计算年龄：

```java
LocalDate birth = LocalDate.of(2000, 5, 20);
LocalDate today = LocalDate.now();
Period age = Period.between(birth, today);
System.out.printf("年龄：%d 岁 %d 个月%n", age.getYears(), age.getMonths());
```

**互动提问**：算"距离双 11 还有几秒"应该用 Duration 还是 Period？（答：Duration。Period 是日期级的，秒级差值用 Duration。）

### 12.9 讲解：DateTimeFormatter——字符串互转

`SimpleDateFormat` 线程不安全，`DateTimeFormatter` 是**不可变、线程安全**的替代品。

#### 预定义格式

```java
LocalDate d = LocalDate.now();
d.format(DateTimeFormatter.ISO_LOCAL_DATE);         // 2025-03-14
```

#### 自定义 pattern

```java
DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
LocalDateTime now = LocalDateTime.now();

String s = now.format(fmt);
LocalDateTime parsed = LocalDateTime.parse("2025-03-14 10:30:00", fmt);
```

#### 常见 pattern 字符

| 字符 | 含义 | 示例 |
|---|---|---|
| `yyyy` | 4 位年 | 2025 |
| `MM` | **月**（2 位） | 03 |
| `dd` | 日（2 位） | 14 |
| `HH` | 24 小时制小时 | 10 |
| `hh` | 12 小时制小时 | 10 |
| `mm` | **分**钟 | 30 |
| `ss` | 秒 | 00 |
| `SSS` | 毫秒 | 123 |
| `E` | 星期缩写 | Fri |
| `a` | AM/PM | AM |
| `z` / `Z` / `X` | 时区名 / 偏移 / ISO 偏移 | CST / +0800 / +08:00 |

**⚠️ 特别注意**：**月份是大写 M；小写 m 表示分钟**。写错就成经典 bug——把 `yyyy-mm-dd` 打出来的日期永远月份是 0，因为 `mm` 是分钟。

#### 本地化

```java
DateTimeFormatter zh = DateTimeFormatter.ofPattern("yyyy年M月d日 EEEE", Locale.CHINESE);
System.out.println(LocalDate.now().format(zh));   // 2025年3月14日 星期五
```

### 12.10 综合案例

#### 计算年龄

```java
public static int age(LocalDate birth) {
    return Period.between(birth, LocalDate.now()).getYears();
}
```

#### 判断周末

```java
public static boolean isWeekend(LocalDate d) {
    DayOfWeek w = d.getDayOfWeek();
    return w == DayOfWeek.SATURDAY || w == DayOfWeek.SUNDAY;
}
```

#### 打印本周一到周日

```java
LocalDate today = LocalDate.now();
LocalDate monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
for (int i = 0; i < 7; i++) {
    LocalDate d = monday.plusDays(i);
    System.out.println(d + " " + d.getDayOfWeek());
}
```

#### 打卡持续时长

```java
LocalDateTime checkIn  = LocalDateTime.of(2025, 3, 14, 9, 0);
LocalDateTime checkOut = LocalDateTime.of(2025, 3, 14, 18, 30);
Duration work = Duration.between(checkIn, checkOut);
System.out.printf("上班 %d 小时 %d 分钟%n", work.toHours(), work.toMinutesPart());
```

#### 时间格式化 + 时区转换

```java
DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z");

ZonedDateTime shanghai = ZonedDateTime.now(ZoneId.of("Asia/Shanghai"));
ZonedDateTime newyork  = shanghai.withZoneSameInstant(ZoneId.of("America/New_York"));

System.out.println(shanghai.format(fmt));   // 2025-03-14 10:30 CST
System.out.println(newyork.format(fmt));    // 2025-03-13 22:30 EDT
```

### 12.11 迁移建议

老代码里如果还在用 `Date` / `Calendar` / `SimpleDateFormat`，可以按需换：

| 旧 | 新 |
|---|---|
| `new Date()` | `Instant.now()` 或 `LocalDateTime.now()` |
| `Calendar.getInstance()` | `LocalDateTime.now()` |
| `SimpleDateFormat("yyyy-MM-dd").parse(s)` | `LocalDate.parse(s, fmt)` |
| `Date` ↔ `Instant` | `Date.from(instant)` / `date.toInstant()` |

`Date` 和 `Instant` 可以互相转换，逐步迁移比大爆炸安全。

### 12.12 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Optional.get()` 抛 NoSuchElementException | 用 `orElse` / `orElseThrow` / `ifPresent` |
| `orElse(昂贵调用)` 每次都被求值 | 用 `orElseGet(Supplier)` |
| Optional 用作字段 / 参数 | 不推荐；只做返回值 |
| 集合返回 `Optional<List<>>` | 直接返回空集合更好 |
| `plusDays(10)` 之后 d 没变 | 不可变对象；必须 `d = d.plusDays(10)` |
| `SimpleDateFormat` 多线程共用崩溃 | 换成 `DateTimeFormatter`（不可变、线程安全） |
| pattern 用 `yyyy-mm-dd` 月份变 0 | 大写 M 是月，小写 m 是分——最大坑 |
| `LocalDateTime` 存数据库跨时区错乱 | 存 `Instant`（UTC），展示时按用户时区渲染 |
| `Duration.between(date1, date2)` 编译错 | Duration 需要 Time/DateTime，日期用 `Period.between` |
| `Date` 里 `month=3` 结果显示是四月 | `Date` 月份从 0 开始；换成 `java.time` |

### 12.13 练习/思考

1. 写方法 `Optional<User> findUser(int id)`，模拟数据库查找。调用方链式获取用户邮箱转小写，若为空返回 `"no@mail"`。
2. 说明 `orElse` 与 `orElseGet` 在传入昂贵操作（如访问网络）时的性能差异，并写代码验证。
3. 计算某人到 60 岁生日还有多少年零多少个月。
4. 输入 `yyyy-MM-dd` 格式的日期字符串，输出它是星期几。
5. 用 `TemporalAdjusters` 找出下一个"本月最后一个星期五"。
6. 写方法 `Duration timeUntilMidnight()`：距离今晚 24:00 还有多久。
7. 一个北京用户在 `2025-03-14 22:00` 发帖，纽约用户看到的时刻是什么？（用 ZonedDateTime 计算并格式化输出）
8. **拓展**：用 `java.time` 写一个"生日剩余天数提醒器"——输入生日，输出"今年生日还有 N 天 / 已过 N 天"。

---

## 本课程收束

### 承前启后（Day06）

- **第 11 讲 Lambda + Stream**——上午把你从 Java 7 的"面向对象+循环"时代正式带进了 Java 8+ 的"函数式+声明式"时代：**行为可以作为参数传递**，**数据处理可以像流水线一样声明**。
- **第 12 讲 Optional + 日期时间 API**——下午的 `Optional` 让"可能为空"进入类型系统，`java.time` 则替代了 25 年前那套糟糕的 `Date` API。

### 回顾 6 天旅程

| Day | 主题 | 关键武器 |
|---|---|---|
| 01 | 泛型 + 异常 | `List<T>` / 通配符 / try-with-resources |
| 02 | IO 流 + 线程基础 | `Files` / `try-with-resources` / `Runnable` |
| 03 | 线程进阶 + 反射 | `ExecutorService` / `Class` / 动态代理 |
| 04 | 注解 + 集合精讲 | `@Retention` / 反射+注解 / `TreeMap` |
| 05 | 数据结构 + 内部类接口 | 手写 `HashMap` / `record` / `sealed` |
| **06** | **Lambda/Stream + Optional/日期** | **`Stream.collect` / `Optional` / `java.time`** |

这 12 讲串起来就是**从"会写 Java"到"能读懂 Spring / MyBatis / Netty 源码"**的桥。接下来的路，是拿这套武器去啃真实项目——建议下一步进入《Spring Boot 项目实战》或《数据库应用开发》。

### 作业

1. **必做**：第 11 讲、第 12 讲末尾练习各选做 3 道。
2. **拓展**：任选一道拓展题深入完成。
3. **综合作业**：写一个"操作日志分析器"——读取一个 CSV（`时间戳,用户,操作`），用 Stream + Optional + `java.time` 完成：
   - 按天分组统计每天的操作总数
   - 找出登录次数最多的前 5 名用户
   - 计算每个用户第一次到最后一次登录的时间跨度（`Duration`）
   - 输出结果到控制台，日期用 `yyyy-MM-dd HH:mm` 格式化
4. **提交**：代码提交到 `ai-programming-advanced/day06/`，README 里写一段"6 天最大的收获是什么"。

### 结课寄语

从 Day01 打地基到 Day06 收官，你走完了 Java 从基础到框架前夜的完整链路。**下一步不是学更多语法，是去写第一个真实项目**——一个能跑起来、能被别人用、能出 bug 也能改回来的项目。祝你继续加油。

---

[⬅️ Day05](day05.md) | [返回目录](../教材/目录.md)
