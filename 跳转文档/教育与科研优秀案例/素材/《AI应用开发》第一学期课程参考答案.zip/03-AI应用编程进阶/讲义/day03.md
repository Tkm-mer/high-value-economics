# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day03：线程进阶 + 反射）

**总课时**：6 讲（其中 Day03 覆盖第 5 讲、第 6 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成 Day02（IO 流 + 线程基础）
**参考教材**：`02-AI应用编程进阶/教材/chapters/05.md`（第 5 章 线程与并发（下））、`06.md`（第 6 章 反射）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 5 讲 | 线程与并发（下） | 会用 `ThreadPoolExecutor` 七大参数自建线程池；能画 6 种线程状态图；用 `wait/notify` 或 `Condition` 实现生产者—消费者 |
| 第 6 讲 | 反射 | 掌握 4 种获取 Class 的方式；能反射构造对象、读写字段、调用方法（含 private）；理解框架为何依赖反射 |

---

## 第 5 讲：线程与并发（下）

### 5.1 引入：昨天的线程池是"教学玩具"

Day02 结尾我们用 `Executors.newFixedThreadPool(3)` 跑了并发下载，看起来很爽。但生产环境**几乎从不这么用**。为什么？

```java
ExecutorService pool = Executors.newFixedThreadPool(4);
// 底层是 new ThreadPoolExecutor(4, 4, 0L, MILLISECONDS,
//        new LinkedBlockingQueue<Runnable>());   // ← 无界队列！
```

**划重点**：队列容量是 `Integer.MAX_VALUE`。如果任务提交速度快于处理速度，队列会**无限膨胀**直到 OOM。真实事故：某支付系统促销时几分钟堆积 300 万个任务，JVM 直接崩溃。

所以生产必须**自建** `ThreadPoolExecutor`，理解**七大参数**是绕不开的关。

#### 完整构造器与七大参数

```java
public ThreadPoolExecutor(
    int corePoolSize,
    int maximumPoolSize,
    long keepAliveTime,
    TimeUnit unit,
    BlockingQueue<Runnable> workQueue,
    ThreadFactory threadFactory,
    RejectedExecutionHandler handler)
```

| 参数 | 含义 |
|---|---|
| `corePoolSize` | 核心线程数：常驻，不会因空闲而回收（除非开启 `allowCoreThreadTimeOut`） |
| `maximumPoolSize` | 最大线程数：队列满且核心繁忙时，最多扩到几个 |
| `keepAliveTime` + `unit` | 超出核心的线程空闲多久回收 |
| `workQueue` | 任务队列，存等待执行的任务 |
| `threadFactory` | 线程创建工厂（**设置线程名、守护标记**，方便排查） |
| `handler` | 拒绝策略：队列满 + 线程数已到最大时怎么办 |

#### 任务提交后的工作流程

```mermaid
flowchart TD
    A[submit 任务] --> B{核心线程<br/>是否已满?}
    B -- 否 --> C[创建核心线程执行]
    B -- 是 --> D{任务队列<br/>是否已满?}
    D -- 否 --> E[放入队列等待]
    D -- 是 --> F{是否小于<br/>最大线程数?}
    F -- 是 --> G[创建非核心线程执行]
    F -- 否 --> H[触发拒绝策略]
```

一句话总结：**核心线程 → 队列 → 非核心线程 → 拒绝**。

**互动提问**：核心 4、最大 8、队列容量 2 的池，一下来 20 个任务，多少个进队列、多少个被拒绝？
（答：先 4 个占核心，接着 2 个进队列，接着新开 4 个非核心（8 - 4），共处理 10 个；剩下 10 个走拒绝策略。）

#### 常见 BlockingQueue

| 队列 | 特点 | 典型搭配 |
|---|---|---|
| `LinkedBlockingQueue` | 链表，可指定容量（默认 `Integer.MAX_VALUE`——无界！） | `newFixedThreadPool` |
| `ArrayBlockingQueue` | 数组，**必须指定容量** | 生产推荐 |
| `SynchronousQueue` | 不存元素，来一个直接交给线程 | `newCachedThreadPool` |
| `PriorityBlockingQueue` | 优先级排序 | 任务有优先级需求 |
| `DelayQueue` | 延迟执行 | 定时任务 |

#### 四大拒绝策略

| 策略 | 行为 |
|---|---|
| `AbortPolicy`（默认） | 抛 `RejectedExecutionException` |
| `CallerRunsPolicy` | 让**调用者线程**自己执行任务（自然限流） |
| `DiscardPolicy` | 静默丢弃（危险，无感） |
| `DiscardOldestPolicy` | 丢掉队列最老的任务，再尝试提交 |

**划重点**：`CallerRunsPolicy` 是最安全的默认——不丢任务、又形成反压：**主线程被拉去干活，自然就慢下来了**，等池空闲再继续提交。

#### 生产推荐的自建模板

```java
ThreadPoolExecutor pool = new ThreadPoolExecutor(
    4,                                   // corePoolSize
    16,                                  // maximumPoolSize
    60L, TimeUnit.SECONDS,               // keepAliveTime
    new ArrayBlockingQueue<>(1000),      // 有界队列，防 OOM
    new ThreadFactory() {                // 有意义的线程名
        private final AtomicInteger id = new AtomicInteger(1);
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "biz-worker-" + id.getAndIncrement());
            t.setDaemon(false);
            return t;
        }
    },
    new ThreadPoolExecutor.CallerRunsPolicy());  // 满了让调用者自己跑
```

#### 参数怎么定（经验公式）

- **CPU 密集**：`corePoolSize ≈ CPU 核心数 + 1`
- **IO 密集**：`corePoolSize ≈ CPU 核心数 × 2` 或更高（IO 时线程在等）
- **maximumPoolSize**：一般不超过 CPU 核心数的 4~5 倍
- **queueCapacity**：根据业务能容忍的等待任务上限定

### 5.2 讲解：线程的 6 种状态

Java 用 `Thread.State` 枚举定义了 6 种状态：

```mermaid
stateDiagram-v2
    [*] --> NEW: new Thread()
    NEW --> RUNNABLE: start()
    RUNNABLE --> BLOCKED: 争夺 synchronized 锁失败
    BLOCKED --> RUNNABLE: 拿到锁
    RUNNABLE --> WAITING: wait()/join()/park()
    WAITING --> RUNNABLE: notify()/notifyAll()/unpark()
    RUNNABLE --> TIMED_WAITING: sleep(ms)/wait(ms)/join(ms)
    TIMED_WAITING --> RUNNABLE: 超时或被唤醒
    RUNNABLE --> TERMINATED: run() 返回
    TERMINATED --> [*]
```

| 状态 | 含义 |
|---|---|
| `NEW` | 已创建 `Thread` 对象，尚未 `start` |
| `RUNNABLE` | 可运行（包括正在运行、等待 CPU 调度） |
| `BLOCKED` | 等待进入 `synchronized` 同步块 |
| `WAITING` | 无限期等待（`wait()`、`join()`、`LockSupport.park()`），需要另一个线程唤醒 |
| `TIMED_WAITING` | 有超时的等待（`sleep(ms)`、`wait(ms)`、`join(ms)`） |
| `TERMINATED` | `run()` 方法执行结束 |

代码验证：

```java
Thread t = new Thread(() -> {
    try { Thread.sleep(1000); } catch (InterruptedException e) {}
});

System.out.println(t.getState());   // NEW
t.start();
System.out.println(t.getState());   // RUNNABLE 或 TIMED_WAITING
Thread.sleep(200);
System.out.println(t.getState());   // TIMED_WAITING
t.join();
System.out.println(t.getState());   // TERMINATED
```

**互动提问**：`sleep` 和 `wait` 都让线程"暂停"，为什么进入的状态一个是 `TIMED_WAITING` / 另一个可能是 `WAITING`？（答：`sleep` 只按时间等；`wait()` 可以无参数等待任意长，是无期限的。**关键差异：`wait` 释放锁，`sleep` 不释放**。）

#### sleep vs wait 对比表（面试常考）

| 对比项 | `Thread.sleep(ms)` | `Object.wait()` |
|---|---|---|
| 属于哪个类 | `Thread` 静态方法 | `Object` 实例方法 |
| 是否需要在同步块内 | 不需要 | **必须**在 `synchronized(obj)` 内 |
| 是否释放锁 | **不释放** | **释放**（wait 的核心用途） |
| 唤醒方式 | 时间到 / 被中断 | `notify` / `notifyAll` / 超时 / 中断 |

### 5.3 wait / notify / notifyAll：线程间协作

`wait / notify / notifyAll` 定义在 `Object` 类中，是**基于对象监视器的线程协作机制**。

#### 五条铁律

1. 必须在 **`synchronized(锁对象)`** 块内调用
2. 调用哪个对象的 `wait`，就要用哪个对象的 `notify`
3. `wait()` 会**释放锁**并挂起当前线程
4. `notify()` 只唤醒一个等待中的线程；`notifyAll()` 唤醒所有
5. 唤醒后线程必须**重新获取锁**才能继续执行

#### 经典模式：生产者—消费者

```java
public class Storage {
    private final Queue<Integer> queue = new LinkedList<>();
    private final int capacity = 5;

    public synchronized void put(int v) throws InterruptedException {
        while (queue.size() == capacity) {   // ⚠️ 必须是 while，不能 if
            wait();                          // 满 → 释放锁挂起
        }
        queue.offer(v);
        System.out.println("生产 " + v + " -> 队列 " + queue);
        notifyAll();                         // 通知消费者
    }

    public synchronized int take() throws InterruptedException {
        while (queue.isEmpty()) {
            wait();                          // 空 → 挂起
        }
        int v = queue.poll();
        System.out.println("消费 " + v + " <- 队列 " + queue);
        notifyAll();
        return v;
    }
}
```

启动：

```java
Storage s = new Storage();
new Thread(() -> {
    try { for (int i = 0; i < 10; i++) { s.put(i); Thread.sleep(100); } }
    catch (InterruptedException e) {}
}, "P").start();

new Thread(() -> {
    try { for (int i = 0; i < 10; i++) { s.take(); Thread.sleep(200); } }
    catch (InterruptedException e) {}
}, "C").start();
```

#### 为什么用 `while` 不用 `if`

`notifyAll` 会唤醒所有等待线程，被唤醒后条件不一定还成立（可能被别的线程抢先消费掉）——这叫**虚假唤醒**。用 `while` 保证"醒来后再检查一次条件"。

**划重点**：**wait 一律用 while 循环包起来，不要用 if，这是所有并发教材的第一条准则**。

#### notify vs notifyAll

- `notify()` 只唤醒**任意一个**——性能高，但可能唤错人（生产者唤醒了另一个生产者）
- `notifyAll()` 唤醒**全部**——安全但开销大

多种角色（生产者/消费者共用一个锁）时，请用 `notifyAll`。真正性能敏感时改用 `ReentrantLock` + 多个 `Condition`。

#### Condition：更精细的 wait / notify

```java
Lock lock = new ReentrantLock();
Condition notFull  = lock.newCondition();
Condition notEmpty = lock.newCondition();

// 生产：满则等 notFull，成功后 signalAll(notEmpty)
lock.lock();
try {
    while (isFull()) notFull.await();
    // ... 生产
    notEmpty.signalAll();
} finally { lock.unlock(); }
```

**优势**：只唤醒真正需要的角色（消费者只被消费条件唤醒，不会被其他生产者"惊醒"）。

### 5.4 join、yield、interrupt

#### `join()`：等一个线程结束

```java
Thread worker = new Thread(() -> {
    try { Thread.sleep(2000); } catch (InterruptedException e) {}
    System.out.println("worker 完成");
});
worker.start();
System.out.println("等 worker 结束...");
worker.join();                    // 主线程阻塞，直到 worker 结束
System.out.println("主线程继续");
```

带超时的 `worker.join(1000);`——最多等 1 秒，超时也返回。

**典型用法**：多个子任务并行拉数据，主线程等它们跑完再汇总：

```java
List<Thread> workers = new ArrayList<>();
for (int i = 0; i < 5; i++) {
    Thread t = new Thread(...);
    t.start();
    workers.add(t);
}
for (Thread t : workers) t.join();
System.out.println("所有子任务完成，开始汇总");
```

> 现代代码通常用 `CompletableFuture` 或 `pool.invokeAll` 替代手写 join。

#### `yield()`：礼让 CPU（几乎不用）

```java
Thread.yield();   // 静态方法，作用于当前线程
```

要点：只是**提示**，调度器可以忽略；**不释放锁**；状态仍是 `RUNNABLE`；生产代码几乎用不到。

#### sleep / wait / join / yield 四兄弟对比

| 方法 | 归属 | 是否释放锁 | 状态 | 唤醒方式 |
|---|---|---|---|---|
| `Thread.sleep(ms)` | Thread 静态 | 否 | TIMED_WAITING | 超时 / 中断 |
| `obj.wait()` | Object | **是** | WAITING | `notify` / 中断 |
| `t.join()` | Thread 实例 | 否 | WAITING（或 TIMED_WAITING） | 目标线程结束 / 中断 |
| `Thread.yield()` | Thread 静态 | 否 | RUNNABLE（可能立即再运行） | 调度器决定 |

#### 中断的正确姿势

Java 的中断是**协作式**的，`t.interrupt()` 只是设置一个"中断标记"，被中断线程需要主动检查：

```java
Thread t = new Thread(() -> {
    while (!Thread.currentThread().isInterrupted()) {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // ⚠️ sleep 抛异常后中断标记被清除，需重新设置
            Thread.currentThread().interrupt();
            break;
        }
    }
    System.out.println("优雅退出");
});
t.start();
Thread.sleep(500);
t.interrupt();
```

### 5.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Executors.newFixedThreadPool` 生产 OOM | 默认队列无界；生产用 `new ThreadPoolExecutor(...)` + `ArrayBlockingQueue` |
| 用 `AbortPolicy`（默认）打挂主链路 | 高并发写日志 / 埋点等非关键路径改用 `CallerRunsPolicy` 或 `DiscardOldestPolicy` |
| `wait` 后写业务代码用 `if` 判断条件 | 必须用 `while`——防虚假唤醒 |
| `notify` 一次只唤醒一个，还唤错人 | 多角色场景用 `notifyAll` 或 `Condition` |
| `wait` 抛 `IllegalMonitorStateException` | 忘记放在 `synchronized(锁对象)` 里 |
| `t.join()` 后主线程"卡住" | 目标线程没结束或死锁；用 `join(timeout)` 或排查死锁 |
| `sleep` 抛异常后线程还在跑 | `InterruptedException` 会清中断标记，需要 `Thread.currentThread().interrupt()` 再抛 |
| `Thread.yield()` 用来做限流 | 完全不可靠，调度器可忽略；限流请用信号量 / 令牌桶 |
| `ThreadPoolExecutor` 参数拍脑袋 | CPU 密集用核心数 + 1；IO 密集用核心数 × 2；上线前压测 |

### 5.6 练习/思考

1. 使用 `ThreadPoolExecutor` 自建：核心 2、最大 4、队列容量 2、拒绝策略 `CallerRunsPolicy`。提交 10 个每个 sleep 1 秒的任务，观察每个任务由哪个线程执行。
2. 在 5.3 的生产者—消费者例子上，改用 `ReentrantLock + 两个 Condition`（`notFull` / `notEmpty`），并解释相比 `synchronized + notifyAll` 的优势。
3. 主线程启动 3 个子线程分别 sleep 1s / 2s / 3s，主线程等它们都结束再打印 `"all done"`。
4. 说出 `sleep` 与 `wait` 的至少 3 处不同。
5. 线程 A 打印偶数、线程 B 打印奇数，交替输出 1—10（用 `wait/notify`）。
6. **拓展**：为"上传日志"场景设计一个更合理的拒绝策略——先写入本地磁盘，等空闲时再重新入队。（提示：实现 `RejectedExecutionHandler`，`rejectedExecution(r, pool)` 里落盘。）

---

## 第 6 讲：反射

### 6.1 引入：为什么框架都要用反射

Spring 里我们写的最多的一句话：

```java
@Autowired
private UserService userService;
```

**问题**：Spring 从来没见过你的 `UserService` 这个类，它是怎么知道要 new 一个实例并塞到这个字段里的？

答：**反射**。Spring 在启动时扫到你的类、拿到 `Class` 对象、发现字段上有 `@Autowired`，然后**用反射调用 `field.set(instance, dependency)`** 完成注入。

反射的官方定义：**在运行时动态地获取任意一个类的信息，并操作它的构造器、字段、方法——即使你在编译时并不知道这个类是什么**。

#### 一张图看懂 Class 对象

```mermaid
flowchart LR
    A[.java 源码] -- 编译 --> B[.class 字节码]
    B -- ClassLoader 加载 --> C[方法区中的 Class 对象]
    C -- new --> D[堆中的实例对象]
    C -. 反射 API .-> E[构造器/字段/方法]
```

**划重点**：每个类**在 JVM 中只对应一个 Class 对象**，所有反射操作都从它出发。

#### 反射能做什么

- 根据字符串创建对象：`Class.forName("com.foo.Bar").getDeclaredConstructor().newInstance()`
- 读取 / 修改任意字段（包括 private）
- 调用任意方法（包括 private）
- 读取类上的注解，做元编程
- 生成动态代理（`Proxy.newProxyInstance`）

#### 反射的代价（面试常考）

- **性能**：反射比直接调用慢一个数量级左右（JIT 有优化）
- **安全**：可以突破 `private`，破坏封装
- **可读性**：编译器看不到你调用的是哪个方法，出错运行时才发现
- **稳定性**：反射依赖字段/方法名，一旦重构就断裂

**结论**：一般业务代码不要用反射；框架用反射连接你的类，它们承担这些代价换取灵活性。

### 6.2 讲解：获取 Class 对象的 4 种方式

```java
// 1. 类字面量（编译时静态确定，最快）
Class<String> c1 = String.class;

// 2. 通过对象
String s = "hello";
Class<?> c2 = s.getClass();

// 3. 通过全限定名（最动态，可读配置）
Class<?> c3 = Class.forName("java.lang.String");

// 4. 通过 ClassLoader（框架常用，可控制加载器）
Class<?> c4 = Thread.currentThread().getContextClassLoader().loadClass("java.lang.String");
```

**四者取到的是同一个 Class 对象**：`c1 == c2 == c3 == c4` 都是 `true`。

**互动提问**：为什么 Spring 读配置文件里的类名要用 `Class.forName`，而不是 `String.class`？（答：配置里是**字符串**，只有 `Class.forName` 能把字符串变成类。这才是"动态"的核心。）

### 6.3 讲解：反射三大操作

准备一个示例类，所有例子都用它：

```java
public class User {
    private String name;
    public  int    age;

    public User() { this("匿名", 0); }
    public User(String name, int age) { this.name = name; this.age = age; }
    private User(String name) { this(name, -1); }

    public  void   say(String msg) { System.out.println(name + " 说：" + msg); }
    private String secret()        { return "hidden-" + name; }

    @Override public String toString() { return "User{name=" + name + ", age=" + age + "}"; }
}
```

#### 6.3.1 构造器（Constructor）

```java
Class<?> clazz = Class.forName("com.demo.User");

Constructor<?>[] pub = clazz.getConstructors();          // 所有 public
Constructor<?>[] all = clazz.getDeclaredConstructors();  // 全部（含 private）

Constructor<?> c0 = clazz.getConstructor();                      // 无参
Constructor<?> c2 = clazz.getConstructor(String.class, int.class);
Constructor<?> cp = clazz.getDeclaredConstructor(String.class);  // private
```

创建对象：

```java
User u1 = (User) c0.newInstance();
User u2 = (User) c2.newInstance("Tom", 20);

cp.setAccessible(true);                    // 突破 private
User u3 = (User) cp.newInstance("Jerry");
System.out.println(u3);                    // User{name=Jerry, age=-1}
```

**划重点**：`Class.newInstance()` 已在 Java 9 起被 `@Deprecated`。请用 `getDeclaredConstructor().newInstance()`。

#### 6.3.2 字段（Field）

```java
Class<?> clazz = User.class;

Field[] pub = clazz.getFields();               // public 字段（含继承）
Field[] all = clazz.getDeclaredFields();       // 当前类**全部**字段（不含继承）

Field nameField = clazz.getDeclaredField("name");
nameField.setAccessible(true);                 // private 需先 setAccessible

User u = new User("Tom", 20);
System.out.println(nameField.get(u));          // Tom
nameField.set(u, "Alice");
System.out.println(u);                         // User{name=Alice, age=20}
```

获取类型/名字/修饰符：

```java
System.out.println(nameField.getType());       // class java.lang.String
System.out.println(nameField.getName());       // name
System.out.println(Modifier.toString(nameField.getModifiers()));  // private
```

#### 6.3.3 方法（Method）

```java
Method[] pub = clazz.getMethods();             // public（含继承的 Object 方法）
Method[] all = clazz.getDeclaredMethods();     // 本类全部

Method say    = clazz.getMethod("say", String.class);
Method secret = clazz.getDeclaredMethod("secret");             // private

User u = new User("Tom", 20);
say.invoke(u, "Hello Reflection");             // Tom 说：Hello Reflection

secret.setAccessible(true);
Object r = secret.invoke(u);                   // hidden-Tom
```

**静态方法** 传 null 作为对象：

```java
Method valueOf = Integer.class.getMethod("valueOf", String.class);
Integer i = (Integer) valueOf.invoke(null, "123");   // 静态方法：obj 传 null
```

#### 6.3.4 数组的反射

```java
Object arr = Array.newInstance(int.class, 5);   // 相当于 new int[5]
Array.setInt(arr, 0, 10);
Array.setInt(arr, 1, 20);
System.out.println(Array.getInt(arr, 0));       // 10
System.out.println(Array.getLength(arr));       // 5
```

#### 6.3.5 泛型信息（部分保留）

字段/方法的**声明处**泛型编译后**保留在字节码常量池**中：

```java
class Box { private List<String> items; }

Field f = Box.class.getDeclaredField("items");
System.out.println(f.getType());              // interface java.util.List
System.out.println(f.getGenericType());       // java.util.List<java.lang.String>

ParameterizedType pt = (ParameterizedType) f.getGenericType();
System.out.println(pt.getActualTypeArguments()[0]);   // class java.lang.String
```

⚠️ 这只是"签名信息"，运行时对象本身仍然被擦除（回顾 Day01 第 1 讲的泛型擦除）。

### 6.4 讲解：反射的典型应用

#### 6.4.1 场景总览

| 场景 | 用反射做什么 |
|---|---|
| Spring IoC | 读配置类名，反射创建 Bean，注入依赖 |
| MyBatis | 反射把 `ResultSet` 结果映射到 JavaBean |
| Jackson / Gson | 反射读写字段，实现 JSON ↔ 对象 |
| JUnit | 找到带 `@Test` 注解的方法反射调用 |
| 动态代理 | 生成实现某个接口的代理对象，拦截方法 |
| 插件/扩展系统 | 主程序不依赖插件类，运行时按名加载 |

#### 6.4.2 迷你 @Autowired（反射 + 注解 = 元编程）

```java
public @interface Autowired { }

public class Container {
    private final Map<Class<?>, Object> beans = new HashMap<>();

    public <T> void register(Class<T> type, T instance) { beans.put(type, instance); }

    public void wire(Object bean) throws Exception {
        for (Field f : bean.getClass().getDeclaredFields()) {
            if (f.isAnnotationPresent(Autowired.class)) {
                Object dep = beans.get(f.getType());
                if (dep == null) throw new IllegalStateException("找不到 bean: " + f.getType());
                f.setAccessible(true);
                f.set(bean, dep);
            }
        }
    }
}
```

使用：

```java
class UserService { @Autowired UserRepository repo; }

Container c = new Container();
c.register(UserRepository.class, new UserRepository());
UserService svc = new UserService();
c.wire(svc);   // 现在 svc.repo 已经被反射注入
```

**划重点**：短短几十行，把 Spring 最核心的思想演示了一遍——**反射 + 注解 = 元编程**。明天第 7 讲会深入注解，这两讲要连着理解。

#### 6.4.3 迷你 JSON 序列化器

```java
public static String toJson(Object obj) throws IllegalAccessException {
    StringBuilder sb = new StringBuilder("{");
    Class<?> c = obj.getClass();
    Field[] fields = c.getDeclaredFields();
    for (int i = 0; i < fields.length; i++) {
        Field f = fields[i];
        f.setAccessible(true);
        Object v = f.get(obj);
        sb.append("\"").append(f.getName()).append("\":");
        if (v instanceof String s) sb.append("\"").append(s).append("\"");
        else                       sb.append(v);
        if (i < fields.length - 1) sb.append(",");
    }
    return sb.append("}").toString();
}

System.out.println(toJson(new User("Tom", 20)));   // {"name":"Tom","age":20}
```

Jackson 处理了很多边界情况，本质套路相同。

#### 6.4.4 动态代理（Spring AOP 的底层）

```java
public interface Hello { String hi(String name); }

Hello proxy = (Hello) Proxy.newProxyInstance(
    Hello.class.getClassLoader(),
    new Class<?>[] { Hello.class },
    (obj, method, args) -> {
        System.out.println("调用前打点");
        String r = "hi, " + args[0];
        System.out.println("调用后打点");
        return r;
    });

System.out.println(proxy.hi("Tom"));
```

动态代理是 **Spring AOP、日志切面、事务包装**的底层实现。

### 6.5 讲解：反射的局限与最佳实践

- **优先普通调用**：能不反射就不反射
- **缓存 Field / Method**：`getDeclaredField` 每次都要遍历，缓存后能显著加速
- **`setAccessible(true) 一次即可`**：不要每次调用都重复设置
- **模块化后受限**：Java 9+ 模块系统会阻止跨模块反射非导出包，需 `--add-opens`
- **性能敏感场景**：换成 `MethodHandle`（比反射快）或代码生成（ASM / Byte Buddy）

### 6.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `NoSuchFieldException: xxx` | 字段名拼错 / 字段在父类里；`getField` 找不到 private，改 `getDeclaredField` |
| `IllegalAccessException` | 访问 private 忘了 `setAccessible(true)` |
| `getFields()` 拿不到私有字段 | `getFields` 只返回 public，用 `getDeclaredFields` |
| `getDeclaredFields()` 拿不到父类字段 | 只查当前类；需要递归 `clazz = clazz.getSuperclass()` |
| 反射调用 static 方法传了 obj 参数 | 静态方法：`method.invoke(null, args)`，obj 传 null |
| JDK 17+ `setAccessible` 抛 `InaccessibleObjectException` | 强封装：JDK 内部包（如 `String.value`）默认拒绝反射；需启动加 `--add-opens java.base/java.lang=ALL-UNNAMED`（不建议） |
| 反射调用抛 `InvocationTargetException` | 目标方法本身抛的异常被包裹了；`getCause()` 取真实异常 |
| 反射性能慢 | 缓存 `Method`/`Field` 对象；或改用 `MethodHandle` |
| `newInstance()` 编译警告 | 已 deprecated，改 `getDeclaredConstructor().newInstance()` |
| 拿不到泛型实参 | 只有**声明处**的泛型能读到（`getGenericType`），运行时实例被擦除 |

### 6.7 练习/思考

1. 用反射打印任意 Java 类的完整信息：包名、父类、实现接口、所有构造器（含 private）、所有字段、所有方法。
2. 给定字符串 `"java.util.ArrayList"`，用反射创建一个 `ArrayList<String>` 并 add 三个元素。
3. 写一个 `void copy(Object src, Object dst)`：把 src 的所有非 static 字段的值复制到 dst 上（要求 src 和 dst 是同一类型）。
4. 定义注解 `@Print`，标注在字段上。写一个方法 `printFields(Object obj)`，只打印带 `@Print` 的字段。
5. 说明为什么下面代码在 JDK 17+ 可能抛异常：
   ```java
   Field f = String.class.getDeclaredField("value");
   f.setAccessible(true);
   ```
6. **拓展**：用动态代理实现 `AuditLogProxy`：对任意接口的方法调用，前后打印方法名、参数、返回值和耗时。

---

## 本日收束

### 承前启后

- **第 5 讲 线程进阶**——上午在昨天线程池的基础上继续深挖：`ExecutorService` 的完整生命周期、`Future` / `CompletableFuture` 异步编排、线程状态机、`wait/notify` 协作。这是 Spring `@Async`、`CompletableFuture` 流水线、消息队列消费者的底层运行方式。
- **第 6 讲 反射**——下午让你能**在运行时读写类的元数据**：`Class` / `Method` / `Field` / `Constructor` / 动态代理。反射是**框架的通用语言**，Spring、MyBatis、Jackson、JUnit 全建在它上面。

今天两讲连起来，你就能理解为什么 Spring "看起来什么都没做但一切都能跑起来"——它在启动时用**反射**扫描类、用**线程池**跑异步任务，把所有依赖穿针引线。

### 6 天旅程中的定位

| Day | 主题 | 今日贡献 |
|---|---|---|
| 01 | 泛型 + 异常 | 类型系统 + 错误处理 |
| 02 | IO + 线程基础 | 数据 I/O + 并发起点 |
| **03** | **线程进阶 + 反射** | **框架底座：并发编排 + 元数据识别** |
| 04 | 注解 + 集合精讲 | 注解 = 反射的搭档 |
| 05 | 数据结构 + 内部类接口 | 集合的原理与设计 |
| 06 | Lambda/Stream + Optional/日期 | 声明式数据处理 |

### 作业

1. **必做**：第 5 讲、第 6 讲末尾练习各选做 3 道。
2. **拓展**：动态代理版 `AuditLogProxy`（第 6 讲拓展题）——写完可以直接拿来当日志切面用。
3. **提交**：代码提交到 `ai-programming-advanced/day03/`。明天进入注解（第 7 讲）和集合精讲（第 8 讲），今天的反射会被立刻用上。

---

[⬅️ Day02](day02.md) | [返回目录](../教材/目录.md) | [Day04 ➡️](day04.md)
