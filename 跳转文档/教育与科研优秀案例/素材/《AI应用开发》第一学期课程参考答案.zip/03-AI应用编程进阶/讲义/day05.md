# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day05：数据结构 + 内部类与接口增强）

**总课时**：6 讲（其中 Day05 覆盖第 9 讲、第 10 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成 Day04（注解 + 集合精讲）
**参考教材**：`02-AI应用编程进阶/教材/chapters/09.md`（第 9 章 数据结构与手动实现）、`10.md`（第 10 章 内部类与接口增强）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 9 讲 | 数据结构与手动实现 | 亲手写 `MyArrayList` / 单链表 / 栈 / 队列 / `MyHashMap`；理解 JDK 源码里那些"多出来的细节" |
| 第 10 讲 | 内部类与接口增强 | 区分四种内部类；掌握接口 `default`/`static`/`private`；能在合适场景选用 `record` 与 `sealed` |

---

## 第 9 讲：数据结构与手动实现

### 9.1 引入：昨天的集合是"黑盒"，今天我们拆开

Day04 你已经能熟练地 `new ArrayList<>()`、`new HashMap<>()`，选型也有底了。但**你说得出为什么 `ArrayList.get(i)` 是 O(1) 吗？为什么 `HashMap.put(key)` 快到"一步就能找到桶"？**

要把面试和后续源码阅读的天花板打破，必须**亲手写一遍**。今天上午的目标：

- 手写 `MyArrayList`（动态数组）
- 手写 `MyLinkedList`（单链表）
- 手写 `MyStack` / `MyQueue`（栈 / 循环数组队列）
- 手写 `MyHashMap`（拉链法哈希表）

**划重点**：写玩具版不是为了跟 JDK 比快，是为了理解"工业级实现在你的玩具之上多做了什么"。这才是从"会用"到"看懂源码"的桥。

### 9.2 数据结构总览

```mermaid
flowchart TB
    A[数据结构] --> L[线性结构]
    A --> N[非线性结构]

    L --> L1[数组]
    L --> L2[链表]
    L --> L3[栈]
    L --> L4[队列]

    N --> N1[树]
    N --> N2[图]
    N --> N3[散列表]
```

| 结构 | 特点 | 典型 Java 容器 |
|---|---|---|
| 数组 | 连续内存、O(1) 随机访问 | `int[]`、`ArrayList` |
| 链表 | 节点通过引用相连、增删灵活 | `LinkedList` |
| 栈 | LIFO | `Deque` / `ArrayDeque` |
| 队列 | FIFO | `Queue` / `ArrayDeque` / `LinkedList` |
| 哈希表 | key → 桶下标 → 桶内查找 | `HashMap`、`HashSet` |
| 二叉搜索树 / 红黑树 | 有序、O(log n) | `TreeMap`、`TreeSet` |
| 堆 | 完全二叉树，堆顶最优 | `PriorityQueue` |

### 9.3 讲解：手动实现 MyArrayList

#### 核心思路

底层用一个 `Object[]` 存元素，`size` 记录当前长度。**扩容**时 new 一个 1.5 倍新数组，`System.arraycopy` 搬迁。

```java
public class MyArrayList<E> {
    private Object[] data;
    private int size;

    public MyArrayList() { this.data = new Object[10]; }

    public int size()      { return size; }
    public boolean isEmpty() { return size == 0; }

    public void add(E e) {
        ensureCapacity(size + 1);
        data[size++] = e;
    }

    public void add(int index, E e) {
        checkIndexForAdd(index);
        ensureCapacity(size + 1);
        System.arraycopy(data, index, data, index + 1, size - index);
        data[index] = e;
        size++;
    }

    @SuppressWarnings("unchecked")
    public E get(int index) {
        checkIndex(index);
        return (E) data[index];
    }

    public E set(int index, E e) {
        checkIndex(index);
        @SuppressWarnings("unchecked")
        E old = (E) data[index];
        data[index] = e;
        return old;
    }

    public E remove(int index) {
        checkIndex(index);
        @SuppressWarnings("unchecked")
        E old = (E) data[index];
        int move = size - index - 1;
        if (move > 0) System.arraycopy(data, index + 1, data, index, move);
        data[--size] = null;         // help GC
        return old;
    }

    private void ensureCapacity(int need) {
        if (need <= data.length) return;
        int newCap = data.length + (data.length >> 1);   // 1.5 倍
        if (newCap < need) newCap = need;
        data = Arrays.copyOf(data, newCap);
    }

    private void checkIndex(int i) {
        if (i < 0 || i >= size) throw new IndexOutOfBoundsException(i);
    }
    private void checkIndexForAdd(int i) {
        if (i < 0 || i > size) throw new IndexOutOfBoundsException(i);
    }
}
```

**划重点**：三个细节

1. **1.5 倍扩容**：`newCap = old + (old >> 1)`——位运算比 `* 1.5` 快，且避免浮点
2. **`data[--size] = null`**：不置 null 会拖着旧对象的引用，GC 回收不了——这就是 JDK 里叫 "help GC" 的经典优化
3. **`System.arraycopy` 是 native 方法**：比手写 for 循环快好几倍，做集合操作首选

#### 与 JDK ArrayList 的差异

- JDK 版本包含 `modCount` 用于 **fail-fast** 迭代器（回顾 Day04：`for-each` 中 `remove` 报 CME 就是它抛的）
- 提供 `trimToSize()`、`clear()`、`iterator()` 等
- 初始容量 0 → 首次 `add` 才扩到 10（懒初始化，节省内存）

**互动提问**：为什么 JDK 用 `Object[]` 而不是 `E[]`？（答：泛型擦除，运行时没有 `E`。用 `new E[]` 编译不过；用 `(E[]) new Object[...]` 强转会给未检查警告，代码里就写成 `Object[]`。）

### 9.4 讲解：手动实现 MyLinkedList（单链表）

```java
public class MyLinkedList<E> {
    private static class Node<E> {
        E val;
        Node<E> next;
        Node(E val, Node<E> next) { this.val = val; this.next = next; }
    }

    private Node<E> head;
    private int size;

    public int size() { return size; }

    public void addFirst(E e) {
        head = new Node<>(e, head);
        size++;
    }

    public void addLast(E e) {
        if (head == null) { head = new Node<>(e, null); size++; return; }
        Node<E> p = head;
        while (p.next != null) p = p.next;
        p.next = new Node<>(e, null);
        size++;
    }

    public E get(int index) {
        checkIndex(index);
        Node<E> p = head;
        for (int i = 0; i < index; i++) p = p.next;
        return p.val;
    }

    public E removeFirst() {
        if (head == null) throw new NoSuchElementException();
        E v = head.val;
        head = head.next;
        size--;
        return v;
    }

    public boolean contains(E e) {
        for (Node<E> p = head; p != null; p = p.next) {
            if (Objects.equals(p.val, e)) return true;
        }
        return false;
    }

    private void checkIndex(int i) {
        if (i < 0 || i >= size) throw new IndexOutOfBoundsException(i);
    }
}
```

#### 关键点

- **单链表尾插 O(n)**：需从头遍历到尾。工业级 `LinkedList` 用**双向 + 尾指针**，尾插 O(1)
- **删除中间节点**：需拿到"前驱节点"——单链表要遍历，双向链表直接
- **help GC**：删除节点后把 `next = null` 断开引用，避免拖住整链
- **`Node` 为什么写成 `static` 内部类**？下一讲会讲到——因为 Node 本身不需要外部类实例的引用

#### 经典链表题：反转（面试必考）

```java
public static <E> Node<E> reverse(Node<E> head) {
    Node<E> prev = null;
    Node<E> curr = head;
    while (curr != null) {
        Node<E> next = curr.next;    // 先记录下一个
        curr.next = prev;            // 反转指针
        prev = curr;                 // prev 前移
        curr = next;                 // curr 前移
    }
    return prev;
}
```

**图示**：三指针 `prev`、`curr`、`next`，一次遍历，O(n) 时间 O(1) 空间。所有反转变体（反转前 k 个、反转 [m, n]、反转每 k 个）都是这个模板。

### 9.5 讲解：栈与队列

#### 用数组实现栈

```java
public class MyStack<E> {
    private Object[] data;
    private int top;   // 指向下一个可写入位置

    public MyStack() { data = new Object[16]; top = 0; }

    public void push(E e) {
        if (top == data.length) data = Arrays.copyOf(data, data.length * 2);
        data[top++] = e;
    }

    @SuppressWarnings("unchecked")
    public E pop() {
        if (top == 0) throw new NoSuchElementException();
        E v = (E) data[--top];
        data[top] = null;
        return v;
    }

    @SuppressWarnings("unchecked")
    public E peek() {
        if (top == 0) throw new NoSuchElementException();
        return (E) data[top - 1];
    }

    public boolean isEmpty() { return top == 0; }
}
```

#### 用循环数组实现队列（重点）

普通数组做队列的问题：`poll` 从头拿走后，前面的位置就浪费了；如果每次都搬迁又是 O(n)。**解决方案：循环数组**——`head` 和 `tail` 各自前进，用 `% length` 绕回。

```java
public class MyQueue<E> {
    private Object[] data;
    private int head, tail, size;

    public MyQueue() { data = new Object[16]; }

    public void offer(E e) {
        if (size == data.length) grow();
        data[tail] = e;
        tail = (tail + 1) % data.length;
        size++;
    }

    @SuppressWarnings("unchecked")
    public E poll() {
        if (size == 0) throw new NoSuchElementException();
        E v = (E) data[head];
        data[head] = null;
        head = (head + 1) % data.length;
        size--;
        return v;
    }

    private void grow() {
        Object[] bigger = new Object[data.length * 2];
        for (int i = 0; i < size; i++) {
            bigger[i] = data[(head + i) % data.length];
        }
        data = bigger;
        head = 0;
        tail = size;
    }
}
```

**划重点**：JDK 的 `ArrayDeque` 更进一步——**容量强制为 2 的幂**，用位运算 `& (n-1)` 替代 `% n`（快很多）。你现在能理解为什么它这么设计了。

**互动提问**：`size` 变量能省掉吗？（答：可以只用 `head` / `tail` 表示"空"和"满"，但需要牺牲一个位置——`(tail + 1) % n == head` 表示满，`head == tail` 表示空。多一个 `size` 更直观且不浪费。）

### 9.6 讲解：手动实现 MyHashMap（本讲核心）

#### 哈希表原理

```mermaid
flowchart LR
    K[key] -- hashCode --> H[hash]
    H -- 位运算取下标 --> I[桶下标]
    I --> B0[桶 0]
    I --> B1[桶 1]
    I --> B2[桶 2]
    B1 --> N1[Node k1 v1]
    N1 --> N2[Node k2 v2]
```

三步：
1. `key.hashCode()` 得到 hash 值
2. hash 映射到桶下标 `(len - 1) & hash`
3. 桶内可能已有别的键（**哈希冲突**）→ **拉链法**：桶里挂一条链表

JDK 8 优化：桶内链表过长（长度 > 8 且表容量 ≥ 64）→ **转红黑树**，最坏查找从 O(n) 优化到 O(log n)。

#### 手写 MyHashMap

```java
public class MyHashMap<K, V> {
    private static class Node<K, V> {
        final int hash;
        final K key;
        V val;
        Node<K, V> next;
        Node(int hash, K k, V v, Node<K, V> next) {
            this.hash = hash; this.key = k; this.val = v; this.next = next;
        }
    }

    private Node<K, V>[] table;
    private int size;
    private static final int INIT_CAP = 16;
    private static final double LOAD = 0.75;

    @SuppressWarnings("unchecked")
    public MyHashMap() {
        table = (Node<K, V>[]) new Node[INIT_CAP];
    }

    public V put(K key, V val) {
        int h = hash(key);
        int i = index(h, table.length);
        // 桶内查找
        for (Node<K, V> p = table[i]; p != null; p = p.next) {
            if (p.hash == h && Objects.equals(p.key, key)) {
                V old = p.val; p.val = val; return old;
            }
        }
        // 头插新节点
        table[i] = new Node<>(h, key, val, table[i]);
        if (++size > table.length * LOAD) resize();
        return null;
    }

    public V get(K key) {
        int h = hash(key);
        int i = index(h, table.length);
        for (Node<K, V> p = table[i]; p != null; p = p.next) {
            if (p.hash == h && Objects.equals(p.key, key)) return p.val;
        }
        return null;
    }

    public V remove(K key) {
        int h = hash(key);
        int i = index(h, table.length);
        Node<K, V> prev = null, p = table[i];
        while (p != null) {
            if (p.hash == h && Objects.equals(p.key, key)) {
                if (prev == null) table[i] = p.next;
                else               prev.next = p.next;
                size--;
                return p.val;
            }
            prev = p; p = p.next;
        }
        return null;
    }

    private static int hash(Object key) {
        if (key == null) return 0;
        int h = key.hashCode();
        return h ^ (h >>> 16);           // JDK 同款「扰动」
    }
    private static int index(int hash, int len) {
        return (len - 1) & hash;         // len 是 2 的幂，等价于取模
    }

    @SuppressWarnings("unchecked")
    private void resize() {
        Node<K, V>[] old = table;
        Node<K, V>[] next = (Node<K, V>[]) new Node[old.length * 2];
        for (Node<K, V> head : old) {
            for (Node<K, V> p = head; p != null; ) {
                Node<K, V> nx = p.next;
                int i = index(p.hash, next.length);
                p.next = next[i];
                next[i] = p;
                p = nx;
            }
        }
        table = next;
    }
}
```

**划重点**：三处 JDK 精髓

1. **扰动函数** `h ^ (h >>> 16)`：把 hash 的高 16 位混入低 16 位，减少冲突（下标只用低几位，如果不扰动，只有低位不同的 key 会全部撞车）
2. **`(len - 1) & hash` 替代 `% len`**：前提是 `len` 是 2 的幂；这也是为什么 HashMap 容量总被扩到 16、32、64...
3. **`load factor 0.75`**：当元素数 > 桶数 × 0.75 就扩容，平衡"内存占用"和"冲突概率"

#### 测试

```java
MyHashMap<String, Integer> map = new MyHashMap<>();
map.put("a", 1); map.put("b", 2); map.put("c", 3);
System.out.println(map.get("b"));   // 2
map.put("b", 22);
System.out.println(map.get("b"));   // 22
map.remove("a");
System.out.println(map.get("a"));   // null
```

#### hashCode / equals 的三条铁律

1. `a.equals(b) == true` → `a.hashCode() == b.hashCode()` **必须**相同
2. hashCode 一致，equals **不一定** true（允许冲突）
3. 用作 HashMap key 的对象，**字段应尽量不可变**——put 后修改字段会让 hash 位置错乱，`get` 就查不到自己刚 put 的值

**互动提问**：如果只重写 `equals` 不重写 `hashCode` 会怎样？（答：两个 equals 相等的对象可能被分到不同桶，`get` 找不到自己刚 put 的东西——是新手用自定义类做 key 时的经典 bug。）

### 9.7 数据结构选择速查表（背下来）

| 需求 | 首选容器 |
|---|---|
| 频繁按下标随机访问 | `ArrayList` |
| 频繁头尾插入 / 出队 | `ArrayDeque` |
| 大量插入 + 少量查找 + 需要唯一 | `HashSet` |
| 有序遍历 + 唯一 | `TreeSet` / `LinkedHashSet` |
| K → V 快查（多数场景） | `HashMap` |
| K → V 按 key 排序 | `TreeMap` |
| K → V 按插入 / 访问顺序遍历（LRU 缓存） | `LinkedHashMap` |
| 优先级排序取最优 | `PriorityQueue` |
| 高并发 K → V | `ConcurrentHashMap` |

### 9.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `remove` 后旧元素还在内存里没释放 | 忘了 `data[i] = null` help GC |
| 泛型数组编译报错 `Cannot create a generic array` | 用 `Object[]` 存元素，get 时强转 |
| `System.arraycopy` 用错方向导致数据被覆盖 | 参数：src、srcPos、dst、dstPos、len；插入前搬 index → index+1 |
| 单链表反转卡壳 | 三指针 `prev / curr / next` 模板必须熟记 |
| 用普通数组做队列越用越慢 | 前面位置浪费；改循环数组 `head` / `tail` |
| 自定义类作 HashMap key `get` 返回 null | 只重写了 `equals`，没重写 `hashCode` |
| 用 HashMap key 是可变对象，改字段后查不到 | key 应尽量不可变（用 record、String、Integer） |
| `hash & (len - 1)` 结果异常 | `len` 必须是 2 的幂，才等价于取模 |
| 高并发下 HashMap 死循环 (JDK 7) | JDK 8 已修复；生产多线程直接用 ConcurrentHashMap |
| 拉链法链表长度失控 | JDK 8 会树化（> 8 且容量 ≥ 64）；自写玩具版可忽略 |

### 9.9 练习/思考

1. 给 `MyArrayList` 增加 `indexOf(E)` 与 `iterator()`，支持 for-each。
2. 把 `MyLinkedList` 改造成**双向链表 + 尾指针**：`addLast` / `removeLast` 都做到 O(1)。
3. 用两个栈实现一个队列：`enqueue` 和 `dequeue` 都要摊还 O(1)。
4. 给 `MyHashMap` 增加 `keySet()` / `values()` / `entrySet()` 三个方法。
5. 用你的 `MyHashMap` 存入自定义类 `Point(int x, int y)`。故意不重写 `hashCode`，观察 `get` 的行为，然后加上正确的 `hashCode` / `equals` 再测。
6. **拓展**：把 `MyQueue` 改成 `MyDeque`，支持四端操作 `addFirst` / `addLast` / `pollFirst` / `pollLast`。

---

## 第 10 讲：内部类与接口增强

### 10.1 引入：昨天的 Node 为什么要写成 static？

回顾 9.4 的 `MyLinkedList`：

```java
public class MyLinkedList<E> {
    private static class Node<E> { ... }    // ← 这里的 static 很关键
    ...
}
```

如果去掉 `static`，代码还能编译，但**每个 Node 会额外持有一个 `MyLinkedList` 的引用**，浪费内存不说，还会阻止外层对象被 GC。今天上午的目标：**把 Java 的 4 种内部类彻底搞清楚**。

Java 有四类内部类：

```mermaid
flowchart TB
    A[类中定义的类] --> B[成员内部类<br/>非 static]
    A --> C[静态嵌套类<br/>static]
    A --> D[局部内部类<br/>方法体内]
    A --> E[匿名内部类<br/>new 时创建]
```

### 10.2 讲解：成员内部类

写在类里面，**不加 static**。它**持有外部类实例的隐式引用**，因此能自由访问外部类的字段和方法（包括 `private`）。

```java
public class Outer {
    private String name = "outer";

    public class Inner {
        public void hello() {
            System.out.println("Inner hello, outer.name = " + name);  // 直接访问 private
        }
    }
}

// 使用
Outer outer = new Outer();
Outer.Inner inner = outer.new Inner();   // ⚠️ 必须先有 outer 才能 new Inner
inner.hello();
```

#### 访问同名字段：`外部类.this`

```java
public class Outer {
    private int x = 10;
    public class Inner {
        private int x = 20;
        public void print() {
            int x = 30;
            System.out.println(x);              // 30（局部）
            System.out.println(this.x);         // 20（Inner）
            System.out.println(Outer.this.x);   // 10（Outer）
        }
    }
}
```

**划重点**：三层同名，用 `外部类.this.字段` 明确指定外部实例——面试常考。

#### 陷阱

- 每个 Inner 实例都持有 Outer 引用 → **可能导致内存泄漏**（Android 里因 Activity 引用泄漏是经典事故）
- 反射创建时要传外部类实例，容易出错
- 结论：**没有必须访问外部实例的需求，就写成静态嵌套类**

### 10.3 讲解：静态嵌套类（最常用）

内部类前加 `static`：**没有外部类实例的隐式引用**，是一个"碰巧写在里面"的独立类。

```java
public class Outer {
    private static String flag = "F";

    public static class Node {
        int val;
        Node next;
        Node(int val) { this.val = val; }
        public String tag() { return flag; }   // 可以访问外部**静态**成员
    }
}

// 使用（不需要外部实例）
Outer.Node n = new Outer.Node(1);
```

#### 典型用途

- **辅助数据结构**：`HashMap.Node`、`ArrayList` 的迭代器（回顾昨天的 `MyHashMap.Node` / `MyLinkedList.Node`）
- **Builder 模式**：`User.Builder`
- 想强调"这个类只属于外部类的作用域"时的命名空间

#### Builder 示例

```java
public class User {
    private final String name;
    private final int    age;
    private User(Builder b) { this.name = b.name; this.age = b.age; }

    public static class Builder {
        private String name;
        private int    age;
        public Builder name(String n) { this.name = n; return this; }
        public Builder age(int a)     { this.age  = a; return this; }
        public User build()           { return new User(this); }
    }
}

// 使用
User u = new User.Builder().name("Tom").age(20).build();
```

**互动提问**：为什么 Builder 要写成 static？（答：`new User.Builder()` 时还没有 User 实例，非 static 就 new 不出来。而且 Builder 本来就不需要访问 User 的成员。）

### 10.4 讲解：局部内部类

写在**方法体内**的类，只在该方法内可见。

```java
public void run() {
    class Local {
        void hi() { System.out.println("local"); }
    }
    new Local().hi();
}
```

#### effectively final 限制

局部内部类访问所在方法的局部变量时，该变量必须是 `final` 或**实际不变**（effectively final）：

```java
public Runnable task() {
    int x = 10;
    // x = 11;    // 一旦有再次赋值，就不是 effectively final，下面会编译报错
    return new Runnable() {
        @Override public void run() { System.out.println(x); }
    };
}
```

**原因**：局部变量随栈帧消亡，编译器实际是把它**复制**进对象里；如果外部改了内部看不到，两者不一致。Java 干脆禁止修改。

**划重点**：局部内部类实际很少用，理解 effectively final 更重要——**Lambda 也有同样限制**，明天讲 Lambda 会遇到。

### 10.5 讲解：匿名内部类

"只用一次"的内部类，`new 类型() { ... }` 直接同时声明并实例化。

```java
Runnable r = new Runnable() {
    @Override public void run() { System.out.println("running"); }
};
new Thread(r).start();

Comparator<Integer> desc = new Comparator<Integer>() {
    @Override public int compare(Integer a, Integer b) { return b - a; }
};
```

#### Lambda 是匿名内部类的语法糖吗？

**几乎，但不完全等价**：

| 对比项 | 匿名内部类 | Lambda |
|---|---|---|
| 语法 | 冗长 | 简洁 |
| 编译产物 | 独立 `.class` 文件 | `invokedynamic + LambdaMetafactory`，不生成额外 `.class` |
| `this` 的含义 | 指自身（匿名对象） | 指**外部类**实例 |
| 适用范围 | 任意接口 / 抽象类 | 只能替代**函数式接口**（一个抽象方法） |

```java
Runnable r1 = () -> System.out.println("lambda");           // ✅
Comparator<Integer> c = (a, b) -> b - a;                    // ✅

// 接口有多个抽象方法，Lambda 不适用，只能用匿名内部类
WindowListener listener = new WindowAdapter() {
    @Override public void windowClosing(WindowEvent e) { ... }
};
```

**划重点**：明天第 11 讲会正式讲 Lambda 和函数式接口——今天先理解**匿名类是老写法**，多数场景 Lambda 会替代它。

### 10.6 讲解：接口增强（JDK 8+）

Java 8 起接口不再是"纯抽象方法"的容器。

#### 默认方法（default）

允许接口提供**默认实现**，实现类可选择不覆盖。

```java
public interface Greeter {
    void hello();

    default void hi() {
        System.out.println("hi from default");
        hello();
    }
}

class ChineseGreeter implements Greeter {
    @Override public void hello() { System.out.println("你好"); }
}

new ChineseGreeter().hi();
// hi from default
// 你好
```

**用途**：给已有接口**加新方法而不破坏所有实现类**。`List.forEach`、`removeIf`、`sort` 都是 JDK 8 用这招加进 `List` 接口的。

#### 静态方法

接口里可以直接写 `static` 工具方法：

```java
public interface Calculator {
    static int square(int x) { return x * x; }
}

int v = Calculator.square(5);
```

`List.of`、`Map.of`、`Stream.of` 都是接口静态方法。

#### 私有方法（JDK 9+）

抽取多个 default 方法之间的公共代码，**不对外暴露**：

```java
public interface Logger {
    default void info(String msg)  { log("INFO",  msg); }
    default void warn(String msg)  { log("WARN",  msg); }
    default void error(String msg) { log("ERROR", msg); }

    private void log(String level, String msg) {
        System.out.println("[" + level + "] " + msg);
    }
}
```

#### 钻石继承与冲突

一个类实现了两个都有相同 default 方法的接口 → 编译错误，**必须显式覆盖**。

```java
interface A { default String name() { return "A"; } }
interface B { default String name() { return "B"; } }

class C implements A, B {
    @Override public String name() {
        return A.super.name() + "+" + B.super.name();     // 显式指定
    }
}
```

**划重点**：`接口名.super.方法名` 是指定"调用哪个父接口的 default"的唯一方式。

#### 接口 vs 抽象类

| 对比 | 接口 | 抽象类 |
|---|---|---|
| 关键字 | `interface` | `abstract class` |
| 单继承 / 多继承 | **多实现** | 单继承 |
| 字段 | 只能是 `public static final` 常量 | 任意字段 |
| 构造器 | 无 | 有 |
| 方法 | abstract / default / static / private | 任意 |
| 语义 | "像/能做…"（横切能力） | "是一个"（继承层次） |

### 10.7 讲解：Record（JDK 16+ 稳定）

`record` 是**不可变数据载体**的语法糖。

```java
public record Point(int x, int y) { }
```

编译器自动生成：

- `private final` 字段 `x`、`y`
- 全参构造器 `Point(int x, int y)`
- `x()`、`y()` 访问器（**不是** `getX`）
- `equals` / `hashCode`（按所有字段）
- `toString`：`Point[x=..., y=...]`

```java
Point p = new Point(1, 2);
System.out.println(p.x());        // 1
System.out.println(p);            // Point[x=1, y=2]
```

#### 紧凑构造器与自定义方法

```java
public record Point(int x, int y) {
    // 紧凑构造器：校验或规范化输入
    public Point {
        if (x < 0 || y < 0) throw new IllegalArgumentException();
    }

    // 静态工厂
    public static Point origin() { return new Point(0, 0); }

    // 自定义方法
    public double distance(Point other) {
        int dx = x - other.x, dy = y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }
}
```

#### 使用场景

- DTO / VO：从数据库或 API 读出来的一次性对象
- Map 中的复合 key（`equals` / `hashCode` 天然到位——**回顾昨天 HashMap 的三条铁律，record 自动满足**）
- 局部聚合：`record Pair<A, B>(A a, B b) { }`

#### 限制

- 隐式 `final`，**不能被继承**
- 不能显式声明实例字段（想放字段就变成普通类）
- 所有组件都是 `final`，需要可变字段的场景不适用

### 10.8 讲解：Sealed 类（JDK 17+ 稳定）

`sealed` 类 / 接口显式列出"允许有哪些子类型"，编译器负责检查。让**代数数据类型（ADT）风格**成为可能。

```java
public sealed interface Shape permits Circle, Rectangle, Triangle { }

public final  class Circle    implements Shape { public double r; }
public final  class Rectangle implements Shape { public double w, h; }
public non-sealed class Triangle implements Shape { }   // 允许被继续继承
```

规则：
- 父：`sealed` + `permits ...`
- 子必须是 `final` / `sealed` / `non-sealed` 之一
- 子类型必须**在同一模块（或未命名模块下的同一包）**

#### 结合 record 与 pattern matching

```java
public sealed interface Shape permits Circle, Rectangle { }
public record Circle(double r)              implements Shape { }
public record Rectangle(double w, double h) implements Shape { }

public static double area(Shape s) {
    return switch (s) {
        case Circle    c -> Math.PI * c.r() * c.r();
        case Rectangle r -> r.w() * r.h();
    };
}
```

**划重点**：编译器知道 `Shape` 只有这两个子类型——**switch 无须 default，也不会漏掉分支**。这是"穷举检查"，比手写 default 更安全。

#### 使用场景

- 领域模型的封闭代数：`Result` = `Ok | Err`；`Event` = `Login | Logout | Purchase`
- 需要"模式匹配 + 完备性检查"时

### 10.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Node 内部类不写 static → 内存膨胀 | 数据节点不需要外部实例引用；一律加 `static` |
| Android 的 Handler 匿名类导致 Activity 泄漏 | 内部类持有外层引用；改静态 + WeakReference |
| Lambda 中修改外部变量编译报错 | effectively final；把变量放数组或用 AtomicInteger |
| 两个接口 default 方法冲突不覆盖 | 编译错误；必须写 `A.super.方法()` 显式选择 |
| 想给已有接口加方法但会破坏子类 | 用 `default` 加，附上合理默认实现 |
| record 想加 setter | 不允许——record 就是不可变；改回普通类 |
| record 想继承 | 不允许——record 隐式 `final`；用普通 class + Lombok 替代 |
| sealed 子类跨模块 | 编译错误；permits 的类型必须同模块 |
| 匿名内部类的 `this` 指的不是外部类 | 用 `Outer.this` 明确；这也是 Lambda 相对匿名类的 subtle 差别 |
| 接口写 `private static` 方法忘了 static | 私有方法可以 static 也可以非 static，看是否要用其它 default |

### 10.10 练习/思考

1. 定义链表类，把 `Node` 作为**静态嵌套类**。用一句话解释为什么用 `static` 而不是成员内部类。
2. 编写 `User.Builder`：链式设置 `name` / `age` / `email`，`build()` 时校验必填字段。
3. 给下列代码找一个能通过编译的最小修改：
   ```java
   public Runnable buildRunnable() {
       int x = 0;
       Runnable r = () -> System.out.println(x);
       x = 1;
       return r;
   }
   ```
4. 定义 `Numbered` 接口，含 `default int id()` 返回默认自增 id。写两个实现类，观察默认 id 的行为。
5. 写 `record Range(int lo, int hi)`，在紧凑构造器里校验 `lo <= hi`，并加 `contains(int)` 方法。
6. 用 `sealed interface Result<T>` + `record Ok<T>(T value)` + `record Err<T>(String msg)` 表示"成功 / 失败"，并写一个 `switch` 分派函数。
7. **拓展**：查阅 `HashMap.Node` 与 `HashMap.TreeNode` 的定义，说明它们为什么是静态嵌套类；再看 `HashMap.KeySet` 为什么是**非静态**成员内部类。

---

## 本日收束

### 承前启后

- **第 9 讲 数据结构**——上午我们把集合从"黑盒"变成"白盒"：你现在能画出 `HashMap` 的桶结构、能反手写出扰动函数、能理解为什么容量总是 2 的幂、能说清 `TreeMap` 红黑树的 5 条性质。**知其所以然**是从"会写 Java"到"读懂 JDK 源码"的分水岭。
- **第 10 讲 内部类 + 接口增强**——下午的内部类和接口增强则是**Java 语法的"设计工艺"层**：`static 嵌套类`、匿名内部类、Lambda 闭包捕获、`default` 方法、`record`、`sealed` 都是让代码"表达意图"的现代 Java 工具。

明天进入 **Day06 最后一天**：函数式编程 Lambda / Stream（第 11 讲）与 Optional / 日期 API（第 12 讲），今天的匿名内部类就会正式退场了。

### 6 天旅程中的定位

| Day | 主题 | 今日贡献 |
|---|---|---|
| 01 | 泛型 + 异常 | 类型系统 + 错误处理 |
| 02 | IO + 线程基础 | 数据 I/O + 并发起点 |
| 03 | 线程进阶 + 反射 | 并发编排 + 元数据识别 |
| 04 | 注解 + 集合精讲 | 框架抓手 + 集合工具箱 |
| **05** | **数据结构 + 内部类接口** | **原理 + 语法工艺：从"会用"到"会设计"** |
| 06 | Lambda/Stream + Optional/日期 | 声明式数据处理 |

### 作业

1. **必做**：第 9 讲、第 10 讲末尾练习各选做 3 道，重点是 `User.Builder` 链式构建 + `sealed interface Result<T>` 分派。
2. **拓展**：查阅 `HashMap.Node` / `HashMap.TreeNode` / `HashMap.KeySet` 的定义，说明为什么前两者是**静态**嵌套类而 `KeySet` 是**非静态**成员内部类。
3. **提交**：代码提交到 `ai-programming-advanced/day05/`。

---

[⬅️ Day04](day04.md) | [返回目录](../教材/目录.md) | [Day06 ➡️](day06.md)
