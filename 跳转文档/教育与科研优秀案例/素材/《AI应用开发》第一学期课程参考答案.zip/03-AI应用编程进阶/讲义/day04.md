# 《AI 应用编程进阶——Java 进阶》- 学生讲义（Day04：注解 + 集合精讲）

**总课时**：6 讲（其中 Day04 覆盖第 7 讲、第 8 讲，共 6 课时 × 45 分钟）
**适用对象**：已完成 Day03（线程进阶 + 反射）
**参考教材**：`02-AI应用编程进阶/教材/chapters/07.md`（第 7 章 注解）、`08.md`（第 8 章 集合精讲）

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 7 讲 | 注解 | 会用 JDK 内置注解与元注解；自定义注解 + 反射解析；能写出玩具版 `@Test` 运行器 |
| 第 8 讲 | 集合精讲 | 画出 Collection / Map 家谱；熟练用 `Arrays` / `Collections` 工具类；掌握 `LinkedList` 双端 API 与 `TreeSet` / `TreeMap` 排序机制 |

---

## 第 7 讲：注解

### 7.1 引入：昨天的 @Autowired 是怎么"被看见"的

Day03 结尾我们写了这段代码：

```java
class UserService {
    @Autowired
    UserRepository repo;
}
```

然后一个 `Container.wire(svc)` 就把 `repo` 塞进去了。**关键问题**：`@Autowired` 是什么？编译器为什么允许这么写？运行时容器又是怎么"看见"它的？

答案就是本讲的主题——**注解（Annotation）**。

**划重点**：反射 + 注解 = Java 元编程。反射负责"操作类"，注解负责"给类打标签"。两者合起来，才是 Spring / MyBatis / JUnit 的完整魔法。

#### 注解 vs 注释（不要混淆）

| 对比 | 注释（Comment） | 注解（Annotation） |
|---|---|---|
| 语法 | `//`、`/* */`、`/** */` | `@AnnotationName(...)` |
| 是否进入字节码 | 不进（`//` 完全丢失） | **通常进入字节码**（受 `@Retention` 控制） |
| 谁看得懂 | 只有人 | 编译器、框架、工具、人 |
| 是否影响程序 | 不影响 | 可能影响（框架据此变化行为） |

#### 注解处理的三种时机

```mermaid
flowchart LR
    A[SOURCE<br/>源码级] --> B[编译器读取<br/>如 @Override]
    C[CLASS<br/>字节码级] --> D[字节码工具读取<br/>如 Lombok]
    E[RUNTIME<br/>运行时] --> F[反射读取<br/>如 Spring/JUnit]
```

由 `@Retention` 决定注解保留到哪个阶段。**框架用的注解几乎清一色是 RUNTIME**。

#### 注解的本质

注解是一种**特殊的接口**，用 `@interface` 关键字定义。运行时你反射拿到的注解实例，本质是 JDK 帮你生成的动态代理对象——回顾昨天的动态代理，会不会觉得一切串起来了？

```java
public @interface Test { }

// 反编译近似：
public interface Test extends java.lang.annotation.Annotation { }
```

### 7.2 讲解：JDK 内置注解与元注解

#### 5 个常用内置注解

| 注解 | 作用 |
|---|---|
| `@Override` | 声明重写父类方法，编译期检查方法签名 |
| `@Deprecated` | 标注已过时；调用时编译器警告；可指定 `since` 和 `forRemoval` |
| `@SuppressWarnings("...")` | 抑制编译器警告，如 `"unchecked"`、`"rawtypes"` |
| `@SafeVarargs` | 声明泛型可变参数使用是安全的（回顾 Day01 泛型的 heap pollution） |
| `@FunctionalInterface` | 声明函数式接口（有且仅有一个抽象方法） |

```java
@Deprecated(since = "1.5", forRemoval = true)
public void oldMethod() { }

@SuppressWarnings({ "unchecked", "rawtypes" })
public void mix() {
    List list = new ArrayList();
    list.add("x");
}

@FunctionalInterface
public interface Converter<T, R> {
    R convert(T t);
    // R convert2(T t);   // ❌ 报错：不能有第二个抽象方法
    default void hello() { }   // ✅ 默认方法允许
}
```

**互动提问**：为什么 `@Override` 是 `SOURCE` 级？（答：它只帮编译器做签名校验，编译过了就没它事了，进字节码是浪费。）

#### 元注解（用来定义注解的注解）

写在自定义注解上，控制它的行为：

| 元注解 | 作用 |
|---|---|
| `@Target` | 允许出现在哪些位置（类、方法、字段…） |
| `@Retention` | 保留到哪个阶段（SOURCE / CLASS / RUNTIME） |
| `@Documented` | 是否生成到 Javadoc 中 |
| `@Inherited` | 子类是否**自动继承**父类上的这个注解（只对类注解生效） |
| `@Repeatable` | 允许注解在同一位置重复出现（Java 8+） |

`@Target` 常用值：

```java
ElementType.TYPE            // 类、接口、枚举、注解
ElementType.METHOD          // 方法
ElementType.FIELD           // 字段
ElementType.PARAMETER       // 参数
ElementType.CONSTRUCTOR     // 构造器
ElementType.LOCAL_VARIABLE  // 局部变量
ElementType.TYPE_PARAMETER  // 类型参数 (Java 8+)
ElementType.TYPE_USE        // 任意类型使用处 (Java 8+)
```

`@Retention` 值：

```java
RetentionPolicy.SOURCE      // 只在源码，编译后丢弃（如 @Override）
RetentionPolicy.CLASS       // 存在字节码但运行时反射看不到（默认值）
RetentionPolicy.RUNTIME     // 运行时可通过反射读取（框架最常用）
```

**划重点**：**框架用的注解必须 `RUNTIME`——`CLASS` 是反射拿不到的默认值，写自定义注解时经常忘记显式指定，导致框架"看不到"你的注解**，是新手第一大坑。

### 7.3 讲解：自定义注解

#### 语法

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface 注解名 {
    // 属性列表（本质是抽象方法）
    属性类型 属性名() default 默认值;
}
```

**属性支持的类型**（编译器强制）：

- 基本类型（int / long / double / boolean 等）
- `String`
- `Class` 或 `Class<?>`
- 枚举
- 注解
- 上述任意类型的**一维数组**

**其它类型（如 `List<String>`）不允许**——这是新手第二大坑。

#### 第一个自定义注解

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Log {
    String value() default "";           // 特殊名字：使用时可省略属性名
    Level level() default Level.INFO;
    String[] tags() default {};
}

// 使用
public class Demo {
    @Log("查询用户")
    public void findUser() { }

    @Log(value = "创建订单", level = Level.WARN, tags = {"order", "audit"})
    public void createOrder() { }
}
```

三条约定：
- 属性名叫 `value` 且只有它一个赋值时，可省略 `value =`
- 属性无默认值时**使用者必须显式赋值**
- 数组只有一个元素时可省大括号：`tags = "order"`

#### 用反射读取注解

```java
Method m = Demo.class.getMethod("createOrder");

if (m.isAnnotationPresent(Log.class)) {
    Log log = m.getAnnotation(Log.class);
    System.out.println(log.value());   // 创建订单
    System.out.println(log.level());   // WARN
    System.out.println(Arrays.toString(log.tags()));  // [order, audit]
}
```

**前提**：注解必须声明 `@Retention(RUNTIME)`，否则反射读不到。

### 7.4 完整案例：迷你 @Test 测试框架

需求：模仿 JUnit——自动发现类中带 `@Test` 的方法并逐一执行，输出耗时和结果。

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Test { }

public class MiniRunner {
    public static void run(Class<?> testClass) throws Exception {
        Object instance = testClass.getDeclaredConstructor().newInstance();
        int pass = 0, fail = 0;
        for (Method m : testClass.getDeclaredMethods()) {
            if (!m.isAnnotationPresent(Test.class)) continue;
            long start = System.currentTimeMillis();
            try {
                m.setAccessible(true);
                m.invoke(instance);
                System.out.printf("✅ %s (%d ms)%n", m.getName(),
                                  System.currentTimeMillis() - start);
                pass++;
            } catch (Exception e) {
                System.out.printf("❌ %s -> %s%n", m.getName(),
                                  e.getCause() != null ? e.getCause() : e);
                fail++;
            }
        }
        System.out.printf("总计 %d 通过 %d 失败%n", pass, fail);
    }
}

public class CalcTest {
    @Test public void plus()  { if (1 + 1 != 2) throw new AssertionError(); }
    @Test public void minus() { if (2 - 1 != 1) throw new AssertionError(); }
    @Test public void bug()   { throw new RuntimeException("故意失败"); }
    public void notTest()     { throw new RuntimeException("不会被跑"); }
}

public class Main {
    public static void main(String[] args) throws Exception {
        MiniRunner.run(CalcTest.class);
    }
}
```

输出：

```text
✅ plus (0 ms)
✅ minus (0 ms)
❌ bug -> java.lang.RuntimeException: 故意失败
总计 2 通过 1 失败
```

**划重点**：40 行代码，你就复刻了 JUnit 最核心的能力。真实 JUnit 加了 `@BeforeEach`/`@AfterEach`/断言库/并行执行等，但骨架就是这样。

### 7.5 讲解：重复注解（@Repeatable）

允许同一位置多次使用同一注解——常见于"多角色""多标签"场景。

```java
@Repeatable(Roles.class)                 // 指向容器注解
@Retention(RetentionPolicy.RUNTIME)
public @interface Role { String value(); }

@Retention(RetentionPolicy.RUNTIME)
public @interface Roles { Role[] value(); }   // 容器：数组类型的 value

@Role("admin")
@Role("editor")
public class UserService { }

// 读取
Role[] rs = UserService.class.getAnnotationsByType(Role.class);
for (Role r : rs) System.out.println(r.value());
// admin
// editor
```

**要点**：写 `@Repeatable` 必须同时定义一个"容器注解"，其 `value` 是原注解的数组。

### 7.6 讲解：注解 + 反射的经典套路

**这是 Java 元编程的核心公式**：

```mermaid
flowchart LR
    A[自定义注解<br/>贴在类/方法/字段上] --> B[反射扫描]
    B --> C[读到注解就做特殊处理]
    C --> D[无需修改被扫描类的代码<br/>就实现横切逻辑]
```

现实中：

- **Spring**：扫描 `@Component` 创建 Bean，扫描 `@Autowired` 注入依赖
- **MyBatis**：扫描 `@Select`、`@Insert` 生成 SQL 与执行逻辑
- **Spring MVC**：扫描 `@RequestMapping` 建立 URL → 方法映射
- **Bean Validation**：扫描 `@NotNull`、`@Size` 做字段验证
- **JUnit**：扫描 `@Test`、`@BeforeEach` 组织测试生命周期

### 7.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 自定义注解写好了，反射 `isAnnotationPresent` 一直 false | 忘写 `@Retention(RUNTIME)`；默认 `CLASS` 反射看不到 |
| 注解用错位置（贴在字段上但 target 是方法） | 忘写 `@Target` 或写错；显式指定并添加多个 `ElementType` |
| 属性用 `List<String>` 编译失败 | 属性类型受限；改用数组 `String[]` |
| `@Deprecated` 加了没警告 | 检查 IDE 警告设置；`forRemoval = true` 会更严格 |
| 想让子类继承父类注解但没生效 | 加 `@Inherited`；且**只对类注解**有效（方法/字段的注解不继承） |
| 重复注解报错 | 忘定义容器注解或容器 `value` 不是原注解数组 |
| 修改注解属性名后老代码运行崩 | 注解也是接口，属性等同于方法签名，改名等于**破坏兼容**；建议只新增 |
| `getAnnotation` 拿到 null | 目标上没这个注解，或 Retention 不对 |
| 忘记 `setAccessible(true)` 反射调 private 方法失败 | 昨天讲反射的重点，还是要记住 |
| 用 `@interface` 时忘了 `@`，写成 `interface` | 编译能过但完全变成普通接口，注解语义没了 |

### 7.8 练习/思考

1. 定义注解 `@BindURL("...")` 只能用于方法，携带一个字符串。写反射扫描器打印所有方法的 URL 与方法名。
2. 定义 `@Range(min=, max=)`，写一个 `Validator.validate(Object)`：反射读取每个 int 字段上的 `@Range`，如超范围则抛异常。
3. 分别写出 `@Retention(SOURCE)`、`@Retention(CLASS)`、`@Retention(RUNTIME)` 三种注解的用途场景各一个例子。
4. 写 `@Repeatable` 注解 `@Author("...")`，允许一个类被多个作者标注，反射读出全部作者名。
5. 说明为什么下面代码会编译错误：
   ```java
   @Target(ElementType.METHOD)
   @Retention(RetentionPolicy.RUNTIME)
   public @interface Config { List<String> tags(); }
   ```
6. **拓展**：仿造 Spring 实现玩具版 `@Component + @Autowired`——手动传入类列表，为其中带 `@Component` 的类创建实例，为带 `@Autowired` 的字段注入其它 Bean。

---

## 第 8 讲：集合精讲

### 8.1 引入：一张家谱先立起来

零散地记 `ArrayList`、`HashMap`、`TreeSet` 是最低效的学法。先把家谱画出来，之后每个类落在哪个位置，特点就自然对上了。

```mermaid
classDiagram
    class Iterable
    class Collection
    class List
    class Set
    class Queue
    class Deque

    class ArrayList
    class LinkedList
    class Vector

    class HashSet
    class LinkedHashSet
    class TreeSet

    class ArrayDeque
    class PriorityQueue

    Iterable <|-- Collection
    Collection <|-- List
    Collection <|-- Set
    Collection <|-- Queue
    Queue <|-- Deque

    List <|.. ArrayList
    List <|.. LinkedList
    List <|.. Vector

    Set <|.. HashSet
    HashSet <|-- LinkedHashSet
    Set <|.. TreeSet

    Deque <|.. ArrayDeque
    Deque <|.. LinkedList
    Queue <|.. PriorityQueue
```

`Map` 独立于 `Collection`，自成一系：

```mermaid
classDiagram
    class Map
    class HashMap
    class LinkedHashMap
    class TreeMap
    class Hashtable
    class ConcurrentHashMap

    Map <|.. HashMap
    HashMap <|-- LinkedHashMap
    Map <|.. TreeMap
    Map <|.. Hashtable
    Map <|.. ConcurrentHashMap
```

**选型速查（背下来）**：

- 顺序访问 + 下标随机访问多 → `ArrayList`
- 频繁头尾插入 / 当作队列/栈 → `ArrayDeque`（**性能优于 LinkedList**）
- 需要唯一 & 无序 → `HashSet`
- 需要唯一 & 有序遍历 → `TreeSet`（自然序） / `LinkedHashSet`（插入序）
- K → V 快速查 → `HashMap`
- 按 key 排序 → `TreeMap`
- 高并发 → `ConcurrentHashMap` / `CopyOnWriteArrayList`

### 8.2 讲解：Arrays 工具类

`java.util.Arrays` 是操作**数组**的静态工具集合。

#### 打印数组

```java
int[] a = {3, 1, 4, 1, 5};
System.out.println(a);                   // [I@1540e19d ← 别用，是内存地址
System.out.println(Arrays.toString(a));  // [3, 1, 4, 1, 5]

int[][] m = {{1, 2}, {3, 4}};
System.out.println(Arrays.deepToString(m));  // [[1, 2], [3, 4]]
```

**划重点**：`System.out.println(数组)` 不会像 `List` 那样打印元素，一定要 `Arrays.toString(...)`。这是初学者的经典盲点。

#### 排序

```java
int[] a = {3, 1, 4, 1, 5};
Arrays.sort(a);                          // 升序，双轴快排 / TimSort
System.out.println(Arrays.toString(a));  // [1, 1, 3, 4, 5]

Integer[] b = {3, 1, 4, 1, 5};
Arrays.sort(b, Comparator.reverseOrder()); // 逆序（基本类型不能传 Comparator）

int[] c = {5, 4, 3, 2, 1};
Arrays.sort(c, 1, 4);                    // 只排 [1, 4)：{5, 2, 3, 4, 1}
```

**互动提问**：为什么 `int[]` 不能传 `Comparator`？（答：`Comparator` 泛型只支持引用类型；`int[]` 是基本类型数组，只能升序。要逆序请用 `Integer[]` 或排完 reverse。）

#### 二分查找

```java
int[] a = {1, 1, 3, 4, 5};               // ⚠️ 必须先排序
int i = Arrays.binarySearch(a, 3);       // 找到 → 返回索引
int j = Arrays.binarySearch(a, 2);       // 找不到 → **负的插入点 - 1**
```

#### 复制

```java
int[] a = {1, 2, 3, 4, 5};
int[] b = Arrays.copyOf(a, 3);           // 前 3 个：[1, 2, 3]
int[] c = Arrays.copyOf(a, 7);           // 长于原数组：[1,2,3,4,5,0,0]
int[] d = Arrays.copyOfRange(a, 1, 4);   // [1, 4)：[2, 3, 4]
```

#### 填充与比较

```java
int[] a = new int[5];
Arrays.fill(a, 7);                       // [7, 7, 7, 7, 7]
Arrays.fill(a, 1, 3, 0);                 // 部分填充：[7, 0, 0, 7, 7]

int[] x = {1, 2, 3};
int[] y = {1, 2, 3};
System.out.println(x == y);              // false（引用）
System.out.println(Arrays.equals(x, y)); // true（元素相等）
```

#### 数组转 List（超高频坑）

```java
List<String> list = Arrays.asList("a", "b", "c");
// ⚠️ 得到的是**固定长度视图**：list.add() / list.remove() 抛 UnsupportedOperationException
```

若要可变：

```java
List<String> list = new ArrayList<>(Arrays.asList("a", "b", "c"));
```

Java 9+ 更简洁（**完全不可变**）：

```java
List<String> list = List.of("a", "b", "c");
```

#### Stream 化

```java
int sum = Arrays.stream(new int[]{1, 2, 3, 4}).sum();          // 10
double avg = Arrays.stream(new int[]{1, 2, 3, 4}).average().orElse(0);
```

（Stream 完整用法在 Day06 讲。）

### 8.3 讲解：Collections 工具类

`java.util.Collections` 是操作**集合**的静态工具集合（注意区分于 `Collection` 接口——多一个 s）。

#### 排序与查找

```java
List<Integer> list = new ArrayList<>(List.of(3, 1, 4, 1, 5));

Collections.sort(list);                          // 自然序
Collections.sort(list, Comparator.reverseOrder());  // 逆序
Collections.reverse(list);                       // 就地反转
Collections.shuffle(list);                       // 随机打乱

int i = Collections.binarySearch(list, 3);       // 需先升序排好

Integer max = Collections.max(list);
Integer min = Collections.min(list);
```

#### 统计与替换

```java
int f = Collections.frequency(list, 1);          // 元素 1 出现次数
Collections.replaceAll(list, 1, 99);             // 全部 1 → 99
Collections.fill(list, 0);                       // 全部替换成 0
```

#### 不可变视图与空集合

```java
List<String> ro   = Collections.unmodifiableList(list);
Map<String, Integer> empty = Collections.emptyMap();
List<String> single = Collections.singletonList("only");
```

Java 9+ 更推荐：`List.of / Set.of / Map.of`（本身不可变，字面量友好）。

#### 线程安全包装（回顾 Day02）

```java
List<String>   sync = Collections.synchronizedList(new ArrayList<>());
Map<String,Integer> sm = Collections.synchronizedMap(new HashMap<>());
```

**局限**：只是每方法加锁，**遍历时仍需外部同步**：

```java
synchronized (sync) {
    for (String s : sync) { ... }        // 遍历必须包在同一个锁里
}
```

高并发首选 `ConcurrentHashMap` / `CopyOnWriteArrayList`。

### 8.4 讲解：LinkedList 精讲

`LinkedList` 是**双向链表**，同时实现了 `List` 和 `Deque` 两个接口。

```mermaid
flowchart LR
    H[head] <--> A[node A] <--> B[node B] <--> C[node C] <--> T[tail]
```

#### 与 ArrayList 对比

| 特性 | `ArrayList` | `LinkedList` |
|---|---|---|
| 底层 | 动态数组 | 双向链表 |
| 随机访问 `get(i)` | O(1) | O(n) |
| 尾部添加 | 平均 O(1)（含扩容） | O(1) |
| 头部添加 | O(n)（要搬迁） | O(1) |
| 中间插入 | O(n) | 定位到位置也 O(n)，插入本身 O(1) |
| 内存占用 | 紧凑 | 每节点额外两个引用 |

**结论**：现代 Java 里 `LinkedList` **几乎已被冷落**——即使是队列 / 栈用途，`ArrayDeque` 也更快。仍讲它是为了理解链表结构和 Deque 语义。

#### Deque 双端 API

| 方法 | 作用 |
|---|---|
| `addFirst(e)` / `addLast(e)` | 头/尾添加 |
| `getFirst()` / `getLast()` | 头/尾查看 |
| `removeFirst()` / `removeLast()` | 头/尾移除 |
| `peekFirst()` / `peekLast()` | 头/尾查看（空返回 null） |
| `pollFirst()` / `pollLast()` | 头/尾移除（空返回 null） |
| `push(e)` / `pop()` | 头部 push/pop（**栈语义**） |
| `offer(e)` / `poll()` | 尾部 offer / 头部 poll（**队列语义**） |

**互动提问**：`peek` 和 `get` 有什么不同？（答：`get`/`removeFirst` 空集合抛异常；`peek`/`poll` 空集合返回 null。写队列尽量用后者，代码不用 try/catch。）

#### 当队列（FIFO）用

```java
Deque<String> queue = new LinkedList<>();
queue.offer("a");
queue.offer("b");
queue.offer("c");
while (!queue.isEmpty()) {
    System.out.println(queue.poll());   // a, b, c
}
```

#### 当栈（LIFO）用

```java
Deque<String> stack = new LinkedList<>();
stack.push("a");
stack.push("b");
stack.push("c");
while (!stack.isEmpty()) {
    System.out.println(stack.pop());    // c, b, a
}
```

Java 官方推荐用 `Deque` 替代老的 `Stack` 类（后者继承 `Vector`，性能差）。

#### 遍历时安全删除

```java
Iterator<Integer> it = list.iterator();
while (it.hasNext()) {
    int v = it.next();
    if (v < 0) it.remove();     // 用 Iterator.remove()
}
```

**划重点**：直接 `for-each` 中调 `list.remove(x)` 会抛 `ConcurrentModificationException`，务必用 `Iterator.remove()`。

### 8.5 讲解：TreeSet 与 TreeMap

它们的核心：**自动排序**，底层用**红黑树**（平衡二叉搜索树），增删查都是 O(log n)。

#### TreeSet 基础

```java
TreeSet<Integer> set = new TreeSet<>();
set.add(3); set.add(1); set.add(4); set.add(1); set.add(5);
System.out.println(set);       // [1, 3, 4, 5]（元素唯一 + 升序）
```

**自然序**要求元素实现 `Comparable`（否则运行时抛 `ClassCastException`）。

#### 使用 Comparator

```java
TreeSet<Integer> desc = new TreeSet<>(Comparator.reverseOrder());
desc.add(3); desc.add(1); desc.add(5);
System.out.println(desc);      // [5, 3, 1]

TreeSet<String> byLen = new TreeSet<>(
    Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder())
);
byLen.add("bb"); byLen.add("a"); byLen.add("ccc"); byLen.add("dd");
System.out.println(byLen);     // [a, bb, dd, ccc]
```

#### 导航方法（NavigableSet）

```java
NavigableSet<Integer> s = new TreeSet<>(List.of(1, 3, 5, 7, 9));

s.first();          // 1
s.last();           // 9
s.floor(4);         // 3（≤ 4 的最大）
s.ceiling(4);       // 5（≥ 4 的最小）
s.lower(3);         // 1（< 3 的最大）
s.higher(3);        // 5（> 3 的最小）
s.headSet(5);       // [1, 3]（< 5）
s.tailSet(5);       // [5, 7, 9]（≥ 5）
s.subSet(3, 7);     // [3, 5]
s.descendingSet();  // [9, 7, 5, 3, 1]
```

面试常考"给一个数，找有序集合里最接近它的元素"——就是 `floor` / `ceiling`。

#### TreeMap 基础

```java
TreeMap<String, Integer> map = new TreeMap<>();
map.put("banana", 2);
map.put("apple",  1);
map.put("cherry", 3);
System.out.println(map);       // {apple=1, banana=2, cherry=3}（按 Key 升序）
```

TreeMap 同样有导航方法：`firstKey / lastKey / floorEntry / ceilingEntry / subMap / descendingKeySet`。

#### 使用要点与坑

- **排序规则要与 equals 一致**：`compareTo == 0` 会被视为"相同"而拒绝插入
  ```java
  // 只按长度比较 → 长度相同的会互相覆盖！
  TreeSet<String> t = new TreeSet<>(Comparator.comparingInt(String::length));
  t.add("aa"); t.add("bb");        // t 里只剩 1 个元素
  ```
- **null 元素**：`TreeSet` / `TreeMap` **不允许** null key（自然序会 NPE，Comparator 需自行处理）
- **性能**：所有操作 O(log n)，比 HashSet / HashMap 慢一个 log；用 TreeSet / TreeMap 是为**有序访问**付这个成本
- **并发**：非线程安全，多线程场景需 `Collections.synchronizedSortedMap` 或 `ConcurrentSkipListMap`

#### 完整案例：字符串按长度、字母序排序去重

```java
public class SortDemo {
    public static void main(String[] args) {
        TreeSet<String> ts = new TreeSet<>(
            Comparator.comparingInt(String::length)
                      .thenComparing(Comparator.naturalOrder())
        );
        ts.addAll(List.of("banana", "apple", "cherry", "kiwi", "pear", "fig"));
        for (String s : ts) System.out.println(s);
    }
}
// fig
// kiwi
// pear
// apple
// banana
// cherry
```

### 8.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `System.out.println(数组)` 打印 `[I@xxxxxx` | 用 `Arrays.toString` / `Arrays.deepToString` |
| `Arrays.asList().add(...)` 抛 UnsupportedOperationException | 是固定长度视图；套 `new ArrayList<>(...)` 或 Java 9+ 用 `List.of` |
| `binarySearch` 数据没排序 | 结果未定义；必须先 `sort` |
| `Comparator` 只比长度导致 TreeSet 去重错误 | 必须与 equals 一致；用 `thenComparing` 补充 |
| `TreeMap.put(null, ...)` 抛 NPE | TreeMap 不允许 null key |
| for-each 中 `list.remove(x)` 抛 CME | 用 `Iterator.remove()` 或 `removeIf` |
| `Collections.synchronizedList` 遍历还是崩 | 遍历需 `synchronized(list)` 外部同步 |
| `LinkedList.get(n)` 慢 | 链表 O(n)；随机访问用 ArrayList |
| 队列 / 栈选 `LinkedList` | 现代推荐 `ArrayDeque`，性能更好 |
| `HashMap` 无序还想遍历稳定 | 用 `LinkedHashMap`（插入序）或 `TreeMap`（Key 排序） |

### 8.7 练习/思考

1. 用 `Arrays.sort` + 自定义 `Comparator` 对字符串数组按长度升序、长度相同按字典序排序。
2. 写 `List<Integer> topK(int[] arr, int k)`：返回数组中最大的 k 个数（用 `Collections.sort` 或优先队列均可）。
3. 用 `LinkedList` 实现"浏览器前进后退"功能：`visit(url)` / `back()` / `forward()`。
4. 输入若干英文单词，用 `TreeSet` 输出去重后按字典序排列的结果。
5. 用 `TreeMap` 实现英文字母频率统计，并按字母序打印。
6. **拓展**：给出以下代码的输出，并说明原因：
   ```java
   TreeSet<Point> set = new TreeSet<>(Comparator.comparingInt(p -> p.x));
   set.add(new Point(1, 5));
   set.add(new Point(1, 9));
   System.out.println(set.size());
   ```
   （提示：只按 x 比较，两个 x=1 被判"相同"。）

---

## 本日收束

### 承前启后

- **第 7 讲 注解**——上午和昨天的反射合二为一，你现在能理解 Spring / MyBatis / JUnit 的"扫描—识别—处理"魔法：注解是**贴在代码上的元数据标签**，反射负责在运行时读它们。
- **第 8 讲 集合精讲**——下午把 `Arrays` / `Collections` 两组工具类、`LinkedList` 双端 API、`TreeSet` / `TreeMap` 排序机制补齐——这三块是数据结构与算法题的高频武器。

明天进入更底层的**数据结构原理**（第 9 讲），你会知道 `HashMap` 到底怎么"哈希"、`TreeMap` 的红黑树怎么"红黑"。

### 6 天旅程中的定位

| Day | 主题 | 今日贡献 |
|---|---|---|
| 01 | 泛型 + 异常 | 类型系统 + 错误处理 |
| 02 | IO + 线程基础 | 数据 I/O + 并发起点 |
| 03 | 线程进阶 + 反射 | 并发编排 + 元数据识别 |
| **04** | **注解 + 集合精讲** | **框架抓手：注解 + 排序 / 双端队列** |
| 05 | 数据结构 + 内部类接口 | 集合的底层原理 |
| 06 | Lambda/Stream + Optional/日期 | 声明式数据处理 |

### 作业

1. **必做**：第 7 讲、第 8 讲末尾练习各选做 3 道。
2. **拓展**：`TreeSet<Point>` 排序陷阱题——理解为什么 `Comparator.comparingInt(p -> p.x)` 会把不同的 Point 判成"相同"。
3. **提交**：代码提交到 `ai-programming-advanced/day04/`。

---

[⬅️ Day03](day03.md) | [返回目录](../教材/目录.md) | [Day05 ➡️](day05.md)
