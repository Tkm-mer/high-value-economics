# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day03（第 13-18 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Day02（IO 流、线程基础）的大学一年级学生
**知识点覆盖**：线程池深潜 + 线程状态 + wait/notify + join/yield（3 课时） + 反射（3 课时）
**参考教材**：`../教材/chapters/05.md`、`06.md`

---

## 本日知识地图

```mermaid
flowchart LR
    subgraph G1["上午 · 并发进阶"]
        direction LR
    L13["第 13 课时<br/>ThreadPoolExecutor & 线程状态"]
    L14["第 14 课时<br/>wait/notify 生产消费"]
    L15["第 15 课时<br/>join/yield/中断"]
    end
    subgraph G2["下午 · 反射"]
        direction LR
    L16["第 16 课时<br/>反射与 Class 对象"]
    L17["第 17 课时<br/>反射三大操作"]
    L18["第 18 课时<br/>迷你 IoC + 动态代理"]
    end
    L13 --> L14 --> L15
    L16 --> L17 --> L18
    L15 -.承接.-> L16
```

> 6 个课时按「并发进阶 → 反射」两大板块递进；上午打基础，下午做延伸，最后一课时做本日综合练习。

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：沿用；本讲要用 `ThreadPoolExecutor`、`Thread.getState()`、`Class.forName`、`MethodHandle` 等 API，全部在 JDK 25 verify 通过。
2. **IntelliJ IDEA（下简称 IDEA） 工程**：`day03-threadpool-reflection/`，含 `poolparam`（七参数演示）、`state`（线程状态观测）、`waitnotify`（生产者消费者）、`reflect`（反射四步）四个包。
3. **示例类文件**：`Person.class` 编译产物提前放到 `resources/` 目录，反射演示需从磁盘加载而非源码依赖。
4. **观测辅助**：VisualVM 或 JConsole 提前打开一次教师机进程（先跑一次 demo），确认线程视图能显示 pool 中的 worker。
5. **黑板/白板**：擦净，中央预划「BlockingQueue + Worker 池」示意图轮廓（不填内容，讲授时逐步补齐）。

### 学情预设
- 前置：Day02 已讲 `Thread` 与 `Runnable` 基础用法、`synchronized` 用过一次；线程池只见过 `Executors.newFixedThreadPool`。
- 预计易混：核心线程 vs 最大线程、`SynchronousQueue` vs `LinkedBlockingQueue`、`wait/notify` vs `sleep`、Class 对象 vs 实例对象。
- 预计基础差距：约 25% 学生对「阻塞队列」概念未建立，需用「食堂排队 + 窗口数」类比。反射对零基础学生偏抽象，本讲配套代码需一步一 println 打印中间结果。

### 教具与板书素材
- 打印 A4：「ThreadPoolExecutor 七参数速查表」+「Thread.State 6 大状态迁移图」+「反射四步骤（getClass→getConstructor→newInstance→invoke）」，一人一份。
- 板书右侧留出「拒绝策略 4 兄弟」区域（AbortPolicy / CallerRunsPolicy / DiscardPolicy / DiscardOldestPolicy）。

### 前置检查（上课前 5 分钟完成）
- 全班 `Runtime.getRuntime().availableProcessors()` 打印一遍，记住数字；后续线程池演示要与此值比对。
- IDEA 中演示 `Ctrl+Shift+F10` 快捷键跑一次 `poolparam.Demo01`，确认输出无异常；若 UTF-8 中文乱码，先修编码再上课。
- 教师机预先编译好 `Person.class` 并复制到工程 `resources/`，避免课堂现编译浪费时间。

---

## 第 13 课时：ThreadPoolExecutor 七大参数与线程状态

### 13.1 教学目标
#### 13.1.1 知识与技能目标
1. 能背出 `ThreadPoolExecutor` 的七大参数并说明各自作用
2. 能画出任务提交后「核心线程 → 队列 → 非核心线程 → 拒绝」的工作流程图
3. 认识 4 大 BlockingQueue 与 4 大拒绝策略
4. 能说清 Java 线程 6 种状态的转换关系
5. 能说出 `sleep` 与 `wait` 的至少 3 处差异

#### 13.1.2 过程与方法目标
1. 通过「用 `ArrayBlockingQueue(2) + corePool=2 + max=4`」故意触发拒绝，让学生亲眼看到 `RejectedExecutionException`
2. 通过 `t.getState()` 打印线程状态，把抽象的状态图落到代码上

### 13.2 教学重难点
- **重点**：七大参数各自含义 / 工作流程 4 步 / 6 种状态
- **难点**：**队列先满还是线程先扩？** —— 是「核心线程满 → 队列满 → 才扩线程」，而不是直觉的「先扩满线程再入队」

### 13.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「昨天说过 `Executors` 生产禁用，因为内部无界。要生产用就得自己搭。今天先揭开 `ThreadPoolExecutor` 的**七大参数**——面试常考、生产必会。」

#### 新知讲授（20 分钟）
**1. 七大参数**（板书）

| 参数 | 含义 |
|------|------|
| `corePoolSize` | 核心线程数：常驻，不因空闲回收 |
| `maximumPoolSize` | 最大线程数：队列满且核心忙时最多能扩到几个 |
| `keepAliveTime + unit` | 超出核心的线程空闲多久回收 |
| `workQueue` | 任务队列 |
| `threadFactory` | 线程创建工厂（**必须自定义线程名**） |
| `handler` | 拒绝策略 |

**2. 工作流程**（板书 Mermaid，反复讲！）

```text
submit
   │
   ▼
核心线程满? ── 否 → 创建核心线程执行
   │是
   ▼
队列满? ── 否 → 放入队列等待
   │是
   ▼
线程 < max? ── 是 → 创建非核心线程执行
   │否
   ▼
触发拒绝策略
```

**核心线程 → 队列 → 非核心线程 → 拒绝**——4 步顺序死记！

**反直觉点**：不是「线程都开满再入队」，而是「队列填满才继续开线程」。这个顺序是 Java 定的（`execute` 源码里就是这样写的）。

**3. 四种 BlockingQueue**

| 队列 | 特点 |
|------|------|
| `LinkedBlockingQueue` | 链表，默认无界（陷阱！） |
| `ArrayBlockingQueue` | 数组，必须指定容量 —— 生产首选 |
| `SynchronousQueue` | 不存元素，一对一直接交接 |
| `PriorityBlockingQueue` | 有优先级 |

**4. 四大拒绝策略**

| 策略 | 行为 |
|------|------|
| `AbortPolicy`（默认） | 抛 `RejectedExecutionException` |
| `CallerRunsPolicy` | 调用者线程自己跑（自然限流） |
| `DiscardPolicy` | 静默丢弃 |
| `DiscardOldestPolicy` | 丢最老任务再尝试提交 |

**5. 生产推荐模板**（板书）
```java
new ThreadPoolExecutor(
    4, 16,
    60L, TimeUnit.SECONDS,
    new ArrayBlockingQueue<>(1000),
    r -> new Thread(r, "biz-" + id.incrementAndGet()),
    new ThreadPoolExecutor.CallerRunsPolicy()
);
```

**6. 参数经验公式**
- CPU 密集：`core ≈ CPU核心数 + 1`
- IO 密集：`core ≈ CPU核心数 × 2`
- `max ≤ CPU核心数 × 4~5`

**7. 线程 6 种状态**（板书 stateDiagram）

| 状态 | 含义 |
|------|------|
| NEW | 已 new，未 start |
| RUNNABLE | 可运行 / 正在运行 |
| BLOCKED | 等 synchronized 锁 |
| WAITING | 无限期等待（wait/join/park） |
| TIMED_WAITING | 有超时等待（sleep(ms)/wait(ms)/join(ms)） |
| TERMINATED | run() 已返回 |

**8. sleep vs wait**（板书对比表）

| 项 | sleep | wait |
|----|-------|------|
| 归属 | `Thread` 静态 | `Object` 实例 |
| 同步块 | 不要求 | **必须** synchronized 内 |
| 是否释放锁 | 否 | **是** |
| 唤醒 | 时间到 / interrupt | notify/notifyAll / 超时 / interrupt |

#### 示例演示（14 分钟）
现场自建线程池，故意触发拒绝：
```java
ThreadPoolExecutor pool = new ThreadPoolExecutor(
    2, 4, 10, TimeUnit.SECONDS,
    new ArrayBlockingQueue<>(2),
    Executors.defaultThreadFactory(),
    new ThreadPoolExecutor.AbortPolicy());

for (int i = 0; i < 10; i++) {
    final int taskId = i;
    try {
        pool.submit(() -> {
            System.out.println("task " + taskId + " on " + Thread.currentThread().getName());
            try { Thread.sleep(2000); } catch (InterruptedException e) {}
        });
    } catch (RejectedExecutionException e) {
        System.out.println("task " + taskId + " 被拒绝！");
    }
}
```
学生能看到：前 2 个立即执行 → 队列存 2 个 → 又开 2 个非核心 → 第 7 个开始被拒绝。**流程 4 步一目了然**。

再演示 `t.getState()`：
```java
Thread t = new Thread(() -> {
    try { Thread.sleep(1000); } catch (InterruptedException e) {}
});
System.out.println(t.getState());  // NEW
t.start();
Thread.sleep(100);
System.out.println(t.getState());  // TIMED_WAITING
t.join();
System.out.println(t.getState());  // TERMINATED
```

#### 课堂练习（4 分钟）
1. 说出七大参数（挨个点名让学生说一个）
2. `newFixedThreadPool(5)` 内部等价于哪些参数？（队列是无界 LinkedBlockingQueue）
3. 判断题：`sleep(1000)` 期间线程处于什么状态？（TIMED_WAITING）

#### 小结（3 分钟）
- 七大参数：`core / max / keepAlive / queue / factory / handler`
- 工作流程 4 步：**核心 → 队列 → 非核心 → 拒绝**
- 6 状态：NEW / RUNNABLE / BLOCKED / WAITING / TIMED_WAITING / TERMINATED

### 13.4 板书设计
```text
┌────────────────────────────────────────────┐
│  ThreadPoolExecutor 七大参数               │
│  core / max / keepAlive+unit / queue       │
│  threadFactory / handler                   │
│                                            │
│  提交流程 4 步：                           │
│  核心线程 → 队列 → 非核心 → 拒绝           │
│                                            │
│  6 状态：                                  │
│  NEW → RUNNABLE ⇄ BLOCKED                  │
│           ⇄ WAITING / TIMED_WAITING        │
│           → TERMINATED                     │
└────────────────────────────────────────────┘
```

### 13.5 课后作业
1. 抄写运行教材 §5.1 + §5.2 全部示例
2. 用自建 `ThreadPoolExecutor(core=2, max=4, queue=2)` 提交 10 个 sleep 1 秒任务，观察每个任务的执行者与被拒绝情况
3. 写一段代码依次让线程进入 NEW → RUNNABLE → TIMED_WAITING → TERMINATED，用 `getState()` 打印

### 13.6 教学反思提示
- 「先满队列再扩线程」违背直觉，务必用演示代码把这个顺序钉死
- 学生常把 BLOCKED 和 WAITING 混淆——强调「BLOCKED = 抢 synchronized」而 WAITING 是主动 wait/join

---

## 第 14 课时：wait/notify 与生产者消费者

### 14.1 教学目标
#### 14.1.1 知识与技能目标
1. 掌握 `wait / notify / notifyAll` 三点约束：同步块内 / 同一对象 / while 检查
2. 能写出生产者—消费者的完整例子
3. 理解虚假唤醒，能说清为什么用 `while` 而不是 `if`
4. 了解 `ReentrantLock + Condition` 相对 `synchronized + notifyAll` 的优势

#### 14.1.2 过程与方法目标
1. 通过一段「用 if 代替 while → 数组越界」的翻车实验，把「虚假唤醒」讲活
2. 通过双 `Condition` 的重构，让学生看到「精确唤醒」的思路

### 14.2 教学重难点
- **重点**：wait/notify 三点约束 / 生产者—消费者模板
- **难点**：为什么 wait 必须在 synchronized 内 / 虚假唤醒

### 14.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「线程池学完了并发的『分工』，还差『协作』。生产者—消费者是最经典的协作模式——今天用最原始的 `wait/notify` 实现一次。」

#### 新知讲授（18 分钟）
**1. wait / notify / notifyAll 三点约束**（板书圈红）
- 必须在 `synchronized(锁对象)` 内调用
- 调用哪个对象的 wait，就用**哪个对象**的 notify
- `wait()` **释放锁**并挂起；被唤醒后**重新竞争锁**才继续

**为什么必须在同步块内？**——wait 的语义就是「先释放锁挂起 → 被唤醒后重新拿锁」，脱离同步块就无锁可释。若忘写 synchronized 会抛 `IllegalMonitorStateException`。

**2. 生产者—消费者模板**（板书完整代码）
```java
public class Storage {
    private final Queue<Integer> queue = new LinkedList<>();
    private final int capacity = 5;

    public synchronized void put(int v) throws InterruptedException {
        while (queue.size() == capacity) wait();
        queue.offer(v);
        notifyAll();
    }

    public synchronized int take() throws InterruptedException {
        while (queue.isEmpty()) wait();
        int v = queue.poll();
        notifyAll();
        return v;
    }
}
```
**背下三处关键**：
- 判断用 `while`，不是 `if`
- 操作完 `notifyAll` 通知另一方
- 整个方法 `synchronized`

**3. 为什么 while 不用 if**（板书场景）

虚假唤醒 / 竞态：
- notifyAll 会**唤醒所有** wait 的线程
- 线程 A 被唤醒后**重新竞争锁**，此时条件可能被别人破坏（例如另一个消费者抢先消费）
- 用 `while` 保证「醒来再检查」

如果错用 `if`：队列空时被唤醒，另一个消费者抢先 poll → `queue.poll()` 返回 null → 后续 NullPointerException。

**4. notify vs notifyAll**
- `notify()` 只唤醒**一个**（可能唤醒错人：生产者唤醒了另一个生产者）
- `notifyAll()` 唤醒全部（安全但开销大）
- 多角色共用一把锁时**用 notifyAll**

**5. Condition：更精细的 wait/notify**

`synchronized + wait/notify` 只有**一个等待队列**，唤醒时无法区分角色。`ReentrantLock + Condition` 支持多个等待队列：

```java
Lock lock = new ReentrantLock();
Condition notFull  = lock.newCondition();
Condition notEmpty = lock.newCondition();

// 生产
lock.lock();
try {
    while (isFull()) notFull.await();
    add(v);
    notEmpty.signalAll();       // 只唤醒消费者
} finally { lock.unlock(); }
```
**只唤醒真正等待的角色**，比 notifyAll 精细。

#### 示例演示（16 分钟）
现场敲教材 §5.3.2 完整例子，跑起来看输出（P 快 C 慢，队列会满；反之会空）。

翻车演示：把 `while` 改成 `if`，再让 2 个消费者线程同时启动，触发虚假唤醒 → `poll()` 返回 null → NPE。学生印象极深。

再用 Condition 重构一次：
```java
public class Storage2 {
    private final Queue<Integer> q = new LinkedList<>();
    private final int cap = 5;
    private final Lock lock = new ReentrantLock();
    private final Condition notFull = lock.newCondition();
    private final Condition notEmpty = lock.newCondition();

    public void put(int v) throws InterruptedException {
        lock.lock();
        try {
            while (q.size() == cap) notFull.await();
            q.offer(v);
            notEmpty.signalAll();
        } finally { lock.unlock(); }
    }
    public int take() throws InterruptedException {
        lock.lock();
        try {
            while (q.isEmpty()) notEmpty.await();
            int v = q.poll();
            notFull.signalAll();
            return v;
        } finally { lock.unlock(); }
    }
}
```

#### 课堂练习（5 分钟）
1. 判断：`wait()` 是否释放锁？`sleep()` 呢？（是；否）
2. 忘写 synchronized 直接调 `obj.wait()` 会发生什么？（抛 `IllegalMonitorStateException`）
3. 写一段最小代码演示：一个生产者线程 put 3 次、一个消费者线程 take 3 次

#### 小结（3 分钟）
- wait/notify 三约束：**同步块内 / 同一对象 / while 检查**
- 虚假唤醒用 `while` 防
- 多角色场景 `notifyAll`；精细唤醒改用 `ReentrantLock + Condition`

### 14.4 板书设计
```text
┌────────────────────────────────────────────┐
│  wait/notify 三约束：                      │
│  1.必须 synchronized(obj) 内               │
│  2.同一 obj                                │
│  3.判断用 while 不是 if（防虚假唤醒）      │
│                                            │
│  生产者—消费者：                           │
│    put:  while(满) wait; add; notifyAll;   │
│    take: while(空) wait; poll; notifyAll;  │
│                                            │
│  升级：ReentrantLock + 两个 Condition      │
│    notFull.await / notEmpty.signal         │
└────────────────────────────────────────────┘
```

### 14.5 课后作业
1. 抄写运行教材 §5.3 全部示例
2. 独立完成教材 §5 练习题 2：用 `ReentrantLock + 两个 Condition` 重构生产者—消费者
3. 挑战：线程 A 打印偶数、线程 B 打印奇数，交替输出 1—10

### 14.6 教学反思提示
- 「wait 必须在同步块内」学生常问「为什么」，用锁的语义（释放/重取）解释
- 双 Condition 例子让学生理解「精确唤醒」的价值，不要一上来就写 `notifyAll`

---

## 第 15 课时：join、yield 与中断

### 15.1 教学目标
#### 15.1.1 知识与技能目标
1. 会用 `join()` 让主线程等子线程结束
2. 认识 `yield()` 是提示而非强制
3. 能对比 sleep / wait / join / yield 四兄弟
4. 掌握 Java 协作式中断的正确姿势

#### 15.1.2 过程与方法目标
1. 通过「多个爬取任务并行 + join 汇总」体验 join 的实际用途
2. 通过 `sleep 抛 InterruptedException 后中断标记被清除` 的坑点，理解中断的协作本质

### 15.2 教学重难点
- **重点**：join 用法 / sleep-wait-join-yield 对比表 / 协作式中断模板
- **难点**：`sleep` 后中断标记被清除，需要重新 `interrupt()`

### 15.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「学过 wait/notify 的『协作』，还差一种最简单的等待——**等某个线程结束**。这就是 `join`。」

#### 新知讲授（18 分钟）
**1. join：等一个线程结束**
```java
Thread worker = new Thread(...);
worker.start();
worker.join();      // 主线程阻塞直到 worker 结束
```

带超时：`worker.join(1000)` —— 最多等 1 秒。

**典型用法**：多任务并行 + 主线程汇总
```java
List<Thread> ts = new ArrayList<>();
for (...) {
    Thread t = new Thread(...);
    t.start();
    ts.add(t);
}
for (Thread t : ts) t.join();       // 等所有都完成
System.out.println("all done");
```

**说明**：现代代码通常用 `CompletableFuture.allOf(...)` 或 `pool.invokeAll(...)` 替代手写 join。

**2. yield：礼让 CPU**
```java
Thread.yield();
```
特点：
- 只是**提示**，调度器可以忽略
- **不释放锁**
- 状态仍是 RUNNABLE（不会进入 WAITING）
- 生产几乎用不到，主要用于测试

**3. 四兄弟对比表**（板书）

| 方法 | 归属 | 释锁 | 状态 | 唤醒方式 |
|------|------|------|------|---------|
| `sleep(ms)` | Thread 静态 | 否 | TIMED_WAITING | 超时/中断 |
| `wait()` | Object 实例 | **是** | WAITING | notify/中断 |
| `t.join()` | Thread 实例 | 否 | WAITING/TIMED_WAITING | 目标线程结束/中断 |
| `yield()` | Thread 静态 | 否 | RUNNABLE | 调度器决定 |

**4. 协作式中断**

Java 中断不是「强制杀线程」，而是**设置一个标记**，被中断的线程需要**主动检查并响应**。

标准模板：
```java
Thread t = new Thread(() -> {
    while (!Thread.currentThread().isInterrupted()) {
        // do work
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            // sleep 抛异常后中断标记被清除！
            Thread.currentThread().interrupt();   // 手动重新设置
            break;
        }
    }
    System.out.println("优雅退出");
});
t.start();
Thread.sleep(500);
t.interrupt();
```

**坑**：`sleep / wait / join` 抛 `InterruptedException` 后，**中断标记会被清除**。若还想让上层感知，必须重新 `interrupt()`。

**5. 何时用 join / 何时用 CompletableFuture**
- 小规模、教学场景：join
- 生产：`CompletableFuture` / `pool.invokeAll` / `CountDownLatch`

#### 示例演示（16 分钟）
现场演示多任务并行 + join 汇总：
```java
List<Thread> tasks = new ArrayList<>();
long start = System.currentTimeMillis();
for (int i = 0; i < 3; i++) {
    final int id = i;
    Thread t = new Thread(() -> {
        try { Thread.sleep((id + 1) * 1000L); } catch (InterruptedException e) {}
        System.out.println("task " + id + " done");
    });
    t.start();
    tasks.add(t);
}
for (Thread t : tasks) t.join();
System.out.println("total: " + (System.currentTimeMillis() - start) + "ms");
// 输出约 3000ms —— 是最长任务，不是三者之和
```

再演示协作式中断：
```java
Thread worker = new Thread(() -> {
    int i = 0;
    while (!Thread.currentThread().isInterrupted()) {
        System.out.println("work " + (i++));
        try { Thread.sleep(300); }
        catch (InterruptedException e) {
            System.out.println("被中断，退出");
            Thread.currentThread().interrupt();
            break;
        }
    }
});
worker.start();
Thread.sleep(1000);
worker.interrupt();
```

#### 课堂练习（5 分钟）
1. 判断题：`Thread.yield()` 会释放锁吗？（不会）
2. `t.join()` 期间当前线程处于什么状态？（WAITING）
3. 主线程启动 3 个子线程分别 sleep 1s/2s/3s，用 join 让主线程等它们全部结束

#### 小结（3 分钟）
- join = 等线程结束（现代替代：CompletableFuture / invokeAll）
- yield = 礼让 CPU（几乎只用于测试）
- 四兄弟对比表要记住「释锁 / 状态 / 唤醒」三列
- 中断是协作式的：`interrupt()` 只设标记，被中断代码要主动响应

### 15.4 板书设计
```text
┌────────────────────────────────────────────┐
│  join   ：等目标线程结束（阻塞当前）       │
│  yield  ：礼让提示（调度器可忽略）         │
│                                            │
│  四兄弟 sleep/wait/join/yield              │
│    看：释锁？ 状态？ 唤醒？                │
│                                            │
│  协作式中断：                              │
│  interrupt() 只设标记                      │
│  被中断代码 while(!isInterrupted()) ...    │
│  catch InterruptedException →              │
│      重新 interrupt() + break              │
└────────────────────────────────────────────┘
```

### 15.5 课后作业（本日上半汇总）
1. 完成教材 §5 全部示例代码抄写与运行
2. 独立完成 §5 练习题 1、3、4、5
3. 挑战：实现题 6——「上传日志」拒绝策略：满时先落地磁盘再重入队

### 15.6 教学反思提示
- 「join 现代替代」提一下 `CompletableFuture` 埋伏笔即可，Day06 再深讲
- 中断标记被清除的坑几乎每个人踩过一次，务必演示

---

## 第 16 课时：反射概述与 Class 对象

### 16.1 教学目标
#### 16.1.1 知识与技能目标
1. 能说清「反射」的定义：运行时动态获取类信息、操作构造器/字段/方法
2. 能画出「.java → .class → Class 对象 → 实例」的关系图
3. 掌握获取 Class 对象的 4 种方式
4. 能说出反射的 4 大代价：性能、安全、可读性、稳定性

#### 16.1.2 过程与方法目标
1. 通过 `Class.forName("java.util.ArrayList")` 让学生看到「从字符串创建对象」的魔法
2. 通过 `c1 == c2 == c3 == c4` 的相等测试，理解「一个类在 JVM 中只对应一个 Class 对象」

### 16.2 教学重难点
- **重点**：4 种获取方式 / Class 对象在 JVM 中的唯一性
- **难点**：Class 对象 ≠ 类的实例 —— 是「描述类的元数据对象」

### 16.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
问：「如果我有一个类名字符串 `"java.util.ArrayList"`，能不能凭这个字符串创建一个 ArrayList？」多数学生说不能。演示：
```java
Object obj = Class.forName("java.util.ArrayList").getDeclaredConstructor().newInstance();
System.out.println(obj);   // []
```
学生震惊——这就是**反射**。Spring / Jackson / MyBatis 全靠它。

#### 新知讲授（18 分钟）
**1. 反射的定义**

在**运行时**动态地获取任意类的信息，并操作它的构造器、字段、方法—— **即使你编译时并不知道这个类是什么**。

**2. 三层对象关系图**（板书 Mermaid）
```text
.java 源码
    │编译
    ▼
.class 字节码文件
    │ClassLoader 加载
    ▼
方法区中的 Class 对象   ← 反射入口
    │new
    ▼
堆中的实例对象
```

**核心**：每个类**在 JVM 中只对应一个 Class 对象**。所有反射操作都从它出发。

**3. 反射能做什么**
- 根据字符串创建对象
- 读写任意字段（含 private）
- 调用任意方法（含 private）
- 读注解，做元编程（Spring / JUnit）
- 生成动态代理（Spring AOP）

**4. 4 种获取 Class 的方式**（板书）
```java
Class<String> c1 = String.class;                    // 类字面量
Class<?> c2 = "hi".getClass();                      // 对象.getClass()
Class<?> c3 = Class.forName("java.lang.String");    // 全限定名
Class<?> c4 = ClassLoader.getSystemClassLoader()    // ClassLoader
                        .loadClass("java.lang.String");
```

**关键性质**：`c1 == c2 == c3 == c4` 都是 `true` —— 是同一个 Class 对象。

**各自使用场景**：
| 方式 | 场景 |
|------|------|
| 类字面量 | 编译时已知类，最快 |
| 对象.getClass | 已有对象，取其运行时类 |
| `forName` | 类名来自配置/字符串（框架常用） |
| ClassLoader | 需要指定/隔离类加载器（插件系统） |

**5. 反射的 4 大代价**（板书圈红）
- **性能**：比直接调用慢一个数量级
- **安全**：可以突破 `private`
- **可读性**：编译器看不到调用，运行时才出错
- **稳定性**：字段/方法名一改就断裂

**结论**：业务代码尽量不用；框架用它换取灵活性。

#### 示例演示（16 分钟）
现场演示 4 种获取方式与相等性：
```java
Class<?> c1 = String.class;
Class<?> c2 = "hi".getClass();
Class<?> c3 = Class.forName("java.lang.String");
Class<?> c4 = ClassLoader.getSystemClassLoader().loadClass("java.lang.String");
System.out.println(c1 == c2);   // true
System.out.println(c2 == c3);   // true
System.out.println(c3 == c4);   // true
System.out.println(c1);         // class java.lang.String
```

再演示「从字符串创建对象」的动态感：
```java
String className = args.length > 0 ? args[0] : "java.util.ArrayList";
Object obj = Class.forName(className).getDeclaredConstructor().newInstance();
System.out.println(obj.getClass());   // 用户传什么就打什么
```
运行时改命令行参数即可创建完全不同的类的实例——**这就是配置驱动**。

再打印 Class 对象的元信息：
```java
Class<?> c = ArrayList.class;
System.out.println("Name:       " + c.getName());
System.out.println("SimpleName: " + c.getSimpleName());
System.out.println("Package:    " + c.getPackage());
System.out.println("Superclass: " + c.getSuperclass());
System.out.println("Interfaces: " + Arrays.toString(c.getInterfaces()));
```

#### 课堂练习（4 分钟）
1. 写出获取 `Integer` 的 Class 对象的 4 种方式
2. 判断：一个 `String` 类在 JVM 中有几个 Class 对象？（1 个）
3. 说出反射的 2 大用途和 2 大代价

#### 小结（3 分钟）
- 反射 = 运行时动态获取类信息 + 操作成员
- 入口 `Class` 对象，JVM 中类唯一
- 4 种获取方式：字面量 / getClass / forName / ClassLoader
- 4 大代价：性能 / 安全 / 可读性 / 稳定性

### 16.4 板书设计
```text
┌────────────────────────────────────────────┐
│  反射 = 运行时动态获取类信息               │
│  入口：Class 对象（JVM 唯一）              │
│                                            │
│  4 种获取方式：                            │
│    1.String.class                          │
│    2.obj.getClass()                        │
│    3.Class.forName("...")                  │
│    4.ClassLoader.loadClass("...")          │
│                                            │
│  4 大代价：性能/安全/可读性/稳定性         │
└────────────────────────────────────────────┘
```

### 16.5 课后作业
1. 抄写运行教材 §6.1 全部示例
2. 打印 `HashMap` 的完整信息：Name / SimpleName / Package / Superclass / Interfaces
3. 写一个方法 `Object create(String className)`，通过 `Class.forName` + 无参构造反射创建对象

### 16.6 教学反思提示
- 「Class 对象 ≠ 类的实例」学生常混淆，用「一份蓝图 vs 多个产品」类比
- `Class.forName` 的字符串来自配置——为下节课「反射 + 注解 = Spring IoC」埋伏笔

---

## 第 17 课时：反射三大操作（构造/字段/方法）

### 17.1 教学目标
#### 17.1.1 知识与技能目标
1. 掌握反射三大操作：获取构造器、字段、方法
2. 会用 `setAccessible(true)` 突破 private
3. 能区分 `getXxx` 与 `getDeclaredXxx` 的差异
4. 会调用静态方法（`invoke(null, ...)`）

#### 17.1.2 过程与方法目标
1. 通过一个 `User` 类走完「构造对象 → 读私有字段 → 改字段 → 调用私有方法」的完整流程
2. 通过 `setAccessible` 前后的对比，感受「反射的越界能力」

### 17.2 教学重难点
- **重点**：三大操作的 API / getXxx vs getDeclaredXxx / setAccessible
- **难点**：`invoke` 的第一个参数：实例方法传对象，静态方法传 null

### 17.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「上节课我们能『看』一个类，还不能真『操作』它。今天学反射三大操作：造对象、改字段、调方法。」

#### 新知讲授（20 分钟）

准备示例类（板书简版）：
```java
public class User {
    private String name;
    public  int    age;
    public  User() { this("匿名", 0); }
    public  User(String name, int age) { this.name = name; this.age = age; }
    private User(String name) { this(name, -1); }
    public  void say(String msg) { System.out.println(name + " 说：" + msg); }
    private String secret() { return "hidden-" + name; }
}
```

**1. getXxx vs getDeclaredXxx**（板书）

| 方法 | 范围 |
|------|------|
| `getConstructors / getFields / getMethods` | **只有 public**，方法含父类继承 |
| `getDeclaredXxx` | **本类全部**（含 private），不含继承 |

**2. 操作构造器**
```java
Class<?> clazz = User.class;

Constructor<?> c0 = clazz.getConstructor();                        // public 无参
Constructor<?> c1 = clazz.getConstructor(String.class, int.class); // public 双参
Constructor<?> cp = clazz.getDeclaredConstructor(String.class);    // private 单参

User u1 = (User) c0.newInstance();
User u2 = (User) c1.newInstance("Tom", 20);

cp.setAccessible(true);          // 突破 private
User u3 = (User) cp.newInstance("Jerry");   // age = -1
```

**注意**：`Class.newInstance()` 在 Java 9 已 `@Deprecated`，用 `getDeclaredConstructor().newInstance()` 代替。

**3. 操作字段**
```java
Field nameField = clazz.getDeclaredField("name");
nameField.setAccessible(true);       // private 必须

User u = new User("Tom", 20);
System.out.println(nameField.get(u));    // Tom
nameField.set(u, "Alice");
System.out.println(u);                    // User{name=Alice, age=20}
```

字段元信息：
```java
nameField.getType();         // String.class
nameField.getName();         // "name"
Modifier.toString(nameField.getModifiers());   // "private"
```

**4. 调用方法**
```java
Method say    = clazz.getMethod("say", String.class);      // public
Method secret = clazz.getDeclaredMethod("secret");         // private

say.invoke(u, "Hello");             // invoke 第一个参数是对象
secret.setAccessible(true);
Object r = secret.invoke(u);        // 返回值封装为 Object
```

**静态方法** 第一个参数传 null：
```java
Method valueOf = Integer.class.getMethod("valueOf", String.class);
Integer i = (Integer) valueOf.invoke(null, "123");
```

**5. 数组反射**
```java
Object arr = Array.newInstance(int.class, 5);   // new int[5]
Array.setInt(arr, 0, 10);
System.out.println(Array.getInt(arr, 0));       // 10
System.out.println(Array.getLength(arr));       // 5
```

**6. 泛型信息**
编译后擦除，但**签名信息保留**在字节码常量池：
```java
class Box { private List<String> items; }
Field f = Box.class.getDeclaredField("items");
System.out.println(f.getType());          // interface java.util.List
System.out.println(f.getGenericType());   // java.util.List<java.lang.String>
```
但运行时对象仍是擦除的 `List`。

#### 示例演示（15 分钟）
现场敲完整流程——把上面所有代码串起来，从 `Class.forName` 开始一路到调用私有方法：
```java
Class<?> clazz = Class.forName("com.demo.User");

Constructor<?> ctor = clazz.getDeclaredConstructor(String.class);
ctor.setAccessible(true);
User u = (User) ctor.newInstance("Jerry");
System.out.println(u);                            // User{name=Jerry, age=-1}

Field nameField = clazz.getDeclaredField("name");
nameField.setAccessible(true);
nameField.set(u, "改了！");
System.out.println(u);                            // User{name=改了！, age=-1}

Method secret = clazz.getDeclaredMethod("secret");
secret.setAccessible(true);
System.out.println(secret.invoke(u));             // hidden-改了！
```

再演示「不 setAccessible 直接访问 private」抛 `IllegalAccessException`。

#### 课堂练习（4 分钟）
1. `getDeclaredMethods` 与 `getMethods` 的两处差异？（范围 + 是否含继承）
2. `Method.invoke(obj, args...)` 中调用静态方法时第一个参数传什么？（null）
3. 写代码用反射把 `private String name` 改成 `"hacked"`

#### 小结（3 分钟）
- 三大操作：**构造器 / 字段 / 方法**
- `getXxx`（public） / `getDeclaredXxx`（含 private）
- `setAccessible(true)` 突破封装
- `invoke`：实例方法传对象，静态方法传 null

### 17.4 板书设计
```text
┌────────────────────────────────────────────┐
│  反射三大操作                              │
│    构造：getDeclaredConstructor(...)       │
│           .newInstance(...)                │
│    字段：getDeclaredField("name")          │
│           .get(obj) / .set(obj, v)         │
│    方法：getDeclaredMethod("say",String)   │
│           .invoke(obj, arg)                │
│                                            │
│  private 三步：                            │
│    getDeclaredXxx → setAccessible(true)    │
│      → get/invoke                          │
│                                            │
│  静态方法 invoke(null, args...)            │
└────────────────────────────────────────────┘
```

### 17.5 课后作业
1. 抄写运行教材 §6.2 全部示例
2. 写方法 `dump(Object obj)`：反射打印所有字段名和当前值（含 private）
3. 挑战：`Field copy(Object src, Object dst)` 复制两个同类型对象的所有非 static 字段

### 17.6 教学反思提示
- `invoke` 静态方法传 null 学生容易忘——现场演示一次
- `setAccessible(true)` 打破 private 让学生震惊，正好引出「反射的代价与治理」

---

## 第 18 课时：反射应用（迷你 IoC + 动态代理）

### 18.1 教学目标
#### 18.1.1 知识与技能目标
1. 能说出反射的 5 大典型应用场景
2. 能写出**迷你 @Autowired 容器**的核心 20 行代码
3. 认识动态代理（`Proxy.newProxyInstance`）
4. 掌握反射的最佳实践：缓存 Method/Field、少用 setAccessible

#### 18.1.2 过程与方法目标
1. 通过迷你 IoC 把「反射 + 注解」串起来，让学生看到 Spring 核心思想的雏形
2. 通过动态代理打印日志的例子，理解 AOP 的底层机制

### 18.2 教学重难点
- **重点**：反射 + 注解 = 元编程 / 迷你 IoC 完整流程 / 动态代理三要素
- **难点**：动态代理的 `InvocationHandler` 是拦截入口，`method.invoke(obj, args)` 委托真实调用

### 18.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「反射的三大操作学完了，都是零碎语法。今天用一节课把它们串起来做点大事——**手写一个迷你 Spring**。」

#### 新知讲授（16 分钟）
**1. 反射 5 大应用**（板书）

| 场景 | 用途 |
|------|------|
| Spring IoC | 反射创建 Bean、注入依赖 |
| MyBatis | 反射把 ResultSet 映射到 JavaBean |
| Jackson / Gson | 反射读写字段做 JSON 序列化 |
| JUnit | 反射找 `@Test` 方法并调用 |
| 动态代理 | 生成代理对象拦截方法（Spring AOP） |

**2. 迷你 IoC 容器**（板书核心 20 行）
```java
public @interface Autowired {}

public class Container {
    private final Map<Class<?>, Object> beans = new HashMap<>();

    public <T> void register(Class<T> type, T instance) {
        beans.put(type, instance);
    }

    public void wire(Object bean) throws Exception {
        for (Field f : bean.getClass().getDeclaredFields()) {
            if (f.isAnnotationPresent(Autowired.class)) {
                Object dep = beans.get(f.getType());
                if (dep == null) throw new IllegalStateException("找不到 bean: " + f.getType());
                f.setAccessible(true);
                f.set(bean, dep);
            }
        }
    }
}
```

使用：
```java
class UserRepository { public String find(long id) { return "user-" + id; } }
class UserService {
    @Autowired UserRepository repo;
}

Container c = new Container();
c.register(UserRepository.class, new UserRepository());

UserService svc = new UserService();
c.wire(svc);
System.out.println(svc.repo.find(1));    // user-1
```

**核心思想**：
- 用注解**标记**要注入的字段
- 用反射**扫描**注解
- 用反射**设置**字段值

Spring 干的事情就是这个思路的工业级实现。

**3. 反射 + JSON 序列化玩具**
```java
public static String toJson(Object obj) throws IllegalAccessException {
    StringBuilder sb = new StringBuilder("{");
    Field[] fs = obj.getClass().getDeclaredFields();
    for (int i = 0; i < fs.length; i++) {
        fs[i].setAccessible(true);
        Object v = fs[i].get(obj);
        sb.append("\"").append(fs[i].getName()).append("\":");
        sb.append(v instanceof String s ? "\"" + s + "\"" : v);
        if (i < fs.length - 1) sb.append(",");
    }
    return sb.append("}").toString();
}

System.out.println(toJson(new User("Tom", 20)));   // {"name":"Tom","age":20}
```

**4. 动态代理三要素**

```java
public interface Hello { String hi(String name); }

Hello proxy = (Hello) Proxy.newProxyInstance(
    Hello.class.getClassLoader(),          // 类加载器
    new Class<?>[] { Hello.class },        // 要实现的接口
    (proxyObj, method, args) -> {          // InvocationHandler：拦截入口
        System.out.println("调用前：" + method.getName() + " " + Arrays.toString(args));
        String r = "hi, " + args[0];
        System.out.println("调用后：" + r);
        return r;
    });

proxy.hi("Tom");
```

三要素：**类加载器 + 接口数组 + InvocationHandler**。Spring AOP、事务、日志切面全靠这个。

**5. 反射的最佳实践**
- 能不反射就不反射
- **缓存 Field / Method**：反射查找有开销，缓存后可显著提速
- `setAccessible(true)` **只设一次**
- Java 9+ 模块化：跨模块反射需要 `--add-opens`
- 极致性能场景：换 `MethodHandle`（比反射快）或字节码生成（ASM / Byte Buddy）

#### 示例演示（18 分钟）
现场敲**迷你 IoC 完整例子**——从注解定义到最终注入调用，让学生完整看到「反射 + 注解 = Spring 雏形」。

再演示动态代理：给一个真实的 `List` 加打点：
```java
List<String> real = new ArrayList<>();

@SuppressWarnings("unchecked")
List<String> proxy = (List<String>) Proxy.newProxyInstance(
    List.class.getClassLoader(),
    new Class<?>[] { List.class },
    (p, method, args) -> {
        long t0 = System.nanoTime();
        Object r = method.invoke(real, args);
        long cost = (System.nanoTime() - t0) / 1000;
        System.out.println(method.getName() + " 耗时 " + cost + "us");
        return r;
    });

proxy.add("A");
proxy.add("B");
proxy.size();
```

学生看到每个调用都被拦截、打印耗时——这就是 AOP。

#### 课堂练习（5 分钟）
1. 说出「反射 + 注解」的两个真实框架用例（Spring IoC、JUnit `@Test`）
2. `Proxy.newProxyInstance` 三个参数分别是什么？
3. 写一段代码：用迷你容器注入一个 `Logger` 到 `Service` 中

#### 小结（3 分钟）
- 反射的价值在**框架**：Spring / MyBatis / Jackson / JUnit
- 迷你 IoC 三步：注解标记 → 反射扫描 → 反射注入
- 动态代理三要素：ClassLoader + 接口数组 + InvocationHandler
- 反射有代价，业务代码优先普通调用

### 18.4 板书设计
```text
┌────────────────────────────────────────────┐
│  反射 5 大应用                             │
│  Spring IoC / MyBatis / Jackson /          │
│  JUnit / 动态代理                          │
│                                            │
│  迷你 IoC 三步：                           │
│    1.定义 @Autowired 注解                  │
│    2.反射扫描 f.isAnnotationPresent(...)   │
│    3.f.set(bean, dep) 注入                 │
│                                            │
│  动态代理三要素：                          │
│    ClassLoader + 接口数组                  │
│      + InvocationHandler                   │
└────────────────────────────────────────────┘
```

### 18.5 课后作业（本日汇总）

**必做**：
1. 完成教材 §5、§6 全部示例代码抄写与运行
2. 独立完成教材 §5 练习题 1、3、4、5 和 §6 练习题 1、2、3、4
3. 综合题：定义 `@Print` 注解，实现 `printFields(Object obj)`——只打印带 `@Print` 的字段

**选做**：
1. 用动态代理为任意接口生成 `AuditLogProxy`：前后打印方法名、参数、返回值、耗时
2. 阅读 Spring `@Autowired` 源码（`AutowiredAnnotationBeanPostProcessor`），找出它对我们迷你版做了哪些补充

### 18.6 教学反思提示
- 迷你 IoC 是本课高潮，务必现场跑通，让学生看到「Spring 也就这样」的顿悟
- 动态代理的 `method.invoke(real, args)` 学生常写成 `method.invoke(proxy, args)` 导致栈溢出，务必强调

---

## 本日总结

Day03 完成教材第 5、6 讲。学生带走的核心能力：
- **线程与并发（下）**：`ThreadPoolExecutor` 七大参数与工作流程、6 种线程状态、wait/notify 模板、join/yield/中断
- **反射**：Class 对象与 4 种获取方式、三大操作（构造/字段/方法）、反射 + 注解 = 元编程雏形、动态代理

明日（Day04）主题：**注解 + 集合精讲**，对应教材第 7、8 讲。请学生课后完成必做作业。
