# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day05（第 25-30 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Day04（注解、集合精讲）的大学一年级学生
**知识点覆盖**：数据结构手写实现（3 课时） + 内部类与接口增强（3 课时）
**参考教材**：`../教材/chapters/09.md`、`10.md`

---

## 本日知识地图

```mermaid
flowchart LR
    subgraph G1["上午 · 数据结构"]
        direction LR
    L25["第 25 课时<br/>手写 ArrayList / 链表"]
    L26["第 26 课时<br/>栈 / 队列 / 手写 HashMap"]
    L27["第 27 课时<br/>数据结构综合选型"]
    end
    subgraph G2["下午 · 内部类家族"]
        direction LR
    L28["第 28 课时<br/>成员 / 静态嵌套类"]
    L29["第 29 课时<br/>局部 / 匿名 / Lambda 铺垫"]
    L30["第 30 课时<br/>接口增强 + Record + Sealed"]
    end
    L25 --> L26 --> L27
    L28 --> L29 --> L30
    L27 -.承接.-> L28
```

> 6 个课时按「数据结构 → 内部类家族」两大板块递进；上午打基础，下午做延伸，最后一课时做本日综合练习。

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：沿用；本讲要用泛型自定义类、`Comparable` 接口、`sealed` 密封类（若讲拓展）、`record`（内部类对比时可现场演示 `record` 替代方案）。
2. **IntelliJ IDEA（下简称 IDEA） 工程**：`day05-datastructure-innerclass/`，含 `mylist`（手写 ArrayList/LinkedList）、`mymap`（手写 HashMap + BST）、`inner`（成员/静态/局部/匿名内部类）、`iface`（default / static / private 接口方法与函数式接口）五个包。
3. **对拍工具**：预置 `PkTest.java` 用 `java.util.ArrayList` 与手写 `MyArrayList` 对拍随机操作 1 万次，用于第 25、27 课时的验证环节。
4. **可视化 GIF**：准备 3 段 GIF 放到 `assets/`：链表节点插入动画、HashMap 链化过程、BST 平衡插入过程，讲授时逐个投影。
5. **打印讲义**：附录「时间复杂度速查表」+「Big-O 记忆歌诀」一人一份。

### 学情预设
- 前置：Day04 集合精讲已通过；`ArrayList` 内部数组扩容学生知道 1.5 倍但没手写过；`HashMap` 哈希冲突听过没画过。
- 预计易混：动态数组 vs 链表访问/插入复杂度、单链表 vs 双链表遍历方向、内部类 4 种（成员、静态、局部、匿名）的语法差异、`default` 方法与「菱形继承」冲突。
- 预计基础差距：手写 BST 是本课程最难节点，约 40% 学生首次听递归实现，需在示例演示前先在纸上画 3 次插入。

### 教具与板书素材
- 板书左「MyArrayList 数组示意 + capacity/size 双指针」，中「链表节点连线 head→n1→n2→null」，右「BST 三种遍历顺序（前中后序）伪代码」。
- 打印 A4：「四种内部类语法对照表 + 何时使用」，一人一份。

### 前置检查（上课前 5 分钟完成）
- 全班在 IDEA 中打开 `mylist/MyArrayList.java` 骨架并编译通过（骨架只有字段声明，方法体空），确保工程构建无误。
- 教师机放 GIF 的目录路径确认可从投影播放。
- 板书三区擦净，粉笔备两色（白色画结构、红色标 pitfall）。

---

## 第 25 课时：手写 ArrayList 与单链表

### 25.1 教学目标
#### 25.1.1 知识与技能目标
1. 理解数组、链表两种线性结构的物理区别
2. 亲手完成 `MyArrayList`：动态扩容、`System.arraycopy` 搬迁
3. 亲手完成 `MyLinkedList`：Node 定义、增删查、`toString`
4. 会写单链表反转（经典面试题）

#### 25.1.2 过程与方法目标
1. 通过对比两种结构操作复杂度，理解「为什么随机访问选 ArrayList、频繁头尾插入选链表」
2. 通过手写代码看到 `Object[]` + 泛型强转的技术细节

### 25.2 教学重难点
- **重点**：`MyArrayList` 扩容公式 `newCap = oldCap + (oldCap >> 1)` / 单链表节点内部类 / 反转三指针
- **难点**：`System.arraycopy` 参数含义 / 单链表反转过程 —— 三指针 prev / curr / next 的推进节奏

### 25.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「上讲学了集合『怎么用』，今天学『怎么造』。造出来的东西不追求生产级，够看清原理即可。手写一次，胜过读十遍源码。」

翻问：`ArrayList` 底层是什么？（数组）扩容时会发生什么？（复制到新数组）今天亲手看到答案。

#### 新知讲授（18 分钟）

**1. 数据结构总览**（板书简化图）
```text
线性：数组 / 链表 / 栈 / 队列
非线性：树 / 图 / 散列表
```

**2. MyArrayList 骨架**（板书核心 4 行）
```java
public class MyArrayList<E> {
    private Object[] data;         // 底层数组
    private int size;              // 当前长度
    public MyArrayList() { data = new Object[10]; }
    ...
}
```

**3. add / get / remove 核心逻辑**
```java
public void add(E e) {
    ensureCapacity(size + 1);
    data[size++] = e;
}

public void add(int index, E e) {
    checkIndexForAdd(index);
    ensureCapacity(size + 1);
    // 从 index 开始的元素整体后移一位
    System.arraycopy(data, index, data, index + 1, size - index);
    data[index] = e;
    size++;
}

public E get(int index) {
    checkIndex(index);
    return (E) data[index];       // 泛型强转
}

public E remove(int index) {
    checkIndex(index);
    E old = (E) data[index];
    int move = size - index - 1;
    if (move > 0) System.arraycopy(data, index + 1, data, index, move);
    data[--size] = null;          // help GC
    return old;
}
```

**扩容公式**（板书圈红）：
```java
private void ensureCapacity(int need) {
    if (need <= data.length) return;
    int newCap = data.length + (data.length >> 1);   // 1.5 倍
    if (newCap < need) newCap = need;
    data = Arrays.copyOf(data, newCap);
}
```

**`>> 1` 是位运算「除以 2」**，`oldCap + oldCap >> 1 = 1.5 oldCap`。JDK 源码同款。

**4. 与 JDK ArrayList 的差异**
- JDK 有 `modCount` 用于 fail-fast 迭代器
- JDK 初始容量为 0（懒初始化），首次 add 才扩到 10
- JDK 有溢出保护 / trimToSize / iterator

**5. 单链表节点**
```java
private static class Node<E> {
    E val;
    Node<E> next;
    Node(E val, Node<E> next) { this.val = val; this.next = next; }
}
```
**为什么 `static`**：节点是纯数据结构，不需要外部类引用；用 `static` 避免隐式引用带来的内存开销（呼应今天下午的内部类课）。

**6. MyLinkedList 核心方法**
```java
private Node<E> head;
private int size;

public void addFirst(E e) {
    head = new Node<>(e, head);
    size++;
}

public void addLast(E e) {
    if (head == null) { head = new Node<>(e, null); size++; return; }
    Node<E> p = head;
    while (p.next != null) p = p.next;
    p.next = new Node<>(e, null);
    size++;
}

public E get(int index) {
    checkIndex(index);
    Node<E> p = head;
    for (int i = 0; i < index; i++) p = p.next;
    return p.val;
}
```

**关键点**：
- 单链表尾插 O(n) —— 从头遍历
- 工业级 `LinkedList` 是**双向链表 + 尾指针**，尾插 O(1)
- 删除中间节点要拿到「前驱节点」——单链表要遍历

**7. 单链表反转**（板书三指针）
```java
public static <E> Node<E> reverse(Node<E> head) {
    Node<E> prev = null;
    Node<E> curr = head;
    while (curr != null) {
        Node<E> next = curr.next;   // 暂存下一节点
        curr.next = prev;           // 反转当前指针
        prev = curr;                // prev 前进
        curr = next;                // curr 前进
    }
    return prev;                    // 新头
}
```
**画图讲**：初始 `null <- a -> b -> c`；每步把 `curr.next` 指回 `prev`，然后 prev / curr 各前进一位。

#### 示例演示（15 分钟）
现场敲完整 `MyArrayList`（简化到 add/get/remove）跑测试：
```java
MyArrayList<String> list = new MyArrayList<>();
list.add("a"); list.add("b"); list.add("c");
list.add(1, "x");
System.out.println(list);   // [a, x, b, c]
list.remove(0);
System.out.println(list);   // [x, b, c]
```

再敲 `MyLinkedList`：addFirst / addLast / get / toString，跑起来看输出：
```java
[1 -> 2 -> 3 -> 4]
```

用画笔画反转的三指针过程，让学生跟着推 3 步。

#### 课堂练习（5 分钟）
1. `ArrayList` 扩容 1.5 倍的位运算怎么写？（`cap + (cap >> 1)`）
2. `System.arraycopy(a, i, a, i+1, n)` 的含义？（从 a[i] 开始的 n 个元素向后移 1 位）
3. 单链表反转的三个指针各自角色？

#### 小结（3 分钟）
- ArrayList = 动态数组 + 扩容 + arraycopy
- 单链表 = Node 引用相连，尾插 O(n)
- 反转 = 三指针：prev / curr / next
- 手写一次原理就懂了

### 25.4 板书设计
```text
┌────────────────────────────────────────────┐
│  MyArrayList                               │
│    Object[] data;  int size;               │
│    扩容：newCap = cap + (cap >> 1)         │
│    add(i,e)：arraycopy 后移 → 赋值         │
│    remove(i)：arraycopy 前移 → size--      │
│                                            │
│  MyLinkedList                              │
│    static class Node { E val; Node next; } │
│    addFirst：head = new Node(e, head)      │
│    addLast：遍历到尾，尾插 O(n)            │
│                                            │
│  反转三指针：prev / curr / next            │
└────────────────────────────────────────────┘
```

### 25.5 课后作业
1. 抄写运行教材 §9.2 + §9.3 全部示例
2. 独立完成教材 §9 练习题 1：给 `MyArrayList` 增加 `indexOf(E)` 和 `iterator()`
3. 挑战：把 `MyLinkedList` 改造成**双向链表 + 尾指针**（教材练习 2）

### 25.6 教学反思提示
- 三指针反转务必画图讲，学生第一次看很懵
- `System.arraycopy` 的 5 个参数记住助记：src / srcPos / dst / dstPos / length
- 强调「手写不是重复造轮子，是**看清工业级源码**」

---

## 第 26 课时：栈、队列与手写 HashMap

### 26.1 教学目标
#### 26.1.1 知识与技能目标
1. 用数组实现栈：`push / pop / peek` 的 `top` 指针
2. 用**循环数组**实现队列：`head` / `tail` 环形推进
3. 认识哈希表原理：hash → 桶下标 → 拉链
4. 亲手实现 `MyHashMap`：put / get / remove / resize

#### 26.1.2 过程与方法目标
1. 通过循环数组的取模操作，理解「为什么 JDK 用 2 的幂 + 位运算」
2. 通过手写 hash 扰动 `h ^ (h >>> 16)` 理解 JDK 精髓

### 26.2 教学重难点
- **重点**：循环数组队列的 `head / tail / size` 三变量 / 哈希表拉链法核心逻辑
- **难点**：`(len - 1) & hash` 等价取模（前提 len 是 2 的幂）

### 26.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「上节课手写了两个线性结构，今天挑战两个更常用的：**栈、队列**（简单）和 **HashMap**（重头戏）。HashMap 是面试常客——今天从头造一遍。」

#### 新知讲授（20 分钟）

**1. 数组栈**（板书）
```java
public class MyStack<E> {
    private Object[] data = new Object[16];
    private int top = 0;               // 下一个可写入位置

    public void push(E e) {
        if (top == data.length) data = Arrays.copyOf(data, data.length * 2);
        data[top++] = e;
    }
    public E pop() {
        if (top == 0) throw new NoSuchElementException();
        E v = (E) data[--top];
        data[top] = null;              // help GC
        return v;
    }
    public E peek() { return (E) data[top - 1]; }
}
```

**2. 循环数组队列**
```java
public class MyQueue<E> {
    private Object[] data = new Object[16];
    private int head, tail, size;

    public void offer(E e) {
        if (size == data.length) grow();
        data[tail] = e;
        tail = (tail + 1) % data.length;    // 环形推进
        size++;
    }
    public E poll() {
        if (size == 0) throw new NoSuchElementException();
        E v = (E) data[head];
        data[head] = null;
        head = (head + 1) % data.length;
        size--;
        return v;
    }
    private void grow() {
        Object[] bigger = new Object[data.length * 2];
        for (int i = 0; i < size; i++)
            bigger[i] = data[(head + i) % data.length];
        data = bigger;
        head = 0;
        tail = size;
    }
}
```

**关键点**（板书圈红）：`head` 追 `tail`，索引 `% length` 实现循环。JDK 的 `ArrayDeque` 更进一步：容量强制 2 的幂，用 `& (n - 1)` 替代取模（更快）。

**3. 哈希表原理**（板书 Mermaid 简化）
```text
key ──hashCode()──> hash ──(len-1)&hash──> 桶下标
        ↓ 冲突则拉链：桶里挂一条链表
        Node[key1, val1] -> Node[key2, val2] -> ...
```

**JDK 8 优化**：桶内链表长 > 8 且表容量 ≥ 64 → 转红黑树。

**4. MyHashMap 三大操作**

节点：
```java
private static class Node<K, V> {
    final int hash;
    final K key;
    V val;
    Node<K, V> next;
    Node(int hash, K k, V v, Node<K, V> next) {
        this.hash = hash; this.key = k; this.val = v; this.next = next;
    }
}
```

**put**：
```java
public V put(K key, V val) {
    int h = hash(key);
    int i = index(h, table.length);
    for (Node<K, V> p = table[i]; p != null; p = p.next) {
        if (p.hash == h && Objects.equals(p.key, key)) {
            V old = p.val; p.val = val; return old;   // 更新
        }
    }
    // 头插新节点
    table[i] = new Node<>(h, key, val, table[i]);
    if (++size > table.length * LOAD) resize();
    return null;
}
```

**get**：
```java
public V get(K key) {
    int h = hash(key);
    int i = index(h, table.length);
    for (Node<K, V> p = table[i]; p != null; p = p.next) {
        if (p.hash == h && Objects.equals(p.key, key)) return p.val;
    }
    return null;
}
```

**hash 扰动**（板书 JDK 同款）：
```java
private static int hash(Object key) {
    if (key == null) return 0;
    int h = key.hashCode();
    return h ^ (h >>> 16);       // 高 16 位异或到低 16 位
}
private static int index(int hash, int len) {
    return (len - 1) & hash;      // 前提 len 是 2 的幂
}
```
**为什么扰动**：`(len-1) & hash` 只用 hash 的低几位，若 hashCode 高位差别大低位相同，冲突严重；异或让高位也参与，降低冲突率。

**5. 与 JDK HashMap 的差异**
- JDK 桶内链表过长 → 树化为红黑树
- 提供 `LinkedHashMap` 的双向链表维护顺序
- 并发场景用 `ConcurrentHashMap`
- 自定义 key 必须**正确覆写 hashCode 和 equals**——否则 get 找不回自己刚 put 的值

**6. hashCode / equals 三条铁律**（板书圈红）
1. `a.equals(b) == true` → `a.hashCode() == b.hashCode()` **必须**成立
2. hashCode 相等不代表 equals（允许冲突）
3. 用作 HashMap key 的对象字段应**不可变**——put 后改字段会让 hash 位置错乱

#### 示例演示（15 分钟）
现场跑通 `MyStack` / `MyQueue`，看栈的 LIFO 和队列的 FIFO 输出。

再敲简版 `MyHashMap`（去掉 resize），跑测试：
```java
MyHashMap<String, Integer> map = new MyHashMap<>();
map.put("a", 1); map.put("b", 2); map.put("c", 3);
System.out.println(map.get("b"));   // 2
map.put("b", 22);
System.out.println(map.get("b"));   // 22
map.remove("a");
System.out.println(map.get("a"));   // null
System.out.println(map.size());     // 2
```

**翻车实验**：定义 `class Person { String name; }` 只覆写 equals 不覆写 hashCode，put 后 get 返回 null——`hashCode/equals 不一致` 的经典坑。

#### 课堂练习（5 分钟）
1. 循环数组队列 `tail = (tail + 1) % length`，若 length 是 2 的幂能改成什么？（`(tail + 1) & (length - 1)`）
2. 说出哈希表拉链法处理冲突的过程
3. 覆写 equals 却忘覆写 hashCode 会导致什么？（HashMap.get 找不到）

#### 小结（3 分钟）
- 栈：数组 + `top` 指针
- 队列：循环数组 + `head/tail/size`
- HashMap：hash → 桶 → 拉链；扰动 `h ^ (h >>> 16)`；下标 `(len-1) & hash`
- 铁律：equals 与 hashCode 必须一致

### 26.4 板书设计
```text
┌────────────────────────────────────────────┐
│  MyStack:  Object[] + top 指针             │
│    push: data[top++] = e                   │
│    pop:  data[--top]                       │
│                                            │
│  MyQueue（循环数组）:                      │
│    head / tail / size 三变量               │
│    tail = (tail + 1) % length              │
│                                            │
│  MyHashMap:                                │
│    hash = key.hashCode() ^ (h >>> 16)      │
│    index = (len - 1) & hash                │
│    冲突：拉链头插                          │
│    扩容阈值：size > cap * 0.75             │
│                                            │
│  hashCode/equals 三铁律 —— 一致！          │
└────────────────────────────────────────────┘
```

### 26.5 课后作业
1. 抄写运行教材 §9.4 + §9.5 全部示例
2. 独立完成教材 §9 练习题 3：用两个栈实现队列，enqueue / dequeue 摊还 O(1)
3. 挑战：给 `MyHashMap` 加 `resize()`（扩容到 2 倍并重分布）

### 26.6 教学反思提示
- 循环数组队列学生易懵，务必画图讲 `head/tail` 环形推进
- 覆写 equals 不覆写 hashCode 的翻车必须真的演示，否则学生不重视
- HashMap 手写太长，简化到 put/get/remove 即可，扩容留作业

---

## 第 27 课时：数据结构综合选型与总结

### 27.1 教学目标
#### 27.1.1 知识与技能目标
1. 内化「用什么容器解什么问题」的选型直觉
2. 认识 `PriorityQueue`（堆）与优先队列典型应用
3. 会看 `HashMap` / `LinkedHashMap` / `ConcurrentHashMap` 的取舍
4. 完成综合题：LRU 缓存（`LinkedHashMap`）与 Top-K（`PriorityQueue`）

#### 27.1.2 过程与方法目标
1. 通过完整选型速查表建立「先想需求、再想容器」的思路
2. 通过 LRU、Top-K 两个经典题目把本讲串起来

### 27.2 教学重难点
- **重点**：容器选型速查表 / PriorityQueue 使用 / LRU 用 LinkedHashMap 一行搞定
- **难点**：`LinkedHashMap` 传 `accessOrder = true` + 覆盖 `removeEldestEntry` 实现 LRU

### 27.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「前两节课手写了 5 个数据结构，今天做**选型专题**——不再造，只学怎么**用对**。加上一个高频的 `PriorityQueue`，最后用 LRU 和 Top-K 收尾。」

#### 新知讲授（18 分钟）

**1. 容器选型速查表**（板书全表，学生必抄）

| 需求 | 首选容器 | 备注 |
|------|---------|------|
| 频繁按下标随机访问 | `ArrayList` | O(1) get |
| 频繁头尾插入 / 出队 | `ArrayDeque` | 位运算，快于 LinkedList |
| 大量插入 + 少量查找 + 唯一 | `HashSet` | O(1) 平均 |
| 有序遍历 + 唯一 | `TreeSet` / `LinkedHashSet` | 前者自然序，后者插入序 |
| K → V 快查（多数场景） | `HashMap` | O(1) 平均 |
| K → V 按 key 排序 | `TreeMap` | O(log n) |
| K → V 按插入 / 访问序遍历 | `LinkedHashMap` | LRU 缓存基础 |
| 优先级排序取最优 | `PriorityQueue` | 堆 |
| 高并发 K → V | `ConcurrentHashMap` | 分段/CAS |
| 高并发读多写少 List | `CopyOnWriteArrayList` | 写时复制 |

**2. PriorityQueue（堆）**
```java
PriorityQueue<Integer> pq = new PriorityQueue<>();   // 默认小顶堆
pq.offer(3); pq.offer(1); pq.offer(4); pq.offer(1); pq.offer(5);
while (!pq.isEmpty()) System.out.println(pq.poll());
// 输出：1 1 3 4 5（每次取最小）
```

传 Comparator 变大顶堆：
```java
PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Comparator.reverseOrder());
```

**特点**：
- 底层是**二叉堆**（基于数组）
- `offer / poll` 都是 O(log n)
- `peek` O(1)
- 遍历**不保证有序**（只有 poll 才有序）

**3. LRU 缓存一行代码搞定**（板书重点）
```java
public class LRUCache<K, V> extends LinkedHashMap<K, V> {
    private final int capacity;
    public LRUCache(int capacity) {
        super(16, 0.75f, true);        // accessOrder = true（关键！）
        this.capacity = capacity;
    }
    @Override
    protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
        return size() > capacity;      // 超容量就淘汰最久未用
    }
}
```
**核心**：
- `accessOrder = true` → 每次 `get` 把节点移到链尾
- `removeEldestEntry` → put 后自动检查是否需要淘汰头节点
- 完美的 LRU 语义，10 行代码

用法：
```java
LRUCache<Integer, String> cache = new LRUCache<>(3);
cache.put(1, "A"); cache.put(2, "B"); cache.put(3, "C");
cache.get(1);              // 访问 1 → 1 挪到尾
cache.put(4, "D");         // 满 → 淘汰最久未用的 2
System.out.println(cache); // {3=C, 1=A, 4=D}
```

**4. Top-K 问题**：数组中最大的 k 个数
```java
public static int[] topK(int[] arr, int k) {
    PriorityQueue<Integer> pq = new PriorityQueue<>();   // 小顶堆
    for (int v : arr) {
        if (pq.size() < k) pq.offer(v);
        else if (v > pq.peek()) { pq.poll(); pq.offer(v); }
    }
    int[] r = new int[k];
    for (int i = 0; i < k; i++) r[i] = pq.poll();
    return r;
}
```
**思路**：维护大小为 k 的小顶堆——比堆顶大就替换。时间复杂度 O(n log k)。

#### 示例演示（16 分钟）
现场跑 `PriorityQueue` 的小顶堆和大顶堆输出。

完整 LRU 演示：
```java
LRUCache<Integer, String> cache = new LRUCache<>(3);
cache.put(1, "A");
cache.put(2, "B");
cache.put(3, "C");
System.out.println(cache);  // {1=A, 2=B, 3=C}
cache.get(1);
cache.put(4, "D");
System.out.println(cache);  // {3=C, 1=A, 4=D}
```

Top-K 现场跑：
```java
int[] r = topK(new int[]{3,1,7,2,9,4,5,6,8}, 3);
System.out.println(Arrays.toString(r));   // [7, 8, 9]
```

#### 课堂练习（5 分钟）
1. 需要「按插入顺序遍历 Map 键」用什么？（LinkedHashMap 默认插入序）
2. 需要「按 key 排序」用什么？（TreeMap）
3. Top-K 用小顶堆还是大顶堆？（**小顶堆**——堆顶是当前 k 个里最小值，方便替换）

#### 小结（3 分钟）
- 容器选型速查表要熟——面试常问
- PriorityQueue：堆，O(log n)
- LRU：LinkedHashMap + accessOrder + removeEldestEntry
- Top-K：小顶堆保留最大 k 个

### 27.4 板书设计
```text
┌────────────────────────────────────────────┐
│  选型 5 原则                               │
│  1.随机访问 → ArrayList                    │
│  2.头尾操作 → ArrayDeque                   │
│  3.唯一 → HashSet / TreeSet                │
│  4.排序 → TreeMap / TreeSet                │
│  5.并发 → ConcurrentHashMap                │
│                                            │
│  PriorityQueue：小顶堆，offer/poll O(log n)│
│                                            │
│  LRU = LinkedHashMap(cap, load, true)      │
│         + removeEldestEntry()              │
│                                            │
│  Top-K：大小 k 的小顶堆                    │
└────────────────────────────────────────────┘
```

### 27.5 课后作业（本日上半汇总）
1. 完成教材 §9 全部示例代码抄写与运行
2. 独立完成教材 §9 剩余练习题
3. 综合题：LRU 缓存类完整实现 + 测试（覆盖满/淘汰/访问后不淘汰）
4. 挑战：用 `PriorityQueue` 求「数据流的中位数」（双堆思路）

### 27.6 教学反思提示
- 选型表反复讲、反复问，让学生像背九九表一样内化
- LRU 一行搞定是本节课的「魔法时刻」，让学生真切感受 JDK 集合库的强大
- Top-K 常被面试问，多花时间练手

---

## 第 28 课时：成员内部类与静态嵌套类

### 28.1 教学目标
#### 28.1.1 知识与技能目标
1. 区分四类内部类：成员内部类 / 静态嵌套类 / 局部内部类 / 匿名内部类
2. 掌握成员内部类的**隐式外部引用**与 `外部类.this` 访问
3. 掌握静态嵌套类的独立性；能用它写 Builder 与内部 Node
4. 认识成员内部类的内存泄漏坑

#### 28.1.2 过程与方法目标
1. 通过 `Outer.this.x / this.x / x` 三层同名字段访问的例子理解作用域
2. 通过 Builder 模式实战体验静态嵌套类的价值

### 28.2 教学重难点
- **重点**：成员 vs 静态嵌套的差异 / Builder 模式模板
- **难点**：`外部实例.new 内部类()` 的语法 —— 为什么必须先有外部实例

### 28.3 教学过程设计（45 分钟)

#### 导入（3 分钟）
「早上手写 MyLinkedList 时用了 `private static class Node`，加了 `static`——为什么？今天讲清楚 4 种内部类，答案自明。」

#### 新知讲授（20 分钟）

**1. 内部类总览**（板书 Mermaid）
```text
类中定义的类
  ├ 成员内部类  (非 static)
  ├ 静态嵌套类  (static)
  ├ 局部内部类  (方法体内)
  └ 匿名内部类  (new 时创建)
```

**核心作用**：**代码组织手段**——把只服务于外部类的辅助类塞进去，隐藏细节。

**2. 成员内部类**
```java
public class Outer {
    private String name = "outer";
    public class Inner {
        public void hello() {
            System.out.println(name);   // 直接访问 private
        }
    }
}

Outer outer = new Outer();
Outer.Inner inner = outer.new Inner();  // ⚠️ 必须先有 outer
```

**关键**：成员内部类**隐式持有外部类实例引用** → 能自由访问外部私有字段。

**3. 同名字段的 3 层作用域**
```java
public class Outer {
    private int x = 10;
    public class Inner {
        private int x = 20;
        public void print() {
            int x = 30;
            System.out.println(x);              // 30 局部
            System.out.println(this.x);         // 20 Inner
            System.out.println(Outer.this.x);   // 10 Outer
        }
    }
}
```

**4. 成员内部类的坑**（板书圈红）
- 每个 Inner 实例持有 Outer 引用 → **可能内存泄漏**（Android 中特别常见）
- 反射创建时得传外部实例，很烦
- **90% 场景用 static 嵌套更好**

**5. 静态嵌套类**
```java
public class Outer {
    private static String flag = "F";
    public static class Node {
        int val;
        Node next;
        Node(int val) { this.val = val; }
        public String tag() { return flag; }   // 只能访问外部 static
    }
}

Outer.Node n = new Outer.Node(1);      // 不需要外部实例！
```

**特点**：
- **无隐式外部引用** → 独立
- 只能访问外部的 static 成员
- 使用时不需要外部实例

**6. 静态嵌套类三大用途**（板书）
1. **辅助数据结构**：`HashMap.Node`、`ArrayList` 的迭代器状态
2. **Builder 模式**：`User.Builder`
3. **命名空间**：强调「这个类只属于外部类的作用域」

**7. Builder 模式实战**
```java
public class User {
    private final String name;
    private final int    age;
    private User(Builder b) { this.name = b.name; this.age = b.age; }

    public static class Builder {
        private String name;
        private int    age;
        public Builder name(String n) { this.name = n; return this; }
        public Builder age(int a)     { this.age  = a; return this; }
        public User build()           { return new User(this); }
    }
}

// 使用
User u = new User.Builder().name("Tom").age(20).build();
```
**优势**：
- 链式调用可读性高
- 参数多时不用记参数顺序
- `User` 构造私有 → 强制通过 Builder，防止不完整对象

#### 示例演示（15 分钟)
现场敲 Outer/Inner 同名字段 3 层输出。让学生跟着改 `Outer.this.x` 的值，看 Inner 里能不能读到。

再敲 `User.Builder`，链式调用给学生看：`new User.Builder().name("Tom").age(20).build()`。

**翻车演示**：`Outer.Inner inner = new Outer.Inner();` （少了 outer.new）→ 编译报错，让学生看提示。

引导：MyLinkedList 里的 Node **不需要**外部类引用，只是纯数据 → 所以用 `static`。今天早上的选择原因，现在明白了。

#### 课堂练习（4 分钟）
1. 成员内部类为什么必须先有外部实例才能 new？（持有隐式引用）
2. 静态嵌套类能访问外部实例字段吗？（不能，只能访问 static）
3. 写 `Order.Builder` 类，支持 `id / userId / amount` 链式设置

#### 小结（3 分钟）
- 内部类是**代码组织**手段
- 成员内部类：持有外部引用，能访问 private；小心内存泄漏
- 静态嵌套类：独立，最常用；Builder 模式、内部数据结构
- 语法：`outer.new Inner()` vs `new Outer.Node(...)`

### 28.4 板书设计
```text
┌────────────────────────────────────────────┐
│  4 类内部类                                │
│    成员 (非 static)  → 持有外部引用        │
│    静态嵌套          → 独立                │
│    局部 (方法内)     → 罕见                │
│    匿名              → new 时定义          │
│                                            │
│  三级作用域：                              │
│    x / this.x / Outer.this.x               │
│                                            │
│  static class Node 用于：                  │
│    1.HashMap.Node                          │
│    2.User.Builder                          │
│    3.命名空间                              │
└────────────────────────────────────────────┘
```

### 28.5 课后作业
1. 抄写运行教材 §10.1、§10.2、§10.3 全部示例
2. 独立完成教材 §10 练习题 1：解释 `MyLinkedList` 里 Node 为什么要 static
3. 完成教材 §10 练习题 2：`User.Builder` 支持 name/age/email，build 时校验必填字段
4. 挑战：拓展题 7 —— 查阅 `HashMap.Node` 和 `HashMap.KeySet`，说明前者为什么 static、后者为什么非 static

### 28.6 教学反思提示
- MyLinkedList 里的 `static class Node` 是本节课的引子，切勿放弃这个绝佳教学时机
- Builder 模式是实用高频模式，务必让学生现场敲一遍
- 内存泄漏可以用 Android 短举例即可，不必展开

---

## 第 29 课时：局部内部类、匿名内部类与 Lambda

### 29.1 教学目标
#### 29.1.1 知识与技能目标
1. 认识局部内部类的用法与「effectively final」限制
2. 熟练使用匿名内部类，掌握 `new 类型() { ... }` 语法
3. 认识 Lambda 与匿名内部类的**语义差异**（this 指向不同）
4. 会判断某场景应该用 Lambda 还是匿名内部类

#### 29.1.2 过程与方法目标
1. 通过「Lambda 里的 this vs 匿名内部类里的 this」翻车对比，理解本质区别
2. 通过 Runnable、Comparator 等常用接口连接到明日的 Lambda 大戏

### 29.2 教学重难点
- **重点**：匿名内部类语法 / effectively final 限制 / Lambda 只能替代函数式接口
- **难点**：`this` 指向差异 —— Lambda 里 `this` 指外部类，匿名内部类里 `this` 指自身

### 29.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「上节课讲了两种命名内部类，今天讲两种不常用但很重要的：局部内部类（罕见）、匿名内部类（常见，是 Lambda 的前身）。」

#### 新知讲授（18 分钟）

**1. 局部内部类**
```java
public void run() {
    class Local {
        void hi() { System.out.println("local"); }
    }
    new Local().hi();
}
```
- 只在方法内可见
- 现代代码几乎不用，被 Lambda / 匿名类替代
- 认识即可

**2. Effectively final 限制**（板书）

局部内部类 / 匿名内部类 / Lambda 访问**方法内**局部变量时，该变量必须是 `final` 或**实际不变**：
```java
public Runnable task() {
    int x = 10;
    // x = 11;   ← 一旦重新赋值，就不是 effectively final，下面编译错误
    return () -> System.out.println(x);
}
```
**原因**：局部变量随方法栈帧消亡，编译器实际是把它复制进对象里。如果外部能改，两者会不一致。

**3. 匿名内部类**
```java
Runnable r = new Runnable() {
    @Override public void run() { System.out.println("running"); }
};
new Thread(r).start();

Comparator<Integer> desc = new Comparator<Integer>() {
    @Override public int compare(Integer a, Integer b) { return b - a; }
};
```
- `new 类型() { ... }` 同时**声明并实例化**
- 类型必须是**接口**或**抽象类**（不能 new 一个已实例化的具体类然后匿名扩展它——其实可以，是子类）
- 「只用一次」的场景

**4. Lambda vs 匿名内部类**（板书对照表）

| 项 | 匿名内部类 | Lambda |
|----|-----------|--------|
| 语法 | `new I() { ... }` | `() -> ...` |
| 接口约束 | 可以是任意接口 / 抽象类 | **必须函数式接口**（一个抽象方法） |
| `this` 指向 | 匿名类实例自身 | **外部类实例** |
| 编译产物 | 每个匿名类生成 `.class` | `invokedynamic + LambdaMetafactory`，不产生 `.class` |
| 用途 | 多方法接口、需要 `this` 指自身 | 单方法接口（Runnable / Comparator / Function 等） |

**this 翻车示例**（板书圈红）：
```java
public class Outer {
    private String name = "OuterName";
    public void demo() {
        Runnable a = new Runnable() {
            @Override public void run() {
                System.out.println(this);            // 匿名类实例
                // System.out.println(this.name);    // 编译错！Runnable 没 name
            }
        };
        Runnable b = () -> {
            System.out.println(this);                // ✅ Outer 实例
            System.out.println(this.name);           // ✅ OuterName
        };
        a.run();
        b.run();
    }
}
```
**Lambda 里没有自己的 this**——`this` 直接指向所在类实例。这是最关键的区别。

**5. 何时用哪种？**
- **函数式接口** + **不需要 this 指自身** → Lambda（更简洁）
- **多抽象方法接口**（如 `WindowListener`）→ 只能匿名类
- **需要 this 指自身**（很少见）→ 匿名类

**6. 常用函数式接口预告**
下节课（Day06）会深讲：`Runnable / Callable / Comparator / Consumer / Supplier / Function / Predicate`。

#### 示例演示（16 分钟）
现场演示匿名 Runnable / Comparator，然后逐步改成 Lambda：
```java
// Step 1: 匿名内部类
Runnable r1 = new Runnable() {
    @Override public void run() { System.out.println("running"); }
};

// Step 2: Lambda
Runnable r2 = () -> System.out.println("running");
```

**this 对比实验**：把 `Outer` 类的两种写法跑起来，让学生看输出：
```text
main.Outer$1@abcd1234        ← 匿名类
main.Outer@ef012345          ← Lambda 指向 Outer
OuterName                    ← 只有 Lambda 能拿到 name
```

**effectively final 翻车**：
```java
int x = 10;
Runnable r = () -> System.out.println(x);
x = 11;                          // ← 加这一行，上面编译错
```

#### 课堂练习（5 分钟）
1. Lambda 里的 `this` 指什么？（外部类）
2. 匿名内部类和 Lambda 谁能替代 `WindowListener`（多个方法）？（只能匿名类）
3. 什么是 effectively final？举例说明

#### 小结（3 分钟）
- 局部内部类罕见
- 匿名内部类：`new 类型() { ... }`，`this` 指自身
- Lambda：只能替代函数式接口，`this` 指外部类
- effectively final：变量不能再赋值

### 29.4 板书设计
```text
┌────────────────────────────────────────────┐
│  匿名内部类 vs Lambda                      │
│                                            │
│  匿名：new I() { ... }                     │
│    ✔ 任意接口/抽象类                       │
│    ✔ this = 自身                           │
│                                            │
│  Lambda：() -> ...                         │
│    ✔ 只限函数式接口                        │
│    ✔ this = 外部类                         │
│    ✔ invokedynamic 不生成 .class           │
│                                            │
│  effectively final：                       │
│    捕获的局部变量不能再赋值                │
└────────────────────────────────────────────┘
```

### 29.5 课后作业
1. 抄写运行教材 §10.4、§10.5 全部示例
2. 独立完成教材 §10 练习题 3：找出 Lambda 捕获变量后又改变量的编译错误，给最小修改
3. 写一段代码，同一个字段名下用匿名类 vs Lambda 对比 this 输出
4. 挑战：用匿名内部类实现 `Comparator<Student>`（先按成绩降序、再按姓名升序），然后改写为 Lambda

### 29.6 教学反思提示
- 「this 指向差异」是本节课最重要的点，让学生亲自跑一次实验
- effectively final 学生第一次听懵，用「变量复制」的解释更直观
- 匿名类是 Lambda 的历史，讲清楚才能自然过渡到 Day06

---

## 第 30 课时：接口增强 + Record + Sealed

### 30.1 教学目标
#### 30.1.1 知识与技能目标
1. 熟练使用 JDK 8+ 接口三大增强：`default` / `static` / `private` 方法
2. 掌握「钻石继承」冲突的显式解决：`A.super.method()`
3. 熟练使用 JDK 16+ `record` 语法与紧凑构造器
4. 认识 JDK 17+ `sealed` 类型 + `switch` 模式匹配

#### 30.1.2 过程与方法目标
1. 通过给已有 `List` 加 `forEach / removeIf` 的例子，理解 default 方法的价值
2. 通过 `record + sealed + switch` 三剑客的组合，感受现代 Java 的表达力

### 30.2 教学重难点
- **重点**：default 方法 / 钻石冲突解决 / record 生成的成员 / sealed 三种子类修饰
- **难点**：record 的**紧凑构造器**语法 / sealed 类型的模块 / 包约束

### 30.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「Java 8 之后接口不再是『纯抽象方法容器』，还多了 default、static、private。加上 JDK 16 稳定的 record 和 17 稳定的 sealed——现代 Java 的接口和类都进化了。今天一节课全学。」

#### 新知讲授（20 分钟）

**1. 接口三大增强**（板书）

**default 方法**：给已有接口加新方法不破坏所有实现：
```java
public interface Greeter {
    void hello();
    default void hi() {
        System.out.println("hi from default");
        hello();
    }
}
```
**用途**：`List.forEach / removeIf / sort` 都是 JDK 8 加的 default 方法——一夜之间所有实现类都得到新能力。

**static 方法**：接口里的工具函数
```java
public interface Calculator {
    static int square(int x) { return x * x; }
}
Calculator.square(5);
```
`List.of / Map.of / Stream.of` 都是接口静态方法。

**private 方法（JDK 9+）**：抽取 default 之间的公共代码
```java
public interface Logger {
    default void info(String m)  { log("INFO",  m); }
    default void warn(String m)  { log("WARN",  m); }
    default void error(String m) { log("ERROR", m); }

    private void log(String level, String m) {
        System.out.println("[" + level + "] " + m);
    }
}
```

**2. 钻石继承冲突**（板书）
```java
interface A { default String name() { return "A"; } }
interface B { default String name() { return "B"; } }

class C implements A, B {
    @Override public String name() {
        return A.super.name() + "+" + B.super.name();
    }
}
```
一个类实现两个都有相同 default 的接口 → **编译错误**，必须显式覆盖。用 `父接口.super.方法()` 指定调用哪个。

**3. 接口 vs 抽象类**（板书对比表）

| 对比 | 接口 | 抽象类 |
|------|------|--------|
| 关键字 | `interface` | `abstract class` |
| 多实现 | ✅ | ✗ 单继承 |
| 字段 | 只能 `public static final` | 任意 |
| 构造器 | 无 | 有 |
| 方法 | abstract / default / static / private | 任意 |
| 语义 | 「能做…」（横切能力） | 「是一个」（继承层次） |

**4. Record（JDK 16+ 稳定）**

不可变数据载体的语法糖：
```java
public record Point(int x, int y) { }
```

编译器自动生成：
- `private final` 字段
- 全参构造器
- 访问器 `x() / y()`（不是 `getX`）
- `equals / hashCode / toString`

用法：
```java
Point p = new Point(1, 2);
System.out.println(p.x());   // 1
System.out.println(p);       // Point[x=1, y=2]
```

**紧凑构造器**（板书）：
```java
public record Point(int x, int y) {
    public Point {
        if (x < 0 || y < 0) throw new IllegalArgumentException();
    }
    public double distance(Point o) {
        int dx = x - o.x, dy = y - o.y;
        return Math.sqrt(dx*dx + dy*dy);
    }
}
```
注意：没有 `()` 也没有 `this.x = x`——JVM 自动完成赋值，你只写校验。

**Record 限制**：
- 隐式 `final`，**不能被继承**
- 不能显式声明实例字段
- 所有组件都是 final

**5. Sealed 类（JDK 17+ 稳定）**

显式声明子类型白名单：
```java
public sealed interface Shape permits Circle, Rectangle, Triangle { }

public final     class Circle    implements Shape { public double r; }
public final     class Rectangle implements Shape { public double w, h; }
public non-sealed class Triangle implements Shape { }   // 允许被继续继承
```

**子类型必须是**：
- `final`（不能再继承）
- `sealed`（也是封闭的）
- `non-sealed`（打开）

**6. 三剑客组合**（板书王炸）
```java
public sealed interface Shape permits Circle, Rectangle { }
public record Circle(double r)              implements Shape { }
public record Rectangle(double w, double h) implements Shape { }

public static double area(Shape s) {
    return switch (s) {
        case Circle    c -> Math.PI * c.r() * c.r();
        case Rectangle r -> r.w() * r.h();
    };
}
```
**编译器知道 Shape 只有这两个子类型**——switch **无须 default、也不会漏分支**。加新子类型时忘了更新 switch → 编译报错。

这就是**代数数据类型**（ADT）在 Java 里的形态。

#### 示例演示（15 分钟)
现场演示 default 冲突翻车（不覆盖直接 `class C implements A, B` 编译错误），然后加 `A.super.name()` 修好。

Record 演示：
```java
record Point(int x, int y) {
    public Point {
        if (x < 0 || y < 0) throw new IllegalArgumentException();
    }
}
new Point(-1, 0);   // 抛异常
System.out.println(new Point(1, 2));   // Point[x=1, y=2]
```

Sealed + switch 演示：
```java
Shape s = new Circle(3);
System.out.println(area(s));   // 28.274...
```
故意注释掉 `Circle` 的 case → 编译报错「switch 未覆盖所有子类型」。这就是穷举检查。

#### 课堂练习（4 分钟）
1. 一个类同时实现两个都有相同 default 方法的接口会怎样？（编译错误，必须覆盖）
2. `record Point(int x, int y)` 有 `getX()` 方法吗？（没有，是 `x()`）
3. sealed 子类必须是哪三种修饰之一？（final / sealed / non-sealed）

#### 小结（3 分钟）
- 接口三增强：default / static / private
- 钻石冲突：`父接口.super.method()`
- Record：不可变数据载体、紧凑构造器
- Sealed：白名单子类型 + switch 穷举检查
- 三剑客组合：Java 现代化 ADT 表达

### 30.4 板书设计
```text
┌────────────────────────────────────────────┐
│  接口 3 增强：                             │
│    default / static / private              │
│  钻石冲突：A.super.name()                  │
│                                            │
│  Record：不可变数据载体                    │
│    public record Point(int x, int y) { }   │
│    自动：ctor / x() / equals / toString    │
│    紧凑构造器：public Point { 校验 }       │
│                                            │
│  Sealed：白名单子类型                      │
│    permits A, B, C                         │
│    子必 final / sealed / non-sealed        │
│                                            │
│  Sealed + Record + switch = 现代 ADT       │
└────────────────────────────────────────────┘
```

### 30.5 课后作业（本日汇总）

**必做**：
1. 完成教材 §10 全部示例代码抄写与运行
2. 独立完成教材 §10 练习题 4：定义 `Numbered` 接口 + `default int id()` 返回自增 id
3. 独立完成教材 §10 练习题 5：`record Range(int lo, int hi)` + 紧凑构造器校验 + `contains(int)` 方法
4. 独立完成教材 §10 练习题 6：`sealed interface Result<T>` + `Ok<T>` + `Err<T>` + switch 分派

**选做**：
1. 拓展题：查阅 `List.forEach` 的 default 实现源码，说说加它对 JDK 8 之前的 `List` 实现类为什么无破坏
2. 用 `sealed + record + switch` 建模一棵**表达式二叉树**：`Num / Add / Mul`，写 `eval(Expr)` 方法

### 30.6 教学反思提示
- default 方法「不破坏已有实现」是关键卖点，用 List.forEach 的例子最贴切
- record 学生第一次看紧凑构造器很懵，反复强调「没参数列表、自动赋值」
- sealed + switch 穷举检查现场演示一次「删掉 case 就报错」——威力才显现

---

## 本日总结

Day05 完成教材第 9、10 讲。学生带走的核心能力：
- **数据结构手写**：ArrayList / LinkedList / Stack / Queue / HashMap 的核心 40 行代码；容器选型速查表；LRU、Top-K
- **内部类与接口**：4 种内部类、Lambda 与匿名类的语义差异、接口 3 增强、Record 与 Sealed 的现代 ADT

明日（Day06）主题：**Lambda / Stream / Optional / 日期时间 API**，对应教材第 11、12 讲——**大结局**。请学生课后完成必做作业。
