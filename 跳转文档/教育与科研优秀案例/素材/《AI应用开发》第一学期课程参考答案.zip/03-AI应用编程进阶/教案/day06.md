# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day06（第 31-36 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Day05（数据结构手写、内部类与接口增强）的大学一年级学生
**知识点覆盖**：Lambda + 方法引用 + Stream（3 课时） + Optional + 日期时间 API（3 课时）
**参考教材**：`../教材/chapters/11.md`、`12.md`

---

## 本日知识地图

```mermaid
flowchart LR
    subgraph G1["上午 · 函数式编程"]
        direction LR
    L31["第 31 课时<br/>Lambda & 函数式接口"]
    L32["第 32 课时<br/>方法引用 & Stream 入门"]
    L33["第 33 课时<br/>Collectors & 并行流"]
    end
    subgraph G2["下午 · 空值 & 日期时间"]
        direction LR
    L34["第 34 课时<br/>Optional 空值处理"]
    L35["第 35 课时<br/>LocalDateTime & Instant"]
    L36["第 36 课时<br/>ZonedDateTime / Duration / Formatter"]
    end
    L31 --> L32 --> L33
    L34 --> L35 --> L36
    L33 -.承接.-> L34
```

> 6 个课时按「函数式编程 → 空值 & 日期时间」两大板块递进；上午打基础，下午做延伸，最后一课时做本日综合练习。

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：沿用；本讲用到 `java.util.function.*`、`Stream`、`Collectors`、`Optional`、`java.time.*` 全套 API，教师机全部预跑通。
2. **IntelliJ IDEA（下简称 IDEA） 工程**：`day06-lambda-stream-time/`，含 `lambda`（Lambda 与函数式接口）、`methodref`（方法引用四种）、`stream`（Stream 中间/终结操作）、`collectors`（groupingBy / partitioningBy / toMap）、`opt`（Optional 三 API：ofNullable/orElseGet/ifPresentOrElse）、`datetime`（LocalDate/Time/ZonedDateTime/Duration/Period/Formatter）六个包。
3. **示例数据集**：预生成 `orders.csv`（500 条订单：订单号、用户、金额、下单时间 ISO-8601 字符串），放到 `resources/`，用于 Stream 综合演示。
4. **时区演示准备**：`ZoneId.getAvailableZoneIds()` 挑 3 个地区（Asia/Shanghai、America/New_York、Europe/London）现场跨时区演示。
5. **打印讲义**：「Stream 中间/终结操作对照表」+「日期时间新旧 API 迁移表」+「Optional API 十条军规」，一人一份。

### 学情预设
- 前置：Day05 内部类 + 匿名类语法已通过——Lambda 直接讲「匿名类简化」；Day04 集合已通过——Stream 直接搭在 `List.stream()` 之上。
- 预计易混：`::new`（构造器引用）与 `::静态方法` 语法差异、`map` vs `flatMap`、`Optional.of` vs `ofNullable` 抛不抛 NPE、`Duration`（时间量）vs `Period`（日期量）。
- 预计基础差距：函数式接口概念对约 30% 学生仍抽象，第 31 课时导入必须用「传行为参数」和「策略模式对比」双例讲透。日期时间对全班都新（多数只用过 `Date`/`SimpleDateFormat`），要给足练习时间。

### 教具与板书素材
- 板书左「Lambda 三段式：参数 → 箭头 → 体」+ 简化演进（匿名类→Lambda→方法引用），中「Stream 流水线图：源 → 中间操作× n → 终结操作」，右「LocalDate/Time/DateTime/ZonedDateTime 四棵树关系」。
- 打印 A4：「四大函数式接口 Function/Consumer/Supplier/Predicate 速查」，一人一份。

### 前置检查（上课前 5 分钟完成）
- 全班 jshell 执行 `Stream.of(1,2,3).map(i -> i*2).toList()` 输出 `[2, 4, 6]`；`LocalDate.now()` 输出今天日期——两个都过才可开讲。
- `orders.csv` 拷贝到位，`Files.lines(Path.of("resources/orders.csv")).count()` 输出 500 才可用。
- 演示计算机时区正确（默认 `Asia/Shanghai`），避免时区演示时错乱。

---

## 第 31 课时：Lambda 与函数式接口

### 31.1 教学目标
#### 31.1.1 知识与技能目标
1. 掌握 Lambda 表达式 5 种写法：无参、单参、多参、显式类型、多行
2. 理解 Lambda 的目标类型 = 函数式接口（有且仅有一个抽象方法）
3. 熟练使用 JDK 5 大内置函数式接口：`Function` / `Predicate` / `Consumer` / `Supplier` / `BiFunction`
4. 掌握 `Function.andThen / compose`、`Predicate.and / or / negate` 组合运算

#### 31.1.2 过程与方法目标
1. 通过对比匿名类 → Lambda 的重构过程，感受简洁性
2. 通过组合运算把「小函数拼成大函数」的思路建立起来

### 31.2 教学重难点
- **重点**：Lambda 语法 5 种写法 / 5 大函数式接口 / andThen 与 compose 区别
- **难点**：`andThen(g)` 是先执行 self 再 g；`compose(g)` 是先 g 再 self —— 顺序容易记反

### 31.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「昨天讲了匿名内部类是 Lambda 的前身。今天正式学 Lambda——本讲和下讲是本课程的**大结局**。学完 Java 你就懂了『函数式编程』的入门体验。」

翻问：Lambda 里的 `this` 指什么？（外部类实例，昨天讲过。）

#### 新知讲授（20 分钟）

**1. 为什么需要 Lambda**（板书对比）

Java 7 写法：
```java
Collections.sort(list, new Comparator<String>() {
    @Override public int compare(String a, String b) {
        return a.length() - b.length();
    }
});
```

Java 8 Lambda：
```java
Collections.sort(list, (a, b) -> a.length() - b.length());
```

**行为像数据一样被传递**——函数式编程的核心。

**2. Lambda 5 种语法**（板书）
```java
() -> 42                        // 无参
x -> x * x                      // 单参数可省括号
(x, y) -> x + y                 // 多参数
(int x, int y) -> x + y         // 显式类型
(x, y) -> {                     // 多行需要 { } + return
    int r = x + y;
    return r;
}
```

**3. 函数式接口 = 有且仅有一个抽象方法的接口**
```java
@FunctionalInterface
public interface Operator {
    int apply(int a, int b);
}

Operator add = (a, b) -> a + b;
add.apply(2, 3);   // 5
```
`@FunctionalInterface` 让编译器**校验**「有且只有一个抽象方法」，防止后续误加。

**4. 变量捕获三条铁律**（板书圈红）
- 可访问外部**类的**字段（无限制）
- 可访问所在方法的**局部变量**，但必须 `final` 或 effectively final
- 内部**不能修改**捕获的局部变量（编译错）

**5. JDK 5 大函数式接口**（板书表格）

| 接口 | 抽象方法 | 语义 | 示例 |
|------|---------|------|------|
| `Function<T, R>` | `R apply(T t)` | T → R 转换 | 长度、大写 |
| `Predicate<T>` | `boolean test(T t)` | 判定 | 非空、正数 |
| `Consumer<T>` | `void accept(T t)` | 消费副作用 | 打印、写日志 |
| `Supplier<T>` | `T get()` | 无输入提供 | new 实例、随机数 |
| `BiFunction<T, U, R>` | `R apply(T, U)` | 二元函数 | 加法、比较 |

使用示例：
```java
Predicate<String> notEmpty = s -> s != null && !s.isEmpty();
Function<String, Integer> length = String::length;
Consumer<String> print = System.out::println;
Supplier<List<String>> newList = ArrayList::new;

if (notEmpty.test("abc")) print.accept("len = " + length.apply("abc"));
```

**6. 特化的基本类型版**：`IntFunction / IntPredicate / IntConsumer / IntSupplier / IntUnaryOperator ...`
避免装箱开销，Stream 里大量使用。

**7. 组合运算**（板书圈红）

**Function**：
```java
Function<Integer, Integer> plus1 = x -> x + 1;
Function<Integer, Integer> times2 = x -> x * 2;

Function<Integer, Integer> f = plus1.andThen(times2);   // 先 +1 后 *2 → (x + 1) * 2
Function<Integer, Integer> g = plus1.compose(times2);   // 先 *2 后 +1 → (x * 2) + 1

f.apply(3);   // 8
g.apply(3);   // 7
```

**记忆口诀**：`andThen` = 「然后」→ self 先跑；`compose` = 「组合前置」→ g 先跑。

**Predicate**：
```java
Predicate<Integer> positive = x -> x > 0;
Predicate<Integer> even = x -> x % 2 == 0;

Predicate<Integer> both = positive.and(even);
Predicate<Integer> either = positive.or(even);
Predicate<Integer> notPositive = positive.negate();
```

#### 示例演示（15 分钟）
现场把 Comparator 从匿名类改成 Lambda 逐步简化：
```java
// Step 1: 匿名类
Comparator<String> c1 = new Comparator<String>() {
    @Override public int compare(String a, String b) { return a.length() - b.length(); }
};
// Step 2: Lambda
Comparator<String> c2 = (a, b) -> a.length() - b.length();
// Step 3: 方法引用（下节讲）
Comparator<String> c3 = Comparator.comparingInt(String::length);
```

演示 5 大接口的最简用法。

**翻车实验**：捕获局部变量后修改：
```java
int x = 10;
Function<Integer, Integer> f = y -> x + y;
x = 11;   // 加这行 → 上面报错
```
学生看编译器提示。

**组合运算演示**：`plus1.andThen(times2).apply(3) == 8`；`plus1.compose(times2).apply(3) == 7`。

#### 课堂练习（4 分钟）
1. `Function<String, Integer>` 抽象方法叫什么？（apply）
2. `andThen` 和 `compose` 谁先执行 self？（andThen）
3. Lambda 内部能改捕获的局部变量吗？（不能）

#### 小结（2 分钟）
- Lambda：`(参数) -> 表达式或代码块`
- 函数式接口：只有一个抽象方法
- 5 大接口：Function / Predicate / Consumer / Supplier / BiFunction
- 组合：andThen / compose / and / or / negate

### 31.4 板书设计
```text
┌────────────────────────────────────────────┐
│  Lambda 5 种写法                           │
│    () -> 42                                │
│    x -> x*x                                │
│    (x,y) -> x+y                            │
│    (int x, int y) -> x+y                   │
│    (x,y) -> { ... return; }                │
│                                            │
│  5 大函数式接口：                          │
│    Function<T,R> .apply                    │
│    Predicate<T>  .test                     │
│    Consumer<T>   .accept                   │
│    Supplier<T>   .get                      │
│    BiFunction<T,U,R>.apply                 │
│                                            │
│  andThen: self → g                         │
│  compose: g → self                         │
└────────────────────────────────────────────┘
```

### 31.5 课后作业
1. 抄写运行教材 §11.1、§11.2 全部示例
2. 独立完成教材 §11 练习题 1：用 Lambda 把 `List<Integer>` 按绝对值升序排列
3. 独立完成教材 §11 练习题 2：`Predicate<String> notBlank` + `and / negate` 组合出「不空且长度不超过 10」的谓词
4. 挑战：定义 `Function<String, String>` 三个：`trim / upper / addExclamation`，用 `andThen` 组合出「先 trim 再大写再加感叹号」的函数

### 31.6 教学反思提示
- Lambda 语法 5 种务必让学生手写一遍
- andThen / compose 顺序易混，反复问反复答
- 组合运算是**函数式思想**的关键，别一带而过

---

## 第 32 课时：方法引用与 Stream 入门

### 32.1 教学目标
#### 32.1.1 知识与技能目标
1. 熟练使用方法引用 4 种形式：静态方法 / 特定对象实例方法 / 类的实例方法 / 构造器
2. 理解 Stream 三段式：源 → 中间操作 → 终结操作
3. 掌握 Stream 创建：`of / stream() / IntStream.range / iterate / generate`
4. 熟练使用核心中间操作：`filter / map / sorted / distinct / limit / skip`
5. 熟练使用核心终结操作：`forEach / count / collect(toList) / toList`

#### 32.1.2 过程与方法目标
1. 通过匿名类 → Lambda → 方法引用 三步重构，感受简洁性
2. 通过 filter+map+toList 组合，建立 Stream 流水线思维

### 32.2 教学重难点
- **重点**：4 种方法引用 / Stream 流水线三段式 / filter+map+toList 套路
- **难点**：类的实例方法 (`String::length`) 与特定对象实例方法 (`System.out::println`) 的语义差异

### 32.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「刚才 `System.out::println` 的写法叫**方法引用**。它是 Lambda 的语法简写。学完方法引用，我们就进入 Java 8 的杀手锏——**Stream**。」

#### 新知讲授（22 分钟）

**1. 方法引用 4 种形式**（板书表格）

| 类型 | 写法 | 等价 Lambda |
|------|------|-------------|
| 静态方法 | `Integer::parseInt` | `s -> Integer.parseInt(s)` |
| 特定对象的实例方法 | `System.out::println` | `s -> System.out.println(s)` |
| 类的实例方法 | `String::length` | `s -> s.length()` |
| 构造器 | `ArrayList::new` | `() -> new ArrayList<>()` |

**易混点**：`String::length` vs `System.out::println`
- `String::length` —— Lambda 的**第一个参数**当接收者（`s.length()`）
- `out::println` —— 接收者已固定，参数全是**方法实参**

#### 示例演示 A（3 分钟）
```java
List<String> list = List.of("apple", "banana", "kiwi");
list.stream()
    .map(String::length)                // s -> s.length()
    .forEach(System.out::println);      // len -> out.println(len)
// 5 6 4
```

**2. Stream 概念**（板书 Mermaid 流水线）

```text
Source(集合/数组/生成器)
      ↓
[中间操作] filter → map → sorted → ...     ← 惰性、返回 Stream
      ↓
[终结操作] collect / forEach / count       ← 触发执行、关闭流
```

**关键特性**：
- **懒执行**：中间操作不做事，直到终结操作触发
- **一次性**：终结后不能再用
- **不改变源集合**

**3. 创建 Stream**
```java
Stream.of(1, 2, 3);
List.of("a", "b").stream();
IntStream.range(0, 10);                     // [0, 10)
IntStream.rangeClosed(1, 100);              // [1, 100]
Stream.iterate(1, x -> x * 2).limit(5);     // 1,2,4,8,16
Stream.generate(Math::random).limit(3);
```

**4. 核心中间操作**
```java
filter(Predicate)             // 过滤
map(Function)                 // 一对一映射
flatMap(Function)             // 一对多映射并展平
distinct()                    // 去重
sorted() / sorted(Comparator) // 排序
limit(n) / skip(n)            // 分页
peek(Consumer)                // 观察（调试用）
```

**5. 核心终结操作**
```java
forEach(Consumer)
count() → long
collect(Collector) → 收集器（下节讲）
toList()                       // JDK 16+ 不可变列表
min / max(Comparator) → Optional
findFirst / findAny → Optional
anyMatch / allMatch / noneMatch(Predicate) → boolean
reduce(identity, BinaryOperator) → T
```

**6. 常用套路：过滤 + 映射 + 收集**
```java
List<String> names = List.of("Tom", "Jerry", "Alice", "Bob");
List<String> longUpper = names.stream()
    .filter(n -> n.length() >= 4)
    .map(String::toUpperCase)
    .sorted()
    .toList();
// [ALICE, JERRY]
```

**7. IntStream / LongStream / DoubleStream**：避免装箱
```java
int sum = names.stream().mapToInt(String::length).sum();
double avg = names.stream().mapToInt(String::length).average().orElse(0);
```

#### 示例演示 B（15 分钟）

现场敲 filter + map + collect：
```java
List<Integer> nums = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
List<Integer> squaresOfEven = nums.stream()
    .filter(n -> n % 2 == 0)          // 偶数
    .map(n -> n * n)                  // 平方
    .toList();
// [4, 16, 36, 64, 100]
```

**懒执行演示**（板书圈红）：
```java
Stream<Integer> s = nums.stream()
    .peek(n -> System.out.println("filter: " + n))
    .filter(n -> n > 3)
    .peek(n -> System.out.println("map: " + n))
    .map(n -> n * n);
// 这时什么都没打印！
System.out.println(s.count());
// 打印会一个个出现，证明是流水线
```

**一次性**翻车：
```java
Stream<Integer> s = nums.stream();
s.count();       // 已终结
s.count();       // IllegalStateException！stream has already been operated upon or closed
```

`IntStream.rangeClosed(1, 100).sum()` → 5050 秒懂。

#### 课堂练习（5 分钟）
1. 写出 `x -> x.trim()` 的方法引用形式（`String::trim`）
2. `Stream.count()` 是中间还是终结操作？（终结）
3. `Stream` 能被终结多少次？（一次）

#### 小结（3 分钟）
- 方法引用 4 种：静态 / 特定对象 / 类实例 / 构造器
- Stream 三段式：源 → 中间 → 终结
- 常用中间：filter / map / sorted / limit / skip / distinct
- 常用终结：forEach / count / collect / toList
- 懒执行 + 一次性

### 32.4 板书设计
```text
┌────────────────────────────────────────────┐
│  方法引用 4 种                             │
│    静态：Integer::parseInt                 │
│    特定对象：System.out::println           │
│    类实例：String::length (首参当接收者)   │
│    构造器：ArrayList::new                  │
│                                            │
│  Stream 流水线                             │
│    Source → filter → map → sorted → collect│
│    懒执行 + 一次性 + 不改源                │
│                                            │
│  常用套路：                                │
│    list.stream()                           │
│      .filter(...)                          │
│      .map(...)                             │
│      .toList()                             │
└────────────────────────────────────────────┘
```

### 32.5 课后作业
1. 抄写运行教材 §11.3、§11.4.1 – §11.4.3 全部示例
2. 独立完成教材 §11 练习题 3：`String[] arr` 用 Stream 得到「去重、按字典序、前 5 个大写形式」
3. 独立完成教材 §11 练习题 6：`IntStream.rangeClosed(1, 100)` 计算 1..100 中能被 3 或 5 整除的数字之和
4. 挑战：把上一课 `topK` 函数改成 Stream 一行版

### 32.6 教学反思提示
- 方法引用「类实例方法」学生总懵，用「首参当接收者」记忆
- 懒执行必须现场演示 peek 顺序，否则学生不信
- 一次性翻车要真报错一次

---

## 第 33 课时：Stream 进阶——Collectors 与并行流

### 33.1 教学目标
#### 33.1.1 知识与技能目标
1. 熟练使用 `Collectors`：`toList / toSet / toMap / joining / groupingBy / counting / averagingXxx`
2. 掌握 `flatMap` 展平嵌套结构
3. 掌握 `reduce` 归约（含 identity 与二元操作）
4. 认识并行 Stream 的适用场景与常见陷阱

#### 33.1.2 过程与方法目标
1. 通过日志统计案例把 Collectors 完整用一遍
2. 通过并行 Stream 副作用翻车实验，理解「无状态」要求

### 33.2 教学重难点
- **重点**：`groupingBy` 与 `counting / averaging` 的下游收集器组合 / `joining` 三参数
- **难点**：`toMap` 遇到重复 key 的合并函数 / 并行 Stream 的无状态要求

### 33.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「上节课学了 Stream 骨架，今天补上最重要的收集器——`Collectors`。它决定 Stream 的输出形状。学完这个，你就能用 5 行代码干过去 30 行的 SQL 分组统计。」

#### 新知讲授（20 分钟）

**1. Collectors 家族**（板书表格）

| 方法 | 输出 | 例子 |
|------|------|------|
| `toList()` / `Collectors.toList()` | `List<T>` | 收集为列表 |
| `toSet()` | `Set<T>` | 收集为集合 |
| `toMap(kFn, vFn)` | `Map<K, V>` | key/value 映射 |
| `joining(sep)` | `String` | 字符串拼接 |
| `groupingBy(kFn)` | `Map<K, List<T>>` | 分组 |
| `groupingBy(kFn, downstream)` | `Map<K, ?>` | 分组 + 下游收集 |
| `counting()` | `Long` | 计数（下游用） |
| `averagingDouble` / `Int` / `Long` | `Double` | 求平均 |
| `summingInt` / `Long` / `Double` | 总和 |
| `partitioningBy(pred)` | `Map<Boolean, List<T>>` | 按谓词二分 |

**2. toList / toSet 基础**
```java
List<String> names = List.of("Tom", "Jerry", "Alice", "Bob");
List<String> l = names.stream().toList();                       // 不可变
Set<String>  s = names.stream().collect(Collectors.toSet());
```

**3. toMap 与冲突**（板书圈红）
```java
Map<String, Integer> m = names.stream()
    .collect(Collectors.toMap(n -> n, String::length));
// {Tom=3, Jerry=5, Alice=5, Bob=3}

// 若有重复 key → IllegalStateException！必须提供合并函数：
Map<Integer, String> m2 = names.stream()
    .collect(Collectors.toMap(
        String::length,
        n -> n,
        (a, b) -> a + "," + b));    // 长度相同的名字拼起来
// {3=Tom,Bob, 5=Jerry,Alice}
```

**4. joining 三态**
```java
names.stream().collect(Collectors.joining());              // TomJerryAliceBob
names.stream().collect(Collectors.joining(","));           // Tom,Jerry,Alice,Bob
names.stream().collect(Collectors.joining(", ", "[", "]"));  // [Tom, Jerry, Alice, Bob]
```

**5. groupingBy 与下游收集器**
```java
Map<Integer, List<String>> byLen = names.stream()
    .collect(Collectors.groupingBy(String::length));
// {3=[Tom, Bob], 5=[Jerry, Alice]}

Map<Integer, Long> cnt = names.stream()
    .collect(Collectors.groupingBy(String::length, Collectors.counting()));
// {3=2, 5=2}

Map<Integer, String> joined = names.stream()
    .collect(Collectors.groupingBy(String::length,
                                   Collectors.joining(",")));
// {3=Tom,Bob, 5=Jerry,Alice}
```

**6. flatMap 展平**
```java
List<List<Integer>> nested = List.of(List.of(1, 2), List.of(3, 4), List.of(5));
List<Integer> flat = nested.stream()
    .flatMap(List::stream)
    .toList();
// [1, 2, 3, 4, 5]

// 拆词
List<String> lines = List.of("hello world", "hi java");
List<String> words = lines.stream()
    .flatMap(l -> Arrays.stream(l.split(" ")))
    .toList();
// [hello, world, hi, java]
```

**7. reduce 归约**
```java
int sum = List.of(1, 2, 3, 4).stream().reduce(0, Integer::sum);        // 10
Optional<Integer> max = List.of(3, 1, 4).stream().reduce(Integer::max);
```
`identity` 是初始值 + 空 Stream 的返回值。

**8. 并行 Stream**（板书圈红）
```java
long count = list.parallelStream()
                 .filter(x -> x.length() >= 3)
                 .count();
```
底层：`ForkJoinPool.commonPool()`。

**适用条件**：
- 数据量大 + 每元素处理耗时
- 无状态、无副作用、可分割

**别用的场景**：
- 小数据集
- 有共享可变状态
- 顺序敏感操作（`findFirst`）
- 阻塞 IO

**常见坑**：
```java
// ❌ ArrayList 非线程安全
List<Integer> r = new ArrayList<>();
list.parallelStream().forEach(r::add);
// ✅
List<Integer> r = list.parallelStream().toList();
```

#### 示例演示（16 分钟）
现场跑教材完整案例——**日志统计**：
```java
record Log(String user, String action) { }

List<Log> logs = List.of(
    new Log("alice", "login"),
    new Log("bob",   "login"),
    new Log("alice", "buy"),
    new Log("alice", "login"),
    new Log("carol", "login")
);

List<Map.Entry<String, Long>> top3 = logs.stream()
    .filter(l -> l.action().equals("login"))
    .collect(Collectors.groupingBy(Log::user, Collectors.counting()))
    .entrySet().stream()
    .sorted(Map.Entry.<String, Long>comparingByValue().reversed())
    .limit(3)
    .toList();

top3.forEach(e -> System.out.println(e.getKey() + " -> " + e.getValue()));
// alice -> 2
// bob -> 1
// carol -> 1
```
学生跟着一步步分析：filter → groupingBy → entrySet → sorted → limit。

**flatMap 演示**：`[[1,2],[3,4],[5]]` → `[1,2,3,4,5]` 现场跑一次。

**并行 Stream 翻车**：
```java
List<Integer> r = new ArrayList<>();
IntStream.rangeClosed(1, 100).parallel().forEach(r::add);
System.out.println(r.size());   // 可能不是 100！
```
学生看到不确定结果，秒懂「副作用不安全」。

**性能对比**：小数据集串行更快，大数据集并行才有收益（可以现场用 `System.nanoTime` 测一下 100 万元素 filter/count）。

#### 课堂练习（4 分钟）
1. `toMap` 遇到重复 key 会怎样？（抛异常，除非给合并函数）
2. `groupingBy(String::length, counting())` 输出类型？（`Map<Integer, Long>`）
3. 并行 Stream 底层用哪个线程池？（`ForkJoinPool.commonPool`）

#### 小结（2 分钟）
- Collectors：toList / toSet / toMap / joining / groupingBy / counting
- flatMap 展平嵌套结构
- reduce 归约
- 并行 Stream 只在「大数据 + 无状态」时用，别乱用

### 33.4 板书设计
```text
┌────────────────────────────────────────────┐
│  Collectors 家族                           │
│    toList / toSet                          │
│    toMap(k, v[, merger])                   │
│    joining(sep [, pre, suf])               │
│    groupingBy(k [, downstream])            │
│    counting / averaging / summing          │
│    partitioningBy(pred)                    │
│                                            │
│  flatMap：Stream<Stream<T>> → Stream<T>    │
│                                            │
│  parallelStream()                          │
│    ✔ 大数据 + 无状态 + 可分割              │
│    ✗ 小数据 / 副作用 / findFirst / IO      │
└────────────────────────────────────────────┘
```

### 33.5 课后作业（本日上半汇总）
1. 完成教材 §11 全部示例代码抄写与运行
2. 独立完成教材 §11 剩余练习题（1-8）
3. 综合题：给 `List<Employee>`（含 `dept, salary`），用 `groupingBy + averagingDouble` 计算各部门平均工资
4. 挑战：给 markdown 文本用 Stream 提取所有一级标题（`# xxx`），按出现顺序返回

### 33.6 教学反思提示
- Collectors.groupingBy 组合下游收集器是本节最实用点，多举例
- 并行 Stream 副作用翻车必须现场跑，让学生看到「不同次执行结果不同」的震撼
- 日志统计案例是集大成，务必让学生一步步跟着推

---

## 第 34 课时：Optional 与空值处理

### 34.1 教学目标
#### 34.1.1 知识与技能目标
1. 认识 `null` 之痛（NPE），理解 Optional 的价值
2. 熟练使用 Optional 创建：`of / ofNullable / empty`
3. 熟练使用 Optional 取值：`orElse / orElseGet / orElseThrow`
4. 熟练使用 Optional 函数式：`ifPresent / map / filter / flatMap`
5. 掌握 Optional 使用规范：适合作返回值，不适合作字段/参数

#### 34.1.2 过程与方法目标
1. 通过「null 判空 vs Optional 链式」对比，感受表达力提升
2. 通过 `orElse` vs `orElseGet` 性能测试，把「昂贵默认值」的坑刻死

### 34.2 教学重难点
- **重点**：`ofNullable` / `orElseGet` / `map + flatMap` / 使用规范
- **难点**：`orElse` 参数**总是被求值** —— 昂贵默认值必须用 `orElseGet(Supplier)`

### 34.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「Java 里的经典报错是什么？NullPointerException！Java 8 给了我们一个显式容器：Optional。它把『可能为 null』写进类型，让调用方无处遁形。」

翻车代码：
```java
User u = userService.findById(1);
String upper = u.getName().toUpperCase();   // NPE？
```
如果返回 `Optional<User>`，调用方就必须处理「找不到」的分支。

#### 新知讲授（20 分钟）

**1. 创建 Optional**（板书）
```java
Optional<String> a = Optional.of("abc");         // 非空，null 会 NPE
Optional<String> b = Optional.ofNullable(null);  // 允许 null → empty
Optional<String> c = Optional.empty();
```
**规则**：来源明确非空 → `of`；可能为 null → `ofNullable`。

**2. 判空与取值**
```java
opt.isPresent();          // true 表示有值
opt.isEmpty();            // JDK 11+
opt.get();                // ⚠️ 空则抛，尽量别用
opt.orElse("default");
opt.orElseGet(() -> compute());
opt.orElseThrow();
opt.orElseThrow(() -> new BizException("miss"));
```

**3. orElse vs orElseGet**（板书圈红——重点坑）
```java
User u1 = opt.orElse(expensiveFetch());     // ← expensiveFetch 一定被调用！
User u2 = opt.orElseGet(() -> expensiveFetch());   // ← 只在空时调用
```
**规则**：昂贵默认值必须用 `orElseGet`。

**4. 函数式操作**
```java
opt.ifPresent(v -> System.out.println(v));
opt.ifPresentOrElse(v -> ..., () -> ...);    // JDK 9+

Optional<Integer> len = opt.map(String::length);
Optional<Character> first = opt.filter(s -> !s.isEmpty()).map(s -> s.charAt(0));

Optional<User> chief = user.flatMap(User::supervisor);   // supervisor 返回 Optional<User>
```

**规律**：
- `map`：值存在 → 映射；空 → 保持空
- `filter`：不满足条件 → 转空
- `flatMap`：映射函数**本身**返回 Optional → 避免嵌套 `Optional<Optional<...>>`

**5. 使用规范**（板书圈红）

**✅ 推荐**：
- 方法**返回值**：告诉调用方「可能没有」
- 局部处理链：`findUser(id).map(...).orElse(...)`

**❌ 不推荐**：
- 类的**字段**：不 Serializable，也没设计成字段容器
- 方法**参数**：不如直接判 null
- Map 的 value：Map 本身有 `getOrDefault / computeIfAbsent`
- 集合返回值：直接返回空集合更好，不要 `Optional<List<>>`

**6. 冗余的错误写法**（板书圈红）
```java
// ❌ 冗余
if (opt.isPresent()) return opt.get();
else                 return default;

// ✅ 一行
return opt.orElse(default);
```

**7. 与 Stream 混用**（JDK 9+）
```java
Optional<User> u = Optional.of(user);
u.stream().flatMap(User::orders).forEach(System.out::println);
```

#### 示例演示（15 分钟)

完整链式演示：
```java
public Optional<User> findUser(int id) { ... }

// 传统写法
User u = findUser(1);
String mail = "no@mail";
if (u != null) {
    String m = u.getEmail();
    if (m != null) mail = m.toLowerCase();
}

// Optional 链
String mail2 = findUser(1)
    .map(User::getEmail)
    .map(String::toLowerCase)
    .orElse("no@mail");
```
学生看到「从 6 行→1 行」的对比。

**orElse vs orElseGet 性能翻车**：
```java
Supplier<String> expensive = () -> { System.out.println("expensive called"); return "expensive!"; };

Optional<String> opt = Optional.of("value");
opt.orElse(expensive.get());        // 打印！expensive called
opt.orElseGet(expensive);           // 不打印
```
学生秒懂：`orElse` 里的 `expensive.get()` **参数求值**总是先发生。

**flatMap 演示**：
```java
class Person {
    Optional<Person> boss;
    Optional<Person> boss() { return boss; }
}

Optional.of(person)
    .flatMap(Person::boss)        // 若用 map，得到 Optional<Optional<Person>>
    .flatMap(Person::boss)        // 老板的老板
    .ifPresent(p -> System.out.println(p));
```

#### 课堂练习（4 分钟）
1. 来源明确非空用哪个方法？（`Optional.of`）
2. `orElse` 参数昂贵怎么办？（改用 `orElseGet`）
3. Optional 适合作字段吗？（不适合）

#### 小结（3 分钟）
- Optional 让「可能为空」进入类型系统
- 创建三态：of / ofNullable / empty
- 取值：orElse / orElseGet / orElseThrow
- 链式：map / filter / flatMap / ifPresent
- 用作返回值最合适，不作字段/参数

### 34.4 板书设计
```text
┌────────────────────────────────────────────┐
│  创建：                                    │
│    Optional.of(x)         明确非空         │
│    Optional.ofNullable(x) 可能 null        │
│    Optional.empty()                        │
│                                            │
│  取值：                                    │
│    orElse(v)      ← 参数总求值             │
│    orElseGet(sup) ← 空时才求值             │
│    orElseThrow    ← 空时抛                 │
│                                            │
│  链式：map / filter / flatMap / ifPresent  │
│                                            │
│  规范：                                    │
│    ✔ 方法返回值                            │
│    ✗ 字段 / 参数 / Map value / 集合返回值  │
└────────────────────────────────────────────┘
```

### 34.5 课后作业
1. 抄写运行教材 §12.1 全部示例
2. 独立完成教材 §12 练习题 1：`Optional<User> findUser(int id)` + 链式取邮箱小写
3. 独立完成教材 §12 练习题 2：`orElse` vs `orElseGet` 性能验证代码

### 34.6 教学反思提示
- orElse 参数总求值的翻车必须演示，学生实际项目里踩这坑的最多
- Optional 用作字段导致反序列化问题的实际案例可以举一个 Jackson 的例子
- 强调「Optional 不是 null 的完全替代」，只是「返回值层面」的语义增强

---

## 第 35 课时：日期时间 API 上——LocalDate/Time/DateTime 与 Instant

### 35.1 教学目标
#### 35.1.1 知识与技能目标
1. 认识老版 `Date/Calendar/SimpleDateFormat` 的三大缺陷
2. 熟练使用 `LocalDate/LocalTime/LocalDateTime` 的创建、读字段、修改、比较
3. 掌握 `Instant` 时间戳与 UTC 时刻的概念
4. 认识 `LocalDateTime` vs `Instant` 的语义差异

#### 35.1.2 过程与方法目标
1. 通过老版 `SimpleDateFormat` 多线程翻车实验，让学生认可换新
2. 通过 `Month` 从 1 开始的对比，让学生记住老版从 0 开始的坑

### 35.2 教学重难点
- **重点**：LocalDate/DateTime 常用 API / `plus/minus/with` 返回新对象 / Instant 是 UTC 时刻
- **难点**：`LocalDateTime` 无时区，跨时区比较需要先转 `Instant` 或 `ZonedDateTime`

### 35.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「Java 里最招骂的 API 之一是老版日期时间——`Date`、`Calendar`、`SimpleDateFormat`。Java 8 才彻底重构。今天学新版，一劳永逸。」

翻车 3 连（板书）：
1. `new Date(2025, 3, 14)` —— 年份从 1900 起、月份从 0 起，得到的其实是 3925 年 4 月
2. `SimpleDateFormat` 多线程共用 → `NumberFormatException` 或错乱结果
3. `Calendar` API 又臭又长

Java 8 引入 `java.time`（参考 Joda-Time）：**不可变、线程安全、类型清晰**。

#### 新知讲授（20 分钟）

**1. 新版 API 全家福**（板书）
```text
LocalDate       只有日期（年月日）
LocalTime       只有时间（时分秒）
LocalDateTime   日期+时间（无时区）
Instant         UTC 时间戳（机器视角）
ZonedDateTime   带时区（下节讲）
Duration        时间量（秒/纳秒）
Period          日期量（年/月/日）
```

**核心特点**：
- **不可变**、**线程安全**
- Month 从 1 开始（不再是 0）
- 类型区分清晰

**2. 创建**
```java
LocalDate today = LocalDate.now();
LocalDate d1 = LocalDate.of(2025, 3, 14);
LocalDate d2 = LocalDate.of(2025, Month.MARCH, 14);
LocalDate d3 = LocalDate.parse("2025-03-14");       // ISO 格式

LocalTime nowT = LocalTime.now();
LocalTime t = LocalTime.of(10, 30, 45);

LocalDateTime dt = LocalDateTime.now();
LocalDateTime dt2 = LocalDateTime.of(2025, 3, 14, 10, 30);
```

**3. 读字段**
```java
LocalDate d = LocalDate.of(2025, 3, 14);
d.getYear();         // 2025
d.getMonth();        // MARCH
d.getMonthValue();   // 3
d.getDayOfMonth();   // 14
d.getDayOfWeek();    // FRIDAY
d.getDayOfYear();    // 73
d.lengthOfMonth();   // 31
d.isLeapYear();      // false
```

**4. 修改（返回新对象，不改原对象）**（板书圈红）
```java
LocalDate d = LocalDate.of(2025, 3, 14);

LocalDate d1 = d.withYear(2026);            // 2026-03-14
LocalDate d2 = d.withDayOfMonth(1);
LocalDate d3 = d.plusDays(10);
LocalDate d4 = d.plusMonths(1).minusDays(2);
LocalDate d5 = d.plusYears(1);

// Adjuster 语义化修改
LocalDate lastDay = d.with(TemporalAdjusters.lastDayOfMonth());
LocalDate nextMon = d.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
```
**记住**：**java.time 对象不可变**。`plus/minus/with` 都返回新实例，原对象没变。

**5. 比较**
```java
LocalDate a = LocalDate.of(2025, 3, 14);
LocalDate b = LocalDate.of(2025, 4, 1);
a.isBefore(b);    // true
a.isAfter(b);     // false
a.equals(b);      // false
a.compareTo(b);   // < 0
```

**6. Instant 时间戳**
```java
Instant now = Instant.now();
long millis = now.toEpochMilli();
long seconds = now.getEpochSecond();
Instant fromMillis = Instant.ofEpochMilli(1_700_000_000_000L);
```

**Instant vs LocalDateTime**（板书圈红）
| | Instant | LocalDateTime |
|---|---------|---------------|
| 语义 | 时间线上的一个点 | 墙上的日期时间 |
| 时区 | 本质 UTC | **无时区** |
| 用途 | 数据库时间戳、日志 | 用户看到的日期时间 |
| 比较 | 全球统一 | 不含时区不能跨区比较 |

**7. Instant ↔ LocalDateTime**
```java
Instant now = Instant.now();
LocalDateTime ldt = LocalDateTime.ofInstant(now, ZoneId.systemDefault());
Instant back = ldt.atZone(ZoneId.systemDefault()).toInstant();
```
**必须给 ZoneId**——LocalDateTime 不知道自己在哪个时区。

#### 示例演示（15 分钟）

现场翻车老版：
```java
Date d = new Date(2025, 3, 14);   // deprecated
System.out.println(d);            // 输出 3925 年 4 月，学生震惊
```

新版正常：
```java
LocalDate d = LocalDate.of(2025, 3, 14);
System.out.println(d);   // 2025-03-14
```

`SimpleDateFormat` 多线程翻车（可以选做，时间紧就口述）：
```java
SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
Runnable r = () -> {
    try { sdf.parse("2025-03-14"); } catch (Exception e) { e.printStackTrace(); }
};
for (int i = 0; i < 20; i++) new Thread(r).start();
// 出现 NumberFormatException 或 ArrayIndexOutOfBoundsException
```
`DateTimeFormatter` 是不可变、线程安全的替代品（下节讲）。

**不可变性演示**：
```java
LocalDate d = LocalDate.of(2025, 3, 14);
d.plusDays(10);                     // 返回值没接住
System.out.println(d);              // 依然 2025-03-14 —— d 没变！

d = d.plusDays(10);                 // 必须重新赋值
System.out.println(d);              // 2025-03-24
```
学生秒懂「不可变」的意思。

**Adjuster 演示**：
```java
LocalDate d = LocalDate.of(2025, 3, 14);
System.out.println(d.with(TemporalAdjusters.lastDayOfMonth()));    // 2025-03-31
System.out.println(d.with(TemporalAdjusters.firstDayOfNextMonth())); // 2025-04-01
System.out.println(d.with(TemporalAdjusters.next(DayOfWeek.MONDAY))); // 2025-03-17
```

**Instant 演示**：
```java
Instant now = Instant.now();
System.out.println(now);            // 2025-03-14T02:30:00Z（Z 表示 UTC）
System.out.println(now.toEpochMilli());
```

#### 课堂练习（4 分钟）
1. `LocalDate.of(2025, 3, 14).plusDays(10)` 之后 d 变了吗？（没变，需要重新赋值）
2. `Month.MARCH` 对应数字几？（3，不再是老版的 2）
3. `Instant` 有时区吗？（本质 UTC 时刻，没有本地时区概念）

#### 小结（2 分钟）
- 新版三大优点：不可变、线程安全、类型清晰
- LocalDate / LocalTime / LocalDateTime 组合日期时间
- plus/minus/with 都返回新对象——**要接住返回值**
- Instant = UTC 时间戳，机器视角

### 35.4 板书设计
```text
┌────────────────────────────────────────────┐
│  java.time 家族                            │
│    LocalDate      日期                     │
│    LocalTime      时间                     │
│    LocalDateTime  日期+时间（无时区）      │
│    Instant        UTC 时间戳               │
│    ZonedDateTime  带时区                   │
│    Duration       时间量                   │
│    Period         日期量                   │
│                                            │
│  不可变：plus/minus/with 返新对象          │
│                                            │
│  Instant vs LocalDateTime                  │
│    Instant → 全球统一（UTC）               │
│    LocalDateTime → 墙上时间，无时区        │
└────────────────────────────────────────────┘
```

### 35.5 课后作业
1. 抄写运行教材 §12.2、§12.3、§12.4 全部示例
2. 独立完成教材 §12 练习题 3：计算某人到 60 岁还有多少年零多少个月
3. 独立完成教材 §12 练习题 4：输入 `yyyy-MM-dd` 输出星期几
4. 挑战：用 `TemporalAdjusters` 找出下一个「本月最后一个星期五」

### 35.6 教学反思提示
- 老版翻车 `new Date(2025, 3, 14)` 输出 3925 年一定要跑，学生笑完就记住了
- 不可变性演示 `d.plusDays(10)` 不接返回值是最经典的翻车
- Instant vs LocalDateTime 的语义差异要用「照片的时刻 vs 墙钟」类比

---

## 第 36 课时：日期时间 API 下——ZonedDateTime / Duration / Period / Formatter

### 36.1 教学目标
#### 36.1.1 知识与技能目标
1. 熟练使用 `ZonedDateTime` 与 `ZoneId` 做时区转换
2. 掌握 `Duration` 与 `Period` 的适用场景
3. 熟练使用 `DateTimeFormatter` 做字符串互转
4. 记住 pattern 大写 M 是月份、小写 m 是分钟
5. 会做老版 `Date` ↔ 新版 `Instant` 的互转迁移

#### 36.1.2 过程与方法目标
1. 通过「北京发帖，纽约看到」实例把时区转换讲透
2. 通过 age / 打卡时长 / 生日提醒器等小案例综合应用

### 36.2 教学重难点
- **重点**：`withZoneSameInstant` 时区转换 / `Duration` 与 `Period` 区分 / pattern 大小写 M
- **难点**：`ZonedDateTime` 与 `Instant` 区别（前者带时区标签、后者纯 UTC 时刻）

### 36.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天的日期没时区，今天补上——真实系统里的日期时间几乎总带时区。加上格式化、时间差计算，构成日期 API 的完整拼图。这也是本课程最后一节。」

#### 新知讲授（20 分钟）

**1. 时区类**（板书）
```text
ZoneId         时区名，如 Asia/Shanghai
ZoneOffset     偏移量，如 +08:00
ZonedDateTime  带时区的日期时间
OffsetDateTime 带偏移量（不含夏令时逻辑）
```

**2. ZonedDateTime 基础**
```java
ZoneId shanghai = ZoneId.of("Asia/Shanghai");
ZoneId newyork  = ZoneId.of("America/New_York");

ZonedDateTime zdt = ZonedDateTime.now(shanghai);
ZonedDateTime zdt2 = ZonedDateTime.of(2025, 3, 14, 10, 30, 0, 0, shanghai);

// 时区转换：同一时刻在不同时区的墙上时间
ZonedDateTime nyTime = zdt.withZoneSameInstant(newyork);
```

**记住**：`withZoneSameInstant` 保持**时刻不变**，改变**显示时区**——就像时钟从北京挪到纽约。

**3. Instant ↔ LocalDateTime ↔ ZonedDateTime**（板书图）
```text
Instant  (UTC 时刻)
   ↑ ↓ (需 ZoneId)
LocalDateTime (墙上时间)
   ↑ ↓ (atZone / .toLocalDateTime)
ZonedDateTime (带时区)
```

```java
Instant now = Instant.now();
LocalDateTime ldt = LocalDateTime.ofInstant(now, ZoneId.systemDefault());
ZonedDateTime zdt = ldt.atZone(ZoneId.systemDefault());
Instant back = zdt.toInstant();
```

**4. Duration 与 Period**（板书对比表）

| | Duration | Period |
|---|---------|--------|
| 基于 | 时间（秒 / 纳秒） | 日期（年 / 月 / 日） |
| 适用 | LocalTime / LocalDateTime / Instant | LocalDate |
| 单位 | seconds / millis / hours | years / months / days |

```java
Duration d = Duration.between(t1, t2);
long seconds = d.getSeconds();
long millis = d.toMillis();
long hours = d.toHours();

Period p = Period.between(startDate, endDate);
int years = p.getYears();
int months = p.getMonths();
int days = p.getDays();
```

**年龄计算**：
```java
LocalDate birth = LocalDate.of(2000, 5, 20);
LocalDate today = LocalDate.now();
Period age = Period.between(birth, today);
System.out.printf("年龄：%d 岁 %d 个月%n", age.getYears(), age.getMonths());
```

**5. DateTimeFormatter**（板书圈红）

预定义：
```java
LocalDate d = LocalDate.now();
d.format(DateTimeFormatter.ISO_LOCAL_DATE);   // 2025-03-14

LocalDateTime dt = LocalDateTime.now();
dt.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
```

自定义 pattern：
```java
DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
LocalDateTime now = LocalDateTime.now();
String s = now.format(fmt);
LocalDateTime parsed = LocalDateTime.parse("2025-03-14 10:30:00", fmt);
```

**pattern 字符表**（板书圈红）：

| 字符 | 含义 |
|------|------|
| `yyyy` | 4 位年 |
| **`MM`** | 月（**大写 M**！） |
| `dd` | 日 |
| `HH` | 24 小时制 |
| `hh` | 12 小时制 |
| **`mm`** | **分钟**（小写！） |
| `ss` | 秒 |
| `SSS` | 毫秒 |
| `E` | 星期缩写 |
| `a` | AM/PM |
| `z / Z / X` | 时区名 / 偏移 / ISO 偏移 |

**⚠️ 最经典坑**：`mm` 是分钟、`MM` 是月份。别写反！

本地化：
```java
DateTimeFormatter zh = DateTimeFormatter.ofPattern("yyyy年M月d日 EEEE", Locale.CHINESE);
System.out.println(LocalDate.now().format(zh));   // 2025年3月14日 星期五
```

**6. 老版迁移指南**

| 旧 | 新 |
|----|-----|
| `new Date()` | `Instant.now()` 或 `LocalDateTime.now()` |
| `Calendar.getInstance()` | `LocalDateTime.now()` |
| `SimpleDateFormat.parse` | `LocalDate.parse(s, fmt)` |
| Date ↔ Instant | `Date.from(instant)` / `date.toInstant()` |

#### 示例演示（16 分钟）

**跨时区演示**（教材经典例子）：
```java
DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm z");
ZonedDateTime shanghai = ZonedDateTime.of(2025, 3, 14, 22, 0, 0, 0, ZoneId.of("Asia/Shanghai"));
ZonedDateTime newyork = shanghai.withZoneSameInstant(ZoneId.of("America/New_York"));

System.out.println(shanghai.format(fmt));   // 2025-03-14 22:00 CST
System.out.println(newyork.format(fmt));    // 2025-03-14 10:00 EDT
```
「北京 3 月 14 号晚上 10 点发的帖子，纽约用户看到是同一天早上 10 点。」学生秒懂。

**打卡时长**：
```java
LocalDateTime in  = LocalDateTime.of(2025, 3, 14, 9, 0);
LocalDateTime out = LocalDateTime.of(2025, 3, 14, 18, 30);
Duration work = Duration.between(in, out);
System.out.printf("上班 %d 小时 %d 分钟%n",
    work.toHours(), work.toMinutesPart());   // 9 小时 30 分钟
```

**判断周末**：
```java
public static boolean isWeekend(LocalDate d) {
    DayOfWeek w = d.getDayOfWeek();
    return w == DayOfWeek.SATURDAY || w == DayOfWeek.SUNDAY;
}
```

**打印本周一到周日**：
```java
LocalDate today = LocalDate.now();
LocalDate monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
for (int i = 0; i < 7; i++) {
    LocalDate d = monday.plusDays(i);
    System.out.println(d + " " + d.getDayOfWeek());
}
```

**pattern 大小写翻车**：
```java
LocalDateTime now = LocalDateTime.of(2025, 3, 14, 10, 30, 0);
DateTimeFormatter wrong = DateTimeFormatter.ofPattern("yyyy-mm-dd HH:MM:ss");
System.out.println(now.format(wrong));   // 2025-30-14 10:03:00 ← 错乱！
DateTimeFormatter right = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
System.out.println(now.format(right));   // 2025-03-14 10:30:00
```

**Date 与 Instant 互转**（老代码迁移）：
```java
Date old = new Date();
Instant inst = old.toInstant();
Date back = Date.from(inst);
```

#### 课堂练习（4 分钟）
1. `withZoneSameInstant` 改变时刻还是显示时区？（只改显示时区，时刻不变）
2. 计算「今天到明年生日还差多少天」用 Duration 还是 Period？（Period 或 ChronoUnit.DAYS）
3. `"mm"` 表示什么？（分钟。月份是大写 `MM`）

#### 小结（3 分钟）
- ZonedDateTime = 时刻 + 时区标签，`withZoneSameInstant` 跨时区显示
- Duration = 时间量，Period = 日期量
- DateTimeFormatter 线程安全、不可变，替代 SimpleDateFormat
- Pattern 大写 M 是月份、小写 m 是分钟
- 老版逐步迁移，Date ↔ Instant 互转

### 36.4 板书设计
```text
┌────────────────────────────────────────────┐
│  时区                                      │
│    ZoneId.of("Asia/Shanghai")              │
│    ZonedDateTime = LocalDateTime + ZoneId  │
│    withZoneSameInstant → 换显示时区        │
│                                            │
│  Duration (时间量) vs Period (日期量)      │
│    Duration.between(t1, t2)                │
│    Period.between(d1, d2)                  │
│                                            │
│  DateTimeFormatter                         │
│    yyyy MM dd HH mm ss SSS                 │
│    MM 月份 ≠ mm 分钟                       │
│                                            │
│  迁移：                                    │
│    Date.from(instant)                      │
│    date.toInstant()                        │
└────────────────────────────────────────────┘
```

### 36.5 课后作业（本日汇总）

**必做**：
1. 完成教材 §12 全部示例代码抄写与运行
2. 独立完成教材 §12 剩余练习题（5-7）
3. 综合题：写 `Duration timeUntilMidnight()` 方法，返回距离今晚 24:00 还有多久

**选做**：
1. 拓展题：写「生日剩余天数提醒器」——输入生日，输出「今年生日还有 N 天 / 已过 N 天」
2. 挑战：把老代码里所有 `SimpleDateFormat` 与 `Date` 替换成 `DateTimeFormatter` 与 `LocalDateTime`，并写单元测试保证行为一致

### 36.6 教学反思提示
- 「北京-纽约同一时刻」的时区例子最直观，一定要讲
- Duration vs Period 用「时钟 vs 日历」类比学生秒懂
- pattern 大小写 M 是本节最坑点，反复问、反复答

---

## 全课程总结（讲完后 5 分钟总结）

《AI 应用编程进阶——Java 进阶》36 课时至此完结。学生累计掌握：
- **Day01**：泛型 + 异常
- **Day02**：IO 流 + 线程基础
- **Day03**：线程进阶（线程池 + wait/notify）+ 反射
- **Day04**：注解 + 集合精讲
- **Day05**：数据结构手写 + 内部类与接口增强
- **Day06**：Lambda / 方法引用 / Stream + Optional + 日期时间 API

**下阶段建议**：
- 项目实战：JDBC / MyBatis / Spring Boot
- 深挖：JVM 与并发 (JMM)
- AI 编程实战：结合 LangChain4j / Spring AI

请学生完成所有必做作业，并**从头到尾重跑一遍所有示例代码**——手上跑过，才是真懂了。
