# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day01（第 1-6 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Java 基础的大学一年级学生
**知识点覆盖**：泛型（3 课时） + 异常处理（3 课时）
**参考教材**：`../教材/chapters/01.md`、`02.md`

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：确认所有学生机安装完成，`java --version` 输出以 `25` 开头；教师机同版本，示例代码全部在 JDK 25 下预跑一遍。
2. **IntelliJ IDEA 2025.2+**（社区版即可）：项目 SDK 指向 JDK 25，语言级别 `25 - No new features`。
3. **代码演示工程**：预先在 IDEA 中打开 `day01-generics-exceptions/` 骨架工程，含四个空 main：`Q1NoGeneric`、`Q2WithGeneric`、`Q3Wildcard`、`Q4CustomException`。
4. **Maven 镜像**：教师机 `~/.m2/settings.xml` 已配置阿里云镜像（参见教材附录 B），避免课堂拉取依赖卡住。
5. **备用离线包**：优盘中携带 JDK 25 安装包和 IDEA 安装包，应对个别学生未装或损坏。

### 学情预设
- 前置：`ArrayList`、`HashMap` 会用，泛型尖括号见过但不理解；异常只用过 `try-catch` 抓 `NumberFormatException` 之类的 unchecked。
- 预计易混：泛型擦除、上下限通配符方向、checked / unchecked 的抛出时机。
- 预计基础差距：约 20% 学生对「编译期 vs 运行期」概念仍模糊，导入环节的第一个演示要慢。

### 教具与板书素材
- 大黑板划三区：左「问题代码」区、中「泛型语法」区、右「坑点速记」区。
- 打印一页 A4 「泛型上下限口诀 + Throwable 层次图」发给每位学生，粘贴在实验报告封面。

### 前置检查（上课前 5 分钟完成）
- 全班随机抽 3 台机器 `javac -version` 和 `java --version`，两者一致方可开讲。
- IDEA 右下角 Java 版本徽标全班截图上传班群，确认无 JDK 24 及以前的旧版本遗留。
- 板书区域擦净、投影亮度调至清晰、示例仓库拉到最新 commit。

---

## 第 1 课时：泛型入门——为什么需要泛型

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能说出没有泛型时 Java 容器的三大痛点
2. 能用一句话解释「泛型是参数化类型」
3. 能定义并使用带一个类型参数的泛型类 `Box<T>`

#### 1.1.2 过程与方法目标
1. 通过「有 / 无泛型」代码对照，体会编译期类型检查的价值
2. 通过类比「函数的参数是值、泛型的参数是类型」，建立参数化思维

### 1.2 教学重难点
- **重点**：泛型的本质 / 泛型类的定义语法 / 类型参数命名约定
- **难点**：理解「类型也可以像值一样被传参」这一抽象概念

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
提问：「上学期我们用 `ArrayList` 存过 `String`，也存过 `Integer`。你们有没有注意到写的时候都要加尖括号 `<String>`？如果不加会怎样？」
让学生尝试写一段 `ArrayList list = new ArrayList(); list.add("a"); list.add(1);`，观察 IDE 的黄色警告。引出：**尖括号里的东西就是「泛型参数」，今天我们就来搞清楚它到底是什么、为什么有用**。

#### 新知讲授（18 分钟）
**1. 无泛型时代的痛点**（板书三条）
- 不安全：类型错误要运行时才发现
- 不方便：每次取值都要强转
- 不清晰：读代码看不出容器装了什么

配合代码（教材 1.1.1）在黑板演示：`Box.set("hello")` 后又 `set(123)`，然后 `(String) box.get()` 抛 `ClassCastException`。

**2. 泛型的定义**
> 泛型（Generics）是 JDK 5 引入的语言特性，本质是**参数化类型**——把类型作为参数传给类 / 接口 / 方法。

对比表：

| 维度 | 无泛型 `Box` | 有泛型 `Box<T>` |
|------|------------|----------------|
| 存放类型 | Object | 用户指定 |
| 类型检查 | 运行时 | 编译期 |
| 取值方式 | 强转 | 直接返回 |
| 混用不同类型 | 会成功编译，运行崩 | 编译不通过 |

**3. 类型参数命名约定**（板书表格 T/E/K/V/R/N）

#### 示例演示（10 分钟）
在 IDE 现场敲 `Box<T>`：
```java
public class Box<T> {
    private T content;
    public void set(T content) { this.content = content; }
    public T get() { return content; }
}
```
分别 `new Box<String>()` 和 `new Box<Integer>()` 演示：
- 类型不匹配时的红波浪线
- 取值时不需要强转
- 编译器把类型信息记住了

#### 课堂练习（10 分钟）
1. 把下面这段无泛型代码改成泛型版本：
   ```java
   public class Pair { Object first; Object second; }
   ```
2. 判断下列语句能否编译（回答 ✅ 或 ❌）：
   ```java
   Box<String> b = new Box<Integer>();     // ?
   Box<String> b = new Box<>();            // ?
   Box b = new Box<String>();              // ?
   ```
3. 猜测：`Box<int>` 能否编译？为什么？（为下节课伏笔）

#### 小结（3 分钟）
本课时抓住一句话——**泛型 = 类型作为参数**。带着这个认识去看下节课的泛型方法和通配符。

### 1.4 板书设计
```text
┌────────────────────────────────────────┐
│  泛型入门                              │
│  1. 无泛型痛点：不安全 / 强转 / 不清晰 │
│  2. 定义：class Box<T> { T x; }        │
│  3. 使用：new Box<String>()            │
│  4. 命名：T E K/V R N                  │
│  5. 好处：编译期检查 / 免强转 / 复用   │
└────────────────────────────────────────┘
```

### 1.5 课后作业
1. 定义泛型类 `Result<T>` 包含 `success`、`data`、`message` 字段
2. 阅读教材 §1.1，抄写并背下「三大好处」
3. 挑战：`Box<int>` 为什么不允许？请预习教材 §1.4.1 找答案

### 1.6 教学反思提示
- 学生是否理解「类型」和「值」的类比？可用「参数是值，泛型是类型的参数」这一句反复强调
- 有没有学生问「那 Object 不就够了吗」？这个问题非常好，是引出编译期类型安全的关键契机

---

## 第 2 课时：泛型类、泛型接口、泛型方法

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 能定义带多个类型参数的泛型类（`Pair<K, V>`）
2. 能实现或使用泛型接口（`Repository<ID, T>`）
3. 能编写独立于类的泛型方法（`<T> void swap(T[], int, int)`）
4. 能说出「泛型类」与「泛型方法」在语法和适用场景上的区别

#### 2.1.2 过程与方法目标
1. 通过「先类再接口再方法」的递进结构，建立完整泛型使用体系
2. 通过一道「静态方法能否用类上的 T」的辨析题，理解类型参数的作用域

### 2.2 教学重难点
- **重点**：泛型方法的语法（`<T>` 位置在返回值之前） / 类型推断
- **难点**：静态方法必须自己声明 `<T>`，不能用类上的 `T`

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
上节课 `Box<T>` 只有一个类型参数。「如果我要一个键值对，键是 String，值是 Integer 呢？」引出多参数泛型类。

#### 新知讲授（18 分钟）
**1. 泛型类**（教材 1.2.1）
语法：`class 类名<类型参数1, 类型参数2, ...>`。
现场推导 `Pair<K, V>` 结构，强调**类型参数在类名后声明一次，全类可用**。

**2. 泛型接口**（教材 1.2.2）
- 场景：数据访问层 `Repository<ID, T>`
- 两种实现方式：
  - 实现时**具体化**：`class UserRepository implements Repository<Long, User>`
  - 实现时**继续保留**：`class MemoryRepository<ID, T> implements Repository<ID, T>`

**3. 泛型方法**（教材 1.2.3）
语法：`<T> 返回值 方法名(参数)`——**`<T>` 必须写在返回值之前**。
关键区别对照表：

| 对比项 | 泛型类 | 泛型方法 |
|--------|--------|----------|
| 类型参数声明位置 | 类名后 `class Box<T>` | 返回值前 `<T> void swap(...)` |
| 生效范围 | 整个类 | 单个方法 |
| 何时确定类型 | `new Box<String>()` | 调用时由参数推断 |
| 静态方法能否用 | 类上的 `T` **不能**用于静态方法 | 静态方法可**自己**声明 `<T>` |

#### 示例演示（12 分钟）
现场敲两个方法：
```java
public static <T> void swap(T[] arr, int i, int j) { ... }
public static <E> Set<E> toSet(List<E> list) { return new HashSet<>(list); }
```
在 `main` 里各调用一次，让 IDE 显示推断出的类型：
- `Utils.swap(new Integer[]{1,2,3}, 0, 2)` 推断 `T = Integer`
- `Utils.toSet(List.of("a","b"))` 推断 `E = String`

**反面教材**（板书划红叉）：
```java
public class Box<T> {
    public static void set(T value) { ... }  // ❌ 静态方法不能用类上的 T
    public static <T> void set2(T value) { ... }  // ✅ 静态方法自己声明
}
```

#### 课堂练习（9 分钟）
1. 写一个泛型方法 `<T> T firstOr(List<T> list, T defaultVal)`，返回列表首元素，若列表为空返回默认值。
2. 判断：`Map<K, V> extends Repository<K, V>` 允许吗？（引申：接口的继承也可以带泛型）
3. 修改一段错误代码，把「静态方法用类上 T」改成正确写法。

#### 小结（3 分钟）
类上的 T 是「类的一员」，方法上的 T 是「方法的一员」，静态成员因为独立于实例，只能用方法自己的 T。

### 2.4 板书设计
```text
┌────────────────────────────────────────┐
│  泛型三种形式                          │
│  类：class Pair<K,V>                   │
│  接口：interface Repo<ID,T>            │
│  方法：<T> void swap(T[], i, j)        │
│  --------------------------------------│
│  静态方法 → 类上的 T                   │
│  静态方法 → 自己的 <T>                 │
└────────────────────────────────────────┘
```

### 2.5 课后作业
1. 完成教材 §1.2 全部代码 `Pair`、`Repository`、`swap`、`toSet` 的手抄输入并运行
2. 定义 `<T> T pick(T a, T b, boolean flag)`，`flag` 为 true 返回 `a`，否则返回 `b`
3. 挑战：实现 `<T extends Comparable<T>> T max(List<T> list)`（提示：涉及下节课的有界类型）

### 2.6 教学反思提示
- 泛型方法的 `<T>` 位置是初学者最容易漏写的地方，务必在黑板上圈出来
- 「静态方法不能用类上的 T」这条规则要用一个错误示例 + 一个修正示例来讲，纯口述效果差

---

## 第 3 课时：通配符与泛型擦除

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 能区分 `List<Object>`、`List<?>`、`List<? extends T>`、`List<? super T>` 四者
2. 能应用 PECS 原则决定使用 `extends` 还是 `super`
3. 能说出泛型擦除的定义，并列出擦除带来的至少 4 条限制

#### 3.1.2 过程与方法目标
1. 通过一个「向 `? extends Number` 里 `add`」编译错误的实验，理解上界通配符的只读特性
2. 通过反射 `getClass()` 相同的现象，感知擦除是编译期概念

### 3.2 教学重难点
- **重点**：`? extends T`（只读）与 `? super T`（只写）的对偶 / PECS 原则
- **难点**：为什么 `List<Integer>` 不是 `List<Number>` 的子类

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
抛问题：「`Integer` 是 `Number` 的子类。那么 `List<Integer>` 是不是 `List<Number>` 的子类？」大部分学生会说是。演示：
```java
List<Number> nums = new ArrayList<Integer>();  // ❌
```
学生震惊：不是子类！这就是通配符要解决的问题。

#### 新知讲授（20 分钟）
**1. 通配符 `?`**
- 「任意类型的 List」的父类型是 `List<?>`，不是 `List<Object>`
- `List<?>` 上只能读、不能写（除了 `null`）

**2. 上界 `? extends T`（教材 §1.3.3）**
配合 `sum(List<? extends Number>)` 例子：Producer——只读。
黑板画:
```text
List<? extends Number>
├─ List<Integer>   ✅
├─ List<Double>    ✅
└─ List<Long>      ✅
   → 读出来一定是 Number
   → 写入被禁止（不知道到底是哪种子类）
```

**3. 下界 `? super T`（教材 §1.3.4）**
`addIntegers(List<? super Integer>)` 例子：Consumer——只写。

**4. PECS 原则**——一句口诀
> **Producer Extends, Consumer Super**——生产者 extends，消费者 super

```mermaid
flowchart LR
    A[需求] --> B{对集合做什么}
    B -->|只读元素| C[? extends T]
    B -->|只写元素| D[? super T]
    B -->|既读又写| E[T 不用通配符]
```

**5. 泛型擦除**（教材 §1.4）
编译后类型参数被擦为上限（默认 Object）。反射实验：
```java
List<String>  ls = new ArrayList<>();
List<Integer> li = new ArrayList<>();
System.out.println(ls.getClass() == li.getClass());  // true
```
擦除带来的 6 条限制（板书表格，教材 §1.4.2）。

#### 示例演示（10 分钟）
现场敲 PECS 场景：
```java
// 拷贝：src 是 Producer，dst 是 Consumer
public static <T> void copy(List<? extends T> src, List<? super T> dst) {
    for (T t : src) dst.add(t);
}
```
调用 `copy(List<Integer>, List<Number>)` 演示灵活性。

#### 课堂练习（8 分钟）
1. 用 `? extends` 和 `? super` 补全：
   ```java
   static double sumAll(List<____ Number> list) { ... }
   static void fill(List<____ String> list, String s) { ... }
   ```
2. 解释为什么以下编译错误，并给出修复：
   ```java
   List<? extends Number> list = new ArrayList<>();
   list.add(1);
   ```
3. 泛型擦除后，`new T[10]` 为何无法编译？替代方案是什么？

#### 小结（3 分钟）
- 「读用 extends，写用 super」这句口诀带走
- 泛型只在编译期存在，是编译器给你的安全网，运行时是 Object

### 3.4 板书设计
```text
┌────────────────────────────────────────┐
│ PECS：Producer Extends, Consumer Super │
│  ┌─────────────┬────────┬────────┐     │
│  │             │  读    │  写    │     │
│  ├─────────────┼────────┼────────┤     │
│  │ ? extends T │  是    │  否    │     │
│  │ ? super  T  │ Object │  量    │     │
│  │      T      │  写    │  量    │     │
│  └─────────────┴────────┴────────┘     │
│  擦除：编译后 T → Object 或上限        │
└────────────────────────────────────────┘
```

### 3.5 课后作业
1. 完成教材 §1.3 所有示例代码的输入与运行
2. 独立完成教材末尾练习题 3、4、5
3. 挑战：实现 `<T> void reverse(List<T> list)`，并思考为什么这里不用通配符

### 3.6 教学反思提示
- PECS 是本讲最有价值的一句话，务必板书 + 口诀 + 例子三重强化
- 泛型擦除对初学者较抽象，用 `getClass()` 实验落地效果最好

---

## 第 4 课时：异常介绍与体系结构

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能说出 Java 异常体系的三大分支：`Error`、`Exception`、`RuntimeException`
2. 能区分**受检异常（Checked）**与**非受检异常（Unchecked）**
3. 能举出 5 种常见的运行时异常
4. 理解「异常是一种对象」这一 Java 设计哲学

#### 4.1.2 过程与方法目标
1. 通过「不用异常怎么处理错误」的 C 语言返回码对比，突出异常机制的优势
2. 通过 UML 类图梳理 `Throwable` 家族关系

### 4.2 教学重难点
- **重点**：Checked vs Unchecked 的判定标准与典型例子
- **难点**：为什么 `Error` 不该被 catch，而 `RuntimeException` 通常也不 catch

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
展示一段没有 try-catch 的除零代码：
```java
int a = 10, b = 0;
System.out.println(a / b);   // 崩溃：ArithmeticException
```
提问：「如果这是 C 语言，程序会怎样？」引导：C 用返回码 -1，需要每次 if 判断。Java 有更优雅的机制——异常。

#### 新知讲授（20 分钟）
**1. 什么是异常**
异常是**程序运行时发生的、非预期的、可打断正常流程的事件**，在 Java 里是一个**对象**。

**2. Throwable 家族**（板书 UML 图）
```mermaid
flowchart TD
    A[Throwable] --> B[Error]
    A --> C[Exception]
    B --> B1[OutOfMemoryError]
    B --> B2[StackOverflowError]
    C --> D[RuntimeException]
    C --> E[IOException / SQLException / ...]
    D --> D1[NullPointerException]
    D --> D2[ArithmeticException]
    D --> D3[IndexOutOfBoundsException]
    D --> D4[ClassCastException]
```

**3. Checked vs Unchecked**

| 分类 | 父类 | 编译器强制处理 | 典型代表 | 处理建议 |
|------|------|--------------|---------|---------|
| **受检异常** | `Exception`（非 RuntimeException） | ✅ 是 | `IOException`、`SQLException` | 必须 try-catch 或 throws |
| **非受检异常** | `RuntimeException` | ❌ 否 | `NullPointerException`、`IndexOutOfBoundsException` | 靠代码质量避免，通常不 catch |
| **错误** | `Error` | ❌ 否 | `OutOfMemoryError`、`StackOverflowError` | 一般不 catch，交给 JVM |

**判定口诀**：
> 是不是 `RuntimeException` 的子类？是 → Unchecked；否 → Checked（除了 Error）。

**4. 5 种最常见的运行时异常**（板书）
- `NullPointerException`（简称 NPE）—— 空指针
- `ArrayIndexOutOfBoundsException` —— 数组越界
- `ClassCastException` —— 类型强转失败
- `NumberFormatException` —— 字符串转数字失败
- `ArithmeticException` —— 除零等算术错误

#### 示例演示（10 分钟）
现场手写并触发 5 种运行时异常：
```java
String s = null; s.length();           // NPE
int[] a = {1}; System.out.println(a[5]); // AIOOBE
Object o = "abc"; Integer i = (Integer) o; // CCE
Integer.parseInt("abc");                // NFE
System.out.println(1 / 0);              // AE
```
每种都让学生说出对应异常名。

再演示一个 Checked 异常：
```java
FileReader fr = new FileReader("no.txt");  // ❌ 编译不通过
```
IDE 提示「Unhandled exception」——这就是**编译器强制处理**的表现。

#### 课堂练习（8 分钟）
1. 判断以下异常属于 Checked 还是 Unchecked：
   `IOException`、`NullPointerException`、`ClassNotFoundException`、`IllegalArgumentException`
2. 说出至少 3 个 `Error` 的子类
3. 若一个方法既可能抛 `IOException` 又可能抛 `NullPointerException`，编译器会强制你处理哪个？

#### 小结（3 分钟）
异常是对象，分三支：Error 别碰、Checked 必须处理、Runtime 靠代码质量避免。

### 4.4 板书设计
```text
┌────────────────────────────────────────┐
│         Throwable                      │
│         /        \                     │
│      Error     Exception               │
│                /       \               │
│         RuntimeExc    其他 Exception   │
│         (Unchecked)   (Checked)        │
│  判定：是不是 RuntimeException 的子类  │
│  Checked  → 编译器强制处理             │
│  Unchecked → 靠代码质量                │
└────────────────────────────────────────┘
```

### 4.5 课后作业
1. 阅读教材 §2.1 全文
2. 写出 10 个你听过或用过的异常类名，标注 Checked / Unchecked
3. 挑战：查阅 JDK 文档，`InterruptedException` 属于哪一类？为什么这样设计？

### 4.6 教学反思提示
- 学生最常混淆 Error 与 Exception，务必让他们记住「Error 一般不 catch」
- 提问「NPE 是 Checked 吗」是一个高频陷阱，可反复检验

---

## 第 5 课时：try-catch-finally 与 throws / throw

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 能写出标准 `try-catch-finally` 结构，掌握多 catch 与异常匹配顺序
2. 能区分 `throws`（方法声明抛出）与 `throw`（真实抛出对象）
3. 能使用 try-with-resources 简化资源关闭
4. 能说出 finally 的执行时机与「返回值覆盖」陷阱

#### 5.1.2 过程与方法目标
1. 通过「多 catch 的顺序错误」的编译报错，理解异常匹配自上而下的机制
2. 通过 finally 的 return 陷阱，让学生形成「finally 里少写 return」的直觉

### 5.2 教学重难点
- **重点**：try-catch-finally 的执行顺序 / try-with-resources 的用法
- **难点**：多 catch 中父类必须写在子类之后 / finally 中 return 覆盖 try 中 return

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
回忆昨天的 `FileReader` 编译错误——「Unhandled exception」。今天来学如何「处理」它。

#### 新知讲授（20 分钟）
**1. 三段式结构**
```java
try {
    // 可能抛异常的代码
} catch (SpecificException e) {
    // 处理 A
} catch (Exception e) {
    // 兜底
} finally {
    // 无论如何都执行
}
```

**2. 多 catch 的三条铁律**
- 一个 try 可有多个 catch
- 从上到下逐个匹配，命中第一个后停止
- **父类必须写在子类之后**——顺序颠倒会编译错误

反面教材：
```java
try { ... }
catch (Exception e) { }            // 父类先写
catch (IOException e) { }          // ❌ 编译错误：unreachable
```

**3. finally 的执行时机**
| 场景 | finally 是否执行 |
|------|-----------------|
| try 正常结束 | ✅ |
| try 抛异常且被 catch | ✅ |
| try 抛异常未被 catch | ✅（然后异常继续抛出） |
| try 中 `return` | ✅（return 前执行） |
| JVM 强制退出 `System.exit(0)` | ❌ |

**finally 陷阱**：
```java
static int test() {
    try { return 1; }
    finally { return 2; }   // ⚠️ 覆盖 try 的 return，最终返回 2
}
```

**4. try-with-resources**（JDK 7+，教材 §2.2）
资源实现 `AutoCloseable` 就能自动关闭：
```java
try (FileReader fr = new FileReader("a.txt");
     BufferedReader br = new BufferedReader(fr)) {
    // 使用
} catch (IOException e) {
    // 处理
}
// 自动 close，无需 finally
```

**5. throws 与 throw**（教材 §2.3）

| 关键字 | 位置 | 作用 |
|--------|------|------|
| `throws` | 方法**签名**上 | 声明：本方法可能抛出这些异常，调用者要处理 |
| `throw`  | 方法**体**内 | 真正抛出一个异常对象 |

示例：
```java
public void readFile(String path) throws IOException {   // 声明
    if (path == null) throw new IllegalArgumentException();  // 抛出
    Files.readAllLines(Path.of(path));
}
```

#### 示例演示（12 分钟）
现场敲一个完整的文件读取：
```java
public static String readFirstLine(String path) {
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        return br.readLine();
    } catch (FileNotFoundException e) {
        return "文件不存在";
    } catch (IOException e) {
        return "读取失败：" + e.getMessage();
    }
}
```
故意把 `FileNotFoundException` 和 `IOException` 顺序颠倒，让 IDE 报错，讲清「子类在前」的原因。

#### 课堂练习（7 分钟）
1. 判断以下代码返回值：
   ```java
   static int f() {
       try { return 1; } finally { System.out.println("bye"); }
   }
   // 输出？返回值？
   ```
2. 把下列 finally 关闭代码改写为 try-with-resources：
   ```java
   FileReader fr = null;
   try { fr = new FileReader("a"); ... }
   finally { if (fr != null) fr.close(); }
   ```
3. 修正错误的多 catch 顺序（现场展示一段错代码）

#### 小结（3 分钟）
- try 试、catch 抓、finally 兜底
- 多 catch 子类在前
- 资源类首选 try-with-resources
- throws 是「预告」，throw 是「投掷」

### 5.4 板书设计
```text
┌────────────────────────────────────────┐
│  try { ... }                           │
│  catch (子类 e) { ... }  ← 顺序        │
│  catch (父类 e) { ... }                │
│  finally { ... }                       │
│                                        │
│  throws (签名) vs throw (体内)         │
│                                        │
│  try(资源) { ... }  ← 自动关闭         │
└────────────────────────────────────────┘
```

### 5.5 课后作业
1. 用 try-with-resources 读取一个文本文件的所有行
2. 写一个方法 `void divide(int a, int b) throws ArithmeticException`，`b == 0` 时抛出并附带提示信息
3. 挑战：写一段代码演示 finally 中 return 覆盖 try 中 return，并解释为什么这是坏味道

### 5.6 教学反思提示
- 「finally 里写 return」的坏味道要用一次「原本能到达的值被吞了」的演示才能让学生真正记住
- try-with-resources 一定要现场演示 IDE 自动补全 `AutoCloseable`，让学生看到编译器如何帮你

---

## 第 6 课时：自定义异常与最佳实践

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 能定义自己的业务异常类，选择继承 `RuntimeException` 或 `Exception`
2. 掌握异常链 `Throwable(String, Throwable)` 的使用
3. 能陈述至少 5 条异常处理的最佳实践与反模式

#### 6.1.2 过程与方法目标
1. 通过一个「用户名重复」的业务场景，走完自定义异常从定义到抛出、捕获、链式包装的全流程
2. 对比「日志吃异常」等常见反模式与正确写法

### 6.2 教学重难点
- **重点**：自定义异常构造函数四件套 / 异常链 / 何时选 Runtime、何时选 Checked
- **难点**：反模式识别——学生易写「空 catch」「catch Exception 兜底」的坏代码

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天讲了 5 种运行时异常，都是 JDK 自带。可如果我要表达『用户名已存在』，JDK 里可没有 `UsernameDuplicatedException`——今天我们自己写一个。」

#### 新知讲授（18 分钟）
**1. 自定义异常四件套构造函数**
```java
public class UsernameDuplicatedException extends RuntimeException {
    public UsernameDuplicatedException() {}
    public UsernameDuplicatedException(String msg) { super(msg); }
    public UsernameDuplicatedException(String msg, Throwable cause) { super(msg, cause); }
    public UsernameDuplicatedException(Throwable cause) { super(cause); }
}
```

**2. Runtime 还是 Checked？——选择表**

| 情况 | 选择 | 理由 |
|------|------|------|
| 业务规则错误、调用方通常无法恢复 | `RuntimeException` | 避免 throws 污染 |
| I/O、网络、数据库这类外部资源错误 | `Exception`（Checked） | 强制调用方处理 |
| 参数校验类 | `IllegalArgumentException`（Runtime） | 现成的，不必自定义 |

**行业习惯**：Spring、Hibernate 等主流框架几乎全用 RuntimeException。

**3. 异常链**
```java
try {
    doDbCall();
} catch (SQLException e) {
    throw new BizException("保存失败", e);   // 保留原始 cause
}
```
好处：`e.printStackTrace()` 会打印 `Caused by:`，问题源头不丢。

**4. 最佳实践 5 条 vs 反模式 5 条**

| # | ✅ 最佳实践 | ❌ 反模式 |
|---|-----------|----------|
| 1 | 抛出**具体**的异常类型 | catch(Exception e) 一网打尽 |
| 2 | 记录日志时**同时打堆栈** | `log.info(e.getMessage())` |
| 3 | 关闭资源用 try-with-resources | 手写 finally 且忘记 null 判断 |
| 4 | 包装底层异常时**保留 cause** | `throw new RuntimeException("...")` 丢原因 |
| 5 | 异常表示**异常情况**，不做流程控制 | 用异常做 `if/else`（性能极差） |

#### 示例演示（12 分钟）
以「注册用户」为例：
```java
public class UserService {
    public void register(String username) {
        if (repo.existsByUsername(username)) {
            throw new UsernameDuplicatedException("用户名已存在：" + username);
        }
        try {
            repo.save(new User(username));
        } catch (SQLException e) {
            throw new BizException("保存用户失败", e);   // 异常链
        }
    }
}
```
控制器里：
```java
try {
    service.register(name);
} catch (UsernameDuplicatedException e) {
    return Result.fail(409, e.getMessage());
} catch (BizException e) {
    log.error("注册异常", e);   // 打堆栈
    return Result.fail(500, "服务器错误");
}
```

#### 课堂练习（9 分钟）
1. 定义 `AmountInvalidException`，用于金额小于等于 0 的场景，选择合适的父类并说明理由
2. 找出以下代码的 3 个反模式，并改写：
   ```java
   try { ... }
   catch (Exception e) { }        // 空 catch
   ```
3. 写一段代码：捕获 `SQLException` 后包装成自定义 `DbException` 抛出，保留原始异常链

#### 小结（3 分钟）
- 自定义异常构造函数四件套是模板
- 业务用 Runtime、外部资源用 Checked 是行业习惯
- 异常链保留 cause，日志一定打堆栈
- **异常表示异常，不做流程控制**

### 6.4 板书设计
```text
┌────────────────────────────────────────┐
│  自定义异常四件套                      │
│  () / (msg) / (msg,cause) / (cause)    │
│                                        │
│  Runtime  ← 业务规则                   │
│  Checked  ← 外部资源                   │
│                                        │
│  反模式：                              │
│    catch(Exception e){}                │
│    log.info(e.getMessage())            │
│    忘记链 cause                        │
└────────────────────────────────────────┘
```

### 6.5 课后作业（本日汇总）
**必做**（本日 6 课时汇总）：
1. 完成教材 §1 与 §2 全部代码抄写并运行
2. 独立完成教材 §1 练习题 1-6 与 §2 练习题
3. 编写一个 `Result<T>` 泛型类，配合两个自定义异常 `NotFoundException`、`InvalidArgumentException`，写一个简易的 UserService 模拟注册 + 查询

**选做**（挑战）：
1. 阅读并总结 JDK 中 `Optional` 是如何避免抛出 `NullPointerException` 的（为第 6 天预习）
2. 找一段你以前写过的项目代码，标出所有异常处理相关的反模式并改写

### 6.6 教学反思提示
- 「异常做流程控制」这一反模式非常隐蔽，学生极易写出（用异常判空、用异常跳出循环），务必用一段现场代码演示
- 用 `printStackTrace()` 输出的 `Caused by:` 视觉冲击很强，一定要在教室大屏演示一次

---

## 本日总结

Day01 完成教材第 1、2 讲。学生带走的核心能力：
- **泛型**：能读能写泛型类 / 接口 / 方法，熟悉通配符 PECS，理解擦除
- **异常**：能设计自己的异常体系，写出符合最佳实践的 try-catch 代码

明日（Day02）主题：**IO 流** + **线程与并发（上）**，对应教材第 3、4 章。请学生课后完成上面必做作业并预习教材第 3 章。
