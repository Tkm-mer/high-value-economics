# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day02（第 7-12 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Java 基础与 Day01（泛型 + 异常）的大学一年级学生
**知识点覆盖**：File 与 IO 流（3 课时） + 线程与并发上（3 课时）
**参考教材**：`../教材/chapters/03.md`、`04.md`

---

## 本日知识地图

```mermaid
flowchart LR
    subgraph G1["上午 · IO"]
        direction LR
    L7["第 7 课时<br/>File 类与 NIO Path"]
    L8["第 8 课时<br/>字节流与字符流"]
    L9["第 9 课时<br/>缓冲流 & 序列化"]
    end
    subgraph G2["下午 · 并发"]
        direction LR
    L10["第 10 课时<br/>线程入门与 4 种实现"]
    L11["第 11 课时<br/>线程安全 4 大解法"]
    L12["第 12 课时<br/>线程池入门"]
    end
    L7 --> L8 --> L9
    L10 --> L11 --> L12
    L9 -.承接.-> L10
```

> 6 个课时按「IO → 并发」两大板块递进；上午打基础，下午做延伸，最后一课时做本日综合练习。

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：沿用 Day01 环境；本讲重点验证 `java.nio.file.Path`、`Files.walkFileTree`、`Thread.ofVirtual()`（预览查看）在 JDK 25 下可用。
2. **示例文件目录**：在学生机 `D:/java-io-demo/`（或 `~/java-io-demo/`）预置一批测试用文件：`hello.txt`（含 UTF-8 中英文混排）、`big.bin`（约 20 MB 随机字节）、`nested/a/b/c.txt` 三级子目录结构，用于 IO 与 File 遍历。
3. **IntelliJ IDEA（下简称 IDEA） 工程**：`day02-io-threads/` 骨架，含 `iodemo`、`niodemo`、`threaddemo` 三个包；教师机预跑一遍确保编码为 UTF-8（`File | Settings | Editor | File Encodings` 全部 UTF-8）。
4. **系统监视工具**：Windows 打开任务管理器「性能 - CPU」页；macOS/Linux 准备 `htop` 或 `Activity Monitor`，用于线程演示时观察核心占用。
5. **网络备份**：`big.bin` 生成脚本 `mkfile.py` 放到班群，学生若丢失可自行重建。

### 学情预设
- 前置：Day01 泛型 + 异常已通过；`try-with-resources` 语法见过但没深入。
- 预计易混：`File` vs `Path`、字节流 vs 字符流、`Runnable` vs `Thread` vs 线程池。
- 预计基础差距：约 30% 学生未接触过操作系统进程/线程概念，「并发」需在导入环节用生活例子（食堂窗口）建模。

### 教具与板书素材
- 板书区左「IO 类图」（InputStream / OutputStream / Reader / Writer 四棵树的根），中「Path/Files API 速查」，右「线程状态迁移图」占位。
- 打印 A4「Java IO 常用类对照表 + 线程 6 大状态图」发给学生。

### 前置检查（上课前 5 分钟完成）
- 全班执行 `java -version`、确认 JDK 25；执行 `Files.exists(Path.of("D:/java-io-demo"))`（可在 jshell 中一句测），报 `true` 才可开讲。
- IDEA 编码栏右下角显示 `UTF-8`，若显示 `GBK` 立即改正，避免中文乱码影响 IO 演示。
- 关闭杀毒软件的 IO 监控，避免 `big.bin` 拷贝被拦截。

---

## 第 7 课时：File 类与 NIO Path

### 7.1 教学目标
#### 7.1.1 知识与技能目标
1. 能说出 `File` 对象「表示路径而非内容」这一核心特性
2. 掌握 `File` 常用方法：`exists / isFile / listFiles / mkdirs / delete`
3. 会用递归方式遍历目录树
4. 认识 NIO 的 `Path` + `Files`，能列出至少 3 条相对 `File` 的改进

#### 7.1.2 过程与方法目标
1. 通过「路径 vs 内容」的类比区分，避免学生误以为 `new File("x.txt")` 就创建了文件
2. 通过递归遍历例子，复习方法递归 + 集合遍历

### 7.2 教学重难点
- **重点**：`File` API 的分类记忆（判断 / 信息 / 操作 / 遍历） / 递归遍历
- **难点**：`File f = new File("a.txt")` 并不实际创建文件；`f.getPath()` 与 `f.getAbsolutePath()` 的区别

### 7.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
提问：「上学期我们用 `Scanner` 从控制台读输入。今天要读**文件**，你觉得 Java 会给你一个什么类？」多数学生会猜 `File`。演示：
```java
File f = new File("no-such.txt");
System.out.println(f.exists());   // false
```
学生震惊——**没抛异常也没创建**。引出：`File` 只是一个「路径描述符」。

#### 新知讲授（18 分钟）
**1. File 的角色**（板书 Mermaid 图）
- 表示：路径信息、元数据
- **不表示**：文件内容（这需要下一节课的 IO 流）

**2. 常用方法分四类**（板书）

| 类别 | 方法 |
|------|------|
| **判断** | `exists / isFile / isDirectory / canRead / canWrite` |
| **信息** | `getName / getPath / getAbsolutePath / length / lastModified` |
| **操作** | `createNewFile / delete / mkdir / mkdirs` |
| **遍历** | `listFiles / list` |

**mkdir vs mkdirs**：
- `mkdir()`：只创建**单层**目录，父目录不存在会失败
- `mkdirs()`：创建**多层**目录（推荐）

**3. 递归遍历目录树**
```java
public static void listAll(File dir, int depth) {
    if (dir == null || !dir.exists()) return;
    System.out.println("  ".repeat(depth) + dir.getName());
    if (dir.isDirectory()) {
        File[] children = dir.listFiles();
        if (children != null) {
            for (File c : children) listAll(c, depth + 1);
        }
    }
}
```
**关键坑**：`listFiles()` 可能返回 **null**（无权限或不是目录），必须判空。

**4. NIO Path & Files（Java 7+）**

| 特性 | File | Path + Files |
|------|------|-------------|
| 定位 | 老 API（1.0） | 新 API（Java 7） |
| 表达 | 路径 + 少量操作 | 路径 vs 操作分离 |
| 一行读写文本 | ❌ | `Files.readString / writeString` |
| 流式遍历 | ❌ | `Files.walk(...)` |
| 异常 | 返回 boolean 吃错误 | 抛 `IOException` 明确 |

现代项目建议 `Path` + `Files`，本课程主教材以 `File` 讲透，NIO 作补充。

#### 示例演示（12 分钟）
在 IDE 现场演示：
```java
File dir = new File("D:/data");
if (!dir.exists()) dir.mkdirs();
File f = new File(dir, "hello.txt");
System.out.println(f.exists());        // false
System.out.println(f.createNewFile()); // true —— 现在文件才被创建
System.out.println(f.length());        // 0
```
然后调用递归遍历打印整棵目录树。

再演示 NIO 版本一行读写：
```java
Files.writeString(Path.of("D:/data/hello.txt"), "你好");
System.out.println(Files.readString(Path.of("D:/data/hello.txt")));
```

#### 课堂练习（8 分钟）
1. 用 `File` 判断 `D:/` 下有多少个直接子项（文件+目录）
2. `f.mkdir()` 与 `f.mkdirs()` 的区别？给出会失败的例子
3. 写一个递归方法 `countFiles(File dir)` 统计目录树中的文件（不含目录）总数

#### 小结（3 分钟）
**File 只是路径不是内容**，创建文件需要 `createNewFile()` 或用 IO 流写内容。`listFiles()` 可能为 null，必须判空。

### 7.4 板书设计
```text
┌──────────────────────────────────────────┐
│  File = 路径描述符（不含内容）           │
│                                          │
│  判断: exists/isFile/isDirectory         │
│  信息: getName/getPath/length            │
│  操作: createNewFile/delete/mkdirs       │
│  遍历: listFiles → 可能为 null！         │
│                                          │
│  NIO: Path + Files (Java 7+)             │
│    readString / writeString / walk       │
└──────────────────────────────────────────┘
```

### 7.5 课后作业
1. 抄写并运行教材 §3.1 全部示例代码
2. 写一个方法 `listJavaFiles(File dir)`，递归找出目录下所有 `.java` 文件并打印
3. 挑战：用 `Files.walk` 实现同样功能，对比两种写法

### 7.6 教学反思提示
- 学生最容易忽视 `listFiles()` 返回 null 的情况，务必演示一次 NullPointerException 让他们记住
- `File` 老、`Path` 新，但本课不要过度强调「淘汰」——`File` 在教材与老代码中仍是主流

---

## 第 8 课时：字节流与字符流

### 8.1 教学目标
#### 8.1.1 知识与技能目标
1. 能画出 Java IO 流的四大基类树：`InputStream`、`OutputStream`、`Reader`、`Writer`
2. 会用 `FileInputStream / FileOutputStream` 复制二进制文件
3. 会用 `InputStreamReader / OutputStreamWriter` 显式指定 UTF-8 编码避免乱码
4. 能说出为什么单字节读写慢、字节数组读写快

#### 8.1.2 过程与方法目标
1. 通过「复制 1MB 图片：单字节 vs 字节数组」的实测耗时对比，感知 IO 性能差异
2. 通过一次「不指定编码 → 乱码」的翻车演示，形成「文本 IO 必带编码」的直觉

### 8.2 教学重难点
- **重点**：字节流 vs 字符流的分工 / 缓冲区 `byte[8192]` 的写法 / `write(buf, 0, len)` 中 `len` 的必要性
- **难点**：桥接类 `InputStreamReader` 的作用 —— 把字节流「翻译」为字符流

### 8.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
展示一张 `.png` 用记事本打开的乱码。「二进制文件用文本方式打开就是乱码。反过来，中文文本用二进制方式**不指定编码**读也会乱。今天我们分清两类流：**字节流处理二进制，字符流处理文本**。」

#### 新知讲授（20 分钟）
**1. 四大基类树**（板书）
```text
    InputStream ─── FileInputStream / BufferedInputStream / ObjectInputStream
    OutputStream ── FileOutputStream / BufferedOutputStream / ObjectOutputStream
    Reader ──────── FileReader / BufferedReader / InputStreamReader
    Writer ──────── FileWriter / BufferedWriter / OutputStreamWriter / PrintWriter
```

**2. 字节流：单字节 vs 字节数组**

单字节（慢，教学用）：
```java
int b;
while ((b = in.read()) != -1) out.write(b);
```

字节数组（快，生产用）：
```java
byte[] buf = new byte[8192];
int len;
while ((len = in.read(buf)) != -1) {
    out.write(buf, 0, len);   // 一定要传 len，否则写入垃圾
}
```

**坑点**：为什么必须 `write(buf, 0, len)` 而不是 `write(buf)`？
最后一次读取可能只填满 buf 的一部分，剩下的是**上一轮的旧数据**。若写整个 buf 会把旧数据也写出去。

**3. 字符流：为什么需要**

一个中文字符在 UTF-8 编码里是 3 字节。若用 `FileInputStream` 逐字节读，恰好在字符中间截断会**乱码**。字符流以 `char` 为单位，读进来时**内置解码**为 `char`。

**4. 编码必须指定**
```java
// ❌ 平台默认编码，在 Windows 常是 GBK，跨平台乱码
Reader r = new FileReader("note.txt");

// ✅ 显式 UTF-8
Reader r = new InputStreamReader(
    new FileInputStream("note.txt"),
    StandardCharsets.UTF_8
);
```

**5. 桥接类**（板书图）
```text
字节流 <──── InputStreamReader / OutputStreamWriter ────> 字符流
     (字节)          (指定编码解码)                    (字符)
```

#### 示例演示（12 分钟）
现场敲图片复制（字节流）+ 文本复制（字符流），双开对比：
```java
// 图片复制
try (var in = new FileInputStream("src.png");
     var out = new FileOutputStream("dst.png")) {
    byte[] buf = new byte[8192];
    int len;
    while ((len = in.read(buf)) != -1) {
        out.write(buf, 0, len);
    }
}

// 文本复制（带 UTF-8）
try (Reader r = new InputStreamReader(new FileInputStream("note.txt"), StandardCharsets.UTF_8);
     Writer w = new OutputStreamWriter(new FileOutputStream("copy.txt"), StandardCharsets.UTF_8)) {
    char[] buf = new char[1024];
    int len;
    while ((len = r.read(buf)) != -1) {
        w.write(buf, 0, len);
    }
}
```

「翻车实验」：故意去掉编码用 `FileReader`，读一个 UTF-8 的中文文件在 Windows 上就出现乱码，学生印象深刻。

#### 课堂练习（7 分钟）
1. 判断以下应该用字节流还是字符流：`.mp3` / `.txt` / `.pdf` / `.java` / `.png`
2. 修改一段错误代码 `out.write(buf)`，改为正确的 `write(buf, 0, len)`
3. 说出 `InputStreamReader` 存在的意义（一句话即可）

#### 小结（3 分钟）
- 二进制文件用字节流、文本文件用字符流
- 字节流复制记忆 `byte[8192] + read(buf) + write(buf, 0, len)`
- 字符流处理文本一定带 `StandardCharsets.UTF_8`

### 8.4 板书设计
```text
┌────────────────────────────────────────────┐
│  IO 四大基类                               │
│  字节流：InputStream / OutputStream        │
│  字符流：Reader / Writer                   │
│                                            │
│  字节读写模板：                            │
│  byte[] buf = new byte[8192];              │
│  while((len = in.read(buf))!=-1)           │
│      out.write(buf, 0, len);   ← 一定要 len│
│                                            │
│  编码必须显式：UTF_8                       │
│  桥接：InputStreamReader                   │
└────────────────────────────────────────────┘
```

### 8.5 课后作业
1. 抄写并运行教材 §3.2 + §3.3 全部示例
2. 复制一张真实图片，测量单字节循环 vs 字节数组两种方式的耗时（用 `System.nanoTime()`）
3. 挑战：写一个方法 `String md5(File f)`（提示 `MessageDigest.getInstance("MD5")`），能给任意文件算 MD5

### 8.6 教学反思提示
- 「乱码演示」是本课时最有教育意义的环节，务必真做一次，别只嘴上说
- `write(buf, 0, len)` 是学生最常写错的地方，让他们主动指出「为什么不能写整个 buf」

---

## 第 9 课时：缓冲流、对象序列化

### 9.1 教学目标
#### 9.1.1 知识与技能目标
1. 理解缓冲流的原理：内存中批量搬运，减少系统调用
2. 会用 `BufferedReader.readLine()` + `BufferedWriter.newLine()` 逐行处理文本
3. 掌握对象序列化：`implements Serializable` + `serialVersionUID` + `transient`
4. 认识 Java 原生序列化的局限，了解 JSON 是现代替代方案

#### 9.1.2 过程与方法目标
1. 通过「缓冲流 vs 无缓冲」的耗时对比，理解「减少系统调用是关键」
2. 通过 `transient password` 反序列化为 null 的现象，理解 `transient` 的语义

### 9.2 教学重难点
- **重点**：缓冲流的用法 / `readLine + newLine` 组合 / 序列化四要素
- **难点**：`serialVersionUID` 的意义与显式声明 / `static` 与 `transient` 不参与序列化的原因

### 9.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天写的字节流复制，`byte[8192]` 大概是自己攒缓冲区。有没有更简单的方式？——今天讲**缓冲流**，一行套一层就能加速。」

#### 新知讲授（20 分钟）
**1. 缓冲流原理**（板书 Mermaid 图）
```text
程序 ──read/write──▶ Buffered 流(8KB) ──批量系统调用──▶ 底层流 ──▶ 磁盘/网络
```
一般能带来**数十倍**的吞吐提升。

**2. 装饰器模式的应用**
`BufferedInputStream` 不是独立的流，而是**装饰**在其他 InputStream 外：
```java
new BufferedInputStream(new FileInputStream("a.bin"))
```

**3. 字符缓冲的两个新方法**
- `BufferedReader.readLine()` —— 按行读，返回 `String`，遇 EOF 返 null
- `BufferedWriter.newLine()` —— 写平台无关的换行符（Windows `\r\n`，Linux `\n`）

标准逐行读写模板：
```java
try (BufferedReader in = new BufferedReader(new InputStreamReader(
        new FileInputStream("a.txt"), StandardCharsets.UTF_8));
     BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
        new FileOutputStream("b.txt"), StandardCharsets.UTF_8))) {
    String line;
    while ((line = in.readLine()) != null) {
        out.write(line);
        out.newLine();
    }
}
```

**4. flush 与 close**
- 写缓冲流数据可能滞留在缓冲区
- `flush()` 强制冲刷；`close()` 关闭前自动 flush
- try-with-resources 关闭时自动 flush，**最佳实践**

**5. 对象序列化**（教材 §3.5）

「序列化」是**对象 → 字节序列**的过程，用来持久化或网络传输。

四要素：
| 要素 | 语法 | 作用 |
|------|------|------|
| 实现接口 | `implements Serializable` | 标记接口，无方法 |
| 版本号 | `private static final long serialVersionUID = 1L` | 类结构变化时的兼容性判据 |
| 跳过字段 | `transient` 修饰符 | 该字段不参与序列化 |
| 跳过静态 | `static` 字段 | 天然不参与（属于类不属于实例） |

写入：`ObjectOutputStream.writeObject(obj)`；读回：`ObjectInputStream.readObject()`。

**serialVersionUID 的作用**
反序列化时 JVM 比对**文件中 UID** 与**当前类 UID**：不一致 → `InvalidClassException`。不显式声明时 JVM 自动生成，任何字段/方法改动都会让 UID 变化。**必须显式声明**。

#### 示例演示（12 分钟）
现场敲一个 `User` 类并序列化：
```java
public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;
    private transient String password;
    // 构造 + toString
}

// 写
try (var out = new ObjectOutputStream(new FileOutputStream("user.obj"))) {
    out.writeObject(new User("Tom", 20, "123456"));
}

// 读
try (var in = new ObjectInputStream(new FileInputStream("user.obj"))) {
    User u = (User) in.readObject();
    System.out.println(u);   // password 显示为 null
}
```
学生看到 password 是 `null` 会有恍然大悟感。

再演示 Java 原生序列化 vs JSON 的对比表（教材 §3.5.5）。

#### 课堂练习（7 分钟）
1. 把昨天的图片复制代码套上缓冲流，观察耗时变化
2. `transient` 修饰的字段反序列化后是什么值？（默认值：引用类型 null / 数值类型 0 / boolean false）
3. 判断以下类是否能被序列化，并说明理由：
   ```java
   class Node implements Serializable {
       private static final long serialVersionUID = 1L;
       private String name;
       private Object cache;   // Object 未必实现 Serializable
   }
   ```

#### 小结（3 分钟）
- 缓冲流原理：内存批量搬运，减少系统调用
- 逐行处理文本：`readLine + newLine`
- 序列化四要素：Serializable / UID / transient / static
- Java 原生序列化二进制、私有、不跨语言，现代项目用 JSON

### 9.4 板书设计
```text
┌────────────────────────────────────────────┐
│  缓冲流：BufferedIn/Out + BufferedR/W      │
│  优势：数十倍吞吐；readLine/newLine        │
│                                            │
│  序列化四要素：                            │
│    1.implements Serializable               │
│    2.serialVersionUID = 1L                 │
│    3.transient 跳过字段                    │
│    4.static 天然跳过                       │
│  UID 不一致 → InvalidClassException        │
└────────────────────────────────────────────┘
```

### 9.5 课后作业
1. 抄写运行教材 §3.4 + §3.5 全部示例
2. 定义 `Employee(String name, double salary, transient String password)` 序列化到文件再读回，验证 `password` 为 null
3. 独立完成教材 §3 练习题 1、3
4. 挑战：用 JSON 库（如 Jackson）序列化同一个 `User`，对比生成文件大小与可读性

### 9.6 教学反思提示
- 「装饰器模式」名字对学生偏抽象，说「一层套一层」+ 现场演示 `new BufferedX(new FileX(...))` 更好懂
- `serialVersionUID` 学生可能觉得繁琐，一定要用「类升级后老数据读不回」的场景解释必要性

---

## 第 10 课时：线程入门与四种实现方式

### 10.1 教学目标
#### 10.1.1 知识与技能目标
1. 能说出进程与线程的区别：资源分配 vs CPU 调度
2. 能画出 Java 线程与堆 / 栈的共享关系
3. 掌握实现线程的 4 种方式：继承 Thread / 实现 Runnable / Callable + FutureTask / 线程池
4. 能说清 `t.start()` 与 `t.run()` 的本质区别

#### 10.1.2 过程与方法目标
1. 通过一次「误调 run() 只在 main 线程执行」的翻车实验，把 start 与 run 的区别刻在骨子里
2. 通过 Callable 返回 42 的例子，认识「异步计算 + 结果获取」的思想

### 10.2 教学重难点
- **重点**：4 种实现方式的语法与选择 / start vs run 的区别
- **难点**：为什么 `Runnable` 优于 `Thread` 继承 / `Callable` 相对 `Runnable` 增加的两点（返回值 + 抛异常）

### 10.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「上午写的都是一根线跑到底。可现实中我们希望：一边下载文件，一边刷新 UI。这就是**多线程**。」现场打开浏览器的开发者工具，让学生看到「多个 Web Worker」。

#### 新知讲授（20 分钟）
**1. 进程 vs 线程**（板书）

| 概念 | 单位 | 独立性 |
|------|------|--------|
| 进程 | 操作系统**资源分配**最小单位 | 独立地址空间 |
| 线程 | CPU **调度**最小单位 | 共享进程内存 |

**2. 线程的资源图**（板书 Mermaid）
- **每线程独有**：栈、程序计数器
- **进程共享**：堆、方法区、静态变量

这就是「线程安全」问题的根源——多个线程共享同一份可变数据。

**3. 为什么用多线程**
- 提高 CPU 利用率（IO 等待期间干别的）
- 提升响应速度（UI 不卡）
- 多核并行加速

**4. 4 种实现方式**（板书 Mermaid）

**方式一：继承 Thread**
```java
class MyThread extends Thread {
    @Override public void run() { System.out.println("run"); }
}
new MyThread().start();
```

**方式二：实现 Runnable（推荐）**
```java
Runnable r = () -> System.out.println("run");
new Thread(r, "worker-1").start();
```

方式二为什么更好？——**Java 单继承**、任务与线程解耦、可直接给线程池使用。

**方式三：Callable + FutureTask**
- `Runnable` 无返回值、不能抛受检异常
- `Callable<V>` 弥补：有返回值、可抛异常

```java
Callable<Integer> task = () -> { Thread.sleep(1000); return 42; };
FutureTask<Integer> future = new FutureTask<>(task);
new Thread(future).start();
System.out.println(future.get());   // 阻塞等待，输出 42
```

**方式四：线程池**（下节课深讲）
```java
ExecutorService pool = Executors.newFixedThreadPool(4);
pool.submit(() -> System.out.println("hi"));
pool.shutdown();
```

**5. start 与 run 的本质区别**（重要！）

| 调用 | 效果 |
|------|------|
| `t.start()` | 让 JVM 启动新线程，在**新线程**里执行 run() |
| `t.run()` | 只是**普通方法调用**，还在**当前线程**执行 |

#### 示例演示（12 分钟）
现场演示「翻车」：
```java
Thread t = new Thread(() -> {
    System.out.println("running in " + Thread.currentThread().getName());
});
t.run();   // 输出 "running in main"  —— 惊！
t.start(); // 输出 "running in Thread-0"
```
学生对比两行输出，立刻明白差异。

再演示 Callable：
```java
Callable<Long> factorial10 = () -> {
    long r = 1;
    for (int i = 1; i <= 10; i++) r *= i;
    return r;
};
FutureTask<Long> f = new FutureTask<>(factorial10);
new Thread(f).start();
System.out.println("10! = " + f.get());
```

#### 课堂练习（6 分钟）
1. 用「继承 Thread」和「Lambda + Thread」两种方式启动一个线程，都打印 `Thread.currentThread().getName()`，比较输出
2. 判断题：`Callable.call()` 与 `Runnable.run()` 的两个差异是什么？（返回值 + 抛异常）
3. 上机题：修改一段错代码，把 `t.run()` 改为 `t.start()`，观察线程名变化

#### 小结（3 分钟）
- 4 种实现方式记住：继承 Thread、实现 Runnable、Callable、线程池
- **首选 Runnable / Lambda**，其次线程池
- **必须写 start()**，不是 run()

### 10.4 板书设计
```text
┌────────────────────────────────────────────┐
│  进程 vs 线程                              │
│    进程：资源分配单位（独立地址空间）      │
│    线程：CPU 调度单位（共享堆）            │
│                                            │
│  4 种实现方式                              │
│    1.extends Thread                        │
│    2.implements Runnable  ← 首选           │
│    3.Callable + FutureTask（有返回值）     │
│    4.ExecutorService（线程池 = 生产首选）  │
│                                            │
│  start() 启新线程                          │
│  run()   只是普通方法调用                  │
└────────────────────────────────────────────┘
```

### 10.5 课后作业
1. 用 4 种方式各启动一个线程打印线程名，命名 `Demo01`~`Demo04`
2. 用 Callable + FutureTask 计算 `1+2+...+100`，主线程打印结果
3. 挑战：让主线程等 3 个子线程都跑完再退出（提示 `t.join()`）

### 10.6 教学反思提示
- 「t.run() 不启动新线程」这个坑几乎所有初学者都会踩，务必现场演示一次
- Callable 的 `get()` 是阻塞的，一定强调这点，为后续「异步 + Future」打基础

---

## 第 11 课时：线程安全问题与四大解法

### 11.1 教学目标
#### 11.1.1 知识与技能目标
1. 能演示 `count++` 在多线程下丢失更新的现象
2. 能说出丢失更新的根因：**非原子操作 + 共享可变状态**
3. 掌握四大解法：`synchronized`、`ReentrantLock`、原子类、并发集合
4. 认识死锁的成因并说出一条避免经验

#### 11.1.2 过程与方法目标
1. 通过 `Counter` 累加实验，让学生亲眼看到「20000 变 15832」
2. 通过 `AtomicInteger` 与 `synchronized` 两种修复方案的对比，理解「加锁」vs「无锁 CAS」

### 11.2 教学重难点
- **重点**：`synchronized` 用法（方法 / 代码块） / `ReentrantLock` 的 try-finally 模板 / `AtomicInteger`
- **难点**：`count++` 的三步分解 / 死锁的顺序依赖

### 11.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
现场跑教材 §4.3.1 的 Counter 例子——两个线程各加 10000 次，期望 20000，实际 15000-19000 随机变化。学生问「为什么？」——今天的核心问题。

#### 新知讲授（20 分钟）
**1. 丢失更新的根因**（板书）

`count++` 不是一步完成的：
```text
1. 读 count 到 CPU
2. 加 1
3. 写回内存
```
三步之间可以被别的线程插入，导致丢失。

时序图（板书）：
```text
Thread-1: 读 100 → 加1 → 101 → 写回
Thread-2:         读 100 → 加1 → 101 → 写回
最终: 101（本该 102）
```

**2. 方案一：synchronized**
- 同步方法：整个方法加锁
- 同步代码块（推荐，粒度小）：
```java
private final Object lock = new Object();
public void inc() {
    synchronized (lock) { count++; }
}
```
- **静态同步方法** 锁的是 `Xxx.class`

**3. 方案二：ReentrantLock**
```java
private final Lock lock = new ReentrantLock();
public void inc() {
    lock.lock();
    try { count++; }
    finally { lock.unlock(); }   // 一定放 finally
}
```
比 `synchronized` 强在：
- `tryLock(timeout)` —— 有限等待
- `lockInterruptibly()` —— 可中断
- `new ReentrantLock(true)` —— 公平锁
- `newCondition()` —— 多个条件变量

**4. 方案三：原子类（CAS 无锁）**
```java
private final AtomicInteger count = new AtomicInteger(0);
public void inc() { count.incrementAndGet(); }
```
基于硬件 CAS 指令，比 `synchronized` 通常更快。

常用：`AtomicInteger / AtomicLong / AtomicBoolean / AtomicReference / LongAdder`（高并发累加更快）

**5. 方案四：并发集合**

| 常见问题 | 推荐替代 |
|---------|---------|
| `ArrayList` 多线程 | `CopyOnWriteArrayList`（读多写少） |
| `HashMap` 多线程 | `ConcurrentHashMap` |
| `Hashtable`（老，慢） | `ConcurrentHashMap`（分段/桶锁） |

**6. 死锁**
```java
new Thread(() -> { synchronized(A){ sleep; synchronized(B){} } }).start();
new Thread(() -> { synchronized(B){ sleep; synchronized(A){} } }).start();
```
互相等对方持有的锁——**永远卡住**。避免经验：**所有线程按同一顺序获取锁** / 使用 `tryLock`。

#### 示例演示（12 分钟）
现场敲修复 Counter 的三个版本，让学生观察输出：
```java
// 版本 A: synchronized
public synchronized void inc() { count++; }

// 版本 B: ReentrantLock
public void inc() { lock.lock(); try { count++; } finally { lock.unlock(); } }

// 版本 C: AtomicInteger
public void inc() { count.incrementAndGet(); }
```
三个版本输出都稳定为 20000。

再演示一次死锁——两个线程一分钟不结束，用 `jstack` 打印堆栈找出 deadlock。

#### 课堂练习（6 分钟）
1. 用 `synchronized` 和 `AtomicInteger` 两种方式修复 Counter，都验证结果为 20000
2. 找出下列代码的死锁并给出修复方案：
   ```java
   synchronized(A) { synchronized(B) { ... } }   // 线程 1
   synchronized(B) { synchronized(A) { ... } }   // 线程 2
   ```
3. 判断：`Vector` 与 `ConcurrentHashMap` 哪个更适合高并发？为什么？

#### 小结（3 分钟）
- 线程安全根因：非原子操作 + 共享可变状态
- 四大解法：synchronized（简单） / ReentrantLock（灵活） / 原子类（CAS 快） / 并发集合（现成）
- 死锁避免：**同一顺序加锁** + `tryLock`

### 11.4 板书设计
```text
┌────────────────────────────────────────────┐
│  count++ 不是原子操作                      │
│  ① 读 ② 加 ③ 写 —— 三步可被打断          │
│                                            │
│  四大解法：                                │
│    1.synchronized {}                       │
│    2.Lock + try/finally                    │
│    3.AtomicInteger (CAS 无锁)              │
│    4.ConcurrentHashMap / CopyOnWriteAL     │
│                                            │
│  死锁：互等对方的锁 → 同序加锁 + tryLock   │
└────────────────────────────────────────────┘
```

### 11.5 课后作业
1. 抄写运行教材 §4.3 全部示例
2. 用 3 种方式（synchronized / Lock / Atomic）分别修复 Counter，比较 100 万次累加的耗时
3. 挑战：写一段代码故意造成死锁，用 `jstack` 命令查看 deadlock 报告

### 11.6 教学反思提示
- `count++` 三步分解是理解并发的第一块骨牌，可以用「读-加-写」三个动作让两个学生演示
- 死锁演示务必真的做——`jstack` 输出让学生印象深刻，胜过口头解释

---

## 第 12 课时：线程池入门

### 12.1 教学目标
#### 12.1.1 知识与技能目标
1. 能说出「每来一个任务 new Thread」的 4 大问题
2. 认识 `Executor` 体系：`Executor / ExecutorService / ScheduledExecutorService`
3. 会用 `Executors` 工厂方法创建 4 种线程池
4. 能规范关闭线程池（`shutdown` + `awaitTermination`）
5. 理解 `execute` 与 `submit` 的差异（返回值 + 异常处理）

#### 12.1.2 过程与方法目标
1. 通过「并发下载 6 个 URL」的完整例子走完线程池全流程
2. 通过 `Executors.newCachedThreadPool` OOM 的例子，铺垫下节课 `ThreadPoolExecutor` 自建

### 12.2 教学重难点
- **重点**：4 种工厂方法的适用场景 / `shutdown` 与 `shutdownNow` 的区别
- **难点**：为什么 `Executors` 生产不推荐（内部无界队列 / 无界线程数导致 OOM）

### 12.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天写的 `new Thread(...).start()` 每次都创一个线程。假设一秒来 1000 个任务，会怎样？」——引出「频繁创建销毁」的开销和「不受控」的风险。

#### 新知讲授（18 分钟）
**1. 为什么需要线程池**（板书 4 大问题）
- 创建/销毁开销大：线程是 OS 资源
- 数量不可控：任务爆发时可能 OOM
- 管理困难：没法统一 shutdown / 监控 / 限流
- 无法复用：一次性用完

**核心思想**：预先创建一批线程，任务复用。

**2. Executor 体系**（板书 Mermaid classDiagram）

```text
Executor
  ↑
ExecutorService (submit / shutdown / invokeAll)
  ↑
ScheduledExecutorService (schedule / scheduleAtFixedRate)

实现：
  ThreadPoolExecutor
  ScheduledThreadPoolExecutor
```

**3. 4 种工厂方法**（教学用，生产不推荐）

| 工厂方法 | 特点 | 适用场景 |
|---------|------|---------|
| `newFixedThreadPool(n)` | 固定 n 个线程，无界队列 | 已知任务量 |
| `newCachedThreadPool()` | 线程数弹性 0-∞，60s 空闲回收 | 大量短任务 |
| `newSingleThreadExecutor()` | 单线程串行 | 需要顺序执行 |
| `newScheduledThreadPool(n)` | 定时/延时执行 | 定时任务 |

**⚠️ 生产不推荐的原因**：
- `newFixedThreadPool` 内部 `LinkedBlockingQueue()` 无界 → 任务堆积 OOM
- `newCachedThreadPool` 最大线程数 `Integer.MAX_VALUE` → 线程爆炸 OOM

**下一讲会讲用 `ThreadPoolExecutor` 手动指定参数**。

**4. execute vs submit**

| 方法 | 参数 | 返回值 | 异常 |
|------|------|--------|------|
| `execute` | `Runnable` | void | 直接抛到 UncaughtExceptionHandler |
| `submit` | `Runnable / Callable` | `Future` | 异常包装在 Future，`get()` 才抛出 |

**submit 的异常吞噬陷阱**（板书圈红）：
```java
pool.submit(() -> { throw new RuntimeException("boom"); });
// 不 get() 就永远看不到这个异常！
```

**5. 关闭线程池**

```java
pool.shutdown();      // 不再接受新任务，跑完已有任务
pool.shutdownNow();   // 尝试立即中断所有任务
pool.awaitTermination(30, TimeUnit.SECONDS);
```

规范用法（try-finally）：
```java
ExecutorService pool = Executors.newFixedThreadPool(4);
try {
    pool.submit(...);
} finally {
    pool.shutdown();
    if (!pool.awaitTermination(30, TimeUnit.SECONDS)) {
        pool.shutdownNow();
    }
}
```

#### 示例演示（15 分钟）
现场敲教材 §4.4.6 的完整例子——3 个线程并发「下载」6 个 URL：
```java
ExecutorService pool = Executors.newFixedThreadPool(3);
List<String> urls = List.of("A", "B", "C", "D", "E", "F");
List<Future<String>> futures = new ArrayList<>();
for (String url : urls) {
    futures.add(pool.submit(() -> {
        Thread.sleep(500);
        return "已下载 " + url + " by " + Thread.currentThread().getName();
    }));
}
for (Future<String> f : futures) {
    System.out.println(f.get());
}
pool.shutdown();
```

观察输出，可以看到只有 3 个线程名（pool-1-thread-1 到 3）在轮流处理 6 个任务。

再演示 `submit` 的异常吞噬——不 `get()` 时 `RuntimeException("boom")` 神秘消失，`get()` 时才在 `ExecutionException.getCause()` 里现身。

#### 课堂练习（6 分钟）
1. 用 `newFixedThreadPool(4)` 提交 20 个任务，每个任务打印线程名，观察输出
2. 说出以下代码为何不推荐生产使用：
   ```java
   ExecutorService pool = Executors.newCachedThreadPool();
   for (int i = 0; i < 100000; i++) pool.submit(() -> { Thread.sleep(10000); });
   ```
3. 关闭下面代码的线程池：
   ```java
   ExecutorService pool = Executors.newFixedThreadPool(4);
   // TODO: 用 shutdown + awaitTermination
   ```

#### 小结（3 分钟）
- 线程池核心：**池化复用 + 统一管理**
- 4 种工厂方法教学用，生产用 `ThreadPoolExecutor`
- `submit` 有返回值但**吞异常**，一定要 `get()` 或加 UncaughtExceptionHandler
- 关闭用 `shutdown + awaitTermination + shutdownNow` 三段式

### 12.4 板书设计
```text
┌────────────────────────────────────────────┐
│  线程池 = 池化复用 + 统一管理              │
│                                            │
│  Executors 4 种工厂：                      │
│    Fixed(n) / Cached / Single / Scheduled  │
│    生产禁用，内部无界会 OOM                │
│                                            │
│  execute vs submit                         │
│    execute: void, 异常直接抛               │
│    submit:  Future, 异常被吞（get 才抛）   │
│                                            │
│  关闭三段式：                              │
│    shutdown() → awaitTermination()         │
│      → shutdownNow()                       │
└────────────────────────────────────────────┘
```

### 12.5 课后作业（本日汇总）

**必做**：
1. 完成教材 §3 与 §4 全部示例代码抄写与运行
2. 独立完成教材 §3 练习题 1-4、§4 练习题 1-5
3. 综合题：读一个大文本文件（用 `BufferedReader`），把每行的处理任务提交到 `newFixedThreadPool(4)` 并行处理，最后汇总统计词数

**选做**：
1. 阅读 `ThreadPoolExecutor` 源码，找出 7 大参数（为明日 Day03 预习）
2. 用 `Files.walk` + 并行 Stream 实现「统计目录下所有 .java 文件的行数总和」

### 12.6 教学反思提示
- 「Executors 生产禁用」是行业常识，务必强调，为下节课埋伏笔
- `submit` 吞异常的坑几乎每个初学者都会踩过一次，用一段代码演示胜过千言万语

---

## 本日总结

Day02 完成教材第 3、4 讲。学生带走的核心能力：
- **File 与 IO 流**：字节流处理二进制、字符流处理文本、缓冲流几乎必备、序列化四要素
- **线程与并发（上）**：4 种线程实现方式（首选 Runnable）、四大线程安全解法、线程池入门

明日（Day03）主题：**线程与并发（下）——线程池深潜 + 状态转换 + wait/notify + volatile** + **反射**，对应教材第 5、6 讲。请学生课后完成必做作业。
