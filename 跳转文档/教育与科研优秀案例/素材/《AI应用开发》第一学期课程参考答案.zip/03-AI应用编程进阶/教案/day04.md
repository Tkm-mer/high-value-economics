# 《AI 应用编程进阶——Java 进阶》- 教师教案 Day04（第 19-24 课时）

**总课时**：6 课时 × 45 分钟
**授课对象**：已完成 Day03（线程进阶、反射）的大学一年级学生
**知识点覆盖**：注解（3 课时） + 集合精讲（3 课时）
**参考教材**：`../教材/chapters/07.md`、`08.md`

---

## 本日知识地图

```mermaid
flowchart LR
    subgraph G1["上午 · 注解 & 反射"]
        direction LR
    L19["第 19 课时<br/>注解基础 & JDK 内置"]
    L20["第 20 课时<br/>元注解 & 自定义注解"]
    L21["第 21 课时<br/>反射解析注解 + 迷你 @Test"]
    end
    subgraph G2["下午 · 集合"]
        direction LR
    L22["第 22 课时<br/>集合框架 & Arrays"]
    L23["第 23 课时<br/>Collections & LinkedList"]
    L24["第 24 课时<br/>TreeSet & TreeMap"]
    end
    L19 --> L20 --> L21
    L22 --> L23 --> L24
    L21 -.承接.-> L22
```

> 6 个课时按「注解 & 反射 → 集合」两大板块递进；上午打基础，下午做延伸，最后一课时做本日综合练习。

---

## 教学准备

### 环境准备
1. **JDK 25 LTS**：沿用；本讲用到 `java.lang.annotation.*`、`Class#getAnnotationsByType`、`SequencedCollection`（JDK 21+）等 API。
2. **IntelliJ IDEA（下简称 IDEA） 工程**：`day04-annotation-collections/`，含 `annobasic`（内置注解）、`annometa`（元注解四兄弟）、`annoprocess`（反射读取注解 + 简易 IoC 容器）、`collections`（List/Set/Map/Queue 对比 + `SequencedCollection`）四个包。
3. **AI 编码工具**：教师机打开通义灵码 / GitHub Copilot / Cursor 其一，用于「用 AI 生成一个测试框架小抄」环节做现场演示；学生机需已装好插件并登录，未装的临时用 Web 版。
4. **示例数据集**：预生成 `students.csv`（100 行学号+姓名+成绩），放到 `resources/`，用于集合遍历与 `Collectors` 演示。
5. **投影分屏**：左半屏 IDEA 代码 + 右半屏 AI 对话窗，便于演示「代码 - Prompt - 回答」循环。

### 学情预设
- 前置：Day03 反射已通过；`@Override`、`@Deprecated` 见过但不解释来路；集合三大接口 `List / Set / Map` 会用 API。
- 预计易混：注解 vs 反射（注解是元数据，反射是读元数据的手段）、`@Retention` 三种策略（SOURCE / CLASS / RUNTIME）、`ArrayList` vs `LinkedList` 性能对比。
- 预计基础差距：约 30% 学生没写过自定义注解，需先在导入用「贴标签」类比；`SequencedCollection` 是 JDK 21 新增，全班都新，作为拓展点讲。

### 教具与板书素材
- 打印 A4：「元注解四兄弟 @Target/@Retention/@Documented/@Inherited 速查」+「集合三大接口继承图（含 `SequencedCollection`）」，一人一份。
- 板书左侧划「注解生命周期时间轴」（源码 → class 文件 → 运行时），右侧留「集合复杂度对照表」。

### 前置检查（上课前 5 分钟完成）
- 全班执行 `List.of(1,2,3).reversed()`（一句 jshell），验证 `SequencedCollection` 可用；若报错则 JDK 版本不对。
- AI 编码插件登录状态检查：随机点名 2 台学生机让其发一条 Prompt 出内容，避免课堂上 AI 无响应。
- `students.csv` 拷贝到位，`Files.lines(Path.of("resources/students.csv")).count()` 输出 100 才可开讲。

---

## 第 19 课时：注解基础与 JDK 内置注解

### 19.1 教学目标
#### 19.1.1 知识与技能目标
1. 能说清「注解」定义：代码上的元数据、不改逻辑
2. 能对比「注解 vs 注释」的 4 个差异
3. 认识注解的 3 种保留时机：SOURCE / CLASS / RUNTIME
4. 熟练使用 5 个常用内置注解：`@Override` / `@Deprecated` / `@SuppressWarnings` / `@SafeVarargs` / `@FunctionalInterface`

#### 19.1.2 过程与方法目标
1. 通过「写错方法名却没写 `@Override` → 编译通过但运行不正确」的翻车实验，理解 `@Override` 的价值
2. 通过反编译看到「`public @interface` = 特殊接口」，理解注解本质

### 19.2 教学重难点
- **重点**：注解 vs 注释、5 个内置注解的用法、3 种 Retention
- **难点**：`@Retention` 决定注解能被谁读到；`@Override` 是编译期检查

### 19.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「上节课我们已经用了 `@Test`、`@Autowired` 这些标签。它们看着像注释，但会影响程序——今天弄清什么是**注解**。」

翻车演示：
```java
class A { public String toString() { return "A"; } }
class B extends A { public String tostring() { return "B"; } }   // 拼错！
System.out.println(new B().toString());   // 输出 A —— 没覆盖成功
```
加上 `@Override`：编译直接报错。→ 注解在**保护**你。

#### 新知讲授（20 分钟）
**1. 注解定义**

代码上的**元数据**：给编译器 / 框架 / 工具打的标签，本身不改变程序逻辑。

**2. 注解 vs 注释**（板书对比表）

| 项 | 注释 `// /* */` | 注解 `@Xxx` |
|----|-----------------|-------------|
| 语法 | `//` 或 `/* */` | `@注解名(...)` |
| 是否进字节码 | 不进（Javadoc 只作文档） | **通常进**（受 Retention 控制） |
| 谁看得懂 | 只有人 | 编译器、框架、工具、人 |
| 是否影响程序 | 不影响 | 可能影响（框架据此变化行为） |

**3. 保留时机**（板书 Mermaid）
```text
SOURCE   —— 只在源码期，编译丢弃（如 @Override）
CLASS    —— 进字节码但运行时反射看不到（默认）
RUNTIME  —— 运行时反射可读（框架最常用）
```

**4. 5 个常用内置注解**

| 注解 | 作用 |
|------|------|
| `@Override` | 声明重写父类方法，编译期检查签名 |
| `@Deprecated` | 标注过时，调用告警；可加 `since` / `forRemoval` |
| `@SuppressWarnings("...")` | 抑制编译警告（`"unchecked"`、`"rawtypes"`） |
| `@SafeVarargs` | 声明可变参数使用安全（泛型可变参数） |
| `@FunctionalInterface` | 声明函数式接口（有且仅有一个抽象方法） |

**5. 注解的本质**（板书）
```java
public @interface Test {}
// 反编译近似：
public interface Test extends java.lang.annotation.Annotation {}
```
`@interface` = 特殊接口。运行时读到的注解实例是 JDK 生成的**动态代理**对象（呼应上节课的动态代理）。

#### 示例演示（14 分钟）
现场演示各内置注解：
```java
@Deprecated(since = "1.5", forRemoval = true)
public void oldMethod() { }

@SuppressWarnings({ "unchecked", "rawtypes" })
public void mix() {
    List list = new ArrayList();
    list.add("x");
}

@FunctionalInterface
public interface Converter<T, R> {
    R convert(T t);
    // R convert2(T t);   // 报错！
    default void hello() { }   // 默认方法允许
}
```

再让学生看 `@Override` 的编译期保护：删掉 `@Override` 拼错方法名 → 编译通过、行为不对；加回 `@Override` → 编译期直接报错。

#### 课堂练习（4 分钟）
1. `@Override` 是运行时读取还是编译期读取？（编译期，Retention=SOURCE）
2. 判断：`@FunctionalInterface` 接口允许有默认方法吗？（允许，只限制抽象方法数）
3. `@Deprecated(since="1.5", forRemoval=true)` 中 `forRemoval` 的含义？（预计移除，警告更强）

#### 小结（3 分钟）
- 注解 = 代码上的元数据、可被编译器/框架读取
- 注解 vs 注释：能否进字节码、能否影响程序
- 5 个内置注解要记住
- 本质：注解 = 特殊接口 + 运行时动态代理

### 19.4 板书设计
```text
┌────────────────────────────────────────────┐
│  注解 = 代码元数据                         │
│  vs 注释：进字节码、影响程序               │
│                                            │
│  3 种 Retention：                          │
│    SOURCE  → 编译期 (@Override)            │
│    CLASS   → 字节码 (默认)                 │
│    RUNTIME → 反射 (框架用)                 │
│                                            │
│  5 内置：                                  │
│    @Override / @Deprecated                 │
│    @SuppressWarnings / @SafeVarargs        │
│    @FunctionalInterface                    │
└────────────────────────────────────────────┘
```

### 19.5 课后作业
1. 抄写运行教材 §7.1 + §7.2 全部示例
2. 判断题（写在纸上）：以下哪些能加 `@Override`？请说明为什么。
   - 重写父类方法 ✓
   - 实现接口方法 ✓
   - 覆盖 static 方法 ✗
   - 私有方法 ✗
3. 试写一个 `@FunctionalInterface` 接口，加 3 个默认方法看是否编译通过

### 19.6 教学反思提示
- 「注解本质是特殊接口」学生偏抽象，用「@interface 反编译成 interface」演示更直观
- 内置注解虽小但重要，务必让学生亲手写 `@Override` 拼错方法名，体验编译期保护

---

## 第 20 课时：元注解与自定义注解

### 20.1 教学目标
#### 20.1.1 知识与技能目标
1. 掌握 4 大元注解：`@Target` / `@Retention` / `@Documented` / `@Inherited`
2. 会自定义注解：语法、属性、默认值、value 简写
3. 认识注解属性的类型限制（基本类型 / String / Class / 枚举 / 注解 / 数组）
4. 认识 `@Repeatable` 允许重复的用法

#### 20.1.2 过程与方法目标
1. 通过「注解属性写 List<String> → 编译报错」的翻车，理解属性类型限制
2. 通过自定义 `@Log` 注解体验完整定义流程

### 20.2 教学重难点
- **重点**：`@Target` + `@Retention` 组合 / 属性语法 / value 简写
- **难点**：属性类型限制（为什么不允许 `List<String>`）

### 20.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「上节课用的都是别人定义好的注解。今天学**自己定义注解**——自定义 = 元注解 + `@interface` + 属性。」

#### 新知讲授（20 分钟）
**1. 元注解 4 剑客**（板书）

| 元注解 | 作用 |
|--------|------|
| `@Target` | 允许出现在哪些位置 |
| `@Retention` | 保留到哪个阶段 |
| `@Documented` | 是否生成到 Javadoc |
| `@Inherited` | 子类是否自动继承父类上的这个注解（**仅类注解**生效） |

**`@Target` 常用值**（板书）
```text
TYPE           类/接口/枚举/注解
METHOD         方法
FIELD          字段
PARAMETER      参数
CONSTRUCTOR    构造器
LOCAL_VARIABLE 局部变量
TYPE_PARAMETER 类型参数 (Java 8+)
TYPE_USE       任意类型使用处 (Java 8+)
```

**`@Retention` 3 个值**：SOURCE / CLASS / RUNTIME（重申一遍，重要！）

**2. 自定义注解语法**（板书模板）
```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface 注解名 {
    属性类型 属性名() default 默认值;
}
```

**3. 属性支持的类型**（编译器强制）
- 基本类型（int / long / double / boolean 等）
- String
- Class 或 Class<?>
- 枚举
- 注解
- 上述任意类型的**一维数组**

其他类型（如 `List<String>`）**不允许**——为什么？因为注解要在编译期序列化到 class 文件常量池，只支持这些「常量」类型。

**4. 第一个自定义注解**（板书）
```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Log {
    String value() default "";
    Level level() default Level.INFO;
    String[] tags() default {};
}
```

使用：
```java
@Log("查询用户")
public void findUser() { }

@Log(value = "创建订单", level = Level.WARN, tags = {"order", "audit"})
public void createOrder() { }
```

**3 个语法糖**：
- 属性名叫 `value` 且只有它一个赋值 → 可省 `value =`
- 属性无默认值 → 使用者**必须**显式赋值
- 数组只有一个元素 → 可省大括号：`tags = "order"`

**5. `@Repeatable` 重复注解**
```java
@Repeatable(Roles.class)
@Retention(RetentionPolicy.RUNTIME)
public @interface Role { String value(); }

@Retention(RetentionPolicy.RUNTIME)
public @interface Roles { Role[] value(); }

@Role("admin")
@Role("editor")
public class UserService { }
```
需要额外定义**容器注解**（`Roles`），元素是数组。

**6. 常见错误**（板书）
- 忘 `@Retention(RUNTIME)`，反射读不到
- 忘 `@Target`，用错位置
- 属性用了 `List` 等不允许类型
- 重构改动名字导致框架崩溃

#### 示例演示（16 分钟）
现场完整定义 `@Log` 注解并使用。翻车演示：把 `String[] tags()` 改成 `List<String> tags()` → 编译错误，让学生看编译器提示。

再演示 value 简写 vs 完整写法的等价性：
```java
@Log("hi")           // 等价于
@Log(value = "hi")
```

演示 `@Repeatable`：`@Role` 贴两次并用反射读出：
```java
Role[] rs = UserService.class.getAnnotationsByType(Role.class);
for (Role r : rs) System.out.println(r.value());   // admin, editor
```

#### 课堂练习（3 分钟）
1. 说出 4 个元注解的作用
2. 判断：注解属性可以是 `int[]` 吗？可以是 `List<Integer>` 吗？（可 / 不可）
3. 用 `@Target(FIELD)` + `@Retention(RUNTIME)` 定义 `@Column(String name())`

#### 小结（3 分钟）
- 元注解 4 剑客：Target / Retention / Documented / Inherited
- 自定义注解 = 元注解 + `@interface` + 属性
- 属性类型受限，运行时读取必须 RUNTIME
- 重复注解需要容器注解 + `@Repeatable`

### 20.4 板书设计
```text
┌────────────────────────────────────────────┐
│  元注解 4 剑客                             │
│    @Target / @Retention                    │
│    @Documented / @Inherited                │
│                                            │
│  自定义模板：                              │
│  @Target(METHOD)                           │
│  @Retention(RUNTIME)                       │
│  public @interface Log {                   │
│    String value() default "";              │
│    String[] tags() default {};             │
│  }                                         │
│                                            │
│  属性类型：基本/String/Class/枚举/注解     │
│           + 上述的一维数组                 │
└────────────────────────────────────────────┘
```

### 20.5 课后作业
1. 抄写运行教材 §7.3.1 + §7.3.2 全部示例
2. 定义 `@BindURL(String value())`，只允许方法上，Retention=RUNTIME。写 3 个使用示例
3. 定义 `@Range(int min(), int max())`，允许字段上
4. 挑战：为什么注解不允许 `List<String>` 属性？（提示：想想常量池）

### 20.6 教学反思提示
- 「属性类型受限」是学生问最多的问题，回答从 class 文件格式讲一句即可，不必展开
- 让学生亲手写一个 `@Log`，比反复看示例效果好

---

## 第 21 课时：反射解析注解与迷你测试框架

### 21.1 教学目标
#### 21.1.1 知识与技能目标
1. 熟练用反射读取注解：`isAnnotationPresent` / `getAnnotation` / `getAnnotationsByType`
2. 能写出**迷你 @Test 框架**：扫描 `@Test` 方法 → 反射调用 → 打印结果
3. 认识「注解 + 反射」是所有 Java 框架的核心公式
4. 掌握 Bean 验证的雏形写法（`@Range` + Validator）

#### 21.1.2 过程与方法目标
1. 通过一个完整的迷你测试框架把「反射 + 注解」串起来
2. 通过 `@Range` 校验器把「元编程」思想落地到业务场景

### 21.2 教学重难点
- **重点**：反射读注解的 3 个 API / 迷你 `@Test` 完整代码 / 注解+反射公式
- **难点**：`m.getAnnotation(Log.class)` 返回的是**动态代理对象**（呼应上节课反射）

### 21.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天讲注解的『定义』，今天讲注解的『使用』——反射读它、然后做点事。这一节课把这学期最重要的公式**注解 + 反射 = 元编程**串起来。」

#### 新知讲授（16 分钟）
**1. 反射读注解 3 个 API**（板书）
```java
// 是否有某注解
m.isAnnotationPresent(Log.class);

// 拿到单个注解（含属性值）
Log log = m.getAnnotation(Log.class);
log.value();  log.level();  log.tags();

// 拿到所有该类型注解（Repeatable 用）
Role[] rs = clazz.getAnnotationsByType(Role.class);
```

**前提**：注解声明为 `@Retention(RUNTIME)`。

**2. 「注解 + 反射」核心公式**（板书 Mermaid）
```text
①自定义注解 → 贴在类/方法/字段上
② 反射扫描
③ 读到注解就做特殊处理
   → 无需改被扫描类代码就实现横切逻辑
```

框架应用（板书对照表）：

| 框架 | 使用的注解 | 反射后做什么 |
|------|-----------|-------------|
| Spring | `@Component` | 创建 Bean |
| Spring | `@Autowired` | 注入依赖 |
| Spring MVC | `@RequestMapping` | 建立 URL → 方法映射 |
| MyBatis | `@Select` / `@Insert` | 生成 SQL 与执行 |
| JUnit | `@Test` / `@Before` | 组织测试生命周期 |
| Bean Validation | `@NotNull` / `@Size` | 字段验证 |

**3. 迷你 `@Test` 测试框架**（板书完整代码）

需求：扫描类里带 `@Test` 的方法并逐一执行，报告通过 / 失败。

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Test { }

public class MiniRunner {
    public static void run(Class<?> testClass) throws Exception {
        Object instance = testClass.getDeclaredConstructor().newInstance();
        int pass = 0, fail = 0;
        for (Method m : testClass.getDeclaredMethods()) {
            if (!m.isAnnotationPresent(Test.class)) continue;
            long start = System.currentTimeMillis();
            try {
                m.setAccessible(true);
                m.invoke(instance);
                System.out.printf("✅ %s (%d ms)%n", m.getName(),
                                  System.currentTimeMillis() - start);
                pass++;
            } catch (Exception e) {
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                System.out.printf("❌ %s -> %s%n", m.getName(), cause);
                fail++;
            }
        }
        System.out.printf("总计 %d 通过 %d 失败%n", pass, fail);
    }
}
```

使用：
```java
public class CalcTest {
    @Test public void plus()  { if (1 + 1 != 2) throw new AssertionError(); }
    @Test public void minus() { if (2 - 1 != 1) throw new AssertionError(); }
    @Test public void bug()   { throw new RuntimeException("故意失败"); }
    public void notTest()     { throw new RuntimeException("不会被跑"); }
}

MiniRunner.run(CalcTest.class);
```

输出：
```text
✅ plus (0 ms)
✅ minus (0 ms)
❌ bug -> java.lang.RuntimeException: 故意失败
总计 2 通过 1 失败
```

**60 行搞定 JUnit 核心**——这就是元编程的威力。

**4. `@Range` Bean 验证器**（板书简版）
```java
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Range { int min(); int max(); }

public static void validate(Object obj) throws Exception {
    for (Field f : obj.getClass().getDeclaredFields()) {
        if (f.isAnnotationPresent(Range.class)) {
            Range r = f.getAnnotation(Range.class);
            f.setAccessible(true);
            int v = f.getInt(obj);
            if (v < r.min() || v > r.max())
                throw new IllegalArgumentException(f.getName() + " 超范围: " + v);
        }
    }
}

class User {
    @Range(min=0, max=150) int age;
    User(int a) { age = a; }
}
validate(new User(200));   // 抛异常：age 超范围: 200
```

### 21.3.1 示例演示（18 分钟）

现场从 0 敲完 MiniRunner，让学生亲眼看到「30 行代码模仿 JUnit」。演示 `@Test` 方法被反射调用、私有方法也能跑（`setAccessible`）。

再演示 `@Range` 验证器。让学生想想：Spring / Jakarta Bean Validation 的 `@NotNull @Size @Email` 本质就是这个思路，只是把「反射扫描」放进了 AOP 拦截器。

#### 课堂练习（5 分钟）
1. 反射读注解的 3 个 API 分别是什么？
2. 注解必须声明什么 Retention 才能被反射读到？（RUNTIME）
3. 写一个 `@Print` 字段注解 + `printFields(Object)` 方法只打印带 `@Print` 的字段

#### 小结（3 分钟）
- 反射读注解 3 API：`isAnnotationPresent` / `getAnnotation` / `getAnnotationsByType`
- **注解 + 反射 = 元编程** —— Spring / MyBatis / JUnit / Jackson 的底层公式
- 迷你 `@Test`：30 行搞定 JUnit 核心
- 前提：`@Retention(RUNTIME)`

### 21.4 板书设计
```text
┌────────────────────────────────────────────┐
│  反射读注解 3 API：                        │
│    isAnnotationPresent(Xxx.class)          │
│    getAnnotation(Xxx.class)                │
│    getAnnotationsByType(Xxx.class)         │
│                                            │
│  注解 + 反射 = 元编程 (核心公式)           │
│    1.@Xxx 贴在成员上                       │
│    2.反射扫描                              │
│    3.读到就做特殊处理                      │
│                                            │
│  MiniRunner：30 行模仿 JUnit               │
└────────────────────────────────────────────┘
```

### 21.5 课后作业（本日上半汇总）
1. 完成教材 §7 全部示例代码抄写与运行
2. 独立完成教材 §7 练习题 1、2、3、4
3. 综合题：仿造 Spring 实现玩具版 `@Component + @Autowired`，扫描类列表创建 Bean 并注入
4. 挑战：给 MiniRunner 增加 `@Before` / `@After` 支持，让每个测试前后执行钩子

### 21.6 教学反思提示
- MiniRunner 是本节课的高潮，务必让学生亲眼看到「30 行搞定 JUnit」的顿悟感
- `@Range` 验证器把注解从「花架子」变成「真业务」，用它承接下节 Spring 引入

---

## 第 22 课时：集合框架回顾与 Arrays 工具类

### 22.1 教学目标
#### 22.1.1 知识与技能目标
1. 能画出 Collection / Map 两大家谱树
2. 掌握集合选择要点：`ArrayList` vs `ArrayDeque` vs `HashSet` vs `HashMap` 等的适用场景
3. 熟练使用 `Arrays` 工具类：`toString / sort / binarySearch / copyOf / fill / equals / asList / stream`
4. 认识 `Arrays.asList` 返回**固定长度视图**的坑

#### 22.1.2 过程与方法目标
1. 通过「`Arrays.asList` add 抛异常」的翻车，把这个坑刻死
2. 通过 `Arrays.sort` 的多种重载，练习 `Comparator` 组合

### 22.2 教学重难点
- **重点**：`Arrays.toString / deepToString` / 三种 `sort` 重载 / `asList` 的坑
- **难点**：`Arrays.binarySearch` 找不到时的返回值 `-(insertion) - 1`

### 22.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「上学期已经学过 List / Set / Map。本讲用 3 节课深挖工具类和常用类。今天从 `Arrays` 开始——数组的『瑞士军刀』。」

#### 新知讲授（18 分钟）
**1. 集合家谱回顾**（板书 Mermaid）
```text
Iterable
  └ Collection
      ├ List: ArrayList / LinkedList / Vector
      ├ Set:  HashSet / LinkedHashSet / TreeSet
      └ Queue → Deque: ArrayDeque / LinkedList
                Queue: PriorityQueue

Map (独立)
  ├ HashMap / LinkedHashMap / TreeMap
  ├ Hashtable (老)
  └ ConcurrentHashMap (并发)
```

**选择要点**（板书对照）
| 需求 | 首选 |
|------|------|
| 顺序 + 下标随机访问 | `ArrayList` |
| 头尾插入 / 队列 / 栈 | `ArrayDeque`（**优于** LinkedList） |
| 唯一 & 无序 | `HashSet` |
| 唯一 & 插入序 | `LinkedHashSet` |
| 唯一 & 自然序 | `TreeSet` |
| K→V 快速查 | `HashMap` |
| K→V 按 key 排序 | `TreeMap` |

**2. Arrays 工具类 7 类操作**

**打印**：
```java
Arrays.toString(new int[]{1,2,3});          // [1, 2, 3]
Arrays.deepToString(new int[][]{{1,2},{3,4}});  // [[1, 2], [3, 4]]
```

**排序**（3 种重载）：
```java
Arrays.sort(a);                        // 升序
Arrays.sort(b, Comparator.reverseOrder());   // 逆序（对象数组）
Arrays.sort(c, 1, 4);                  // 部分排序 [1, 4)
```
基本类型数组**不能**传 Comparator（因为泛型不能装箱）。

**二分查找**（**必须先排序！**）：
```java
int i = Arrays.binarySearch(a, 3);     // 找到 → 索引
int j = Arrays.binarySearch(a, 2);     // 找不到 → -(插入点)-1
```

**复制**：
```java
Arrays.copyOf(a, 3);                   // 前 3 个
Arrays.copyOf(a, 7);                   // 长于原数组，末尾补 0
Arrays.copyOfRange(a, 1, 4);           // [1, 4)
```

**填充与比较**：
```java
Arrays.fill(a, 7);
Arrays.equals(x, y);                   // 元素相等（不是引用比较！）
```

**数组转 List**（板书圈红 —— **坑**）：
```java
List<String> list = Arrays.asList("a", "b", "c");
list.add("d");   // ❌ UnsupportedOperationException —— 固定长度视图！
```

要可变：`new ArrayList<>(Arrays.asList(...))`
Java 9+ 更简洁：`List.of("a","b","c")`（**不可变**）

**Stream 化**：
```java
int sum = Arrays.stream(new int[]{1,2,3,4}).sum();
double avg = Arrays.stream(new int[]{1,2,3,4}).average().orElse(0);
```

#### 示例演示（15 分钟）
现场演示每类操作，让学生看输出。

**翻车实验 1**：`Arrays.asList` 上 add：
```java
List<String> list = Arrays.asList("a", "b");
list.add("c");   // Exception in thread ...
```
学生看到才印象深刻。

**翻车实验 2**：`==` vs `Arrays.equals`：
```java
int[] x = {1,2,3};
int[] y = {1,2,3};
System.out.println(x == y);              // false
System.out.println(Arrays.equals(x, y)); // true
```

**Comparator 组合**：
```java
String[] arr = {"banana", "kiwi", "apple", "fig"};
Arrays.sort(arr, Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()));
System.out.println(Arrays.toString(arr));   // [fig, kiwi, apple, banana]
```

#### 课堂练习（5 分钟）
1. 写代码：`Arrays.sort` 让 `Integer[]` 数组降序
2. `Arrays.binarySearch` 找不到时返回什么？（`-(插入点)-1`）
3. `Arrays.asList(...)` 得到的 List 能不能 add？（不能，固定长度）

#### 小结（3 分钟）
- Arrays 是操作数组的静态工具集合
- 排序 3 种重载；二分找不到返回负数
- `asList` 是固定长度视图，别 add
- 数组比较用 `Arrays.equals`，不能 `==`

### 22.4 板书设计
```text
┌────────────────────────────────────────────┐
│  Arrays 常用：                             │
│    toString / deepToString                 │
│    sort (3 种重载)                         │
│    binarySearch (必须先排序)               │
│    copyOf / copyOfRange                    │
│    fill / equals                           │
│    asList (固定长度视图)                   │
│    stream                                  │
│                                            │
│  binarySearch 未找到 → -(insert)-1         │
│  asList 需可变 → new ArrayList<>(...)      │
└────────────────────────────────────────────┘
```

### 22.5 课后作业
1. 抄写运行教材 §8.1 + §8.2 全部示例
2. 用 `Arrays.sort` + Comparator 对字符串数组按长度升序、长度相同按字典序排
3. 挑战：写 `int[] merge(int[] a, int[] b)` 合并两个已排序数组，返回排好序的新数组（用 `Arrays.copyOf`）

### 22.6 教学反思提示
- 学生最容易忘：`Arrays.equals` 而不是 `==`
- `Arrays.asList` 的坑一定要真的演示一次，光说没用

---

## 第 23 课时：Collections 工具类与 LinkedList

### 23.1 教学目标
#### 23.1.1 知识与技能目标
1. 熟练使用 `Collections`：`sort` / `binarySearch` / `reverse` / `shuffle` / `max` / `min` / `frequency`
2. 认识 `Collections` 的三种「视图」方法：不可变、空、单元素
3. 掌握 `LinkedList` 的双端 API：`addFirst/Last`、`push/pop`、`offer/poll`
4. 能用 `LinkedList` 或 `ArrayDeque` 作队列 / 栈

#### 23.1.2 过程与方法目标
1. 对比 `ArrayList` vs `LinkedList` 的操作复杂度，理解为什么 `ArrayDeque` 现代场景更优
2. 通过「浏览器前进后退」小例子把 Deque 语义落地

### 23.2 教学重难点
- **重点**：`Collections` 8 个常用静态方法 / Deque 6 组双端方法
- **难点**：`push/pop`（栈）vs `offer/poll`（队列）的区别 —— 栈是**头进头出**，队列是**尾进头出**

### 23.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「昨天 `Arrays` 处理数组，今天 `Collections` 处理集合——名字很像但作用不同（注意 `Collection` 是接口、`Collections` 才是工具类）。」

#### 新知讲授（18 分钟）
**1. Collections 常用方法**（板书）

排序与查找：
```java
Collections.sort(list);
Collections.sort(list, Comparator.reverseOrder());
Collections.reverse(list);         // 就地反转
Collections.shuffle(list);         // 随机打乱
Collections.binarySearch(list, x); // 需先排好序
Collections.max(list) / Collections.min(list);
```

统计与替换：
```java
Collections.frequency(list, x);
Collections.replaceAll(list, old, newV);
Collections.fill(list, 0);
```

视图方法：
```java
Collections.unmodifiableList(list);   // 不可变包装
Collections.emptyMap();
Collections.singletonList("x");
```

线程安全包装（局限：遍历仍需外部同步）：
```java
List<String> sync = Collections.synchronizedList(new ArrayList<>());
synchronized (sync) { for (String s : sync) { ... } }   // 遍历必须锁
```
高并发优先 `ConcurrentHashMap` / `CopyOnWriteArrayList`。

**2. LinkedList 深入**

**结构图**（板书）：
```text
head ⇄ node A ⇄ node B ⇄ node C ⇄ tail
```

**与 ArrayList 对比表**：
| 操作 | ArrayList | LinkedList |
|------|-----------|------------|
| `get(i)` 随机访问 | O(1) | O(n) |
| 尾部添加 | 平均 O(1) | O(1) |
| 头部添加 | O(n)（搬） | O(1) |
| 中间插入 | O(n) | 定位 O(n) + 插入 O(1) |
| 内存 | 紧凑 | 每节点 2 个额外引用 |

**结论**：现代 Java 中 LinkedList 几乎冷落——即使当队列/栈也用 **ArrayDeque** 更快。仍讲它是为理解「链表 + Deque 语义」。

**3. Deque 双端 API**（板书 6 组）
```text
addFirst  / addLast       —— 头/尾添加（满则抛异常）
offerFirst/ offerLast     —— 头/尾添加（满则返 false）
getFirst  / getLast       —— 头/尾查看（空则抛异常）
peekFirst / peekLast      —— 头/尾查看（空返 null）
removeFirst / removeLast  —— 头/尾移除（空则抛）
pollFirst / pollLast      —— 头/尾移除（空返 null）

栈语义：push(e) = addFirst;  pop() = removeFirst
队列语义：offer(e) = offerLast;  poll() = pollFirst
```

**4. 当队列 / 栈用**

队列（FIFO）：
```java
Deque<String> q = new LinkedList<>();
q.offer("a"); q.offer("b"); q.offer("c");
while (!q.isEmpty()) System.out.println(q.poll());   // a b c
```

栈（LIFO）：
```java
Deque<String> s = new LinkedList<>();
s.push("a"); s.push("b"); s.push("c");
while (!s.isEmpty()) System.out.println(s.pop());    // c b a
```
Java 官方推荐 `Deque` 替代老的 `Stack` 类（后者继承 Vector，慢）。

**5. 迭代器安全删除**
```java
Iterator<Integer> it = list.iterator();
while (it.hasNext()) {
    if (it.next() < 0) it.remove();   // ✅ 安全
}
```
**for-each + `list.remove(...)`** 会抛 `ConcurrentModificationException`！

#### 示例演示（16 分钟）
现场演示 `Collections` 常用方法与 `Deque` 队列 / 栈。

**浏览器前进后退**小例子（栈的经典应用）：
```java
Deque<String> back = new ArrayDeque<>();
Deque<String> forward = new ArrayDeque<>();
String cur = null;

// visit(url)
cur = "home";
back.push("home");

cur = "search";
back.push(cur);   forward.clear();

cur = "detail";
back.push(cur);   forward.clear();

// back()
if (back.size() > 1) {
    forward.push(back.pop());
    cur = back.peek();
}
System.out.println("现在在：" + cur);   // search

// forward()
if (!forward.isEmpty()) {
    String u = forward.pop();
    back.push(u);
    cur = u;
}
System.out.println("现在在：" + cur);   // detail
```

翻车演示：`for-each` 边遍历边 `list.remove(x)` → `ConcurrentModificationException`。改用迭代器 `it.remove()` 即可。

#### 课堂练习（5 分钟）
1. 说出 `push/pop` 与 `offer/poll` 的区别（栈 vs 队列，也就是从哪端操作）
2. `Collections.synchronizedList` 遍历时还需要什么？（外部同步块）
3. 判断：`for-each` 遍历中调 `list.remove(x)` 会怎样？（CME）

#### 小结（3 分钟）
- `Collections` 8 类方法：排序 / 查找 / 反转 / 打乱 / 统计 / 替换 / 视图 / 线程包装
- LinkedList 结构熟悉即可，实用优先 `ArrayDeque`
- Deque 6 组双端方法；栈 push/pop，队列 offer/poll
- 遍历中删除必须用 `Iterator.remove`

### 23.4 板书设计
```text
┌────────────────────────────────────────────┐
│  Collections 常用：                        │
│    sort / binarySearch / reverse           │
│    shuffle / max / min / frequency         │
│    unmodifiableXxx / emptyXxx              │
│    synchronizedXxx                         │
│                                            │
│  Deque 双端：                              │
│    addFirst/Last  offerFirst/Last          │
│    getFirst/Last  peekFirst/Last           │
│    removeFirst/Last pollFirst/Last         │
│                                            │
│  栈：push/pop   队列：offer/poll           │
│  Stack 类已淘汰 → 用 Deque                 │
└────────────────────────────────────────────┘
```

### 23.5 课后作业
1. 抄写运行教材 §8.3 + §8.4 全部示例
2. 用 `LinkedList` 实现浏览器「前进 / 后退 / 访问」的完整类
3. 用 `Collections.shuffle + Collections.sort` 把一副扑克牌（52 张）洗牌后按花色 + 点数排序

### 23.6 教学反思提示
- `Stack` 类淘汰这一点要强调，学生课本可能仍在教
- `Iterator.remove` 是唯一安全删除方式，要现场演示 CME

---

## 第 24 课时：TreeSet 与 TreeMap

### 24.1 教学目标
#### 24.1.1 知识与技能目标
1. 认识 `TreeSet` / `TreeMap` 基于红黑树，O(log n)
2. 会通过 `Comparable` 或 `Comparator` 自定义排序
3. 熟练使用导航方法：`first / last / floor / ceiling / lower / higher / subSet / headSet / tailSet`
4. 认识「Comparator == 0 视为相同」的去重坑

#### 24.1.2 过程与方法目标
1. 通过「按长度排序 → 只按长度会去重」的翻车，理解「排序规则要与 equals 一致」
2. 通过字典功能例子体验 TreeMap 的**范围查询**能力

### 24.2 教学重难点
- **重点**：Comparator 构造 TreeSet / 8 个导航方法
- **难点**：`compare() == 0` 被视为「相同」→ 排序规则必须与 equals 语义一致

### 24.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
「今天讲有序集合。前面的 HashSet / HashMap 都是无序；TreeSet / TreeMap 自动排序、还能范围查询——是词典、排行榜、时间线的天然选择。」

#### 新知讲授（18 分钟）
**1. 结构与性能**（板书）
- 底层：**红黑树**（平衡二叉搜索树）
- 增/删/查：**O(log n)**（比 HashSet 慢一个 log，换来有序）
- 元素自动排序，遍历有序

**2. TreeSet 基础**
```java
TreeSet<Integer> set = new TreeSet<>();
set.add(3); set.add(1); set.add(4); set.add(1);
System.out.println(set);   // [1, 3, 4]  —— 唯一 + 升序
```

**自然序**：元素必须实现 `Comparable`，否则抛 `ClassCastException`。`Integer / String` 已实现。

**3. 使用 Comparator**
```java
TreeSet<Integer> desc = new TreeSet<>(Comparator.reverseOrder());
desc.add(3); desc.add(1); desc.add(5);
System.out.println(desc);   // [5, 3, 1]

TreeSet<String> byLen = new TreeSet<>(
    Comparator.comparingInt(String::length)
              .thenComparing(Comparator.naturalOrder())
);
byLen.addAll(List.of("bb","a","ccc","dd"));
System.out.println(byLen);   // [a, bb, dd, ccc]
```

**4. TreeSet 导航方法**（板书）
```java
NavigableSet<Integer> s = new TreeSet<>(List.of(1,3,5,7,9));

s.first();          // 1
s.last();           // 9
s.floor(4);         // 3       ≤ 4 的最大
s.ceiling(4);       // 5       ≥ 4 的最小
s.lower(3);         // 1       < 3 的最大
s.higher(3);        // 5       > 3 的最小
s.headSet(5);       // [1, 3]  < 5
s.tailSet(5);       // [5,7,9] ≥ 5
s.subSet(3, 7);     // [3, 5]
s.descendingSet();  // [9,7,5,3,1]
```

**5. TreeMap 基础**
```java
TreeMap<String, Integer> map = new TreeMap<>();
map.put("banana", 2); map.put("apple", 1); map.put("cherry", 3);
System.out.println(map);   // {apple=1, banana=2, cherry=3}
```
按 **Key** 排序，遍历天然有序。

**6. TreeMap 导航方法**
```java
map.firstKey();               // apple
map.floorEntry("b");          // apple=1
map.ceilingEntry("b");        // banana=2
map.subMap("apple", "cherry");// {apple=1, banana=2}
map.descendingKeySet();       // [cherry, banana, apple]
```

**7. 使用要点与坑**（板书圈红）

**坑一：排序规则必须与 equals 一致**
```java
// 只按长度比较 → 长度相同被视为「相同」，后加入的被拒
TreeSet<String> t = new TreeSet<>(Comparator.comparingInt(String::length));
t.add("aa"); t.add("bb");        // t 只剩 1 个元素！
System.out.println(t);           // [aa]
```
必须补一个 `thenComparing(naturalOrder())` 才能区分不同字符串。

**坑二：null 元素**
- TreeSet / TreeMap **不允许 null key**（自然序 NPE，Comparator 需自处理）
- HashMap 允许 null key（1 个）

**坑三：并发**
- 非线程安全
- 并发场景 → `ConcurrentSkipListMap` / `Collections.synchronizedSortedMap`

#### 示例演示（16 分钟）
现场演示 TreeSet 自然序 + Comparator + 导航方法。

**翻车实验**：按长度排序漏元素——学生亲眼看到 `size() = 1`，然后加上 `thenComparing` 修好。

**综合示例**：字符串按长度、字母序排序去重
```java
TreeSet<String> ts = new TreeSet<>(
    Comparator.comparingInt(String::length)
              .thenComparing(Comparator.naturalOrder())
);
ts.addAll(List.of("banana", "apple", "cherry", "kiwi", "pear", "fig"));
ts.forEach(System.out::println);
// fig kiwi pear apple banana cherry
```

**TreeMap 范围查询例子**（考试成绩排行）：
```java
TreeMap<Integer, String> scores = new TreeMap<>();
scores.put(85, "Tom");
scores.put(92, "Jerry");
scores.put(78, "Alice");
scores.put(95, "Bob");

// 95 分以下 90 分及以上的同学
Map<Integer, String> top = scores.subMap(90, 96);
top.forEach((k, v) -> System.out.println(k + " " + v));   // 92 Jerry / 95 Bob
```

#### 课堂练习（5 分钟）
1. `TreeSet` 底层是什么？操作是什么复杂度？（红黑树，O(log n)）
2. 用 `Comparator.comparingInt(String::length)` 做 TreeSet 排序，两个不同的 `"aa"` `"bb"` 结果 size 是多少？（1！）
3. `floor` 与 `lower` 的区别？（≤ vs <）

#### 小结（3 分钟）
- TreeSet / TreeMap = 红黑树，O(log n)，自动排序
- 排序：`Comparable` 自然序 or Comparator 显式序
- 8 个导航方法：first/last, floor/ceiling, lower/higher, subSet/headSet/tailSet
- 排序规则必须与 equals 一致，否则「相同」元素互相覆盖

### 24.4 板书设计
```text
┌────────────────────────────────────────────┐
│  TreeSet / TreeMap = 红黑树                │
│  O(log n) + 自动排序                       │
│                                            │
│  排序：Comparable 或 Comparator            │
│                                            │
│  导航 4 组：                               │
│    first/last                              │
│    floor(≤) / ceiling(≥)                   │
│    lower(<) / higher(>)                    │
│    headSet / tailSet / subSet              │
│                                            │
│  坑：compare()==0 → 视为「相同」！         │
│    → thenComparing(naturalOrder())         │
└────────────────────────────────────────────┘
```

### 24.5 课后作业（本日汇总）

**必做**：
1. 完成教材 §8 全部示例代码抄写与运行
2. 独立完成教材 §8 练习题 1-5
3. 综合题：用 TreeMap 实现英文字母频率统计（区分大小写），按字母序打印

**选做**：
1. 拓展题：给定 `Point(x, y)` 用 `Comparator.comparingInt(p -> p.x)` 做 TreeSet，插入 `(1,5)` 和 `(1,9)` 后 size 是多少？为什么？如何修复？
2. 用 `TreeMap` 实现「按时间段查询日志」：给定起止时间戳，返回落在该范围的所有日志（用 `subMap`）

### 24.6 教学反思提示
- 「compare==0 视为相同」是最容易忘的坑，务必演示一次
- TreeMap 的 `subMap` 范围查询非常强大，可以借考试成绩、时间戳等例子让学生记住

---

## 本日总结

Day04 完成教材第 7、8 讲。学生带走的核心能力：
- **注解**：内置注解 + 元注解 + 自定义 + 反射解析 = 迷你 JUnit（30 行）
- **集合精讲**：Arrays 与 Collections 双工具类、LinkedList 与 Deque、TreeSet / TreeMap 有序集合与导航方法

明日（Day05）主题：**数据结构 + 内部类接口**，对应教材第 9、10 讲。请学生课后完成必做作业。
