# 《AI 应用 Web 开发》 - 学生讲义（Day02：JavaScript/jQuery + AI 编写前端）

**总讲次：6 讲**
**适用对象：** Web 开发初学者（已完成 Day01 HTML+CSS 学习）
**贯穿案例：** 《印想瑜伽会馆客户管理系统》前端界面
**版本基线：** Node.js 20 / Vue 3.5+（预告）/ jQuery 3.7.1 / 通义灵码 + Trae

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | JS 引入方式 + 变量与数据类型 | 会用 `defer` 引入外部 JS，掌握 `const/let`、`===`、7 种原始类型 |
| 第 2 讲 | 流程控制 + 函数 + 数组与对象 | 用 `filter/map/reduce` 处理会员数组、写箭头函数、用解构与展开 |
| 第 3 讲 | DOM 操作 | 用 `querySelector`、`textContent`、`classList` 动态渲染课程列表 |
| 第 4 讲 | 事件处理 + jQuery 简介 | 用 `addEventListener` + 事件委托做登录校验，看懂 jQuery 简写 |
| 第 5 讲 | 通义灵码/Trae 使用入门 | 用精准提示词让 AI 一次生成登录页 HTML |
| 第 6 讲 | AI 生成代码的审查、调优与排错 | 掌握 5 条审查清单 + 4 问阅读器 + `/fix` 修复流程 |

---

## 第 1 讲：JavaScript 引入方式 + 变量与数据类型

### 1.1 引入：为什么 HTML 页面\"不会动\"

你已经会写 HTML + CSS 了：HTML 是骨架，CSS 是皮肤。但——**用户点击按钮，页面什么都不发生**。原因是缺了**灵魂**，也就是 JavaScript（简称 JS）。

**一句定位**：JavaScript 是浏览器唯一\"会说\"的编程语言，负责让页面**活起来**、**能响应用户**、**能操作后端数据**。

**HTML / CSS / JS 三兄弟分工**：

| 层 | 负责 | 例子 |
|---|---|---|
| HTML | 说什么 | 有一个按钮，写着\"登录\" |
| CSS | 长什么样 | 按钮圆角、紫色背景 |
| JavaScript | 做什么、怎么变 | 点击后校验手机号，跳转到会员中心 |

### 1.2 三种引入方式

```html
<!-- 1. 行内脚本（不推荐） -->
<button onclick="alert('点了！')">点我</button>

<!-- 2. 内部脚本（小 Demo 可用） -->
<script>
    console.log('Hello JS');
</script>

<!-- 3. 外部脚本（推荐 ✅） -->
<script src="app.js" defer></script>
```

**划重点：`defer` 属性**

- `defer`：脚本会**等 HTML 解析完**再执行，避免\"找不到 DOM 元素\"报错；
- `async`：脚本尽早执行，**不保证顺序**（一般只用于统计脚本）；
- **默认无属性**：脚本一遇到就立即执行，**会阻塞后续 HTML 解析**（不推荐）。

**口诀**：**外部脚本 + `defer`**，就是 2026 年前端项目的标配。

### 1.3 变量与常量

```javascript
let age = 18;             // 可变
const PI = 3.14159;       // 不可变
var name = '张三';        // 老写法，已被淘汰
```

**口诀**：**能用 `const` 就用 `const`，需要重新赋值再用 `let`，不要用 `var`**。

- 为什么不要用 `var`？—— `var` 有\"变量提升\"和\"函数作用域\"的历史坑，容易出 bug。**新代码只用 `let` 和 `const`**。

### 1.4 数据类型

**7 种原始类型 + 3 种引用类型**：

| 分类 | 类型 | 例子 |
|---|---|---|
| 原始 | `number` | `42`、`3.14`、`NaN`、`Infinity` |
| 原始 | `string` | `'你好'`、`` `模板字符串 ${age}` `` |
| 原始 | `boolean` | `true` / `false` |
| 原始 | `null` | `null`（\"故意为空\"） |
| 原始 | `undefined` | `undefined`（\"未赋值\"） |
| 原始 | `symbol` | 独一无二的标识（较少用） |
| 原始 | `bigint` | `9007199254740993n`（超大整数） |
| 引用 | `object` | `{name: '张三', age: 20}` |
| 引用 | `array` | `[1, 2, 3]` |
| 引用 | `function` | `() => 42` |

**用 `typeof` 查类型**：

```javascript
typeof 123;         // 'number'
typeof '你好';      // 'string'
typeof true;        // 'boolean'
typeof undefined;   // 'undefined'
typeof null;        // 'object'  ← 历史遗留 bug，牢记
typeof [];          // 'object'
typeof function(){};// 'function'
```

> 💡 `typeof null === 'object'` 是 JavaScript 设计时的一个 bug，向后兼容至今。**判断 null 要用 `=== null`**。

### 1.5 相等运算符：`==` vs `===`

```javascript
'1' == 1;    // true  （宽松相等，会类型转换）
'1' === 1;   // false （严格相等，类型也要一样）
0 == false;  // true
0 === false; // false
```

**口诀**：**永远用 `===`，除非你有充分理由用 `==`**。

### 1.6 现代 JS 常用语法速览

- **模板字符串**：`` `Hello, ${name}!` ``
- **空值合并**：`a ?? b`（`a` 为 `null` 或 `undefined` 时取 `b`）
- **可选链**：`user?.contact?.email`（防空指针，任一层为空就返回 `undefined`）

### 1.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `<script>` 放 `<head>` 不加 `defer`，报 `Cannot read properties of null` | JS 在 DOM 解析前跑，找不到元素。加 `defer` 或放 `</body>` 前 |
| `typeof null === 'object'` 让判断失效 | 用 `x === null` 精确判断 |
| `'1' == 1` 返回 `true` 让你怀疑人生 | 永远用 `===` |
| 用 `var` 声明的变量在 `for` 循环里被外部访问到 | 换成 `let` |
| 用 `const` 声明的对象里改属性却没报错 | `const` 锁的是**引用**，不是内部值。对象内部字段可改 |

### 1.8 练习/思考

1. 新建 `warmup.html` + `warmup.js`，用 `defer` 引入。脚本中用 `const`、`let`、`var` 各声明 1 个变量，并 `console.log` 各自的 `typeof`。
2. 在 DevTools Console 中输入以下表达式，先猜答案再运行：
   - `[] == false`
   - `null == undefined`
   - `null === undefined`
   - `NaN === NaN`
3. 为《印想瑜伽会馆》登录页 `member-login.html` 增加一个\"记住我\"复选框，在 `member-login.js` 中读取其 `checked` 状态并打印。
4. 查阅资料：为什么 `0.1 + 0.2 !== 0.3`？给出至少一种解决方案（≤ 200 字）。

---

## 第 2 讲：流程控制 + 函数 + 数组与对象

### 2.1 引入：会员数组怎么处理？

《印想瑜伽会馆》的会员数据存在一个数组里，你面对下面这些真实需求：

- 筛出所有\"未过期的 VIP\"；
- 把会员列表映射成\"姓名 - 手机号\"字符串数组；
- 计算所有会员的**总消费金额**；
- 找到 `id === 3` 的会员详情。

这些操作靠 `for` 循环也能做，但用 **`filter / map / reduce / find`** 一行就搞定——本讲就是让你会用这些\"厨房神器\"。

### 2.2 流程控制

```javascript
// if / else
if (score >= 90) {
    console.log('优秀');
} else if (score >= 60) {
    console.log('及格');
} else {
    console.log('不及格');
}

// for
for (let i = 0; i < 5; i++) console.log(i);

// while
let n = 3;
while (n--) console.log(n);

// for..of 遍历数组（值）
for (const item of ['A','B','C']) console.log(item);

// for..in 遍历对象（键）
for (const key in {a:1,b:2}) console.log(key);
```

**口诀**：**`for..of` 拿值（数组），`for..in` 拿键（对象）**。

### 2.3 函数三写法

```javascript
// 1. 函数声明（有变量提升）
function add(a, b) { return a + b; }

// 2. 函数表达式（无提升）
const mul = function(a, b) { return a * b; };

// 3. 箭头函数（最常用 ✅）
const div = (a, b) => a / b;
```

**箭头函数的优势**：
- 简洁，尤其单参数、单表达式时：`x => x * 2`；
- 没有自己的 `this`（用外层 `this`），**回调场景不再踩坑**。

**默认参数 + 剩余参数**：

```javascript
function greet(name = 'World') { return `Hello, ${name}!`; }
function sum(...nums) { return nums.reduce((s, n) => s + n, 0); }
```

### 2.4 数组常用 6 方法

| 方法 | 作用 | 例子 | 是否改原数组 |
|---|---|---|---|
| `push(x)` | 尾插 | `arr.push(6)` | ✅ |
| `pop()` | 尾删 | `arr.pop()` | ✅ |
| `map(fn)` | 映射为新数组 | `[1,2,3].map(x=>x*2)` → `[2,4,6]` | ❌ |
| `filter(fn)` | 筛选 | `[1,2,3].filter(x=>x>1)` → `[2,3]` | ❌ |
| `find(fn)` | 找第一个符合的 | `arr.find(x=>x.id===3)` | ❌ |
| `reduce(fn, init)` | 累加/汇总 | `[1,2,3].reduce((s,x)=>s+x, 0)` → `6` | ❌ |

**三部曲口诀**：**筛（filter）→ 映（map）→ 合（reduce）**。

### 2.5 对象、解构与展开

```javascript
const user = {
    name: '张三',
    age: 20,
    greet() { return `Hi, I'm ${this.name}`; }
};

// 解构（把属性变成同名变量）
const { name, age } = user;

// 展开 + 覆盖（克隆并改一个字段）
const clone = { ...user, age: 21 };

// 可选链 + 空值合并
const email = user?.contact?.email ?? '无邮箱';
```

**口诀**：**`?.` 防空指针，`??` 防空值**。

### 2.6 🎯 例子锚点：印想瑜伽会员数据处理

```javascript
const members = [
    { id: 1, name: '张三', level: 'VIP',    expired: false, spent: 3800 },
    { id: 2, name: '李四', level: '普通',   expired: true,  spent: 1200 },
    { id: 3, name: '王五', level: 'VIP',    expired: false, spent: 6500 },
    { id: 4, name: '赵六', level: '体验卡', expired: false, spent: 200  },
];

// 1. 筛：未过期的 VIP
const activeVip = members.filter(m => !m.expired && m.level === 'VIP');
// → [{id:1,...}, {id:3,...}]

// 2. 映：所有会员姓名
const names = members.map(m => m.name);
// → ['张三','李四','王五','赵六']

// 3. 合：总消费
const total = members.reduce((sum, m) => sum + m.spent, 0);
// → 11700

// 4. 找：id 为 3 的会员
const target = members.find(m => m.id === 3);
// → {id:3, name:'王五', ...}
```

**记住**：**大部分列表页面的数据处理，就是这 4 招的组合**。

### 2.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `map` 里忘了 `return`，得到全 `undefined` | 单表达式箭头函数省掉 `{}`：`x => x * 2` |
| 箭头函数里用 `this` 得到父作用域的 `this` | 这是特性不是 bug；需要独立 `this` 请用普通 `function` |
| `for..in` 遍历数组时拿到字符串索引 | 数组请用 `for..of` 或 `forEach` |
| `reduce` 没给初始值，空数组报错 | 一律写 `reduce(fn, initValue)` |
| 用展开 `{...obj}` 只是浅拷贝 | 深拷贝用 `structuredClone(obj)`（现代浏览器已支持） |

### 2.8 练习/思考

1. 用 `members` 数组写出：\"消费 > 3000\"的会员，并映射为 `"姓名（等级）"` 字符串数组（提示：`filter` + `map`）。
2. 用 `reduce` 分别统计 VIP / 普通 / 体验卡三类会员的人数，返回一个对象 `{VIP: n1, 普通: n2, 体验卡: n3}`。
3. 写一个 `stats.js`，读取自己造的 20 条会员数据，输出：VIP 人数、平均消费、消费最高会员姓名。
4. 用一行 `reduce` 实现 `[1,2,3,4,5].reverse()` 的功能，不能调用 `reverse`。

---

## 第 3 讲：DOM 操作

### 3.1 引入：DOM 是什么

浏览器加载 HTML 后，把它解析成一棵**文档树**，每个标签都是一个 JavaScript 对象。这棵树就叫 **DOM（Document Object Model，文档对象模型）**。

```
document
  └─ html
      ├─ head
      └─ body
          ├─ h1（"印想瑜伽"）
          └─ ul
              ├─ li（"哈他瑜伽入门"）
              └─ li（"流瑜伽进阶"）
```

**关键认知**：**HTML 加载完就变成 DOM，JS 能读、能写、能增、能删这棵树**。所有的\"页面动态效果\"，本质都是 JS 在改这棵树。

### 3.2 查询元素（5 种方式）

```javascript
document.getElementById('title');
document.getElementsByClassName('item');
document.getElementsByTagName('p');
document.querySelector('.card > h1');       // ✅ 推荐
document.querySelectorAll('.item');         // ✅ 推荐，返回 NodeList
```

**划重点**：日常开发**用 `querySelector` 和 `querySelectorAll` 就够了**——语法就是 CSS 选择器，学过 Day01 CSS 直接能写。

| 方法 | 返回 | 适用场景 |
|---|---|---|
| `getElementById(id)` | 单个元素 | 已知 id 时最快 |
| `querySelector(css)` | 单个元素（第一个匹配） | 通用推荐 |
| `querySelectorAll(css)` | NodeList（可 `.forEach`） | 批量操作 |

### 3.3 修改内容与属性

```javascript
const h1 = document.querySelector('h1');

h1.textContent = '新标题';              // 只读写文本 ✅ 安全
h1.innerHTML   = '<em>富文本</em>';     // 会解析 HTML ⚠️ XSS 风险

h1.setAttribute('data-id', 42);        // 加自定义属性
h1.classList.add('active');             // 加 class
h1.classList.remove('hidden');          // 删 class
h1.classList.toggle('selected');        // 切换 class
h1.style.color = 'red';                 // 直接改样式（不推荐大量用）
```

⚠️ **特别注意 XSS**：如果内容来自用户输入（评论、搜索框、URL 参数），**绝对不要**用 `innerHTML`，永远用 `textContent`。否则用户可以注入恶意脚本。

### 3.4 增删节点

```javascript
// 创建元素
const li = document.createElement('li');
li.textContent = '新条目';
li.classList.add('course-item');

// 追加到父元素末尾
document.querySelector('ul').appendChild(li);

// 移除自己
li.remove();
```

### 3.5 🎯 例子锚点：印想瑜伽课程列表动态渲染

```html
<h2>课程列表</h2>
<ul id="course-list"></ul>
<script src="course-list.js" defer></script>
```

```javascript
// course-list.js
const courses = [
    { name: '哈他瑜伽入门', teacher: '林老师', duration: 60 },
    { name: '流瑜伽进阶',   teacher: '陈老师', duration: 75 },
    { name: '孕妇瑜伽',     teacher: '王老师', duration: 45 },
    { name: '空中瑜伽',     teacher: '李老师', duration: 60 },
];

const ul = document.querySelector('#course-list');
courses.forEach((c, idx) => {
    const li = document.createElement('li');
    li.textContent = `${c.name} —— ${c.teacher}（${c.duration} 分钟）`;
    li.classList.add('course-item');
    li.setAttribute('data-id', idx);
    ul.appendChild(li);
});
```

**四步曲**：**查（querySelector）→ 建（createElement）→ 填（textContent/setAttribute）→ 挂（appendChild）**。

### 3.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `document.getElementById(...)` 得到 `null` | 元素还没渲染。加 `defer` 或用 `DOMContentLoaded` |
| `innerHTML` 被注入恶意脚本 | 用户输入永远用 `textContent`；富文本用 DOMPurify 之类的库 |
| `getElementsByClassName` 拿到的集合会随 DOM 变化 | 想要静态快照用 `querySelectorAll` |
| `el.style.background-color` 报错 | CSS 属性名转小驼峰：`el.style.backgroundColor` |
| 循环里频繁 `appendChild` 卡顿 | 用 `DocumentFragment` 一次性挂载 |

### 3.7 练习/思考

1. 为课程列表加一个\"添加课程\"按钮，点击时用 `createElement` 追加一条固定内容的 `<li>`。
2. 给每条课程加 `data-id` 属性（用 `setAttribute`），值为下标。
3. 用 `classList.toggle('done')` 让点击某条课程时切换\"已报名\"样式。
4. 做一个\"课程详情面板\"：点击课程列表任一条目时，把该课程的 `name/teacher/duration` 显示到旁边一个 `<div id="detail">` 中（提示：先查该 `<li>` 的 `data-id`，再从数组取详情）。

---

## 第 4 讲：事件处理 + jQuery 简介

### 4.1 引入：让 DOM \"会回应\"

DOM 会展示、能修改还不够，用户还要能\"跟它互动\"——点击、输入、提交、拖拽。这一切靠**事件（Event）** 系统。

**一句话定义**：**事件 = 用户或浏览器发生的一件事（点击、输入、加载完成、按下键）**，JS 可以监听事件、执行回调。

### 4.2 三种事件绑定方式

```html
<!-- 1. 行内（不推荐，HTML 与 JS 耦合） -->
<button onclick="alert(1)">A</button>

<!-- 2. 属性绑定（覆盖式，只能一个回调） -->
<script>
    btn.onclick = () => alert(2);
</script>

<!-- 3. 事件监听 ✅ 推荐（可绑多个） -->
<script>
    btn.addEventListener('click', () => alert(3));
</script>
```

**划重点**：**只用 `addEventListener`**。它支持给同一个元素同一个事件绑多个回调，也支持解绑（`removeEventListener`）。

### 4.3 常见事件速查

| 事件 | 触发时机 | 常见场景 |
|------|----------|---------|
| `click` | 单击 | 按钮、链接 |
| `dblclick` | 双击 | 编辑单元格 |
| `input` | 输入框内容变化 | 实时校验、搜索联想 |
| `change` | 值改变并失焦 | 下拉框、单选/复选 |
| `submit` | 表单提交 | 登录、注册 |
| `mouseenter` / `mouseleave` | 鼠标进入 / 离开 | Hover 效果 |
| `keydown` / `keyup` | 键盘按下 / 抬起 | 快捷键、回车提交 |
| `DOMContentLoaded` | HTML 解析完成 | 初始化脚本 |

### 4.4 事件对象

回调函数会收到一个事件对象参数（约定叫 `e`），常用属性：

- `e.target`：**真正触发事件的元素**（可能是子元素）；
- `e.currentTarget`：**绑定监听器的元素**；
- `e.preventDefault()`：**阻止默认行为**（如表单默认提交、链接默认跳转）；
- `e.stopPropagation()`：阻止事件冒泡；
- `e.key`：键盘事件里按下的键名（`'Enter'`、`'Escape'` 等）。

```javascript
form.addEventListener('submit', (e) => {
    e.preventDefault();               // 阻止默认提交（页面刷新）
    console.log(e.target.username.value);
});
```

### 4.5 事件委托：一个监听器管一群子元素

**问题**：给 100 个 `<li>` 各绑一个 `click`？既费性能，又对新增的 `<li>` 无效。

**解决**：把监听器绑到**共同父元素**上，通过 `e.target` 判断实际点的是谁：

```javascript
document.querySelector('#course-list').addEventListener('click', (e) => {
    if (e.target.tagName === 'LI') {
        e.target.classList.toggle('selected');
    }
});
```

**好处**：
1. **监听器少，性能好**；
2. **动态生成的元素自动生效**（后加进来的 `<li>` 不用重新绑）。

### 4.6 🎯 例子锚点：印想瑜伽会员登录（完整版）

```html
<form id="loginForm">
    <input name="phone" placeholder="手机号（11 位）">
    <input name="password" type="password" placeholder="密码（6-16 位）">
    <button type="submit">登录</button>
    <div id="msg"></div>
</form>
<script src="login.js" defer></script>
```

```javascript
// login.js
const form = document.getElementById('loginForm');
const msg  = document.getElementById('msg');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const { phone, password } = e.target;

    if (!/^1\d{10}$/.test(phone.value)) {
        msg.textContent = '手机号格式不正确';
        return;
    }
    if (password.value.length < 6 || password.value.length > 16) {
        msg.textContent = '密码长度需 6—16 位';
        return;
    }
    msg.textContent = `欢迎回来，${phone.value}`;
});
```

**测试**：输入 `13800138000` + `abc123` → 显示欢迎；输入 `123` → 提示手机号格式不正确。

### 4.7 jQuery 简介

**为什么还要学 jQuery**：
- 大量老项目、后台管理系统、CMS 仍在使用；
- 语法简洁：`$('选择器')` 一步到位；
- 面试与阅读遗留代码的必备技能。

> 💡 **新项目请用 Vue / React，不要用 jQuery 新写业务代码**。学 jQuery 的目的是**能读懂**。

**引入方式**（3.7.1 是 2026 年当前稳定版）：

```html
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
```

**原生 JS vs jQuery 对照**：

| 原生 JS | jQuery |
|---------|--------|
| `document.querySelector('.a')` | `$('.a')` |
| `document.querySelectorAll('.a')` | `$('.a')` |
| `el.addEventListener('click', fn)` | `$('.a').click(fn)` 或 `$('.a').on('click', fn)` |
| `el.style.color = 'red'` | `$('.a').css('color', 'red')` |
| `el.textContent = 'x'` | `$('.a').text('x')` |
| `el.innerHTML = 'x'` | `$('.a').html('x')` |
| `el.classList.add('b')` | `$('.a').addClass('b')` |
| `fetch(url).then(r => r.json())` | `$.get(url, cb)` |

**jQuery 版课程列表委托**：

```javascript
$('#course-list').on('click', 'li', function () {
    $(this).toggleClass('selected');
});
```

**注意**：这里的 `function () { ... }` **不能换成箭头函数**，因为 jQuery 通过 `this` 传递\"当前被点击的 li\"，而箭头函数没有自己的 `this`。

### 4.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 表单点\"提交\"页面刷新，Console 报错清空 | 忘了 `e.preventDefault()` |
| 事件委托里 `e.target.tagName === 'LI'` 判断失败 | `tagName` 是**大写** `'LI'`，不是 `'li'` |
| 给 100 个按钮各绑一个事件卡顿 | 用事件委托 |
| jQuery 的 `.on('click', 'li', () => $(this))` 拿不到 `this` | 用 `function()` 不用箭头函数 |
| 同一按钮两次 `addEventListener('click', fn)` | 会被绑两次！先 `removeEventListener` 或用命名函数 |

### 4.9 练习/思考

1. 为登录表单增加\"记住我\"复选框，若勾选则在 `msg` 中额外显示\"已开启记住我\"。
2. 用**事件委托**为课程列表增加\"双击删除\"：`dblclick` 事件 → `e.target.remove()`。
3. 为登录表单增加\"3 次输错锁定 30 秒\"功能（用 `setTimeout` 与计数器）。
4. 把\"课程列表\"用 jQuery 重写一遍，感受两种写法差异（≤ 30 行）。

---

## 第 5 讲：通义灵码/Trae 使用入门 + AI 生成第一个前端页面

### 5.1 引入：为什么要用 AI 写前端

上一讲你手写了一个登录页。回想一下：**这个登录页你花了多久？** 30 分钟？1 小时？其实这种\"重复劳动\"AI 90 秒就能做完，并且质量不差。

**AI 不是替代你思考，而是替你打字**。把\"打字工\"交给 AI，你才能腾出时间去想\"这个功能怎么设计更合理\"。

### 5.2 通义灵码是什么

**通义灵码（TONGYI Lingma）**：阿里出的 AI 编程助手，能在 VS Code、Trae、JetBrains IDEA 里当\"副驾驶\"。国内直连、免费、中文交互友好。

**Trae**：字节出的一款 AI 原生 IDE，直接内置了 AI 编辑体验（本课程主用 Trae + 通义灵码）。

### 5.3 安装与登录

1. 打开 Trae（或 VS Code）→ 扩展商店 → 搜索 `TONGYI Lingma` → 安装；
2. 安装后左侧栏出现 Lingma 图标 → 点击 → 登录（三选一）：
   - 手机号 + 验证码
   - 阿里云账号
   - 钉钉扫码
3. 登录成功后左下角显示头像即可开始使用。

### 5.4 六大核心功能

| 功能 | 触发方式 | 用途 |
|------|---------|------|
| 代码补全 | 输入自动触发（灰色提示 → 按 `Tab` 接受） | 智能续写当前光标处代码 |
| 智能问答 | `Ctrl+Shift+L` 唤起侧栏 | 自由对话、生成整块代码 |
| 代码解释 | 选中代码 → 右键 → Lingma → 解释 | 解读遗留代码 |
| 代码优化 | 同上 → 优化 | 重构、性能改进 |
| 生成注释 | 同上 → 生成注释 | JSDoc / JavaDoc |
| 生成单测 | 同上 → 生成单元测试 | 一键出测试文件 |

**80% 的日常编码需求就被这 6 个覆盖**。

### 5.5 三种触发方式

1. **Tab 补全**：写一半代码，等灰色提示出来按 `Tab`。适合零散补全。
2. **`/` 快捷指令**：在侧栏输入 `/explain`、`/fix`、`/tests` 等命令。适合针对某段代码做操作。
3. **`@` 引用**：`@file:login.js`、`@workspace`——让 AI 读到上下文文件。适合让 AI 保持风格一致。

### 5.6 精准提示词 5 要素

```text
【角色】：<Web 初学者 / 后端工程师 / 前端专家>
【背景】：<正在做什么项目、使用什么技术栈>
【目标】：<清晰、单一的一件事>
【约束】：<必须遵守的规则，如"只用一个文件""不引入第三方库">
【输出】：<代码 + 简要说明 / 表格 / 步骤>
```

**口诀**：**角色—背景—目标—约束—输出**，每一格都填清楚，AI 一次到位。

### 5.7 对比：模糊 vs 精准

**模糊版**（AI 只会给通用模板）：

```text
写一个登录页面。
```

**精准版**（AI 一次就对）：

```text
【角色】前端初学者，学过 HTML/CSS/JS。
【背景】《印想瑜伽会馆客户管理系统》，需要为会员做登录入口。
【目标】生成 login.html 单文件。
【约束】
1. 内联 <style>，Flex 居中，卡片宽 360px、圆角 8px、投影柔和；
2. 表单字段：手机号（11 位，1 开头）+ 密码（6-16 位）；
3. 点击"登录"按钮校验字段并 alert 结果，不发起真实请求；
4. 不引入任何外部 CDN 或库；
5. 主色调 #667eea（瑜伽紫）。
【输出】完整的单文件 HTML。
```

### 5.8 🎯 例子锚点：AI 生成印想瑜伽登录页（完整流程）

1. **新建文件**：在 Trae 里新建 `login.html`；
2. **打开侧栏**：`Ctrl+Shift+L` 唤起 Lingma 侧栏；
3. **粘贴精准提示词**（上面的\"正例\"）；
4. **点击\"插入到编辑器\"**：AI 输出的代码块右上角有这个按钮；
5. **保存 + 预览**：右键 → Open with Live Server；
6. **不满意就追问**：\"错误提示颜色请改为 #e53e3e，字号 12px\"、\"卡片增加渐变背景\"……

**@file: 引用示例**（让新页面延用登录页的风格）：

```text
@file:login.html 参考这个登录页的风格，
再帮我做一个会员列表页面 member-list.html，
展示 5 条 mock 数据（姓名、手机号、等级、注册日期）。
```

### 5.9 AI 编程闭环

```
需求 → 提示词 → AI 生成代码 → 人工审查 →（不满意）→ 追问 → 调优 → 上线
                                        ↘（通过）→ 单测 → 上线
```

**核心思想**：**AI 是循环里的一环，不是终点**。每一步你都要检查、修改、追问。

### 5.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 通义灵码首次登录被公司/校园网拦 | 改用手机热点 / 钉钉扫码 |
| AI 输出的代码引入了外部 CDN | 在\"约束\"里明确写\"不引入外部库\" |
| 提示词写了 500 字 AI 反而抓不住重点 | 约束条件要**精准**，不要罗嗦 |
| AI 每次生成的代码风格都不一致 | 用 `@file:xxx` 让它读参考文件 |
| 生成的代码变量名是英文缩写看不懂 | 追问一句：\"请把变量名改成有意义的中文拼音或英文全称\" |

### 5.11 练习/思考

1. 用精准提示词让 AI 生成《印想瑜伽会馆》**首页**：顶部 Logo + 导航（首页/课程/会员/联系我们）+ Banner（一张纯色背景 + 一句标语）+ 页脚。单文件、内联样式、Flex 布局。
2. 用精准提示词生成**课程详情页** `course-detail.html`：课程封面 + 标题 + 教练 + 时长 + 报名按钮。
3. 整理\"我的第一个提示词库\"，收录至少 3 个精准提示词模板（登录页 / 列表页 / 详情页），保存为 `.md`。
4. 用 `@file:` 引用你已生成的登录页，让 AI 帮你再做一个\"注册页\"，保持视觉一致。

---

## 第 6 讲：AI 生成代码的审查、调优与排错

### 6.1 引入：AI 生成的代码能直接用吗？

答案是——**不能**。原因：

1. AI 有\"幻觉\"，可能编造不存在的 API；
2. AI 不了解你的具体需求全貌，容易\"看起来对但边界错\"；
3. **代码是你签字上线的，出问题你担责，不是 AI**。

本讲教你**怎么审、怎么改、怎么救**——把 AI 从\"神秘外包\"变成\"可控助手\"。

### 6.2 AI 代码审查 5 条清单

拿到 AI 输出后，**逐条对照**：

| # | 检查项 | 该看什么 |
|---|---|---|
| 1 | 约束满足 | 你在提示词里写的每一条是否都被实现？ |
| 2 | 语法错误 | Trae 会用红波浪线提示；控制台是否报错？ |
| 3 | 边界条件 | 空输入、超长输入、特殊字符、极端数据 |
| 4 | 可访问性 | `<input>` 是否配了 `<label>`？颜色对比度够吗？ |
| 5 | 命名可读 | 变量名是否清晰？函数名是否表达意图？ |

### 6.3 4 问阅读器

看到一段 AI 生成的代码，逐段问自己：

```
Q1  这段代码做什么？（用一句话总结）
Q2  它读了什么、写了什么？（数据流方向）
Q3  有没有更简洁的写法？（重构机会）
Q4  它会在什么情况下崩？（边界与异常）
```

**这 4 问是你从\"码农\"进化到\"工程师\"的分水岭**。

### 6.4 🎯 例子锚点：印想瑜伽后台会员列表

**提示词**：

```text
【角色】前端工程师。
【背景】《印想瑜伽会馆》后台管理，需要展示会员列表。
【目标】生成 emp.html：顶部标题栏 + "新增会员"按钮，
     中部表格（姓名/手机号/等级/入会日期/操作），
     底部分页栏（上一页 / 页码 / 下一页），
     JS 数组模拟 20 条数据。
【约束】单文件、Flex + 表格样式、不引入外部库、每页 5 条。
【输出】完整 HTML。
```

AI 会给出：`<table>` 结构 + Mock 数据 + `render(page)` 分页函数 + 编辑/删除按钮委托事件。**拿到后，就用 5 条清单 + 4 问阅读器逐段审**。

### 6.5 场景一：控制台报错 → AI 修复

假设你打开生成的 `emp.html`，控制台报：

```text
Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
    at emp.html:87
```

**操作**：把这段报错**整段粘贴**到 Lingma 侧栏，加一句：

```text
以下报错什么原因？如何修复？
Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
    at emp.html:87
```

AI 回答（大意）：

> 常见原因：脚本在 DOM 加载完成前执行，`document.getElementById('xxx')` 返回 `null`。
> 解决方案：
> 1. 将 `<script>` 放到 `</body>` 前；
> 2. 使用 `<script defer>`；
> 3. 或包裹在 `document.addEventListener('DOMContentLoaded', () => { ... })` 里。

**这就是最完整的 AI 排错闭环：贴报错 → 得诊断 → 选方案 → 验证**。

### 6.6 场景二：让 AI 解释一段\"天书代码\"

选中一段陌生代码 → **右键 → Lingma → 解释代码**。AI 会分段讲解每一句作用。

- 适合啃老项目、看开源库源码；
- 适合读队友写的\"意大利面代码\"。

### 6.7 场景三：让 AI 生成注释与单测

- **选中函数 → Lingma → 生成注释** → 一次出 JSDoc；
- **选中函数 → Lingma → 生成单元测试** → 输出可跑的 Jest 代码。

```javascript
/**
 * 渲染分页后的会员列表
 * @param {number} page - 当前页码（从 1 开始）
 * @param {Array<Member>} data - 会员数据源
 * @param {number} [pageSize=5] - 每页条数
 * @returns {void}
 */
function render(page, data, pageSize = 5) { /* ... */ }
```

### 6.8 AI 编程三条纪律

⚠️ **纪律一：代码是自己的责任**
AI 只是助手，最终代码错了你要担责。**任何 AI 产出都必须读懂 + 测试**。

⚠️ **纪律二：不要泄露敏感信息**
数据库密码、AccessKey、公司内网地址、身份证号、他人隐私——**都不要贴进 AI 对话**。Cherry Studio 是本地客户端，但对话内容仍会发往云端 API。

⚠️ **纪律三：保持思考肌肉**
先自己想 **30 秒**再问 AI，避免变成\"提示词工人\"。**AI 会写代码不代表你不用学编程**——那样你连 review 都做不了。

### 6.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| AI 生成代码直接用，上线出 bug | 每一次都必须过 5 条审查清单 |
| AI 编造了一个不存在的 API | 幻觉。让它给出 MDN 链接验证，或亲自跑一遍 |
| 让 AI 修 bug 修出更多 bug | 每次只让它改一处，改完立即测试 |
| 把公司内部代码贴进 AI 分析 | 严重违规。用本地大模型或对代码脱敏 |
| 提示词说\"要考虑边界\"，AI 边界还是没覆盖 | 明确写出**哪些**边界：空、超长、负数、特殊字符 |

### 6.10 练习/思考

1. 用 AI 生成《印想瑜伽会馆》**会员列表页 + 新增会员弹窗**，按 5 条清单自查并写一份 ≤ 300 字的\"AI 代码 Review 报告\"。
2. 让 AI 生成一个 `add(a, b)` 函数，故意在提示词里要求\"必须支持字符串数字\"，然后审查 AI 的输出——大概率会有 `add('1', '2') === '12'` 的坑。用 `/fix` 让 AI 修复，再让它出 5 条单测。
3. 让 AI 为你 Day02 写的所有 JS 函数生成 JSDoc 注释，提交前逐个通读修改。
4. 给 AI 一段**你自己写错的 JS 代码**（例如死循环、内存泄漏、XSS 漏洞），用 `/fix` 让它修复，写 200 字点评修复质量。

---

## Day02 收官

到这里你已经掌握了：

- ✅ JavaScript 语法基础（变量、类型、流程、函数、数组、对象）；
- ✅ DOM 操作四步曲（查 → 建 → 填 → 挂）；
- ✅ 事件处理（`addEventListener` + 事件委托）；
- ✅ jQuery 阅读能力（不用它写新项目，但能读懂）；
- ✅ 通义灵码 + Trae 的完整工作流；
- ✅ AI 生成代码的审查、调优、排错方法论。

**下一步**（Day03 预告）：**Vue 3 前端框架**——从\"手写 DOM 操作\"进阶到\"数据驱动 UI\"。你会发现之前用 `document.createElement + appendChild` 写的一大堆代码，Vue 里只要一个 `v-for` 就搞定。

**记住一句话**：**JavaScript 是练出来的，不是听出来的**。今天讲义里的每一段代码，你都亲手敲一遍，才算真正学过。
