# 《AI 应用 Web 开发》 - 学生讲义（Day09：文件上传与阿里云 OSS + 代理模式与 AOP 概念）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day08 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、DTO/VO、Result 统一响应、全局异常处理、参数校验、日志与配置基础）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / aliyun-sdk-oss 3.17.4 / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day08 结束时，会员、教练、课程三张表都留了 `avatar / cover / id_card` 三个 URL 字段，但前端一直在问「图片到底传到哪儿去、URL 从哪里回」——Day09 就把这条链路彻底打穿。前 3 讲把「文件从哪里来、存到哪里、URL 从哪里回」贯通到本地磁盘与阿里云 OSS 两条路径；后 3 讲把每个 Service 方法都要重复的日志、耗时、事务、权限抽出去——先看清代理模式三形态（静态 → JDK 动态 → CGLIB），再引出 Spring AOP 五要素与切点表达式，最后落到「`this.method` 不走代理」这个必栽的经典坑。Day09 结束后，你的 `POST /files/upload` 一份接口同时支撑开发和生产，Controller 层已经能被 AOP 全局增强。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 文件上传总览与本地磁盘方案（一） | 打通 `POST /files/upload`：multipart 双阈值 + ResourceHandler 静态映射 |
| 第 2 讲 | 本地磁盘上传实战——三层安全校验 + 日期分桶 + UUID 命名 | `LocalFileStorage` 组件 + `UploadVO(url,size,ext)` |
| 第 3 讲 | 阿里云 OSS 集成 + `@ConditionalOnProperty` 优雅切换 | `OssFileStorage` + 运行时开关，前端接口零改动 |
| 第 4 讲 | 代理模式三形态——静态 → JDK 动态 → CGLIB | 三份最小 Demo + 观察 Spring 用哪种代理 |
| 第 5 讲 | Spring AOP 五要素 + 切点表达式 + 最小可运行切面 | `TimingAspect` 全局耗时切面 + `@OperationLog` 注解切面 |
| 第 6 讲 | `this.method` 陷阱 + 三种解法 + 观察代理对象 + Day09 收官 | 复现 + 修复 + 5 大排查点 |

---

## 第 1 讲：文件上传总览与本地磁盘方案（一）

### 1.1 引入：avatar / cover / id_card 三个 URL 字段到底怎么来？

Day03–Day08 我们已经把 `tb_member.avatar`、`tb_coach.avatar`、`tb_course.cover` 三个字段落到 DDL 里，注册接口也能存 URL 字符串——但真正的图片文件到底怎么从前端到达后端、又怎么变成一个可访问的 URL？本讲把这条链路的第一段（本地磁盘方案）打通。

🎯 **一句话目标**：一份 `POST /files/upload` 接口，同时能存到本地磁盘（开发环境）和阿里云 OSS（生产环境），前端不用改一行代码。

### 1.2 文件上传总体链路

```
┌────────────┐   multipart   ┌───────────────┐    落盘/put    ┌──────────────┐   URL   ┌────────────┐
│ 前端 FormData │ ────────────>│ Spring MVC 解析│ ─────────────>│ Storage 组件 │ ──────>│ 数据库 URL │
└────────────┘               └───────────────┘               │ 本地/OSS/COS │        └────────────┘
                                                             └──────────────┘
```

🎯 **关键约定**：**数据库里存的永远是 URL 字符串，不是二进制**。文件本身只在文件系统 / OSS 中，业务表只留一个短短的字符串。

### 1.3 本地磁盘 vs 对象存储 —— 五维对比

| 维度 | 本地磁盘 | 对象存储 (OSS/S3/COS) |
|------|---------|---------|
| 多机部署 | 写 A 机，读到 B 机就 404 | 全局共享 |
| 备份容灾 | 手工写脚本 | 平台自带多副本 |
| 带宽 / CDN | 自己扛 | 一键 CDN 加速 |
| 大文件 | 磁盘 IO 与数据库耦合 | 天生分离 |
| 成本 | 小规模便宜、大规模崩 | 大规模摊薄 |

💡 **结论**：**生产 100% 用 OSS，本地磁盘只在开发环境用**。理由是「便宜、不占学生的阿里云余额、离线也能开发」。

### 1.4 `spring.servlet.multipart` 两个关键配置

```yaml
spring:
  servlet:
    multipart:
      max-file-size:    10MB   # 单个文件上限
      max-request-size: 30MB   # 整个请求体上限
      file-size-threshold: 0   # 超过阈值才写临时文件，一般不调
```

⚠️ **两个值必须同时调**：前端一次传 3 张 8MB 图，即使单张不超 10MB，也会因为 request 总和 24MB > 默认 10MB 被拒。

- `max-file-size` —— 单个文件上限；
- `max-request-size` —— 整个请求体上限（一次可能传 3 张图，总量 = 3 × 8MB = 24MB）；
- `file-size-threshold` —— 超过阈值才写临时文件，否则直接内存，日常不调。

### 1.5 应用级配置（印想瑜伽）

```yaml
yinxiang:
  upload:
    local:
      base-dir: D:/yinxiang/uploads   # Linux/Mac: /opt/yinxiang/uploads
      base-url: /files
```

- `base-dir` 是文件真实落盘的**绝对路径**；
- `base-url` 是浏览器访问的**URL 前缀**。

### 1.6 静态映射：把本地目录暴露成 HTTP 静态资源

Spring MVC 提供了 `WebMvcConfigurer.addResourceHandlers` 钩子。写一次就把「本地目录 → URL 前缀」的映射注册好，浏览器就能直接访问。

```java
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Value("${yinxiang.upload.local.base-dir}")
    private String baseDir;

    @Value("${yinxiang.upload.local.base-url}")
    private String baseUrl;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry reg) {
        reg.addResourceHandler(baseUrl + "/**")
           .addResourceLocations("file:" + baseDir + "/");
    }
}
```

🎯 **两条铁律**：

1. **`file:` 协议前缀不能少** —— 不加 `file:`，Spring 会当成 classpath 资源去找；
2. **`base-dir` 结尾的 `/` 不能少** —— 不加 `/`，Spring 会把 `D:/yinxiang/uploads` 当成一个**文件**而非**目录**。

### 1.7 最简版上传接口

```java
@RestController
@RequestMapping("/files")
@RequiredArgsConstructor
@Slf4j
public class FileController {

    @Value("${yinxiang.upload.local.base-dir}")
    private String baseDir;

    @Value("${yinxiang.upload.local.base-url}")
    private String baseUrl;

    @PostMapping("/upload")
    public Result<String> upload(@RequestPart("file") MultipartFile file) throws IOException {
        String fileName = file.getOriginalFilename();               // 故意用原文件名 → 下一讲打脸
        File target = new File(baseDir + "/" + fileName);
        file.transferTo(target);
        return Result.success(baseUrl + "/" + fileName);
    }
}
```

- `@RequestPart("file")` 表示「从 multipart 请求体里名叫 `file` 的那一段读」；
- `@RequestParam` 也能收到，但语义上 `@RequestPart` 更明确，推荐前者；
- `transferTo(File)` **必须传绝对路径**——传相对路径会落到 servlet 临时目录，坑无数人。

### 1.8 联调剧本

**准备**：先手工建好 `D:/yinxiang/uploads/` 目录（Windows 学生尤其容易漏），Linux/Mac 学生注意目录写权限。

Postman：
- 方法：`POST http://localhost:8080/files/upload`
- Body → `form-data` → key = `file`，type 选 **File**，选一张 png；
- 期望响应：`{"code": 0, "msg": "OK", "data": "/files/xxx.png"}`；
- 浏览器打开 `http://localhost:8080/files/xxx.png` 应能直接预览图片；
- 到 `D:/yinxiang/uploads/` 磁盘目录也能看到文件落地。

### 1.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 上传返回 200 但浏览器 URL 打开 404 | `addResourceLocations` 结尾漏 `/`，或 `base-dir` 是相对路径 |
| `MaxUploadSizeExceededException` | `max-file-size` 或 `max-request-size` 太小，两者要同时调 |
| `FileNotFoundException: ... uploads (系统找不到指定的路径)` | `base-dir` 目录没提前建好，`transferTo` 不会自动建父目录 |
| Postman 上传返回 415 Unsupported Media Type | Body 选成了 `raw` 而不是 `form-data` |
| 传相对路径 `transferTo(new File("uploads/a.png"))` | 落到 servlet 临时目录，不是 `base-dir`；必须用绝对路径 |

### 1.10 练习/思考

1. **必做**：完成 `POST /files/upload` 本地磁盘最小版，交 3 张截图（Postman 200 / 浏览器预览 / 磁盘目录快照）；
2. **必做**：把 `max-file-size` 改成 `1MB`，上传 5MB 图片，观察 Spring 抛的异常全名（提示：`org.springframework.web.multipart.MaxUploadSizeExceededException`）；
3. **思考**：为什么 `ResourceHandler` 的第二个参数一定要 `file:` 前缀？（提示：`Resource` 的 URL 协议解析——不写协议头默认 classpath）；
4. **挑战**：改造 `WebConfig`，同时映射两个目录（`/files/**` → 本地 uploads，`/static/**` → classpath 静态资源），观察路径冲突时哪一个优先。

---

## 第 2 讲：本地磁盘上传实战 —— 三层安全校验 + 日期分桶 + UUID 命名

### 2.1 引入：如果我把文件名改成 `../../../etc/passwd`……

上一讲直接用 `file.getOriginalFilename()` 落盘。反问几个问题：

- 如果我把文件名改成 `../../../../etc/passwd`，`transferTo` 会不会真的写到 `/etc/passwd`？—— **目录穿越攻击**；
- 如果我把 `virus.exe` 改名成 `cute.png`，你的校验挡不挡得住？—— **扩展名伪装**；
- 如果两个用户同时传 `avatar.jpg`，谁覆盖谁？—— **同名覆盖**。

本讲一次性收拾这三个坑，把上一讲那份「能跑」的代码升级到「能上线」。

### 2.2 三层安全校验（顺序不能乱）

**顺序 = 代价递增**：先便宜的校验先拦，最贵的校验放最后。

```java
// 第 1 层 非空
if (file == null || file.isEmpty()) {
    throw new BizException("请选择文件");
}

// 第 2 层 大小
if (file.getSize() > MAX_SIZE) {
    throw new BizException("单文件不得超过 5MB");
}

// 第 3 层 白名单扩展名
String ext = ext(file.getOriginalFilename());
if (!IMAGE_EXTS.contains(ext)) {
    throw new BizException("仅支持 jpg/png/gif/webp");
}
```

🎯 **两个「再挡一次」的哲学**：

- `application.yml` 里的 `max-file-size` 已经在 MVC 层挡了，为什么 Java 层还要再挡一次？—— **配置改错了、被误覆盖了、被环境变量顶替了……业务规则必须由代码保证**；
- `<input accept="image/*">` 前端已经限制了，为什么后端还要挡？—— **永远不信任外部输入**。

### 2.3 为什么用白名单而不是黑名单？

**黑名单永远补不全**。当你在拒绝列表里塞进 `.php .jsp .exe .sh .html .htaccess ...` 之后，攻击者再传一个：

- `.phtml` `.php3` `.php4` `.php5` `.pht` `.phar` —— 你补不完；
- `virus.png.exe` —— 双扩展名，取「最后一段」的规则被绕过；
- `virus.PhP` —— 大小写混合。

**白名单只写明确允许的**，其他一律拒。业务上「允许什么」永远是有限枚举，很好写。

```java
private static final Set<String> IMAGE_EXTS = Set.of("jpg", "jpeg", "png", "gif", "webp");
```

`Set.of(...)` 是不可变集合，`contains` O(1)，性能与安全兼顾。

### 2.4 文件命名策略

**反例 1**：用原始文件名 —— 中文乱码、特殊字符（空格、`?`、`#`）、目录穿越、同名覆盖，四个坑一起踩；
**反例 2**：只用 UUID 但不分目录 —— 一个目录堆到几十万个文件，`ls` 直接卡死，文件系统 inode 也可能耗尽。

**推荐**：`yyyy/MM/dd/<32位 UUID>.<ext>`

- **日期分桶**：每天一个目录，天然限制每目录规模到「一天几千个」；
- **UUID**：保证唯一，无同名覆盖；
- **保留扩展名**：`.png` `.jpg` 让浏览器、OSS 都能识别 Content-Type。

```java
LocalDate today = LocalDate.now();
String rel = today.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
             + "/" + UUID.randomUUID().toString().replace("-", "")
             + "." + ext;
// → 2026/07/17/8f3c1d2e4a5b6c7d8e9f0a1b2c3d4e5f.png
```

### 2.5 返回结构 `UploadVO`

Java 25 的 `record` 一行搞定：

```java
public record UploadVO(String url, long size, String ext) {}
```

- `url`：前端拿到直接写回业务字段（`memberDTO.avatar = data.url`）；
- `size`：前端立刻显示「已上传 3.2MB」，不用再发一次请求；
- `ext`：前端可以据此判断是否要显示「预览」按钮（图片可预览、PDF 不行）。

🎯 **返回结构一稳定，前端就能写死渲染逻辑**。无论切到本地还是 OSS，前端都拿到同样的三个字段。

### 2.6 完整 `LocalFileStorage` 实现

```java
@Component
@RequiredArgsConstructor
@Slf4j
public class LocalFileStorage {

    @Value("${yinxiang.upload.local.base-dir}")
    private String baseDir;

    @Value("${yinxiang.upload.local.base-url}")
    private String baseUrl;

    private static final Set<String> IMAGE_EXTS = Set.of("jpg", "jpeg", "png", "gif", "webp");
    private static final long MAX_SIZE = 5 * 1024 * 1024;   // 5MB

    public UploadVO save(MultipartFile file) {
        // 1. 三层校验
        if (file == null || file.isEmpty()) {
            throw new BizException("请选择文件");
        }
        if (file.getSize() > MAX_SIZE) {
            throw new BizException("单文件不得超过 5MB");
        }
        String ext = ext(file.getOriginalFilename());
        if (!IMAGE_EXTS.contains(ext)) {
            throw new BizException("仅支持 jpg/png/gif/webp");
        }

        // 2. 安全命名：日期分桶 + UUID
        String rel = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
                   + "/" + UUID.randomUUID().toString().replace("-", "")
                   + "." + ext;
        File target = new File(baseDir, rel);

        // 3. 落盘
        try {
            FileUtils.forceMkdirParent(target);   // 父目录不存在时自动建
            file.transferTo(target);
        } catch (IOException e) {
            log.error("[本地上传] 写文件失败 rel={}", rel, e);
            throw new BizException("上传失败");
        }

        // 4. 拼 URL
        String url = baseUrl + "/" + rel.replace("\\", "/");   // Windows 反斜杠归一化
        log.info("[本地上传] 完成 url={} size={}", url, file.getSize());
        return new UploadVO(url, file.getSize(), ext);
    }

    private String ext(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }
}
```

**几个细节**：

- `FileUtils.forceMkdirParent` 来自 `commons-io`，Spring Boot Web 已经间接依赖，能自动建父目录；
- `toLowerCase(Locale.ROOT)` —— **必须指定 Locale**，否则土耳其语环境下 `"I".toLowerCase()` 会变成 `"ı"`（无点小 i），把 `.JPG` 归一化为 `.jpg` 就失败了；
- `rel.replace("\\", "/")` —— Windows 上 `LocalDate.format` 用 `/` 是 OK 的，但如果你换成 `File.separator` 就会出现反斜杠，URL 里的 `\` 是非法的，一定要归一化。

### 2.7 Controller 瘦身

```java
@RestController
@RequestMapping("/files")
@RequiredArgsConstructor
public class FileController {

    private final LocalFileStorage localStorage;

    @PostMapping("/upload")
    public Result<UploadVO> upload(@RequestPart("file") MultipartFile file) {
        return Result.success(localStorage.save(file));
    }
}
```

Controller 一行——**存储实现细节被 `LocalFileStorage` 完全屏蔽**。下一讲切 OSS 时，Controller 也只改一行。

### 2.8 联调三种场景

| # | 场景 | 请求 | 期望 |
|---|------|------|------|
| 1 | 正常 | 上传 3MB `avatar.png` | 200，`url=/files/2026/07/17/xxxxxxxx.png` |
| 2 | 超大 | 上传 8MB `big.jpg` | `{"code":500,"msg":"单文件不得超过 5MB"}` |
| 3 | 非图片 | 改扩展名为 `.exe` 上传 | `{"code":500,"msg":"仅支持 jpg/png/gif/webp"}` |

顺手在 `D:/yinxiang/uploads/2026/07/17/` 打开磁盘目录，看到 UUID 文件安静地躺着——**证据链完整**。

### 2.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 校验通过但传上来的其实是 exe | 只做扩展名校验的必然漏，进阶方案做 magic number |
| Windows 上 URL 出现反斜杠 | `LocalDate.format` 结果本来是 `/`，但拼 `File.separator` 时会串进 `\`，用 `replace("\\", "/")` 归一化 |
| 中文原文件名乱码 | 我们已经不用原文件名了，UUID 命名天然避开；如果保留可选原名字段，请用 `URLEncoder` |
| `toLowerCase()` 在某些环境把 `I` 变成 `ı` | 必须传 `Locale.ROOT`，否则土耳其语环境炸 |
| `record` 里 `getUrl()` 报错 | Java 25 `record` 的访问器叫 `url()` 而非 `getUrl()`；Jackson 序列化字段名仍是 `url` |

### 2.10 练习/思考

1. **必做**：完成三层校验版 `LocalFileStorage`，交 4 张截图（正常 / 超大 / 非图片 / 磁盘目录）；
2. **必做**：把 `MAX_SIZE` 与 `IMAGE_EXTS` 抽到 `application.yml`，用 `@ConfigurationProperties(prefix="yinxiang.upload")` 收拢到 `LocalUploadProperties`；
3. **必做**：把 Day09-01 的「直接用原始文件名」旧版代码删掉，git commit：`重构：文件上传引入安全校验与 UUID 命名`；
4. **思考**：把 `IMAGE_EXTS` 换成读配置（`yinxiang.upload.allowed-exts: jpg,png,webp`），`@Value("${...}") private Set<String> allowedExts` 是否可行？（提示：需要 `@Value("#{'${...}'.split(',')}")` SpEL 表达式）；
5. **挑战**：追加 magic number 校验——读取文件头 8 个字节，判断是否与扩展名声明的图片类型一致（PNG=`89 50 4E 47`，JPG=`FF D8 FF`，GIF=`47 49 46 38`）。

---

## 第 3 讲：阿里云 OSS 集成 + `@ConditionalOnProperty` 优雅切换

### 3.1 引入：一个真实事故

某创业公司把主账号 AK/SK 提交到 GitHub 公开仓库，凌晨 4 点被脚本扫库拿走，几小时内被开了 200 台按量付费 GPU 挖矿实例，一觉起来欠费 3 万块，公司险些倒闭。

🎯 **一个铁律**：**主账号 AK 一次都不能出现在业务代码里。** 从今天开始，所有与云资源打交道的代码都遵守这条规矩。

本讲把上一讲的本地磁盘方案「平移」到阿里云 OSS：**Controller 不变，`Storage` 接口不变，只换实现**。同时用 `@ConditionalOnProperty` 让 OSS 组件按需加载——本地开发一秒切回磁盘。

### 3.2 控制台四步准备

| 步骤 | 动作 | 关键点 |
|------|------|-------|
| 1 | 开通「对象存储 OSS」 | 免费开通，按量付费，日常几毛钱 |
| 2 | 创建 Bucket `yinxiang-yoga` | 区域「华东 1（杭州）」、读写权限「**公共读**」、存储类型「标准」 |
| 3 | 到「访问控制 RAM」创建**子用户** | 勾选 `AliyunOSSFullAccess`（生产可收敛到 `AliyunOSSPutObjectAccess`），记下 `AccessKeyId / AccessKeySecret` |
| 4 | 记 Endpoint 和 Domain | Endpoint = `https://oss-cn-hangzhou.aliyuncs.com`；Domain = `https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com` |

⚠️ **Endpoint 与 Domain 是两个不同的东西**：
- **Endpoint** —— SDK 上传时用的 API 域名，格式 `oss-cn-<region>.aliyuncs.com`；
- **Domain** —— 浏览器读取时用的域名，格式 `<bucket>.oss-cn-<region>.aliyuncs.com`；
- 上传 `putObject` 用 Endpoint；拼 URL 给前端用 Domain。

### 3.3 三个「绝不」

- ✘ **主账号 AK 用在业务**——一次都不允许；
- ✘ **AK/SK 硬编码进代码**——从 GitHub 到反编译都能扒出来；
- ✘ **AK/SK 提交进 Git**——commit 一次永远在历史里，即使删除也能通过 `git log -p` 找到。

**替代方案**：环境变量、Nacos 配置中心、阿里云 KMS 密钥托管。本讲用最简单的环境变量。

### 3.4 依赖

```xml
<dependency>
    <groupId>com.aliyun.oss</groupId>
    <artifactId>aliyun-sdk-oss</artifactId>
    <version>3.17.4</version>
</dependency>
```

### 3.5 配置

```yaml
yinxiang:
  upload:
    local:
      base-dir: D:/yinxiang/uploads
      base-url: /files
    oss:
      enabled: true
      endpoint: https://oss-cn-hangzhou.aliyuncs.com
      bucket:   yinxiang-yoga
      access-key-id:     ${OSS_AK:xxx}
      access-key-secret: ${OSS_SK:xxx}
      domain: https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com
```

🎯 **`${OSS_AK:xxx}` 语法**：优先读环境变量 `OSS_AK`，读不到才用 `xxx` 兜底。IDEA Run Configuration → Environment Variables 里配好 `OSS_AK=LTAI...` 和 `OSS_SK=...`，**不进 Git**。

### 3.6 配置类

```java
@Data
@Component
@ConfigurationProperties(prefix = "yinxiang.upload.oss")
public class OssProperties {
    private boolean enabled;
    private String endpoint;
    private String bucket;
    private String accessKeyId;
    private String accessKeySecret;
    private String domain;
}
```

### 3.7 客户端 Bean —— `@ConditionalOnProperty` 让 OSS 按需加载

```java
@Configuration
@ConditionalOnProperty(prefix = "yinxiang.upload.oss", name = "enabled", havingValue = "true")
public class OssConfig {

    @Bean(destroyMethod = "shutdown")
    public OSS ossClient(OssProperties p) {
        return new OSSClientBuilder().build(
                p.getEndpoint(),
                p.getAccessKeyId(),
                p.getAccessKeySecret());
    }
}
```

🎯 **两个细节**：

- `@ConditionalOnProperty(havingValue = "true")` —— 只有配置里 `enabled=true` 才装配这个 Config；本地开发写 `enabled=false`（或者干脆不写），**OSS Bean 根本不加载**，即使你没 AK/SK 也能启动项目；
- `destroyMethod = "shutdown"` —— Spring 容器关闭时自动调用 `ossClient.shutdown()`，释放连接池；漏了这个，某些 SDK 版本会导致进程挂 60 秒才退出。

### 3.8 `OssFileStorage` 实现

```java
@Component
@RequiredArgsConstructor
@ConditionalOnBean(OSS.class)
@Slf4j
public class OssFileStorage {

    private final OSS ossClient;
    private final OssProperties p;

    private static final Set<String> IMAGE_EXTS = Set.of("jpg", "jpeg", "png", "gif", "webp");
    private static final long MAX_SIZE = 5 * 1024 * 1024;

    public UploadVO save(MultipartFile file) {
        // 复用第 2 讲的三层校验
        if (file == null || file.isEmpty()) throw new BizException("请选择文件");
        if (file.getSize() > MAX_SIZE)      throw new BizException("单文件不得超过 5MB");
        String ext = FileNameUtil.ext(file.getOriginalFilename());
        if (!IMAGE_EXTS.contains(ext))      throw new BizException("仅支持 jpg/png/gif/webp");

        // key = images/2026/07/17/uuid.png
        String key = "images/"
                   + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
                   + "/" + UUID.randomUUID().toString().replace("-", "")
                   + "." + ext;

        try (InputStream in = file.getInputStream()) {
            ObjectMetadata meta = new ObjectMetadata();
            meta.setContentLength(file.getSize());
            meta.setContentType(file.getContentType());
            meta.setCacheControl("public, max-age=31536000");   // 一年缓存
            ossClient.putObject(p.getBucket(), key, in, meta);
        } catch (IOException e) {
            log.error("[OSS 上传] 读取文件失败 key={}", key, e);
            throw new BizException("上传失败");
        } catch (OSSException | ClientException e) {
            log.error("[OSS 上传] OSS 端异常 code={} msg={}",
                      e.getClass().getSimpleName(), e.getMessage());
            throw new BizException("上传失败：" + e.getMessage());
        }

        String url = p.getDomain() + "/" + key;
        log.info("[OSS 上传] 完成 url={} size={}", url, file.getSize());
        return new UploadVO(url, file.getSize(), ext);
    }
}
```

**四个关键点**：

1. **`try-with-resources`** —— `MultipartFile.getInputStream()` 返回的流由**调用方负责关闭**，SDK 不管；不用 try-with-resources 就是资源泄漏，几万次请求后连接池爆炸；
2. **`ContentType`** —— **不设 ContentType，浏览器会把图片当成下载**（`Content-Disposition: attachment`），前端预览爆炸；
3. **`CacheControl`** —— 图片是**不可变资源**（UUID 命名保证），随便缓存一年；
4. **双异常捕获** —— `IOException`（本地读文件失败）和 `OSSException | ClientException`（OSS 端失败）分开处理，日志里带 `code / message` 但**别把 AK 打出来**。

### 3.9 `FileNameUtil` 工具类

第 2 讲的 `ext` 方法在两处复用，抽出：

```java
public final class FileNameUtil {
    private FileNameUtil() {}
    public static String ext(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }
}
```

### 3.10 Controller 加开关

```java
@RestController
@RequestMapping("/files")
@RequiredArgsConstructor
public class FileController {

    private final LocalFileStorage localStorage;
    private final ObjectProvider<OssFileStorage> ossStorageProvider;

    @Value("${yinxiang.upload.oss.enabled:false}")
    private boolean ossEnabled;

    @PostMapping("/upload")
    public Result<UploadVO> upload(@RequestPart("file") MultipartFile file) {
        UploadVO vo = ossEnabled
                ? Objects.requireNonNull(ossStorageProvider.getIfAvailable(),
                        () -> "OSS 存储未装配，请检查配置").save(file)
                : localStorage.save(file);
        return Result.success(vo);
    }
}
```

🎯 **`ObjectProvider<T>` 是什么？**

- 普通 `@Autowired` 找不到 Bean 就抛 `NoSuchBeanDefinitionException`；
- `ObjectProvider<T>` 允许 Bean **不存在**，用 `getIfAvailable()` 返回 null 或已装配的实例；
- 在这种「按配置装配」的场景下最合适——本地开发关掉 OSS 时，`OssFileStorage` 根本没进容器，用 `ObjectProvider` 优雅兜底。

### 3.11 联调剧本

**Step 1 — 本地版**：
```yaml
yinxiang.upload.oss.enabled: false
```
重启，Postman 上传，返回 `url=/files/2026/07/17/xxx.png`。

**Step 2 — OSS 版**：
```yaml
yinxiang.upload.oss.enabled: true
```
IDEA Run Configuration 里配好 `OSS_AK` / `OSS_SK` 环境变量，重启，Postman 上传同一张图，返回 `url=https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com/images/2026/07/17/xxx.png`，浏览器直接可访问。

**Step 3 — 阿里云控制台**：到 OSS Bucket 里能看到 `images/2026/07/17/xxx.png`——**证据链完整**。

**Step 4 — 回写业务字段**：把返回的 URL 拷到 Day05 的 `POST /api/member` 请求体里的 `avatar` 字段，会员新增成功，DB 里 `tb_member.avatar` 存的就是这个 URL。

### 3.12 私有 Bucket 与签名 URL（预告）

课程封面、会员头像用「公共读」没问题。但如果上传的是**身份证扫描件、结业证书**，绝对不能公开——攻击者一旦拿到 URL 规律（比如 `yyyy/MM/dd/`），可能扫库获取隐私。

**做法**：

- Bucket 权限设为「**私有**」；
- 上传后返回**签名 URL**（含有效期），前端拿到就能预览，链接过期后自然失效。

```java
public String signedUrl(String key, Duration expire) {
    Date expiration = new Date(System.currentTimeMillis() + expire.toMillis());
    return ossClient.generatePresignedUrl(p.getBucket(), key, expiration).toString();
}
```

有效期建议 15 分钟。此技巧到「查看证件」按钮时真正用上，本讲只做预告。

### 3.13 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| OSS 上传成功但访问 URL 返回 403 | Bucket 权限是「私有」，改「公共读」或改用签名 URL |
| OSS 上传成功但访问 URL 返回 404 | Endpoint 与 Domain 区域不一致；用 `putObjectResult.getResponse().getUri()` 而不是自己拼域名 |
| `OSS ossClient` 注入失败 | 缺 `@ConditionalOnProperty` 或 `enabled=false`；或 AK 拼错、Endpoint 拼错 |
| 上传大文件（10MB+）超时 | 默认 SDK 超时 50 秒，可配 `ClientBuilderConfiguration` 调大；大文件建议改分片上传 |
| 日志里出现完整 AK/SK | **马上禁用密钥、建新密钥、检查账单**——线上事故等级 P0 |
| 图片上传成功但浏览器变成下载 | `ObjectMetadata.setContentType` 忘设 |

### 3.14 练习/思考

1. **必做**：完成 OSS 版接口，交 4 张截图（本地 URL / OSS URL / OSS 控制台目录 / IDEA 环境变量配置）；
2. **必做**：把 `POST /files/upload` 拿到的 URL 回填到 Day05 `POST /api/member`，验证会员新增能正确保存 `avatar`；
3. **必做**：写一段 300 字反思：如果 AK/SK 泄露了，你应该在 15 分钟内完成的三件事（提示：① 阿里云控制台**禁用密钥**；② **建新密钥**并部署；③ **检查账单与访问日志**）；
4. **思考**：Bucket 权限改为「私有」后，之前的 URL 会怎样？（403）如何做？（关键词：签名 URL / 预签名 URL）；
5. **挑战**：给 `OssFileStorage` 加**进度回调**（`ProgressListener`），上传 20MB 大文件时能在日志里看到 `[OSS 上传] 30% / 60% / 90%`。

---

## 第 4 讲：代理模式三形态 —— 静态 → JDK 动态 → CGLIB

### 4.1 引入：从「日志遍布 Service」讲起

Day08 你已经写了 20 多个 Service 方法，几乎每个方法开头都在打：

```java
public void save(MemberDTO dto) {
    log.info("[会员新增] name={} phone={}", dto.getName(), dto.getPhone());
    long t = System.currentTimeMillis();
    // 业务代码
    log.info("[会员新增] 完成 id={} cost={}ms", id, System.currentTimeMillis() - t);
}
```

30 个方法都要打日志、都要统计耗时、都要判断权限、都要开启事务——**同样的模板复制 30 遍**。一处改，30 处跟着改。这就是**横切关注点（Cross-cutting Concerns）**。

🎯 **AOP 的初心**：把这些横切关注点抽出去，作为「切面」，声明「在什么时候织入」；业务代码只保留业务本身。要吃透 AOP，先要看清它的地基 —— **代理模式**。

### 4.2 什么是代理

**代理 = 替身**。客户端只认代理，代理内部握着 target，调 target 前后加自己的逻辑。

现实类比：**明星（target）+ 经纪人（proxy）**。粉丝找经纪人谈合同，经纪人先审合约再交给明星，明星只管演戏。

```
外部客户端 ──调用──> Proxy(替身)
                   ├── 前置增强
                   ├── target.method()  ← 真正的业务
                   └── 后置增强
```

**类图**：`Subject`（接口）← `RealSubject`（target）/ `Proxy`（代理，也实现 Subject，持有 RealSubject 引用）。

### 4.3 静态代理 —— 复制粘贴的代理

```java
public interface MemberService {
    void save(MemberDTO dto);
}

public class MemberServiceImpl implements MemberService {
    @Override
    public void save(MemberDTO dto) {
        System.out.println("入库: " + dto.getName());
    }
}

// 静态代理类
public class LoggingMemberServiceProxy implements MemberService {
    private final MemberService target;

    public LoggingMemberServiceProxy(MemberService target) {
        this.target = target;
    }

    @Override
    public void save(MemberDTO dto) {
        long t = System.currentTimeMillis();
        System.out.println("[LOG] before save");
        try {
            target.save(dto);
        } finally {
            System.out.println("[LOG] after save cost=" + (System.currentTimeMillis() - t) + "ms");
        }
    }
}

// 使用
MemberService svc = new LoggingMemberServiceProxy(new MemberServiceImpl());
svc.save(new MemberDTO(...));
```

**优点**：一目了然，代码直白。

**痛点**：
- 每加一个业务接口就要新写一个代理类；
- 每加一个方法就要在**所有代理类**里加同一份模板；
- 100 个 Service = 100 份代理类，一处 log 格式改动要改 100 次；
- **面向对象的复制粘贴**。

### 4.4 JDK 动态代理 —— 运行时生成实现类

`java.lang.reflect.Proxy` 可以**在运行时动态生成一个实现指定接口的类**：

```java
public class LoggingHandler implements InvocationHandler {
    private final Object target;

    public LoggingHandler(Object target) {
        this.target = target;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        long t = System.currentTimeMillis();
        System.out.println("[LOG] before " + method.getName());
        try {
            return method.invoke(target, args);
        } finally {
            System.out.println("[LOG] after cost=" + (System.currentTimeMillis() - t) + "ms");
        }
    }
}

// 使用
MemberService target = new MemberServiceImpl();
MemberService proxy = (MemberService) Proxy.newProxyInstance(
        target.getClass().getClassLoader(),
        target.getClass().getInterfaces(),
        new LoggingHandler(target));
proxy.save(new MemberDTO(...));
```

**三个入参**：

| 参数 | 作用 |
|------|------|
| `ClassLoader loader` | 用哪个类加载器加载生成的 class |
| `Class<?>[] interfaces` | 生成的代理类要实现哪些接口 |
| `InvocationHandler h` | 所有方法调用都走它的 `invoke` |

**核心限制**：**目标类必须实现接口**。因为 JDK 动态代理生成的代理类是 `java.lang.reflect.Proxy` 的子类 + 实现你的接口，若没有接口，生成不出「等价的替身」。

🎯 **实验**：故意把 `MemberServiceImpl` 上的 `implements MemberService` 删掉重跑，`getInterfaces()` 返回空数组，运行时报错——印象深刻。

### 4.5 CGLIB 代理 —— 通过继承生成

CGLIB 通过**继承目标类**并覆盖所有方法生成代理，**不要求接口**：

```java
public class CglibDemo {
    public static void main(String[] args) {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(MemberServiceImpl.class);
        enhancer.setCallback((MethodInterceptor) (obj, method, params, methodProxy) -> {
            long t = System.currentTimeMillis();
            System.out.println("[LOG] before " + method.getName());
            try {
                return methodProxy.invokeSuper(obj, params);
            } finally {
                System.out.println("[LOG] cost=" + (System.currentTimeMillis() - t) + "ms");
            }
        });
        MemberServiceImpl proxy = (MemberServiceImpl) enhancer.create();
        proxy.save(new MemberDTO(...));
    }
}
```

**关键 API**：

- `Enhancer.setSuperclass(TargetClass)` —— 设定要继承的目标类；
- `Enhancer.setCallback(MethodInterceptor)` —— 设定拦截逻辑；
- `MethodInterceptor.intercept(obj, method, params, methodProxy)` —— **用 `methodProxy.invokeSuper(obj, params)` 调父类实现**，不要用 `method.invoke(target, ...)`（后者走反射，性能差且需要额外 target 引用）。

**限制**：
- 目标类**不能 `final`** —— 靠继承实现，父类 final 就没戏；
- 被增强的方法**不能 `final / private / static`** —— private 子类看不到、static 属于类不属于对象、final 子类不能覆盖。

🎯 **实验**：把 `MemberServiceImpl` 加上 `final` 关键字，`Enhancer.create()` 直接抛 `Cannot subclass final class`。

### 4.6 Spring AOP 用哪种代理？

Spring AOP 有一个默认策略：

- 目标类**实现了接口** → 默认走 JDK 动态代理；
- 目标类**没实现接口** → 走 CGLIB；
- 强制 CGLIB：`@EnableAspectJAutoProxy(proxyTargetClass = true)`。

🎯 **Spring Boot 2.x 起 `proxyTargetClass = true` 是默认值**——**不管有没有接口都走 CGLIB**。为什么？因为「有接口时走 JDK 代理」会造成注入类型不一致：

- `@Autowired MemberService svc` → 拿到接口类型的 JDK 代理，OK；
- `@Autowired MemberServiceImpl svc` → 拿不到，因为 JDK 代理是接口的实现类不是 `MemberServiceImpl`；

这个坑历史上坑了太多人，Spring Boot 一刀切默认 CGLIB，皆大欢喜。

### 4.7 观察 Spring 用的哪种代理

打开印想瑜伽项目，加：

```java
@RequiredArgsConstructor
@Component
@Slf4j
public class ProxyDebugRunner {

    private final ApplicationContext ctx;

    @PostConstruct
    void debug() {
        Object svc = ctx.getBean("memberService");
        log.info("memberService = {}", svc.getClass().getName());
    }
}
```

启动看日志：

- 未被 AOP 增强 → `com.yinxiang.service.MemberService`
- 被 AOP 增强 → `com.yinxiang.service.MemberService$$SpringCGLIB$$0` 或 `com.sun.proxy.$Proxy...`

看到这个后缀，说明 Spring 已经悄悄用 CGLIB 把你的 Bean **换成了替身**。

### 4.8 三种代理形态对比

| 维度 | 静态代理 | JDK 动态代理 | CGLIB |
|------|---------|-------------|-------|
| 生成时机 | 编译期 | 运行时 | 运行时 |
| 是否要求接口 | 是 | **是** | 否 |
| 生成机制 | 手写 | 反射生成实现类 | 继承生成子类 |
| 性能 | 最快 | 中等（反射） | 快（字节码） |
| 限制 | 一接口一代理，模板复制 | target 必须有接口 | target/方法不能 final |
| 代表场景 | 教学 Demo | 早期 Spring AOP | Spring Boot 2.x+ 默认 |

**核心不变量**：**替身 + 委托**。

### 4.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| JDK 动态代理抛 `NullPointerException` at `getInterfaces()` | 目标类没实现任何接口，JDK 代理不适用，换 CGLIB |
| CGLIB 抛 `Cannot subclass final class` | 目标类是 `final`；把 `final` 去掉或改用 JDK 代理 |
| 拿到代理但强转成 `MemberServiceImpl` 失败 | JDK 代理是接口的实现类，不是 `MemberServiceImpl` 的子类；强转要用**接口类型** |
| Spring 里 `@Autowired MemberServiceImpl impl` 报错 | 早期 Spring 走 JDK 代理时会失败；Spring Boot 2.x+ 默认 CGLIB 已经解决 |
| CGLIB 无法拦截 `private` 方法 | 子类看不到父类 private；改成 `protected` 或 `public` |

### 4.10 练习/思考

1. **必做**：分别写出**静态代理 + JDK 动态代理 + CGLIB** 三个版本的「方法耗时打印」，交代码 diff 与控制台输出截图；
2. **必做**：在印想瑜伽项目里加 `@PostConstruct` 打印 `getBean(...).getClass().getName()`，截图 `$$SpringCGLIB$$` 后缀；
3. **实验**：把 `MemberServiceImpl` 加 `final`，观察 CGLIB 报错信息，把异常堆栈贴到笔记；
4. **思考**：如果同一个类既有 `save(MemberDTO)` 又有 `save(CoachDTO)`（重载），`InvocationHandler.invoke` 里如何区分两个方法？（提示：`method.getParameterTypes()`）；
5. **挑战**：读一下 `java.lang.reflect.Proxy` 生成的字节码——`ProxyGenerator.generateProxyClass` 把结果写到磁盘，再 `javap -c` 反编译，观察 JDK 到底生成了什么。

---

## 第 5 讲：Spring AOP 五要素 + 切点表达式 + 最小可运行切面

### 5.1 引入：从「手写代理」到「注解声明」

上一讲你用 CGLIB 手写了一个代理增强 `MemberService`，本质是「拦所有方法、加日志」。**Spring AOP 就是把这件事变成注解**——你只需要写 `@Aspect + @Around("execution(...)")`，Spring 帮你：

1. 装配代理；
2. 把切点表达式解析成拦截规则；
3. 把 Advice 方法织入进去。

本讲把 AOP 的「说明书」啃完，然后写一个能立即上线的切面。

### 5.2 五要素术语字典

```
      ┌──────────── Aspect 切面 ────────────┐
      │  ┌──────── Pointcut 切点 ────────┐  │
      │  │  execution(* controller..*.*)│  │
      │  └──────────────┬───────────────┘  │
      │                 ▼                  │
      │           Advice 通知              │
      │        @Before/@After/@Around      │
      └─────────────────┬──────────────────┘
                        │ Weaving 织入（运行时）
                        ▼
                 Target 目标对象
                        │
                        ▼
                  JoinPoint 拦截时刻
```

| 术语 | 一句话 | 具体例子 |
|------|--------|---------|
| **Aspect（切面）** | 一份横切逻辑打包 | `LoggingAspect` 类头 `@Aspect` |
| **Pointcut（切点）** | 拦哪些方法的规则 | `execution(* com.yinxiang.controller..*.*(..))` |
| **Advice（通知）** | 拦到之后做什么 | 打日志、计耗时、开事务 |
| **JoinPoint（连接点）** | 拦截时刻的上下文 | 方法名、参数、目标类、返回值、异常 |
| **Weaving（织入）** | 把 Advice 塞进 target | Spring AOP 是**运行时**织入 |
| **Target** | 被代理的原始对象 | `MemberServiceImpl` 实例 |
| **Proxy** | Spring 给你的替身 | 容器里 `@Autowired` 注入的其实是它 |

### 5.3 五种 Advice —— 顺口溜「前后成异环」

| 类型 | 语义 | 注解 |
|------|------|------|
| **Before** | 方法执行**前** | `@Before` |
| **After (finally)** | 方法执行**后**（无论正常/异常，等价 Java 的 finally） | `@After` |
| **AfterReturning** | 方法**正常返回后**（可拿返回值） | `@AfterReturning` |
| **AfterThrowing** | 方法**抛异常后**（可拿异常对象） | `@AfterThrowing` |
| **Around** | **环绕**（可控制是否/何时调用 target） | `@Around` |

🎯 **日常 90% 只用 `@Around`**。它能覆盖上面四种全部能力，还能决定「要不要真的调 target」（例如权限不足时直接抛异常、幂等命中时直接返回缓存）。

### 5.4 切点表达式速查

Spring AOP 用 AspectJ 表达式：

```
execution(修饰符? 返回类型 全限定类名.方法名(参数) throws?)
```

**四大常用**：

```java
// ① 包路径匹配
@Pointcut("execution(* com.yinxiang.controller..*.*(..))")
public void controllerLayer() {}

// ② 只拦 public 方法
@Pointcut("execution(public * com.yinxiang.service..*.*(..))")
public void publicServiceLayer() {}

// ③ 拦所有加了自定义注解的方法
@Pointcut("@annotation(com.yinxiang.annotation.OperationLog)")
public void operationLog() {}

// ④ 拦类头加了 @RestController 的类
@Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
public void restController() {}

// ⑤ 组合（交集）
@Pointcut("controllerLayer() && @annotation(org.springframework.web.bind.annotation.GetMapping)")
public void controllerGetMapping() {}
```

🎯 **口诀**：`..` 任意层子包、`*` 一个通配、`(..)` 任意个参数。

**易混淆**：

| 表达式 | 含义 |
|--------|------|
| `com.yinxiang.controller.*` | 只匹配 `controller` 包**下一层**的类 |
| `com.yinxiang.controller..*` | 匹配 `controller` 包及**所有子包**的类 |
| `*(..)` | 任意个参数 |
| `*(*)` | **恰好** 1 个参数 |
| `*(String)` | 恰好 1 个 String 参数 |

### 5.5 `@Around` 标准骨架

```java
@Around("controllerLayer()")
public Object aroundController(ProceedingJoinPoint pjp) throws Throwable {
    long t = System.currentTimeMillis();
    try {
        Object ret = pjp.proceed();
        // 正常返回后
        return ret;
    } catch (Throwable e) {
        // 抛异常后
        throw e;              // ⚠️ 一定要重新抛，否则吞异常
    } finally {
        // 无论成败
        log.info("cost={}ms", System.currentTimeMillis() - t);
    }
}
```

🎯 **三个不能改的地方**：

1. **返回类型 `Object`** —— 因为被切的业务方法各不相同；
2. **必须抛 `Throwable`** —— 兼容所有异常层次；
3. **`throw e` 不能省** —— 省了，业务异常被 AOP 吞掉、前端拿到 200 但业务其实抛异常，**事故等级 P1**。

### 5.6 最小可运行切面 —— `TimingAspect`

```java
@Aspect
@Component
@Slf4j
public class TimingAspect {

    @Pointcut("execution(* com.yinxiang.controller..*.*(..))")
    public void controllerLayer() {}

    @Around("controllerLayer()")
    public Object aroundController(ProceedingJoinPoint pjp) throws Throwable {
        long t = System.currentTimeMillis();
        String signature = pjp.getSignature().toShortString();
        try {
            Object ret = pjp.proceed();
            long cost = System.currentTimeMillis() - t;
            if (cost > 500) {
                log.warn("[耗时-慢接口] {} cost={}ms", signature, cost);
            } else {
                log.info("[耗时] {} cost={}ms", signature, cost);
            }
            return ret;
        } catch (Throwable e) {
            log.warn("[耗时-异常] {} cost={}ms ex={}",
                     signature, System.currentTimeMillis() - t, e.toString());
            throw e;
        }
    }
}
```

**验证**：重启项目，Postman 调一个 `GET /members/{id}`，控制台立刻出现：

```
[耗时] MemberController.get cost=42ms
```

**你没有动 Controller 一行代码**，就给全部 Controller 加了统计。**这就是 AOP 的力量。**

### 5.7 进阶：`@OperationLog` 注解式切面

需求：不是所有方法都要日志——只有加了 `@OperationLog` 注解的方法才要。**注解式切面**天然细粒度。

**Step 1 — 自定义注解**：

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface OperationLog {
    String value() default "";   // 业务描述，如「新增会员」
}
```

**Step 2 — 切面**：

```java
@Aspect
@Component
@Slf4j
public class OperationLogAspect {

    @Around("@annotation(operationLog)")
    public Object around(ProceedingJoinPoint pjp, OperationLog operationLog) throws Throwable {
        String biz = operationLog.value();
        log.info("[操作日志] {} args={}", biz, Arrays.toString(pjp.getArgs()));
        long t = System.currentTimeMillis();
        try {
            Object ret = pjp.proceed();
            log.info("[操作日志] {} OK cost={}ms", biz, System.currentTimeMillis() - t);
            return ret;
        } catch (Throwable e) {
            log.warn("[操作日志] {} FAIL cost={}ms ex={}",
                     biz, System.currentTimeMillis() - t, e.toString());
            throw e;
        }
    }
}
```

🎯 **注意**：`@Around("@annotation(operationLog)")` 里的 `operationLog` **必须与方法参数名一致**——Spring AOP 通过参数名绑定注解实例。

**Step 3 — 使用**：

```java
@PostMapping
@OperationLog("新增会员")
public Result<Void> save(@RequestBody @Valid MemberDTO dto) {
    memberService.save(dto);
    return Result.success();
}
```

Postman 调一次 `POST /members`，日志出现：

```
[操作日志] 新增会员 args=[MemberDTO(name=张三, phone=138...)]
[操作日志] 新增会员 OK cost=54ms
```

Day10 我们会把「操作日志」升级到「入库审计」，本讲先建立注解式切面的骨架。

### 5.8 `pjp` 能给你什么

| API | 返回 | 用途 |
|-----|------|------|
| `pjp.getSignature()` | `Signature` | 方法签名 |
| `pjp.getSignature().toShortString()` | `String` | 类名.方法名 |
| `((MethodSignature) pjp.getSignature()).getMethod()` | `Method` | 反射拿注解、参数、返回类型 |
| `pjp.getArgs()` | `Object[]` | 入参数组 |
| `pjp.getTarget()` | `Object` | 原始目标对象 |
| `pjp.getThis()` | `Object` | 代理对象本身 |
| `pjp.proceed()` | `Object` | 执行 target 方法 |
| `pjp.proceed(args)` | `Object` | 传入修改后的参数执行 |

### 5.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 切面加了但没生效 | 缺 `@Component`；或切了 `private` 方法；或切了 `@PostConstruct` 时刻 |
| Postman 拿到 200 但业务其实抛异常 | `@Around` 里没写 `throw e`，异常被吞 |
| 切面栈溢出 | 切点表达式把切面自己所在包也切进去，用 `!within(com.yinxiang.aspect..*)` 排除 |
| 两个切面执行顺序不确定 | 加 `@Order(1)`（值越小越早进入，越晚退出，洋葱模型） |
| `@annotation(x)` 绑定不上 | 方法形参名与切点表达式里的名字必须一致 |
| `@Before` 里 `pjp.proceed()` 报错 | `@Before` 用的是 `JoinPoint` 不是 `ProceedingJoinPoint`，只有 `@Around` 才能 `proceed` |
| 切了 Controller 层但拿不到 `HttpServletRequest` | 参数里加一个 `HttpServletRequest req` 即可，Spring 会传入；或用 `RequestContextHolder` |

### 5.10 练习/思考

1. **必做**：完成 `TimingAspect` Controller 全局耗时切面，跑通 3 个不同接口，交日志截图；
2. **必做**：完成 `OperationLogAspect` + `@OperationLog` 注解，给 Day09-01 的 `POST /files/upload` 打上 `@OperationLog("上传文件")`，联调看日志；
3. **必做**：断点看 `pjp.getSignature()` 到底是什么类型（`MethodSignature`），学着从中拿 `Method` 对象；
4. **思考**：如果两个切面都命中同一个方法，执行顺序由什么决定？（`@Order` 值越小越早进入 / 越晚退出）；
5. **挑战**：写一版 `@Around` 版的**幂等切面**——注解 `@Idempotent(key="#dto.phone", expire=5)`，5 秒内重复调抛业务异常（先 mock 一个内存 `ConcurrentHashMap`，Redis 版留到后面章节）。

---

## 第 6 讲：`this.method` 陷阱 + 三种解法 + 观察代理对象 + Day09 收官

### 6.1 引入：一个「肯定要栽」的坑

反问一个场景：

```java
@Service
public class OrderService {

    @Transactional
    public void create(Order o) {
        // ... 主流程
        this.updateStock(o);        // ← 用 this 调用
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock(Order o) {
        // 期望：开一个新事务
    }
}
```

期望：`updateStock` 开启**新事务**（`REQUIRES_NEW`），即使 `create` 事务回滚，`updateStock` 也已提交。

实际：`updateStock` **和 `create` 共用同一个事务**，`REQUIRES_NEW` **没生效**——`create` 回滚时 `updateStock` 一起回滚。

这是**面试高频、新手必栽**的坑，本讲把它彻底讲透。

### 6.2 原理：外部 → Proxy → Target，`this` 绕过 Proxy

```
外部客户端
    │
    │ 调用 orderService.create()
    ▼
┌────────────┐
│   Proxy    │← Spring 容器里注入的是这个
│ (AOP 增强) │
└─────┬──────┘
      │ 内部委托
      ▼
┌────────────┐
│   Target   │← 真实 OrderService 实例
│  .create() │
│     │      │
│     ▼      │
│  this.updateStock()  ← 直接调用真实对象，绕过 Proxy
└────────────┘
```

**关键点**：

- Spring 容器里注入的是 `orderService$Proxy`；
- **外部调用**先进代理，代理执行 AOP（事务、日志、耗时）后再委托给真实对象；
- 但一旦**进入了 `create` 方法体**，`this` 就是**真实对象**而非代理；
- `this.updateStock()` 直接调真实对象的方法，**没经过代理**，AOP 全部落空——事务、日志、耗时统统失效。

一句话：**AOP 只对「从代理进入」的调用生效。**

### 6.3 复现 bug（印想瑜伽 sandbox 包，别污染业务代码）

```java
@Service
@Slf4j
public class OrderService {

    @Transactional
    public void create() {
        String txName = TransactionSynchronizationManager.getCurrentTransactionName();
        log.info("[create] 事务名 = {}", txName);
        this.updateStock();                    // ← 陷阱
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock() {
        String txName = TransactionSynchronizationManager.getCurrentTransactionName();
        log.info("[updateStock] 事务名 = {}", txName);
    }
}
```

Controller 调 `create()`，观察日志：

```
[create] 事务名 = com.yinxiang.sandbox.OrderService.create
[updateStock] 事务名 = com.yinxiang.sandbox.OrderService.create  ← 一模一样！
```

**证据锁定**：两个方法事务名一致，`REQUIRES_NEW` 没触发。

### 6.4 三种解法

#### 解法 1：自注入 —— `@Autowired @Lazy self`

```java
@Service
@Slf4j
public class OrderService {

    @Autowired @Lazy
    private OrderService self;

    @Transactional
    public void create() {
        self.updateStock();          // 走代理
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock() { }
}
```

- `@Autowired` 拿到的 `self` 就是**代理对象**（容器里的 Bean 本来就是代理）；
- **`@Lazy` 是关键**——避免 Bean 初始化阶段的**循环依赖**（`OrderService` 依赖 `OrderService` 自己，不加 `@Lazy` 有些场景会启动失败）；
- 缺点：把「代理」这个实现细节暴露到业务代码。

#### 解法 2：`AopContext.currentProxy()`

```java
@EnableAspectJAutoProxy(exposeProxy = true)   // ⚠️ 必须开启
@SpringBootApplication
public class YogaApplication { ... }

@Service
public class OrderService {

    @Transactional
    public void create() {
        ((OrderService) AopContext.currentProxy()).updateStock();
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock() { }
}
```

- `AopContext.currentProxy()` 拿当前线程绑定的代理对象；
- **必须**在启动类加 `@EnableAspectJAutoProxy(exposeProxy = true)`；
- 忘开 `exposeProxy` 时抛 `IllegalStateException: Cannot find current proxy`；
- 缺点：耦合 Spring AOP 内部 API，业务代码不干净。

#### 解法 3：方法拆到另一个 Service —— **推荐**

```java
@Service
@RequiredArgsConstructor
public class OrderService {

    private final StockService stockService;

    @Transactional
    public void create() {
        stockService.updateStock();          // 跨类调用，天然走代理
    }
}

@Service
public class StockService {

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void updateStock() { }
}
```

- **跨类调用天然走代理**，AOP 自然生效；
- **最干净**，符合单一职责原则；
- **推荐**的默认解法。

### 6.5 三种解法对比

| 解法 | 侵入性 | 是否需要额外配置 | 循环依赖风险 | 推荐 |
|------|--------|-----------------|-------------|------|
| ① 自注入 `@Lazy self` | 低 | 无 | 需 `@Lazy` 规避 | 快速修 |
| ② `AopContext.currentProxy()` | 高（耦合 Spring API） | 需 `exposeProxy=true` | 无 | 不推荐 |
| ③ 拆到另一个 Service | 中（架构变动） | 无 | 无 | ✅ **首选** |

### 6.6 观察代理对象

```java
@Autowired ApplicationContext ctx;

@PostConstruct
void debug() {
    Object svc = ctx.getBean("orderService");
    log.info("orderService = {}", svc.getClass().getName());
}
```

- 未增强 → `com.yinxiang.sandbox.OrderService`
- 被增强 → `com.yinxiang.sandbox.OrderService$$SpringCGLIB$$0`

看到 `$$SpringCGLIB$$` 就说明有代理。**给 `OrderService` 加 `final` 试试**——项目启动直接抛 `Cannot subclass final class`，CGLIB 靠继承，父类 final 就没戏（回顾第 4 讲）。

### 6.7 「切面加了没生效」5 大排查点

| # | 排查点 | 检查方法 |
|---|--------|---------|
| 1 | `@Aspect` + `@Component` 齐不齐？ | 缺任一切面不装配 |
| 2 | 目标方法是 `private / static / final`？ | Spring AOP 只切 public 非 final 方法 |
| 3 | 是不是 `this.method` 内部调用？ | **今日主课**，见 6.2 |
| 4 | 是不是 `@PostConstruct` 阶段？ | 代理装配未完成，此时切不到 |
| 5 | 切点表达式是不是把自己所在包也切进去了？ | 栈溢出；用 `!within(com.yinxiang.aspect..*)` 排除 |

### 6.8 Day09 六讲串讲

```
第 1 讲 ──── multipart 双阈值 + ResourceHandler 静态映射
   │
   ▼
第 2 讲 ──── 三层校验 + UUID + 日期分桶 → LocalFileStorage
   │
   ▼                                            ┐
第 3 讲 ──── @ConditionalOnProperty + OSS       │ 文件上传三讲：URL 字段最后一公里
             → OssFileStorage + Controller 开关 ┘
   │
   ▼
第 4 讲 ──── 代理三形态：静态 / JDK / CGLIB     ┐
   │                                            │
   ▼                                            │
第 5 讲 ──── AOP 五要素 + 切点表达式             │ 代理与 AOP 三讲：为 Day10 铺路
             + TimingAspect + OperationLog      │
   │                                            │
   ▼                                            │
第 6 讲 ──── this 陷阱 + 三种解法                ┘
```

**Day09 交付验收**：
- `POST /files/upload` **本地版 + OSS 版** 双通道；
- `TimingAspect` Controller 全局耗时切面；
- `OperationLogAspect` 注解式操作日志切面；
- `this` 陷阱三种解法各跑通一次。

**Day10 预告**：AOP 实战——把所有 Service 的**操作日志**统一落库到 `tb_operation_log`，把**全局异常处理**增强成**「异常也走操作日志」**，把今天的两个切面从「日志打印」升级到「审计追踪」。

### 6.9 Day09 核心口诀

- **上传三层校验**：非空 → 大小 → 白名单扩展名；
- **上传命名策略**：`yyyy/MM/dd/<UUID>.<ext>`，服务端自主命名；
- **OSS 三个绝不**：主账号 AK 不用、AK/SK 不硬编码、AK/SK 不进 Git；
- **代理三形态**：静态代理复制粘贴 → JDK 动态代理需要接口 → CGLIB 继承生成；
- **AOP 五要素**：Aspect / Pointcut / Advice / JoinPoint / Weaving；
- **Advice 顺口溜**：前后成异环——`@Before @After @AfterReturning @AfterThrowing @Around`；
- **`@Around` 骨架**：`try proceed → catch throw e → finally`；
- **切点四剑客**：`execution` / `@annotation` / `@within` / `A && B`；
- **切面没生效 5 大排查**：注解齐、非 private、非 this、非 `@PostConstruct`、不切自己所在包；
- **`this` 陷阱首选解法**：把方法拆到另一个 Service。

### 6.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `@Transactional(REQUIRES_NEW)` 没开新事务 | 十有八九是 `this.method` 内部调用，用解法 3 |
| `AopContext.currentProxy()` 抛 `IllegalStateException` | 未开 `@EnableAspectJAutoProxy(exposeProxy = true)` |
| `@Autowired @Lazy self` 启动时循环依赖 | `@Lazy` 加了吗？还有可能 Spring 版本 bug，升级 Boot 版本 |
| `@PostConstruct` 方法上的 `@Around` 切面没生效 | 代理装配未完成，此时切不到；用 `ApplicationRunner` 替代 |
| 项目启动抛 `Cannot subclass final class` | 目标类有 `final`，CGLIB 靠继承没法代理 |
| 切面把自己所在包也切了，栈溢出 | 切点表达式加 `!within(com.yinxiang.aspect..*)` 排除 |

### 6.11 练习/思考

1. **必做**：复现 `this` 陷阱一次，交两张日志截图（bug 现场 + 修复后）；
2. **必做**：用三种解法各解决一次，各交一张日志截图；
3. **必做**：Day09 复盘 500 字：踩过的坑（≥ 3 个）+ 收获（≥ 3 条）+ 明天想问老师的问题（≥ 1 个）；
4. **思考**：`self` 自注入用 `@Autowired @Lazy` 的原因是什么？直接 `@Autowired` 不加 `@Lazy` 会怎样？（提示：`@Lazy` 避免 Bean 初始化阶段的**循环依赖**）；
5. **挑战**：给 `OrderService` 加乐观锁——`create` 里 `this.updateStock` 用 `where version=?`，`rows == 0` 时把 `this.retry()` 也走一遍（先复现失败，再用解法 3 修复）。

---

## 附录 A：Day09 交付物一览

| 序号 | 分类 | 交付 | 关键点 |
|------|------|------|--------|
| 1 | 文件上传 | `POST /files/upload` 本地版 | 三层校验 + UUID + 日期分桶 |
| 2 | 文件上传 | `POST /files/upload` OSS 版 | RAM 子用户 + AK 环境变量 + `@ConditionalOnProperty` |
| 3 | 文件上传 | `WebConfig.addResourceHandlers` | `file:` 协议 + 末尾 `/` |
| 4 | 文件上传 | `UploadVO(url,size,ext)` | Java 25 `record`，前端契约稳定 |
| 5 | 代理 | 静态代理 Demo | `Proxy implements Subject` |
| 6 | 代理 | JDK 动态代理 Demo | `Proxy.newProxyInstance` + `InvocationHandler` |
| 7 | 代理 | CGLIB 代理 Demo | `Enhancer.setSuperclass` + `MethodInterceptor` |
| 8 | AOP | `TimingAspect` | `@Around` + `execution(..controller..)` |
| 9 | AOP | `OperationLogAspect` | `@Around` + `@annotation(OperationLog)` |
| 10 | AOP | `this` 陷阱三种解法 | 自注入 / AopContext / 拆 Service |

## 附录 B：完整 `application.yml` 与依赖

```yaml
spring:
  servlet:
    multipart:
      max-file-size:    10MB
      max-request-size: 30MB
yinxiang:
  upload:
    local:
      base-dir: D:/yinxiang/uploads      # Linux/Mac: /opt/yinxiang/uploads
      base-url: /files
    oss:
      enabled: false                      # 默认关闭，改 true 才启用 OSS
      endpoint: https://oss-cn-hangzhou.aliyuncs.com
      bucket:   yinxiang-yoga
      access-key-id:     ${OSS_AK:xxx}
      access-key-secret: ${OSS_SK:xxx}
      domain: https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com
```

```xml
<dependency>
    <groupId>com.aliyun.oss</groupId>
    <artifactId>aliyun-sdk-oss</artifactId>
    <version>3.17.4</version>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>
```

---

**Day09 学生讲义完**
