# 《AI 应用 Web 开发》 - 学生讲义（Day08：多表关联设计与课程管理·查询 + 课程管理·新增/修改/删除）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day07 的学生（掌握 Spring Boot 4.0、MyBatis 3.5+、Bean Validation、Result 统一响应、全局异常、Logback 生产配置、教练模块与教室模块 CRUD）**

**技术版本基线**：Spring Boot 4.0 / Java 25 / Vue 3.5+ / pnpm 9 / MyBatis 3.5+ / MySQL 8.0 / Redis 8.x / Docker 24+ / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。前七天已经把「会员」「教练」「教室」三张主数据表 CRUD 全部打通，`Result<T>`、`BizException`、`GlobalExceptionHandler`、`logback-spring.xml` 也已经就位。今天要做的事情听起来很朴素——**给会馆加一张课程表**——但它是整个系统第一次做「多表关联」：一节课 = 一位教练 + 一间教室 + 一段时段 + 一份定价。前三讲把「查」跑通：表怎么建、resultMap 怎么写嵌套、分页多表联查的 SQL 与索引怎么用；后三讲把「写」跑通：DTO 校验、外键存在性、区间重叠冲突检测、状态流转与逻辑删除。到今晚，`CourseController` 会有 6 个接口、Service 层会有 5 个方法、Mapper 会有 5 条以上 SQL——从此，会员可以看到课程列表，管理员可以排课与改课。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 课程模块承上启下 + `tb_course` 表设计 | 完整 DDL + 示例数据 + 索引方案 |
| 第 2 讲 | 实体 / VO 分层 + MyBatis resultMap 一对一映射 | `Course` / `CourseVO` + 嵌套/扁平两种 resultMap |
| 第 3 讲 | 分页多表联查 SQL + Service 层查询 | `selectPage` + `selectPageCount` + `pageQuery` |
| 第 4 讲 | 外键存在性校验 + 课程 DTO 与基础校验 | `ExistenceChecker` + `CourseAddDTO/UpdateDTO` + `@ValidTimeRange` |
| 第 5 讲 | 冲突检测 SQL + 新增 / 修改 Service | 区间重叠四情形 + `countCoachConflict` + `add` / `update` |
| 第 6 讲 | 状态流转 + 删除策略 + Controller 汇总 + AI 生成冲突检测 | 表驱动状态机 + `updateStatus` + `CourseController` 六接口 |

---

## 第 1 讲：课程模块承上启下 + tb_course 表设计

### 1.1 引入：三张主数据表之间还缺一个「中枢」

Day07 结束时，`yoga-member` 项目里已经能做到：

- 教练能建（`tb_coach`）
- 教室能建（`tb_room`）
- 会员能注册（`tb_member`）

可管理员在钉钉群里问了一个非常朴素的问题：

> 会员现在打开小程序，看到的是空的——他要预约「张老师周三 20:00 的流瑜伽」，可这条排课在哪里？

一节瑜伽课要落地成一条数据库记录，至少需要 4 个要素：**谁教（教练）、何时开（时段）、哪里上（教室）、什么内容（课程）**。前三个表是「资源」，真正把它们**串起来**的是**课程**。所以从 Day08 开始，SQL 从「单表 CRUD」跨入「多表 JOIN」。

🎯 **一句话痛点**：**教练、教室、会员各自独立时都还算干净，一旦要「关联」，DDL / SQL / 校验 / 状态四个维度全部升级。**

### 1.2 为什么把「课程」放在项目后半段

划重点：课程模块是**依赖链最深**的一张表——

```text
tb_member  ─┐
tb_coach   ─┼──> tb_course ──> tb_booking
tb_room    ─┘
```

它依赖 `tb_coach`、`tb_room`（外键指向）、`tb_member`（预约时通过 `tb_booking` 关联），而且它的字段设计还要**为将来的报名与状态流转留位子**（`enrolled_count`、`status`）。所以：

1. 早于它做，其他三张主数据没建好，`INSERT` 都写不通；
2. 晚于它做，`tb_booking`、报表、教练日程都会阻塞；
3. **恰好放在 Day08**——既有前置铺垫（校验、异常、日志、双重唯一），又能给后续「预约模块」「报表模块」「状态定时任务」留出接口。

💡 **口诀**：**资源表先立、关联表后立、事务表最末**。这句话在瑜伽会馆里适用，在电商、酒店、SaaS 里也一样——课程之于我们，就等于订单之于电商。

### 1.3 tb_course 表 DDL

放到 `sql/schema/09_course.sql`：

```sql
CREATE TABLE tb_course (
  id              BIGINT       PRIMARY KEY AUTO_INCREMENT COMMENT '课程 id',

  title           VARCHAR(100) NOT NULL COMMENT '课程标题',
  coach_id        BIGINT       NOT NULL COMMENT '授课教练 id',
  room_id         BIGINT       NOT NULL COMMENT '上课教室 id',

  start_time      DATETIME     NOT NULL COMMENT '开始时间（左闭）',
  end_time        DATETIME     NOT NULL COMMENT '结束时间（右开）',

  capacity        INT          NOT NULL COMMENT '课程容量（人）',
  enrolled_count  INT          NOT NULL DEFAULT 0 COMMENT '已报名人数（冗余）',

  status          TINYINT      NOT NULL DEFAULT 0
                  COMMENT '0 待开始 1 报名中 2 进行中 3 已结束 4 已取消',

  fee             DECIMAL(10,2) NOT NULL COMMENT '课程费用（元）',
  intro           TEXT                   COMMENT '课程介绍',
  cover_url       VARCHAR(255)           COMMENT '封面 URL',

  create_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  update_time     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted         TINYINT      NOT NULL DEFAULT 0 COMMENT '0 未删 1 已删',

  KEY idx_coach    (coach_id),
  KEY idx_room     (room_id),
  KEY idx_start    (start_time),
  KEY idx_status   (status),
  KEY idx_conflict (coach_id, start_time, end_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程';
```

### 1.4 字段逐个说明

划重点：**每一个字段都要能解释「为什么是它，不是别的类型」**——面试常考、生产真出事。

| 字段 | 类型 | 说明 |
|---|---|---|
| `id` | `BIGINT` | 主键，`AUTO_INCREMENT` |
| `title` | `VARCHAR(100)` | 标题；`utf8mb4` 下最多存 100 汉字 |
| `coach_id` / `room_id` | `BIGINT` | 逻辑外键，不加真实 FK 约束 |
| `start_time` / `end_time` | `DATETIME` | 存**绝对时间**，避免时区歧义；不用 `TIMESTAMP` |
| `capacity` | `INT` | 课程最多能容纳多少人；受教室容量约束 |
| `enrolled_count` | `INT` | **冗余字段**：不用每次 `count(*)`，写入时同步 +1 |
| `status` | `TINYINT` | 五档业务状态，见 1.5 |
| `fee` | `DECIMAL(10,2)` | 金额**必须**用 `DECIMAL`，绝不用 `FLOAT/DOUBLE` |
| `intro` | `TEXT` | 富文本或长介绍；超过 5000 字前端可自行截断 |
| `cover_url` | `VARCHAR(255)` | 封面图 URL；文件本身走 Day09 的 OSS |
| `deleted` | `TINYINT` | 逻辑删除标记 |

⚠️ **特别注意**：`enrolled_count` 是**冗余**——它的「真值」是 `SELECT COUNT(*) FROM tb_booking WHERE course_id = ?`，但每次列表接口都跑一次子查询非常昂贵。冗余带来的代价是**必须保持一致**：报名成功要 +1，退款成功要 -1，报名和退款的写操作都必须放在同一个事务里更新它。

### 1.5 status 五种状态的业务含义

```text
0 待开始   → 课程刚创建，还没手动发布，前台看不到
1 报名中   → 已发布，会员可以看到并预约
2 进行中   → start_time 已到，未到 end_time
3 已结束   → end_time 已到（终态）
4 已取消   → 手工取消（终态）
```

划重点：

- `0 → 1`：管理员在后台点「发布」，手工触发；
- `1 → 2` / `2 → 3`：**定时任务**扫描 `start_time` / `end_time` 自动流转（Day13-14 讲）；
- `0 → 4`、`1 → 4`：手工取消；`2 → 4` 业务上一般禁止（已经上课了）；
- `3` 与 `4` 都是**终态**：不能再回流。

### 1.6 索引设计

划重点：**索引不是越多越好**，加错了写入变慢、加漏了查询变慢。本表五条索引各司其职：

| 索引名 | 覆盖字段 | 用途 |
|---|---|---|
| `PRIMARY` | `id` | 主键 |
| `idx_coach` | `coach_id` | 按教练筛课程；教练日程页 |
| `idx_room` | `room_id` | 按教室筛课程 |
| `idx_start` | `start_time` | 时间线排序 / 定时任务扫描 |
| `idx_status` | `status` | 按状态过滤（已发布、进行中） |
| `idx_conflict` | `(coach_id, start_time, end_time)` | **冲突检测**专用组合索引 |

`idx_conflict` 是本表最重要的索引——**第 5 讲**的区间重叠 SQL 会重度依赖它。它的三个字段顺序不能变：最左前缀 `coach_id` 等值命中，再走 `start_time` 范围扫描，`end_time` 作为覆盖索引降低回表次数。

💡 **口诀**：**等值列在前、范围列在后、覆盖列压尾**。这是组合索引的三段式。

### 1.7 外键的取舍：物理外键 vs 逻辑外键

这是每个新项目都必然要做的选择。放一张对比：

| 维度 | 物理外键（DDL 加 `FOREIGN KEY`） | 逻辑外键（不加约束，靠 Service 校验） |
|---|---|---|
| 数据一致性 | 数据库强保证 | 依赖代码，漏一处校验就脏 |
| 分库分表 | ❌ 跨库无法建立外键 | ✅ 完全兼容 |
| 迁移 / DDL 变更 | 依赖关系复杂，改表要拆约束 | 灵活 |
| 逻辑删除 | 物理外键会阻止软删（父表还在但子表已引用） | 无阻力 |
| 生产建议 | 中小项目可用 | **中大型项目主流选择** |

⚠️ **特别注意**：本项目**不加物理外键**——用 `KEY idx_coach(coach_id)` 保留普通索引以加速查询，但**不**用 `FOREIGN KEY(coach_id) REFERENCES tb_coach(id)`。所有存在性校验放到 Service 层（第 4 讲的 `ExistenceChecker`）。这也是国内 90% 互联网公司的做法。

### 1.8 示例数据

联调准备：先造一批数据方便后续几讲直接跑通。

```sql
-- 前置：假设 tb_coach 已有 id=1,2；tb_room 已有 id=1,2 且 capacity>=20
INSERT INTO tb_course
  (title, coach_id, room_id, start_time, end_time,
   capacity, enrolled_count, status, fee, intro, cover_url)
VALUES
  ('周一晨间哈他',   1, 1, '2026-07-20 08:00:00', '2026-07-20 09:00:00',
   20, 0, 1,  88.00,  '基础哈他，适合新手',   NULL),
  ('周二夜阴瑜伽',   1, 2, '2026-07-21 20:00:00', '2026-07-21 21:00:00',
   12, 0, 1, 128.00,  '阴瑜伽，放松深层组织', NULL),
  ('周三流瑜伽',     2, 1, '2026-07-22 19:30:00', '2026-07-22 20:30:00',
   20, 0, 0, 128.00,  '流瑜伽，动态串联',     NULL);
```

### 1.9 联调剧本（本讲预热）

本讲只建表 + 造数据，没有接口可调。用 MySQL 客户端做两组自检：

```sql
-- 1. 三张主数据表的关联性检查（应返回 3 行）
SELECT c.id, c.title, co.name AS coach_name, r.name AS room_name
FROM tb_course c
LEFT JOIN tb_coach co ON co.id = c.coach_id
LEFT JOIN tb_room  r  ON r.id  = c.room_id
WHERE c.deleted = 0;

-- 2. 索引使用检查（应看到 key = idx_conflict）
EXPLAIN
SELECT * FROM tb_course
WHERE coach_id = 1
  AND start_time >= '2026-07-20 00:00:00'
  AND start_time <  '2026-07-21 00:00:00';
```

期望 `EXPLAIN` 的 `type` 列是 `range`、`key` 列是 `idx_conflict`、`rows` 是个位数——**这就是组合索引工作正常的样子**。

### 1.10 pitfall / 注意

1. **`DATETIME` vs `TIMESTAMP`**：`TIMESTAMP` 只到 2038 年，且**会随时区自动换算**；本项目排课要写多年后的时间且时区固定东八区，一律用 `DATETIME`。
2. **`DECIMAL` vs `FLOAT/DOUBLE`**：金额只能用 `DECIMAL`。`FLOAT/DOUBLE` 会出现 `0.1 + 0.2 ≠ 0.3` 的经典二进制精度问题——上线后对账差 1 分钱都是灾难。
3. **`enrolled_count` 冗余字段的一致性**：写入 `tb_booking` 时必须同步 `UPDATE tb_course SET enrolled_count = enrolled_count + 1`。写在同一个事务里，任何一步失败整体回滚。
4. **软删除后唯一索引**：如果给 `title + start_time` 加过唯一索引，逻辑删除后再重建同名课程会因唯一冲突失败。解决方案是**联合 `deleted` 字段**：`UNIQUE KEY uk_title_start (title, start_time, deleted)`。
5. **字符集 utf8mb4**：`utf8` 只支持 3 字节字符，Emoji 与生僻字会**直接报错**。所有表统一 `utf8mb4`。

### 1.11 练习 / 思考

1. **必做**：把 `tb_course` 表 DDL 与示例数据在本地 MySQL 8.0 上执行一遍，确保 `EXPLAIN` 能命中 `idx_conflict`。
2. **必做**：思考「`enrolled_count` 冗余字段」是否可以省掉，改成每次 `count(*)`？在什么场景下省掉更合理？在什么场景下必须冗余？
3. **思考**：如果业务将来要支持**跨月**的连续课程（如每周三 19:30 一节，连续 10 周），单表 `tb_course` 会怎么演化？是插 10 条记录，还是引入「课程周期表」？
4. **挑战**：为 `title` 加一个 `FULLTEXT` 全文索引，试试 `MATCH ... AGAINST` 语法在 100 万数据下能否比 `LIKE '%xx%'` 快一个数量级。

---

## 第 2 讲：实体 / VO 分层 + MyBatis resultMap 一对一映射

### 2.1 引入：Controller 直接返回实体，前端会怎么骂

上一讲把表建好了。假设最偷懒的写法是——`Controller` 直接返回 `Course` 实体：

```java
// ❌ 反面教材
@GetMapping("/{id}")
public Result<Course> detail(@PathVariable Long id) {
    return Result.success(courseMapper.selectById(id));
}
```

前端拿到的 JSON 是这样的：

```json
{
  "code": 0,
  "msg": "OK",
  "data": {
    "id": 1,
    "title": "周一晨间哈他",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-07-20T08:00:00",
    "endTime": "2026-07-20T09:00:00",
    "capacity": 20,
    "enrolledCount": 0,
    "status": 1,
    "fee": 88.00,
    "createTime": "2026-07-15T10:00:00",
    "updateTime": "2026-07-15T10:00:00",
    "deleted": 0
  }
}
```

前端会立刻发消息回来：

> 你这个 `coachId=1` 我怎么用？我要显示「张教练」，我不能拿 id 再调一次接口吧？还有 `deleted`、`createTime`、`updateTime` 我根本不需要，能不能别塞给我？

🎯 **一句话痛点**：**实体是「表结构的 Java 表达」，它服务于 ORM；前端要的是「视图对象」，它服务于展示。两者的字段不该一模一样。**

### 2.2 核心概念：Entity 与 VO 的边界

划重点：

| 层次 | 定位 | 字段来源 | 命名后缀 |
|---|---|---|---|
| **Entity** | 一张表一个类 | 数据库列一一对应 | 无后缀（`Course`、`Coach`） |
| **DTO**    | 前端传给后端 | 请求参数子集 | `AddDTO` / `UpdateDTO` / `QueryDTO` |
| **VO**     | 后端返给前端 | 展示字段 + 关联信息 | `VO` / `BriefVO` |

`Entity` 与 `VO` 是**互相独立**的两个类——不要试图给 `Course` 加一个 `coachName` 字段完事，那会让 Entity 沾染业务展示逻辑，坏味道。

💡 **口诀**：**Entity 贴数据库、DTO 贴请求、VO 贴前端**。中间的转换是 Service 层（或专门的 `Converter` / `MapStruct`）的活。

### 2.3 Course 实体源码

`com.yinxiang.entity.Course`：

```java
package com.yinxiang.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 课程实体，与 tb_course 一一对应。
 */
@Data
public class Course {

    private Long id;
    private String title;
    private Long coachId;
    private Long roomId;

    private LocalDateTime startTime;
    private LocalDateTime endTime;

    private Integer capacity;
    private Integer enrolledCount;
    private Integer status;

    private BigDecimal fee;
    private String intro;
    private String coverUrl;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private Integer deleted;
}
```

⚠️ **特别注意**：所有时间字段用 `LocalDateTime` 而**不是** `Date`。`Date` 是 JDK 1.0 的老古董，可变、无时区、格式混乱；`LocalDateTime` 是 Java 8 的现代 API，不可变、有明确语义、序列化格式稳定。

### 2.4 CourseVO 源码（嵌套版）

`com.yinxiang.vo.CourseVO`：

```java
package com.yinxiang.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CourseVO {

    private Long id;
    private String title;

    private LocalDateTime startTime;
    private LocalDateTime endTime;

    private Integer capacity;
    private Integer enrolledCount;

    private BigDecimal fee;
    private String coverUrl;

    private Integer status;
    /** 展示用文案：待开始 / 报名中 / 进行中 / 已结束 / 已取消 */
    private String  statusText;

    /** 一对一嵌套：教练简版 */
    private CoachBriefVO coach;
    /** 一对一嵌套：教室简版 */
    private RoomBriefVO  room;
}
```

`CoachBriefVO`、`RoomBriefVO` 是**只包含前端展示所需**的最少字段：

```java
package com.yinxiang.vo;

import lombok.Data;

@Data
public class CoachBriefVO {
    private Long   id;
    private String name;
    private String avatar;
}

@Data
public class RoomBriefVO {
    private Long   id;
    private String code;    // 教室编号
    private String name;    // 教室名
    private Integer capacity;
}
```

划重点：

- **不放 `deleted`、`createTime`、`updateTime`**——前端不需要；
- **不放 `intro`**——列表页展示不需要，详情页再单独取；
- **只放展示必需的最小集合**——遵循「最小暴露原则」。

### 2.5 CourseVO 源码（扁平版）

除了嵌套写法，还有一种**扁平**写法——把关联字段平铺到 VO：

```java
package com.yinxiang.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CourseFlatVO {

    private Long id;
    private String title;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer capacity;
    private Integer enrolledCount;
    private BigDecimal fee;
    private String coverUrl;
    private Integer status;
    private String  statusText;

    // 扁平字段：直接塞在 VO 表层
    private Long   coachId;
    private String coachName;
    private String coachAvatar;

    private Long   roomId;
    private String roomCode;
    private String roomName;
    private Integer roomCapacity;
}
```

### 2.6 嵌套 vs 扁平：怎么选

| 维度 | 嵌套（`CourseVO`） | 扁平（`CourseFlatVO`） |
|---|---|---|
| 前端字段访问 | `vo.coach.name` | `vo.coachName` |
| JSON 结构 | 层次感强 | 一层展平 |
| 展示复用 | `coach` 对象可复用为教练卡片 | 扁平字段无法复用 |
| Excel 导出 | 需自己扁平化再导出 | 直接对应表头 |
| 前端类型定义 | 需定义 `CoachBriefVO` 接口 | 无需子接口 |

划重点：

- **列表页**（要导出 Excel、要做筛选）用扁平；
- **详情页**（要展示教练卡片、要复用其他组件）用嵌套；
- 本项目两种都留着，`selectPage` 返回扁平结构方便前端表格直接渲染，`selectDetail` 返回嵌套结构方便详情页复用组件。

### 2.7 resultMap 一对一（嵌套版）

`CourseMapper.xml` 里配 `resultMap`：

```xml
<resultMap id="courseVOMap" type="com.yinxiang.vo.CourseVO">
  <id     column="id"             property="id"/>
  <result column="title"          property="title"/>
  <result column="start_time"     property="startTime"/>
  <result column="end_time"       property="endTime"/>
  <result column="capacity"       property="capacity"/>
  <result column="enrolled_count" property="enrolledCount"/>
  <result column="fee"            property="fee"/>
  <result column="cover_url"      property="coverUrl"/>
  <result column="status"         property="status"/>

  <association property="coach" javaType="com.yinxiang.vo.CoachBriefVO">
    <id     column="co_id"     property="id"/>
    <result column="co_name"   property="name"/>
    <result column="co_avatar" property="avatar"/>
  </association>

  <association property="room" javaType="com.yinxiang.vo.RoomBriefVO">
    <id     column="r_id"       property="id"/>
    <result column="r_code"     property="code"/>
    <result column="r_name"     property="name"/>
    <result column="r_capacity" property="capacity"/>
  </association>
</resultMap>
```

⚠️ **特别注意**：`<association>` 是**一对一**的关联映射；`<collection>` 是一对多（本讲用不到，Day10 会讲到）。`javaType` 一定要写**全限定类名**，写错会静默失败——VO 里的子对象是 `null`。

### 2.8 resultMap 扁平版

扁平写法更简单——就是把所有字段都平铺：

```xml
<resultMap id="courseFlatVOMap" type="com.yinxiang.vo.CourseFlatVO">
  <id     column="id"             property="id"/>
  <result column="title"          property="title"/>
  <result column="start_time"     property="startTime"/>
  <result column="end_time"       property="endTime"/>
  <result column="capacity"       property="capacity"/>
  <result column="enrolled_count" property="enrolledCount"/>
  <result column="fee"            property="fee"/>
  <result column="cover_url"      property="coverUrl"/>
  <result column="status"         property="status"/>

  <result column="coach_id"       property="coachId"/>
  <result column="co_name"        property="coachName"/>
  <result column="co_avatar"      property="coachAvatar"/>

  <result column="room_id"        property="roomId"/>
  <result column="r_code"         property="roomCode"/>
  <result column="r_name"         property="roomName"/>
  <result column="r_capacity"     property="roomCapacity"/>
</resultMap>
```

### 2.9 别名约定：s_ / co_ / r_

多表 JOIN 后的结果是一行**扁平数据**，同名字段（如三张表都有 `id`、`name`）**必须**用别名区分：

```text
| c.id | c.title | co.id | co.name | r.id | r.name |
    ↓                ↓                  ↓
   id              co_id / co_name    r_id / r_name
```

约定：

- **主表**（`tb_course`）字段用**原名**（`id`、`title`）；
- **子表**用 **2 字缩写 + 下划线**：教练 `co_`、教室 `r_`（教练首字母 c 与主表 course 冲突，改用 `co_`）。

💡 **口诀**：**主表原名、子表带前缀、前缀避冲突**。

### 2.10 columnPrefix：更优雅的写法

如果懒得每列都写别名，可以用 `columnPrefix` 让 MyBatis **自动**给子对象的列名加前缀：

```xml
<association property="coach"
             javaType="com.yinxiang.vo.CoachBriefVO"
             columnPrefix="co_">
  <id     column="id"     property="id"/>
  <result column="name"   property="name"/>
  <result column="avatar" property="avatar"/>
</association>
```

配合 SQL 中的 `co.id AS co_id, co.name AS co_name, co.avatar AS co_avatar`，MyBatis 自动把 `co_id` 视作子对象的 `id`。**列名映射与前缀解耦**，读起来更清晰。

⚠️ **特别注意**：`columnPrefix` 只影响 `<association>` 内部的列匹配，不影响 SQL 本身——SQL 里的别名还是要自己起。

### 2.11 联调剧本（本讲预热）

本讲代码还没跑通到 Controller，先用 MyBatis 的 `sqlSessionFactory` 手动跑一下：

```sql
-- 手动跑一次 JOIN，观察输出
SELECT
  c.id, c.title, c.start_time, c.end_time,
  c.capacity, c.enrolled_count, c.fee, c.cover_url, c.status,

  co.id     AS co_id,
  co.name   AS co_name,
  co.avatar AS co_avatar,

  r.id       AS r_id,
  r.code     AS r_code,
  r.name     AS r_name,
  r.capacity AS r_capacity
FROM tb_course c
LEFT JOIN tb_coach co ON co.id = c.coach_id AND co.deleted = 0
LEFT JOIN tb_room  r  ON r.id  = c.room_id  AND r.deleted  = 0
WHERE c.deleted = 0
LIMIT 3;
```

期望能看到三行，每一行有 12 个字段——前 9 个是课程本身，后 3 组是教练 / 教室。**这就是给 MyBatis resultMap「解读」的原始数据形态**。

### 2.12 pitfall / 注意

1. **`resultMap` 的 `type` 属性没写全限定名**：写成 `type="CourseVO"` 会启动时报 `ClassNotFound`。一律写包名。
2. **列名冲突**：SQL 里三张表都有 `id`，若忘记别名，`resultMap` 会把最后一个覆盖前面的，导致 `vo.coach.id` 变成课程 id。检查手法：在 IDEA 里直接跑 SQL，看结果列名。
3. **`<association>` 用了 `select` 属性**：这会让 MyBatis 对每一条主记录**再发一次 SQL** 去查子对象——就是经典的 **N+1 问题**。列表页 100 条课程会发 201 条 SQL。**本项目一律用 `resultMap` 内嵌 `<id>` + `<result>`**，靠一次 JOIN 拿全。
4. **`autoMapping` 的开关**：MyBatis 有个全局设置 `mapUnderscoreToCamelCase=true` 会自动把 `enrolled_count` 映射到 `enrolledCount`——`resultMap` 里就不用手写 `<result>`。但**多表 JOIN** 时子表字段带前缀，`autoMapping` 就管不到了，还是得显式写。
5. **`<id>` 标签不能省**：分页多行结果集合并去重时，MyBatis 用 `<id>` 标签判断「这两行是不是同一个主对象」——省了就会出现「同一课程的教练信息被复制多份」的诡异现象。

### 2.13 练习 / 思考

1. **必做**：仿照 `CourseVO`，写一个 `CourseFlatVO` 与对应的 `resultMap`，在同一个 Mapper 里同时提供两种映射。
2. **必做**：把 `<association>` 里的 `javaType` 故意写错一个字母，观察运行时会出现什么现象——学会**读错误信息**是最好的学习。
3. **思考**：如果 `CourseVO` 除了教练与教室，还想嵌套「已报名会员列表」（一对多），应该用什么标签？该标签会不会影响分页行数？
4. **挑战**：给 `resultMap` 的 `<association>` 加 `columnPrefix`，把 SQL 里的别名 `co_id / co_name / co_avatar` 简化成子对象内部只写 `id / name / avatar`，跑通后对比两种写法的可读性。

---

## 第 3 讲：分页多表联查 SQL + Service 层查询

### 3.1 引入：一条 SQL 还是分多次查？

需求场景：管理员打开课程管理页，一屏展示 10 条课程，每条要显示：

- 课程标题、开始时间、结束时间、状态
- **教练头像 + 姓名**
- **教室编号 + 名称**
- 已报名 / 容量

方案 A：先查 10 条课程，再循环调 `coachMapper.getById(10 次)` + `roomMapper.getById(10 次)`——**21 次 SQL**。
方案 B：一条 `LEFT JOIN` SQL 全部拿到——**1 次 SQL**。

🎯 **一句话痛点**：**方案 A 是新手常犯的 N+1 问题，方案 B 是所有列表页的正统写法。**

### 3.2 核心概念：list SQL 与 count SQL 分家

分页查询有两个副产物：

1. **当前页数据**：`SELECT ... LIMIT offset, size`；
2. **总记录数**：`SELECT COUNT(*)`。

**这两条要分开写**，理由是：

- **list SQL** 需要 JOIN 出教练 / 教室字段供前端显示；
- **count SQL** 只关心「有多少行」，**不需要**任何 JOIN——JOIN 上去只会拖慢 COUNT。

划重点：把两条 SQL 分开写能让 count 快一个数量级。有些框架（如 PageHelper）会**自动包装** count SQL，但它**不会**主动删除不必要的 JOIN——深分页场景手写 count 更快。

### 3.3 CoursePageQuery：分页查询参数

`com.yinxiang.dto.CoursePageQuery`：

```java
package com.yinxiang.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class CoursePageQuery {

    /** 标题模糊 */
    private String title;

    /** 状态精确：0/1/2/3/4 */
    private Integer status;

    /** 教练 id 精确 */
    private Long coachId;

    /** 教室 id 精确 */
    private Long roomId;

    /** 开始时间下界（左闭） */
    private LocalDateTime startFrom;

    /** 开始时间上界（右开） */
    private LocalDateTime startTo;

    /** 分页参数：从 1 开始 */
    private Integer pageNum  = 1;
    private Integer pageSize = 10;

    /** 便捷方法：转 offset / size */
    public Integer getOffset() { return (pageNum - 1) * pageSize; }
    public Integer getSize()   { return pageSize; }
}
```

### 3.4 CourseMapper.xml：完整 SQL

`resources/mapper/CourseMapper.xml`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "https://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.yinxiang.mapper.CourseMapper">

  <!-- resultMap 见第 2 讲，略 -->

  <!-- ============ list SQL：多表 JOIN + 分页 ============ -->
  <select id="selectPage" resultMap="courseVOMap">
    SELECT
      c.id, c.title, c.start_time, c.end_time,
      c.capacity, c.enrolled_count, c.fee, c.cover_url, c.status,

      co.id     AS co_id,
      co.name   AS co_name,
      co.avatar AS co_avatar,

      r.id       AS r_id,
      r.code     AS r_code,
      r.name     AS r_name,
      r.capacity AS r_capacity

    FROM tb_course c
    LEFT JOIN tb_coach co ON co.id = c.coach_id AND co.deleted = 0
    LEFT JOIN tb_room  r  ON r.id  = c.room_id  AND r.deleted  = 0
    <where>
      c.deleted = 0
      <if test="title != null and title != ''">
        AND c.title LIKE CONCAT('%', #{title}, '%')
      </if>
      <if test="status != null">
        AND c.status = #{status}
      </if>
      <if test="coachId != null">
        AND c.coach_id = #{coachId}
      </if>
      <if test="roomId != null">
        AND c.room_id = #{roomId}
      </if>
      <if test="startFrom != null">
        AND c.start_time &gt;= #{startFrom}
      </if>
      <if test="startTo != null">
        AND c.start_time &lt; #{startTo}
      </if>
    </where>
    ORDER BY c.start_time DESC, c.id DESC
    LIMIT #{offset}, #{size}
  </select>

  <!-- ============ count SQL：单表 COUNT，不 JOIN ============ -->
  <select id="selectPageCount" resultType="long">
    SELECT COUNT(*)
    FROM tb_course c
    <where>
      c.deleted = 0
      <if test="title != null and title != ''">
        AND c.title LIKE CONCAT('%', #{title}, '%')
      </if>
      <if test="status != null">AND c.status   = #{status}</if>
      <if test="coachId != null">AND c.coach_id = #{coachId}</if>
      <if test="roomId  != null">AND c.room_id  = #{roomId}</if>
      <if test="startFrom != null">AND c.start_time &gt;= #{startFrom}</if>
      <if test="startTo   != null">AND c.start_time &lt;  #{startTo}</if>
    </where>
  </select>

</mapper>
```

### 3.5 CourseMapper 接口

```java
package com.yinxiang.mapper;

import com.yinxiang.dto.CoursePageQuery;
import com.yinxiang.vo.CourseVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CourseMapper {

    List<CourseVO> selectPage(CoursePageQuery q);

    long selectPageCount(CoursePageQuery q);
}
```

### 3.6 SQL 里的四个关键点

划重点：这条 SQL 有四个新手最容易踩错的地方，一个个看清楚。

**（1）为什么用 LEFT JOIN 而不是 INNER JOIN？**

`tb_course` 的 `coach_id`、`room_id` 都是 `NOT NULL`，理论上不会有孤儿——但**教练可能被软删**。如果教练离职，`tb_coach.deleted = 1`：

- `INNER JOIN` + `AND co.deleted = 0` → 整条课程**消失**；
- `LEFT JOIN`  + `AND co.deleted = 0` → 课程保留，`vo.coach` 为 `null`。

前端拿到 `coach: null` 可以显示「教练已离职」——**用户不会以为系统丢数据**。

**（2）`AND co.deleted = 0` 写在 ON 里还是 WHERE 里？**

⚠️ **特别注意**：这是本讲最经典的坑——

```sql
-- ✅ 正确：写在 ON 里
LEFT JOIN tb_coach co ON co.id = c.coach_id AND co.deleted = 0

-- ❌ 错误：写在 WHERE 里
LEFT JOIN tb_coach co ON co.id = c.coach_id
WHERE ... AND co.deleted = 0
```

后者会让 LEFT JOIN **退化为 INNER JOIN**——因为 `WHERE co.deleted = 0` 对**JOIN 后**的行做过滤，被软删的教练那条课程会因为 `co.deleted IS NULL` 被过滤掉。

💡 **口诀**：**子表条件写 ON，主表条件写 WHERE**。

**（3）日期区间用左闭右开**

```sql
AND c.start_time >= #{startFrom}
AND c.start_time <  #{startTo}      -- 注意是 < 不是 <=
```

想查 2026-07-20 一整天的课程，参数：`startFrom=2026-07-20 00:00:00, startTo=2026-07-21 00:00:00`。**左闭右开**保证同一秒不会重复也不会遗漏。

**（4）`ORDER BY` 加 `c.id DESC` 作平局裁决**

```sql
ORDER BY c.start_time DESC, c.id DESC
```

同一秒开始的两节课不加 `id DESC` 排序会不稳定——分页翻到第二页可能看到重复行。加 `id DESC` 作为兜底保证**顺序确定**。

### 3.7 动态条件与索引利用

划重点：条件筛选和索引利用不是随便加加就了事，看这张对照表：

| 条件 | SQL 片段 | 走索引？ | 说明 |
|---|---|---|---|
| `title` 模糊 | `title LIKE '%xx%'` | ❌ 全表扫描 | 前导 `%` 无法用 B+Tree |
| `status` 精确 | `status = 2` | ✅ `idx_status` | 单列等值 |
| `coachId` 精确 | `coach_id = 1` | ✅ `idx_coach` | 单列等值 |
| `roomId` 精确 | `room_id = 1` | ✅ `idx_room` | 单列等值 |
| `startFrom + startTo` | `start_time BETWEEN ...` | ✅ `idx_start` | 范围扫描 |
| `coachId + startFrom` | `coach_id = 1 AND start_time >= ?` | ✅ `idx_conflict` 全命中 | 组合最左前缀完整 |

「教练维度 + 时间区间」的组合查询最快，因为 `idx_conflict(coach_id, start_time, end_time)` 两个字段都能用上——这是本表的**杀手锏**索引。

⚠️ **特别注意**：**`title` 模糊查询不走索引**是无解的——除非引入全文索引或 Elasticsearch。本项目数据量小暂不做，但要**在心里记着**：等数据涨到 100 万时，`title LIKE '%xx%'` 会变成第一号性能杀手。

### 3.8 PageResult 泛型分页对象

`com.yinxiang.common.PageResult`：

```java
package com.yinxiang.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

/**
 * 分页返回体：total + list 两个字段足够前端翻页控件使用。
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageResult<T> {

    /** 总记录数（来自 count SQL） */
    private long total;

    /** 当前页数据（来自 list SQL） */
    private List<T> list;

    public static <T> PageResult<T> empty() {
        return new PageResult<>(0L, Collections.emptyList());
    }
}
```

划重点：`PageResult` 只留 `total` 与 `list` 两个字段。有些团队会再加 `pageNum` / `pageSize` / `totalPages`——都是**回声值**（前端本来就知道），价值不大，本项目省了。

### 3.9 CourseService.pageQuery

`com.yinxiang.service.CourseService`：

```java
package com.yinxiang.service;

import com.yinxiang.common.PageResult;
import com.yinxiang.dto.CoursePageQuery;
import com.yinxiang.mapper.CourseMapper;
import com.yinxiang.vo.CourseVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseMapper courseMapper;

    public PageResult<CourseVO> pageQuery(CoursePageQuery q) {
        // 1. 先 count：等于 0 直接返回空列表，省一次 list SQL 的 IO
        long total = courseMapper.selectPageCount(q);
        if (total == 0) {
            log.info("[课程分页] 命中空集，q={}", q);
            return PageResult.empty();
        }

        // 2. 再 list
        List<CourseVO> list = courseMapper.selectPage(q);

        // 3. 补 statusText 展示字段（Entity 无此字段，Service 层补）
        list.forEach(vo -> vo.setStatusText(courseStatusText(vo.getStatus())));

        log.info("[课程分页] total={} 当前页={}", total, list.size());
        return new PageResult<>(total, list);
    }

    private String courseStatusText(Integer s) {
        return switch (s == null ? -1 : s) {
            case 0 -> "待开始";
            case 1 -> "报名中";
            case 2 -> "进行中";
            case 3 -> "已结束";
            case 4 -> "已取消";
            default -> "未知";
        };
    }
}
```

划重点：**早失败早返回**——`total == 0` 直接返回空 `PageResult`，省一次 list SQL 的网络与磁盘 IO。这在深分页场景下尤为关键。

### 3.10 CourseController.page

`com.yinxiang.controller.CourseController`：

```java
package com.yinxiang.controller;

import com.yinxiang.common.PageResult;
import com.yinxiang.common.Result;
import com.yinxiang.dto.CoursePageQuery;
import com.yinxiang.service.CourseService;
import com.yinxiang.vo.CourseVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public Result<PageResult<CourseVO>> page(CoursePageQuery q) {
        return Result.ok(courseService.pageQuery(q));
    }
}
```

### 3.11 联调剧本：四组分页查询

启动应用后，用 curl 依次跑：

**（1）全量分页**

```bash
curl -i "http://localhost:8080/api/courses?pageNum=1&pageSize=10"
```

期望响应：

```json
{
  "code": 0,
  "msg": "OK",
  "data": {
    "total": 3,
    "list": [
      {
        "id": 3,
        "title": "周三流瑜伽",
        "startTime": "2026-07-22T19:30:00",
        "endTime":   "2026-07-22T20:30:00",
        "capacity": 20,
        "enrolledCount": 0,
        "fee": 128.00,
        "status": 0,
        "statusText": "待开始",
        "coach": { "id": 2, "name": "李教练", "avatar": "..." },
        "room":  { "id": 1, "code": "R101", "name": "阳光馆", "capacity": 25 }
      }
      // ...
    ]
  }
}
```

**（2）按教练筛选**

```bash
curl -i "http://localhost:8080/api/courses?coachId=1"
```

期望：返回 2 条（张教练的哈他 + 阴瑜伽）。

**（3）时间区间筛选（左闭右开验证）**

```bash
curl -i "http://localhost:8080/api/courses?startFrom=2026-07-21T00:00:00&startTo=2026-07-22T00:00:00"
```

期望：返回 1 条（阴瑜伽在 07-21 20:00）。

**（4）组合筛选**

```bash
curl -i "http://localhost:8080/api/courses?title=%E7%91%9C%E4%BC%BD&status=1&pageNum=1&pageSize=5"
```

（`%E7%91%9C%E4%BC%BD` 是「瑜伽」的 URL 编码）

期望：返回所有标题含「瑜伽」且状态为 1（报名中）的课程。

### 3.12 pitfall / 注意

1. **`LEFT JOIN` 后 `WHERE` 里判空**：`WHERE co.id = NULL` 永远返回 false，必须写 `WHERE co.id IS NULL`——SQL 三值逻辑（true/false/unknown）陷阱。
2. **`LIMIT offset` 大时的性能陷阱**：`LIMIT 99990, 10` 会让 MySQL 先读 10 万行再丢掉前 99990——**深分页**问题。Day13-14 会讲游标分页（`WHERE id < lastId`）优化。
3. **动态 `<if test="xx != null and xx != ''">` 的空串坑**：字符串条件必须**同时**判 `null` 和空串。只判 `null` 会让前端传空串时错走 SQL：`title LIKE '%%'` 匹配所有行。
4. **count SQL 加了不必要的 JOIN**：如果懒得抽出 count 单独写，把 list SQL 的 `SELECT ... FROM ...` 改成 `SELECT COUNT(*) FROM ...` 保留 JOIN——**JOIN 里的行数会被 COUNT 掉的**，性能不会翻车但也慢一个数量级。**手写才最快**。
5. **`ORDER BY` 单字段导致分页错乱**：同一时间点两条记录，翻页时可能重复出现或漏掉。加 `id DESC` 作平局裁决。
6. **`#{q.title}` 与 `#{title}` 的区别**：当 mapper 方法参数是**单个 DTO**（未加 `@Param`）时，MyBatis 允许 `#{title}`；如果参数是 `@Param("q") CoursePageQuery q`，就必须写 `#{q.title}`。本项目单参数不加 `@Param`。

### 3.13 练习 / 思考

1. **必做**：完成 `CoursePageQuery` + `CourseMapper` + `CourseService.pageQuery` + `CourseController.page` 四层，用 4 条 curl 验证。
2. **必做**：在 MySQL 客户端跑 `EXPLAIN` 观察至少 3 组查询条件的 `type` / `key` / `rows`，把结果贴到笔记里。
3. **思考**：`title LIKE 'xx%'`（右模糊）会走索引吗？改成 `LIKE '%xx'`（左模糊）呢？
4. **挑战**：把 `startTo` 参数换成 `endBefore`（表示「结束时间早于此点的课程」），观察 SQL 与索引利用会如何变化。

---

## 第 4 讲：外键存在性校验 + 课程 DTO 与基础校验

### 4.1 引入：前端手误传了 coachId=999，会发生什么

上一讲把「查」跑通了，现在准备做「写」——`POST /courses` 新增一节课。设想以下反例：

前端手误提交：`{"coachId": 999, "roomId": 1, ...}`——`tb_coach` 里根本没有 id=999 的教练。

由于本项目 DDL **不加物理外键**，数据库这一层根本不拦——`INSERT` 直接成功。然后：

- 前端查列表，`LEFT JOIN` 出来的 `coach` 是 `null`；
- 页面上显示「教练：null」——脏数据。

🎯 **一句话痛点**：**不加物理外键的项目，必须由 Service 层的「外键存在性校验」把脏数据堵在源头。**

### 4.2 核心概念：三层校验

划重点：一个「写」接口应该在**三个层次**上校验，缺一不可：

```text
┌──────────────────────────────────────────────────────┐
│  Controller  @Valid + Bean Validation                │
│              ↓ 单字段合法性：非空、长度、正则、范围     │
│  跨字段      @ValidTimeRange（类级注解）              │
│              ↓ end > start，最少 15 分钟              │
│  Service     assertCoachExists / assertRoomExists    │
│              ↓ 数据库反查存在且未删                    │
└──────────────────────────────────────────────────────┘
```

💡 **口诀**：**字段级 → 跨字段 → 跨记录，一层比一层重**。

### 4.3 ExistenceChecker 组件

`com.yinxiang.common.ExistenceChecker`：

```java
package com.yinxiang.common;

import com.yinxiang.common.exception.BizException;
import com.yinxiang.entity.Coach;
import com.yinxiang.entity.Room;
import com.yinxiang.mapper.CoachMapper;
import com.yinxiang.mapper.RoomMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * 外键存在性校验组件。
 * <p>本项目 DDL 不加物理外键，靠这里代码把「不存在的外键」堵在 Service 层。
 */
@Component
@RequiredArgsConstructor
public class ExistenceChecker {

    private final CoachMapper coachMapper;
    private final RoomMapper  roomMapper;

    /** 校验教练存在且未删，成功时返回教练对象（上层往往还需要它）。 */
    public Coach assertCoachExists(Long id) {
        Coach c = coachMapper.selectById(id);
        if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
            throw new BizException(4041, "教练不存在：id=" + id);
        }
        return c;
    }

    /** 校验教室存在且未删。 */
    public Room assertRoomExists(Long id) {
        Room r = roomMapper.selectById(id);
        if (r == null || Integer.valueOf(1).equals(r.getDeleted())) {
            throw new BizException(4042, "教室不存在：id=" + id);
        }
        return r;
    }
}
```

划重点：

- **返回校验到的对象**——上层可能还需要它。例如新增课程时，要拿教室的 `capacity` 与课程的 `capacity` 做比较；
- **错误码分段**：`4041 教练不存在 / 4042 教室不存在`——方便前端根据不同错误码高亮不同下拉框；
- **软删除也视作不存在**：`deleted = 1` 的教练不能再被排新课。

### 4.4 为什么把外键校验放到 Service 而不是 Controller

划重点：

| 层次 | 能做什么校验 | 不能做什么 |
|---|---|---|
| Controller | 单字段合法性（非空、长度、范围、正则） | 跨字段、跨记录、需要数据库查询的都不行 |
| Service | 跨字段、跨记录、事务内校验 | 请求参数格式类校验 |

外键存在性校验**必须**查数据库——Controller 层的 Bean Validation 只是纯注解，做不到这种事。

⚠️ **特别注意**：不要把校验放在 Mapper 层——Mapper 只负责 SQL 收发，业务规则一律不进 Mapper。这是「关注点分离」的基本盘。

### 4.5 CourseAddDTO 完整源码

`com.yinxiang.dto.CourseAddDTO`：

```java
package com.yinxiang.dto;

import com.yinxiang.common.validation.ValidTimeRange;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 新增课程请求体。类级 @ValidTimeRange 做跨字段校验。
 */
@Data
@ValidTimeRange   // 类级注解：结束时间必须晚于开始时间
public class CourseAddDTO {

    @NotBlank(message = "课程标题不能为空")
    @Size(max = 100, message = "课程标题最多 100 字")
    private String title;

    @NotNull(message = "教练不能为空")
    private Long coachId;

    @NotNull(message = "教室不能为空")
    private Long roomId;

    @NotNull(message = "开始时间不能为空")
    @Future(message = "开始时间必须晚于当前时间")
    private LocalDateTime startTime;

    @NotNull(message = "结束时间不能为空")
    private LocalDateTime endTime;

    @NotNull(message = "容量不能为空")
    @Positive(message = "容量必须大于 0")
    @Max(value = 200, message = "容量最多 200 人")
    private Integer capacity;

    @NotNull(message = "费用不能为空")
    @DecimalMin(value = "0.00", message = "费用不能为负")
    @DecimalMax(value = "99999.99", message = "费用过大")
    @Digits(integer = 6, fraction = 2, message = "费用格式：整数 6 位、小数 2 位")
    private BigDecimal fee;

    @Size(max = 5000, message = "介绍最多 5000 字")
    private String intro;

    @Size(max = 255, message = "封面 URL 过长")
    private String coverUrl;
}
```

### 4.6 Bean Validation 注解逐个说明

| 注解 | 作用 | 用在 |
|---|---|---|
| `@NotBlank` | 字符串非空**且**去空格后不为 `""` | 字符串必填 |
| `@NotNull` | 对象引用不为 `null` | 非字符串必填 |
| `@Size(max=X)` | 字符串或集合长度上限 | 字符串、集合 |
| `@Future` | 时间必须晚于当前 | `LocalDateTime` |
| `@Positive` | 数字 > 0（不含 0） | 数字 |
| `@Max` / `@Min` | 数字上下界（含） | 整数 |
| `@DecimalMin` / `@DecimalMax` | `BigDecimal` 上下界（可指定含不含） | `BigDecimal` |
| `@Digits(integer, fraction)` | `BigDecimal` 整数/小数位限制 | `BigDecimal` |

⚠️ **特别注意**：`@NotBlank` 只能用在**字符串**，`@NotNull` 用在**其他类型**。用错了会启动时报 `Constraint validator not found`。

### 4.7 自定义校验器 @ValidTimeRange

Bean Validation 只能做**字段自己**的校验，「结束时间必须晚于开始时间」这种**跨字段**校验必须自定义。分两步：

**（1）定义注解**

`com.yinxiang.common.validation.ValidTimeRange`：

```java
package com.yinxiang.common.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)   // 类级注解！
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TimeRangeValidator.class)
public @interface ValidTimeRange {

    String message() default "结束时间必须晚于开始时间，且至少 15 分钟";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
```

**（2）实现校验器**

`com.yinxiang.common.validation.TimeRangeValidator`：

```java
package com.yinxiang.common.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.time.Duration;
import java.time.LocalDateTime;

public class TimeRangeValidator
        implements ConstraintValidator<ValidTimeRange, Object> {

    @Override
    public boolean isValid(Object value, ConstraintValidatorContext ctx) {
        if (value == null) return true;
        LocalDateTime start, end;
        try {
            start = (LocalDateTime) value.getClass().getMethod("getStartTime").invoke(value);
            end   = (LocalDateTime) value.getClass().getMethod("getEndTime")  .invoke(value);
        } catch (Exception e) {
            // DTO 里没有 startTime/endTime 字段，交给字段级注解处理
            return true;
        }
        // 任一为 null 交给字段级 @NotNull
        if (start == null || end == null) return true;
        return end.isAfter(start) && Duration.between(start, end).toMinutes() >= 15;
    }
}
```

划重点：

- **类级注解**：`@Target(TYPE)` 而不是 `FIELD`——校验器拿到的 `value` 是整个 DTO 对象；
- **`ConstraintValidator` 的第二个泛型是 `Object`**——因为多个 DTO（Add / Update）都可以使用同一个校验器；
- **反射拿字段**：`getStartTime()` / `getEndTime()` 通过反射调用。如果 DTO 没这两个方法就跳过。

⚠️ **特别注意**：如果学生对反射不适应，可以简化成 `if (value instanceof CourseAddDTO dto) { ... }`——**不推荐**，通用性差，但初学者更好懂。

### 4.8 CourseUpdateDTO 完整源码

修改 DTO 与新增 DTO 有两处差异：

1. **多一个 `id` 字段**（必填）；
2. **其他字段大多可选**——修改时用户只传要改的字段，没传的字段保持不变（PATCH 语义）。

```java
package com.yinxiang.dto;

import com.yinxiang.common.validation.ValidTimeRange;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@ValidTimeRange
public class CourseUpdateDTO {

    @NotNull(message = "id 不能为空")
    private Long id;

    // 修改场景下大部分字段可选：不传就不改
    @Size(max = 100) private String title;

    private Long coachId;
    private Long roomId;

    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @Positive @Max(200)
    private Integer capacity;

    @DecimalMin("0.00") @DecimalMax("99999.99")
    @Digits(integer = 6, fraction = 2)
    private BigDecimal fee;

    @Size(max = 5000) private String intro;
    @Size(max = 255)  private String coverUrl;
}
```

划重点：新增 DTO 里的 `@NotBlank` / `@NotNull` 在修改 DTO 里都**去掉**——修改时字段没传就不动。但 `id` 必须传。

### 4.9 分组校验 @Validated 的可能性

如果你希望**一个** DTO 类同时服务于「新增」和「修改」两个场景，可以用**分组**：

```java
public interface AddGroup    { }
public interface UpdateGroup { }

@Data
@ValidTimeRange
public class CourseSaveDTO {

    @Null(groups = AddGroup.class)    // 新增不传 id
    @NotNull(groups = UpdateGroup.class) // 修改必传 id
    private Long id;

    @NotBlank(groups = AddGroup.class)
    @Size(max = 100, groups = {AddGroup.class, UpdateGroup.class})
    private String title;

    // ...
}
```

Controller 里：

```java
@PostMapping
public Result<Long> add(@RequestBody @Validated(AddGroup.class) CourseSaveDTO dto) { ... }

@PutMapping("/{id}")
public Result<Void> update(@RequestBody @Validated(UpdateGroup.class) CourseSaveDTO dto) { ... }
```

⚠️ **特别注意**：分组的写法看起来 DRY，但**可读性差**——一个 DTO 类里既有新增规则又有修改规则，一个字段有多个 `groups`，容易看晕。**本项目为了教学清晰，坚持写两个 DTO 类**。

💡 **口诀**：**DRY 是好东西，但**「过早抽象」也是万恶之源**。**两个 DTO 类的复制成本 < 学生看懂分组的心智成本。

### 4.10 Controller 里的 @Valid 触发

```java
@PostMapping
public Result<Long> add(@RequestBody @Valid CourseAddDTO dto) {
    return Result.ok(courseService.add(dto));
}

@PutMapping("/{id}")
public Result<Void> update(@PathVariable Long id,
                            @RequestBody @Valid CourseUpdateDTO dto) {
    dto.setId(id);   // 以 path 里的 id 为准
    courseService.update(dto);
    return Result.ok();
}
```

`@Valid` 触发校验，失败会抛 `MethodArgumentNotValidException`——**Day07 的 `GlobalExceptionHandler` 已经接过它**，前端拿到的响应体：

```json
{
  "code": 400,
  "msg": "title: 课程标题不能为空; capacity: 容量必须大于 0",
  "data": null,
  "timestamp": 1721030400000
}
```

⚠️ **特别注意**：**`@Valid` 是 JSR 标准注解**，`@Validated` 是 Spring 的扩展（支持分组）。不用分组时 `@Valid` 就够。

### 4.11 联调剧本：4 组反例

前置：确保 Day07 的 `GlobalExceptionHandler` 已生效。

**（1）空标题**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-08-01T10:00:00",
    "endTime":   "2026-08-01T11:00:00",
    "capacity": 20,
    "fee": 88.00
  }'
```

期望：`code: 400, msg: "title: 课程标题不能为空"`。

**（2）教练不存在（99999）**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "测试课",
    "coachId": 99999,
    "roomId": 1,
    "startTime": "2026-08-01T10:00:00",
    "endTime":   "2026-08-01T11:00:00",
    "capacity": 20,
    "fee": 88.00
  }'
```

期望：`code: 4041, msg: "教练不存在：id=99999"`。

**（3）开始时间晚于结束时间**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "时间反了",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-08-01T12:00:00",
    "endTime":   "2026-08-01T10:00:00",
    "capacity": 20,
    "fee": 88.00
  }'
```

期望：`code: 400, msg: "结束时间必须晚于开始时间，且至少 15 分钟"`。

**（4）容量为负数**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "容量负数",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-08-01T10:00:00",
    "endTime":   "2026-08-01T11:00:00",
    "capacity": -1,
    "fee": 88.00
  }'
```

期望：`code: 400, msg: "capacity: 容量必须大于 0"`。

### 4.12 pitfall / 注意

1. **`@NotNull` 与 `@NotBlank` 混用**：字符串上写 `@NotNull` 允许 `""` 通过——想禁空串必须 `@NotBlank`。
2. **`@Valid` vs `@Validated`**：`@Valid` 是 JSR 标准，`@Validated` 是 Spring 扩展。不用分组一律 `@Valid`；要分组必须 `@Validated`。**混用不会报错但会漏校验**。
3. **跨字段校验的错误消息定位**：类级注解的错误消息前端拿到时是「整个对象」的错，`fieldErrors` 里没具体字段——如果需要指向某字段，`isValid` 里可以 `ctx.buildConstraintViolationWithTemplate(...).addPropertyNode("endTime").addConstraintViolation()`。
4. **Optional 字段的 null 语义**：`CourseUpdateDTO.title = null` 意味着**不改**还是**改为 null**？本项目约定**不改**。所以 Update Service 里必须做「非空才覆盖」的 selective 逻辑。
5. **`@Future` 与 `@FutureOrPresent`**：`@Future` 严格晚于**当前时刻**，排课要提前几分钟就够——用它。要是允许「立即开课」就用 `@FutureOrPresent`。

### 4.13 练习 / 思考

1. **必做**：完成 `ExistenceChecker` + `CourseAddDTO` + `CourseUpdateDTO` + `@ValidTimeRange` + `TimeRangeValidator` 五个文件的编码。
2. **必做**：用 Postman 至少测 6 组反例（每个字段级注解都要至少覆盖 1 条），把 `Result` 响应体贴到笔记里。
3. **思考**：如果 Controller 里忘了写 `@Valid`，Bean Validation 还生效吗？（答案：不生效。字段级注解无人触发。）
4. **挑战**：为 `@ValidTimeRange` 增加一个 `minMinutes` 属性，默认 15，允许业务方通过 `@ValidTimeRange(minMinutes = 30)` 自定义。

---

## 第 5 讲：冲突检测 SQL + 新增 / 修改 Service

### 5.1 引入：一位教练同时排两节课

场景：张教练已经排了「周一 8:00-9:00 哈他」，运营小姐姐又想给她加一节「周一 8:30-9:30 阴瑜伽」——**一个人不能同时在两个课上**。

再想复杂一点：教练可以，但**教室**也不能同时开两节课。

🎯 **一句话痛点**：**排课冲突检测**是本讲要解决的核心问题。它比想象中难——不是简单的「字段相等」，而是**区间相交**。

### 5.2 核心概念：区间重叠的四种情形

划重点：先在纸上画图，再推 SQL。两个时间区间「旧」和「新」，可能出现四种关系：

```text
情形 A：新区间完全在旧区间前
   旧：       [------------------]
   新：  [--]
   → 不冲突：new.end <= old.start

情形 B：新区间完全在旧区间后
   旧：  [------------------]
   新:                       [--]
   → 不冲突：new.start >= old.end

情形 C：部分重叠
   旧：  [------------------]
   新：            [------------]
   → 冲突

情形 D：完全包含（新包旧 或 旧包新）
   旧：       [--]
   新：  [------------------]
   → 冲突
```

**推导**：

- **不冲突** = 情形 A **或** 情形 B = `new.end <= old.start  OR  new.start >= old.end`
- **冲突**   = 取反 = `NOT (new.end <= old.start OR new.start >= old.end)`

💡 **口诀**：**「不冲突」= 我结束前你已结束 或 我开始前你还没开始**。取反就是冲突。

⚠️ **特别注意**：等号「= 」的处理——**左闭右开**语义下，「上一节 9:00 结束、下一节 9:00 开始」是**允许**的（不算重叠），所以带等号：`end <= start` 与 `start >= end`。

这个模板不仅适用于排课，还适用于会议室预定、酒店房间预定、机器分时租赁——**背下来**。

### 5.3 countCoachConflict SQL

`CourseMapper.xml`：

```xml
<!-- 教练冲突检测 -->
<select id="countCoachConflict" resultType="int">
  SELECT COUNT(*)
  FROM tb_course
  WHERE deleted = 0
    AND status &lt;&gt; 4                    <!-- 已取消不占用 -->
    AND coach_id = #{coachId}
    <if test="excludeId != null">
      AND id &lt;&gt; #{excludeId}          <!-- 修改场景排除自己 -->
    </if>
    AND NOT (end_time   &lt;= #{startTime}
          OR start_time &gt;= #{endTime})
</select>
```

划重点：这条 SQL 有三个必须理解的点——

**（1）`status <> 4`**

已取消的课程**不占用**时段。同一时段本来是「周一 8:00 哈他」，取消后可以再排「周一 8:00 阴瑜伽」。SQL 层排除掉。

**（2）`excludeId`**

修改自己时把自己排除，否则「自己和自己冲突」。用 `<if>` 包裹：新增时传 `null` 不生效，修改时传自己 id。

**（3)`end_time <=` 与 `start_time >=` 的等号**

左闭右开语义下，紧邻的两个时段（`[8:00, 9:00)` 与 `[9:00, 10:00)`）**不算重叠**——所以带等号才是「不冲突」。

### 5.4 countRoomConflict SQL

与教练冲突同构，只把 `coach_id` 换成 `room_id`：

```xml
<select id="countRoomConflict" resultType="int">
  SELECT COUNT(*)
  FROM tb_course
  WHERE deleted = 0
    AND status &lt;&gt; 4
    AND room_id = #{roomId}
    <if test="excludeId != null">
      AND id &lt;&gt; #{excludeId}
    </if>
    AND NOT (end_time   &lt;= #{startTime}
          OR start_time &gt;= #{endTime})
</select>
```

⚠️ **特别注意**：两条 SQL 结构一模一样，为什么不合并成一个 `OR (coach_id = ? OR room_id = ?)`？答：**合并了走不同索引会退化到全表扫描**。分开写，教练冲突走 `idx_coach`（或 `idx_conflict`），教室冲突走 `idx_room`，都非常快。

### 5.5 CourseMapper 接口方法

```java
package com.yinxiang.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;

@Mapper
public interface CourseMapper {

    // ... 分页方法略

    int countCoachConflict(@Param("coachId")   Long coachId,
                           @Param("startTime") LocalDateTime startTime,
                           @Param("endTime")   LocalDateTime endTime,
                           @Param("excludeId") Long excludeId);

    int countRoomConflict(@Param("roomId")    Long roomId,
                          @Param("startTime") LocalDateTime startTime,
                          @Param("endTime")   LocalDateTime endTime,
                          @Param("excludeId") Long excludeId);

    int insert(com.yinxiang.entity.Course c);

    int updateSelective(com.yinxiang.entity.Course c);

    com.yinxiang.entity.Course selectById(Long id);
}
```

⚠️ **特别注意**：多参数方法必须显式 `@Param`，XML 里才能用 `#{coachId}` 引用。

### 5.6 @Transactional 加在哪一层

划重点：

```text
Controller       ← 不加事务：HTTP 层不关心事务
    ↓
Service          ← 加 @Transactional：业务边界在这里
    ↓
Mapper           ← 不加事务：ORM 层不做决策
```

**Service 是业务边界**——一个方法内的多次 DB 操作要么全成功、要么全回滚，这就是事务的含义。

本讲只用 `@Transactional` 的默认传播行为 `REQUIRED`——「有事务就加入，没有就新建」。传播的其他级别（`REQUIRES_NEW` / `NESTED`）是 Day11-12 的话题，先埋种子。

### 5.7 CourseService.add 完整源码

```java
package com.yinxiang.service;

import com.yinxiang.common.ExistenceChecker;
import com.yinxiang.common.exception.BizException;
import com.yinxiang.dto.CourseAddDTO;
import com.yinxiang.entity.Course;
import com.yinxiang.entity.Room;
import com.yinxiang.mapper.CourseMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseMapper courseMapper;
    private final ExistenceChecker existenceChecker;

    /**
     * 新增课程。
     * <p>校验顺序（早失败早返回）：
     * <ol>
     *   <li>外键存在性（顺便拿教室信息用于容量比对）</li>
     *   <li>本地对象比较（课程容量 vs 教室容量）</li>
     *   <li>教练冲突检测</li>
     *   <li>教室冲突检测</li>
     *   <li>落库</li>
     * </ol>
     */
    @Transactional(rollbackFor = Exception.class)
    public Long add(CourseAddDTO dto) {
        // 1. 外键校验（顺便拿教室对象）
        existenceChecker.assertCoachExists(dto.getCoachId());
        Room room = existenceChecker.assertRoomExists(dto.getRoomId());

        // 2. 容量不得超过教室容量
        if (dto.getCapacity() > room.getCapacity()) {
            throw new BizException(4001,
                "课程容量（" + dto.getCapacity()
              + "）超过教室容量（" + room.getCapacity() + "）");
        }

        // 3. 教练冲突检测（新增时 excludeId = null）
        int coachConflict = courseMapper.countCoachConflict(
                dto.getCoachId(), dto.getStartTime(), dto.getEndTime(), null);
        if (coachConflict > 0) {
            throw new BizException(4091, "该教练在此时间段已有课程");
        }

        // 4. 教室冲突检测
        int roomConflict = courseMapper.countRoomConflict(
                dto.getRoomId(), dto.getStartTime(), dto.getEndTime(), null);
        if (roomConflict > 0) {
            throw new BizException(4092, "该教室在此时间段已被占用");
        }

        // 5. 落库
        Course c = new Course();
        BeanUtils.copyProperties(dto, c);
        c.setStatus(0);          // 默认待开始
        c.setEnrolledCount(0);
        courseMapper.insert(c);

        log.info("[新增课程] id={} title={} coach={} room={}",
                 c.getId(), c.getTitle(), c.getCoachId(), c.getRoomId());
        return c.getId();
    }
}
```

划重点：**校验顺序按「便宜到昂贵」排列**——先做本地对象比较（`capacity > 教室 capacity`），再做 DB 查询（存在性、冲突），最后 `INSERT`。**早失败早返回**能省一次网络往返和一次磁盘写。

### 5.8 CourseService.update 完整源码

```java
/**
 * 修改课程。
 * <p>差异点：
 * <ul>
 *   <li>先取 old，把 dto 的 null 字段用 old 字段补齐（PATCH 语义）</li>
 *   <li>冲突检测 excludeId = 自己的 id</li>
 *   <li>capacity 不得小于 enrolled_count</li>
 *   <li>已结束或已取消的课程禁止修改</li>
 *   <li>rows == 0 视为并发修改</li>
 * </ul>
 */
@Transactional(rollbackFor = Exception.class)
public void update(CourseUpdateDTO dto) {
    Course old = courseMapper.selectById(dto.getId());
    if (old == null || Integer.valueOf(1).equals(old.getDeleted())) {
        throw new BizException(4041, "课程不存在：id=" + dto.getId());
    }
    if (old.getStatus() == 3 || old.getStatus() == 4) {
        throw new BizException(4093, "已结束或已取消的课程不允许修改");
    }

    // 拼合并对象：dto 里 null 的字段用 old 字段兜底
    Long coachId = dto.getCoachId() != null ? dto.getCoachId() : old.getCoachId();
    Long roomId  = dto.getRoomId()  != null ? dto.getRoomId()  : old.getRoomId();
    LocalDateTime start = dto.getStartTime() != null
            ? dto.getStartTime() : old.getStartTime();
    LocalDateTime end   = dto.getEndTime()   != null
            ? dto.getEndTime()   : old.getEndTime();

    // 校验外键
    existenceChecker.assertCoachExists(coachId);
    Room room = existenceChecker.assertRoomExists(roomId);

    Integer capacity = dto.getCapacity() != null
            ? dto.getCapacity() : old.getCapacity();
    if (capacity > room.getCapacity()) {
        throw new BizException(4001, "课程容量超过教室容量");
    }
    if (capacity < old.getEnrolledCount()) {
        throw new BizException(4002, "已报名人数超过新容量，不能改小");
    }

    // 冲突检测：excludeId = 自己
    if (courseMapper.countCoachConflict(coachId, start, end, dto.getId()) > 0) {
        throw new BizException(4091, "该教练在此时间段已有课程");
    }
    if (courseMapper.countRoomConflict(roomId, start, end, dto.getId()) > 0) {
        throw new BizException(4092, "该教室在此时间段已被占用");
    }

    // selective 更新
    Course c = new Course();
    BeanUtils.copyProperties(dto, c);
    int rows = courseMapper.updateSelective(c);
    if (rows == 0) {
        throw new BizException(4094, "并发修改，请刷新重试");
    }

    log.info("[修改课程] id={}", dto.getId());
}
```

划重点：**修改比新增多三点考虑**——

1. `excludeId = dto.getId()`：不然自己和自己冲突；
2. `capacity < enrolledCount`：已经有人报名后不能把容量改小；
3. `rows == 0`：视为并发修改——防止两个后台同时改一条数据只有一个生效但都返回成功。

### 5.9 updateSelective SQL

`CourseMapper.xml`：

```xml
<update id="updateSelective">
  UPDATE tb_course
  <set>
    <if test="title      != null">title       = #{title},</if>
    <if test="coachId    != null">coach_id    = #{coachId},</if>
    <if test="roomId     != null">room_id     = #{roomId},</if>
    <if test="startTime  != null">start_time  = #{startTime},</if>
    <if test="endTime    != null">end_time    = #{endTime},</if>
    <if test="capacity   != null">capacity    = #{capacity},</if>
    <if test="fee        != null">fee         = #{fee},</if>
    <if test="intro      != null">intro       = #{intro},</if>
    <if test="coverUrl   != null">cover_url   = #{coverUrl},</if>
    update_time = NOW()
  </set>
  WHERE id = #{id}
    AND deleted = 0
</update>
```

⚠️ **特别注意**：`<set>` 标签会自动去掉最后一个逗号，比手写 `SET a=?, b=?, ...` 优雅。`update_time = NOW()` 放在 `<if>` **外面**——每次修改都要更新时间戳。

### 5.10 insert SQL

```xml
<insert id="insert" useGeneratedKeys="true" keyProperty="id">
  INSERT INTO tb_course
    (title, coach_id, room_id, start_time, end_time,
     capacity, enrolled_count, status, fee, intro, cover_url)
  VALUES
    (#{title}, #{coachId}, #{roomId}, #{startTime}, #{endTime},
     #{capacity}, #{enrolledCount}, #{status}, #{fee}, #{intro}, #{coverUrl})
</insert>
```

`useGeneratedKeys="true" keyProperty="id"` 让 MyBatis 把 `AUTO_INCREMENT` 生成的主键回填到实体的 `id` 字段——Service 里 `c.getId()` 才能拿到。

### 5.11 联调剧本：8 组用例

**（1）正常新增**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "周四塑形",
    "coachId": 2,
    "roomId": 2,
    "startTime": "2026-07-23T19:00:00",
    "endTime":   "2026-07-23T20:00:00",
    "capacity": 15,
    "fee": 128.00
  }'
```

期望：`code: 0, data: <新 id>`。

**（2）教练冲突（张教练已有 07-20 08:00-09:00 哈他）**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "冲突课",
    "coachId": 1,
    "roomId": 2,
    "startTime": "2026-07-20T08:30:00",
    "endTime":   "2026-07-20T09:30:00",
    "capacity": 15,
    "fee": 88.00
  }'
```

期望：`code: 4091, msg: "该教练在此时间段已有课程"`。

**（3）教室冲突（1 号教室已有 07-20 08:00-09:00）**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "教室冲突",
    "coachId": 2,
    "roomId": 1,
    "startTime": "2026-07-20T08:30:00",
    "endTime":   "2026-07-20T09:30:00",
    "capacity": 15,
    "fee": 88.00
  }'
```

期望：`code: 4092, msg: "该教室在此时间段已被占用"`。

**（4）容量超限（教室容量 20，课程容量 100）**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "超容量",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-08-15T08:00:00",
    "endTime":   "2026-08-15T09:00:00",
    "capacity": 100,
    "fee": 88.00
  }'
```

期望：`code: 4001, msg: "课程容量（100）超过教室容量（20）"`。

**（5）修改课程标题（不改时间）**

```bash
curl -X PUT http://localhost:8080/api/courses/1 \
  -H "Content-Type: application/json" \
  -d '{"id": 1, "title": "周一晨间哈他（改版）"}'
```

期望：`code: 0`。

**（6）修改课程时间到冲突段**

```bash
curl -X PUT http://localhost:8080/api/courses/3 \
  -H "Content-Type: application/json" \
  -d '{
    "id": 3,
    "startTime": "2026-07-20T08:00:00",
    "endTime":   "2026-07-20T09:00:00"
  }'
```

期望：`code: 4091` 或 `4092`（因为周三流瑜伽 id=3 改到周一 08:00 就撞上 1 号教练）。

**（7）修改容量小于已报名（假设已报名 5 人，改到 3）**

```bash
curl -X PUT http://localhost:8080/api/courses/1 \
  -H "Content-Type: application/json" \
  -d '{"id": 1, "capacity": 3}'
```

期望：`code: 4002, msg: "已报名人数超过新容量，不能改小"`。

**（8）修改已结束课程**

先手动把 id=1 改成 `status=3`，再：

```bash
curl -X PUT http://localhost:8080/api/courses/1 \
  -H "Content-Type: application/json" \
  -d '{"id": 1, "title": "新标题"}'
```

期望：`code: 4093, msg: "已结束或已取消的课程不允许修改"`。

### 5.12 pitfall / 注意

1. **`LocalDateTime` 时区**：JVM 时区必须与 MySQL 时区一致。启动脚本加 `-Duser.timezone=Asia/Shanghai`，JDBC URL 加 `serverTimezone=Asia/Shanghai`。否则 8 点写入、8 点查出、变成 0 点或 16 点——用户看到时会怀疑人生。
2. **`DATETIME` 精度**：MySQL 8.0 支持 `DATETIME(6)` 微秒精度，本项目秒级足够；如果精度不一致，`LocalDateTime` 里的纳秒部分会被 MySQL 静默截断。
3. **事务传播 REQUIRED vs REQUIRES_NEW**：本讲只用 `REQUIRED`（默认）。`REQUIRES_NEW` 强制新起独立事务，与外层事务隔离——Day11-12 会讲。
4. **`@Transactional` 在 `private` 方法上失效**：Spring 用代理拦截事务，`private` 方法**不走代理**——`@Transactional` 加了也没用。**只在 `public` 方法上加**。
5. **跨库无法用 `@Transactional`**：单个 `@Transactional` 只对**同一个** `DataSource` 生效。跨库要用「分布式事务」（Seata 等），Day15+ 才会讲。
6. **`DuplicateKeyException` 与 `BizException` 的区别**：Service 层预查漏了、并发下 DB 唯一索引拦下的，抛的是 `DuplicateKeyException`。这不是业务异常——`GlobalExceptionHandler` 里已有单独分支处理，返回 `code: 409`。

### 5.13 练习 / 思考

1. **必做**：完成 `countCoachConflict` / `countRoomConflict` 两条 SQL + `CourseService.add` / `update` + `updateSelective` / `insert` SQL 的全套编码。
2. **必做**：Postman 至少交 8 组用例的截图（正反各半）。
3. **思考**：如果同一秒两个前端同时提交新增「同教练同时段」的课，冲突检测 SQL 会不会双双通过？答：会，这是**竞态**（race condition）——Day13-14 用「乐观锁 / 唯一索引 / 分布式锁」补齐。
4. **挑战**：为 `insert` 补一条**兜底**唯一索引 `UNIQUE KEY uk_conflict (coach_id, start_time, deleted)`，试试它能兜住哪些场景、兜不住哪些场景（提示：唯一索引不能表达「区间相交」，只能兜住「完全相同时间点」）。

---

## 第 6 讲：状态流转 + 删除策略 + Controller 汇总 + AI 生成冲突检测

### 6.1 引入：报名中的课能删吗？已结束的课能改时间吗？

上讲把「新增」「修改」跑通了，还剩三件事：

1. **状态变更**：发布（0→1）、取消（0/1→4）、结课（2→3）；
2. **删除**：能删还是不能删？
3. **Controller 六接口汇总**。

场景：前端课程详情页右上角有「发布」「取消」「删除」三个按钮——今天把这三个按钮的后端接口全部实现。

🎯 **一句话痛点**：**状态与删除看起来最简单，坑却最多**——终态回流、并发点击、有引用还能不能删——都会在这一讲讲清楚。

### 6.2 核心概念：状态机

状态机图（ASCII 版）：

```text
           ┌──────────┐
           │ 0 待开始 │
           └────┬─────┘
                │ 手工发布
                ▼
           ┌──────────┐        取消
           │ 1 报名中 │ ──────────────┐
           └────┬─────┘               │
     定时任务   │ start_time 到       │
                ▼                     ▼
           ┌──────────┐         ┌──────────┐
           │ 2 进行中 │         │ 4 已取消 │◄─── 从 0/1 可来
           └────┬─────┘         └──────────┘
                │ end_time 到          ▲
                ▼                       │
           ┌──────────┐                 │
           │ 3 已结束 │(终态)            │
           └──────────┘                 │
                                        │
   0/1 → 4：手工取消 ────────────────────┘
```

划重点：

- `3 已结束` 和 `4 已取消` 是**终态**，不能再回流；
- 从 `0 / 1` 都能到 `4`；
- `2 进行中` 到 `3 已结束` 由**定时任务**触发（Day13-14 讲 `@Scheduled`）；
- `2 进行中` 不允许**手工取消**——课已经在上了，取消损失更大，业务上要走「退款」流程。

### 6.3 表驱动的状态转移校验

用一个 `Map<Integer, Set<Integer>>` 把规则从代码抽到数据里——**表驱动**：

`com.yinxiang.common.StateTransitionValidator`：

```java
package com.yinxiang.common;

import com.yinxiang.common.exception.BizException;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Set;

/**
 * 课程状态转移校验器。
 * <p>表驱动：加状态只改 TRANSITIONS，不改 if-else。
 */
@Component
public class StateTransitionValidator {

    /** 允许的转移：from → 可达 to 的集合 */
    private static final Map<Integer, Set<Integer>> TRANSITIONS = Map.of(
        0, Set.of(1, 4),    // 待开始 → 报名中 / 已取消
        1, Set.of(2, 4),    // 报名中 → 进行中 / 已取消
        2, Set.of(3)        // 进行中 → 已结束
        // 3 与 4 是终态，不出现在 key 里
    );

    /** 校验 from → to 是否合法，非法则抛业务异常。 */
    public void assertAllowed(int from, int to) {
        Set<Integer> allowed = TRANSITIONS.getOrDefault(from, Set.of());
        if (!allowed.contains(to)) {
            throw new BizException(4095,
                "状态不允许从 " + from + " 变更为 " + to);
        }
    }
}
```

划重点：**表驱动**是把「配置」与「逻辑」分开的经典做法——未来加状态只改 `Map`，不改 `if-else`。

### 6.4 乐观并发 SQL

发布 / 取消这类**并发点击**场景怎么办？两个人几乎同时点「发布」，怎么保证只有一个成功？

方案 A：`SELECT FOR UPDATE` 悲观锁——会锁行，并发下性能差；
方案 B：`WHERE status = fromStatus` 乐观锁——**零成本**。

`CourseMapper.xml`：

```xml
<update id="updateStatus">
  UPDATE tb_course
     SET status = #{toStatus}, update_time = NOW()
   WHERE id = #{id}
     AND status = #{fromStatus}
     AND deleted = 0
</update>
```

划重点：`AND status = #{fromStatus}` 就是**最朴素的乐观锁**——

- 两人几乎同时点「发布」；
- 第一个把 status 从 0 改到 1；
- 第二个 SQL 的 `WHERE status = 0` **匹配失败**，`rows = 0`，Service 层判 0 抛异常。

💡 **口诀**：**WHERE 里带上「预期原值」+ 检查 rows == 0**——这是 SQL 乐观锁的标准姿势。

### 6.5 CourseService.updateStatus

```java
@Transactional(rollbackFor = Exception.class)
public void updateStatus(Long id, Integer toStatus) {
    Course c = courseMapper.selectById(id);
    if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
        throw new BizException(4041, "课程不存在");
    }

    // 表驱动校验合法性
    stateTransitionValidator.assertAllowed(c.getStatus(), toStatus);

    // 乐观锁 UPDATE
    int rows = courseMapper.updateStatus(id, c.getStatus(), toStatus);
    if (rows == 0) {
        throw new BizException(4094, "并发修改，请刷新重试");
    }

    log.info("[状态流转] id={} {} → {}", id, c.getStatus(), toStatus);
}
```

Mapper 接口：

```java
int updateStatus(@Param("id") Long id,
                 @Param("fromStatus") Integer fromStatus,
                 @Param("toStatus")   Integer toStatus);
```

### 6.6 删除策略：三选一

| 策略 | 说明 | 优点 | 缺点 |
|---|---|---|---|
| **物理删除** | `DELETE FROM tb_course` | 数据干净 | 有外键引用（订单）会失败 / 无法追溯 |
| **逻辑删除** | `UPDATE tb_course SET deleted = 1` | 保留数据 / 可恢复 | 所有查询要 `AND deleted = 0` |
| **归档** | 移到 `tb_course_archive` | 主表干净 + 保留历史 | 维护成本高（要建镜像表） |

划重点：**本项目课程用逻辑删除**——理由是「订单要能查到已删除的课名」。

删除时同步校验：如果已有报名（`enrolled_count > 0`），提示「请改为取消课程」，禁止删除。

**规则**：`enrolled_count > 0` **禁止**逻辑删除。

### 6.7 逻辑删除后名称能否复用

⚠️ **特别注意**：本项目 `tb_course` **没建** `title` 的唯一索引，所以逻辑删除后同名课程能重建，没问题。

如果业务将来要求「课程标题不能重名」，需要加：

```sql
UNIQUE KEY uk_title_deleted (title, deleted)
```

**必须**联合 `deleted` 字段——否则软删后重建同名课程会因唯一冲突失败。

💡 **口诀**：**逻辑删除的表要建唯一索引，索引 key 里带上 `deleted`**。

### 6.8 CourseService.logicalDelete

```java
@Transactional(rollbackFor = Exception.class)
public void logicalDelete(Long id) {
    Course c = courseMapper.selectById(id);
    if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
        throw new BizException(4041, "课程不存在");
    }
    if (c.getEnrolledCount() != null && c.getEnrolledCount() > 0) {
        throw new BizException(4096, "该课程已有报名，请改为取消课程");
    }
    courseMapper.logicalDeleteById(id);

    log.info("[逻辑删除课程] id={}", id);
}
```

Mapper XML：

```xml
<update id="logicalDeleteById">
  UPDATE tb_course
     SET deleted = 1, update_time = NOW()
   WHERE id = #{id} AND deleted = 0
</update>
```

### 6.9 CourseController 完整源码（六接口）

```java
package com.yinxiang.controller;

import com.yinxiang.common.PageResult;
import com.yinxiang.common.Result;
import com.yinxiang.dto.CourseAddDTO;
import com.yinxiang.dto.CoursePageQuery;
import com.yinxiang.dto.CourseUpdateDTO;
import com.yinxiang.service.CourseService;
import com.yinxiang.vo.CourseVO;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    /** 1. 分页查询 */
    @GetMapping
    public Result<PageResult<CourseVO>> page(CoursePageQuery q) {
        return Result.ok(courseService.pageQuery(q));
    }

    /** 2. 详情 */
    @GetMapping("/{id}")
    public Result<CourseVO> detail(@PathVariable Long id) {
        return Result.ok(courseService.detail(id));
    }

    /** 3. 新增 */
    @PostMapping
    public Result<Long> add(@RequestBody @Valid CourseAddDTO dto) {
        return Result.ok(courseService.add(dto));
    }

    /** 4. 修改（PUT 语义：整体修改，但字段可选） */
    @PutMapping("/{id}")
    public Result<Void> update(@PathVariable Long id,
                                @RequestBody @Valid CourseUpdateDTO dto) {
        dto.setId(id);                 // path 与 body 都传时，以 path 为准
        courseService.update(dto);
        return Result.ok();
    }

    /** 5. 状态流转（PATCH 语义：局部字段变更） */
    @PatchMapping("/{id}/status")
    public Result<Void> updateStatus(@PathVariable Long id,
                                      @RequestParam Integer toStatus) {
        courseService.updateStatus(id, toStatus);
        return Result.ok();
    }

    /** 6. 逻辑删除 */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        courseService.logicalDelete(id);
        return Result.ok();
    }
}
```

### 6.10 HTTP 语义速查

划重点：这是每个 Web 开发都要背熟的对照表——

| 方法 | 用途 | 幂等 | 本项目用例 |
|---|---|---|---|
| GET | 查询 | ✅ | `/courses`、`/courses/{id}` |
| POST | 新增 / 触发 | ❌ | `/courses` |
| PUT | 整体替换 | ✅ | `/courses/{id}` |
| PATCH | 局部更新 | ✅（一般） | `/courses/{id}/status` |
| DELETE | 删除 | ✅ | `/courses/{id}` |

⚠️ **特别注意**：本项目 `PUT /courses/{id}` 允许 body 里字段可选（不传就不改）——严格来讲这是 PATCH 语义。业界惯例是**只要主对象「整体」更新的接口都用 PUT**，字段可选是 selective 实现细节。**看团队约定**。

### 6.11 详情接口 selectDetail

补一下第 2 讲留下的 `detail` 方法。`CourseMapper.xml`：

```xml
<select id="selectDetail" resultMap="courseVOMap">
  SELECT
    c.id, c.title, c.start_time, c.end_time,
    c.capacity, c.enrolled_count, c.fee, c.cover_url, c.status,

    co.id     AS co_id,
    co.name   AS co_name,
    co.avatar AS co_avatar,

    r.id       AS r_id,
    r.code     AS r_code,
    r.name     AS r_name,
    r.capacity AS r_capacity

  FROM tb_course c
  LEFT JOIN tb_coach co ON co.id = c.coach_id AND co.deleted = 0
  LEFT JOIN tb_room  r  ON r.id  = c.room_id  AND r.deleted  = 0
  WHERE c.id = #{id} AND c.deleted = 0
</select>
```

Service：

```java
public CourseVO detail(Long id) {
    CourseVO vo = courseMapper.selectDetail(id);
    if (vo == null) {
        throw new BizException(4041, "课程不存在：id=" + id);
    }
    vo.setStatusText(courseStatusText(vo.getStatus()));
    return vo;
}
```

### 6.12 用 AI 生成冲突检测代码：提示词模板

划重点：好的 AI 提示词有**四个要素**——

1. **表结构**（AI 才能生成正确 SQL）；
2. **业务定义**（AI 才知道什么算「冲突」）；
3. **谓词模板**（AI 就不用自己推导，减少错误率）；
4. **接口契约**（返回值、异常、字段命名）。

完整模板：

```text
请为 Spring Boot 4.0 + MyBatis + MySQL 8.0 项目实现「排课冲突检测」。

表结构（关键字段）：
tb_course(id, coach_id, room_id, start_time, end_time,
          status[0-4], deleted[0/1])

冲突定义（业务背景）：
两个课程时间区间有重叠 → 冲突。
区间重叠的四种情形：
  A 完全前：new.end   <= old.start（不冲突）
  B 完全后：new.start >= old.end  （不冲突）
  C 部分重叠：冲突
  D 完全包含：冲突
不冲突 = A 或 B → 冲突 = NOT (A OR B)

要求：
1. Mapper 提供两个方法：
   countCoachConflict(coachId, startTime, endTime, excludeId)
   countRoomConflict (roomId,  startTime, endTime, excludeId)
2. SQL 使用：
   NOT (end_time <= startTime OR start_time >= endTime)
3. 过滤条件：deleted = 0 AND status <> 4
4. excludeId 用 <if> 包裹：修改场景传自己 id，新增场景传 null
5. Service 层顺序调用两个方法，抛 BizException(4091 / 4092)
6. 时间字段用 LocalDateTime，不用 Date
```

### 6.13 收到 AI 输出后必做的 5 项校验

划重点：AI 是助手不是老板——它输出的代码**必须**再走一遍质量清单：

1. **`status <> 4` 有没有漏**：已取消课程不占用时段，AI 常忘写这条；
2. **是否排除自己 id**（`excludeId`）：如果 AI 忘用 `<if>` 包裹，新增场景会传空报错；
3. **`deleted = 0` 是否加**：AI 有时候只写业务条件，忘了软删除标记；
4. **时间字段是 `LocalDateTime`**：AI 老写 `Date`——一律拒收；
5. **返回类型与 Service 契约一致**：`countXxxConflict` 应该返回 `int`（0 表不冲突），有时 AI 会返回 `List<Course>`，需要改成 `COUNT(*)`。

💡 **口诀**：**AI 生成一次、人工审五点、跑一遍单测**——这就是 AI 协作的完整闭环。

### 6.14 联调剧本：完整 CRUD 走一遍

**（1）新增课程**

```bash
curl -X POST http://localhost:8080/api/courses \
  -H "Content-Type: application/json" \
  -d '{
    "title": "AI 演示课",
    "coachId": 1,
    "roomId": 1,
    "startTime": "2026-09-01T10:00:00",
    "endTime":   "2026-09-01T11:00:00",
    "capacity": 15,
    "fee": 128.00
  }'
```

期望：`code: 0, data: 100`（假设新 id 为 100）。

**（2）查详情**

```bash
curl -i http://localhost:8080/api/courses/100
```

期望：完整嵌套 VO。

**（3）发布（0 → 1）**

```bash
curl -X PATCH "http://localhost:8080/api/courses/100/status?toStatus=1"
```

期望：`code: 0`。

**（4）强行从 3 回到 1（终态回流应报错）**

先手动改成 status=3，再：

```bash
curl -X PATCH "http://localhost:8080/api/courses/100/status?toStatus=1"
```

期望：`code: 4095, msg: "状态不允许从 3 变更为 1"`。

**（5）删除（无报名）**

```bash
curl -X DELETE http://localhost:8080/api/courses/100
```

期望：`code: 0`。

**（6）删除后再查详情**

```bash
curl -i http://localhost:8080/api/courses/100
```

期望：`code: 4041, msg: "课程不存在：id=100"`。

### 6.15 本日回顾

一句话主线：**「多表关联 = 主表 + 外键索引 + LEFT JOIN + resultMap；写入前 = 三层校验（字段/跨字段/外键）+ 冲突检测 + 状态流转 + 软删除」**。

今天你手上应该有：

- 一张 `tb_course` 表（含 5 条索引）；
- 两个 VO 类（嵌套 + 扁平）；
- 一个 `resultMap`；
- 两条查询 SQL（`selectPage` + `selectPageCount` + `selectDetail`）；
- 两条冲突检测 SQL（教练 + 教室）；
- 两个 DTO（`CourseAddDTO` + `CourseUpdateDTO`）；
- 一个 `@ValidTimeRange` 自定义校验器；
- 一个 `ExistenceChecker` + 一个 `StateTransitionValidator`；
- 一个 `CourseService`（`pageQuery` / `detail` / `add` / `update` / `updateStatus` / `logicalDelete` 六方法）；
- 一个 `CourseController`（六接口）。

**总代码量约 800 行，覆盖 6 个 REST 接口，处理 15+ 种业务异常**——这是学 Web 开发以来单日产出最多的一次。

### 6.16 pitfall / 注意

1. **`LocalDateTime` 序列化格式**：默认 Jackson 会把 `LocalDateTime` 序列化成数组 `[2026,7,20,8,0]`——很丑。全局配 `spring.jackson.serialization.write-dates-as-timestamps: false` 与 `@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")`，前端才拿到 ISO 字符串。
2. **时区**：见第 5 讲 pitfall 1；**JVM、MySQL、前端**三处时区都要显式设置为 `Asia/Shanghai`。
3. **并发下的状态转移**：本讲用 `WHERE status = fromStatus` 做乐观锁——已经足够。要做**强一致**（金额、库存）需要 `version` 字段的 CAS 方案，Day13+ 讲。
4. **Controller 参数用 `@Valid` 而不是 `@Validated`**：不用分组时一律 `@Valid`。用了 `@Validated({AddGroup.class})` 但 DTO 上没标 `groups` 会**漏校验**。
5. **PATCH 与 PUT 的语义**：严格 REST 里 PUT 是**整体替换**、PATCH 是**局部更新**。本项目 `PUT /courses/{id}` 允许 body 字段可选（selective）——本质上更接近 PATCH，但业界惯例宽松处理。
6. **逻辑删除的联合唯一索引**：如果给某字段建了唯一索引，**必须**联合 `deleted` 字段——否则软删后重建同名会因唯一冲突失败。**本表暂未加唯一索引**，但要牢记规则。

### 6.17 练习 / 思考

1. **必做**：完成 `StateTransitionValidator` + `updateStatus` + `logicalDelete` + `CourseController` 六接口的完整代码，Postman 至少交 5 组用例截图。
2. **必做**：把 6.12 的 AI 提示词完整发给通义灵码 / Trae，把 AI 输出的代码贴到笔记里，**用批注**圈出至少 3 处可以改进的地方（`status`、`excludeId`、`deleted`、时间类型任选）。
3. **思考**：为什么本讲用 `PATCH /courses/{id}/status?toStatus=1` 而不是 `POST /courses/{id}/publish`？两种设计各自的优缺点是什么？
4. **挑战**：给课程模块补一个「批量取消」接口 `POST /courses/batch-cancel`，一次传多个 id，任意一个失败整体回滚（提示：`@Transactional` 的 `rollbackFor` + 循环调用 `updateStatus`；Day11-12 讲事务传播时会再展开）。

---

**Day08 结课语**：整整一天，把印想瑜伽会馆最关键的关联型业务数据——「课程」——从表结构到 Controller 全部走完。明天 Day09 我们把课程封面图（`cover_url`）真正接通——**文件上传与阿里云 OSS**。
