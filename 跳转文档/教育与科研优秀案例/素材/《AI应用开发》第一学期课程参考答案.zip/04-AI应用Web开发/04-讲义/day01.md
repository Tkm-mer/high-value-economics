# 《AI 应用 Web 开发》 - 学生讲义（Day01：Web 初识 + HTML/CSS 基础）

**总讲次：6 讲**
**适用对象：Web 开发初学者（大一/大二本科生），会用浏览器上网、能操作 Windows/macOS 文件系统**
**配套教程：** 《AI 应用 Web 开发教程》第 1 章 + 第 2 章
**项目主线：** 印想瑜伽会馆客户管理系统

---

## 本日概览

| 讲次 | 主题 | 核心产出 |
|------|------|----------|
| 第 1 讲 | Web 工作原理 + B/S vs C/S + HTTP 请求响应模型 | 会用 DevTools Network 观察一次访问全过程 |
| 第 2 讲 | HTML/CSS/JavaScript 三剑客总览 + 入门示例 | 手写一份三剑客共存的最小 `hello.html` |
| 第 3 讲 | Trae 安装配置 + AI 辅助生成 HTML 页面 | 用四要素提示词让 AI 生成一份印想瑜伽首页 |
| 第 4 讲 | HTML 常用标签（结构 / 文本 / 图片 / 链接 / 列表 / 表格 / 表单） | 手写\"印想瑜伽会员登记表\" |
| 第 5 讲 | CSS 引入方式 + CSS 选择器（含优先级） | 给会员登记表配好外部样式表 |
| 第 6 讲 | CSS 盒模型 + DIV + CSS 布局实战 | 完成印想瑜伽后台管理首页三栏布局 |

---

## 第 1 讲：Web 工作原理 + B/S vs C/S + HTTP 请求响应模型

### 1.1 引入：为什么浏览器一按回车，页面就出现了？

你每天打开 B 站、淘宝、微博，看到的页面**不是浏览器凭空画出来的**——它经过了一系列\"客户端问、服务器答\"的过程。这套问答机制就是 **Web**（World Wide Web，万维网）。本讲把这条链路彻底讲透，让你以后遇到\"页面打不开\"\"图片刷不出来\"\"点击按钮没反应\"等问题时，能第一时间定位到出错在哪一步。

**🎯 例子锚点：** 我们本学期要做的《印想瑜伽会馆客户管理系统》，也是一个 Web 应用，运行原理和 B 站一模一样。

### 1.2 从一次浏览器访问说起

当你在浏览器输入 `https://www.bilibili.com` 并按下回车，屏幕出现视频列表这几秒内，实际发生了下面 5 步：

```mermaid
sequenceDiagram
    participant U as 用户浏览器
    participant D as DNS 服务器
    participant S as B 站服务器
    U->>D: 请问 www.bilibili.com 的 IP 地址？
    D-->>U: 是 x.x.x.x
    U->>S: 发送 HTTP 请求 GET /
    S-->>U: 返回 HTML/CSS/JS 等资源
    U->>U: 渲染页面
```

**划重点：** **请求—响应** 是整个 Web 的心跳。一次访问 = 一次心跳。

### 1.3 B/S 架构 vs C/S 架构

Web 应用采用 **B/S 架构**（Browser/Server，浏览器/服务器）。它和传统的 **C/S 架构**（Client/Server，专用客户端/服务器）不同：

| 架构 | 全称 | 客户端 | 更新方式 | 典型代表 |
|------|------|--------|---------|---------|
| B/S | Browser/Server | 浏览器 | 服务器更新即可，用户无感 | 淘宝、微博、B 站、印想瑜伽会馆管理系统 |
| C/S | Client/Server | 专用客户端（.exe / .app） | 需重新下载安装 | 微信桌面版、QQ、王者荣耀 |

**口诀：** B/S 免安装、C/S 要装包。

**💡 提示：** 我们本课程做的印想瑜伽系统属于 B/S——会员用手机浏览器订课，管理员用电脑浏览器管理系统，无需下载 App。

### 1.4 前端 vs 后端 vs 数据库

一个完整的 Web 应用不止有网页——它由三层协同工作：

- **前端**（Front-end）：运行在浏览器里，**看得见摸得着**——页面布局、按钮交互、动画特效
- **后端**（Back-end）：运行在服务器上，**看不见但离不开**——登录校验、订单存储、支付处理
- **数据库**（Database）：存储会员信息、课程信息、预约记录

```mermaid
flowchart LR
    A[用户浏览器<br/>前端 HTML/CSS/JS] -->|HTTP 请求| B[服务器<br/>后端 Java/Spring Boot]
    B -->|SQL 查询| C[数据库<br/>MySQL]
    C -->|返回数据| B
    B -->|返回 JSON| A
```

**Web 公式：**

> **Web 应用 = 前端 + 后端 + 数据库 + 部署**

### 1.5 HTTP 请求响应的 5 个关键要素

每次浏览器和服务器对话，都会带着 5 项信息：

| 要素 | 说明 | 举例 |
|------|------|------|
| URL | 请求地址 | `https://api.yinxiang.com/courses` |
| 方法 | 请求动作 | `GET`（查）/ `POST`（增）/ `PUT`（改）/ `DELETE`（删） |
| 请求头 | 附加信息 | `Content-Type: application/json` |
| 状态码 | 服务器答复 | `200`（成功）/ `404`（找不到）/ `500`（服务器崩了） |
| 响应体 | 实际数据 | HTML 源码 / JSON 数据 / 图片二进制 |

**图示：一次典型请求响应**

```
浏览器 → 服务器：
   GET /api/courses HTTP/1.1
   Host: api.yinxiang.com
   Accept: application/json

服务器 → 浏览器：
   HTTP/1.1 200 OK
   Content-Type: application/json

   [{\"id\":1,\"name\":\"哈他瑜伽\"},{\"id\":2,\"name\":\"阴瑜伽\"}]
```

### 1.6 DevTools：你的第一个调试神器

Chrome / Edge 按 `F12` 打开**开发者工具**（DevTools）。四个高频面板：

| 面板 | 用途 |
|------|------|
| **Elements** | 查看 HTML / CSS 结构 |
| **Console** | 查看 JS 输出与错误 |
| **Network** | 查看所有 HTTP 请求（🌟 本讲重点） |
| **Sources** | 调试 JS 断点 |

**Network 面板的观察路径：** 按 `F12` → 切到 `Network` → 刷新页面 → 从上往下看列表——第一行**主文档**（`Type: document`），后续跟着 CSS、JS、图片。点开任一行右侧可看 **Headers**（请求头 / 状态码）、**Response**（响应内容）、**Timing**（各阶段耗时）。

### 1.7 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| 混淆\"前端\"和\"客户端\" | 前端 = 运行在浏览器里的代码；B/S 架构下客户端就是浏览器 |
| 以为 DNS 解析在服务器上完成 | DNS 解析在**你的电脑发起**，问的是运营商/公共 DNS |
| 只知道 GET 和 POST | 实际上还有 PUT / DELETE / PATCH 等，RESTful API 里都会用 |
| 看到 200 就以为成功 | 状态码 200 只表示 HTTP 层成功，业务上是否成功还要看响应体 |
| 页面白屏就以为是网络问题 | 也可能是 JS 报错，先看 Console 面板 |

### 1.8 练习 / 思考

1. 打开 Chrome DevTools，访问 `https://www.baidu.com`，回答：主文档的状态码是多少？Content-Type 是什么？前 5 个请求里有几个是图片？
2. 画一张\"访问印想瑜伽官网\"的时序图，至少标注：用户 / DNS / 前端服务器 / 后端 API / MySQL 数据库五个角色。
3. HTTP 和 HTTPS 有什么区别？为什么现代网站都要上 HTTPS？
4. 思考：如果你的印象瑜伽 App 是 B/S 架构，会员想升级到\"最新功能\"是自动的还是要重新下载？

---

## 第 2 讲：HTML / CSS / JavaScript 三剑客总览 + 入门示例

### 2.1 引入：网页上一个按钮为什么能显示、能有颜色、能被点击？

答案是三个不同的技术在协作：**HTML 让它出现、CSS 让它好看、JavaScript 让它能响应你**。这三种技术合称\"前端三剑客\"，是所有 Web 开发者必须过的第一关。

### 2.2 HTML：网页的骨架

**HTML**（HyperText Markup Language，超文本标记语言）用于描述网页的**结构**。它由一系列**标签**（Tag）组成。

一份最简 HTML 页面：

```html
<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
    <meta charset=\"UTF-8\">
    <title>我的第一个网页</title>
</head>
<body>
    <h1>你好，Web 世界！</h1>
    <p>这是一个段落。</p>
</body>
</html>
```

逐行解释：

| 代码 | 含义 |
|------|------|
| `<!DOCTYPE html>` | 声明为 HTML5 标准 |
| `<html lang=\"zh-CN\">` | 主要语言为中文 |
| `<meta charset=\"UTF-8\">` | 字符编码，防止中文乱码 |
| `<title>` | 浏览器标签页显示的名字 |
| `<h1>` | 一级标题 |
| `<p>` | 段落 |

**类比锚点：** HTML 就像盖房子的**钢筋骨架**——决定页面有什么、结构怎么组织，但不决定颜色和交互。

### 2.3 CSS：网页的外衣

**CSS**（Cascading Style Sheets，层叠样式表）用于描述网页的**样式**：颜色、字体、间距、动画……

```css
h1 {
    color: #409eff;
    text-align: center;
    font-size: 32px;
}
```

上面的代码会把所有 `<h1>` 变成蓝色、居中、32 像素大字。

**CSS 三段式：**

```
选择器 { 属性: 值; 属性: 值; }
```

**类比锚点：** CSS 就像**衣服和化妆**——同一副骨架，可以穿不同衣服。

### 2.4 JavaScript：网页的灵魂

**JavaScript**（简称 JS）用于赋予网页**交互能力**：点击按钮、验证表单、发送请求、更新 DOM……

```javascript
document.querySelector('button').addEventListener('click', () => {
    alert('你点了我一下！');
});
```

**JS 三步走：**

1. **选元素**：`document.querySelector('button')`
2. **绑事件**：`.addEventListener('click', ...)`
3. **执行动作**：回调函数里的代码

**类比锚点：** HTML 是身体骨骼，CSS 是衣服和化妆，JavaScript 是灵魂与动作。

### 2.5 三剑客的关系与浏览器渲染流水线

```mermaid
flowchart TB
    A[浏览器接收 HTML] --> B[解析 DOM 树]
    B --> C[遇到 CSS 链接<br/>并发下载]
    C --> D[构建 CSSOM]
    B --> E[遇到 JS 脚本<br/>下载并执行]
    D --> F[合成渲染树]
    B --> F
    E --> F
    F --> G[布局 + 绘制]
    G --> H[用户看到页面]
```

**⚠️ 特别注意：** 如果 `<script>` 放在 `<head>` 里且没加 `async` / `defer`，JS 会**阻塞** DOM 解析——用户看到白屏。所以经典做法是把 `<script>` 放到 `</body>` 前。

### 2.6 一个三剑客共存的完整最小示例

```html
<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
    <meta charset=\"UTF-8\">
    <title>三剑客最小示例</title>
    <style>
        body { font-family: \"Microsoft YaHei\", sans-serif; text-align: center; margin-top: 80px; }
        h1 { color: #409eff; }
        button {
            padding: 10px 30px;
            background: #7CB342;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover { background: #558B2F; }
    </style>
</head>
<body>
    <h1>印想瑜伽会馆</h1>
    <p>欢迎来到会员登记页</p>
    <button id=\"btn\">立即登记</button>
    <script>
        document.getElementById('btn').addEventListener('click', () => {
            alert('登记成功！这是 JS 的功劳。');
        });
    </script>
</body>
</html>
```

保存为 `hello.html`，双击打开——你会看到：**结构（HTML）+ 样式（CSS）+ 交互（JS）** 同时生效。

### 2.7 三剑客在印想瑜伽项目中的分工

| 场景 | HTML 负责 | CSS 负责 | JavaScript 负责 |
|------|-----------|----------|-----------------|
| 会员登记表 | 输入框、下拉框、按钮的结构 | 输入框圆角 / 按钮品牌绿 / 悬停变深 | 校验手机号格式、调后端 API |
| 课程列表页 | 卡片结构、图片、文字 | 卡片阴影、Hover 放大 | 无限滚动加载更多 |
| 后台仪表盘 | 侧栏菜单、内容区结构 | 三栏 Flex 布局 | 切换菜单不刷新页面 |

### 2.8 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| 忘写 `<meta charset=\"UTF-8\">` | 中文一定乱码，页面骨架 4 件套一个都不能少 |
| `<script>` 放 `<head>` 里没加 defer | 会阻塞渲染，导致白屏或 JS 找不到元素报错 |
| CSS 选择器 `.` 和 `#` 写反 | `.` 对应 class 属性、`#` 对应 id 属性 |
| 以为标签必须闭合成 `<img></img>` | `<img>` `<br>` `<input>` 是自闭合，不需要结束标签 |
| HTML 和 XML 混淆 | HTML 大小写不敏感、语法宽松；XML 严格 |

### 2.9 练习 / 思考

1. 把上文的 `hello.html` 完善为「印想瑜伽会馆首页」：会馆名称、简介、\"立即预约\"按钮（点击 alert 提示\"预约成功\"）。
2. 用思维导图总结 HTML / CSS / JS 三者的关系与各自作用。
3. 把 `<script>` 从 `<body>` 底部移到 `<head>` 里，观察 alert 为什么不再触发，并解释原因。
4. 思考：为什么现代 Web 页面往往用**外部**的 `.css` 和 `.js` 文件而不是内嵌？

---

## 第 3 讲：Trae 安装配置 + AI 辅助生成第一个 HTML 页面

### 3.1 引入：让 AI 帮你写 HTML，前提是你会问

上一讲你手敲的一份 20 行 HTML 大概花了 5—10 分钟。今天你会看到，只要你**会用四要素提示词**，AI 30 秒就能给你一份 50 行完整可运行的页面。但记住：**AI 不是读心术**——问得好才写得好。这就是**提示工程**（Prompt Engineering）。

### 3.2 Trae：我们本课程的主力 IDE

**Trae** 是字节跳动推出的 **AI 原生 IDE**，基于 VS Code 内核，深度整合豆包大模型。选它的四大理由：

1. **免费、开箱即用**
2. **AI 补全 + AI 对话 + AI 生成整块代码**
3. **完整支持 HTML/CSS/JS/Vue 语法高亮与调试**
4. **中文界面友好**

下载地址：<https://www.trae.ai>

### 3.3 Trae 首次启动三步走

```mermaid
flowchart LR
    A[① 中文界面] --> B[② 登录豆包账号]
    B --> C[③ 新建工作区]
```

| 步骤 | 操作 |
|------|------|
| ① 中文界面 | `Ctrl+Shift+P` → 输入 `Configure Display Language` → 选 `简体中文` → 重启 |
| ② 登录豆包 | 右下角\"AI 助手\" → 手机号登录（获得免费额度） |
| ③ 新建工作区 | 菜单 `文件 → 打开文件夹` → 推荐目录 `D:/web-learn/day01/` |

### 3.4 通义灵码（Lingma）：另一款主流 AI 编程助手

**通义灵码**（Lingma）是阿里云推出的免费 AI 编程助手，本课程后期讲 Spring Boot 后端时会主推它（对 Java 生态更友好）。

安装方式：

- **IDEA 版**：`Settings → Plugins → Marketplace → 搜索 Lingma → Install`
- **VS Code / Trae 版**：`扩展市场 → 搜索 TONGYI Lingma → 安装`
- 登录阿里云账号即可享受**代码补全、代码解释、单元测试生成、Bug 修复**等功能

**💡 提示：** Trae 内置的豆包 AI 和通义灵码可以**同时使用**，前者擅长前端整块生成，后者擅长后端 Java 单函数补全。

### 3.5 提示词四要素：背景 + 目标 + 约束 + 示例

一个高质量的提示词一定包含四部分：

| 要素 | 说明 | 举例 |
|------|------|------|
| **背景** | 我是谁、场景是什么 | 我是 Web 初学者、正在做印想瑜伽首页 |
| **目标** | 我要 AI 给我什么 | 生成一个 HTML 页面 |
| **约束** | 技术限制 | 只用一个文件、行内样式、要品牌绿 `#7CB342` |
| **示例** | 期望效果参考 | 风格类似 Apple 官网的简洁风 |

**图示：四要素田字格**

```
┌───────────────┬───────────────┐
│  背景         │  目标         │
│  我是谁       │  我要什么     │
├───────────────┼───────────────┤
│  约束         │  示例         │
│  技术限制     │  期望效果     │
└───────────────┴───────────────┘
```

**口诀：** **背景 + 目标 + 约束 + 示例，一样不能少。**

### 3.6 反例 vs 正例对比

**反例（AI 无所适从）：**

```text
帮我写一个 HTML 页面。
```

AI 只能给一个通用模板，不贴合你的需求。

**正例（四要素齐全）：**

```text
背景：我是一名 Web 开发初学者，第一次使用 Trae。
目标：请生成一个 HTML 页面，用于\"印想瑜伽会馆\"首页展示。
约束：
1. 只用一个文件，样式用 <style> 内嵌，脚本用 <script> 内嵌；
2. 页面标题为\"印想瑜伽会馆——静心养身\"；
3. 顶部一个居中的一级标题\"印想瑜伽会馆\"，颜色 #7CB342（品牌绿）；
4. 中间一段介绍文字\"用一节课的时间，找回自己的呼吸\"；
5. 底部一个\"立即预约\"按钮，点击弹出 alert 提示\"预约成功，客服会联系您\"。
示例：整体风格类似 Apple 官网的简洁风，字体 Microsoft YaHei，页面居中。
```

AI 会返回一段完整、可直接运行的代码。点击代码块右上角\"插入到编辑器\"→ 保存为 `.html` → 浏览器打开即可看到效果。

### 3.7 AI 时代的写代码方式：反复对话，逐步逼近

拿到 AI 的第一版代码后，通常不是终点。你可以继续追问：

```text
请把按钮改成圆角 8px、悬停时颜色加深。
```

```text
请在按钮下方加一句小字\"© 2026 印想瑜伽会馆\"，颜色 #999。
```

**划重点：** **AI 是助手不是替代者**。**看不懂的代码不要盲目提交**——AI 也会犯错，也会写出\"看似能跑但有隐患\"的代码。

### 3.8 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| 提示词太笼统 | 用四要素框架，尤其\"约束\"部分要具体 |
| AI 输出被截断 | 直接说\"请继续\"或\"请把剩下部分完整给我\" |
| 每次都从零开始问 | 在同一个对话里继续追问，AI 有上下文记忆 |
| 复制 AI 代码不检查 | 至少要跑一遍，看是否有报错；未来项目里更要**审代码** |
| 忘记登录导致额度报错 | 检查右下角\"AI 助手\"是否登录成功 |

### 3.9 练习 / 思考

1. 完成 Trae 安装 + 中文化 + 豆包登录 + 新建工作区 `D:/web-learn/day01/`，截图证明。
2. 用四要素提示词让 AI 生成一份\"个人名片\"HTML，包含姓名、专业、照片、爱好列表，保存为 `card.html`。
3. 把同一需求（个人名片）**分别用四要素完整版**和**只写一句话**让 AI 各生成一次，对比两次输出差异，写 100 字点评。
4. 思考：如果你负责教一个从没写过代码的高中生用 Trae，你会怎么解释\"提示词四要素\"？

---

## 第 4 讲：HTML 常用标签（结构 / 文本 / 图片 / 链接 / 列表 / 表格 / 表单）

### 4.1 引入：让 AI 写代码好，但看得懂 AI 写的每一行更好

上一讲你已经能让 AI 生成完整 HTML 页面。但如果你不认识里面每一个标签，你就永远只是\"AI 的搬运工\"。本讲把 HTML 常用标签系统过一遍，让你以后**既会用又能改**。

### 4.2 页面骨架 4 件套

任何一个合格的 HTML 页面都必须包含：

```html
<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>页面标题</title>
</head>
<body>
    <!-- 页面正文 -->
</body>
</html>
```

| 部分 | 作用 |
|------|------|
| `<!DOCTYPE html>` | 声明为 HTML5 标准 |
| `<html lang=\"zh-CN\">` | 告诉浏览器与搜索引擎主要使用中文 |
| `<meta charset=\"UTF-8\">` | 字符编码——**忘写中文必乱码** |
| `<meta name=\"viewport\">` | 移动端自适应 |
| `<title>` | 浏览器标签页显示的名字 |

**⚠️ 特别注意：** 4 件套一个都不能少，是 HTML 页面的**基石**。

### 4.3 文字类标签

| 标签 | 说明 | 示例 |
|------|------|------|
| `<h1>` ~ `<h6>` | 六级标题，`h1` 最大 | `<h1>大标题</h1>` |
| `<p>` | 段落 | `<p>一段文字</p>` |
| `<span>` | 行内容器（不换行） | `<span>片段</span>` |
| `<br>` | 换行 | `文本一<br>文本二` |
| `<strong>` | 加粗强调（**语义**） | `<strong>重要</strong>` |
| `<em>` | 倾斜强调（**语义**） | `<em>强调</em>` |

**划重点：** `<strong>` 和 `<b>` 视觉上都变粗——但 `<strong>` 是**语义级别的重要**，对 SEO 和屏幕阅读器友好；只是为了变粗，推荐用 CSS 的 `font-weight`。

### 4.4 图片、超链接、列表

```html
<!-- 图片 -->
<img src=\"course-cover.jpg\" alt=\"哈他瑜伽课程封面\" width=\"320\">

<!-- 超链接 -->
<a href=\"https://www.bilibili.com\" target=\"_blank\">去 B 站</a>

<!-- 无序列表 -->
<ul>
    <li>哈他瑜伽</li>
    <li>阴瑜伽</li>
    <li>流瑜伽</li>
</ul>

<!-- 有序列表 -->
<ol>
    <li>第一步：注册账号</li>
    <li>第二步：预约课程</li>
    <li>第三步：签到上课</li>
</ol>
```

**⚠️ 特别注意：**
- `<img>` **必带 `alt` 属性**：图片加载失败时显示替代文字，也帮助盲人用户/搜索引擎
- `<a>` 的 `target=\"_blank\"` 表示**在新标签页打开**（避免离开当前页）

### 4.5 表格

```html
<table border=\"1\">
    <thead>
        <tr><th>课程名</th><th>教练</th><th>时间</th></tr>
    </thead>
    <tbody>
        <tr><td>哈他瑜伽</td><td>李老师</td><td>周一 19:00</td></tr>
        <tr><td>阴瑜伽</td><td>王老师</td><td>周三 20:00</td></tr>
    </tbody>
</table>
```

| 标签 | 含义 |
|------|------|
| `<table>` | 整张表 |
| `<thead>` / `<tbody>` | 表头 / 表体 |
| `<tr>` | 一行（Table Row） |
| `<th>` | 表头单元格（Table Header） |
| `<td>` | 数据单元格（Table Data） |

**💡 提示：** 真实项目里，`border` **由 CSS 控制**，不用标签属性 `border=\"1\"`。学习期可以先写，工作后就改用 CSS。

### 4.6 表单（重点！后端联调的入口）

表单是**收集用户输入**的核心，也是前后端联调的入口。以下是**印想瑜伽会员登记表**：

```html
<form action=\"/api/members\" method=\"post\">
    <label>姓名：<input type=\"text\" name=\"name\"></label><br>
    <label>手机：<input type=\"tel\" name=\"phone\"></label><br>
    <label>密码：<input type=\"password\" name=\"password\"></label><br>
    <label>性别：
        <input type=\"radio\" name=\"gender\" value=\"F\" checked> 女
        <input type=\"radio\" name=\"gender\" value=\"M\"> 男
    </label><br>
    <label>感兴趣的科目：
        <input type=\"checkbox\" name=\"interest\" value=\"hatha\"> 哈他
        <input type=\"checkbox\" name=\"interest\" value=\"yin\"> 阴瑜伽
        <input type=\"checkbox\" name=\"interest\" value=\"flow\"> 流瑜伽
    </label><br>
    <label>会员卡类型：
        <select name=\"card\">
            <option value=\"month\">月卡</option>
            <option value=\"season\">季卡</option>
            <option value=\"year\">年卡</option>
        </select>
    </label><br>
    <textarea name=\"remark\" rows=\"3\" cols=\"30\" placeholder=\"备注（如身体状况）\"></textarea><br>
    <button type=\"submit\">立即登记</button>
</form>
```

**表单标签速查：**

| 标签 | 作用 | 关键属性 |
|------|------|----------|
| `<form>` | 表单容器 | `action`（提交去哪）、`method`（GET/POST） |
| `<input type=\"text\">` | 文本框 | `name`、`placeholder`、`required` |
| `<input type=\"password\">` | 密码框 | 输入时显示 `•••` |
| `<input type=\"tel\">` | 手机号 | 移动端弹数字键盘 |
| `<input type=\"radio\">` | 单选（同 `name` 一组） | `value`、`checked` |
| `<input type=\"checkbox\">` | 复选 | `value`、`checked` |
| `<select>` + `<option>` | 下拉选择 | `<option value=\"...\">` |
| `<textarea>` | 多行文本 | `rows`、`cols`、`placeholder` |
| `<button type=\"submit\">` | 提交按钮 | `type=\"submit\"` |

**⚠️ 特别注意：** `name` 属性是**后端拿到数据的键**，务必与后端约定的字段名一致。印想瑜伽的 `MemberController` 拿的字段名必须和这里对得上，否则数据接不上。

**🎯 例子锚点：** 上面的 `name=\"phone\"` 意味着后端 Java 里 `member.setPhone(request.getParameter(\"phone\"))` 能拿到值。改成 `name=\"tel\"` 后端就拿不到了。

### 4.7 HTML5 语义化标签

以下标签在结构上等价于 `<div>`，但**含义更清晰**，对 SEO 与可访问性更友好：

| 标签 | 语义 | 典型位置 |
|------|------|----------|
| `<header>` | 页头 | 顶部 Logo + 导航 |
| `<nav>` | 导航区 | 菜单、面包屑 |
| `<main>` | 主体内容 | 中间大区域（每页应只有一个） |
| `<section>` | 章节 | 内容分块 |
| `<article>` | 独立文章 | 博客文章、新闻卡片 |
| `<aside>` | 侧栏 | 右侧广告、相关链接 |
| `<footer>` | 页脚 | 版权信息 |

**图示：印想瑜伽官网的语义化结构**

```mermaid
flowchart TB
    A[header 会馆 Logo + 主导航] --> B[main]
    B --> C[section 本周热门课程]
    B --> D[section 会员招募]
    B --> E[aside 联系方式]
    B --> F[footer 版权信息]
```

### 4.8 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| `<img>` 忘写 `alt` | 影响可访问性 + 图片加载失败时页面空缺 |
| `<input>` 忘写 `name` | 后端拿不到数据，表单形同虚设 |
| 同组 `radio` 用了不同 `name` | 单选会变成多选（各选各的），必须同一 `name` |
| 一个页面用了多个 `<h1>` | 语义上不规范，正确做法是每页 1 个 `<h1>` |
| 表单外套 `<form>` 忘了 | 无法提交，`<button type=\"submit\">` 也没反应 |

### 4.9 练习 / 思考

1. 完成\"印想瑜伽会员登记表\"HTML 页面，字段至少包含：姓名、手机、密码、确认密码、性别、感兴趣科目、卡种、备注、提交按钮。保存为 `register.html`。
2. 手抄一份「HTML 常用标签速查表」，A4 纸一页以内，贴电脑旁。
3. 用 AI 生成一份「印想瑜伽会馆教练介绍页」，要求使用 `<section>` + `<article>` + `<img>` + `<h3>` + `<p>` 语义化标签，介绍 3 位教练。
4. 思考：为什么 HTML5 要新增语义化标签？只用 `<div class=\"header\">` 有什么问题？

---

## 第 5 讲：CSS 引入方式 + CSS 选择器（含优先级）

### 5.1 引入：上一讲的会员登记表是不是有点丑？

原生 HTML 的默认样式确实简陋。要让页面\"漂亮\"，就得学 CSS。本讲教你**三种引入方式怎么选**、**6 类选择器怎么用**、以及最重要的——**优先级怎么算**。

### 5.2 CSS 三种引入方式

| 方式 | 写法 | 场景 | 推荐度 |
|------|------|------|--------|
| 行内样式 | `<h1 style=\"color:red\">` | 临时调试 | ⚠️ 最不推荐 |
| 内部样式 | `<style>` 写在 `<head>` 中 | 单页面小项目 | ✅ 学习/演示 |
| 外部样式 | `<link rel=\"stylesheet\" href=\"a.css\">` | 项目正式代码 | ✅✅✅ 强烈推荐 |

三种方式并存的例子：

```html
<!DOCTYPE html>
<html>
<head>
    <link rel=\"stylesheet\" href=\"style.css\">  <!-- 外部：p 是绿色 -->
    <style>
        p { color: blue; }                        <!-- 内部：p 是蓝色 -->
    </style>
</head>
<body>
    <p style=\"color:red\">行内红色</p>          <!-- 行内：红色 -->
    <p>内部蓝色（或外部绿色）</p>
</body>
</html>
```

**划重点：** **结构与样式分离**是工程审美，真实项目里 90% 的 CSS 都在**外部** `.css` 文件里。

### 5.3 6 类常用选择器

```css
/* 1. 元素选择器：全站所有 <p> */
p { color: gray; }

/* 2. 类选择器：class=\"warning\" 的元素 */
.warning { color: red; }

/* 3. id 选择器：id=\"main-title\" 的元素（页面唯一） */
#main-title { font-size: 32px; }

/* 4. 后代选择器：.card 内部任意层级的 <p> */
.card p { color: #333; }

/* 5. 子代选择器：.card 的直接子 <p>（孙子层级不选中） */
.card > p { color: #333; }

/* 6. 属性选择器：type=\"text\" 的 <input> */
input[type=\"text\"] { border: 1px solid #ccc; }
```

**后代 vs 子代对比图示：**

```html
<div class=\"card\">
    <p>直接子 p ← 后代 ✔ / 子代 ✔</p>
    <section>
        <p>孙子 p ← 后代 ✔ / 子代 ✘</p>
    </section>
</div>
```

**口诀：** **后代看血缘、子代看代际**。

### 5.4 伪类 与 伪元素

```css
/* 伪类：状态选择器 */
a:hover { color: #409eff; }         /* 鼠标悬停 */
button:disabled { opacity: 0.4; }   /* 禁用状态 */
input:focus { border-color: #409eff; }  /* 聚焦 */

/* 伪元素：部分选择器 */
p::first-letter { font-size: 24px; }  /* 首字母 */
p::before { content: \"→ \"; }         /* 内容之前插一段 */
```

**口诀：** 伪类看状态、伪元素看部位。

### 5.5 CSS 优先级：为什么我的样式不生效？

优先级决定同一个元素被多条 CSS 规则命中时**最终采用哪一条**。规则如下：

| 层级 | 权重值 | 示例 |
|------|--------|------|
| `!important` | ∞ | `color: red !important;` |
| 行内样式 | 1000 | `<p style=\"color:red\">` |
| id 选择器 | 100 | `#main` |
| 类 / 伪类 / 属性选择器 | 10 | `.warning` / `:hover` / `[type=text]` |
| 元素 / 伪元素选择器 | 1 | `p` / `::before` |
| `*` 通配符 | 0 | `*` |

**优先级口诀：**

> **!important > 行内 > id > 类/伪类/属性 > 元素/伪元素 > 通配符**
> **∞  >  1000  >  100  >  10  >  1  >  0**

**同权重时：** 后写的覆盖先写的（书写顺序决定）。

**🎯 例子锚点：**

```html
<style>
    p { color: blue; }        /* 权重 1 */
    .red { color: red; }      /* 权重 10 */
    #x { color: green; }      /* 权重 100 */
</style>
<p id=\"x\" class=\"red\" style=\"color: orange;\">测试</p>
```

问：这段 `<p>` 最终什么颜色？答：**orange**（行内 1000 最大）。

### 5.6 常用 CSS 属性速查

**文字类：**
- `color` 文字颜色
- `font-size` 字号
- `font-family` 字体
- `font-weight` 粗细（`normal` / `bold` / `600`）
- `line-height` 行高
- `text-align` 对齐（`left` / `center` / `right`）

**背景类：**
- `background-color` 背景色
- `background-image` 背景图
- `background-size` 背景图尺寸（`cover` / `contain`）

**边框与圆角：**
- `border: 1px solid #ccc;`
- `border-radius: 8px;`

**间距与尺寸：**
- `margin`（外边距）/ `padding`（内边距）
- `width` / `height` / `max-width`

**显示与定位：**
- `display: block | inline | inline-block | flex | none`
- `position: static | relative | absolute | fixed | sticky`

### 5.7 DevTools：优先级 debug 神器

Chrome DevTools 的 **Elements → Styles** 面板会：
- **列出所有命中当前元素的 CSS 规则**（从优先级高到低）
- **用删除线标出被覆盖的规则**
- 支持**实时修改**样式看效果

**💡 提示：** 遇到\"我的样式为什么不生效\"，第一时间打开 DevTools 看这里。

### 5.8 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| 滥用 `!important` | 一旦上瘾，后期维护地狱。除非万不得已别用 |
| 后代选择器嵌套过深（如 `.a .b .c .d p`） | 层级越深越难维护，能扁平就扁平 |
| id 选择器 `#x` 用于样式 | id 优先级过高，一旦冲突难以覆盖，推荐用类选择器 |
| 忘了同权重时后写覆盖先写 | 外部 CSS 引入顺序会影响最终样式 |
| 类名用中文或大小写混合 | 建议全小写 + 短横线（如 `.member-card`） |

### 5.9 练习 / 思考

1. 把上一讲的 `register.html` 完善为外部样式版本（拆出 `register.css`），美化会员登记表。
2. 手抄\"优先级口诀\"贴电脑前，并用 3 个小例子验证优先级。
3. 给\"印想瑜伽课程列表页\"表格加\"斑马纹\"（奇偶行不同背景色，用伪类 `tr:nth-child(even)`）。
4. 思考：如果两条外部样式 `a.css` 和 `b.css` 里都定义了 `p { color: xxx }`，最终 `<p>` 是什么颜色由什么决定？

---

## 第 6 讲：CSS 盒模型 + DIV + CSS 布局实战

### 6.1 引入：想不想让你的页面长成后台管理系统那样？

打开印想瑜伽后台管理系统的雏形——**顶栏 + 侧栏菜单 + 内容区 + 底栏**四块整齐排列。这就是本讲要教你的：**盒模型 + Flex 布局**，两把钥匙搞定 80% 的布局需求。

### 6.2 盒模型：每个 HTML 元素都是一个盒子

每一个 HTML 元素都是一个**盒子**，由 4 部分构成（从内到外）：

```mermaid
flowchart TB
    subgraph 盒模型
      subgraph 外边距-margin
        subgraph 边框-border
          subgraph 内边距-padding
            C[内容 content]
          end
        end
      end
    end
```

**4 层含义：**

| 层 | 说明 |
|----|------|
| content | 元素真正的内容区 |
| padding | 内容与边框之间的空隙（**内**边距） |
| border | 边框（有粗细、颜色、样式） |
| margin | 边框与其他元素之间的距离（**外**边距） |

**🎯 例子锚点：** 一个课程卡片：内容是文字与图片（content），文字距离卡片边框 16px（padding），卡片有 1px 灰色边框（border），卡片和其他卡片间隔 20px（margin）。

### 6.3 两种盒模型：content-box vs border-box

CSS 属性 `box-sizing` 有两个值：

| 值 | 含义 | 举例（`width:200; padding:20; border:2`） |
|----|------|------------------------------------------|
| `content-box`（默认） | `width` **只算内容** | 盒子实际宽 = 200 + 20\\*2 + 2\\*2 = **244px** ❗ |
| `border-box`（推荐） | `width` **包含 padding + border** | 盒子实际宽 = **始终 200px** ✅ |

**⚠️ 特别注意：** `content-box` 是新手最容易翻车的地方——**你以为 `width: 200px` 就是 200px，实际却更大**。现代项目**必写全局**：

```css
*, *::before, *::after {
    box-sizing: border-box;
}
```

**口诀：** **写 border-box、天下我有。**

### 6.4 margin 合并陷阱

**⚠️ 特别注意：** 上下相邻的两个块级元素的 margin 会**合并**，取**较大值**（不是相加）。

```
[元素 A]    margin-bottom: 30px
   ↕ 实际间距 = max(30, 20) = 30px（不是 50！）
[元素 B]    margin-top: 20px
```

**避免方式：**
1. 只给单侧设 margin（比如只设 `margin-top`）
2. 用 padding 代替
3. 用 Flex/Grid 布局（Flex 项目间没有 margin 合并问题）

### 6.5 从 float 到 Flex：布局技术的演进

**旧方案 float（了解即可，读得懂就行）：**

```css
.left { float: left; width: 200px; }
.right { margin-left: 220px; }
```

float 原本是为\"文字环绕图片\"设计的，被硬拿来做布局导致各种坑（清除浮动、高度塌陷……）。

**现代方案 Flex（新项目直接用这个）：**

```css
.container { display: flex; gap: 20px; }
.left { width: 200px; }
.right { flex: 1; }
```

**划重点：** **新项目全部用 Flex，float 只需要会读，不需要会写。**

### 6.6 Flex 布局：容器 5 属性 + 项目 3 属性

**容器属性（写在父元素上）：**

```css
.container {
    display: flex;              /* 开启 Flex 布局 */
    flex-direction: row;        /* 主轴方向 row(默认) / column */
    justify-content: center;    /* 主轴对齐 flex-start/center/space-between/space-around */
    align-items: center;        /* 交叉轴对齐 flex-start/center/stretch */
    gap: 20px;                  /* 项目间距 */
}
```

**项目属性（写在子元素上）：**

```css
.item {
    flex: 1;         /* 弹性填充：吃掉剩余空间。多个项目都设 flex: 1 会均分 */
    align-self: end; /* 单独设置这一项的交叉轴对齐 */
    order: 2;        /* 显示顺序，数字越小越靠前 */
}
```

**图示：Flex 主轴与交叉轴**

```
flex-direction: row （主轴水平）
   ┌──────────────────────────┐
   │  [项目1] [项目2] [项目3]  │→ 主轴
   └──────────────────────────┘
                ↕ 交叉轴

flex-direction: column（主轴垂直）
   ┌──────────┐
   │  [项目1] │
   │  [项目2] │  ↕ 主轴
   │  [项目3] │
   └──────────┘
     ← → 交叉轴
```

### 6.7 完整实战：印想瑜伽后台管理首页三栏布局

这就是我们本学期最后要做的界面雏形：

```html
<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
    <meta charset=\"UTF-8\">
    <title>印想瑜伽后台管理</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: \"Microsoft YaHei\", sans-serif; }
        .header { background: #7CB342; color: #fff; padding: 16px; text-align: center; }
        .main { display: flex; min-height: 500px; }
        .sidebar { width: 220px; background: #f5f5f5; padding: 16px; }
        .sidebar ul { list-style: none; }
        .sidebar li { padding: 12px; cursor: pointer; }
        .sidebar li:hover { background: #e0e0e0; }
        .content { flex: 1; padding: 24px; }
        .footer { background: #333; color: #fff; text-align: center; padding: 12px; }
    </style>
</head>
<body>
    <header class=\"header\"><h1>印想瑜伽会馆 - 后台管理</h1></header>
    <div class=\"main\">
        <aside class=\"sidebar\">
            <ul>
                <li>课程科目管理</li>
                <li>会员管理</li>
                <li>教练管理</li>
                <li>教室管理</li>
                <li>预约管理</li>
            </ul>
        </aside>
        <main class=\"content\">
            <h2>欢迎回来</h2>
            <p>请在左侧菜单选择要管理的模块。</p>
        </main>
    </div>
    <footer class=\"footer\">© 2026 印想瑜伽会馆</footer>
</body>
</html>
```

**关键点解读：**

1. `* { box-sizing: border-box; margin: 0; padding: 0; }` 全局重置
2. `.main { display: flex; }` 中间区域用 Flex 分左右
3. `.sidebar { width: 220px; }` 固定侧栏宽度
4. `.content { flex: 1; }` 内容区**吃掉剩余空间**——窗口变宽内容区就变宽，侧栏保持不变
5. `.sidebar li:hover` 鼠标悬停菜单项变色

### 6.8 常用布局套路速查

| 场景 | 关键 CSS |
|------|----------|
| 水平居中一个块 | `margin: 0 auto;` |
| 垂直+水平双向居中 | `display: flex; justify-content: center; align-items: center;` |
| 两栏（左固定 + 右自适应） | 容器 `display: flex;`，左 `width: 200px;`，右 `flex: 1;` |
| 三栏均分 | 容器 `display: flex;`，每项 `flex: 1;` |
| 项目间距 | 容器 `gap: 20px;`（比传统 margin 更清爽） |
| 卡片阴影 | `box-shadow: 0 2px 8px rgba(0,0,0,0.1);` |

### 6.9 pitfall / 注意

| 常见坑 | 建议 |
|--------|------|
| 忘记全局 `border-box` | 页面宽度计算错乱、总是超出预期 |
| 相邻 margin 期望相加实际取大 | 用 padding 或 Flex `gap` 替代 |
| Flex 项目\"挤成一排\"却想换行 | 加 `flex-wrap: wrap;` |
| 用 `float` 做新布局 | 直接改用 Flex，别踩浮动的坑 |
| `flex: 1` 后子项内容溢出 | 加 `min-width: 0;` 或 `overflow: hidden;` |

### 6.10 练习 / 思考

1. 完成\"印想瑜伽后台管理首页\"三栏布局：全局 `border-box`、Flex 分栏、侧栏菜单 5 项、悬停变色。
2. 完成\"印想瑜伽课程卡片九宫格\"：3×3 布局，格子间距 16px，卡片圆角 8px + 阴影，悬停放大 `transform: scale(1.05)`。
3. 让 AI 生成一份\"电商商品详情页\"HTML+CSS，然后用 DevTools 逐一修改 `box-sizing` 和 `margin` 观察布局变化。
4. 思考：如果一个 Flex 容器里有 3 个子项，`flex-basis` 分别是 `100px / 200px / 300px`，容器总宽 900px，最终每个子项实际宽度是多少？

---

## Day01 收官寄语

到这里，你已经掌握了：

- ✅ Web 的工作原理（客户端 / 服务器 / HTTP）
- ✅ B/S 与 C/S 架构的差异
- ✅ 前端三剑客（HTML / CSS / JavaScript）的分工
- ✅ Trae + AI 提示词四要素的工作流
- ✅ HTML 常用标签（含表单）
- ✅ CSS 三种引入方式 + 6 类选择器 + 优先级
- ✅ 盒模型 + Flex 布局

**你现在能独立完成的产物：**
- `hello.html` 三剑客最小示例
- `card.html` AI 生成的个人名片
- `register.html` + `register.css` 印想瑜伽会员登记表
- `courses.html` 印想瑜伽课程列表页
- `admin.html` 印想瑜伽后台管理三栏布局
- `grid.html` 印想瑜伽课程卡片九宫格

**明日预告：** Day02 学 **JavaScript 与 jQuery 基础** + **AI 辅助编写前端界面实战**，让静态页面\"活\"起来，能响应用户操作、能校验表单、能异步请求后端 API。
