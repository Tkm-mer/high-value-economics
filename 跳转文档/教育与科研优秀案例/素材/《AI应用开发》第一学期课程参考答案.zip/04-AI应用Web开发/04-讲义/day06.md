# 《AI 应用 Web 开发》 - 学生讲义（Day06：课程科目管理 + 会员管理）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day05 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、Result 统一响应、参数校验基础）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / PageHelper 6.1+ / MySQL 8.0 / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。今天要打通两张最重要的业务表 —— `tb_category`（课程科目）和 `tb_member`（会员），从表结构到 REST 接口全链路走一遍。前者字段少、规则简单，是「热身」；后者字段多、规则复杂（唯一手机号、软删除、日期区间、状态枚举），是「实战」。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 课程科目列表 + 分页查询 | 跑通 `GET /api/category?page=&pageSize=&name=&status=`，返回 `{total, rows}` |
| 第 2 讲 | 批量删除（前后端约定 + MyBatis foreach） | 跑通 `DELETE /api/category?ids=1,2,3` |
| 第 3 讲 | 新增与修改（表单参数、参数校验、DTO/VO） | 跑通 `POST /api/category` + `PUT /api/category`，名称唯一性校验带 `excludeId` |
| 第 4 讲 | 会员列表与多条件查询（模糊 / 精确 / 区间） | 跑通 `GET /api/member` 六个条件组合 |
| 第 5 讲 | 会员删除与新增（软删除 + 头像预留） | 跑通 `POST /api/member`、`DELETE /api/member/{id}`（`deleted=1`） |
| 第 6 讲 | 会员修改（回显 + 提交）+ 业务层重构与异常处理改造 | 跑通 `GET /api/member/{id}` → `PUT /api/member`，Service 层抽象 `existsByX(value, excludeId)` |

---

## 第 1 讲：课程科目列表 + 分页查询

### 1.1 引入：为什么列表接口天生要分页？

印想瑜伽会馆开了 15 个课程科目（哈他 / 阴 / 流 / 高温 / 孕妇……），前端一次拉回所有科目做排课界面还凑合。可一旦扩到 100 个科目，页面直接卡死。**分页是列表接口的「缺省要求」**，不是加分项。今天先在字段少的 `tb_category` 上把分页链路打通，第 4 讲的会员多条件查询就能顺势推进。

### 1.2 表结构 `tb_category`

```sql
CREATE TABLE tb_category (
  id          BIGINT       PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
  name        VARCHAR(50)  NOT NULL UNIQUE COMMENT '科目名称',
  intro       VARCHAR(255)          COMMENT '简介',
  level       TINYINT      DEFAULT 1 COMMENT '难度 1 入门 2 进阶 3 高级',
  status      TINYINT      DEFAULT 1 COMMENT '状态 0 停用 1 启用',
  create_time DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT '课程科目';

INSERT INTO tb_category (name, intro, level, status) VALUES
 ('哈他瑜伽', '基础体式与呼吸', 1, 1),
 ('阴瑜伽',   '长时间静止拉伸', 2, 1),
 ('流瑜伽',   '连贯串联体式',   2, 1),
 ('孕妇瑜伽', '孕期专属课程',   1, 1);
```

🎯 **划重点**：

- `name` 加 `UNIQUE`（业务上唯一 → 后面新增/修改都要做唯一校验）；
- `status` 用 `TINYINT` 而不是 `BOOLEAN`（后期可扩展 3、4 状态）；
- `create_time / update_time` 用 MySQL 自动填充，Java 侧不用 `setCreateTime(...)`。

### 1.3 引入 PageHelper

`pom.xml`：

```xml
<dependency>
    <groupId>com.github.pagehelper</groupId>
    <artifactId>pagehelper-spring-boot-starter</artifactId>
    <version>2.1.1</version>
</dependency>
```

`application.yml`：

```yaml
pagehelper:
  helper-dialect: mysql
  reasonable: true                 # 页码越界时自动回到第一页 / 最后一页
  support-methods-arguments: true
```

💡 **口诀**：**MySQL 方言 + reasonable 兜底**。

### 1.4 分页四件套：参数对象 → startPage → PageInfo → PageResult

```java
// 分页参数对象
@Data
public class CategoryPageQuery {
    private Integer page = 1;
    private Integer pageSize = 10;
    private String  name;      // 名称模糊
    private Integer status;    // 状态筛选
}

// 分页返回结构（全局通用，放在 common 模块）
@Data
@AllArgsConstructor
public class PageResult<T> {
    private long total;
    private List<T> rows;
}
```

Service 层核心 4 行：

```java
public PageResult<Category> page(CategoryPageQuery q) {
    PageHelper.startPage(q.getPage(), q.getPageSize());       // ① 启动分页
    List<Category> list = mapper.list(q);                     // ② 紧邻的第一条 select 会被自动改写
    PageInfo<Category> info = new PageInfo<>(list);           // ③ 提取 total
    return new PageResult<>(info.getTotal(), info.getList()); // ④ 组装返回
}
```

⚠️ **PageHelper 隐性契约**：`startPage()` **只对紧邻的第一条 select 生效**，中间不能插入任何其它查询语句，否则要么误伤别的 SQL、要么直接不生效。

### 1.5 Mapper XML：`<where>` + `<if>` 组合动态条件

```xml
<mapper namespace="com.yinxiang.mapper.CategoryMapper">
  <select id="list" resultType="com.yinxiang.entity.Category">
    SELECT id, name, intro, level, status, create_time, update_time
    FROM tb_category
    <where>
      <if test="name != null and name != ''">
        AND name LIKE CONCAT('%', #{name}, '%')
      </if>
      <if test="status != null">
        AND status = #{status}
      </if>
    </where>
    ORDER BY id DESC
  </select>
</mapper>
```

🎯 **`<where>` 的三重魔法**：

1. 至少一个 `<if>` 为真时才输出 `WHERE`；
2. 自动吃掉紧跟其后的第一个 `AND` 或 `OR`；
3. 完全为空时直接不输出，避免出现悬空 `WHERE`。

### 1.6 Controller

```java
@RestController
@RequestMapping("/api/category")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService service;

    @GetMapping
    public Result<PageResult<Category>> page(CategoryPageQuery q) {
        return Result.success(service.page(q));
    }
}
```

联调（Postman）：

```text
GET http://localhost:8080/api/category?page=1&pageSize=5&name=瑜伽&status=1
```

期望返回：

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "total": 4,
    "rows": [
      {"id": 4, "name": "孕妇瑜伽", "level": 1, "status": 1, "..." : "..."},
      {"id": 3, "name": "流瑜伽",   "level": 2, "status": 1, "..." : "..."}
    ]
  }
}
```

### 1.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 分页失效，`total` 永远等于 `list.size()` | `PageHelper.startPage` 与目标 select 之间夹了别的 select（如日志、鉴权查询） |
| 中文模糊查询乱码或搜不到 | 表未使用 `utf8mb4`；连接串缺 `?useUnicode=true&characterEncoding=utf8` |
| `<where>` 输出成空 `WHERE` | 用了 `WHERE 1=1` 拼接的老写法，直接删掉，交给 `<where>` |
| `reasonable=false` 时页码传 0 直接报错 | 建议 `true`，前端偶尔手抖不至于崩 |
| `pageSize=10000` 被恶意刷 | Service 里做上限保护：`Math.min(q.getPageSize(), 100)` |

### 1.8 练习/思考

1. 在 `CategoryPageQuery` 里增加 `orderBy` 参数（值只允许 `id`、`create_time`、`level`），实现动态排序。**限制**：只接受白名单，否则抛 `BizException`（防 SQL 注入）。
2. **思考**：如果不使用 PageHelper，自己写 `LIMIT #{offset}, #{pageSize}` 有什么坑？（提示：`total` 从哪来？前端翻到第 5 页时 `offset` 怎么算？）
3. **对比**：`List<Category>` 直接 `new PageInfo<>(list)` 拿 total 是怎么做到的？（提示：PageHelper 拦截器把结果集包成了 `Page<T>` 子类）

---

## 第 2 讲：批量删除（前后端约定 + MyBatis foreach）

### 2.1 引入：删除一条，就够了吗？

后台管理页面几乎每个列表都有一列复选框，选中若干条后点「批量删除」。如果每选一条就调一次 `DELETE /api/category/{id}`，选 20 条要打 20 个请求 —— 网络往返成本、事务边界、失败重试全都出问题。**批量接口是刚需**，而它的核心是**前后端参数格式的约定**。

### 2.2 前后端参数约定：`?ids=1,2,3`

Spring MVC 天然支持把逗号分隔字符串自动转成 `List<Long>`，两种写法都能接：

```text
DELETE /api/category?ids=1,2,3           ← 推荐（URL 短）
DELETE /api/category?ids=1&ids=2&ids=3   ← 也可以（多值参数）
```

Controller：

```java
@DeleteMapping
public Result<Void> deleteBatch(@RequestParam List<Long> ids) {
    if (ids == null || ids.isEmpty()) {
        throw new BizException("请至少选择一条记录");
    }
    service.deleteBatch(ids);
    return Result.success();
}
```

💡 **口诀**：**`?ids=1,2,3` → `List<Long>` 自动装配**，无需写自定义 Converter。

### 2.3 MyBatis `<foreach>` 拼 IN 子句

```xml
<delete id="deleteByIds">
  DELETE FROM tb_category WHERE id IN
  <foreach collection="ids" item="id" open="(" separator="," close=")">
    #{id}
  </foreach>
</delete>
```

Mapper 接口：

```java
int deleteByIds(@Param("ids") List<Long> ids);
```

拼出来的 SQL：

```sql
DELETE FROM tb_category WHERE id IN (1, 2, 3)
```

🎯 **`<foreach>` 五要素**：`collection`（集合名，对应 `@Param`）、`item`（每次迭代的变量名）、`open`（开括号）、`separator`（分隔符）、`close`（闭括号）。少写一个都会拼错。

### 2.4 Service：拿影响行数做二次校验

```java
public void deleteBatch(List<Long> ids) {
    int rows = mapper.deleteByIds(ids);
    if (rows == 0) {
        throw new BizException("记录不存在或已被删除");
    }
    // 若 rows < ids.size()，说明部分 id 不存在 —— 可视业务需要判断是否报错
}
```

💡 **单条删除接口**只是批量删除的语法糖：

```java
@DeleteMapping("/{id}")
public Result<Void> delete(@PathVariable Long id) {
    service.deleteBatch(List.of(id));   // 复用批量逻辑
    return Result.success();
}
```

一个 Service 方法覆盖单删 + 批删，代码复用度最高。

### 2.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `@RequestParam List<Long> ids` 收到 `null` | 前端 URL 少了 `ids=`；或前端错用 JSON body 提交，需改成 `@RequestBody List<Long>` |
| `?ids=` 传空串 400 | 前端「未选中任何行」时不要发请求，或后端加空判断 |
| `<foreach>` 忘写 `open="(" close=")"` | 拼出来变成 `IN 1,2,3` 直接语法错 |
| `IN` 里塞几万个 id | MySQL 单条 SQL 有长度限制（默认 4MB）；分批（如每 500 一批）执行 |
| 删除完发现 rows=0 却没提示 | Service 忘记判断 `rows == 0`，前端一直显示成功 |

### 2.6 练习/思考

1. 前端传 `?ids=` 空串时，`@RequestParam List<Long> ids` 收到的是 `null`、空 List 还是抛异常？动手测一次。
2. 改造 `deleteByIds`，在 SQL 上加 `AND status = 0`（只允许删除**已停用**的科目），防止误删启用中的字典。
3. **思考**：如果表增加 `deleted` 字段做软删除，`deleteByIds` 应该改成 `UPDATE ... SET deleted=1 WHERE id IN (...)`，你猜第 5 讲会不会踩到这个坑？

---

## 第 3 讲：新增与修改（表单参数、参数校验、DTO/VO）

### 3.1 引入：新增 + 修改，抽公用还是各写各的？

写 CRUD 时最容易「随手起个类」：`CategoryAddParam`、`CategoryUpdateParam`、`CategoryVO`、`CategoryDetailVO`……四五个类字段大部分重叠，改一处漏三处。**规范做法**：入参统一用 `CategoryDTO`（含 `id` 字段，新增时 `id=null`、修改时 `id≠null`），出参统一用 `CategoryVO`（如果不需要额外翻译字段，直接用实体也行）。

### 3.2 CategoryDTO 与 Bean Validation

```java
@Data
public class CategoryDTO {
    private Long id;                                          // 新增为 null，修改必填

    @NotBlank(message = "科目名称不能为空")
    @Size(max = 50, message = "名称最长 50 字")
    private String name;

    @Size(max = 255)
    private String intro;

    @Min(1) @Max(3)
    private Integer level;

    private Integer status;
}
```

Controller 接住 DTO，加 `@Valid`：

```java
@PostMapping
public Result<Void> save(@RequestBody @Valid CategoryDTO dto) {
    service.save(dto);
    return Result.success();
}

@PutMapping
public Result<Void> update(@RequestBody @Valid CategoryDTO dto) {
    service.update(dto);
    return Result.success();
}
```

🎯 **`@Valid` 生效三条件**：

1. Controller 参数前有 `@Valid`（或 `@Validated`）；
2. `pom.xml` 引入 `spring-boot-starter-validation`；
3. 参数上有 `@RequestBody`（表单场景则参数上无需 `@RequestBody`，但类前加 `@Validated`）。

### 3.3 Service：名称唯一性校验的通用模式 `existsByX(value, excludeId)`

新增时**没有** id 需要排除；修改时要**排除自己**（否则改个简介也报「名称已存在」）。因此校验方法多一个 `excludeId` 入参：

```java
public void save(CategoryDTO dto) {
    if (mapper.existsByName(dto.getName(), null) > 0) {
        throw new BizException("科目名称已存在");
    }
    Category c = new Category();
    BeanUtils.copyProperties(dto, c);
    if (c.getStatus() == null) c.setStatus(1);
    mapper.insert(c);
}

public void update(CategoryDTO dto) {
    if (dto.getId() == null) throw new BizException("id 不能为空");
    if (mapper.existsByName(dto.getName(), dto.getId()) > 0) {
        throw new BizException("科目名称已被其它记录占用");
    }
    Category c = new Category();
    BeanUtils.copyProperties(dto, c);
    mapper.update(c);
}
```

Mapper XML：

```xml
<select id="existsByName" resultType="int">
  SELECT COUNT(*) FROM tb_category
  WHERE name = #{name}
  <if test="excludeId != null">
    AND id &lt;&gt; #{excludeId}
  </if>
</select>

<insert id="insert" useGeneratedKeys="true" keyProperty="id">
  INSERT INTO tb_category (name, intro, level, status)
  VALUES (#{name}, #{intro}, #{level}, #{status})
</insert>

<update id="update">
  UPDATE tb_category
  <set>
    <if test="name  != null">name  = #{name},</if>
    <if test="intro != null">intro = #{intro},</if>
    <if test="level != null">level = #{level},</if>
    <if test="status!= null">status= #{status},</if>
  </set>
  WHERE id = #{id}
</update>
```

💡 **口诀**：**`<set>` 自动吃逗号，`<where>` 自动吃 AND；WHERE 别忘 id**。

### 3.4 DTO / VO / Entity 三者的关系图

```
前端提交 JSON  ──►  CategoryDTO   ──BeanUtils──►  Category (Entity)  ──►  数据库
                    (参数校验)                     (纯字段映射)

数据库  ──►  Category (Entity)  ──[如需字段翻译]──►  CategoryVO  ──►  前端渲染
```

- **Entity**：与数据库列一一对应，字段名遵守驼峰转下划线；
- **DTO**（Data Transfer Object）：**入参**载体，加校验注解；
- **VO**（View Object）：**出参**载体，可增删字段、可加 xxxText 翻译。

对科目这种字段少的表，出参直接用 Entity 也可以；一旦要翻译 `statusText`（如第 4 讲的会员），就必须走 VO。

### 3.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `@Valid` 完全不生效 | 参数漏了 `@RequestBody`，或没引 `spring-boot-starter-validation` |
| 校验失败返回 500，前端拿不到字段错误 | 需要在全局异常处理器里捕 `MethodArgumentNotValidException`（第 13 章会做） |
| 修改时传 `status=null` 把已启用状态覆盖成 null | `BeanUtils.copyProperties` 是浅拷贝、null 也会覆盖；建议 `<set>` + `<if>` 动态更新，null 不出现在 SQL |
| 修改忘传 id | Service 层第一行判空拦截，别让空 id 的 SQL 打到 MySQL |
| 唯一校验只在应用层做 | 数据库层 `UNIQUE` 约束必须保留，做兜底 |

### 3.6 练习/思考

1. 让 AI 助手（通义灵码）根据表结构生成 `CategoryDTO`、`Category`、`CategoryMapper.xml`。收到代码后，**逐项审查**：注解是否落到 DTO 而非 Entity？`<set>` 各行末尾是否有逗号？`<if test="status != null">` 有没有把 `status=0` 也过滤掉？（`0 != null` 为 true，✅ 正常）
2. 给 `save()` 和 `update()` 都加上 `@Transactional`，思考：读一次 `existsByName` + 写一次 `insert`，需要事务吗？为什么？
3. **思考**：如果两个人同时提交同名科目 —— 应用层校验都过了，会不会同时落库？数据库 `UNIQUE` 约束能救你吗？

---

## 第 4 讲：会员列表与多条件查询（模糊 / 精确 / 区间）

### 4.1 引入：字典表 vs 主档表，难度陡增

第 1—3 讲的 `tb_category` 是「字典表」：字段少、规则简单、只做被引用。今天开始的 `tb_member` 是「主档表」：字段多（12 个）、规则复杂（**手机号唯一**、**软删除**、**日期区间**、**状态枚举**），是印想瑜伽会馆的**核心资产**。业务要求列表支持 6 类条件组合：姓名模糊、手机号模糊、卡类型精确、状态精确、加入时间左区间、加入时间右区间。

### 4.2 表结构 `tb_member`

```sql
CREATE TABLE tb_member (
  id           BIGINT       PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
  name         VARCHAR(50)  NOT NULL COMMENT '姓名',
  phone        VARCHAR(20)  NOT NULL COMMENT '手机号',
  gender       TINYINT      DEFAULT 0 COMMENT '性别 0 未知 1 女 2 男',
  id_card      VARCHAR(32)           COMMENT '身份证号',
  avatar       VARCHAR(255)          COMMENT '头像 URL（Day06 预留字段，Day07 讲文件上传时启用）',
  card_type    TINYINT      DEFAULT 1 COMMENT '卡类型 1 月卡 2 季卡 3 年卡 4 次卡',
  card_expire  DATE                  COMMENT '会员卡到期日',
  status       TINYINT      DEFAULT 1 COMMENT '状态 1 正常 2 冻结 3 过期 4 注销',
  remark       VARCHAR(255)          COMMENT '备注',
  deleted      TINYINT      DEFAULT 0 COMMENT '软删除标记',
  create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_phone_deleted (phone, deleted)
) COMMENT '会员档案';
```

🎯 **两个关键设计**：

- `avatar` **预留字段**：Day06 不做上传，先放 `""` 或前端默认头像 URL；Day07 讲文件上传后再启用。
- `UNIQUE KEY (phone, deleted)`：**软删除必须让唯一索引带上 `deleted`**，否则「删除后再注册同一手机号」会撞唯一约束。这是软删除设计的**头号铁律**。

### 4.3 三类查询条件的 SQL 写法对照

| 条件类型 | 例子 | SQL 片段 | Java 判空 |
|---|---|---|---|
| 模糊 `LIKE` | 姓名 / 手机号 | `AND name LIKE CONCAT('%', #{name}, '%')` | `name != null and name != ''` |
| 精确 `=` | 卡类型 / 状态 | `AND card_type = #{cardType}` | `cardType != null`（**不判空串**） |
| 区间「左闭右开」 | 加入日期 | `AND create_time >= #{begin} AND create_time < DATE_ADD(#{end}, INTERVAL 1 DAY)` | `begin != null` / `end != null` |

⚠️ **日期区间为什么「左闭右开」？**
如果直接 `<= #{end}`，`end='2026-07-16'` 会被解析为 `2026-07-16 00:00:00`，当天 12 点入会的会员**全部漏掉**。改成 `< '2026-07-17 00:00:00'`（即 `DATE_ADD(#{end}, INTERVAL 1 DAY)`），就把整个 7 月 16 号包进来了。这是**日期查询的头号铁律**。

### 4.4 参数对象 `MemberPageQuery`

```java
@Data
public class MemberPageQuery {
    private Integer page = 1;
    private Integer pageSize = 10;

    private String  name;        // 模糊
    private String  phone;       // 模糊
    private Integer cardType;    // 精确
    private Integer status;      // 精确

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate joinBegin; // 区间左

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate joinEnd;   // 区间右
}
```

💡 **`@DateTimeFormat` 只对 GET query 参数生效**（走 Spring 转换器）；如果是 JSON body，需要用 `@JsonFormat(pattern="yyyy-MM-dd")`（走 Jackson）。**两个注解，各自战场，别混用。**

### 4.5 Mapper XML：`<where>` 里 `deleted = 0` 必须置顶

```xml
<select id="list" resultType="com.yinxiang.entity.Member">
  SELECT id, name, phone, gender, id_card, avatar,
         card_type, card_expire, status, remark, create_time
  FROM tb_member
  <where>
    deleted = 0
    <if test="name != null and name != ''">
      AND name LIKE CONCAT('%', #{name}, '%')
    </if>
    <if test="phone != null and phone != ''">
      AND phone LIKE CONCAT('%', #{phone}, '%')
    </if>
    <if test="cardType != null">AND card_type = #{cardType}</if>
    <if test="status   != null">AND status    = #{status}</if>
    <if test="joinBegin != null">
      AND create_time &gt;= #{joinBegin}
    </if>
    <if test="joinEnd != null">
      AND create_time &lt; DATE_ADD(#{joinEnd}, INTERVAL 1 DAY)
    </if>
  </where>
  ORDER BY id DESC
</select>
```

🎯 **`deleted = 0` 三处必须**：
1. **每一条查询 SELECT** 都要带 `WHERE deleted = 0`；
2. **每一条唯一性校验** `existsByX` 都要带 `AND deleted = 0`；
3. **唯一索引**把 `deleted` 纳入（表结构层已经保证）。

任何一个漏掉，都会出现「查得到已删除数据」或「删除后无法再注册」的 bug。

### 4.6 VO 与状态文本翻译

前端渲染时希望直接拿到「正常 / 冻结 / 过期 / 注销」四个字，而不是 `1/2/3/4`。做法：VO 增加 `statusText`、`cardTypeText`、`genderText` 字段：

```java
@Data
public class MemberVO {
    private Long   id;
    private String name;
    private String phone;
    private Integer gender;
    private String  genderText;
    private String  avatar;
    private Integer cardType;
    private String  cardTypeText;
    private LocalDate cardExpire;
    private Integer status;
    private String  statusText;
    private LocalDateTime createTime;
}
```

```java
public class MemberConverter {

    public static MemberVO toVO(Member m) {
        MemberVO v = new MemberVO();
        BeanUtils.copyProperties(m, v);
        v.setGenderText   (genderText   (m.getGender()));
        v.setCardTypeText (cardTypeText (m.getCardType()));
        v.setStatusText   (statusText   (m.getStatus()));
        return v;
    }
    private static String statusText(Integer s) {
        return switch (s == null ? 0 : s) {
            case 1 -> "正常"; case 2 -> "冻结";
            case 3 -> "过期"; case 4 -> "注销";
            default -> "未知";
        };
    }
    // genderText / cardTypeText 类似
}
```

💡 **口诀**：**Entity 存 code、VO 加 label、前端只认字**。别让前端硬编码 `if (status === 2)`，改起来是灾难。

### 4.7 Service 组装分页 + VO 翻译

```java
public PageResult<MemberVO> page(MemberPageQuery q) {
    PageHelper.startPage(q.getPage(), q.getPageSize());
    List<Member> list = mapper.list(q);
    List<MemberVO> vos = list.stream().map(MemberConverter::toVO).toList();
    long total = new PageInfo<>(list).getTotal();
    return new PageResult<>(total, vos);
}
```

⚠️ **陷阱**：`new PageInfo<>(vos)` 是**错的** —— 必须传原始 `list`（Page 拦截器包过的对象），否则 `total` 会退化成 `vos.size()`。

### 4.8 Controller

```java
@RestController
@RequestMapping("/api/member")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService service;

    @GetMapping
    public Result<PageResult<MemberVO>> page(MemberPageQuery q) {
        return Result.success(service.page(q));
    }
}
```

联调：

```text
GET /api/member?page=1&pageSize=10&name=张&status=1
GET /api/member?joinBegin=2026-07-01&joinEnd=2026-07-16
GET /api/member?phone=138&cardType=3
```

### 4.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 已删除会员出现在列表 | `<where>` 里漏了 `deleted = 0` |
| 加入日期 = `2026-07-16` 的会员查不出来 | `<= #{end}` 写法只覆盖到 `00:00:00`，改成 `< DATE_ADD(end, INTERVAL 1 DAY)` |
| `joinBegin=2026/07/01` 报 400 | 前端传斜杠格式；`@DateTimeFormat(pattern="yyyy-MM-dd")` 只认连字符 |
| VO 里 `statusText` 全为 null | 忘了在 Converter 里 `setStatusText`；或 `switch` 忘处理 null |
| 模糊查 `_` 或 `%` 匹配到所有行 | `LIKE` 中 `_` 是通配符，需要 `ESCAPE '\\'` 或用 `REPLACE` 转义 |
| 分页 total 等于当前页记录数 | `new PageInfo<>(vos)` 传错了对象，改传 `list` |

### 4.10 练习/思考

1. 增加 `cardExpireBegin` / `cardExpireEnd` 两个入参，实现「会员卡到期日区间」查询。**注意** `card_expire` 类型是 `DATE`，日期比较写法不同（不需要 DATE_ADD）。
2. 用 AI 助手生成 50 条种子数据 SQL：真实感的姓名 + `13[3-9]` 手机号，随机分布到 4 种卡类型。测你的分页 + 多条件查询。
3. **思考**：如果状态字段将来扩展到 8 种，`switch` 里 `case 5..8` 一个个加，改动大。用**枚举**能怎么优雅解决？（预习：`MemberStatus` + `@EnumValue`，第 15 章 MyBatis-Plus 会讲）

---

## 第 5 讲：会员删除与新增（软删除 + 头像预留）

### 5.1 引入：删除的两种流派

删除数据有两种流派：

- **硬删除**：`DELETE FROM tb_member WHERE id = ?` —— 记录从表中消失，无法恢复；
- **软删除**：`UPDATE tb_member SET deleted = 1 WHERE id = ?` —— 记录还在，查询时用 `WHERE deleted = 0` 过滤掉。

会员、订单、支付相关的**主档数据必须软删除**：万一有会员反悔、财务对账翻旧账、老板要看历史留存，你能救回来。日志、临时表、缓存表这些**可硬删除**。

### 5.2 软删除 vs 硬删除对照

| 维度 | 软删除 | 硬删除 |
|---|---|---|
| 数据可恢复 | ✅ 改 `deleted=0` 即可 | ❌ 除非查备份 |
| 会计合规 | ✅ 保留历史 | 需要外部审计日志 |
| 查询语句 | 每条 SELECT 都加 `deleted=0` | 无额外条件 |
| 唯一约束 | 需把 `deleted` 纳入唯一键 | 无需 |
| 数据表体积 | 会持续膨胀，需定期归档 | 自然清理 |

### 5.3 软删除 SQL

```xml
<update id="softDeleteByIds">
  UPDATE tb_member
     SET deleted = 1,
         update_time = NOW()
   WHERE deleted = 0
     AND id IN
  <foreach collection="ids" item="id" open="(" separator="," close=")">
    #{id}
  </foreach>
</update>
```

🎯 **两点讲究**：

1. `WHERE deleted = 0` 加上，避免重复删除已删除的记录（虽然影响不大，但更严谨）；
2. `update_time = NOW()` 显式更新，方便审计（部分场景 MyBatis 自动填充失效时兜底）。

### 5.4 Controller：单删 + 批删共用一个 Service 方法

```java
@DeleteMapping("/{id}")
public Result<Void> delete(@PathVariable Long id) {
    service.delete(List.of(id));
    return Result.success();
}

@DeleteMapping
public Result<Void> deleteBatch(@RequestParam List<Long> ids) {
    service.delete(ids);
    return Result.success();
}
```

Service：

```java
public void delete(List<Long> ids) {
    if (ids == null || ids.isEmpty()) {
        throw new BizException("请至少选择一条记录");
    }
    int rows = mapper.softDeleteByIds(ids);
    if (rows == 0) throw new BizException("会员不存在或已删除");
}
```

💡 **接口复用**：单删 `List.of(id)` → 批删同一个方法，Service 层只维护一份逻辑。

### 5.5 新增会员：DTO + 手机号唯一 + 头像预留

```java
@Data
public class MemberDTO {
    private Long id;

    @NotBlank(message = "姓名不能为空")
    @Size(max = 50)
    private String name;

    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    @Min(0) @Max(2)
    private Integer gender;

    @Pattern(regexp = "^$|(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)",
             message = "身份证号格式不正确")
    private String idCard;

    private String avatar;                              // Day06 预留，前端可传空串

    @NotNull @Min(1) @Max(4)
    private Integer cardType;

    @NotNull
    private LocalDate cardExpire;

    private Integer status;                             // 新增时可留空，Service 默认置 1

    @Size(max = 255)
    private String remark;
}
```

🎯 **头像字段的处理策略**：Day06 前端可传空串或默认头像 URL；Day07 讲文件上传时切换为「先调 `POST /api/upload` 拿到 URL、再把 URL 塞进 `avatar` 字段」。**表结构不改**，只改前端交互。

### 5.6 Service：手机号唯一性 + 软删除感知

```java
public void save(MemberDTO dto) {
    if (mapper.existsByPhone(dto.getPhone(), null) > 0) {
        throw new BizException("手机号已被注册");
    }
    Member m = new Member();
    BeanUtils.copyProperties(dto, m);
    if (m.getStatus() == null) m.setStatus(1);
    mapper.insert(m);
}
```

```xml
<select id="existsByPhone" resultType="int">
  SELECT COUNT(*) FROM tb_member
  WHERE phone = #{phone} AND deleted = 0
  <if test="excludeId != null">
    AND id &lt;&gt; #{excludeId}
  </if>
</select>
```

⚠️ **必须** `AND deleted = 0`：否则「删除后重新用同一手机号注册」会被判为「已注册」，业务瘫痪。

### 5.7 手机号正则 `^1[3-9]\d{9}$` 拆解

```
^  1  [3-9]  \d{9}  $
│  │  │      │      │
│  │  │      │      └── 结尾
│  │  │      └── 后 9 位数字
│  │  └── 第 2 位 3~9（覆盖 130~199 号段）
│  └── 首位 1
└── 开头
```

💡 **口诀**：**一 三到九 九位数**（1 + [3-9] + 9 位数字 = 11 位）。

### 5.8 Controller

```java
@PostMapping
public Result<Void> save(@RequestBody @Valid MemberDTO dto) {
    service.save(dto);
    return Result.success();
}
```

联调剧本：

```text
POST /api/member    body: {"name":"张小雅","phone":"13800138001","cardType":1,"cardExpire":"2027-07-16"}
POST /api/member    再来一次相同手机号 → 期望 "手机号已被注册"
DELETE /api/member/1
POST /api/member    再次用 13800138001 注册 → 期望成功（软删除已让唯一索引带 deleted）
```

### 5.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 删除后无法再注册同一手机号 | 唯一索引没带 `deleted`，改 `UNIQUE KEY (phone, deleted)` |
| `existsByPhone` 查到已删除的记录 | `<select>` 里漏了 `AND deleted = 0` |
| 手机号正则通过了 `1234567890` | 正则漏了首位 1；用 `^1[3-9]\d{9}$` |
| `@Valid` 通过但 `avatar` 传了 5000 字符长的 base64 | DTO 里给 `avatar` 加 `@Size(max = 255)` 或走文件上传接口 |
| 新增时 `cardExpire` 传 `2027/07/16` 报 400 | `LocalDate` 需 ISO 格式，前端统一用 `yyyy-MM-dd` |

### 5.10 练习/思考

1. 用 AI 助手生成 20 条新增会员的 Postman 用例（真实姓名 + 真实号段），跑一遍看有几条被「重复手机号」拦下来。
2. 增加 `POST /api/member/{id}/restore` 接口：把 `deleted=1` 改回 `0`，作为「误删恢复」入口。**思考**：恢复时需要重新做手机号唯一性校验吗？为什么？
3. **思考**：应用层 `existsByPhone` + 数据库唯一索引，两道防线，能否只留其中一道？各自的意义是什么？

---

## 第 6 讲：会员修改（回显 + 提交）+ 业务层重构与异常处理改造

### 6.1 引入：修改 = 详情 + 更新

修改本质是 `UPDATE`，但**必须先做一次「详情查询」把最新数据回填给前端**，否则容易出现「A 用户在编辑，B 已经改了并保存，A 提交时覆盖 B 的改动」的 Last Write Wins 问题。所以修改功能实际上是**两个接口协作**：`GET /api/member/{id}` 回显 + `PUT /api/member` 提交。

### 6.2 详情接口 `GET /api/member/{id}`

```java
@GetMapping("/{id}")
public Result<MemberVO> getById(@PathVariable Long id) {
    return Result.success(service.getVO(id));
}
```

Service：

```java
public MemberVO getVO(Long id) {
    Member m = mapper.getById(id);
    if (m == null || m.getDeleted() == 1) {
        throw new BizException("会员不存在或已删除");
    }
    return MemberConverter.toVO(m);
}
```

Mapper XML：

```xml
<select id="getById" resultType="com.yinxiang.entity.Member">
  SELECT id, name, phone, gender, id_card, avatar,
         card_type, card_expire, status, remark, deleted, create_time, update_time
  FROM tb_member
  WHERE id = #{id}
</select>
```

💡 **注意**：详情查询**允许**查出 `deleted=1` 的记录（Service 里判掉），因为将来「恢复删除」功能可能需要看到已删除的数据。

### 6.3 修改接口 `PUT /api/member`

```java
@PutMapping
public Result<Void> update(@RequestBody @Valid MemberDTO dto) {
    service.update(dto);
    return Result.success();
}
```

Service：

```java
public void update(MemberDTO dto) {
    if (dto.getId() == null) throw new BizException("id 不能为空");
    if (mapper.existsByPhone(dto.getPhone(), dto.getId()) > 0) {
        throw new BizException("手机号已被其它会员占用");
    }
    Member m = new Member();
    BeanUtils.copyProperties(dto, m);
    int rows = mapper.update(m);
    if (rows == 0) throw new BizException("会员不存在或已删除");
}
```

🎯 **修改流程 4 步**：

1. **入参校验**：`@Valid` 拦格式，`id != null` 拦业务；
2. **唯一性校验**：`existsByPhone(phone, id)` 排除自己；
3. **执行 UPDATE**：`<set>` + `<if>` 动态更新，null 字段不覆盖；
4. **影响行数校验**：`rows == 0` 说明 id 不存在 / 已软删除。

### 6.4 Mapper `<update>`：null 不覆盖

```xml
<update id="update">
  UPDATE tb_member
  <set>
    <if test="name        != null">name         = #{name},</if>
    <if test="phone       != null">phone        = #{phone},</if>
    <if test="gender      != null">gender       = #{gender},</if>
    <if test="idCard      != null">id_card      = #{idCard},</if>
    <if test="avatar      != null">avatar       = #{avatar},</if>
    <if test="cardType    != null">card_type    = #{cardType},</if>
    <if test="cardExpire  != null">card_expire  = #{cardExpire},</if>
    <if test="status      != null">status       = #{status},</if>
    <if test="remark      != null">remark       = #{remark},</if>
  </set>
  WHERE id = #{id} AND deleted = 0
</update>
```

⚠️ **两处铁律**：

1. `<set>` 里每行末尾都写 `,`，`<set>` 会自动吃掉多余的逗号；
2. **`WHERE id = #{id}` 一秒也不能忘**，`<set>` 后没 `WHERE` 就是全表更新，事故等级 P0。

### 6.5 业务层重构：抽象 `existsByX(value, excludeId)` 通用签名

第 3 讲的 `existsByName(name, excludeId)` + 第 5 讲的 `existsByPhone(phone, excludeId)`，模式完全一样。规范做法：

```java
// Mapper 接口签名对齐
int existsByName (@Param("name")  String name,  @Param("excludeId") Long excludeId);
int existsByPhone(@Param("phone") String phone, @Param("excludeId") Long excludeId);

// Service 里做 assert 私有方法收敛
private void assertPhoneNotExists(String phone, Long excludeId) {
    if (mapper.existsByPhone(phone, excludeId) > 0) {
        throw new BizException("手机号已被其它会员占用");
    }
}
```

🎯 **规范收益**：任何时候要加「唯一性校验」，直接照这个签名写；将来上 MyBatis-Plus 或换 ORM 也不用改上层。

### 6.6 异常处理改造预告

现在抛 `BizException` 会直接返回 HTTP 500，前端看到的响应体很难看：

```json
{"timestamp":"...","status":500,"error":"Internal Server Error","message":"手机号已被注册"}
```

第 13 章会做**全局异常处理器** `@RestControllerAdvice`：

```java
@ExceptionHandler(BizException.class)
public Result<?> handle(BizException e) {
    return Result.fail(e.getMessage());
}

@ExceptionHandler(MethodArgumentNotValidException.class)
public Result<?> handle(MethodArgumentNotValidException e) {
    String msg = e.getBindingResult().getFieldErrors().stream()
                   .map(f -> f.getField() + ": " + f.getDefaultMessage())
                   .collect(Collectors.joining("; "));
    return Result.fail(msg);
}
```

改造后所有业务异常统一为：

```json
{"code": 500, "msg": "手机号已被注册", "data": null}
```

**Day06 里为了跑通链路暂时保留原样**，第 13 章统一切换。

### 6.7 三层校验总结

| 层级 | 位置 | 触发 | 例子 |
|---|---|---|---|
| **格式校验** | Controller `@Valid` | JSON 字段不合规 | `name` 空、`phone` 不是 11 位数字 |
| **业务校验** | Service 抛 `BizException` | 数据规则不合规 | 手机号已注册、id 不存在 |
| **落库校验** | Mapper 影响行数 + DB 约束 | 并发写冲突、外键 | 唯一索引撞车、`rows == 0` 说明记录已删 |

💡 **口诀**：**格式挡在门口、业务收在中厅、落库兜在底楼**，三道防线一道都不能少。

### 6.8 Day06 全链路联调剧本

```text
# 课程科目
POST   /api/category    {"name":"高温瑜伽","intro":"38°C","level":2}
POST   /api/category    再来一次相同名 → "科目名称已存在"
GET    /api/category?page=1&pageSize=5&name=瑜伽
PUT    /api/category    {"id":5,"name":"高温瑜伽-进阶","level":3}
DELETE /api/category?ids=4,5

# 会员
POST   /api/member      {"name":"张小雅","phone":"13800138001","cardType":1,"cardExpire":"2027-07-16"}
POST   /api/member      再来一次相同手机号 → "手机号已被注册"
GET    /api/member?page=1&pageSize=10&name=张
GET    /api/member?joinBegin=2026-07-01&joinEnd=2026-07-16
GET    /api/member/1
PUT    /api/member      {"id":1,"name":"张小雅","phone":"13900139000","cardType":3,"cardExpire":"2028-07-16"}
DELETE /api/member/1
GET    /api/member      列表看不到 id=1
POST   /api/member      再次用 13800138001 注册 → 期望成功（软删除已让唯一索引带 deleted）
```

### 6.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 修改时 `status=null` 把状态覆盖成 null | `BeanUtils.copyProperties` 浅拷贝会把 null 传下去；用 `<set>` + `<if>` 让 null 不出现在 SQL |
| `PUT /api/member` 没传 `id` 也执行了全表 UPDATE | Service 第一行 `if (dto.getId() == null) throw ...`；SQL 加 `WHERE id = #{id} AND deleted = 0` |
| 修改后立刻查详情看不到新值 | 前端拿旧数据缓存了；后端已经落库，让前端刷一次 |
| `getById` 返回了 `deleted=1` 的记录，前端渲染成正常 | Service 里判断软删除标记 → 抛业务异常 |
| 手机号改成别人的仍然通过 | `existsByPhone` 忘传 `excludeId=dto.getId()`，只校验了非自己 |
| `BizException` 返回 500 前端体验差 | 第 13 章全局异常处理器，Day06 内忍一忍 |

### 6.10 练习/思考

1. 给 `getById` + `update` 组合场景加乐观锁：表增加 `version` 字段，修改时 `WHERE id=? AND version=?`；`rows==0` 时提示「数据已被他人修改，请刷新后再试」。
2. 在 IDEA 里用通义灵码生成一份 Postman Collection JSON（含 Day06 全部接口 + 断言），导入 Postman 一键跑通全链路。
3. **思考**：Day06 的 6 个功能里，哪些**必须**加 `@Transactional`？如果只用 `INSERT` / `UPDATE` 单表操作，事务真的必要吗？（提示：读一次 exists + 写一次 insert 之间会不会插进来别人的记录 → 幂等 vs 并发）

---

## 附录 A：Day06 关键口诀速查

- **分页四件套**：参数对象 → `PageHelper.startPage` → mapper 查询 → `PageInfo` 组装。
- **动态 SQL 三剑客**：`<where>` 吃 AND、`<set>` 吃逗号、`<foreach>` 拼 IN。
- **唯一性校验**：`existsByX(value, excludeId)`；新增传 `null`，修改传自己的 id。
- **软删除三件套**：唯一索引带 `deleted` + 每条 SELECT 加 `deleted=0` + `existsByX` 加 `deleted=0`。
- **日期区间**：左闭右开，`>= begin AND < DATE_ADD(end, INTERVAL 1 DAY)`。
- **修改闭环**：先 GET 回显、再 PUT 提交，`WHERE id = #{id}` 一秒也不能少。
- **三层校验**：格式（`@Valid`）→ 业务（`BizException`）→ 落库（影响行数 + DB 约束）。

## 附录 B：Day06 常见问题速答

| 问题 | 回答 |
|---|---|
| PageHelper 分页失效 | 检查 `PageHelper.startPage` 与目标 select 之间有没有夹别的 SQL |
| `?ids=` 收不到 | 前端 axios 用 `params.ids = [1,2,3].join(',')`，或改用 URLSearchParams 的多值格式 |
| 删除后再注册报冲突 | 唯一索引没带 `deleted`，改 `UNIQUE (phone, deleted)` |
| 日期区间漏最后一天 | 改成左闭右开 `< DATE_ADD(end, INTERVAL 1 DAY)` |
| `@Valid` 不生效 | Controller 参数漏了 `@RequestBody`，或没引 `spring-boot-starter-validation` |
| 修改 status 传 null 被覆盖 | `BeanUtils.copyProperties` 浅拷贝会传 null；用 `<set>` + `<if>` 动态更新 |
| VO 里 `statusText` 全为 null | 忘了在 Converter 里 `setStatusText`；或 `switch` 未处理 null |
| 分页 total 等于当前页记录数 | `new PageInfo<>(vos)` 传错了对象，改传 `list`（PageHelper 包装后的原始集合） |

## 附录 C：AI 辅助提示词模板

对通义灵码 / Trae 直接抛以下提示词，可一次性拿到 Day06 全部脚手架代码：

```text
我在写基于 Spring Boot 4.0.x + MyBatis 3.5+ + PageHelper 6.1+ 的印想瑜伽会馆项目。请分别为「课程科目 tb_category」和「会员 tb_member」生成完整 CRUD 代码：

【tb_category】字段：id / name(UNIQUE) / intro / level / status / create_time / update_time。
接口：GET /api/category（分页 + 名称模糊 + 状态精确）、POST、PUT、DELETE /api/category?ids=、DELETE /api/category/{id}。

【tb_member】字段：id / name / phone / gender / id_card / avatar / card_type / card_expire / status / remark / deleted / create_time / update_time；UNIQUE KEY (phone, deleted)。
接口：GET /api/member（分页 + name/phone 模糊 + cardType/status 精确 + joinBegin/joinEnd 区间）、GET /api/member/{id}、POST、PUT、DELETE /api/member/{id}（软删除）、DELETE /api/member?ids=（软删除）。

代码规范：
1. Lombok + @RequiredArgsConstructor 构造器注入；
2. 分页返回 PageResult<T>{total, rows}；
3. 统一响应 Result<T>{code, msg, data}；
4. 业务异常抛 BizException；
5. DTO 用 Bean Validation 注解；
6. Mapper 用 XML，动态 SQL 用 <where> <set> <foreach>；
7. 软删除：每条 SELECT 加 deleted=0；existsByPhone 也要加 deleted=0；
8. 日期区间左闭右开 < DATE_ADD(end, INTERVAL 1 DAY)；
9. MemberVO 增加 genderText / cardTypeText / statusText 翻译字段。

要求：一次性输出 Entity / DTO / VO / Mapper 接口 / Mapper XML / Service / Controller，并附 Postman 用例。
```

**收到 AI 输出后必须审查**：

1. `<where>` 是否把 `deleted = 0` 放在最前？
2. 日期区间是否**左闭右开**？
3. 唯一性校验是否传了 `excludeId`？
4. VO 是否翻译了 `xxxText` 字段？
5. 软删除是否只更新 `deleted=1` 而不动其它字段？
6. 分页返回是否包含 `total` 与 `rows`？
7. `PageHelper.startPage` 与目标 select 之间是否夹了别的 SQL？
8. `<set>` 各行末尾是否有逗号？`WHERE id = #{id}` 有没有丢？

不满足的地方，**直接对话继续追问**：「上面代码中 `<where>` 未包含软删除条件，请修正」。这就是 AI 协作的**迭代式细化**，也是提示词工程的核心动作。

---

**Day06 学生讲义完**
