# 《AI 应用 Web 开发》 - 学生讲义（Day13：会员管理前端页面 + AI 编写前端页面与布局）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day12 的学生（掌握 Spring Boot 4.0.x 后端全栈、Vue 3.4 + Vite + TypeScript 工程化、Pinia 状态管理、Axios 请求实例、Element Plus 3 组件库；Day12 已抽出 `PageContainer / SearchBar / ProTable` 三大通用组件、`/utils/dict.ts` 字典与 `handleErr` 错误处理）**

**技术版本基线**：Vue 3.4 / Vite 5.x / TypeScript 5.x / Element Plus 3 / Pinia 2 / Axios 1.7 / unplugin-auto-import / IDEA 2024.3+ / VS Code + 通义灵码 + Trae + Cursor。前端项目名 `yoga-admin`。

**课程主线项目**：印想瑜伽会馆管理系统（`yoga-admin`）。Day12 我们已经把项目跑起来、路由与登录跑通、通用组件抽出并入库，今天要把它们真正用到第一个业务模块——「会员管理」的完整前端页面。前 3 讲把「列表 + 弹窗 + 抽屉 + 删除」这一整套「后台管理页面标准范式」跑通；中间 1 讲切换赛道，从「手写」跳到「AI 生成」，用通义灵码 / Trae 一次性生成第二个业务模块（教练管理）的三件套；最后 2 讲抬升视角看布局层——把顶栏、侧栏 Menu、面包屑这套后台通用外壳搭起来，并复盘「页面拆分」的取舍。跑完 Day13，`yoga-admin` 具备「一个完整业务模块 + 一份可复用的 AI 生成流程 + 一套完整后台外壳」，从下一天开始，任意新业务模块的前端交付可以从「1 天」压缩到「1 小时」。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 会员列表页 —— Table + 分页 + 搜索栏 | `MemberListView.vue` 骨架 + `memberApi` 7 方法 + `joinRange` 桥接 + `sortable="custom"` 后端排序 |
| 第 2 讲 | 会员新增 / 修改页 —— Form + 校验 + Dialog | `MemberFormDialog.vue` + `defineExpose({ open })` + `FormRules` 5 类规则 + `@closed` reset |
| 第 3 讲 | 会员删除 + 批量删除 + 冻结解冻 | `ElMessageBox.confirm` 两路径 + `selected` 空选禁用 + `remove(ids)` 统一 API + 冻结解冻切换 |
| 第 4 讲 | AI 编写前端页面流程 —— Prompt → 生成 → 验收 | Prompt 六要素 + 四段式验收 + 迭代 3 点 + `docs/PROMPTS.md` 沉淀 |
| 第 5 讲 | 后台通用布局 —— 顶栏 + 侧栏 Menu + 面包屑 | `Layout / Header / Sidebar / Breadcrumb` 四组件 + 路由 meta 单一数据源 + 折叠持久化 |
| 第 6 讲 | 页面拆分与子组件抽取 —— Props / Emit / defineExpose | 三种交互契约 + `v-model` 语法糖本质 + Rule of Three + `MemberListView` 重构 |

---

## 第 1 讲：会员列表页 —— Table + 分页 + 搜索栏

### 1.1 引入：从「一句 h2」到「一套后台标准列表页」

Day12 我们把 `yoga-admin` 侧边栏加上了「会员管理」入口，点进去只有一个 `<h2>会员管理</h2>`——空白页。今天要把它真正变成一个可用的业务模块。

一个成熟的后台列表页拆开看有 5 类元素：

1. 顶部操作栏：新增、批量删除、导出
2. 搜索栏：姓名、手机号、状态、入会时段
3. 数据表：分页、多选、排序
4. 右侧操作列：编辑、详情、冻结、删除
5. 弹窗与抽屉：新增 / 编辑用 Dialog，详情用 Drawer

灵魂问题一句：**为什么要区分 Dialog、Drawer 和独立路由？**——字段少（< 10 个）且无联动用 Dialog；需要展示子列表（会员卡、消费记录）用 Drawer；表单巨大 + 分步流程用独立路由页。破坏性操作（删除、冻结）一律走 `MessageBox.confirm` 二次确认——这是工程规约。

🎯 **一句话目标**：**`PageContainer + SearchBar + ProTable` 三件套 + `q` 响应式 = 后台列表页标准范式**，今天先把「列表 + 分页 + 搜索」的壳跑起来。

### 1.2 类型定义与 API 层

打开 `src/api/member.ts`，Day12 只有 `page` 一个方法，今天补齐 `detail / create / update / remove / freeze / unfreeze` 共 7 个方法：

```ts
// src/api/member.ts
import request from './request'
import type { PageResult } from './types'

export interface MemberVO {
  id: number
  name: string
  phone: string
  gender: 0 | 1 | 2
  birthday?: string
  cardType: number    // 1 次卡 2 月卡 3 年卡
  status: 1 | 2       // 1 正常 2 冻结
  joinTime: string
  remark?: string
}

export interface MemberQuery {
  name?: string
  phone?: string
  status?: number
  joinBegin?: string
  joinEnd?: string
  pageNum: number
  pageSize: number
  sortBy?: string
  sortDir?: string
}

export interface MemberFormDTO {
  id?: number
  name: string
  phone: string
  gender: 0 | 1 | 2
  birthday?: string
  cardType: number
  status?: 1 | 2
  remark?: string
}

export const memberApi = {
  page:     (q: MemberQuery)     => request.get<any, PageResult<MemberVO>>('/members', { params: q }),
  detail:   (id: number)         => request.get<any, MemberVO>(`/members/${id}`),
  create:   (dto: MemberFormDTO) => request.post<any, number>('/members', dto),
  update:   (dto: MemberFormDTO) => request.put<any, void>('/members', dto),
  freeze:   (id: number)         => request.post<any, void>(`/members/${id}/freeze`),
  unfreeze: (id: number)         => request.post<any, void>(`/members/${id}/unfreeze`),
  remove:   (ids: number[])      => request.delete<any, void>('/members', { data: ids }),
}
```

`src/api/types.ts` 里的 `PageResult<T>` 是全项目分页返回的标准结构：

```ts
export interface PageResult<T> {
  total: number
  records: T[]
}
```

关键点说明：

- **`request` 泛型第二参数**：`request.get<any, PageResult<MemberVO>>(...)`——Axios 响应拦截器已经解包（第 24 章讲过），所以第二个泛型就是最终业务数据类型。
- **`remove` 传 `number[]` 而非单个 `number`**：单删就是数组长度为 1 的批量删——统一 API 表达面。前后端约定：批量 DELETE 走 `body: number[]`。
- **`update` 参数含 `id`**：把 `id` 放进 DTO 而不是走 URL 路径，是本项目后端约定的写法，跟 Day09-Day12 的接口对齐。

### 1.3 `MemberListView.vue` 骨架

新建 `src/views/member/MemberListView.vue`：

```vue
<!-- src/views/member/MemberListView.vue -->
<template>
  <PageContainer title="会员管理">
    <template #actions>
      <el-button type="primary" @click="onAdd">
        <el-icon><Plus/></el-icon>新增会员
      </el-button>
      <el-button type="danger" plain :disabled="!selected.length" @click="onBatchDelete">
        <el-icon><Delete/></el-icon>批量删除
      </el-button>
      <el-button plain @click="onExport">
        <el-icon><Download/></el-icon>导出
      </el-button>
    </template>

    <SearchBar :model="q" @search="tableRef?.resetToFirst()" @reset="tableRef?.resetToFirst()">
      <el-form-item label="姓名">
        <el-input v-model="q.name" placeholder="姓名" clearable/>
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="q.phone" placeholder="11 位手机号" clearable/>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="q.status" clearable placeholder="全部" style="width:120px">
          <el-option label="正常" :value="1"/>
          <el-option label="冻结" :value="2"/>
        </el-select>
      </el-form-item>
      <el-form-item label="入会时间">
        <el-date-picker v-model="joinRange" type="daterange"
          value-format="YYYY-MM-DD" range-separator="-"
          start-placeholder="开始" end-placeholder="结束"
          style="width:230px"/>
      </el-form-item>
    </SearchBar>

    <ProTable ref="tableRef" :loader="memberApi.page" :query="q"
              @selection-change="v => selected = v"
              @sort-change="onSort">
      <el-table-column type="selection" width="42"/>
      <el-table-column prop="name"   label="姓名"   min-width="90"/>
      <el-table-column prop="phone"  label="手机号" width="130"/>
      <el-table-column label="性别" width="60">
        <template #default="{ row }">{{ GENDER[row.gender] }}</template>
      </el-table-column>
      <el-table-column prop="birthday" label="生日" width="110"/>
      <el-table-column label="会员卡" width="90">
        <template #default="{ row }">{{ CARD_TYPE[row.cardType] }}</template>
      </el-table-column>
      <el-table-column label="状态" width="80">
        <template #default="{ row }">
          <el-tag :type="MEMBER_STATUS[row.status].type">
            {{ MEMBER_STATUS[row.status].label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="joinTime" label="入会时间" width="160" sortable="custom"/>
      <el-table-column label="操作" width="240" fixed="right">
        <template #default="{ row }">
          <el-button size="small" link @click="onDetail(row)">详情</el-button>
          <el-button size="small" link type="primary" @click="onEdit(row)">编辑</el-button>
          <el-button size="small" link :type="row.status === 1 ? 'warning' : 'success'"
                     @click="onToggleFreeze(row)">
            {{ row.status === 1 ? '冻结' : '解冻' }}
          </el-button>
          <el-button size="small" link type="danger" @click="onDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </ProTable>

    <MemberFormDialog ref="dialogRef" @saved="tableRef?.refresh()"/>
    <MemberDetailDrawer ref="drawerRef"/>
  </PageContainer>
</template>

<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { memberApi, type MemberVO } from '@/api/member'
import { GENDER, MEMBER_STATUS } from '@/utils/dict'
import { toastErr } from '@/utils/handleErr'
import MemberFormDialog   from './MemberFormDialog.vue'
import MemberDetailDrawer from './MemberDetailDrawer.vue'

const CARD_TYPE: Record<number, string> = { 1: '次卡', 2: '月卡', 3: '年卡' }

const q = reactive<{
  name?: string; phone?: string; status?: number
  joinBegin?: string; joinEnd?: string
  pageNum: number; pageSize: number
  sortBy?: string; sortDir?: string
}>({ pageNum: 1, pageSize: 10 })

const joinRange = ref<string[]>()
watch(joinRange, v => { q.joinBegin = v?.[0]; q.joinEnd = v?.[1] })

const tableRef  = ref<InstanceType<typeof import('@/components/ProTable.vue').default>>()
const dialogRef = ref<InstanceType<typeof MemberFormDialog>>()
const drawerRef = ref<InstanceType<typeof MemberDetailDrawer>>()

const selected = ref<MemberVO[]>([])

function onAdd()                 { dialogRef.value?.open() }
function onEdit(row: MemberVO)   { dialogRef.value?.open(row.id) }
function onDetail(row: MemberVO) { drawerRef.value?.open(row.id) }
function onSort({ prop, order }: { prop: string; order: 'ascending' | 'descending' | null }) {
  q.sortBy  = order ? prop : undefined
  q.sortDir = order === 'ascending' ? 'asc' : order === 'descending' ? 'desc' : undefined
  tableRef.value?.refresh()
}

// 以下 3 个方法留到第 3 讲实现
function onDelete(_row: MemberVO)  { /* TODO 第 3 讲 */ }
function onBatchDelete()           { /* TODO 第 3 讲 */ }
function onToggleFreeze(_row: MemberVO) { /* TODO 第 3 讲 */ }
function onExport() { ElMessage.info('导出功能：请参考第 3 讲课后练习') }
</script>
```

### 1.4 三个组件契约再确认

Day12 抽出的三个通用组件今天正式服役，把契约再次固化到肌肉记忆里：

- **`PageContainer`**：提供 `title` prop 与 `#actions` 具名插槽——顶部按钮组固定放这里。
- **`SearchBar`**：`:model` prop 绑响应式对象、`@search / @reset` 事件由内部「查询 / 重置」按钮 emit——**它不管刷新，只 emit**，刷新由父组件里 `tableRef?.resetToFirst()` 完成。
- **`ProTable`**：`:loader` 是函数引用（`memberApi.page`）、`:query` 是响应式 `q`；内部通过 `defineExpose({ refresh, resetToFirst })` 把两个方法暴露给父。

**关键语义差异**：`resetToFirst()` 会把 `pageNum` 重置为 1 再拉，`refresh()` 保留当前分页拉——**查询按钮触发 `resetToFirst`**（换了搜索条件，从第一页看），删除后触发 `refresh`（保留在当前页，看新数据）。

### 1.5 表格列的两种渲染模式

`<el-table-column>` 有两种模式，学会切换：

- **`prop` 直取字段**：`<el-table-column prop="phone" label="手机号"/>`——单元格显示 `row.phone`。
- **`#default="{ row }"` 插槽**：需要字典映射、tag 着色、组合按钮时用。上面代码里「性别、会员卡、状态、操作」四列都是插槽模式。

**列宽经验值（团队约定）**：姓名 90 / 手机号 130 / 性别 60 / 生日 110 / 会员卡 90 / 状态 80 / 入会时间 160 / 操作 240。这份数字在教练管理、课程管理里也复用——第 4 讲 AI 生成时会用到「风格一致」这一段。

### 1.6 后端排序 vs 前端排序

`<el-table-column sortable="custom">` 和 `<el-table-column sortable>` 长得像，行为差了一大截：

| 写法 | 触发时机 | 数据来源 | 翻页后 |
|---|---|---|---|
| `sortable` | 点击列头 | 当前页数据在**前端**排 | **丢失**排序（下一页是新拉的） |
| `sortable="custom"` | 点击列头 | 派发 `sort-change` 事件给外部 | 保留（外部把 `sortBy/sortDir` 塞进 `q` 再拉） |

**结论**：**后端分页 + 排序 = `sortable="custom"` + `sort-change` 事件回传 query**——本项目所有可排序列一律 `custom`。

### 1.7 字典配置

在 `src/utils/dict.ts` 里补齐今天要用的两个字典：

```ts
// src/utils/dict.ts
export const GENDER: Record<number, string> = {
  0: '保密',
  1: '男',
  2: '女',
}

export const MEMBER_STATUS: Record<number, { label: string; type: 'success' | 'warning' }> = {
  1: { label: '正常', type: 'success' },
  2: { label: '冻结', type: 'warning' },
}
```

**为什么字典要集中管理**：会员管理、教练管理、订单管理都要用「性别、状态」这类枚举——集中在一份 `dict.ts` 让所有页面共享同一套映射，改文案只改一处；散在各个页面则会造成「同一个 0 值有的地方叫『男』、有的地方叫『保密』」这种历史祖传 bug。

### 1.8 联调剧本

1. 前端 `pnpm dev` 起 Vite；后端 `yoga-member` 起 Spring Boot。
2. 浏览器打开 `http://localhost:5173/members`——首次进入应显示表头 + 分页组件 +「暂无数据」（库里还没会员）。
3. 用 Postman 或 Navicat 手动插 3 条会员，刷新页面——列表出现 3 行。
4. 把 `pageSize` 临时改成 2，观察分页组件的「下一页」按钮变亮，翻页拉新数据。
5. 输入「张」+ 状态「正常」+ 入会时段——点查询，列表按条件过滤（Network 面板确认请求参数带上了 `name / status / joinBegin / joinEnd`）。
6. 点「入会时间」列头——观察 Network 里请求携带 `sortBy=joinTime&sortDir=asc/desc`。

### 1.9 常见坑

| 症状 | 原因 | 修法 |
|---|---|---|
| 后端 `joinBegin` 永远收到 `undefined` | 忘了写 `watch(joinRange, ...)` 桥接 | 加上 watch，或直接把 `SearchBar` 里 `v-model="joinRange"` 改成 computed 双向 |
| 列头点了本页排了序，翻页丢失 | 写成 `sortable` 而非 `sortable="custom"` | 改成 `sortable="custom"` + 监听 `@sort-change` |
| 勾选列宽被挤压不见 | 忘了给 `type="selection"` 加 `width="42"` | 显式写宽度 |
| Network 分页字段名对不上 | 后端老项目叫 `page / size`，前端叫 `pageNum / pageSize` | 提前对齐命名，或在 `request` 拦截器里做别名映射 |
| `ProTable` 不会自动刷新 | `q` 内部字段变但引用没变，`props.query` watch 不到 | 本项目采用显式 `resetToFirst()` 调用，不做 deep watch |

### 1.10 练习

1. **必做**：完成 `MemberListView.vue` 的骨架，实现「姓名 + 手机号 + 状态 + 入会时段」四字段搜索、分页翻页、按入会时间后端排序。交 4 张截图（空数据 / 有数据 / 分页翻页 / 排序切换）。
2. **必做**：补齐 `src/utils/dict.ts` 里的 `GENDER / MEMBER_STATUS / CARD_TYPE` 三个字典，并把主页里的 `CARD_TYPE` 局部常量迁移到统一字典。
3. **挑战**：给列表增加「快速搜索」输入框——用 `@vueuse/core` 的 `useDebounceFn`，300ms 防抖直接触发 `tableRef?.resetToFirst()`，不占用 `SearchBar` 的位置。

---

## 第 2 讲：会员新增 / 修改页 —— Form + 校验 + Dialog

### 2.1 引入：让空列表能被写入

第 1 讲跑完，列表页可以查、可以分页、可以排序——但**只读**。学生点「新增会员」按钮，控制台报 `Cannot read properties of undefined (reading 'open')`——因为 `MemberFormDialog` 组件还没写。

一个「新增 + 编辑」复用的弹窗，父子之间最少要约定几个契约？

```
父 --ref.open(id?)--> 子（弹窗）
子 --emit('saved')--> 父（列表刷新）
```

就这两个。父组件通过 `ref` 拿到子组件实例、调 `open(id?)`：不传 `id` 是新增，传 `id` 是编辑；子组件保存成功后 emit `saved`，父组件 refresh 列表。

🎯 **一句话目标**：**一份 Dialog 组件同时支持「新增」与「编辑」，父组件只通过 `open(id?)` 一个 API 交互；关闭动画结束才 reset**。

### 2.2 `FormRules<T>` 与 5 类校验规则

`FormRules<MemberFormDTO>` 泛型会约束**规则的 key 必须是 `MemberFormDTO` 的字段名**——写错字段名 TypeScript 直接报错。常用规则有 5 类：

| 类型 | 举例 | 用途 |
|---|---|---|
| `required` | `{ required: true, message: '请输入姓名', trigger: 'blur' }` | 必填 |
| `min / max` | `{ min: 2, max: 20, message: '2~20 字符' }` | 长度 |
| `pattern` | `{ pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确' }` | 正则 |
| `type` | `{ type: 'email', message: '邮箱格式' }` | 内置类型（email / number / date …） |
| `validator` | 见下面「至少选一项」示例 | 自定义函数 |

**`trigger` 两个取值**：`'blur'`（离焦）用于文本输入，`'change'`（值变化）用于 select / radio / checkbox。

### 2.3 `MemberFormDialog.vue` 完整代码

```vue
<!-- src/views/member/MemberFormDialog.vue -->
<template>
  <el-dialog v-model="visible" :title="isEdit ? '编辑会员' : '新增会员'"
             width="520" @closed="reset">
    <el-form ref="formRef" :model="form" :rules="rules"
             label-width="90px" label-position="right">
      <el-form-item label="姓名" prop="name">
        <el-input v-model="form.name" placeholder="真实姓名" maxlength="20" show-word-limit/>
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="form.phone" placeholder="11 位手机号"
                  :disabled="isEdit" maxlength="11"/>
      </el-form-item>
      <el-form-item label="性别" prop="gender">
        <el-radio-group v-model="form.gender">
          <el-radio :value="1">男</el-radio>
          <el-radio :value="2">女</el-radio>
          <el-radio :value="0">保密</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="生日" prop="birthday">
        <el-date-picker v-model="form.birthday" type="date" value-format="YYYY-MM-DD"
                        placeholder="选择日期" style="width:100%"
                        :disabled-date="(d: Date) => d > new Date()"/>
      </el-form-item>
      <el-form-item label="会员卡" prop="cardType">
        <el-select v-model="form.cardType" placeholder="选择会员卡" style="width:100%">
          <el-option label="次卡" :value="1"/>
          <el-option label="月卡" :value="2"/>
          <el-option label="年卡" :value="3"/>
        </el-select>
      </el-form-item>
      <el-form-item label="备注" prop="remark">
        <el-input v-model="form.remark" type="textarea" :rows="3"
                  maxlength="200" show-word-limit placeholder="选填"/>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" :loading="saving" @click="submit">保存</el-button>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { memberApi, type MemberFormDTO } from '@/api/member'
import { toastErr } from '@/utils/handleErr'

const emit = defineEmits<{ (e: 'saved'): void }>()

const visible = ref(false)
const saving  = ref(false)
const isEdit  = ref(false)
const editId  = ref<number>()

const formRef = ref<FormInstance>()
const form = reactive<MemberFormDTO>({
  name: '', phone: '', gender: 1, cardType: 2, birthday: undefined, remark: '',
})

const rules: FormRules<MemberFormDTO> = {
  name:     [{ required: true, message: '请输入姓名', trigger: 'blur' },
             { min: 2, max: 20, message: '2~20 字符', trigger: 'blur' }],
  phone:    [{ required: true, message: '请输入手机号', trigger: 'blur' },
             { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }],
  gender:   [{ required: true, message: '请选择性别', trigger: 'change' }],
  cardType: [{ required: true, message: '请选择会员卡', trigger: 'change' }],
}

async function open(id?: number) {
  reset()                    // ① 先 reset
  visible.value = true       // ② 再打开
  if (id) {                  // ③ 编辑态才拉详情
    isEdit.value = true
    editId.value = id
    try {
      const r = await memberApi.detail(id)
      Object.assign(form, {
        name: r.name, phone: r.phone, gender: r.gender,
        birthday: r.birthday, cardType: r.cardType, remark: r.remark,
      })
    } catch (e) {
      toastErr(e)
      visible.value = false
    }
  }
}

function reset() {
  isEdit.value = false
  editId.value = undefined
  Object.assign(form, {
    name: '', phone: '', gender: 1, cardType: 2, birthday: undefined, remark: '',
  })
  formRef.value?.clearValidate()
}

async function submit() {
  const ok = await formRef.value?.validate().catch(() => false)
  if (!ok) return
  saving.value = true
  try {
    if (isEdit.value) await memberApi.update({ ...form, id: editId.value })
    else              await memberApi.create(form)
    ElMessage.success(isEdit.value ? '更新成功' : '新增成功')
    visible.value = false
    emit('saved')
  } catch (e) {
    toastErr(e)
  } finally {
    saving.value = false
  }
}

defineExpose({ open })
</script>
```

### 2.4 `open(id?)` 两段式赋值的顺序

`open` 方法内部的顺序**不能颠倒**：

1. `reset()`：先把 `form` 清空——防止用户看到「上次编辑的姓名」还残留在字段里。
2. `visible.value = true`：立即打开弹窗——用户能看到骨架。
3. `if (id) { ... await memberApi.detail(id); Object.assign(form, r) }`：**只在编辑态才异步拉详情**——回填。

**为什么用 `Object.assign(form, r)` 而不是 `form = r`**：`form` 是 `reactive` 对象，**引用不能换**——重新赋值会让模板里 `v-model="form.name"` 的绑定断开。`Object.assign` 只改内容不改引用，响应式活着。

**异常兜底**：`await memberApi.detail(id)` 失败要 `toastErr(e); visible.value = false`——不能让用户看着一个「加载中」的空表单傻等。

### 2.5 `@closed` vs `@close` 的时序差

`<el-dialog>` 有两个关闭相关事件：

| 事件 | 时机 | 用途 |
|---|---|---|
| `@close` | 关闭前，动画开始 | 阻止关闭（如「有未保存修改」提示）—— **不适合 reset** |
| `@closed` | 关闭后，动画结束 | reset 数据 —— 用户看不见清空过程 |

**口诀**：**`@close` 是关门开始，`@closed` 是关门结束——过去时才是「完成」**。

把 `@closed="reset"` 改成 `@close="reset"` 后手动点关闭按钮——能看到弹窗关闭动画的 300ms 里表单被清空的视觉抖动。恢复 `@closed`——动画结束后才 reset，肉眼看不出任何异常。

### 2.6 `validate()` 必须 catch

`formRef.value?.validate()` 返回的是 **Promise**：

- 校验通过 → resolve `true`
- 校验失败 → **reject** 一个错误对象（**不是** resolve `false`）

不 catch 直接 await 会让 rejection 冒到 window 的 `unhandledrejection`——控制台一堆红字。**惯用写法**是 `.catch(() => false)`：

```ts
const ok = await formRef.value?.validate().catch(() => false)
if (!ok) return
```

### 2.7 `defineExpose({ open })` 白名单

`<script setup>` 默认**所有变量都是私有的**——即使父组件通过 ref 拿到子实例，也调不到 `open`。必须显式 `defineExpose({ open })` 才能暴露给外部。

父组件配套写法：

```vue
<MemberFormDialog ref="dialogRef" @saved="tableRef?.refresh()"/>
```

```ts
import type MemberFormDialog from './MemberFormDialog.vue'
const dialogRef = ref<InstanceType<typeof MemberFormDialog>>()
// 使用
dialogRef.value?.open()       // 新增
dialogRef.value?.open(row.id) // 编辑
```

### 2.8 联调剧本

1. 点「新增会员」→ 弹窗打开，字段全空，标题「新增会员」。
2. 什么都不填直接点保存 → 姓名、手机号、会员卡三个必填项红字提示。
3. 手机号输入 `12345` → 红字「手机号格式不正确」（blur 触发）。
4. 输入合法值「张三 / 13800001111 / 男 / 月卡」→ 点保存 → 「新增成功」气泡 → 弹窗关闭 → 列表刷新出现新行。
5. 点某行的「编辑」→ 弹窗标题变「编辑会员」，字段回填，**手机号灰色禁用**。
6. 改姓名 + 备注 → 保存 → 列表刷新看到新姓名。
7. 打开一个编辑弹窗，不点保存，直接点关闭 → 观察表单在关闭动画期间**不闪烁**（`@closed` 生效）。

### 2.9 常见坑

| 症状 | 原因 | 修法 |
|---|---|---|
| `dialogRef.value?.open is not a function` | 忘了 `defineExpose({ open })` | 补上 defineExpose |
| 关闭弹窗动画期间表单闪一下空白 | 用了 `@close` 而非 `@closed` | 改成 `@closed="reset"` |
| 打开编辑弹窗一瞬间看到别人的姓名 | `open` 里没先 reset 就赋值 | 严格「先 reset 再赋值」 |
| 校验失败控制台报 `Uncaught (in promise)` | `validate()` 没 catch | `validate().catch(() => false)` |
| 后端返回 `member_name` 字段前端 `name` 收不到 | `Object.assign(form, r)` 静默不生效 | 手动映射每个字段而非一把梭 |
| `<el-radio :label="1">` 报废弃警告 | Element Plus 3.x 应用 `:value` | 全改 `:value` |
| 编辑态还能改手机号 | 忘了 `:disabled="isEdit"` | 补上 disabled 绑定 |
| `showWordLimit` 无效 | 缺 `maxlength` | 补 `maxlength="20"` |

### 2.10 练习

1. **必做**：完成 `MemberFormDialog.vue`，跑通「新增 + 编辑」两个场景，交 6 张截图（新增空验证 / 手机号格式错 / 新增成功 / 编辑加载 / 手机号禁用 / 保存成功）。
2. **必做**：给「生日」加 `disabled-date` 禁止选未来日期——`(d: Date) => d > new Date()`。
3. **挑战**：给「备注」的 `<el-input type="textarea">` 加上 `show-word-limit` + `maxlength="200"` 字数统计——观察为什么 `show-word-limit` 只在配了 `maxlength` 后才生效（读 Element Plus 源码 `input.vue` 的模板判断分支）。

---

## 第 3 讲：会员删除 + 批量删除 + 冻结解冻

### 3.1 引入：破坏性操作要几步

第 2 讲我们能新增、能编辑了，但列表页那 4 个「操作」按钮里还有 3 个是空壳：删除、冻结、解冻。这一讲把它们补齐。

破坏性操作要几步？一般是三步：

1. **二次确认**：`ElMessageBox.confirm` 弹「你确定要删除『张三』吗？」
2. **调接口**：拿到用户确认后再真删
3. **反馈 + 刷新**：成功气泡 + 列表 refresh

批量操作再加一层：**空选禁用按钮**——`selected` 数组为空时按钮灰色不可点，避免用户点了空的批量删除。

🎯 **一句话目标**：**破坏性操作 = 二次确认 + 具体文案；批量操作 = 未选禁用 + 数组统一 API**。

### 3.2 `ElMessageBox.confirm` 的两条路径

`ElMessageBox.confirm(...)` 返回一个 **Promise**：

- 点「确认」→ resolve
- 点「取消」→ **reject**（抛出字符串 `'cancel'`）

两种写法：

```ts
// 写法 A：链式 —— 推荐
ElMessageBox.confirm('确认删除？', '删除确认', { type: 'warning' })
  .then(() => memberApi.remove([row.id]))
  .then(() => { ElMessage.success('删除成功'); tableRef.value?.refresh() })
  .catch(e => e === 'cancel' ? null : toastErr(e))

// 写法 B：await 风格 —— 简洁但要小心
try {
  await ElMessageBox.confirm('确认删除？', '删除确认', { type: 'warning' })
  await memberApi.remove([row.id])
  ElMessage.success('删除成功')
  tableRef.value?.refresh()
} catch (e) {
  if (e === 'cancel') return    // 用户取消，静默返回
  toastErr(e)
}
```

**本项目主要用写法 B（await）**——代码更线性、更符合直觉；但**必须 catch**，否则用户点取消时控制台会跳出 `Uncaught (in promise) cancel` —— **看起来像 Bug 又不影响功能**，最容易漏。

**红色按钮约定**：破坏性操作确认按钮要变红——`confirmButtonClass: 'el-button--danger'` + `confirmButtonText: '删除'`。UX 规约：红色 = 危险操作。

### 3.3 `selected` 数组的收集

要拿到用户勾选的行，三步：

1. 表格第一列加 `<el-table-column type="selection" width="42"/>`——**列宽 42** 是团队约定，默认宽度不够会挤压后续列。
2. 监听 `@selection-change="v => selected = v"`——`v` 是**当前所有勾选的行对象数组**（不是 id 数组）。
3. 顶部批量按钮 `:disabled="!selected.length"`——空选禁用。

### 3.4 补齐 `onDelete / onBatchDelete / onToggleFreeze`

回到 `MemberListView.vue`，把第 1 讲留的三个 TODO 填上：

```ts
async function onDelete(row: MemberVO) {
  try {
    await ElMessageBox.confirm(
      `确认删除会员「${row.name}」？该操作不可撤销`,
      '删除确认',
      {
        type: 'warning',
        confirmButtonText: '删除',
        confirmButtonClass: 'el-button--danger',
      },
    )
  } catch (e) {
    return   // 用户取消
  }
  try {
    await memberApi.remove([row.id])
    ElMessage.success('删除成功')
    tableRef.value?.refresh()
  } catch (e) {
    toastErr(e)
  }
}

async function onBatchDelete() {
  const ids = selected.value.map(m => m.id)
  if (!ids.length) return
  try {
    await ElMessageBox.confirm(
      `即将删除 ${ids.length} 条记录，是否继续？`,
      '批量删除',
      { type: 'warning' },
    )
  } catch { return }
  try {
    await memberApi.remove(ids)
    ElMessage.success(`已删除 ${ids.length} 条`)
    selected.value = []           // 关键：清空勾选状态
    tableRef.value?.refresh()
  } catch (e) {
    toastErr(e)
  }
}

async function onToggleFreeze(row: MemberVO) {
  const action = row.status === 1 ? '冻结' : '解冻'
  try {
    await ElMessageBox.confirm(`确认${action}「${row.name}」？`, `${action}确认`, {
      type: 'warning',
    })
  } catch { return }
  try {
    if (row.status === 1) await memberApi.freeze(row.id)
    else                  await memberApi.unfreeze(row.id)
    ElMessage.success(`${action}成功`)
    tableRef.value?.refresh()
  } catch (e) {
    toastErr(e)
  }
}
```

### 3.5 统一 API 表达面：`remove(ids: number[])`

**单删就是长度 1 的批量删**——前后端都用同一个 `remove(ids: number[])` 接口。

好处：

- 后端一个 controller 方法处理所有删除场景。
- 前端拆分成「单行删」和「批量删」两个函数只是**表现层的语义包装**，底层 API 完全一样。
- 未来要加「按查询条件批删」也是同一个接口 + 前端组一下 ids 数组。

**Axios 的坑**：`DELETE` 请求默认**不带 body**——必须写 `request.delete(url, { data: ids })`。学生第一次踩这个坑会怀疑「后端没收到参数」。

### 3.6 冻结 / 解冻的按钮切换

`<el-button :type="row.status === 1 ? 'warning' : 'success'">` + `{{ row.status === 1 ? '冻结' : '解冻' }}` —— 同一个按钮位置、根据状态显示不同文案与颜色。

**动态类型绑定**：`:type` 是 Vue 表达式，值必须是 Element Plus 认识的字符串枚举（`'primary' | 'success' | 'warning' | 'danger' | 'info'`）。直接写 `type="warning"` 是**静态字符串**，写 `:type="'warning'"` 是**动态但值不变**——一开始容易混。

**二次确认文案也动态**：`` `确认${action}「${row.name}」？` `` —— 破坏性操作的文案**必须带具体对象名**，不要写「你确定吗？」这种 UX 灾难。

### 3.7 前端 vs 后端校验的分层

| 校验项 | 前端 | 后端 |
|---|---|---|
| 必填 | ✅ | ✅ |
| 长度、格式（手机号正则） | ✅ | ✅（**兜底**） |
| 唯一性（手机号已注册） | ❌ 前端无法查 | ✅ |
| 业务规则（该手机号已被冻结） | ❌ | ✅ |
| 越权（编辑他人数据） | ❌ | ✅ **必须** |

**铁律**：**前端校验只为提升体验，安全校验永远由后端负责**。前端能做的一切校验绕过（Postman 直调、开控制台改代码），后端都要挡住。

### 3.8 联调剧本

1. 点某行「删除」→ 弹窗「确认删除会员『张三』？」→ 点「取消」→ 弹窗关闭，无任何变化、控制台无红字。
2. 再点删除 → 点确认（红色按钮）→ 「删除成功」气泡 → 列表刷新，该行消失。
3. 勾 3 条 → 顶部「批量删除」按钮从灰变红 → 点击 → 弹窗「即将删除 3 条记录」→ 确认 → 3 行消失、勾选清空。
4. 点某行「冻结」按钮 → 弹窗确认 → 该行状态 tag 变黄「冻结」，按钮文案变「解冻」。
5. 再点「解冻」→ 弹窗 → 状态 tag 恢复绿色「正常」，按钮变回「冻结」。
6. 断网点删除 → `toastErr(e)` 弹红色气泡「网络异常」，列表不受影响（因为 refresh 没被调用）。

### 3.9 常见坑

| 症状 | 原因 | 修法 |
|---|---|---|
| 用户点取消，控制台跳 `Uncaught (in promise) cancel` | await confirm 没 catch | 加 `catch { return }` 或链式 `.catch(e => e === 'cancel' ? null : toastErr(e))` |
| 用户看到「删除失败」但行还是没了 | 乐观更新的回滚顺序错 / 误清了本地列表 | 主流程用悲观更新（refresh），乐观更新是挑战作业 |
| 二次确认文案硬编码「你确定吗？」 | 缺具体对象名 | 拼上 `${row.name}` 让用户知道到底删哪个 |
| Axios `DELETE` 请求 body 后端收不到 | Axios 默认 DELETE 不带 body | `request.delete(url, { data: ids })` |
| 批量删除后 `selected` 里还有旧引用 | 后端删了但前端数组没清 | `selected.value = []` 手动清 |
| `:type="warning"` 报错 | 忘了 `:` 前缀成字符串 vs 表达式 | 写 `:type="row.status === 1 ? 'warning' : 'success'"` |

### 3.10 练习

1. **必做**：完成 `onDelete / onBatchDelete / onToggleFreeze` 三个方法，跑通「单删 → 批量删 → 冻结 → 解冻」四个场景，交 4 张截图。
2. **必做**：把 `refresh()` 后手动 `selected.value = []`——避免残留勾选数据污染下次批量操作。
3. **挑战**：给单删实现**乐观更新 + 失败回滚**——需要在 `ProTable` 里加一个 `removeRow(id)` 方法暴露出来，删除失败调 `insertRow(row, index)` 恢复；写一个后端故意返回 500 的测试用例验证回滚。
4. **挑战**：完成详情抽屉 `MemberDetailDrawer.vue` —— `<el-drawer>` + `<el-descriptions>` 展示会员信息，`open(id)` 内部拉详情、`el-skeleton` 占位加载中、`destroy-on-close` 关闭销毁 DOM。

---

## 第 4 讲：AI 编写前端页面流程 —— Prompt → 生成 → 验收

### 4.1 引入：手写要写多久

第 1 到 3 讲，我们**手写**了会员管理页——大约花了 3 讲时间。心里估算一下：项目里还有教练管理、课程管理、教室管理、订单管理、会员卡管理、消费记录、优惠券管理…… 至少 15 个模块。

15 × 3 = 45 讲——**够跑完一整门课的一半**。真项目里没这个耐心。

但仔细看，这 15 个页面 80% 是模板（列表 + 弹窗 + 抽屉），20% 才是业务差异（字段名、校验规则、按钮）。**80% 的模板部分**——正是 AI 最擅长的。

灵魂问题：**AI 能取代前端工程师吗？** 不能。但**能把 15 × 3 的工作量压缩到 15 × 1**——你从「码农」变成「验收员」。这一讲的核心不是让 AI 写代码，而是**你怎么让 AI 写出你能验收的代码**。

🎯 **一句话目标**：**Prompt 六要素 + 四段式验收 + 迭代 3 点 = 让 AI 变成能持续产出可入库代码的初级前端**。

### 4.2 后台管理页面的 5 层结构

对任意一个后台管理业务模块的前端页面，可以拆成 5 层：

1. **列表页**：顶部操作栏 / 搜索栏 / 数据表 / 操作列
2. **弹窗 / 抽屉**：表单字段 / 校验规则 / 提交与取消
3. **API 层**：类型定义 / 增删改查方法
4. **路由**：Menu 入口 / View 挂载
5. **通用能力**：字典 / 错误处理 / 样式变量

**变化点分布**：

- **API 层**：路径、字段结构——**完全业务相关**
- **列表页**：搜索字段、表格列——**业务字段 + 复用组件**
- **弹窗**：表单字段与校验规则——**业务规则**
- **路由 / 字典 / 样式**：几乎不变

**AI 生成的最佳边界**：一次生成 **API + 列表页 + 弹窗**三件套，路由和字典人工接。

### 4.3 Prompt 六要素

一份能让 AI 直接产出可用代码的提示词，需要包含 6 个要素：

| 要素 | 例子 | 缺失后果 |
|---|---|---|
| ① 技术栈版本 | Vue 3.4 + Element Plus 3 + TS + Vite | 生成过时 API（如 `<el-radio :label>`） |
| ② 目录约定 | `api/coach.ts` `views/coach/*.vue` | 输出散乱、引入路径不对 |
| ③ 复用组件 | `PageContainer / SearchBar / ProTable` | 从零重写，风格漂移 |
| ④ 业务字段 + 校验规则 | name / employeeNo / phone / level / specialty | 字段错位或校验缺失 |
| ⑤ 交互细节 | Dialog 用 `@closed` reset、`:disabled=isEdit` | 缺二次确认 / 关闭时机错 |
| ⑥ 输出格式 | 「按文件分块，每块前用 `// FILE: xxx`」 | 一坨代码难拆分 |

**六要素缺一不可**——特别是 ① 技术栈版本，Element Plus 2 和 3 差异很大，AI 训练语料混杂新旧版本，不明确指定它就靠猜。

### 4.4 完整 Prompt 示例：教练管理三件套

第 14 章后端已经有 `/coaches` 系列接口。完整提示词（约 60 行，每一行都消除了 AI 一个可能的自由发挥）：

```text
你是资深 Vue 3 + Element Plus 前端。为「印想瑜伽后台管理系统」生成【教练管理】的前端代码。

技术栈：Vue 3.4 + Vite + TS + Pinia + Element Plus 3（unplugin 自动引入 ElMessage/ElMessageBox/ElNotification），Axios 请求实例 @/api/request（响应已解包）。

复用现有组件（不要重写）：@/components/PageContainer.vue、@/components/SearchBar.vue、@/components/ProTable.vue（props: { loader, query } + defineExpose { refresh, resetToFirst }）；错误处理 @/utils/handleErr 的 toastErr(e)。

后端接口：
- GET    /coaches                查询分页  params: name?/phone?/level?/status?/pageNum/pageSize
- GET    /coaches/{id}           详情
- POST   /coaches                新增
- PUT    /coaches                更新
- DELETE /coaches                批量删除（body: number[]）
- POST   /coaches/{id}/freeze    冻结
- POST   /coaches/{id}/unfreeze  解冻

数据模型 CoachVO：id / name / employeeNo(YX+4 位) / phone(11 位) / level(1 初 2 中 3 高) / specialty(string[]) / status(1 在职 2 离职) / hireDate(YYYY-MM-DD) / remark?

请生成 3 个文件：
1. src/api/coach.ts —— 完整类型 + coachApi = { page, detail, create, update, remove, freeze, unfreeze }
2. src/views/coach/CoachListView.vue —— 使用 PageContainer/SearchBar/ProTable；顶部新增/批量删除/导出（导出仅弹提示）；搜索姓名/手机号/职级/状态；列勾选、姓名、工号、手机号、职级 tag、擅长 tag 多个、状态 tag、入职日期、操作；操作含编辑/冻结解冻/删除，破坏性操作二次确认。
3. src/views/coach/CoachFormDialog.vue —— defineExpose({ open(id?) })；有 id 则加载详情做编辑；FormRules：name 2-20 必填 / employeeNo 必填正则 /^YX\d{4}$/ / phone 必填手机号正则 / level required / specialty 至少选 1 项（自定义 validator）；phone 编辑禁改；保存后 emit 'saved'；@closed reset。

输出要求：TypeScript 严格模式、<script setup lang="ts">、每个文件前用 // FILE: 路径 分隔便于我复制；不要输出 tsconfig / router 修改，只输出这 3 个文件。
```

### 4.5 四段式验收

AI 输出后，**不是无脑接收**，而是走四段式验收：

```
① 跑得起来 → ② 逻辑正确 → ③ 边界完整 → ④ 风格一致 → 入库
   ↑           ↑           ↑           ↑
   任何一段失败 → 一句话补丁 → 丢回给 AI → 再验
```

#### 4.5.1 跑得起来（Compile & Render）

复制到项目 → `pnpm dev` → 打开菜单 → 页面加载不报错。

常见失败：

- 引入路径写错（`@/components/pro-table.vue` vs `ProTable.vue`）
- Element Plus 组件用了 v-model 错误的绑定（`<el-radio-group v-model:value>`）
- TS 类型 `Record<number, string>` 缺 import

**改法**：让 AI 用你的目录结构——所以要在 Prompt 里明确路径。

#### 4.5.2 逻辑正确（Business Correctness）

- 分页请求参数字段名与后端一致（`pageNum` vs `page`）
- **编辑态**：手机号是否禁用、`update` 是否带 `id`
- 校验规则是否覆盖所有 required 字段
- **删除是否二次确认**

**改法**：一句话补丁——「手机号编辑时 `:disabled=isEdit`」。

#### 4.5.3 边界完整（Corner Cases）

- 空数据：列表为空时是否有「暂无数据」占位
- 网络失败：`toastErr(e)` 是否包裹每个 API 调用
- Loading：saving / loading 状态是否显示在按钮上
- 关闭时机：`@closed` 而非 `@close`
- ElMessageBox reject 是否吞掉

**改法**：**主动补一遍**——AI 常常漏这些细节。

#### 4.5.4 风格一致（Consistency）

- 表格列宽是否与会员管理页保持一致（姓名 90 / 手机号 130）
- 按钮颜色、图标是否统一
- `<template #actions>` 的位置
- 字典是否统一挂在 `@/utils/dict.ts`（而不是页面内散列 `LEVEL_MAP`）

**改法**：把字典集中化——如果生成时把 `LEVEL_MAP` 内嵌，就抽到 dict.ts。

### 4.6 迭代式微调 —— 每轮只改 3 个点

第一轮 = 完整提示词，第二轮以后 = **补丁式指令**：

```text
上一版有 3 个问题请修正：
1. <el-radio :label="1"> 换成 :value="1"
2. 手机号编辑态要 :disabled=isEdit
3. specialty 默认值改为 []

保持其余不变，重新输出这两个文件。
```

**关键**：**每轮只改 3 个点**——不要重复描述已经对的部分，否则 AI 会**改坏已经对的地方**（比如把 `ProTable` 的 ref 类型换成另一种写法、把 `SearchBar` 的 `@search` 变成 `@click`）。

**第三轮增量补漏示例**：

```text
再加两点：
1. 顶部按钮增加「导入 Excel」占位按钮，onClick 弹 ElMessage.info('功能开发中')
2. CoachListView.vue 增加「入职年月」列，格式化为「2025-06」，从 hireDate 派生
```

### 4.7 AI 前端代码常见错误清单

| 症状 | 原因 | 修法 |
|---|---|---|
| `<el-radio :label="1">`（旧 API） | 训练语料混杂 3.x 与 2.x | 手改 `:value="1"` |
| `ref<InstanceType<typeof X>>()` 报类型错 | AI 忘了 `default` 导出 | 改成 `InstanceType<typeof import(...).default>` |
| Dialog reset 用 `@close` | 混淆 close / closed | 手改 `@closed` |
| `disabled-date` 参数类型不对 | AI 猜的类型 | 改 `(d: Date) => d > new Date()` |
| `showWordLimit` 无效 | 缺 `maxlength` | 补 `maxlength="20"` |
| `specialty` 为 undefined | AI 忘了初始化数组 | `specialty: []` |
| ElNotification 不生效 | 忘了 unplugin auto-import 白名单 | 补 `resolvers` 配置 |
| 校验器返回 `false` 却不显示错误 | 应 `callback(new Error(...))` | 改回调式 validator |
| 接口路径幻觉 `/coach/list` | AI 猜路径 | Prompt 里必须明确接口清单 |
| 忽略通用组件重造轮子 | Prompt 没说「不要重写」 | 在 Prompt 强调复用现有组件 |
| 过度包装 3 层 composable | 简单业务被抽象化 | Prompt 明确规模（如 200 行以内） |
| 中文注释混入 markdown 语法 | AI 训练语料混杂 | 要求「无 markdown 语法」 |
| 引用不存在的字典 `LEVEL` | AI 猜 dict 里有这个 | 字典一并生成 |
| 依赖 element-plus 2.x API | 没指定版本 | Prompt 明确「Element Plus 3」 |

**建议**：把这张表贴到项目 wiki，团队共享。AI 生成时可以**把这张表再喂回给 AI** 做自校对——「请对照以下清单检查你的输出」。

### 4.8 工具选型

| 工具 | 强项 | 用途 |
|---|---|---|
| ChatGPT / Claude 网页 | 全流程生成 + 讲解 | 学习 / 提示词打磨 |
| Cursor / Windsurf | 项目上下文 + 多文件重构 | **真实开发主战场** |
| 通义灵码 / Trae | IDE 内联 + 中文对齐 | 国内团队主战场 |
| Copilot | 行内补全 | 打字加速 |
| v0.dev | 视觉页面生成 | Landing / 营销页 |
| bolt.new / lovable | 从 0 起项目 | 原型 / 玩具 |

**本课程推荐**：**Cursor + Claude / GPT** 或 **通义灵码 / Trae + 团队 wiki 提示词库**。核心工作流是「读上下文 → 生成 → 应用 diff」，你只负责验收。

### 4.9 「AI 是脚手架，人是架构师」

**AI 擅长**：

- 结构相似的重复代码
- 记住繁多的 API 参数
- 生成初稿

**AI 不擅长（你必须做）**：

- 抽象出通用组件（`ProTable / SearchBar`）—— **架构判断**
- 决定交互形式（Dialog vs Drawer vs 独立页）—— **产品判断**
- 决定校验分层（前端 vs 后端）—— **安全判断**
- 决定性能优化点（懒加载 / 虚拟滚动 / 分页粒度）—— **工程判断**

⚠️ **特别注意**：**永远不要把你不懂的代码提交到主干**。AI 生成再香，你要能**逐行看懂**才敢用——出问题时半夜爬起来修的是你，不是 AI。

### 4.10 联调剧本

1. 打开 AI 助手（通义灵码 / Trae / Cursor），粘贴 4.4 节的完整提示词。
2. AI 输出 3 个文件，按 `// FILE:` 分隔复制到项目对应位置。
3. 路由文件加 `{ path: '/coaches', component: () => import('@/views/coach/CoachListView.vue'), meta: { title: '教练管理', icon: 'Avatar' } }`。
4. `pnpm dev` → 打开 `/coaches` → **① 跑得起来** —— 大概率红字 3~5 处（`import` 路径大小写、`ElMessage` 未 import、`FormRules` 类型缺 import），一起丢回 AI 做补丁修正。
5. 二次生成后页面渲染成功 → **② 逻辑正确** —— Postman 测 POST /coaches，发现 `phone` 字段前端传成 `mobile`（AI 混淆）—— 记下修正 1。
6. **③ 边界完整** —— 断网点新增，弹窗直接白屏没错误提示 —— AI 忘了 `toastErr(e)`，记下修正 2。
7. **④ 风格一致** —— 教练列表的「工号」列宽 120，会员管理里手机号是 130，团队规约都是 130 —— 记下修正 3。
8. 三个补丁一起丢回 AI 修正 → 页面入库。

### 4.11 常见坑（AI 生成场景专属）

| 症状 | 原因 | 修法 |
|---|---|---|
| AI 猜 `/coach/list`，后端是 `/coaches` | Prompt 未明确接口清单 | 接口清单一定要写全路径 |
| AI 自建 `MyTable`，忽略 `ProTable` | 缺「不要重写」的强约束 | Prompt 强调「复用组件，不要重写」 |
| AI 套 3 层 composable | 缺规模约束 | Prompt 加「简单业务，300 行以内」 |
| AI 注释里出现 `**加粗**` markdown | 训练语料混合 | Prompt 要求「JSDoc 无 markdown 语法」 |
| AI 引用不存在的 `import { LEVEL }` | 字典未一并维护 | 把字典也放入 Prompt |
| 同会话多轮后前后不一致 | AI 忘掉最初约定 | 每几轮把关键约束再念一遍 |
| 第三轮把已经对的地方改坏 | 补丁指令没精简，重复描述 | 只说要改的点，「保持其余不变」 |

### 4.12 练习

1. **必做**：用本讲的提示词模板，让 AI 一次性生成「教室管理」的 API + 列表页 + 弹窗——字段 `roomNo / name / capacity / location / equipments[] / status`；走完四段式验收；交完整代码 + 验收记录（4 段各发现多少问题）。
2. **必做**：把本次成功的提示词沉淀到 `docs/PROMPTS.md`，加上「本团队约定」段——通用组件路径、字典约定、错误处理规则、列宽经验值。
3. **挑战**：让 AI 生成 Dashboard 首页（4 个数字卡片 + 2 个 ECharts 图表 + 1 个操作日志 ProTable），走完验收，特别关注 **ECharts 的 dispose 逻辑** —— 组件卸载时是否释放实例；同时并发请求所有接口、任一失败 `toastErr`。

---

## 第 5 讲：后台通用布局 —— 顶栏 + 侧栏 Menu + 面包屑

### 5.1 引入：外壳里的四件事

第 4 讲结束，`yoga-admin` 已经有会员管理和教练管理两个业务模块——但**页面外壳**还是 Day12 简易版：顶部一行 logo、左侧一个 `<router-link>` 列表、没有面包屑、没有折叠。

一个真实的后台管理系统外壳有 4 个组件：

1. **`Layout.vue`**：三栏骨架（顶 + 侧 + 主）
2. **`Header.vue`**：logo + 面包屑 + 用户菜单
3. **`Sidebar.vue`**：多级菜单 + 折叠按钮
4. **`Breadcrumb.vue`**：动态面包屑

灵魂问题一句：**为什么菜单要从路由派生，而不是自己写一份？**——因为路由和菜单本质是**同一份信息的两种视图**，同源才能同步；分开写只会越写越漂。

🎯 **一句话目标**：**路由 `meta` 作为单一数据源，Sidebar 从 `router.options.routes` 派生，Breadcrumb 从 `route.matched` 派生 —— 一份数据三种视图**。

### 5.2 `<el-container>` 三栏结构

Element Plus 提供了 `<el-container>` 系列组件，直接子里有 `<el-header>` 或 `<el-footer>` 时**纵向布局**，否则**横向布局**——利用这个特性搭三栏：

```vue
<!-- src/layout/Layout.vue -->
<template>
  <el-container class="layout">
    <el-aside :width="isCollapse ? '64px' : '210px'">
      <Sidebar :collapse="isCollapse"/>
    </el-aside>
    <el-container>
      <el-header height="60px">
        <Header v-model:collapse="isCollapse"/>
      </el-header>
      <el-main>
        <router-view/>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { useStorage } from '@vueuse/core'
import Sidebar from './Sidebar.vue'
import Header from './Header.vue'

// 折叠状态持久化到 localStorage
const isCollapse = useStorage('sidebar-collapse', false)
</script>

<style scoped>
.layout { height: 100vh; }
.el-aside {
  background: #001529;
  transition: width 0.3s;   /* 折叠动画 */
  overflow: hidden;
}
.el-header {
  background: #fff;
  border-bottom: 1px solid #e4e7ed;
  display: flex;
  align-items: center;
  padding: 0 16px;
}
.el-main {
  background: #f5f7fa;
  padding: 12px;
}
</style>
```

**关键点**：

- 外层 `<el-container class="layout">` 高度 `100vh` —— 铺满视口。
- `<el-aside>` 的 `:width` 绑响应式变量 `isCollapse` —— 折叠时 64px、展开时 210px。
- **`transition: width 0.3s` 是折叠动画的关键** —— 不写就没动画，直接跳变，UX 一坨。
- `useStorage('sidebar-collapse', false)` 用 `@vueuse/core` 一行代码实现 localStorage 持久化——刷新页面折叠状态保留。

### 5.3 路由 meta 作为单一数据源

传统写法把路由和菜单**各写一份**——路由改字段名菜单要跟着改，两处失同步。单一数据源写法：**菜单从路由 meta 派生**。

```ts
// src/router/index.ts
import { createRouter, createWebHistory } from 'vue-router'
import Layout from '@/layout/Layout.vue'

export default createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/login', component: () => import('@/views/LoginView.vue'),
      meta: { hidden: true } },   // 不出现在菜单
    { path: '/', component: Layout, redirect: '/members', children: [
      { path: 'members', component: () => import('@/views/member/MemberListView.vue'),
        meta: { title: '会员管理', icon: 'User' } },
      { path: 'coaches', component: () => import('@/views/coach/CoachListView.vue'),
        meta: { title: '教练管理', icon: 'Avatar' } },
      { path: 'rooms',   component: () => import('@/views/room/RoomListView.vue'),
        meta: { title: '教室管理', icon: 'House' } },
    ]},
  ],
})
```

`meta` 三个约定字段：

| 字段 | 类型 | 作用 |
|---|---|---|
| `title` | string | 菜单显示文字 + 面包屑标签，**没有 title 的路由不进菜单不进面包屑** |
| `icon` | string | Element Plus 图标名 |
| `hidden` | boolean | 显式排除，即使有 title 也不进菜单（用于登录页、404） |

### 5.4 `Sidebar.vue` —— 递归渲染菜单

```vue
<!-- src/layout/Sidebar.vue -->
<template>
  <div class="sidebar-logo">
    <img src="/logo.svg" alt="logo"/>
    <span v-show="!collapse">印想瑜伽</span>
  </div>
  <el-menu :default-active="route.path" :collapse="collapse"
           :unique-opened="true" router
           background-color="#001529"
           text-color="#dcdfe6"
           active-text-color="#409EFF">
    <template v-for="r in menuRoutes" :key="r.path">
      <el-menu-item v-if="!r.children?.length" :index="'/' + r.path">
        <el-icon><component :is="r.meta?.icon"/></el-icon>
        <template #title>{{ r.meta?.title }}</template>
      </el-menu-item>
      <el-sub-menu v-else :index="'/' + r.path">
        <template #title>
          <el-icon><component :is="r.meta?.icon"/></el-icon>
          <span>{{ r.meta?.title }}</span>
        </template>
        <el-menu-item v-for="c in r.children" :key="c.path"
                      :index="'/' + r.path + '/' + c.path">
          {{ c.meta?.title }}
        </el-menu-item>
      </el-sub-menu>
    </template>
  </el-menu>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'

defineProps<{ collapse: boolean }>()

const route  = useRoute()
const router = useRouter()

// 从路由派生菜单：过滤 hidden、只保留有 title 或有 children 的
const menuRoutes = computed(() => {
  const layout = router.options.routes.find(r => r.path === '/')
  return (layout?.children ?? []).filter(r =>
    !r.meta?.hidden && (r.meta?.title || r.children?.length))
})
</script>
<!-- style scoped：sidebar-logo 60px 高、居中、深底白字；.el-menu 去掉右边框 -->
```

**`<el-menu>` 关键属性**：

| 属性 | 作用 |
|---|---|
| `router` | 开启路由模式——`<el-menu-item index="/members">` 点击自动 `router.push('/members')` |
| `default-active` | 当前高亮的 index，绑 `route.path` 让菜单跟路由同步 |
| `unique-opened` | 同一层级只能展开一个子菜单 |
| `collapse` | 折叠模式——item 只显图标，文字变悬浮 popover |

**递归菜单**：本项目只讲两级（父 → 子），深层递归需要写一个 `MenuItem.vue` 组件递归自身——放到挑战作业。

### 5.5 `Breadcrumb.vue` —— 从 `route.matched` 派生

`useRoute().matched` 返回**当前路由的所有父级链**——比如访问 `/members` 时返回：

```
[
  { path: '/',        meta: {} },                          // Layout，没 title 跳过
  { path: '/members', meta: { title: '会员管理' } },       // 保留
]
```

面包屑就是这个数组的可视化：

```vue
<!-- src/layout/Breadcrumb.vue -->
<template>
  <el-breadcrumb separator="/">
    <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item v-for="c in crumbs" :key="c.path">
      {{ c.meta?.title }}
    </el-breadcrumb-item>
  </el-breadcrumb>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()

const crumbs = computed(() =>
  route.matched.filter(r => r.meta?.title),   // 跳过没有 title 的顶层布局路由
)
</script>
```

**关键**：`.filter(r => r.meta?.title)` —— 跳过没有 title 的路由层级（比如 Layout 本身没 title）。不写这一句就会出现「首页 → → 会员管理」中间一个空白 item。

### 5.6 `Header.vue` —— logo + 折叠按钮 + 面包屑 + 用户菜单

```vue
<!-- src/layout/Header.vue -->
<template>
  <el-icon class="collapse-btn" @click="toggle">
    <Fold v-if="!collapse"/>
    <Expand v-else/>
  </el-icon>
  <Breadcrumb class="header-breadcrumb"/>
  <div class="header-user">
    <el-dropdown>
      <span class="user-trigger">
        <el-avatar :size="28" :src="userStore.avatar"/>
        <span>{{ userStore.name }}</span>
        <el-icon><ArrowDown/></el-icon>
      </span>
      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item @click="onProfile">个人中心</el-dropdown-item>
          <el-dropdown-item divided @click="onLogout">退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script setup lang="ts">
import Breadcrumb from './Breadcrumb.vue'
import { useUserStore } from '@/stores/user'
import { useRouter } from 'vue-router'

const props = defineProps<{ collapse: boolean }>()
const emit  = defineEmits<{ (e: 'update:collapse', v: boolean): void }>()

const userStore = useUserStore()
const router    = useRouter()

function toggle() { emit('update:collapse', !props.collapse) }
function onProfile() { router.push('/profile') }
async function onLogout() {
  await userStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.collapse-btn {
  font-size: 20px;
  cursor: pointer;
  margin-right: 16px;
}
.header-breadcrumb { flex: 1; }
.header-user { display: flex; align-items: center; gap: 8px; }
.user-trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
}
</style>
```

**`v-model:collapse` 语法糖**：`<Header v-model:collapse="isCollapse"/>` 本质是 `:collapse="isCollapse" @update:collapse="v => isCollapse = v"`——第 6 讲会详细展开。这里父组件把 `isCollapse` 双向绑定给 `Header`，`Header` 里的折叠按钮点击时 emit `update:collapse` 让父组件更新。

### 5.7 联调剧本

1. 完成 4 个布局组件后，`pnpm dev` → 打开根路径 `/` → 自动重定向到 `/members`。
2. 观察三栏结构：左侧深色侧栏 210px、顶栏 60px 高白色带面包屑、主区浅灰。
3. 点侧栏「教练管理」→ 主区切换到 `/coaches`、面包屑变「首页 / 教练管理」、菜单高亮跟着变。
4. 手动改地址栏为 `/coaches`（不通过菜单）→ 菜单仍能正确高亮——`default-active` 绑 `route.path` 生效。
5. 点顶栏折叠按钮 → 侧栏 210 → 64 有 300ms 过渡动画、logo 文字消失、菜单文字变悬浮 tooltip。
6. **刷新页面** → 折叠状态保留（`useStorage` 生效）。
7. 打开 `/login`（假设已在路由声明为 `meta.hidden: true`）→ 菜单里没有登录项。
8. 点用户头像 → 下拉菜单出现「个人中心 / 退出登录」。

### 5.8 常见坑

| 症状 | 原因 | 修法 |
|---|---|---|
| 手动改地址栏后菜单不高亮 | `default-active` 没绑响应式 | `:default-active="route.path"` |
| 面包屑「首页 → → 会员管理」中间有空 item | 没过滤没有 title 的父级 | `.filter(r => r.meta?.title)` |
| 折叠动画卡顿 / 直接跳变 | 没加 `transition: width 0.3s` | CSS 里补上过渡 |
| 刷新页面折叠状态丢失 | 用了 `ref(false)` 而非持久化 | `useStorage('sidebar-collapse', false)` |
| 递归菜单深层报警告「component name is required」 | 递归组件没显式命名 | `defineOptions({ name: 'MenuItem' })` |
| 登录页出现在菜单里 | 没标 `meta.hidden: true` | 补 hidden 字段并在派生逻辑里排除 |
| 图标 `<component :is="r.meta?.icon"/>` 不显示 | Element Plus 图标组件没在 auto-import 白名单 | 检查 `unplugin-vue-components` 的 `ElementPlusResolver({ importStyle: 'sass', directives: true })` |

### 5.9 练习

1. **必做**：完成 4 个布局组件，跑通「会员管理 / 教练管理」的完整外壳（顶栏 + 侧栏 + 面包屑），刷新保留折叠状态，交 4 张截图（展开态 / 折叠态 / 面包屑深两层 / 首页）。
2. **必做**：给路由 meta 加 `hidden` 字段，把「登录页」`/login` 从菜单中隐藏。
3. **挑战**：实现 **Tags View** —— 顶栏下方一排 tab，每个 tab 对应一个「打开过的路由」，可关闭；用 Pinia 存 `openedTags` 数组，`router.afterEach` 里 push 新 tag。
4. **挑战**：把两级菜单扩展到多级——写 `MenuItem.vue` 递归组件（`defineOptions({ name: 'MenuItem' })`），支持任意层级嵌套。

---

## 第 6 讲：页面拆分与子组件抽取 —— Props / Emit / defineExpose

### 6.1 引入：一个 300 行文件的味道

`MemberListView.vue` 现在多少行？打开一看——**300+ 行**。模板、script、导入、类型定义堆在一起。灵魂问题一句：**这个文件哪一段最独立、可以拆出去？**

数一下：

- 顶部操作栏（新增 / 批量删 / 导出）—— 3 个按钮，独立
- 搜索栏字段定义 —— 内嵌 SearchBar 内部，暂时够用
- 表格列定义 —— 8 列的模板占了 60 行，可以抽成配置对象
- 弹窗、抽屉 —— 本来就是独立文件

抽分方案：**1 个主页 + 3 个子组件 + 1 个列配置**。

但先别急着抽——**过早抽象是原罪**。三行按钮抽成组件反而更繁：主页 import 多 1 行 + 子组件文件 20 行 + 还得写 Props/Emit。

🎯 **一句话目标**：**Props 单向数据 / Emit 事件通知 / defineExpose 命令式调用 —— 三种模式各司其职，不要滥用 ref**。

### 6.2 什么时候抽子组件（3 个信号）

| 信号 | 说明 |
|---|---|
| ① 模板超过 200 行 | 阅读困难 → 抽 |
| ② 内部有独立业务逻辑 | 弹窗自己管 visible/form/rules → 抽 |
| ③ 可能被多处复用 | Dialog、Drawer 是天然的复用者 → 抽 |

**反例**：一个只有 3 行的按钮组抽成组件 → **过度抽象**，反而变复杂。

**原则**：**Rule of Three** —— 同一段代码写第 3 次时才抽——前两次先复制粘贴。

### 6.3 `defineProps<T>()` 与 `withDefaults`

Vue 3 的 script setup 里，Props 有两种写法：

```ts
// 运行时式（无类型约束）
const props = defineProps({
  modelValue: { type: Boolean, required: true },
  title: { type: String, default: '默认标题' },
})

// 类型式（推荐）
const props = defineProps<{
  modelValue: boolean
  title?: string
}>()

// 类型式 + 默认值
const props = withDefaults(defineProps<{
  modelValue: boolean
  title?: string
}>(), {
  title: '默认标题',
})
```

- **必填 vs 可选** 由 `?` 决定。
- **只读**：props 是**单向数据流**——子组件不能改 props（改了 dev 环境会报 Warning）。要改，emit 事件让父改。

### 6.4 `defineEmits<T>()` 三种写法

```ts
// 简单数组（无类型约束）
const emit = defineEmits(['saved', 'delete'])

// 类型式（Vue 3.3 及以下）
const emit = defineEmits<{
  (e: 'saved'): void
  (e: 'delete', id: number): void
}>()

// Vue 3.4+ 简化元组语法（推荐）
const emit = defineEmits<{
  saved: []              // 无参数
  delete: [id: number]   // 一个 number 参数
  save: [dto: MemberFormDTO, silent?: boolean]  // 多参数
}>()
```

强类型约束让编译期就能发现「emit 事件名拼错」「参数类型不对」——比运行时字符串数组安全得多。

### 6.5 `v-model` 是语法糖

这是 Vue 3 最常被误解的一点。`v-model` 不是「双向绑定的黑魔法」，而是 **Props + Emit 的组合语法糖**：

```vue
<!-- 这两种写法完全等价 -->
<Dialog v-model="visible"/>

<Dialog :model-value="visible" @update:model-value="v => visible = v"/>
```

具名 v-model：

```vue
<Dialog v-model:visible="visible"/>
<!-- 等价于 -->
<Dialog :visible="visible" @update:visible="v => visible = v"/>
```

**多个 v-model**：一个组件可以同时 `v-model:visible` + `v-model:tabName`——本质是两组 Props+Emit：

```vue
<TabDialog v-model:visible="visible" v-model:tab="tabName"/>
```

Element Plus 的 Dialog、Drawer、Table 都用这个模式——一旦理解本质，看官方组件源码不再神秘。

**子组件里实现**：

```vue
<script setup lang="ts">
const props = defineProps<{
  visible: boolean
  tab: string
}>()
const emit = defineEmits<{
  'update:visible': [v: boolean]
  'update:tab': [v: string]
}>()

// 关闭时通知父组件
function close() { emit('update:visible', false) }
function switchTab(t: string) { emit('update:tab', t) }
</script>
```

### 6.6 `defineExpose` 的使用时机

`<script setup>` 默认所有变量都是**私有**的——即使父组件通过 ref 拿到子组件实例也调不到。`defineExpose({ open })` 是**显式白名单**，把方法暴露给父。

**首选 Props/Emit，defineExpose 是最后手段**：

- 优先用 **Props / Emit**——数据流单向、事件流单向，最清晰。
- `defineExpose` 只用于「**父不得不命令式调用子**」的场景：Dialog 的 `open(id?)` 是典型——**父不给 props 只发命令**。
- **反例**：用 `defineExpose` 暴露内部数据给父读——**破坏封装**，应改用 emit 或 v-model。

### 6.7 三种父子交互模式的选型

| 模式 | 方向 | 场景 |
|---|---|---|
| **Props** | 父 → 子 | 数据下发，如 `disabled` 状态、初始值 |
| **Emit** | 子 → 父 | 事件通知，如 `save / delete / close` |
| **defineExpose** | 父 → 子（命令式） | 只有当父需要主动触发子行为、且用 props 表达不自然时 |
| **v-model** | 双向 | Props + `update:xxx` Emit 的组合语法糖 |

**决策树**：

```
需要给子传数据？        → Props
需要子通知父？          → Emit
需要双向绑定？          → v-model
父需要「命令」子做事？   → 优先想 Props（如 open 用 :open="true"）
                       → 实在不行才 defineExpose
```

### 6.8 抽 `MemberToolbar.vue`

从 `MemberListView.vue` 里把顶部操作栏抽出来：

```vue
<!-- src/views/member/MemberToolbar.vue -->
<template>
  <div class="member-toolbar">
    <el-button type="primary" @click="emit('add')">
      <el-icon><Plus/></el-icon>新增会员
    </el-button>
    <el-button type="danger" plain :disabled="disabledBatch" @click="emit('batchDelete')">
      <el-icon><Delete/></el-icon>批量删除
    </el-button>
    <el-button plain @click="emit('export')">
      <el-icon><Download/></el-icon>导出
    </el-button>
  </div>
</template>

<script setup lang="ts">
defineProps<{ disabledBatch: boolean }>()
const emit = defineEmits<{
  add: []
  batchDelete: []
  export: []
}>()
</script>

<style scoped>
.member-toolbar { display: flex; gap: 8px; }
</style>
```

主页改用：

```vue
<template #actions>
  <MemberToolbar :disabled-batch="!selected.length"
                 @add="onAdd"
                 @batch-delete="onBatchDelete"
                 @export="onExport"/>
</template>
```

主页从 300 行降到 260 行——**局部可读性显著提升**，`MemberToolbar` 未来还能被 `MemberDetailView`、`MemberImportView` 等其他会员相关页面复用。

### 6.9 抽列配置对象（可选）

如果表格列很稳定、且需要「隐藏列、列宽拖动」等能力，可以把列定义抽成数据：

```ts
// src/views/member/memberColumns.ts
import type { MemberVO } from '@/api/member'
import { GENDER, MEMBER_STATUS } from '@/utils/dict'

export interface ColumnConfig<T = any> {
  prop?: keyof T | string
  label: string
  width?: number | string
  minWidth?: number | string
  sortable?: 'custom' | boolean
  fixed?: 'left' | 'right'
  formatter?: (row: T) => string
  slot?: string   // 使用具名插槽渲染
}

const CARD_TYPE: Record<number, string> = { 1: '次卡', 2: '月卡', 3: '年卡' }

export const MEMBER_COLUMNS: ColumnConfig<MemberVO>[] = [
  { prop: 'name',   label: '姓名',   minWidth: 90 },
  { prop: 'phone',  label: '手机号', width: 130 },
  { label: '性别',  width: 60,   formatter: r => GENDER[r.gender] },
  { prop: 'birthday', label: '生日', width: 110 },
  { label: '会员卡', width: 90,   formatter: r => CARD_TYPE[r.cardType] },
  { label: '状态',  width: 80,   slot: 'status' },
  { prop: 'joinTime', label: '入会时间', width: 160, sortable: 'custom' },
  { label: '操作',  width: 240, fixed: 'right', slot: 'actions' },
]
```

列配置从**声明式模板**变成**数据驱动**——后续加隐藏列、拖动列宽等能力更容易。但**代价**是复杂：简单场景反而不如手写模板直观。**是否抽看规模**——本项目 8 列写死也 OK。

### 6.10 两种弹窗控制模式对比

`MemberFormDialog` 有两种控制方式：

**方式 A：`v-model:visible` + Props `editId?: number`** —— 父组件掌控所有状态：

```vue
<MemberFormDialog v-model:visible="dialogVisible" :edit-id="editingId" @saved="onSaved"/>
```

子组件里 `watch(() => props.visible)`：从 `false` 变 `true` 且带 `editId` 时拉详情，否则 reset。

**方式 B：`defineExpose({ open(id?) })`** —— 子组件自己管 state：

```vue
<MemberFormDialog ref="dialogRef" @saved="onSaved"/>
<!-- dialogRef.value?.open()  或  dialogRef.value?.open(row.id) -->
```

**选型建议**：

| 场景 | 选型 |
|---|---|
| 新增 + 编辑复用，弹窗关闭后完全 destroy | **方式 B** 更简洁——本项目主选 |
| Drawer 侧边常驻，或需要外部读弹窗状态 | **方式 A** 更好 |
| 弹窗内容非常复杂，需要外部动态改字段 | **方式 A** |
| 简单命令式打开 / 关闭 | **方式 B** |

**核心**：看场景，不要僵化。项目里两种都有用。

### 6.11 「过度抽象」反例

把一个只有 3 行的「新增按钮」抽成 `AddButton.vue` 组件：

```vue
<!-- ❌ 反例：AddButton.vue -->
<template>
  <el-button type="primary" @click="emit('click')">
    <el-icon><Plus/></el-icon>{{ text }}
  </el-button>
</template>
<script setup lang="ts">
defineProps<{ text: string }>()
const emit = defineEmits<{ click: [] }>()
</script>
```

**代价对比**：

| 抽前 | 抽后 |
|---|---|
| 主页 3 行 `<el-button ...>` | 主页 1 行 `<AddButton .../>` + import 1 行 = 2 行 |
| 单一文件 | 双文件 |
| 一目了然 | 得跳到子组件才看得清 |

**结论**：**净收益负数**。**Rule of Three——写第 3 次时才抽**。

### 6.12 联调剧本

1. 完成 `MemberToolbar.vue` 抽取，主页从 300+ 行降到 260 行左右。
2. 页面功能全跑一遍——新增、批量删、导出都能正常触发——**行为不变，代码更清爽**。
3. 用 `v-model:visible` 版本重写一遍 `MemberFormDialog`，与 `defineExpose` 版本并列放在项目里。
4. 在 `docs/COMPONENTS.md` 里写一份对比 README——两种模式各自的代码量、心智负担、可测试性。
5. 尝试把 3 行按钮抽成 `AddButton`——观察抽完后代码变多，感受**过度抽象**的坏味道。

### 6.13 常见坑

| 症状 | 原因 | 修法 |
|---|---|---|
| Props 直接改报 `Vue warn: mutating prop` | Props 是单向数据流 | emit 事件让父改，或用 `computed` 中转 |
| `defineEmits<{ saved: [] }>()` 语法报错 | Vue 版本 < 3.4，不支持元组简化语法 | 用 `(e: 'saved'): void` 老写法，或升级到 3.4+ |
| `v-model` 拿不到值 | 子组件没 emit `update:modelValue` | 检查 emit 事件名与 v-model 参数一致 |
| ref 拿到子组件但调不到方法 | 忘了 `defineExpose` | 补上 `defineExpose({ open })` |
| `defineProps<{ modelValue?: boolean }>()` 默认值不生效 | 类型式 Props 不能同时写默认值 | 用 `withDefaults(defineProps<...>(), { ... })` |
| 主页抽了 5 个子组件后代码更难读 | 过度抽象 | Rule of Three，两次以内先复制 |
| 组件命名 `myToolbar` PascalCase 报错 | Vue 组件应 PascalCase | 文件名 `MyToolbar.vue`，import 也用 PascalCase |
| 递归组件报 `component name is required` | 缺显式 name | `defineOptions({ name: 'MenuItem' })` |

### 6.14 练习

1. **必做**：把 `MemberListView.vue` 拆成 `MemberToolbar / MemberSearch / MemberColumns / MemberFormDialog / MemberDetailDrawer` 5 个组件 / 配置，主页保留在 150 行以内。交拆分前后的 `wc -l` 对比截图。
2. **必做**：给 `MemberFormDialog` 增加**双向绑定版本**——`v-model:visible` + Props `editId?: number`——与 `defineExpose({ open })` 版本共存，写一个 `docs/DIALOG_MODES.md` 对比 README。
3. **挑战**：把「教练管理」也做同样的组件拆分，观察是否有可以进一步上移到通用层的组件（如 `BaseToolbar` 抽出「新增 + 批量删除 + 导出」三段式）。**注意**：抽到通用层前先确认 3 个业务模块都会用它——否则又是过早抽象。
4. **挑战**：实现 `<PermButton>` 权限按钮——`v-permission="'member:delete'"` 指令自动根据 Pinia userStore 的权限清单决定是否显示。这是 Props + 自定义指令的组合，为 Day14 权限系统预热。

---

## Day13 全日总结

**知识产出**：

- 会员管理前端完整闭环：列表 + 弹窗 + 抽屉 + 删除 + 冻结
- AI 编写前端页面的 Prompt 六要素 + 四段式验收方法论
- 后台通用布局四组件（Layout / Header / Sidebar / Breadcrumb）
- 组件拆分三大契约（Props / Emit / defineExpose）与选型经验
- 路由 `meta` 作为菜单与面包屑的单一数据源

**代码产出**：

- `src/api/member.ts` 补齐 7 个方法
- `src/views/member/*` 完整 5 文件（列表 + 弹窗 + 抽屉 + Toolbar + 列配置）
- `src/api/coach.ts` + `src/views/coach/*` AI 生成三件套
- `src/layout/*` 布局四组件
- `docs/PROMPTS.md` 团队提示词模板
- `docs/DIALOG_MODES.md` 弹窗控制模式对比

**能力沉淀**：

- 手写业务模块用时从「1 天」压缩到「3 小时」
- AI 生成业务模块用时从「1 天」压缩到「1 小时」
- 后台外壳一次搭建全项目复用
- Element Plus 3 常见 API 差异（`:label` vs `:value`、`@close` vs `@closed`）形成肌肉记忆
- Vue 3.4 `defineEmits` 元组语法 + `v-model` 语法糖本质吃透

**下一日预告**：Day14 接入课程管理 + 排课日历，使用本讲的 AI 流程一次性生成三件套，深化「AI 是脚手架，人是架构师」的工程哲学；同时把权限系统（`v-permission` 指令 + Pinia userStore 权限清单）落地。
