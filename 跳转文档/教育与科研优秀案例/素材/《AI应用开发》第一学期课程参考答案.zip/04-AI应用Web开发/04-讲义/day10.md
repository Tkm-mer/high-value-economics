# 《AI 应用 Web 开发》 - 学生讲义（Day10：Spring AOP 实战 + Redis 缓存 + Spring 事务）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day09 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、DTO/VO、Result 统一响应、全局异常处理、参数校验、文件上传 OSS、代理模式与 AOP 五要素概念、`this` 调用不走代理的经典坑）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / Redis 8.0 / Lettuce（Spring Data Redis 默认）/ Spring Cache（`spring-boot-starter-cache`）/ IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day09 结束时，我们已经理解了 AOP 五要素 + 代理模式三形态 + `this` 调用不走代理的经典坑，但真正把 AOP 用在业务上还差一步。Day10 前 2 讲把「操作日志」这个团队规约级切面**从注解定义到异步落库**完整落地；中间 2 讲把 Redis 8 请进后端，让读接口性能提升 300×；最后 2 讲把 `@Transactional` 讲透，并处理「缓存 + 事务共存陷阱」这道最后一道工程折衷坎。Day10 结束后，会员 / 课程 / 科目三条业务线拥有「审计 + 加速 + 一致」三大能力，为 Day11 的预约管理与状态机奠基。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | `@Around` 统一记录会员操作日志 | `@OperationLog` 注解 + `OperationLogAspect` 骨架，`tb_op_log` 落一行审计 |
| 第 2 讲 | 自定义 `@Log` 注解 + SpEL 取参数 | 一份切面适配全项目 CRUD，`#dto.name / #_ret` 动态取值 |
| 第 3 讲 | Redis 入门 + Spring Data Redis + `StringRedisTemplate` | Docker Redis 8 + `RedisConfig` JSON 序列化 + 短信限流 + 报名计数 |
| 第 4 讲 | Spring Cache `@Cacheable / @CacheEvict` + Redis 作缓存 | `SubjectService` 从 30ms 打到 3ms，三注解语义与差异 |
| 第 5 讲 | Spring 声明式事务 `@Transactional` | 5 种传播行为 + 4 大失效场景 + `REQUIRES_NEW` 记审计 |
| 第 6 讲 | 事务 + 缓存共存陷阱（双写一致性 + 方法内自调失效） | Cache Aside + 双删 + `@TransactionalEventListener(AFTER_COMMIT)` |

---

## 第 1 讲：`@Around` 统一记录会员操作日志

### 1.1 引入：从「AOP 概念」到「审计切面」的最后一步

Day09 结尾的 `TimingAspect` 已经证明 AOP 能在控制台 print 一行耗时——但真实项目要的是**可持久化、可查询、可追责**的审计日志：谁在什么时候、对哪个业务、做了什么。总不能在 300 个 Service 方法里各写一段 `insert into op_log`。

🎯 **一句话目标**：**只在 Service 方法上加一个注解，后台 `tb_op_log` 表自动落一行审计**——不改业务代码一行。

### 1.2 需求画像：一份完整的「后台操作日志」

管理员在瑜伽会馆后台的每一次「新增会员」「修改课程价格」「删除教练」都应该留痕，可查询、可追责。目标数据：

| 字段 | 说明 |
|---|---|
| operator | 操作者（管理员账号，从上下文取） |
| action | 动作描述（如「新增会员」） |
| module | 业务模块（member / course / coach…） |
| target_id | 业务主键 ID |
| method | 被调用的 Java 方法（`ClassName.methodName`） |
| args | 入参 JSON |
| result | 返回值 JSON（或异常信息） |
| success | 是否成功（1 / 0） |
| err_msg | 失败原因（截断到 500 字符） |
| ip | 请求来源 IP |
| cost_ms | 耗时 |
| create_time | 操作时间 |

💡 **约束**：**不改 Service 代码**——只在关键接口方法上加一个 `@OperationLog` 注解即可。

### 1.3 建表 SQL

```sql
CREATE TABLE tb_op_log (
  id          BIGINT PRIMARY KEY AUTO_INCREMENT,
  operator    VARCHAR(50)  NOT NULL DEFAULT 'anonymous',
  action      VARCHAR(100) NOT NULL,
  module      VARCHAR(50)  NOT NULL,
  target_id   VARCHAR(64),
  method      VARCHAR(255) NOT NULL,
  args        MEDIUMTEXT,
  result      MEDIUMTEXT,
  success     TINYINT      DEFAULT 1,
  err_msg     VARCHAR(500),
  ip          VARCHAR(45),
  cost_ms     INT,
  create_time DATETIME     DEFAULT CURRENT_TIMESTAMP,
  KEY idx_module      (module),
  KEY idx_operator    (operator),
  KEY idx_create_time (create_time)
) COMMENT '操作日志';
```

🎯 **两条工程约定**：
1. **大字段 `args / result` 用 `MEDIUMTEXT`**（16MB 上限，够绝大多数 JSON 序列化结果）——不要塞 `VARCHAR`；
2. **时间列 `create_time` 建索引**——日志表最常见的查询就是「按时间范围过滤」。

### 1.4 定义 `@OperationLog` 注解

```java
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperationLog {

    /** 动作描述，可包含 SpEL：#{'新增会员：' + #dto.name} */
    String value();

    /** 模块名：member / course / coach ... */
    String module();

    /** 目标 ID SpEL：#{#dto.id} 或 #{#id} */
    String targetIdEl() default "";

    /** 是否记录入参（大文件上传接口可关闭） */
    boolean logArgs() default true;

    /** 是否记录返回值 */
    boolean logResult() default false;
}
```

🎯 **两处设计要点**：
1. `@Retention(RetentionPolicy.RUNTIME)` —— **运行时保留**是必须的，否则 AOP 拿不到注解；
2. `value` 与 `targetIdEl` 支持 **SpEL 表达式**——同一个注解可以贴到不同方法上，动态取参数（第 2 讲展开）。

### 1.5 `@Around` 切面骨架

```java
@Aspect
@Component
@RequiredArgsConstructor
@Slf4j
public class OperationLogAspect {

    private final OpLogService opLogService;
    private final HttpServletRequest request;

    @Around("@annotation(op)")
    public Object around(ProceedingJoinPoint pjp, OperationLog op) throws Throwable {
        long start = System.currentTimeMillis();
        MethodSignature ms = (MethodSignature) pjp.getSignature();
        Method method = ms.getMethod();
        Object[] args = pjp.getArgs();

        OpLog record = new OpLog();
        record.setOperator(currentOperator());
        record.setModule(op.module());
        record.setMethod(method.getDeclaringClass().getSimpleName() + "." + method.getName());
        record.setIp(clientIp());
        if (op.logArgs()) record.setArgs(JsonUtil.stringify(args));

        Object ret = null;
        try {
            ret = pjp.proceed();
            record.setSuccess((byte) 1);
            if (op.logResult()) record.setResult(JsonUtil.stringify(ret));
            return ret;
        } catch (Throwable ex) {
            record.setSuccess((byte) 0);
            record.setErrMsg(StringUtils.abbreviate(ex.getMessage(), 500));
            throw ex;                                  // ★ 必须 rethrow
        } finally {
            record.setCostMs((int) (System.currentTimeMillis() - start));
            record.setAction(op.value());              // 第 2 讲改成 SpEL
            try {
                opLogService.saveAsync(record);
            } catch (Exception e) {
                log.error("[操作日志] 异步入库失败 {}", record, e);
            }
        }
    }

    private String currentOperator() {
        try { return String.valueOf(request.getAttribute("currentUser")); }
        catch (Exception ignore) { return "anonymous"; }
    }

    private String clientIp() {
        try {
            String xf = request.getHeader("X-Forwarded-For");
            if (xf != null && !xf.isBlank()) return xf.split(",")[0].trim();
            return request.getRemoteAddr();
        } catch (Exception ignore) { return "unknown"; }
    }
}
```

🎯 **三个关键 API**：
1. `@Around("@annotation(op)")` —— Spring 把方法上的注解**直接注入切面参数 `op`**，不需要再自己 `method.getAnnotation(...)`；
2. `ProceedingJoinPoint.proceed()` —— 执行业务方法，返回值必须**原样 return** 出去；
3. `try / catch(Throwable) / finally` 收敛正常与异常两条路径——**catch 必须 rethrow**。

### 1.6 异步落库

日志入库**不能阻塞业务响应**——单独线程池 + `@Async`：

```java
@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean("logExecutor")
    public ThreadPoolTaskExecutor logExecutor() {
        var pool = new ThreadPoolTaskExecutor();
        pool.setCorePoolSize(2);
        pool.setMaxPoolSize(4);
        pool.setQueueCapacity(500);
        pool.setThreadNamePrefix("op-log-");
        pool.setRejectedExecutionHandler(new ThreadPoolExecutor.DiscardOldestPolicy());
        pool.initialize();
        return pool;
    }
}

@Service
@RequiredArgsConstructor
public class OpLogService {

    private final OpLogMapper mapper;

    @Async("logExecutor")
    public void saveAsync(OpLog log) {
        try { mapper.insert(log); }
        catch (Exception e) {
            LoggerFactory.getLogger(getClass())
                .error("[操作日志] 落库失败 module={} method={}", log.getModule(), log.getMethod(), e);
        }
    }
}
```

💡 **口诀**：**日志掉了不能让业务掉**——`saveAsync` 里 catch 到 Exception 一律吞掉 + `log.error`，绝不能反噬主流程。

### 1.7 联调剧本

给 `MemberService.save` 加注解（本讲先用**静态字符串**占位，SpEL 下一讲讲）：

```java
@OperationLog(value = "新增会员", module = "member")
public Long save(MemberDTO dto) { ... }
```

**成功场景**：
- Postman `POST /members` body `{"name":"张三","phone":"13800138000"}` → 200；
- `SELECT * FROM tb_op_log ORDER BY id DESC LIMIT 1;` → 一行 `action=新增会员 module=member method=MemberService.save success=1 cost_ms=约 40`。

**失败场景**：
- 再传一次同姓同电话 → 触发 `BizException("姓名已存在")`；
- `tb_op_log` 应有一行 `success=0 err_msg=姓名已存在`，且 `cost_ms` 仍有值。

### 1.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 业务方法抛异常，前端却返回 200 | 切面 catch 里忘写 `throw ex`——**AOP 里 catch 必须 rethrow** |
| 业务方法有返回值，接口 `data` 是 null | 切面方法签名写成 `void` 而不是 `Object`；或漏了 `return ret` |
| `record.setMethod(...)` 打出 `[Ljava.lang.Object;@xxx` | `args` 直接 `.toString()` 了，要用 Jackson 序列化 |
| `MultipartFile` 参数触发 `StackOverflowError` | 大对象白名单——`@OperationLog(logArgs=false)` 关掉 |
| 异步线程里取 `HttpServletRequest` 得到 null | 主线程先取好 IP / operator 放进 `OpLog` 对象再异步落库 |
| `@Async` 不生效 | 忘 `@EnableAsync`；或**同类 `this.saveAsync` 内部调用**（Day09 的坑再上演一次） |

### 1.9 练习 / 思考

1. **必做**：把 `@OperationLog(value="新增会员", module="member")` 贴到 `MemberService.save / update / delete` 三个方法上，联调三种场景（成功 / 姓名重复 / 主键不存在），交 3 张 `tb_op_log` 截图；
2. **必做**：整理「Spring AOP 常用切点表达式」速查表，覆盖 `@annotation() / execution(* com.yinxiang..service..*(..)) / within() / args()` 四种；
3. **思考**：切面里 `HttpServletRequest` 是**单例**吗？为什么并发请求下每个线程能拿到自己的 request？（提示：`RequestContextHolder` + `ThreadLocal`）；
4. **挑战**：把 `record.setMethod` 从 `MemberService.save` 升级成 `MemberService.save(MemberDTO)`——考虑参数类型的全限定名会不会太长。

---

## 第 2 讲：自定义 `@Log` 注解 + SpEL 取参数

### 2.1 引入：静态字符串顶不住 20 个 CRUD

上一讲的 `@OperationLog(value="新增会员", module="member")` 里 `value` 是**死字符串**——项目里有 20 个业务方法，每个都想在 `action` 里带上业务实体的名字（如「新增会员：张三」「删除课程：id=42」）。难道要在切面里 `switch(method.getName()) { case ... }`？

**SpEL** 就是为这个场景准备的：让 `value` 变成一个**微型模板**，从入参 / 返回值动态取值。

🎯 **一句话目标**：**让一份切面适配全项目所有 CRUD 方法**——不同业务只改注解字符串，不改切面代码。

### 2.2 SpEL 三件套

```java
private static final ParameterNameDiscoverer PND = new DefaultParameterNameDiscoverer();
private static final SpelExpressionParser    PARSER = new SpelExpressionParser();
private static final ParserContext           TPL_CTX = new TemplateParserContext("#{", "}");
```

| 组件 | 作用 |
|---|---|
| `DefaultParameterNameDiscoverer` | 解析方法参数名（依赖编译期 `-parameters`） |
| `SpelExpressionParser` | 解析 SpEL 表达式 |
| `TemplateParserContext("#{", "}")` | 声明 `#{...}` 是模板占位符，普通字符串按字面处理 |

### 2.3 装填 `EvaluationContext` 并求值

```java
private Object evalSpELRaw(String tpl, Method method, Object[] args, Object ret) {
    if (tpl == null || tpl.isEmpty()) return null;

    String[] names = PND.getParameterNames(method);
    EvaluationContext ctx = new StandardEvaluationContext();
    if (names != null) {
        for (int i = 0; i < names.length; i++) ctx.setVariable(names[i], args[i]);
    }
    ctx.setVariable("_ret", ret);   // ★ 内置变量：返回值

    return PARSER.parseExpression(tpl, TPL_CTX).getValue(ctx);
}

private String evalSpEL(String tpl, Method method, Object[] args, Object ret) {
    try {
        Object v = evalSpELRaw(tpl, method, args, ret);
        return v == null ? "" : String.valueOf(v);
    } catch (Exception e) {
        // ★ SpEL 报错不能反噬业务
        LoggerFactory.getLogger(getClass()).warn("[操作日志] SpEL 求值失败 tpl={}", tpl, e);
        return "";
    }
}
```

🎯 **三处要点**：
1. `ctx.setVariable(names[i], args[i])` —— 按参数名注入（`#dto`），**不推荐** `#p0 / #arg0` 索引方式；
2. `ctx.setVariable("_ret", ret)` —— 额外注入内置变量，让注解里能写 `#{#_ret}` 引用返回值；
3. **外层再包一层 `try-catch`**——SpEL 报错**必须**降级为空字符串 + `log.warn`，绝不能让审计切面拖垮业务。

### 2.4 `-parameters` 编译参数

Spring Boot Maven 项目默认已在 `spring-boot-maven-plugin` 里加了 `-parameters`——绝大多数学生开箱即用。**但**：

- 手写 pom / Gradle / 老项目升级——**都可能漏**；
- 漏了 `-parameters` 时，`PND.getParameterNames(method)` 返回 `["arg0"]`，注解里写 `#dto.name` 直接抛 `SpelEvaluationException: EL1008E-Property or field 'dto' cannot be found`；
- 排查口诀：**看到 `EL1008E` 立刻检查 `-parameters`**。

pom 显式配置：

```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-compiler-plugin</artifactId>
    <configuration>
        <parameters>true</parameters>
    </configuration>
</plugin>
```

### 2.5 使用示例：一份切面适配 5 个方法

```java
@OperationLog(value = "#{'新增会员：' + #dto.name}", module = "member",
              targetIdEl = "#{#_ret}")
public Long save(MemberDTO dto) { ... }

@OperationLog(value = "#{'修改会员：' + #dto.name}", module = "member",
              targetIdEl = "#{#dto.id}")
public void update(MemberDTO dto) { ... }

@OperationLog(value = "#{'删除会员：ids=' + #ids}", module = "member",
              targetIdEl = "#{#ids[0]}")
public void delete(List<Long> ids) { ... }

@OperationLog(value = "#{'发布课程：' + #id}", module = "course",
              targetIdEl = "#{#id}")
public void publish(Long id) { ... }

@OperationLog(value = "#{'新增课程：' + #dto.title}", module = "course",
              targetIdEl = "#{#_ret}", logResult = true)
public Long save(CourseDTO dto) { ... }
```

调用后 `tb_op_log` 五行：

```
action=新增会员：张三              target_id=1001
action=修改会员：张三              target_id=1001
action=删除会员：ids=[1001,1002]   target_id=1001
action=发布课程：42                target_id=42
action=新增课程：瑜伽入门          target_id=99
```

### 2.6 `logArgs / logResult` 开关的典型用例

**关闭 args**：文件上传接口 `upload(MultipartFile file)`——`MultipartFile` 触发 Jackson `StackOverflowError`：

```java
@OperationLog(value = "#{'上传头像'}", module = "member", logArgs = false)
public String upload(MultipartFile file) { ... }
```

**打开 result**：新增接口，返回值就是新记录 id——直接作为 `target_id`：

```java
@OperationLog(value = "#{'新增课程'}", module = "course",
              targetIdEl = "#{#_ret}", logResult = true)
public Long save(CourseDTO dto) { ... }
```

### 2.7 联调剧本

**正常场景**：
- Postman `POST /members` body `{"name":"张三"}` → 200；
- `tb_op_log` 一行 `action=新增会员：张三 target_id=<新 id> module=member`。

**SpEL 写错**：故意把 `#dto.name` 写成 `#dot.name`：
- 业务接口仍返回 200（业务没被反噬）；
- `tb_op_log` 一行 `action='' target_id=...`（SpEL 求值失败降级为空串）；
- 后台日志有一行 `WARN [操作日志] SpEL 求值失败 tpl=#{'新增会员：' + #dot.name}`。

### 2.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| SpEL 报错 `EL1008E: Property or field 'dto' cannot be found` | pom 没开 `-parameters`；或参数名与注解表达式不匹配 |
| 注解里 `key="'hot-top10'"` 报错 | SpEL 里**字符串常量要加单引号**，`hot-top10` 会被当成 SpEL 减法 |
| 注解写 `value = "#dto.name"` 拿到字面量 `#dto.name` | 忘了 `TemplateParserContext("#{", "}")`——**模板必须用 `#{...}` 包裹** |
| `#_ret` 报 null | 异常路径下 `ret` 是 null 属正常；注解里加 `?.`：`#{#_ret?.id}` |
| args 里能拿到值，`#dto` 拿不到 | 手写 pom 漏 `-parameters`，回到第 2.4 节 |
| 切面 SpEL 抛异常导致 500 | `evalSpEL` 外层没包 try-catch——**审计切面不能反噬业务** |

### 2.9 练习 / 思考

1. **必做**：把 Day07 的 `CourseService` 全部 CRUD 方法加上 SpEL 版 `@OperationLog`，5 个接口联调后交 `tb_op_log` 截图；
2. **必做**：给 `@OperationLog` 加一个新字段 `sensitive: String[]` 表示「入参哪些字段要脱敏」（如 `password / idCard`），落库前用 Jackson 覆盖为 `***`；
3. **思考**：`#dto.name` 与 `#dto?.name` 有何区别？（提示：Safe Navigation Operator，`null` 时返回 `null` 而不抛 `NullPointerException`）；
4. **挑战**：把 `@Log` 注解 + 切面抽成 `yinxiang-common` starter 模块，让整个团队 import 即用。

---

## 第 3 讲：Redis 入门 + Spring Data Redis + `StringRedisTemplate`

### 3.1 引入：MySQL 30ms vs Redis 0.1ms，300× 差距

Day08 的课程列表接口需要 3 张表 LEFT JOIN + 分页，SQL 平均耗时 30ms。前端首页每分钟刷新几十次，一天下来这条 SQL 被执行几十万次。**MySQL 磁盘 + 索引扫描的极限就在这里**——再优化 SQL 也逃不出 10ms 量级。Redis 内存访问约 0.1ms——**300× 性能差距**。

🎯 **一句话目标**：**今天先让 Redis 8 在 Docker 里跑起来，再让 Spring Boot 能用 `RedisTemplate` 读写 Redis，最后完成两个真实业务：短信限流 + 报名人数**。

### 3.2 Docker 起 Redis 8

```bash
docker run -d --name redis8 -p 6379:6379 redis:8.0
docker exec -it redis8 redis-cli
```

在 `redis-cli` 里：

```redis
127.0.0.1:6379> PING
PONG
127.0.0.1:6379> SET hello world EX 60
OK
127.0.0.1:6379> GET hello
"world"
127.0.0.1:6379> TTL hello
(integer) 58
```

- `PING → PONG` 是最经典的连通性检查；
- `SET k v EX 60` = 「设置 + 60 秒过期」一步完成；
- `TTL k` 查看剩余过期时间。

### 3.3 六大数据结构 & 印想瑜伽会馆场景

| 结构 | 命令 | 印想业务场景 |
|---|---|---|
| String | `GET/SET/INCR` | 会员登录 Token、课程报名计数 |
| Hash | `HSET/HGET` | 会员资料局部更新 |
| List | `LPUSH/RPOP` | 待推送短信队列、消息时间线 |
| Set | `SADD/SISMEMBER` | 会员标签去重、教练特长集合 |
| ZSet | `ZADD/ZRANGE` | 教练热度排行榜、课程报名榜 |
| Stream | `XADD/XREAD` | 轻量级操作日志消息总线 |

### 3.4 Spring Boot 4 依赖 + `application.yml`

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-pool2</artifactId>
</dependency>
```

```yaml
spring:
  data:
    redis:
      host: 127.0.0.1
      port: 6379
      password: ${REDIS_PASSWORD:}
      timeout: 3s
      lettuce:
        pool:
          max-active: 16
          max-idle: 8
          min-idle: 2
```

💡 **Lettuce 而非 Jedis**：Spring Boot 4 官方推荐 Lettuce——基于 Netty，天生支持异步与响应式，Jedis 已属老古董。

### 3.5 `RedisConfig` 自定义序列化（**必做**）

Spring Boot 默认 `RedisTemplate<Object,Object>` 使用 **JDK 序列化**——二进制乱码，跨语言不友好。必须自己配置一份 JSON 序列化版本：

```java
@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory f) {
        RedisTemplate<String, Object> tpl = new RedisTemplate<>();
        tpl.setConnectionFactory(f);

        var json = new GenericJackson2JsonRedisSerializer(objectMapper());
        var str  = new StringRedisSerializer();

        tpl.setKeySerializer(str);
        tpl.setHashKeySerializer(str);
        tpl.setValueSerializer(json);
        tpl.setHashValueSerializer(json);
        tpl.afterPropertiesSet();
        return tpl;
    }

    private ObjectMapper objectMapper() {
        var m = new ObjectMapper();
        m.registerModule(new JavaTimeModule());
        m.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        m.activateDefaultTyping(BasicPolymorphicTypeValidator.builder()
                .allowIfSubType("com.yinxiang").allowIfSubType("java.util").build(),
                ObjectMapper.DefaultTyping.NON_FINAL);
        return m;
    }
}
```

🎯 **三个约定**：
1. **Key 一律 String**——`StringRedisSerializer`，`redis-cli` 里能直接看到 `subject::1` 而不是二进制乱码；
2. **Value 用 JSON**——`GenericJackson2JsonRedisSerializer`，跨语言可读；
3. **`activateDefaultTyping`** —— 让 JSON 里带 `@class` 元信息，反序列化能还原成原类，而不是拿到一个 `LinkedHashMap` 然后 `.getName()` 抛 `ClassCastException`。

### 3.6 编程式用例一：手机号 60 秒发送限流

```java
@Service
@RequiredArgsConstructor
public class SmsService {

    private final StringRedisTemplate redis;

    public void send(String phone, String code) {
        String key = "sms:limit:" + phone;
        Boolean ok = redis.opsForValue()
            .setIfAbsent(key, "1", Duration.ofSeconds(60));
        if (!Boolean.TRUE.equals(ok)) {
            throw new BizException("发送过于频繁，请稍后再试");
        }
        // ... 真正调用短信服务
    }
}
```

🎯 **原子性关键**：`setIfAbsent(key, val, TTL)` **一次调用**完成「SET NX EX 60」，绝不允许 `set` + `expire` 两步——中间宕机会造成 key 永不过期。

### 3.7 编程式用例二：课程报名人数原子自增

```java
public void book(Long courseId, Long capacity) {
    Long v = redis.opsForValue().increment("course:booked:" + courseId);
    if (v > capacity) {
        redis.opsForValue().decrement("course:booked:" + courseId);
        throw new BizException("已满员");
    }
    // 真正写库逻辑
}
```

🎯 **为什么不能先 `GET` 再判断再 `INCR`**：`GET + 判断 + INCR` 三步不是原子操作，两个线程都能通过判断，最终库存超卖。`increment` 是 Redis 侧的**单命令原子**——多线程也不会超卖。

### 3.8 联调剧本

**短信限流**：
```
POST /sms/send   body: {"phone":"13800138000"}   →  200
POST /sms/send   body: {"phone":"13800138000"}   →  429 「发送过于频繁」
60 秒后再打                                        →  200
```

**报名超卖测试**：打开 2 个 Postman 标签，`courseId=1 capacity=10`，各自并发 POST 10 次——`SELECT count(*) FROM tb_booking WHERE course_id=1` 应严格 ≤ 10。

**乱码验证**：临时把 `RedisConfig` 注释掉，`redis-cli GET course:booked:1` 会看到 `"\xac\xed\x00\x05sr\x00\x11java.lang.Long..."`——**这就是不配置 `RedisConfig` 的下场**。

### 3.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `redis-cli GET k` 显示一堆 `\xac\xed` | 没自定义 `RedisConfig`，用了 JDK 序列化——立即配置 |
| 反序列化 Java 对象得到 `LinkedHashMap` | `ObjectMapper` 没开 `defaultTyping` |
| `LocalDateTime` 反序列化抛异常 | `ObjectMapper` 没 `registerModule(new JavaTimeModule())` |
| `setIfAbsent` 与 `expire` 分成两步写 | 中间宕机 key 永不过期——**必须**用 `setIfAbsent(k, v, TTL)` 三参数版本 |
| `Docker Desktop 未启动` | Windows 学生课前先启动，Linux 学生检查 `docker ps` 需否加 `sudo` |
| Redis 单 key > 1MB 慢查询暴涨 | 设计前评估大 key，超大集合改分片 |

### 3.10 练习 / 思考

1. **必做**：本机装好 Docker 与 Redis 8，`PING → PONG` 截图；
2. **必做**：把「手机号 60 秒限流」和「课程报名人数原子自增」两个业务都跑通，各交 2 张截图（Postman + `redis-cli`）；
3. **思考**：`RedisTemplate<String, Object>` 与 `StringRedisTemplate` 什么关系？（提示：后者是「Key 和 Value 都是 String」的特化）；
4. **挑战**：用 ZSet 实现「教练热度排行榜」——`ZADD coach:rank 42 张老师`，前端读取 `ZREVRANGE coach:rank 0 9 WITHSCORES`；思考「按周滚动」的 Key 设计。

---

## 第 4 讲：Spring Cache `@Cacheable / @CacheEvict` + Redis 作缓存

### 4.1 引入：从编程式到声明式

上一讲的 `redisTemplate.opsForValue().set(...)` 是**编程式**——每个读接口都要抄一遍「先 get，命中返回；不命中回源 DB，再 set 回缓存」的模板。**Spring Cache** 就是把这三步吞进注解里的**声明式**方案。

🎯 **一句话目标**：**让科目详情、课程详情两个读接口通过一个注解获得 300× 性能提升，且业务方法零改动**。

### 4.2 `@EnableCaching` + `RedisCacheManager`

```java
@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public RedisCacheManager cacheManager(RedisConnectionFactory f) {
        RedisCacheConfiguration base = RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(10))
            .serializeKeysWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new StringRedisSerializer()))
            .serializeValuesWith(RedisSerializationContext.SerializationPair
                    .fromSerializer(new GenericJackson2JsonRedisSerializer()))
            .disableCachingNullValues();

        Map<String, RedisCacheConfiguration> custom = Map.of(
            "course",  base.entryTtl(Duration.ofMinutes(5)),
            "subject", base.entryTtl(Duration.ofHours(1))    // 变更少
        );
        return RedisCacheManager.builder(f).cacheDefaults(base)
                .withInitialCacheConfigurations(custom).build();
    }
}
```

🎯 **分层配置**：
- `cacheDefaults(base)` —— 全局基线（10 分钟 TTL、String Key、JSON Value、禁 null）；
- `withInitialCacheConfigurations(Map)` —— 具名 cache 差异化：`subject` 1 小时（变更少）、`course` 5 分钟（变更中等）。

### 4.3 三大注解语义

| 注解 | 时机 | 语义 |
|---|---|---|
| `@Cacheable` | 方法前 | 查缓存，命中直接返回；未命中执行方法后写缓存 |
| `@CachePut` | 方法后 | **一定执行方法**，把返回值写缓存（用于「更新」场景） |
| `@CacheEvict` | 方法后 | 执行方法后删缓存（`beforeInvocation=true` 改为方法前） |

### 4.4 完整示例：`SubjectService`

```java
@Service
public class SubjectService {

    @Cacheable(cacheNames = "subject", key = "#id", unless = "#result == null")
    public SubjectVO detail(Long id) {
        return convert(subjectMapper.selectById(id));
    }

    @CachePut(cacheNames = "subject", key = "#dto.id")
    public SubjectVO update(SubjectDTO dto) {
        subjectMapper.update(convert(dto));
        return detail(dto.getId());
    }

    @CacheEvict(cacheNames = "subject", key = "#id")
    public void delete(Long id) {
        subjectMapper.deleteById(id);
    }

    @CacheEvict(cacheNames = "subject", allEntries = true)   // 清空整个 cache
    public void batchImport(List<SubjectDTO> list) {
        list.forEach(this::save);   // ★ 此处的 this. 是坑，见 4.7 节
    }
}
```

### 4.5 `condition` vs `unless`

| 属性 | 时机 | 例子 | 语义 |
|---|---|---|---|
| `condition` | 方法**前后**都可判 | `condition = "#id > 0"` | **满足**条件才介入缓存 |
| `unless` | 方法**后**判（能拿到 `#result`） | `unless = "#result == null"` | **除非**满足否则写缓存（取反语义） |

💡 **口诀**：**读用 `condition` 拦非法参数，写用 `unless` 拦坏结果**。

### 4.6 Redis Key 结构

Spring Cache 默认 Key = `cacheName::key`：

```redis
127.0.0.1:6379> KEYS subject::*
1) "subject::1"
2) "subject::2"
127.0.0.1:6379> GET subject::1
"{\"@class\":\"com.yinxiang.vo.SubjectVO\",\"id\":1,\"name\":\"瑜伽入门\",...}"
```

- 两个冒号 `::` 是默认分隔符；
- Spring Boot 4 默认没加 `key-prefix`，多服务共用 Redis 时建议在 `RedisCacheConfiguration.computePrefixWith(...)` 里加上 `service-name:` 前缀。

### 4.7 `this` 调用不走缓存（**同 `@Transactional` 一个坑**）

```java
public void batchImport(List<SubjectDTO> list) {
    for (SubjectDTO dto : list) {
        this.save(dto);   // ★ 不走代理，@CachePut 完全失效
    }
}
```

**症状**：`batchImport` 跑完 100 条数据，`redis-cli KEYS subject::*` 返回**空**——因为 `this.save` 是原始对象调用，不经过 CGLIB 代理。

**修法**：注入自己（自注入）：

```java
@Service
public class SubjectService {

    @Autowired
    private SubjectService self;

    public void batchImport(List<SubjectDTO> list) {
        for (SubjectDTO dto : list) self.save(dto);
    }

    @CachePut(cacheNames = "subject", key = "#dto.id")
    public SubjectVO save(SubjectDTO dto) { ... }
}
```

或者通过 `AopContext.currentProxy()` 拿到当前代理（需要 `@EnableAspectJAutoProxy(exposeProxy = true)`）。

### 4.8 联调剧本

**首次进库 → 二次命中缓存**：
- 打开 IDEA 控制台 `mybatis-plus.configuration.log-impl: StdOutImpl`；
- Postman `GET /subjects/1` → 控制台看到 `SELECT * FROM tb_subject WHERE id=1`，接口耗时 ~30ms；
- 再打 `GET /subjects/1` → 控制台 SQL **不再出现**，接口 ~3ms；
- `redis-cli KEYS subject::* → 1) "subject::1"`。

**`@CacheEvict` 生效**：
- `DELETE /subjects/1` → `KEYS subject::*` 应为空；
- 再 `GET /subjects/1` → 控制台 SQL 重新出现（缓存已被清）。

**`@CachePut` 生效**：
- `PUT /subjects` body `{"id":1,"name":"瑜伽进阶"}` → `GET subject::1` 已看到新名字。

### 4.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 加了 `@Cacheable` 但每次都进 DB | 类内 `this.detail(id)` 调用不走代理——注入 `self` 或改造调用链 |
| `key="hot-top10"` 报 SpEL 错误 | 字符串常量要加**单引号**：`key="'hot-top10'"` |
| Java 25 record 存 Redis 反序列化失败 | `ObjectMapper` 没开 `defaultTyping` 或 record 类不在 `allowIfSubType` 白名单 |
| 返回值是 null 也被缓存 | 加 `unless = "#result == null"`；或全局 `disableCachingNullValues` |
| `allEntries=true` 拖慢 Redis | 底层 SCAN 遍历该 cacheName 全部 key——海量数据慎用 |
| `@CacheEvict` 事务未提交就删 | 见第 6 讲——建议用 `@TransactionalEventListener(AFTER_COMMIT)` |

### 4.10 练习 / 思考

1. **必做**：给 `SubjectService.detail / update / delete` 加齐三注解，联调「首次进库 → 命中 → 更新回写 → 命中新值 → 删除穿透」五步剧本；
2. **必做**：给 `CourseService.hotTop10()` 加 `@Cacheable(cacheNames="course", key="'hot-top10'")`——注意字符串常量的单引号；
3. **思考**：`@CachePut` 与 `@Cacheable` 都能实现「更新 + 回写」，为什么更新场景用 `@CachePut`？（提示：`@Cacheable` 命中直接跳过方法体）；
4. **挑战**：`@CacheEvict(cacheNames="course", allEntries=true)` 会不会清掉同一个 Redis 里其他业务的 key？（提示：Spring Cache 只按 `cacheName::` 前缀）。

---

## 第 5 讲：Spring 声明式事务 `@Transactional`（传播行为 + 回滚规则）

### 5.1 引入：`@Transactional` 三个字符换来一致性

Day07 的会员注册接口里：

```java
public void register(MemberDTO dto) {
    memberMapper.insert(member);
    pointsMapper.insertInitialPoints(member.getId());   // 突然抛异常
}
```

如果 `insertInitialPoints` 抛异常，`tb_member` 的记录会不会回滚？**不会**——`@Transactional` 不是自动的，必须**显式声明**。今天把 Spring 事务的传播行为、回滚规则、失效场景讲透。

🎯 **一句话目标**：**能在 30 秒内定位任何『事务没生效』的报警——因为你已经背熟了 5 种传播 + 4 大失效**。

### 5.2 Spring 事务执行链路

```
调用 → AOP 代理 → TransactionInterceptor
     → getTransaction (BEGIN)
     → 方法体
     → normal ? commit : rollback
```

💡 **和 `@Cacheable / @Async / @OperationLog` 是同一套 AOP 机制**——理解一个就理解全部。**代理对象 ≠ `this`**：`this` 是原始实例，代理是 CGLIB 生成的子类实例。

### 5.3 五种主要传播行为

| 值 | 语义 | 印想瑜伽会馆场景 |
|---|---|---|
| `REQUIRED`（默认） | 有事务加入，没有则新建 | 90% 业务方法 |
| `REQUIRES_NEW` | 挂起外层事务，新开一个 | 记审计日志、发短信——**不希望被外层回滚** |
| `NESTED` | 嵌套 SAVEPOINT，可独立回滚 | 复杂业务分块 |
| `SUPPORTS` | 有则加入，没有以非事务运行 | 只读方法 |
| `NEVER / MANDATORY / NOT_SUPPORTED` | 罕用 | 特殊校验 |

隔离级别一笔带过：Spring 默认使用**数据库默认**，MySQL 是 `REPEATABLE_READ`。**绝大多数业务保留默认**，除非你明确知道要什么。

### 5.4 四大失效场景（**必背**）

#### 场景 A：`this.method()` 内部调用

```java
@Service
public class MemberService {
    public void register(MemberDTO dto) {
        memberMapper.insert(...);
        this.savePoints(...);   // ★ 不走代理
    }

    @Transactional
    public void savePoints(...) {
        pointsMapper.insert(...);
        throw new RuntimeException("boom");
    }
}
```

- `savePoints` 抛异常，`tb_points` 不回滚——**`tb_member` 也不回滚**（外层根本没有事务）；
- **修法**：注入 `@Autowired private MemberService self; self.savePoints(...)`；
- 或者把 `savePoints` 拆到另一个 Service 类。

#### 场景 B：catch 未 rethrow

```java
@Transactional
public void register(MemberDTO dto) {
    memberMapper.insert(...);
    try {
        pointsMapper.insert(...);   // 抛异常
    } catch (Exception e) {
        log.warn("积分入库失败", e);   // ★ 事务不知道该回滚
    }
}
```

- 事务照常提交——`tb_member` 有数据，`tb_points` 无数据；
- **修法**：要么 rethrow，要么显式：`TransactionAspectSupport.currentTransactionStatus().setRollbackOnly()`。

#### 场景 C：默认不回滚受检异常

```java
@Transactional
public void register(MemberDTO dto) throws IOException {
    memberMapper.insert(...);
    throw new IOException("外部系统故障");   // 受检异常
}
```

- Spring 默认只对 `RuntimeException / Error` 回滚——受检异常照常提交；
- **修法**：`@Transactional(rollbackFor = Exception.class)`。

#### 场景 D：方法非 public

```java
@Transactional
private void register(MemberDTO dto) { ... }   // ★ private
```

- Spring AOP 只切 public——`@Transactional` 是死代码；
- **修法**：改回 public。

### 5.5 `REQUIRES_NEW` 的正确姿势

场景：会员预约课程失败要记 `tb_audit_log`——外层事务回滚时**审计不能丢**。

```java
@Service
public class AuditService {
    private final AuditMapper auditMapper;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void write(AuditLog log) {
        auditMapper.insert(log);
    }
}

@Service
@RequiredArgsConstructor
public class BookingService {
    private final AuditService auditService;   // ★ 必须通过代理调用

    @Transactional(rollbackFor = Exception.class)
    public void book(BookingDTO dto) {
        try {
            bookingMapper.insert(...);
            stockService.reduce(dto);
        } catch (Exception e) {
            auditService.write(new AuditLog("预约失败:" + e.getMessage()));
            throw e;
        }
    }
}
```

**联调**：故意让 `stockService.reduce` 抛 `BizException("已满员")`：
- `tb_booking` 无数据（外层事务回滚）；
- `tb_audit_log` **有数据**（内层独立事务已提交）。

### 5.6 联调剧本

| 场景 | 操作 | 预期 |
|---|---|---|
| A—`this` 坑 | 保持 `this.savePoints`，注册张三 | `tb_member` 已有脏数据，`tb_points` 无 |
| A—修正 | 改用 `self.savePoints` 再注册李四 | 两表都无数据 |
| B—catch 未 rethrow | 保持 catch，注册王五 | `tb_member` 有，`tb_points` 无 |
| C—受检异常 | 保持默认 `@Transactional`，抛 `IOException` | 不回滚 |
| C—修正 | 加 `rollbackFor = Exception.class` | 回滚 |
| D—private | 把方法改成 private | 事务完全不生效 |
| `REQUIRES_NEW` | 外层抛异常 | `tb_booking` 无，`tb_audit_log` 有 |

### 5.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 抛 `RuntimeException` 但事务不回滚 | 检查是否 `this.method()` 内部调用 |
| 抛受检异常事务不回滚 | 加 `rollbackFor = Exception.class` |
| catch 后再 throw 事务不回滚 | 事实上会回滚——只要**最终 rethrow**就行 |
| `@Async` 方法里事务不生效 | 事务绑定线程，异步线程是新线程——需要在异步方法里再声明 `@Transactional` |
| 长事务导致锁等待超时 | `transactionManager.default-timeout: 30` 强制超时 |
| Java 25 record 作 DTO 用不了 `@Transactional`？ | 事务加在 Service 方法上——DTO 是不是 record 无关 |

### 5.8 练习 / 思考

1. **必做**：把四大失效场景各写一个 Demo，交 8 张截图（每场景 = 错前 + 修后 两张）；
2. **必做**：给 `BookingService.book` 加 `@Transactional(rollbackFor = Exception.class)`，`AuditService.write` 加 `REQUIRES_NEW`，联调「预约失败但审计留痕」剧本；
3. **思考**：给下面这段代码画传播图，判断 b 和 c 分别是否回滚：
   ```java
   @Transactional public void a() { b(); c(); }
   @Transactional(propagation = REQUIRES_NEW) public void b() { insert(); }
   @Transactional public void c() { throw new RuntimeException(); }
   ```
   （前提：b、c 通过 Spring 代理调用）；
4. **挑战**：查 Spring 源码 `TransactionAspectSupport.invokeWithinTransaction`，画详细流程图。

---

## 第 6 讲：事务 + 缓存共存陷阱（双写一致性 + 方法内自调失效）

### 6.1 引入：把前 5 讲拼一起的最后一道坎

第 4 讲：读接口用 `@Cacheable` 打到 300× 提速。
第 5 讲：写接口用 `@Transactional` 保证一致。
**现在把两者拼一起**：`SubjectService.update` 既要 `@Transactional` 又要 `@CacheEvict`。

反问三连：
- **先执行哪个**？
- **事务提交前删还是提交后删**？
- **如果之间有并发读会不会脏读**？

学生一般会答「先删缓存再写库」——今天要打破这个直觉。

🎯 **一句话目标**：**掌握「Cache Aside + 双删 + `AFTER_COMMIT`」= 缓存与事务共存的工程折衷**。

### 6.2 Cache Aside Pattern（旁路缓存）

**读路径**：
```
cache.get(k)
  ├── hit  →  return
  └── miss →  db.query → cache.set → return
```

**写路径**：
```
db.update
  →  cache.delete   (★ 不是 update)
```

🎯 **两条原则**：
1. **写库在前，删缓存在后**——不是先删再写；
2. **是删缓存，不是更新缓存**——改缓存时算错、字段漏改比「下一次读时回源」更危险。

**为什么不能「先删缓存再写库」**：写库失败 = 缓存已丢 + 数据未变，下一次读会**重新写入旧数据**，缓存永远比数据库旧。

### 6.3 三大缓存问题速查

| 问题 | 现象 | 解决方案 |
|---|---|---|
| 穿透 | 查必然不存在的 key（如 id=-1），缓存永远不命中 | ① 空值也缓存 + 短 TTL ② 布隆过滤器（Guava `BloomFilter`） |
| 击穿 | 热点 key 过期瞬间，大量并发穿到 DB | ① 互斥锁（`setIfAbsent` 抢锁）+ 递归重试 ② 物理不过期 + 逻辑过期 |
| 雪崩 | 大量 key 同时过期或 Redis 挂 | ① TTL 加随机抖动（`5min + Random(0,60s)`） ② Caffeine 本地缓存兜底 ③ Redis 哨兵 / 集群 |

#### 6.3.1 击穿：互斥锁示例

```java
public SubjectVO detailSafe(Long id) {
    String key = "subject::" + id;
    Object cache = redis.opsForValue().get(key);
    if (cache != null) return (SubjectVO) cache;

    String lock = "lock:subject:" + id;
    Boolean got = redis.opsForValue().setIfAbsent(lock, "1", Duration.ofSeconds(3));
    if (Boolean.TRUE.equals(got)) {
        try {
            SubjectVO db = loadFromDb(id);
            redis.opsForValue().set(key, db, Duration.ofMinutes(5));
            return db;
        } finally { redis.delete(lock); }
    } else {
        Thread.sleep(50);
        return detailSafe(id);   // 递归重试
    }
}
```

### 6.4 双删补偿

**并发脏读时序**：

```
时间 →
  A 写库中 ─────────────────────→ 事务提交 → 删缓存
                B 读缓存未命中 → 回源 DB → 读到旧数据 → 写回缓存
                                                                        C 读到旧数据 (× 灾难)
```

**双删补偿方案**：

```java
public void update(SubjectDTO dto) {
    subjectMapper.update(convert(dto));
    redis.delete("subject::" + dto.getId());          // 立即删
    executor.schedule(
      () -> redis.delete("subject::" + dto.getId()),  // 500ms 后再删一次
      500, TimeUnit.MILLISECONDS);
}
```

- 500ms 是经验值——只要**大于**并发读的回源时间即可；
- 面试如果追问「强一致性怎么办」——答：**用 Canal 订阅 MySQL binlog 异步同步**（本课不深入，方向即可）。

### 6.5 `@TransactionalEventListener(AFTER_COMMIT)`——事务里删缓存的正确姿势

**反例**：直接 `@Transactional + @CacheEvict` 同时贴在方法上：

```java
@Transactional
@CacheEvict(cacheNames = "subject", key = "#dto.id")
public void update(SubjectDTO dto) {
    subjectMapper.update(convert(dto));
    // 事务未提交，此刻缓存已删！
    // 并发读线程回填旧数据；如果事务最终回滚 → 缓存和数据库都是旧
}
```

**正例**：改用事件发布 + `AFTER_COMMIT` 监听：

```java
@Service
@RequiredArgsConstructor
public class SubjectService {

    private final ApplicationEventPublisher publisher;

    @Transactional
    public void update(SubjectDTO dto) {
        subjectMapper.update(convert(dto));
        publisher.publishEvent(new SubjectUpdatedEvent(dto.getId()));
    }
}

@Component
@RequiredArgsConstructor
public class SubjectCacheListener {

    private final StringRedisTemplate redis;
    private final TaskScheduler scheduler;

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onUpdated(SubjectUpdatedEvent e) {
        String key = "subject::" + e.id();
        redis.delete(key);
        scheduler.schedule(() -> redis.delete(key),
            Instant.now().plusMillis(500));
    }
}
```

🎯 **关键**：`AFTER_COMMIT` 保证「事务真正提交完」才删缓存——事务回滚时监听器**根本不执行**，避免「回滚后缓存丢失」。

### 6.6 方法内自调再一次栽

第 4 讲遇到过的坑，Day10 结束前再看一次——**同类 `@Cacheable / @CachePut / @CacheEvict` 方法互相调用一律不走代理**：

```java
public void batchImport(List<SubjectDTO> list) {
    list.forEach(this::save);   // ★ this 不走代理，@CachePut 完全失效
}
```

**症状**：`batchImport` 完成后 `KEYS subject::*` 是**空**。

**三种修法**：

```java
// 修法 1：自注入
@Autowired private SubjectService self;
list.forEach(self::save);

// 修法 2：AopContext（需要 @EnableAspectJAutoProxy(exposeProxy = true)）
SubjectService proxy = (SubjectService) AopContext.currentProxy();
list.forEach(proxy::save);

// 修法 3：拆到不同 Service
list.forEach(subjectSaveService::save);
```

### 6.7 联调剧本

**脏读复现**：
- 在 `SubjectService.update` 里故意加 `Thread.sleep(1000)` 模拟慢事务；
- 打开 2 个 Postman：A `PUT /subjects/1` 改标题为「瑜伽进阶」，B 循环 `GET /subjects/1`；
- **反例场景**（`@CacheEvict` 直接贴在方法上）：B 在 A 慢事务期间反复回填旧数据 → 一致性窗口 = 事务耗时 + 缓存 TTL；
- **正例场景**（改造为 `AFTER_COMMIT` + 双删）：脏读窗口收敛到 500ms 内。

**自调坑复现**：
- `batchImport(3 条)` 跑完 → `KEYS subject::*` 应为空（`this.save` 未触发 `@CachePut`）；
- 改成 `self.save` 再跑一次 → `KEYS` 应有 3 个 key。

### 6.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `@TransactionalEventListener` 完全不执行 | 事件所在方法没加 `@Transactional`（Spring 4.2+ 默认 `fallbackExecution=false`） |
| 并发读拿到旧数据即使加了 `@CacheEvict` | 事务未提交就删了缓存，B 线程回填旧数据；改用 `AFTER_COMMIT` |
| 方法内 `this.save` 不触发 `@CachePut` | 自注入 `self` 或用 `AopContext.currentProxy()` |
| 加了双删仍偶发不一致 | 500ms 不够——按业务实际的「并发读回源耗时」调大，或引入 Canal binlog |
| `@Cacheable` 与 `@Transactional` 加在同一方法上导致重复代理链 | 不是 Bug，只是代理链变长；性能可接受，无需拆分 |
| 布隆过滤器加载超慢 | 启动时 `SELECT id FROM ...` 全表扫描——数据量大时用分批 `LIMIT` |

### 6.9 Day10 全景回顾

Day10 交付物盘点：

| 能力 | 组件 | 交付物 |
|---|---|---|
| 审计 | `@OperationLog` + `OperationLogAspect` + `tb_op_log` | 全项目审计，一份切面适配所有 CRUD |
| 加速 | Redis 8 + `RedisConfig` + `@Cacheable / @CachePut / @CacheEvict` | 读接口 300× 提速 |
| 一致 | `@Transactional` + `REQUIRES_NEW` + `AFTER_COMMIT` 事件 + 双删补偿 | 事务与缓存共存 |

### 6.10 练习 / 思考

1. **必做**：把 `SubjectService.update` 改造为 `@TransactionalEventListener(AFTER_COMMIT)` 清缓存 + 双删补偿，交并发脏读复现前后对比截图；
2. **必做**：给 `CourseService.detail` 加「TTL 5 分钟 + `Random(0, 60秒)` 抖动」的雪崩防护——提示：`RedisCacheConfiguration.entryTtl` 只支持固定值，需自定义 `RedisCacheWriter` 或编程式实现；
3. **思考**：如果 Redis 主从复制存在延迟，`AFTER_COMMIT` 删主节点后，从节点的旧数据还会被读到吗？如何解决？（提示：主从延迟、强制主读、Redis 读写分离策略）；
4. **挑战**：用 Guava `BloomFilter` 给 `SubjectService.detail` 加上布隆过滤器兜底——启动时把 `SELECT id FROM tb_subject` 全灌进过滤器，非法 id 直接短路。

---

## Day10 结语

至此 Day10 六讲把「审计（AOP）+ 加速（缓存）+ 一致（事务）」三大能力全部装进印想瑜伽会馆系统。Day11 开始进入**预约管理 CRUD + 状态机**——你会用到今天所有的工具：审计留痕、Redis 计数（报名人数）、事务保证「扣减库存 + 生成预约」原子性。今天所有的工程折衷都会在明天的高并发场景里被再次验证。
