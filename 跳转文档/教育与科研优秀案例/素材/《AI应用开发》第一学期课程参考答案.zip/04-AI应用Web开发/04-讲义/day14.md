# 《AI 应用 Web 开发》 - 学生讲义（Day14：课程管理前端 + 表单校验体系 + 系统日志前端）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day13 的学生（掌握 Spring Boot 4.0.x 后端全链路、JWT 登录、AOP 操作日志、课程 / 教练 / 教室后端接口、Vue 3 工程化、VueRouter 4、Axios 二次封装、Pinia、Element Plus 按需引入、PageContainer / SearchBar / ProTable 三件套、会员管理前端）**

**技术版本基线**：Node.js 20 LTS / pnpm 9.x / Vue 3.5.x / Vite 5.x / TypeScript 5.x / vue-router 4.x / pinia 3.x / axios 1.7+ / element-plus 3.x / @vueuse/core 10.x / dayjs 1.11+ / IDEA 2024.3+ / VS Code / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统 `yoga-admin`（前端管理后台）。Day13 我们已经把会员管理这条业务线完整搬进 `yoga-admin`——一份「列表 + 弹窗表单」的 CRUD 模板；但真实项目里，课程这类实体的字段数是会员的两倍、外键关联三方、还带时段冲突这样的业务级校验，一个弹窗根本装不下。Day14 前 3 讲把**课程管理前端**从零落地：先把「列表页 + 多条件搜索 + 关联展示」的骨架搭起来，再把独立路由的**编辑页**与「科目 → 教练」级联下拉、教室下拉、日期时段选择器一起交付，最后把课程发布 / 下架 / 单删 / 批删的**业务确认弹窗**接上第 15-16 章后端。中间 1 讲把 Element Plus 的**表单校验体系**做一次系统性总结——分层图 + 内置规则 + 异步 `validator` + 跨字段校验 + 抽取到 `utils/validators.ts` 的团队级复用。第 5 讲把**系统操作日志**页面落地：对接 Day10 交付的 `/op-logs` 后端，时间区间 + 状态 + 模块过滤，抽屉详情页展示 JSON 美化的请求参数、返回结果、异常堆栈，附带 CSV 导出。最后 1 讲把「前端异常处理体系」补齐——Axios 拦截器统一处理 401 / 403 / 500 / 网络错误，`ElMessage` 与 `ElNotification` 的语义分工、`toastErr` 工具函数、页面级 try-catch 与全局 `unhandledrejection` 兜底。跑完 Day14 六讲，`yoga-admin` 前端管理后台已经覆盖了「会员 / 课程 / 教练 / 教室 / 日志」全部业务模块，具备完整的**校验 + 反馈 + 审计**能力，是一个真实可交付的管理端产品。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 课程列表页 —— 多条件搜索与关联展示 | `CourseListView.vue`：SearchBar 5 项 + ProTable 9 列 + 状态字典 + `dateRange` watch 拆分 |
| 第 2 讲 | 课程新增 / 修改 —— 独立路由页 + 级联下拉 | `CourseEditView.vue`：`courses/edit/:id?` 路由 + 4 组字段 + `coachesFiltered` computed + 300ms 防抖冲突预检 |
| 第 3 讲 | 课程删除 + 业务确认（发布 / 下架 / 单删 / 批删） | `ElMessageBox` 三色语义 + `v-if` 按状态显隐 + 保存双重确认 + `router.replace` 返列表 |
| 第 4 讲 | Element Plus 表单校验体系（同步 + 异步 + 自定义） | 六层校验分层图 + `FormItemRule` 10 字段 + Promise 风格 validator + `validators.ts` 常量与工厂 |
| 第 5 讲 | 系统日志前端页面（对接 AOP + 时间区间 + 导出） | `OpLogListView.vue` + `OpLogDetailDrawer.vue` + `JsonBlock.vue` + CSV 导出四步式 |
| 第 6 讲 | 前端异常处理体系 + 友好提示 | Axios 拦截器四分支 + `BizError` + `toastErr` + Message/Notification 分工 + 全局 `unhandledrejection` |

---

## 第 1 讲：课程列表页 —— 多条件搜索与关联展示

### 1.1 引入：为什么会员管理的模板不够用

Day13 我们把会员管理页做完了，模板是「一个弹窗装下 8 个字段」。今天要落地的课程管理页，字段数是会员的两倍多，外键关联科目 / 教练 / 教室三方，还有开课时间和报名截止两组日期字段，UED 给的高保真原型里筛选条件就有 5 个。如果继续套用「一个弹窗」的做法，弹窗一打开会把用户按在椅子上下不来。所以今天开始，我们把课程页拆成**列表页 + 独立路由编辑页**两块，先把列表骨架跑通。

🎯 **一句话目标**：**列表页 = SearchBar 5 项 + ProTable 9 列 + 状态字典**，字段与关联对象靠后端 join 一次冗余返回，前端不再翻译。

### 1.2 会员管理 vs 课程管理的六维差异

```
维度         会员            课程
字段数       8               15+
关联对象     无              科目 / 教练 / 教室
时间字段     生日            开课~结束 + 报名截止
状态流转     正常 / 冻结     未发布 → 报名中 → 已满 → 已开课 → 已结束
校验复杂度   字段级          字段级 + 业务级冲突检测
交互形态     单弹窗          弹窗新增 + 独立路由编辑页
```

这六个维度里，字段数和状态流转决定了「一个弹窗塞不下」；校验复杂度里的**业务级冲突检测**决定了保存前得预检一次；交互形态里的独立路由页决定了 URL 要多加一条 `courses/edit/:id?`。

### 1.3 API 层：三个 TypeScript 接口 + 八个方法

新建 `src/api/course.ts`：

```ts
import request from './request'
import type { PageResult } from './types'

export type CourseStatus = 1 | 2 | 3 | 4 | 5
// 1 未发布 2 报名中 3 已满 4 已开课 5 已结束

export interface CourseVO {
  id: number
  title: string
  subjectId: number
  subjectName: string          // 冗余：后端 join 一次
  coachId: number
  coachName: string
  roomId: number
  roomName: string
  startTime: string            // YYYY-MM-DD HH:mm
  endTime: string
  enrollDeadline: string
  capacity: number
  enrolled: number
  price: number
  status: CourseStatus
  cover?: string
  intro?: string
}

export interface CourseFormDTO {
  id?: number
  title: string
  subjectId?: number
  coachId?: number
  roomId?: number
  timeRange?: [string, string] // 前端表单专用，提交时拆成 startTime / endTime
  enrollDeadline?: string
  capacity: number
  price: number
  cover?: string
  intro?: string
}

export interface ConflictVO {
  coachConflict?: { id: number; title: string; startTime: string; endTime: string }
  roomConflict?:  { id: number; title: string; startTime: string; endTime: string }
}

export const courseApi = {
  page:     (q: any)        => request.get<any, PageResult<CourseVO>>('/courses', { params: q }),
  detail:   (id: number)    => request.get<any, CourseVO>(`/courses/${id}`),
  create:   (dto: any)      => request.post<any, number>('/courses', dto),
  update:   (dto: any)      => request.put<any, void>('/courses', dto),
  publish:  (id: number)    => request.post<any, void>(`/courses/${id}/publish`),
  offline:  (id: number)    => request.post<any, void>(`/courses/${id}/offline`),
  remove:   (ids: number[]) => request.delete<any, void>('/courses', { data: ids }),
  /** 冲突预检：新增/编辑保存前调，展示冲突提示但不阻断（后端最终校验） */
  checkConflict: (p: { id?: number; coachId: number; roomId: number; startTime: string; endTime: string })
                => request.post<any, ConflictVO>('/courses/check-conflict', p)
}
```

**要点**：

- `CourseVO` 里带 `subjectName / coachName / roomName` 是**冗余字段**——后端 join 一次，前端不再查字典翻译；代价是外键改名后要重刷缓存。
- `CourseFormDTO` 里的 `timeRange: [string, string]` 是**前端表单专用**——`el-date-picker type="datetimerange"` 天然吐两元素数组；提交前会拆成 `startTime / endTime` 两个字段发给后端。
- `ConflictVO` 结构 `{ coachConflict?, roomConflict? }` 承载后端预检返回，两个 key 都是可选，都缺就是没冲突。
- 同理准备 `subjectApi.list()` / `coachApi.simpleList()` / `roomApi.simpleList()`，返回 `{ id, name }` 数组（教练额外带 `subjectIds` 便于前端过滤）。

### 1.4 状态字典：集中管理避免 magic number

在 `src/utils/dict.ts` 里定义：

```ts
export const COURSE_STATUS = {
  1: { label: '未发布', type: 'info'    },
  2: { label: '报名中', type: 'success' },
  3: { label: '已满',   type: 'warning' },
  4: { label: '已开课', type: 'primary' },
  5: { label: '已结束', type: 'info'    }
} as const
```

`as const` 把 label 与 type 收窄成字面量类型，避免 IDE 补全时看不到具体值。使用姿势：

```vue
<el-tag :type="COURSE_STATUS[row.status].type">
  {{ COURSE_STATUS[row.status].label }}
</el-tag>
```

在 `el-select` 里遍历：

```vue
<el-option v-for="(v, k) in COURSE_STATUS" :key="k" :label="v.label" :value="+k"/>
```

⚠️ 注意 `:value="+k"`：`Object.keys` 返回的字符串 `'1'` 用 `+` 强制转 number，否则筛选参数发到后端类型对不上，Java 端反序列化会报 `NumberFormatException`。

### 1.5 列表页字段规划：5 个筛选 + 9 列表格

**5 个筛选条件**：

| 筛选项 | 控件 | 关键属性 |
|-------|-----|--------|
| 课程名 | `el-input` | `clearable`，模糊搜索 |
| 科目 | `el-select` | `<10` 项不需 filterable |
| 教练 | `el-select` | `filterable`，教练量可能上百 |
| 状态 | `el-select` | 枚举 5 项，`+k` 转 number |
| 开课时段 | `el-date-picker daterange` | `value-format="YYYY-MM-DD"` |

**9 列表格**：

| 列 | 类型 | 关键属性 |
|---|-----|---------|
| 多选 | `type="selection"` | `width="42"` |
| 课程名 | 主要列 | `min-width="180"`，`el-link` 跳编辑 |
| 科目 | 冗余字段 | `width="90"` |
| 教练 | 冗余字段 | `width="90"` |
| 教室 | 冗余字段 | `width="90"` |
| 开课时间 | 拼接列 | `width="260"`，`{{ startTime }} ~ {{ endTime }}` |
| 报名进度 | 满员高亮 | `width="90"`，`:class="{ full: row.enrolled >= row.capacity }"` |
| 价格 | 数字列 | `width="80"`，`¥{{ row.price.toFixed(2) }}` |
| 状态 | tag 列 | `width="90"`，用字典映射 |
| 操作 | 固定右侧 | `width="200"`，`fixed="right"` |

`min-width` 用于主要展示列，`width` 用于短字段固定宽，`fixed="right"` 让操作列在横向滚动时贴右不动。

### 1.6 完整实现：`CourseListView.vue`

```vue
<template>
  <PageContainer title="课程管理">
    <template #actions>
      <el-button type="primary" @click="$router.push('/courses/edit')">新增课程</el-button>
      <el-button type="danger" plain :disabled="!selected.length"
                 @click="onBatchDelete">批量删除</el-button>
    </template>

    <SearchBar :model="q" @search="tableRef?.resetToFirst()" @reset="tableRef?.resetToFirst()">
      <el-form-item label="课程名"><el-input v-model="q.title" clearable/></el-form-item>
      <el-form-item label="科目">
        <el-select v-model="q.subjectId" clearable style="width:120px">
          <el-option v-for="s in subjects" :key="s.id" :label="s.name" :value="s.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="教练">
        <el-select v-model="q.coachId" clearable filterable style="width:120px">
          <el-option v-for="c in coaches" :key="c.id" :label="c.name" :value="c.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="q.status" clearable style="width:120px">
          <el-option v-for="(v, k) in COURSE_STATUS" :key="k" :label="v.label" :value="+k"/>
        </el-select>
      </el-form-item>
      <el-form-item label="开课时段">
        <el-date-picker v-model="dateRange" type="daterange" value-format="YYYY-MM-DD"
                        start-placeholder="开始" end-placeholder="结束" style="width:230px"/>
      </el-form-item>
    </SearchBar>

    <ProTable ref="tableRef" :loader="courseApi.page" :query="q"
              @selection-change="v => selected = v">
      <el-table-column type="selection" width="42"/>
      <el-table-column prop="title" label="课程" min-width="180">
        <template #default="{ row }">
          <el-link type="primary" @click="$router.push(`/courses/edit/${row.id}`)">
            {{ row.title }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column prop="subjectName" label="科目" width="90"/>
      <el-table-column prop="coachName"   label="教练" width="90"/>
      <el-table-column prop="roomName"    label="教室" width="90"/>
      <el-table-column label="开课时间" width="260">
        <template #default="{ row }">{{ row.startTime }} ~ {{ row.endTime }}</template>
      </el-table-column>
      <el-table-column label="报名" width="90">
        <template #default="{ row }">
          <span :class="{ full: row.enrolled >= row.capacity }">
            {{ row.enrolled }} / {{ row.capacity }}
          </span>
        </template>
      </el-table-column>
      <el-table-column label="价格" width="80">
        <template #default="{ row }">¥{{ row.price.toFixed(2) }}</template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="COURSE_STATUS[row.status].type">
            {{ COURSE_STATUS[row.status].label }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="200" fixed="right">
        <template #default="{ row }">
          <el-button size="small" link @click="$router.push(`/courses/edit/${row.id}`)">编辑</el-button>
          <el-button v-if="row.status === 1" size="small" link type="success"
                     @click="onPublish(row)">发布</el-button>
          <el-button v-if="[2, 3].includes(row.status)" size="small" link type="warning"
                     @click="onOffline(row)">下架</el-button>
          <el-button size="small" link type="danger" @click="onDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </ProTable>
  </PageContainer>
</template>

<script setup lang="ts">
import { reactive, ref, watch, onMounted } from 'vue'
import { courseApi, type CourseVO } from '@/api/course'
import { subjectApi } from '@/api/subject'
import { coachApi }   from '@/api/coach'
import { COURSE_STATUS } from '@/utils/dict'
import { toastErr } from '@/utils/handleErr'

const q = reactive<any>({ pageNum: 1, pageSize: 10 })
const dateRange = ref<string[]>()
watch(dateRange, v => { q.startBegin = v?.[0]; q.startEnd = v?.[1] })

const subjects = ref<any[]>([]); const coaches = ref<any[]>([])
onMounted(async () => {
  try { [subjects.value, coaches.value] = await Promise.all([
    subjectApi.list(), coachApi.simpleList()]) }
  catch (e) { toastErr(e) }
})

const tableRef = ref<any>()
const selected = ref<CourseVO[]>([])
// onPublish / onOffline / onDelete / onBatchDelete 见第 3 讲
</script>

<style scoped>.full { color: #E6A23C; font-weight: 600; }</style>
```

### 1.7 关键细节详解

**`dateRange` 为什么要 watch 拆分**：后端接口约定的是 `startBegin` 与 `startEnd` 两个 query 参数，而 daterange 组件天然吐一个数组。用 `watch(dateRange, v => { q.startBegin = v?.[0]; q.startEnd = v?.[1] })` 把数组的两个位置分别写到 `q` 的两个字段，`v` 清空时两个字段都会被赋成 `undefined`，`axios` 会自动剔除 undefined 参数。

**冗余字段 vs 前端字典 join**：如果后端只返回 `subjectId`，前端要额外拉一次科目字典再做 `subjects.find(s => s.id === row.subjectId)?.name` 翻译。列表一屏 20 行、3 个外键就是 60 次 find，可读性也差。本项目选**后端 join 一次**——代价是外键改名后要跟着改列表接口，但字段名不常改，值得。

**`el-table-column` 的插槽解构**：`<template #default="{ row }">` 里的 `{ row }` 是 Element Plus 提供的插槽作用域数据，等价于早期版本的 `scope.row`。习惯用解构写法会让代码短很多。

**`onMounted` 里的 `Promise.all` 并发**：科目字典与教练字典之间没有依赖，串行拉两次会白白多等一个 RTT。并发之后失败任一都会走 `catch`，我们用 `toastErr` 统一处理——不会因为字典没拉到就白屏。

### 1.8 提炼

- 课程列表页 = `SearchBar` 5 项 + `ProTable` 9 列 + 状态字典
- 冗余字段策略：后端 join 一次，前端只渲染
- 日期区间 `dateRange` 用 `watch` 拆到两个 query 参数
- 状态过滤：`el-option :value="+k"` 强制转 number
- 关联字典：`Promise.all` 并发拉取 + `toastErr` 统一兜底

### 1.9 练习

1. 【必做】把项目里的 `MemberListView.vue` 复制一份重命名 `CourseListView.vue` 作为起手骨架。
2. 【必做】把搜索栏改造成本讲要求的 5 个条件，注意「开课时段」用 `daterange`。
3. 【必做】`onMounted` 里并发拉科目字典与教练字典，用 `Promise.all` + `toastErr` 兜底。
4. 【必做】把 9 列表格铺全，报名进度满员时橙色高亮。
5. 【选做】在页面切走时缓存搜索条件（`localStorage`），回到该页时自动还原。

---

## 第 2 讲：课程新增 / 修改 —— 独立路由页 + 级联下拉

### 2.1 引入：为什么这次不用弹窗

上讲列表页跑通了，点「新增课程」按钮跳 `/courses/edit`——页面 404。这讲要补上编辑页。为什么不像会员管理那样用弹窗？三条选型标准：

1. **字段数 > 10**：课程 15 个字段，弹窗最大宽度也放不下。
2. **有联动预检**：教练 / 教室 / 时段变化时要触发冲突检测，弹窗里放个 `el-alert` 面板太挤。
3. **有嵌入子表**：将来还要挂「已报名会员列表」等子模块。

满足其一就该独立路由页。而且独立路由能保留浏览器前进 / 后退历史，写一半临时切走还能回来接着写。

🎯 **一句话目标**：**独立路由 `/courses/edit/:id?` + 4 组字段 + 前端 computed 级联 + 300ms 防抖冲突预检**——新增与编辑复用同一个组件。

### 2.2 路由：可选参数写法

`router/index.ts` 加：

```ts
{
  path: 'courses/edit/:id?',
  component: () => import('@/views/course/CourseEditView.vue'),
  meta: { title: '编辑课程' }
}
```

`:id?` 的问号是关键——**冒号带问号**意味着参数可选，`/courses/edit` 与 `/courses/edit/42` 都能匹配到这条路由。组件里通过 `route.params.id` 判断 `isEdit`：

```ts
const route = useRoute()
const isEdit = computed(() => !!route.params.id)
const editId = computed(() => Number(route.params.id))
```

⚠️ **路由复用陷阱**：从 `/courses/edit/1` 跳到 `/courses/edit/2` 时，同一个组件实例被复用，`onMounted` 不会再触发，`form` 里还是上一条课程的数据。解决方案是给顶层 `<router-view>` 加 `:key="$route.fullPath"`：

```vue
<router-view :key="$route.fullPath"/>
```

这行代码让每次 fullPath 变化时组件强制 remount。

### 2.3 表单结构：15 个字段拆 4 组

| 组 | 字段 | 控件 |
|---|-----|-----|
| 基础信息 | title（课程名） | `el-input maxlength="40" show-word-limit` |
| 关联 | subjectId / coachId / roomId | `el-select`，教练加 `filterable :disabled` |
| 时间 | timeRange / enrollDeadline | `datetimerange` / `datetime` |
| 业务 | capacity / price / cover / intro | `input-number` / `input-number` / `input` / `textarea` |

**每种控件的选型逻辑**：

- **`filterable` 教练但不用在科目**：科目 < 10 个不需要搜索，教练可能有几十上百个。
- **`el-input-number` 而不是 `input type=number`**：前者的 `v-model` 类型是 number；后者是 string，会导致 TypeScript 报类型错。
- **`textarea :rows="4"`**：简介可能好几段，用文本框比单行输入友好。
- **`show-word-limit`**：给用户实时字符数反馈，配合 `maxlength` 使用。

### 2.4 级联下拉：三种做法与选型

| 做法 | 适用 | 本项目 |
|-----|-----|-------|
| 前端过滤（教练带 `subjectIds`） | 教练量 < 200 | ✅ |
| 每次调 `/coaches?subjectId=xx` | 教练量大 / 权限差异 | 备选 |
| 树形 `el-cascader` | 深层级 | 不需要 |

本项目教练是简单字典，选**前端过滤**：

```ts
const coachesFiltered = computed(() =>
  form.subjectId
    ? coaches.value.filter(c => c.subjectIds?.includes(form.subjectId!))
    : []
)
```

`form.subjectId` 一变，`coachesFiltered` 自动重算，教练下拉自动刷新。

### 2.5 联动策略：科目变了如何处理教练

看下面这个反面例子：

```ts
function onSubjectChange() {
  form.coachId = undefined       // ❌ 无脑清
}
```

问题：用户「先选科目 A → 选教练甲 → 想改到同科目 A 下的教练乙」时，`onSubjectChange` 不会触发（`subjectId` 没变），但**如果**触发就会清掉正在选的教练。所以正确的写法是**只清不合法的**：

```ts
function onSubjectChange() {
  if (form.coachId && !coachesFiltered.value.some(c => c.id === form.coachId)) {
    form.coachId = undefined
  }
}
```

只有当前选中的教练**不在**新的过滤列表里时才清，否则保留。

### 2.6 冲突预检：防抖 + 不阻断保存

用户输时段、改教练时都要触发一次预检。核心组合是 `@vueuse/core` 的 `useDebounceFn`：

```ts
import { useDebounceFn } from '@vueuse/core'

const conflict = reactive<ConflictVO>({})

const debouncedCheck = useDebounceFn(async () => {
  Object.assign(conflict, { coachConflict: undefined, roomConflict: undefined })
  if (!form.coachId || !form.roomId || !form.timeRange) return
  try {
    const c = await courseApi.checkConflict({
      id: form.id,           // 编辑态带上以排除自身
      coachId: form.coachId,
      roomId: form.roomId,
      startTime: form.timeRange[0],
      endTime: form.timeRange[1]
    })
    Object.assign(conflict, c)
  } catch {
    // 冲突检测失败不阻断保存
  }
}, 300)

function onCoachRoomOrTimeChange() { debouncedCheck() }
```

**300ms** 是键盘操作的舒适阈值——太短请求太密，太长看到反馈会等得心慌。

**编辑态一定要带 `id`**：不然后端会把「正在编辑的这条课本身」也算成冲突，用户改个简介都会弹冲突警告。

**不阻断保存**：预检结果只放到 `el-alert` 展示，保存按钮永远可点——最终校验以后端为准。这是「体验优化」与「兜底安全」的边界：前端预检可绕过，后端最终校验不可少。

### 2.7 冲突提示区：`el-alert` 分别渲染

```vue
<el-alert v-if="conflict.coachConflict" type="warning" show-icon :closable="false"
          style="margin-top:8px" title="教练时间冲突">
  教练在 <b>{{ conflict.coachConflict.startTime }} ~ {{ conflict.coachConflict.endTime }}</b>
  已安排「{{ conflict.coachConflict.title }}」
</el-alert>
<el-alert v-if="conflict.roomConflict" type="warning" show-icon :closable="false"
          style="margin-top:8px" title="教室时间冲突">
  教室在 <b>{{ conflict.roomConflict.startTime }} ~ {{ conflict.roomConflict.endTime }}</b>
  已被「{{ conflict.roomConflict.title }}」占用
</el-alert>
```

⚠️ **`:closable="false"`** 一定要加——不加的话冲突消失后关闭图标还在。

### 2.8 完整实现：`CourseEditView.vue`

```vue
<template>
  <PageContainer :title="isEdit ? '编辑课程' : '新增课程'" back>
    <template #actions>
      <el-button @click="$router.back()">取消</el-button>
      <el-button type="primary" :loading="saving" @click="submit">保存</el-button>
    </template>

    <el-form ref="formRef" :model="form" :rules="rules" label-width="110px" style="max-width:800px">
      <el-form-item label="课程名称" prop="title">
        <el-input v-model="form.title" maxlength="40" show-word-limit/>
      </el-form-item>
      <el-form-item label="科目" prop="subjectId">
        <el-select v-model="form.subjectId" style="width:220px" @change="onSubjectChange">
          <el-option v-for="s in subjects" :key="s.id" :label="s.name" :value="s.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="教练" prop="coachId">
        <el-select v-model="form.coachId" filterable :disabled="!form.subjectId"
                   style="width:220px" @change="onCoachRoomOrTimeChange">
          <el-option v-for="c in coachesFiltered" :key="c.id" :label="c.name" :value="c.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="教室" prop="roomId">
        <el-select v-model="form.roomId" style="width:220px" @change="onCoachRoomOrTimeChange">
          <el-option v-for="r in rooms" :key="r.id"
                     :label="`${r.name}（容量 ${r.capacity}）`" :value="r.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="开课时段" prop="timeRange">
        <el-date-picker v-model="form.timeRange" type="datetimerange"
                        value-format="YYYY-MM-DD HH:mm" format="YYYY-MM-DD HH:mm"
                        :disabled-date="(d: Date) => d < new Date(Date.now() - 864e5)"
                        style="width:380px" @change="onCoachRoomOrTimeChange"/>
      </el-form-item>
      <el-form-item label="报名截止" prop="enrollDeadline">
        <el-date-picker v-model="form.enrollDeadline" type="datetime"
                        value-format="YYYY-MM-DD HH:mm" format="YYYY-MM-DD HH:mm"
                        style="width:220px"/>
      </el-form-item>
      <el-form-item label="容量" prop="capacity">
        <el-input-number v-model="form.capacity" :min="1" :max="200"/>
        <span v-if="selectedRoomCap" style="margin-left:8px;color:#999">
          （教室容量 {{ selectedRoomCap }}）
        </span>
      </el-form-item>
      <el-form-item label="价格" prop="price">
        <el-input-number v-model="form.price" :min="0" :max="9999" :precision="2"/>
      </el-form-item>
      <el-form-item label="封面"><el-input v-model="form.cover" placeholder="OSS URL"/></el-form-item>
      <el-form-item label="简介">
        <el-input v-model="form.intro" type="textarea" :rows="4" maxlength="500" show-word-limit/>
      </el-form-item>
    </el-form>

    <el-alert v-if="conflict.coachConflict" type="warning" show-icon :closable="false"
              style="margin-top:8px" title="教练时间冲突">
      教练在 {{ conflict.coachConflict.startTime }} ~ {{ conflict.coachConflict.endTime }} 已安排「{{ conflict.coachConflict.title }}」
    </el-alert>
    <el-alert v-if="conflict.roomConflict" type="warning" show-icon :closable="false"
              style="margin-top:8px" title="教室时间冲突">
      教室在 {{ conflict.roomConflict.startTime }} ~ {{ conflict.roomConflict.endTime }} 已被「{{ conflict.roomConflict.title }}」占用
    </el-alert>
  </PageContainer>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import type { FormInstance, FormRules } from 'element-plus'
import { courseApi, type CourseFormDTO, type ConflictVO } from '@/api/course'
import { subjectApi } from '@/api/subject'
import { coachApi } from '@/api/coach'
import { roomApi } from '@/api/room'
import { toastErr } from '@/utils/handleErr'
import { useDebounceFn } from '@vueuse/core'

const route = useRoute(), router = useRouter()
const isEdit = computed(() => !!route.params.id)
const editId = computed(() => Number(route.params.id))

const form = reactive<CourseFormDTO>({ title: '', capacity: 20, price: 0 })
const formRef = ref<FormInstance>()
const saving = ref(false)

const subjects = ref<{ id: number; name: string }[]>([])
const coaches  = ref<{ id: number; name: string; subjectIds: number[] }[]>([])
const rooms    = ref<{ id: number; name: string; capacity: number }[]>([])

const coachesFiltered = computed(() =>
  form.subjectId
    ? coaches.value.filter(c => c.subjectIds?.includes(form.subjectId!))
    : []
)
const selectedRoomCap = computed(() =>
  rooms.value.find(r => r.id === form.roomId)?.capacity
)

const conflict = reactive<ConflictVO>({})

const rules: FormRules = {
  title:     [{ required: true, message: '请输入课程名', trigger: 'blur' },
              { min: 2, max: 40, message: '2~40 字符', trigger: 'blur' }],
  subjectId: [{ required: true, message: '请选择科目', trigger: 'change' }],
  coachId:   [{ required: true, message: '请选择教练', trigger: 'change' }],
  roomId:    [{ required: true, message: '请选择教室', trigger: 'change' }],
  timeRange: [{ required: true, message: '请选择开课时段', trigger: 'change' },
              { validator: (_r, v, cb) => {
                  if (!v || v.length !== 2) return cb(new Error('请选择完整时段'))
                  if (new Date(v[1]) <= new Date(v[0])) return cb(new Error('结束时间必须晚于开始'))
                  cb()
                }, trigger: 'change' }],
  capacity:  [{ required: true, message: '请填写容量', trigger: 'blur' },
              { validator: (_r, v, cb) => {
                  if (selectedRoomCap.value && v > selectedRoomCap.value)
                    return cb(new Error(`容量不能超过教室容量 ${selectedRoomCap.value}`))
                  cb()
                }, trigger: 'change' }],
  price:     [{ required: true, message: '请填写价格', trigger: 'blur' }]
}

// —— 初始化：并发拉字典 + 详情 ——
onMounted(async () => {
  try {
    [subjects.value, coaches.value, rooms.value] = await Promise.all([
      subjectApi.list(), coachApi.simpleList(), roomApi.simpleList()
    ])
    if (isEdit.value) {
      const d = await courseApi.detail(editId.value)
      Object.assign(form, {
        id: d.id, title: d.title,
        subjectId: d.subjectId, coachId: d.coachId, roomId: d.roomId,
        timeRange: [d.startTime, d.endTime],
        enrollDeadline: d.enrollDeadline,
        capacity: d.capacity, price: d.price,
        cover: d.cover, intro: d.intro
      })
    }
  } catch (e) { toastErr(e); router.back() }
})

// —— 联动：科目变了才清不合法的教练 ——
function onSubjectChange() {
  if (form.coachId && !coachesFiltered.value.some(c => c.id === form.coachId)) {
    form.coachId = undefined
  }
}

// —— 教练 / 教室 / 时段变化触发冲突预检 ——
const debouncedCheck = useDebounceFn(async () => {
  Object.assign(conflict, { coachConflict: undefined, roomConflict: undefined })
  if (!form.coachId || !form.roomId || !form.timeRange) return
  try {
    const c = await courseApi.checkConflict({
      id: form.id,
      coachId: form.coachId,
      roomId: form.roomId,
      startTime: form.timeRange[0],
      endTime:   form.timeRange[1]
    })
    Object.assign(conflict, c)
  } catch { /* ignore */ }
}, 300)

function onCoachRoomOrTimeChange() { debouncedCheck() }

// —— 保存（详见第 3 讲） ——
async function submit() { /* 见第 3 讲 */ }
</script>
```

### 2.9 细节详解

**`disabled-date` 里为什么减一天**：`(d: Date) => d < new Date(Date.now() - 864e5)`。如果直接写 `< new Date()`，今天上午 10 点开的场次会被禁掉——因为「今天早于当前时刻」被判为过去。减一天让整个今天都可选。

**`Object.assign(form, d)` 反填要注意 `timeRange`**：详情接口返回的是 `startTime` 与 `endTime` 两个字段，前端表单要的是 `timeRange: [startTime, endTime]` 数组，必须**手工拼接**，不然 `datetimerange` 面板不会显示已选值。

**`el-input-number` `v-model` 类型是 number**：TypeScript 严格模式下 `form.capacity` 就应是 `number`，不要写成 `number | string`。

**`filterable` 大小写敏感吗**：Element Plus 默认忽略大小写；如需自定义匹配规则要传 `:filter-method`。

### 2.10 提炼

- 独立路由页 = `path: '/courses/edit/:id?'` + 组件里 `isEdit` computed
- 4 组字段：基础信息 / 关联 / 时间 / 业务
- 级联下拉：`coachesFiltered` computed 过滤 + `onSubjectChange` 仅清不合法值
- 冲突预检：`useDebounceFn` 300ms + `el-alert` + 不阻断保存
- 路由复用陷阱：`<router-view :key="$route.fullPath">` 强制 remount

### 2.11 练习

1. 【必做】把 `router/index.ts` 里加 `courses/edit/:id?` 路由，跑通 `/courses/edit` 页面不是 404。
2. 【必做】把 15 个表单字段全部铺上，只做 UI，先不管校验和联动。
3. 【必做】加 `coachesFiltered` computed，观察科目切换后教练下拉的变化。
4. 【必做】接上冲突预检，改时段后 300ms 内看到 alert 弹出。
5. 【选做】给「简介」加上 markdown 预览（可选 `md-editor-v3`）。

---

## 第 3 讲：课程删除 + 业务确认（发布 / 下架 / 单删 / 批删）

### 3.1 引入：为什么要「业务确认」

编辑页把表单和联动做完了，还差保存按钮真的调后端。同时列表页里「发布」「下架」「删除」「批量删除」四个按钮都还是空壳。这一讲把这四条**业务动作**接上，同时把编辑页的保存流打通。

灵魂问题：**用户点「删除」按钮时，如果直接调后端删除，为什么很危险？**——因为一次误点可能让 100 人的报名记录消失；给出**语义化确认弹窗**是最后一道防线，也是给用户「后悔一秒」的机会。

🎯 **一句话目标**：**`ElMessageBox.confirm` 三色语义 + `v-if` 按状态显隐 + 保存双重确认（校验 + 冲突）+ `router.replace` 返列表**。

### 3.2 `ElMessageBox.confirm` 的三种语义

| 动作 | type | 补充 | 图标含义 |
|-----|-----|------|--------|
| 发布 | `'success'` | 无 | 绿勾，正向操作 |
| 下架 | `'warning'` | 无 | 黄叹号，谨慎操作 |
| 删除 | `'warning'` | `confirmButtonClass: 'el-button--danger'` | 黄叹号 + 红按钮，最谨慎 |

核心是让用户**看到图标就知道后果**，减少误点损失。

**通用调用样板**：

```ts
async function onPublish(row: CourseVO) {
  await ElMessageBox.confirm(`确认发布「${row.title}」？`, '发布确认', { type: 'success' })
  try {
    await courseApi.publish(row.id)
    ElMessage.success('发布成功')
    tableRef.value?.refresh()
  } catch (e) { toastErr(e) }
}

async function onOffline(row: CourseVO) {
  await ElMessageBox.confirm(
    `下架后无法再报名，确认下架「${row.title}」？`,
    '下架确认',
    { type: 'warning' }
  )
  try {
    await courseApi.offline(row.id)
    ElMessage.success('已下架')
    tableRef.value?.refresh()
  } catch (e) { toastErr(e) }
}

async function onDelete(row: CourseVO) {
  await ElMessageBox.confirm(`确认删除「${row.title}」？`, '删除确认', {
    type: 'warning',
    confirmButtonClass: 'el-button--danger'
  })
  try {
    await courseApi.remove([row.id])
    ElMessage.success('已删除')
    tableRef.value?.refresh()
  } catch (e) { toastErr(e) }
}
```

⚠️ **`ElMessageBox` 的 reject 必须处理**：用户点「取消」时 confirm 会 reject，如果 `await` 后面不处理，控制台会一堆红字警告，生产上被监控误报。三种处理方式：

1. 什么都不做（推荐，`await` 会抛错，函数自然结束）；
2. `.catch(() => {})` 显式吞掉；
3. `try...catch` 包一层。

上例采用第 1 种：`await` 后面的语句只有在用户点「确定」时才会执行，reject 会直接跳出函数。

### 3.3 批量删除

```ts
async function onBatchDelete() {
  const ids = selected.value.map(c => c.id)
  await ElMessageBox.confirm(
    `即将删除 ${ids.length} 门课程，是否继续？`,
    '批量删除',
    { type: 'warning' }
  )
  try {
    await courseApi.remove(ids)
    ElMessage.success('已删除')
    tableRef.value?.refresh()
  } catch (e) { toastErr(e) }
}
```

**三道防线**：

1. 按钮 `:disabled="!selected.length"` 拦空选；
2. 弹窗里显示 `ids.length` 让用户看数字；
3. 后端权限校验兜底。

**为什么单删也用数组接口**：`courseApi.remove` 后端接口只写一版接受 `ids[]`——单删传 `[row.id]`、批删传 `selected.map(c => c.id)`，接口收敛，前后端都少一半代码。

### 3.4 `v-if` vs `:disabled` 按状态显隐

```vue
<el-button v-if="row.status === 1"          @click="onPublish">发布</el-button>
<el-button v-if="[2, 3].includes(row.status)" @click="onOffline">下架</el-button>
```

为什么用 `v-if` 而不是 `:disabled`？

- **业务状态触发的操作**：只在特定状态可用，其他状态下按钮存在只会让 UI 变胖并诱导误操作 → 用 `v-if` 完全隐藏。
- **权限相关**：比如「非管理员看不到」，希望用户知道按钮存在但没权限 → 用 `:disabled` + tooltip 提示原因。

课程状态属于前者，`v-if` 直接隐掉最干净。

### 3.5 编辑页保存链路：双重确认

保存路径要拦两层错误：

1. **第一层：字段级校验**——`formRef.value?.validate()` 检查所有 rules；
2. **第二层：冲突二次确认**——`conflict.coachConflict || conflict.roomConflict` 时弹 confirm。

```ts
async function submit() {
  const ok = await formRef.value?.validate().catch(() => false)
  if (!ok) return
  if (conflict.coachConflict || conflict.roomConflict) {
    await ElMessageBox.confirm(
      '当前存在时间冲突，仍要保存吗？（后端将最终校验，冲突时无法保存）',
      '确认冲突', { type: 'warning' }
    )
  }
  saving.value = true
  try {
    const dto: any = {
      ...form,
      startTime: form.timeRange![0],
      endTime:   form.timeRange![1]
    }
    delete dto.timeRange
    if (isEdit.value) await courseApi.update(dto)
    else              await courseApi.create(dto)
    ElMessage.success(isEdit.value ? '更新成功' : '新增成功')
    router.replace('/courses')
  } catch (e) { toastErr(e) }
  finally { saving.value = false }
}
```

**要点**：

- `formRef.value?.validate().catch(() => false)`：validate 失败会 reject，`.catch` 把它翻译成 `false`，避免用 try-catch 包住整个 submit。
- `timeRange` 拆成 `startTime / endTime` 后**必须 `delete dto.timeRange`**，否则后端严格 DTO 校验会抱怨多余字段。
- `router.replace('/courses')` 而不是 `router.push`——编辑保存后不该在浏览器历史里留下编辑页，不然点后退还会跳回编辑页。
- `saving.value = false` 一定放 `finally` 里，`try` 里 `return` 前就复位会漏掉异常路径。

### 3.6 完整代码回顾（列表页动作部分）

将上面 4 个函数（`onPublish` / `onOffline` / `onDelete` / `onBatchDelete`）追加到 `CourseListView.vue` 的 `<script setup>` 中，导入 `ElMessage / ElMessageBox / toastErr / courseApi` 即可。样板代码见 3.2 与 3.3 节，直接复用。

### 3.7 提炼

- 业务确认：`ElMessageBox.confirm` 三色语义（success 发布 / warning 下架 / warning + danger 按钮删除）
- 状态相关按钮用 `v-if` 直接隐藏；权限相关按钮用 `:disabled` + tooltip
- 保存 = validate → 冲突二次确认 → 组装 DTO → API → `router.replace` 返回
- 单删 / 批删共用后端接口 `remove(ids[])`
- `saving.value` 必须走 `finally` 复位
- `ElMessageBox` 的 reject 分支自然抛出，不用额外 catch

### 3.8 练习

1. 【必做】把 `onPublish / onOffline / onDelete` 三个函数写完，点击真的能改后端状态。
2. 【必做】把批删接上，观察 `selected.length` 与按钮 `disabled` 的联动。
3. 【必做】编辑页保存按钮接通，走一次「新增课程 → 列表出现新行」。
4. 【必做】写一次「保存冲突 → 二次确认 → 后端强校验拒绝」的完整链路。
5. 【选做】给「发布」加两阶段确认——第一次弹「课程一发布不能改课程时间，确认？」，第二次才真调后端。

---

## 第 4 讲：Element Plus 表单校验体系（同步 + 异步 + 自定义）

### 4.1 引入：项目里已经堆了 8 处校验规则

课程编辑页里我们已经写了 6-7 条校验规则，Day13 会员表单又写了 4-5 条，注册页还有一堆。仔细数一数，「手机号」的正则出现了 3 次、「必填」的 message 写了 12 次「请输入 XXX」。这一讲做一次系统总结——**把校验分层理清楚，把公共规则抽出来**。

🎯 **一句话目标**：**六层校验分层图 + Promise 风格 validator + `validators.ts` 常量与工厂函数**——让每个表单的 rules 缩短到 3 行以内。

### 4.2 校验分层图

```
用户输入
   ↓
① 前端字段级（rules: required / min / pattern）    ← 即时反馈
   ↓
② 前端跨字段（validator 引用其他字段）              ← 表单内部一致性
   ↓
③ 前端预检 API（如冲突检测 / 唯一性）               ← 提前告知，可选
   ↓
用户点保存
   ↓
④ 后端 JSR-303（@Valid + @Pattern / @NotBlank）    ← 兜底
   ↓
⑤ 后端业务级（Service 里的时间冲突 / 余额不足）     ← 决策
   ↓
⑥ 数据库约束（唯一索引 / 外键）                     ← 最后防线
```

**每层职责与代价**：

| 层级 | 谁负责 | 例子 | 代价 |
|-----|-------|-----|------|
| ① 前端字段级 | rules | 手机号格式 | 0 网络 |
| ② 前端跨字段 | validator | 结束 > 开始 | 0 网络 |
| ③ 前端预检 | API | 手机号是否已注册 | 1 次请求 |
| ④ 后端字段级 | JSR-303 | `@Pattern` | 后端处理 |
| ⑤ 后端业务级 | Service | 冲突检测 | 后端处理 |
| ⑥ DB 约束 | 唯一 / FK | 唯一索引 | DB 处理 |

⚠️ **铁律**：**前端可绕过，后端不可少**。前端只做「提升体验」，后端才是「兜住安全」。这不是重复劳动，是防御性架构。

### 4.3 `FormItemRule` 内置字段大全

Element Plus 底层是 `async-validator`，`rules` 支持的常用字段：

```ts
const rule: FormItemRule = {
  required:   true,                                    // 必填
  type:       'string' | 'number' | 'array' | 'date' | 'email' | 'url',
  min:        2, max: 20,                              // 长度或数值区间
  len:        11,                                      // 精确长度
  pattern:    /^1[3-9]\d{9}$/,                         // 正则
  enum:       ['A', 'B'],                              // 枚举
  whitespace: true,                                    // 禁止纯空格
  message:    '请输入姓名',
  trigger:    'blur' | 'change' | ['blur', 'change'],
  validator:  (rule, value, callback) => { ... },      // 同步 / 异步
  asyncValidator: (rule, value) => Promise             // Promise 版
}
```

**多规则组合按数组顺序执行；一旦前一条 reject，后一条不再执行**：

```ts
name: [
  { required: true, message: '请输入姓名', trigger: 'blur' },
  { min: 2, max: 20, message: '2~20 字符', trigger: 'blur' },
  { pattern: /^[\u4e00-\u9fa5A-Za-z·]+$/, message: '只允许中英文与间隔号', trigger: 'blur' }
]
```

### 4.4 自定义 `validator` 的三种风格

```ts
// A. callback 风格（老 API，兼容广）
validator: (_rule, value, callback) => {
  if (!value) return callback(new Error('必填'))
  if (value.length < 6) return callback(new Error('太短'))
  callback()               // 通过必须调
}

// B. Promise 风格（推荐）
validator: async (_rule, value) => {
  if (!value) throw new Error('必填')
  const exists = await memberApi.checkPhone(value)
  if (exists) throw new Error('手机号已注册')
}

// C. 同步返回
validator: (_rule, value) => value.length >= 6      // 返回 false 触发 message
```

⚠️ **经典坑：`callback()` 忘调导致 validate 永远 pending**——表单永远处于校验中，`await validate()` 永远 resolve 不了，用户点保存没反应。改用 Promise 风格能根治这个坑，因为「无论 throw 还是正常 return，Promise 一定会 settled」。

⚠️ **异步 validator 的竞态**：用户快速改字段时，早请求晚返回可能覆盖新答案。两种解法：

1. 每次调用记 `seq`，返回时对比，只有最新一次生效；
2. 用 `lodash.debounce` + 只对最后一次生效。

### 4.5 跨字段校验：`validateField` 主动触发

以「二次密码」为例：

```ts
const rules: FormRules = {
  password:  [{ required: true, min: 8, trigger: 'blur' }],
  password2: [
    { required: true, trigger: 'blur' },
    { validator: (_r, v) => {
        if (v !== form.password) throw new Error('两次密码不一致')
      }, trigger: 'blur' }
  ]
}

watch(() => form.password, () => {
  if (form.password2) formRef.value?.validateField('password2')
})
```

**核心**：修改 `password` 时被依赖字段 `password2` 不会自动重新校验，必须 `watch` 里**主动**调 `validateField('password2')`。不加这行的话，用户改前一个字段，后一个字段的红字不会消失，看着像 bug。

### 4.6 数组字段校验：至少选 1 项

```ts
specialty: [{
  type: 'array', required: true, message: '至少选择 1 项', trigger: 'change'
}]

// 或用自定义 validator
specialty: [{
  validator: (_r, v) => {
    if (!Array.isArray(v) || v.length === 0) throw new Error('至少选择 1 项')
  }, trigger: 'change'
}]
```

`type: 'array' + required: true` 与「至少选 1 项」语义等价，且更简洁。

### 4.7 抽取到 `utils/validators.ts`

项目里手机号、身份证等规则会**反复出现**。经验法则：**同一规则第 3 次出现时抽出来**。过早抽反而是过度设计。

```ts
// src/utils/validators.ts
import type { FormItemRule } from 'element-plus'

/** 手机号 */
export const phoneRule: FormItemRule = {
  pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur'
}

/** 中国大陆身份证（18 位，末位可能是 X） */
export const idCardRule: FormItemRule = {
  pattern: /^[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/,
  message: '身份证号格式不正确', trigger: 'blur'
}

/** 强密码：8+ 位，需含大小写字母 + 数字 */
export const strongPasswordRule: FormItemRule = {
  validator: (_r, v) => {
    if (!v) return
    if (v.length < 8) throw new Error('至少 8 位')
    if (!/[A-Z]/.test(v)) throw new Error('需包含大写字母')
    if (!/[a-z]/.test(v)) throw new Error('需包含小写字母')
    if (!/\d/.test(v))    throw new Error('需包含数字')
  }, trigger: 'blur'
}

/** URL */
export const urlRule: FormItemRule = {
  type: 'url', message: 'URL 格式不正确', trigger: 'blur'
}

/** 「必填」的语义化封装 */
export const required = (
  label: string,
  trigger: FormItemRule['trigger'] = 'blur'
): FormItemRule =>
  ({ required: true, message: `请输入${label}`, trigger })

/** 长度范围 */
export const lenRange = (
  min: number, max: number,
  trigger: FormItemRule['trigger'] = 'blur'
): FormItemRule =>
  ({ min, max, message: `${min}~${max} 字符`, trigger })

/** 异步唯一性校验工厂 */
export function uniqueRule(
  check: (v: any) => Promise<boolean>,
  message = '已存在'
): FormItemRule {
  return {
    trigger: 'blur',
    validator: async (_r, v) => {
      if (!v) return
      const exists = await check(v)
      if (exists) throw new Error(message)
    }
  }
}
```

**设计要点**：

- 常量（`phoneRule`）与工厂函数（`required('手机号')`）分开——常量适合无参数的固定规则，工厂函数适合需要传入 label / 参数的规则。
- 空值一律 `return`（跳过），把「必填」交给独立的 `required` 规则；单条规则职责单一。
- `strongPasswordRule` 用 Promise 风格 `throw new Error(...)`，一律避开 callback 忘调的坑。

### 4.8 改造 Day13 会员表单：3 行 vs 12 行

**改造前**（12 行）：

```ts
const rules: FormRules<MemberFormDTO> = {
  name: [
    { required: true, message: '请输入姓名', trigger: 'blur' },
    { min: 2, max: 20, message: '2~20 字符', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '请输入手机号', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '格式不对', trigger: 'blur' },
    { validator: async (_r, v) => {
        if (!v) return
        const e = await memberApi.checkPhone(v)
        if (e) throw new Error('已注册')
      }, trigger: 'blur' }
  ]
}
```

**改造后**（3 行）：

```ts
import { required, lenRange, phoneRule, uniqueRule } from '@/utils/validators'
import { memberApi } from '@/api/member'

const rules: FormRules<MemberFormDTO> = {
  name:  [required('姓名'), lenRange(2, 20)],
  phone: [required('手机号'), phoneRule, uniqueRule(memberApi.checkPhone, '手机号已注册')]
}
```

**收益**：

- 校验规则**去重**——手机号规则从 12 个页面收敛到 1 处；
- 团队新人**照抄**——不用每次翻旧代码找正则；
- 修改统一——换正则一处生效。

### 4.9 提炼

- 校验分六层：前端 3 层体验 + 后端 3 层安全
- `FormItemRule` 10 个常用字段：`required / type / min / max / len / pattern / enum / whitespace / message / trigger`
- `validator` 一律 Promise 风格，根治 `callback()` 忘调
- 跨字段：`watch` + `validateField`
- 公共规则抽 `validators.ts`：常量 + 工厂函数
- 抽取时机：出现第 3 次；早抽反而过度设计

### 4.10 练习

1. 【必做】新建 `src/utils/validators.ts`，落地 `phoneRule / required / lenRange / uniqueRule` 四个工具。
2. 【必做】把会员表单的 rules 全部改成新工具调用，验证代码行数至少减半。
3. 【必做】给注册页加二次密码校验 + `watch` 触发 `validateField`。
4. 【选做】给 `uniqueRule` 加防抖，避免快速输入触发大量后端请求。
5. 【选做】加一个 `sameAsRule(otherField: Ref)` 工厂，用于「两次密码一致」等语义。

---

## 第 5 讲：系统日志前端页面（对接 AOP + 时间区间 + 导出）

### 5.1 引入：为什么运维要看日志

Day10 我们已经用 `@OperationLog` 切面把每次会员 / 课程 / 教练操作都落进 `tb_op_log` 表。数据在库里躺着但没人能看——运维要 SSH 到服务器 `SELECT * FROM tb_op_log`，一是不方便，二是给他们数据库权限风险大。这一讲把日志**可视化**：搜索、翻页、看详情、导 CSV。

🎯 **一句话目标**：**让每次后台点击的痕迹都能被审计和追溯**——4 项搜索 + 9 列表格 + 抽屉详情 + JSON 美化 + CSV 导出。

### 5.2 `OpLogVO` 建模

对接后端 `tb_op_log` 表的 15 个字段：

```ts
// src/api/opLog.ts
import request from './request'
import type { PageResult } from './types'

export interface OpLogVO {
  id: number
  operator: string             // 用户名（登录账号）
  operatorRealName: string     // 真名
  module: string               // 业务模块（会员 / 课程 / ...）
  action: string               // 操作类型（新增 / 修改 / 删除 ...）
  method: string               // HTTP method：GET / POST / PUT / DELETE
  uri: string                  // 请求 URI
  params: string               // JSON 字符串（可能很长）
  result?: string              // 成功返回摘要
  error?: string               // 异常堆栈摘要
  ip: string
  costMs: number
  status: 1 | 2                // 1 成功 2 失败
  createTime: string
}

export const opLogApi = {
  page:      (q: any)       => request.get<any, PageResult<OpLogVO>>('/op-logs', { params: q }),
  detail:    (id: number)   => request.get<any, OpLogVO>(`/op-logs/${id}`),
  remove:    (ids: number[]) => request.delete<any, void>('/op-logs', { data: ids }),
  exportCsv: (q: any)       => request.get('/op-logs/export', { params: q, responseType: 'blob' })
}
```

**要点**：

- `params / result / error` 都是 string，因为后端存 JSON 字符串或堆栈文本；前端要 `JSON.parse` 美化再展示。
- `status: 1 | 2` 是字面量联合，配合 tag 涂色使用。
- `exportCsv` 的 `responseType: 'blob'` 让 Axios 直接返回二进制，不走 JSON 解析。

### 5.3 列表页布局要点

**4 项搜索**：操作人（模糊）/ 模块（select）/ 状态（select）/ 时间（datetimerange 精确到秒）。

**9 列表格**：多选 / 时间（`sortable="custom"`）/ 操作人（双行）/ 模块 / 操作 / 接口（method tag + uri）/ IP / 耗时（>500ms 橙色）/ 状态 tag / 详情按钮。

**method 涂色映射**：

| method | tag type | 语义 |
|--------|---------|------|
| GET | `info` | 灰蓝，只读 |
| POST | `success` | 绿，新增 |
| PUT | `warning` | 黄，修改 |
| DELETE | `danger` | 红，删除 |

对应函数：

```ts
const methodType = (m: string) => ({
  GET: 'info', POST: 'success', PUT: 'warning', DELETE: 'danger'
} as any)[m] || ''
```

**耗时高亮**：CSS `.slow { color: #E6A23C; font-weight: 600; }` + `<span :class="{ slow: row.costMs > 500 }">`——运维一眼找出慢接口。

### 5.4 `OpLogListView.vue` 核心结构

```vue
<template>
  <PageContainer title="操作日志">
    <template #actions>
      <el-button plain @click="onExport">导出 CSV</el-button>
      <el-button plain type="danger" :disabled="!selected.length" @click="onDelete">清理选中</el-button>
    </template>

    <SearchBar :model="q" @search="tableRef?.resetToFirst()" @reset="tableRef?.resetToFirst()">
      <el-form-item label="操作人"><el-input v-model="q.operator" clearable/></el-form-item>
      <el-form-item label="模块">
        <el-select v-model="q.module" clearable style="width:120px">
          <el-option v-for="m in MODULES" :key="m" :label="m" :value="m"/>
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="q.status" clearable style="width:100px">
          <el-option label="成功" :value="1"/><el-option label="失败" :value="2"/>
        </el-select>
      </el-form-item>
      <el-form-item label="时间">
        <el-date-picker v-model="timeRange" type="datetimerange"
                        value-format="YYYY-MM-DD HH:mm:ss" style="width:340px"/>
      </el-form-item>
    </SearchBar>

    <ProTable ref="tableRef" :loader="opLogApi.page" :query="q"
              @selection-change="v => selected = v">
      <el-table-column type="selection" width="42"/>
      <el-table-column prop="createTime" label="时间" width="160" sortable="custom"/>
      <el-table-column label="操作人" width="130">
        <template #default="{ row }">
          {{ row.operatorRealName }}
          <span style="color:#999">({{ row.operator }})</span>
        </template>
      </el-table-column>
      <el-table-column prop="module" label="模块" width="90"/>
      <el-table-column prop="action" label="操作" width="120"/>
      <el-table-column label="接口" min-width="240">
        <template #default="{ row }">
          <el-tag size="small" :type="methodType(row.method)">{{ row.method }}</el-tag>
          <span style="margin-left:6px">{{ row.uri }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="ip" label="IP" width="130"/>
      <el-table-column label="耗时" width="80">
        <template #default="{ row }">
          <span :class="{ slow: row.costMs > 500 }">{{ row.costMs }} ms</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="70">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'danger'">
            {{ row.status === 1 ? '成功' : '失败' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="80" fixed="right">
        <template #default="{ row }">
          <el-button size="small" link @click="onDetail(row)">详情</el-button>
        </template>
      </el-table-column>
    </ProTable>

    <OpLogDetailDrawer ref="drawerRef"/>
  </PageContainer>
</template>

<script setup lang="ts">
import { reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { opLogApi, type OpLogVO } from '@/api/opLog'
import { toastErr } from '@/utils/handleErr'
import OpLogDetailDrawer from './OpLogDetailDrawer.vue'

const MODULES = ['会员', '课程', '教练', '教室', '预约', '日志', '认证', '系统']
const q = reactive<any>({ pageNum: 1, pageSize: 20 })
const timeRange = ref<string[]>()
watch(timeRange, v => { q.timeBegin = v?.[0]; q.timeEnd = v?.[1] })

const tableRef = ref<any>()
const drawerRef = ref<InstanceType<typeof OpLogDetailDrawer>>()
const selected = ref<OpLogVO[]>([])
const methodType = (m: string) => ({ GET: 'info', POST: 'success', PUT: 'warning', DELETE: 'danger' } as any)[m] || ''

function onDetail(row: OpLogVO) { drawerRef.value?.open(row.id) }

async function onDelete() {
  const ids = selected.value.map(l => l.id)
  await ElMessageBox.confirm(`清理 ${ids.length} 条日志，不可恢复`, '清理确认', { type: 'warning' })
  try { await opLogApi.remove(ids); ElMessage.success('已清理'); tableRef.value?.refresh() }
  catch (e) { toastErr(e) }
}

async function onExport() {
  try {
    const blob = await opLogApi.exportCsv(q) as any as Blob
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `op-logs-${Date.now()}.csv`; a.click()
    URL.revokeObjectURL(url)
  } catch (e) { toastErr(e) }
}
</script>

<style scoped>.slow { color: #E6A23C; font-weight: 600; }</style>
```

### 5.5 详情抽屉：命令式 `open(id)`

日志详情内容长（参数 JSON 可能几百行），弹窗塞不下，用**右侧抽屉**更好。

```vue
<!-- OpLogDetailDrawer.vue -->
<template>
  <el-drawer v-model="visible" title="操作日志详情" size="640" :destroy-on-close="true">
    <el-skeleton v-if="loading" :rows="10" animated/>
    <template v-else-if="data">
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item label="时间">{{ data.createTime }}</el-descriptions-item>
        <el-descriptions-item label="耗时">{{ data.costMs }} ms</el-descriptions-item>
        <el-descriptions-item label="操作人">
          {{ data.operatorRealName }} ({{ data.operator }})
        </el-descriptions-item>
        <el-descriptions-item label="IP">{{ data.ip }}</el-descriptions-item>
        <el-descriptions-item label="模块">{{ data.module }}</el-descriptions-item>
        <el-descriptions-item label="操作">{{ data.action }}</el-descriptions-item>
        <el-descriptions-item label="接口" :span="2">
          <el-tag size="small" type="info">{{ data.method }}</el-tag>
          {{ data.uri }}
        </el-descriptions-item>
        <el-descriptions-item label="状态" :span="2">
          <el-tag :type="data.status === 1 ? 'success' : 'danger'">
            {{ data.status === 1 ? '成功' : '失败' }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>

      <el-tabs style="margin-top:12px">
        <el-tab-pane label="请求参数">
          <JsonBlock :raw="data.params"/>
        </el-tab-pane>
        <el-tab-pane label="返回结果" v-if="data.result">
          <JsonBlock :raw="data.result"/>
        </el-tab-pane>
        <el-tab-pane label="异常信息" v-if="data.error">
          <pre class="err">{{ data.error }}</pre>
        </el-tab-pane>
      </el-tabs>
    </template>
  </el-drawer>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { opLogApi, type OpLogVO } from '@/api/opLog'
import { toastErr } from '@/utils/handleErr'
import JsonBlock from '@/components/JsonBlock.vue'

const visible = ref(false)
const loading = ref(false)
const data = ref<OpLogVO>()

async function open(id: number) {
  visible.value = true
  loading.value = true
  data.value = undefined
  try { data.value = await opLogApi.detail(id) }
  catch (e) { toastErr(e) }
  finally   { loading.value = false }
}
defineExpose({ open })
</script>

<style scoped>
.err { color: #c00; background: #fef0f0; padding: 8px; border-radius: 4px;
       max-height: 300px; overflow: auto; font-size: 12px; }
</style>
```

**要点**：

- **`defineExpose({ open })`**：让父组件通过 `drawerRef.value?.open(id)` 命令式调用。相较双向绑定 `v-model + prop id`，命令式接口的调用方代码更短。
- **`:destroy-on-close="true"`**：关闭时销毁抽屉内容，避免上一条日志的数据残留。
- **`el-skeleton`**：加载时的骨架屏，比空白等待更友好。
- **异常信息用 `<pre>`**：堆栈保留换行；`max-height + overflow:auto` 缺一不可，不然长堆栈会撑破抽屉。

### 5.6 `JsonBlock.vue`：通用 JSON 美化组件

```vue
<template>
  <div class="json-block">
    <div class="tools">
      <el-button size="small" @click="copy">
        <el-icon><CopyDocument/></el-icon>复制
      </el-button>
      <el-button size="small" @click="folded = !folded">
        {{ folded ? '展开' : '折叠' }}
      </el-button>
    </div>
    <pre v-show="!folded"><code>{{ pretty }}</code></pre>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'

const props = defineProps<{ raw?: string }>()

const folded = ref(false)
const pretty = computed(() => {
  if (!props.raw) return '(空)'
  try { return JSON.stringify(JSON.parse(props.raw), null, 2) }
  catch { return props.raw }
})

async function copy() {
  try {
    await navigator.clipboard.writeText(pretty.value)
    ElMessage.success('已复制')
  } catch { ElMessage.error('复制失败，请手动选中') }
}
</script>

<style scoped>
.json-block { background: #f7f8fa; border-radius: 4px; padding: 8px; position: relative; }
.tools      { position: absolute; top: 6px; right: 6px; display: flex; gap: 6px; }
pre         { margin: 0; max-height: 400px; overflow: auto;
              font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
              font-size: 12px; line-height: 1.5; }
</style>
```

**要点**：

- **`JSON.parse` 失败回退原文**：有些日志的 `params` 不是 JSON（例如短参数字符串），`try...catch` 让组件不会因为非 JSON 输入而白屏。
- **`folded` 折叠**：对超长日志友好——十几屏的返回结果先折叠，需要时再展开。
- **`navigator.clipboard`**：在 http 环境下 undefined。生产建议加 `document.execCommand('copy')` 兜底。

### 5.7 CSV 导出四步式

```ts
async function onExport() {
  try {
    const blob = await opLogApi.exportCsv(q) as any as Blob
    const url = URL.createObjectURL(blob)               // ① blob → URL
    const a = document.createElement('a')
    a.href = url; a.download = `op-logs-${Date.now()}.csv`
    a.click()                                            // ② 触发下载
    URL.revokeObjectURL(url)                             // ③ 释放内存
  } catch (e) { toastErr(e) }
}
```

**通用工具**（可抽到 `utils/download.ts`）：

```ts
export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}
```

**中文乱码的 3 种解**：

1. 后端 Content-Type 加 `charset=utf-8` + 输出 BOM 头 `\uFEFF`；
2. 前端拼 `new Blob(['\uFEFF' + csvText], { type: 'text/csv;charset=utf-8' })`；
3. 走 xlsx（本项目不涉及）。

**中文文件名**：后端 Content-Disposition 里用 `filename*=UTF-8''` 编码，前端不用管。

**大文件建议后端返回 OSS 直传的签名 URL**，不要走后端流。

### 5.8 提炼

- 日志页 = 4 项搜索 + 9 列表格 + 详情抽屉 + CSV 导出
- `JsonBlock` 通用组件：parse 美化 + 回退原文 + 复制 + 折叠
- 命令式抽屉：`defineExpose({ open })` 让父组件通过 ref 调用
- CSV 导出四步：blob → objectURL → `a.click` → revoke
- method 涂色映射：GET/POST/PUT/DELETE 对应 info/success/warning/danger
- 耗时高亮：> 500ms 橙色，运维一眼找出慢接口

### 5.9 练习

1. 【必做】`src/api/opLog.ts` 完成接口层与类型。
2. 【必做】`OpLogListView.vue` 列表页跑通，能看到 Day10 落的日志。
3. 【必做】详情按钮打开抽屉，参数 tab 里看到 JSON 美化。
4. 【必做】顶栏「导出 CSV」跑通，Excel 打开无乱码。
5. 【选做】给 `JsonBlock` 增加语法高亮（`highlight.js` json 语法）。
6. 【选做】实现「操作日志实时推送」：后端 SSE 推送新日志，前端首页展示滚动 timeline，最多保留 20 条。

---

## 第 6 讲：前端异常处理体系 + 友好提示

### 6.1 引入：为什么要收敛 try-catch

一路做下来，学生已经在多个组件里手写过：

```ts
try { ... } catch (e) { ElMessage.error(e.message) }
```

这样有三个问题：

1. **重复劳动**：每个组件都要写；
2. **提示不统一**：有的用 `ElMessage`，有的用 `ElNotification`；
3. **漏网 Promise**：忘了 `try...catch` 的 async 函数抛错到全局，控制台一片红字。

这一讲做一次收敛——**让异常处理有全局规范、有分层职责、有兜底机制**，同时兼顾用户友好。

🎯 **一句话目标**：**四层异常处理架构 = Axios 拦截器 + API 层 try / catch + 组件层 `toastErr` + 全局 `unhandledrejection`**。

### 6.2 四层异常处理架构

```
┌─────────────────────────────────────┐
│ 全局 unhandledrejection（兜底）      │  ← 未 catch 的 Promise
├─────────────────────────────────────┤
│ 组件层 toastErr(e)（识别 + 提示）    │  ← 决定 Message / Notification
├─────────────────────────────────────┤
│ API 层 try-catch（可选：本地处理）   │  ← 需要特殊处理时才写
├─────────────────────────────────────┤
│ Axios 响应拦截器（统一预处理）       │  ← 401 / 403 / 500 / 网络错误
└─────────────────────────────────────┘
```

**分层职责**：

- **拦截器**：只做「翻译错误」——把 HTTP 状态码翻译成 `BizError`，把业务码非 200 也翻译成 `BizError`；不做用户提示。
- **组件层**：决定「弹 Message 还是 Notification」——`toastErr` 里根据错误类型分派。
- **全局兜底**：所有漏网 Promise 都有归宿，不让红字散落控制台。

### 6.3 `BizError`：业务错误载体

```ts
// @/utils/BizError.ts
export class BizError extends Error {
  constructor(public code: number, message: string) {
    super(message)
    this.name = 'BizError'
  }
}
```

`code` 是业务码或 HTTP 状态码，`message` 是给用户看的文案。所有拦截器抛出的错误都是 `BizError`——统一类型让组件层做类型判断更简单。

### 6.4 Axios 响应拦截器四分支

```ts
// @/api/request.ts
import axios from 'axios'
import { BizError } from '@/utils/BizError'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/store/auth'
import router from '@/router'

let isRedirecting = false

const request = axios.create({ baseURL: '/api', timeout: 15000 })

request.interceptors.response.use(
  async (res) => {
    // ① 已经是 blob（导出接口）直接返回；但要防止后端把错误当 JSON 塞进 blob
    if (res.config.responseType === 'blob') {
      if ((res.data as Blob).type === 'application/json') {
        const text = await (res.data as Blob).text()
        const { code, msg } = JSON.parse(text)
        throw new BizError(code, msg)
      }
      return res.data
    }
    // ② 普通 JSON：code === 200 通过，非 200 抛 BizError
    const { code, msg, data } = res.data
    if (code === 200) return data
    throw new BizError(code, msg)
  },
  (err) => {
    // ③ HTTP 层错误分四种
    const status = err.response?.status
    if (status === 401) {
      if (!isRedirecting) {
        isRedirecting = true
        ElMessage.warning('登录已过期，请重新登录')
        useAuthStore().logout()
        router.replace('/login')
        setTimeout(() => (isRedirecting = false), 1500)
      }
      return Promise.reject(new BizError(401, '未登录'))
    }
    if (status === 403) return Promise.reject(new BizError(403, '无权访问'))
    if (status >= 500)  return Promise.reject(new BizError(status, '服务异常，请稍后重试'))
    if (!err.response)  return Promise.reject(new BizError(-1, '网络异常，请检查连接'))
    return Promise.reject(err)
  }
)

export default request
```

**要点**：

- **`isRedirecting` 标志位**：并发请求都会拿到 401，如果不加标志位会连弹 10 次「登录已过期」，用户界面被消息覆盖。1500ms 后重置标志位，避免下次真的 401 时不弹。
- **blob 请求异常特殊处理**：CSV 导出时，如果后端返回 401，Axios 拿到的还是 blob，要先转 text 再 parse。
- **`code === 200 return data`**：直接把 data 剥出来，业务代码 `const list = await courseApi.page(q)` 拿到的就是分页数据本体，不需要再 `.data`。

### 6.5 `ElMessage` vs `ElNotification` 分工

| 场景 | 组件 | 停留时长 | 特点 |
|-----|-----|--------|-----|
| 保存成功 | `Message.success` | 3s | 顶部一行 |
| 表单校验错 | `Message.error` | 3s | 顶部一行 |
| 权限不足 | `Message.warning` | 3s | 顶部一行 |
| 服务 500 | `Notification.error` | 6s 或手动关 | 右下富文本 |
| 长任务通知 | `Notification.info` | 手动关 | 带标题 + 内容 |

**核心原则**：**短反馈用 Message，需要用户读一段文字或强调的错误用 Notification**。

### 6.6 `toastErr` 通用工具

```ts
// @/utils/handleErr.ts
import { ElMessage, ElNotification } from 'element-plus'
import { BizError } from './BizError'
import axios from 'axios'

const recent = new Map<string, number>()
function dedup(msg: string): boolean {
  const t = Date.now()
  const last = recent.get(msg) || 0
  if (t - last < 3000) return true
  recent.set(msg, t)
  return false
}

export function toastErr(e: unknown, opts?: { title?: string; long?: boolean }) {
  let msg = '未知错误'
  let long = opts?.long ?? false
  if (e instanceof BizError) {
    msg = e.message
    if (e.code >= 500) long = true
  } else if (axios.isAxiosError(e)) {
    msg = e.message
    long = true
  } else if (e instanceof Error) {
    msg = e.message
  }
  if (dedup(msg)) return
  if (long) {
    ElNotification.error({ title: opts?.title ?? '出错了', message: msg, duration: 6000 })
  } else {
    ElMessage.error(msg)
  }
}
```

**要点**：

- **`dedup` 去重**：同一消息 3 秒内只弹一次，避免用户界面被同样文案刷屏。用 Map 记录消息 → 时间戳，简单粗暴够用。
- **类型分支识别**：`BizError` / `AxiosError` / 普通 `Error` / 未知错误，分别取消息。500 及以上或 Axios 错误默认用 Notification。
- **`opts` 参数**：允许调用方覆盖默认行为，比如强制 long、自定义 title。

**使用姿势**：

```ts
try {
  await courseApi.remove(ids)
  ElMessage.success('已删除')
} catch (e) { toastErr(e) }
```

组件层不再关心是 400 还是 500，`toastErr` 全部搞定。

### 6.7 全局 `unhandledrejection` 兜底

```ts
// main.ts
window.addEventListener('unhandledrejection', (e) => {
  console.error('Unhandled Promise Rejection:', e.reason)
  toastErr(e.reason, { title: '未捕获异常', long: true })
  e.preventDefault()
})
```

**触发时机**：某个 async 函数抛错但调用方没有 `await` 或没 `try...catch`，Promise 拒绝没人处理时冒泡到 window。

**`e.preventDefault()`**：告诉浏览器「这个错我处理了」，避免浏览器把红字打到控制台。开发环境可以去掉这行，方便定位。

⚠️ **同步错误不走这里**：`throw new Error('...')` 直接抛在函数体里的会走 `window.onerror`，本项目暂不额外处理，交给浏览器默认。

### 6.8 blob 请求异常的特殊处理详解

用户导出 CSV 时，如果 token 过期，后端会返回 401 的 JSON。但 Axios 因为 `responseType: 'blob'`，把响应体当二进制处理，业务码判断不生效。解决办法在拦截器里：

```ts
if (res.config.responseType === 'blob') {
  if ((res.data as Blob).type === 'application/json') {
    // 后端把错误当 JSON 返回了，把 blob 转 text 再 parse
    const text = await (res.data as Blob).text()
    const { code, msg } = JSON.parse(text)
    throw new BizError(code, msg)
  }
  return res.data
}
```

判断 `blob.type` 是 `application/json` 就说明后端返回的是错误 JSON 不是文件，转成文本再 parse。

### 6.9 联调剧本回顾

**课程管理**：

1. `/courses` 空列表 → 点「新增课程」→ 跳 `/courses/edit`
2. 选科目「阴瑜伽」→ 教练下拉自动过滤 → 选「王芳」→ 教室「A302」→ 时段「明天 09:00 ~ 10:00」→ 冲突面板空
3. 改时段到「明天 10:00 ~ 11:00」→ 300ms 后 alert 冲突弹出
4. 容量填 200（超教室容量 30）→ 校验器红字
5. 保存 → 冲突二次确认；后端 `1010 时间冲突` → toastErr 弹通知
6. 列表刷新 → 新课「未发布」灰色 → 点「发布」→ 变「报名中」绿 → 「下架」出现
7. 状态过滤「报名中」→ 只显示 1 条

**系统日志**：

1. 完成会员 / 课程 / 教练的一系列操作留下日志
2. `/logs` 加载 10-20 条
3. 按操作人 `admin` 筛选 → 只剩 admin
4. 「模块=会员」+「状态=失败」→「手机号已注册」失败日志
5. 时间「最近 1 小时」→ 实时过滤
6. 详情 → 3 个 tab（参数 JSON / 返回结果 / 异常）
7. 复制按钮 → 剪贴板
8. 导出 CSV → Excel 打开正常
9. 勾选 →「清理选中」→ 确认 → 刷新

**异常处理**：

1. 停掉后端 → 任一列表请求 → 右下 Notification「网络异常」6 秒
2. token 手工过期 → 任一请求 → 顶部 Message「登录过期」→ 跳登录页
3. 无权限接口 → 403 → Message「无权访问」
4. 触发 500 → Notification 长内容显示
5. 未 catch 的 async → `unhandledrejection` 兜底

### 6.10 提炼

- 四层异常：拦截器 → API try → 组件 `toastErr` → 全局 `unhandledrejection`
- `BizError` 承载业务码 + 消息，统一错误载体
- `ElMessage` 短反馈 / `ElNotification` 长内容
- 401 防重复：`isRedirecting` 标志位 + 1500ms 复位
- blob 异常特殊处理：`type === 'application/json'` 判断
- `toastErr` 里做去重：3 秒内同消息合并
- 全局兜底：`window.addEventListener('unhandledrejection', ...)`

### 6.11 练习

1. 【必做】完善 `request.ts` 拦截器，覆盖 401 / 403 / 500 / 网络错误四种。
2. 【必做】把 `toastErr` 落地，把项目里所有 `catch (e) { ElMessage.error(e.message) }` 替换成 `catch (e) { toastErr(e) }`。
3. 【必做】`main.ts` 加全局 `unhandledrejection`。
4. 【必做】跑一遍第 6.9 的三组联调剧本，每种错误都触发一次。
5. 【选做】把 blob 异常处理也走一遍——手工把 token 改错，点导出 CSV，看是否弹「登录过期」。
6. 【选做】封装 `toastOk(msg)` 与 `toastWarn(msg)`，进一步收敛所有 ElMessage 调用。

---

## Day14 总结与作业

### 本日交付物

1. `src/api/course.ts` / `src/api/opLog.ts`
2. `src/views/course/CourseListView.vue` / `CourseEditView.vue`
3. `src/views/log/OpLogListView.vue` / `OpLogDetailDrawer.vue`
4. `src/components/JsonBlock.vue`
5. `src/utils/validators.ts` / `handleErr.ts` / `BizError.ts`
6. `src/api/request.ts` 拦截器升级
7. `main.ts` 全局 `unhandledrejection`

### 本日主线回顾

- **前 3 讲**：课程管理前端完整落地——列表页 5 项搜索 9 列表格，独立路由编辑页 15 字段，科目 → 教练级联下拉，冲突预检 300ms 防抖，发布 / 下架 / 单删 / 批删 4 种业务动作
- **第 4 讲**：Element Plus 校验体系六层分层图，`validator` 三种风格，跨字段 `validateField`，`validators.ts` 抽取
- **第 5 讲**：系统日志前端 4 项搜索 9 列表格，抽屉详情 + `JsonBlock` + CSV 导出
- **第 6 讲**：异常处理四层架构，`BizError` + `toastErr`，`Message` vs `Notification` 分工，全局 `unhandledrejection` 兜底

### 课后作业

1. 【必做】把 Day13 会员表单的 rules 全部改成 `validators.ts` 里的工具，代码行数至少减半。
2. 【必做】用 AI 生成「批量复制课程」功能：多选课程 → 弹窗选新的开课日期 → 保留其他字段一键复制。
3. 【选做】给 `JsonBlock` 增加**语法高亮**（`highlight.js` json 语法）。
4. 【选做】实现「操作日志实时推送」：后端 SSE 推送新日志，前端首页展示滚动 timeline，最多保留 20 条。
5. 【选做】增加「登录尝试记录」独立页面，超阈值高亮，可一键封禁 IP。

### 常见问题排查手册

| 现象 | 可能原因 | 解决 |
|------|--------|-----|
| 编辑页从 A 课跳到 B 课字段没变 | `<router-view>` 未加 `:key` | `<router-view :key="$route.fullPath">` |
| 教练下拉一直是空 | `subjectIds` 字段没返回 | 后端 `coachApi.simpleList()` 补字段 |
| 冲突预检没触发 | debounce 挂在错误 hook | 挂 `@change`，且要 return debounced 函数本身 |
| `datetimerange` 返回 null | `value-format` 没配置 | `value-format="YYYY-MM-DD HH:mm"` |
| CSV 打开中文乱码 | UTF-8 无 BOM | 后端写 `\uFEFF` 头或前端拼接 |
| `ElMessageBox` 控制台红字 | reject 没 catch | 自然抛出让 `await` 跳出，或加 `.catch(() => {})` |
| Message 连续弹 5 次 | 无去重 | `toastErr` 里 `dedup`，3 秒内同消息合并 |
| 401 弹 10 次 | 并发请求都触发 | 加 `isRedirecting` 标志位 |
| `validator` 永远 pending | `callback()` 忘调 | 改 Promise 风格 |
| 修改前一字段，后一字段红字不消失 | 未 `validateField` | `watch` 里手动触发 |
| 抽屉里 `pre` 撑破抽屉 | 无 `max-height` | `max-height: 400px; overflow: auto` |
| `navigator.clipboard` undefined | 非 https | 用 `document.execCommand('copy')` 兜底 |
| `el-input-number` 类型报错 | `form.capacity` 声明成了 `string \| number` | 改为 `number` |
| 编辑保存后浏览器后退回编辑页 | 用了 `router.push` | 改成 `router.replace` |
| 导出 CSV 401 无提示 | 拦截器未处理 blob 分支 | `blob.type === 'application/json'` 时转文本 parse |
| `disabled-date` 禁掉了今天上午 | `< new Date()` | 改成 `< new Date(Date.now() - 864e5)` |
| 编辑态冲突预检把自己算冲突 | 未传 `id` | 预检接口传上 `form.id` |

---

## 附：核心概念速查

### 独立路由编辑页三条选型标准

1. 字段数 > 10
2. 有联动预检
3. 有嵌入子表

满足任一条件用独立路由页，否则用弹窗。

### 校验分层六字口诀

**前端可绕过，后端不可少**。前端只做体验优化，后端才是安全兜底。

### `validator` 一律 Promise 风格

```ts
validator: async (_r, v) => {
  if (条件不满足) throw new Error('提示文案')
  // 正常 return，无需 callback
}
```

### Message vs Notification 分工

- 短反馈（成功 / 校验错 / 警告）→ `ElMessage`
- 长内容 / 服务器错误 / 长任务通知 → `ElNotification`

### 异常处理四层次

1. **Axios 拦截器**：翻译错误为 `BizError`
2. **API 层**（可选）：本地特殊处理
3. **组件层**：`catch (e) { toastErr(e) }`
4. **全局**：`window.addEventListener('unhandledrejection', ...)`

### CSV 导出四步

```
blob → URL.createObjectURL → a.click → revokeObjectURL
```

### `ElMessageBox.confirm` 三色语义

- 正向操作 → `type: 'success'`
- 谨慎操作 → `type: 'warning'`
- 危险操作 → `type: 'warning'` + `confirmButtonClass: 'el-button--danger'`

---
