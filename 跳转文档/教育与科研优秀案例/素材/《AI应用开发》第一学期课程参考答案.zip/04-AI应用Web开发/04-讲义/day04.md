# 《AI 应用 Web 开发》 - 学生讲义（Day04：MySQL + MyBatis 首个 CRUD）

**总讲次：6 讲**
**适用对象：已完成 Day01—Day03 的大二/大三本科生（掌握 Java 基础语法、能熟练使用 IDEA 2024.3+、JDK 25，已跑通 Spring Boot 4.0 三层结构的 `/api/course/list`）**

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 全部案例围绕主线项目展开，数据库统一使用 `yoga_member`，主线表为 `course`（瑜伽课程）、`member`（会员）、`coach`（教练）、`classroom`（教室）。MyBatis 首个 CRUD 案例以最简单的 `category`（课程科目）表切入，第 5 讲升级到 `course` 全流程 CRUD。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | MySQL 安装与连接 + SQL 分类 | 命令行 + 图形化客户端都能连接到 `yoga_member` |
| 第 2 讲 | DDL 建库建表 + 主线 4 表设计 | 完成 `course / member / coach / classroom` 4 张表 |
| 第 3 讲 | DML 与 DQL（增/改/删/查/分组/分页） | 手写 8 条常用查询、掌握 S-F-W-G-H-O-L 口诀 |
| 第 4 讲 | MyBatis 介绍 + 入门程序 | 第一个 `CategoryMapper#selectAll` 跑通 + 看懂 SQL 日志 |
| 第 5 讲 | MyBatis CRUD 完整实现（三层穿通） | `/api/course` 5 端点 Postman 全过 |
| 第 6 讲 | XML 映射进阶 + 动态 SQL 初识 | `listByCondition` + `deleteBatch` XML 版本跑通 |

---

## 第 1 讲：MySQL 安装与连接 + SQL 分类

### 1.1 引入：为什么需要数据库？

想象你现在在管理印想瑜伽会馆：3 位前台、8 位教练、200 位会员、每天 40 节课。所有信息如果只用 Excel 存：

- 前台 A 改会员余额、前台 B 也在改，谁的改动生效？
- 300MB 的 Excel 打开卡 30 秒；
- 电脑蓝屏那一秒，你把 200 位会员从 0 开始重新录一遍；
- 老板要"上个月生日会员名单"，你打开 30 张 sheet 手动筛。

**关系型数据库（RDBMS）**帮你解决这 5 件事：

| 能力 | 说明 |
|---|---|
| **持久化** | 断电不丢，数据落到磁盘 |
| **结构化** | 表 + 行 + 列组织，形如 Excel 但支持约束 |
| **事务** | ACID 保证一致性，改余额和记流水要么全成功、要么全回滚 |
| **索引** | 亿级数据秒级查询 |
| **权限** | 前台、店长、管理员看到的数据不同，账号隔离 |

### 1.2 MySQL 的地位与本课程版本

- MySQL 是**全球最流行的开源关系型数据库**，Java Web 中小型项目首选；
- **本课程版本基线：MySQL 8.0.x**（相对 5.7 支持更好的 JSON、CTE、窗口函数、`check` 约束真正生效）；
- 服务在后台监听 `3306` 端口，客户端（命令行 or 图形化）通过 3306 发 SQL 过去。

🎯 **口诀**：**MySQL 服务在后台跑，客户端只是壳子发 SQL**。

### 1.3 常用图形化客户端 4 选 1

| 产品 | 是否收费 | 特点 |
|---|---|---|
| Navicat Premium | 收费 | 界面友好、中文体验好 |
| **DBeaver** | 免费 | 多数据库通吃、开源 |
| DataGrip | 收费 | JetBrains 家族、和 IDEA 一致 |
| **IDEA Ultimate 内置 Database** | 随 IDEA | 无需安装另一个软件 |

💡 **给学生的建议**：**DBeaver 或 IDEA 内置 Database**——免费、够用、不用额外账号。

### 1.4 三个"必学 SQL 命令"

登录进入 MySQL 之后，先掌握三条最常用的：

```sql
show databases;                                     -- 看看有哪些库
create database yoga_member default charset utf8mb4; -- 建一个新库
use yoga_member;                                    -- 切进这个库
show tables;                                        -- 看看库里有哪些表
```

⚠️ **字符集必须 `utf8mb4`，不要写 `utf8`**——MySQL 早期的 `utf8` 是"伪三字节"，`utf8mb4` 才是真正的 4 字节 UTF-8，能正确存储 emoji 和生僻汉字。

### 1.5 SQL 四大分类

SQL 语言可以按用途分成 4 类：

| 分类 | 全称 | 关键字 | 典型场景 |
|------|------|--------|----------|
| **DDL** | Data Definition Language | `create / drop / alter` | 建库、建表、改表 |
| **DML** | Data Manipulation Language | `insert / update / delete` | 增改删数据 |
| **DQL** | Data Query Language | `select` | 查询数据 |
| **DCL** | Data Control Language | `grant / revoke` | 用户与权限 |

🎯 **口诀**：**DDL 改结构、DML 改数据、DQL 只看、DCL 管人**。

后 2 讲主要练 DML 与 DQL，DCL 本课程不展开（工程实践中大多由 DBA 负责）。

### 1.6 命令行登录 MySQL

```bash
mysql -uroot -p
# 回车后输入密码（练习环境常用 123456）
```

看到 `mysql>` 提示符即成功。若报 `不是内部或外部命令`，说明 MySQL 的 `bin` 目录没加入系统 `Path`。

### 1.7 DBeaver 连接 MySQL

1. 打开 DBeaver → 左上角"新建连接" → 选 `MySQL`；
2. 填 Host `localhost` / Port `3306` / User `root` / Password `123456`；
3. Test Connection → 若提示下载驱动，点 `Download` 即可；
4. Finish，左侧树能看到 `yoga_member` 数据库。

### 1.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Access denied for user 'root'@'localhost'` | 密码错，或大小写敏感；先命令行验证 |
| `Communications link failure` | MySQL 服务未启动 / 端口被占用 |
| 建库不带 `utf8mb4`，后来存中文乱码 | 一律 `default charset utf8mb4`；老库需要 `alter database ... character set utf8mb4` |
| 命令行 `mvn -v` 报错但你输的是 `mysql` | `mysql` 不在 `Path`，把 MySQL 的 `bin` 加进 `Path` |
| 端口 3306 冲突 | 命令行执行 `netstat -ano \| findstr 3306` 找出占用进程 |

### 1.9 练习/思考

1. 用命令行完成 MySQL 登录，执行 `create database yoga_member default charset utf8mb4;`，截图 `show databases;` 的输出。
2. 在自选的图形化客户端里连接同一个 MySQL 服务，左侧数据库列表能看到 `yoga_member`。
3. 查一查 `utf8mb4_0900_ai_ci` 排序规则是什么意思，用 200 字总结 `ai` / `ci` / `bin` 三种后缀的区别。

---

## 第 2 讲：DDL 建库建表 + 主线 4 表设计

### 2.1 引入：从"纸上表格"到"数据库表"

印象瑜伽会馆现在有 4 张纸质表格：会员登记表、课程价目表、教练花名册、教室排布图。要把它们变成数据库的 4 张表，核心就是回答三个问题：

1. **表里有哪些字段？**
2. **每个字段是什么类型？**（数字、文本、日期、金额……）
3. **有哪些约束？**（不能为空、必须唯一、有默认值……）

### 2.2 `create table` 4 段式

```sql
create table 表名 (
    字段名  数据类型  约束  comment '注释',
    ...
) comment '表注释';
```

- **字段名**：小写下划线（如 `create_time`），别用中文；
- **数据类型**：见下节 8 大类；
- **约束**：`primary key / not null / unique / default ...`；
- **注释**：中文写清楚这个字段的含义。

### 2.3 数据类型 8 大类

| 类型族 | 常用成员 | 场景 |
|---|---|---|
| 整型 | `tinyint / int / bigint` | 状态位、年龄、主键（工业级用 `bigint`） |
| 浮点/精确 | `float / double / decimal(m,d)` | **金额必须 `decimal`** |
| 字符串 变长 | `varchar(n)` | 名称、地址（推荐） |
| 字符串 定长 | `char(n)` | 固定长度（如身份证 18 位） |
| 长文本 | `text` | 课程描述、文章内容 |
| 日期时间 | `date / datetime / timestamp` | 生日 / 记录时间 |
| 枚举 | `enum('a','b')` | 工程实践常改用 `tinyint` + 注释 |
| JSON | `json` | 半结构化数据（MySQL 8.0+ 原生支持） |

⚠️ **金额场景不要用 `double` / `float`**——浮点数在计算 `0.1 + 0.2` 时会得到 `0.30000000000000004`，会员余额就错了。**一律 `decimal(10,2)`**（总长 10 位、小数 2 位）。

### 2.4 五大约束

| 约束 | 关键字 | 例子 |
|---|---|---|
| 主键 | `primary key` | `id int primary key auto_increment` |
| 非空 | `not null` | `name varchar(32) not null` |
| 唯一 | `unique` | `phone varchar(11) unique` |
| 默认值 | `default` | `status tinyint default 1` |
| 检查 | `check` | `check (age > 0)`（MySQL 8.0.16+ 生效） |

💡 关于**外键 `foreign key`**：教科书里必学，但**工程实践中常常不加**，改由 Service 层保证一致性——理由是删除、迁移、分库分表时外键会带来一堆麻烦。本课程主线 4 张表**不用外键**。

### 2.5 主线 4 张表建表 SQL

#### 2.5.1 瑜伽课程表 `course`

```sql
create table course (
    id           int          primary key auto_increment comment '主键',
    name         varchar(50)  not null                 comment '课程名，如"哈他初级"',
    category_id  int                                   comment '课程科目 id',
    coach_id     int                                   comment '主教练 id',
    duration     int          default 60               comment '时长（分钟）',
    price        decimal(10,2) not null                comment '课程单价',
    image        varchar(300)                          comment '封面图 url',
    description  text                                  comment '课程简介',
    status       tinyint      default 1                comment '1上架 0下架',
    create_time  datetime     default current_timestamp,
    update_time  datetime     default current_timestamp on update current_timestamp
) comment '瑜伽课程表';
```

#### 2.5.2 会员表 `member`

```sql
create table member (
    id           int          primary key auto_increment,
    name         varchar(32)  not null                 comment '会员姓名',
    phone        varchar(11)  unique                   comment '手机号，登录用',
    gender       tinyint                               comment '1男 2女',
    birthday     date                                  comment '生日',
    level        tinyint      default 1                comment '1普通 2黄金 3钻石',
    balance      decimal(10,2) default 0.00            comment '会员卡余额',
    create_time  datetime     default current_timestamp,
    update_time  datetime     default current_timestamp on update current_timestamp
) comment '会员表';
```

#### 2.5.3 教练表 `coach`

```sql
create table coach (
    id           int          primary key auto_increment,
    name         varchar(32)  not null,
    phone        varchar(11)  unique,
    level        tinyint      default 1                comment '1初级 2中级 3高级',
    intro        text                                  comment '教练简介',
    image        varchar(300)                          comment '头像',
    create_time  datetime     default current_timestamp,
    update_time  datetime     default current_timestamp on update current_timestamp
) comment '教练表';
```

#### 2.5.4 教室表 `classroom`

```sql
create table classroom (
    id           int          primary key auto_increment,
    name         varchar(32)  not null unique,
    capacity     int          default 20               comment '容量',
    create_time  datetime     default current_timestamp,
    update_time  datetime     default current_timestamp on update current_timestamp
) comment '教室表';
```

### 2.6 `alter table` 三兄弟

改表结构 3 大操作 + 重命名：

```sql
-- 加字段
alter table course add column tags varchar(200);

-- 改字段类型/约束
alter table course modify column price decimal(10,2) not null;

-- 删字段
alter table course drop column tags;

-- 重命名表
alter table course rename to yoga_course;
```

用 `desc course;` 或 `show create table course;` 反查表结构，验证结果。

### 2.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 金额用 `double` 存，算总账每次差 1 分 | 金额一律 `decimal(10,2)`，别偷懒 |
| `varchar(2000)` 存手机号 | 数据类型是设计的一部分，别"一律 varchar 越大越好" |
| 忘记 `default charset utf8mb4`，插入中文乱码 | 建库时就要写，事后补虽然可以但麻烦 |
| `alter table` 改字段类型，数据丢失 | 生产环境改字段前一定要备份 |
| `enum('普通','黄金','钻石')` 后来想加新等级 | 工程实践常改用 `tinyint` + 注释，扩展方便 |

### 2.8 练习/思考

1. 手写完整 4 张表建表 SQL（`course / member / coach / classroom`），字段注释齐全，字符集 `utf8mb4`。
2. 用 `alter table` 给 `course` 加一个 `tags varchar(200)` 字段，再删掉；截屏两次 `desc course;` 前后对比。
3. 让通义灵码/Trae 给你生成第 5 张表 `booking`（预约表：`id / member_id / course_id / classroom_id / book_time / status / create_time / update_time`），要求给出 3 个方案对比（有外键 vs 无外键 vs 组合唯一索引），并解释你的选型理由，写 200 字。

---

## 第 3 讲：DML 与 DQL（增改删 + 查询六件套）

### 3.1 引入：一句 SQL 引发的血案

某年某月某日，某工程师执行：

```sql
update user set password = '123' where id = 1;
```

不小心多按了一次回车，`where` 还没输完就 Enter，实际执行：

```sql
update user set password = '123';
```

**全站 300 万用户密码变成 `123`**，第二天早晨老板亲自去机房拔电源。

⚠️ **DML 铁律：`update / delete` 必带 `where`，除非你真的想全表操作**。生产上常见做法：先在事务里 `begin` → 执行 → `select` 检查 → 满意才 `commit`；不对就 `rollback`。

### 3.2 DML 三兄弟

#### 3.2.1 插入 `insert`

```sql
-- 指定列
insert into course(name, category_id, price)
values('哈他初级', 1, 199.00);

-- 全部列（对应表定义所有列的顺序）
insert into course values(default, '阿斯汤加进阶', 2, 1, 90, 299.00,
                         null, '中级课程', 1, default, default);

-- 批量
insert into course(name, price) values
('阴瑜伽入门', 199.00),
('流瑜伽进阶', 299.00),
('高温 26 式',  399.00);
```

`default` 让主键 `id` 自增、时间戳自动填充。

#### 3.2.2 更新 `update`

```sql
update course set price = 259.00 where id = 1;
update course set price = price * 0.9 where category_id = 2;   -- 打 9 折
```

#### 3.2.3 删除 `delete`

```sql
delete from course where id = 5;
delete from course where status = 0;         -- 删所有已下架课程
truncate table course;                       -- 清空+重置自增，无法回滚
```

`delete` vs `truncate`：

| 命令 | 能带 where | 触发触发器 | 重置自增 | 可回滚 |
|---|:---:|:---:|:---:|:---:|
| `delete` | ✅ | ✅ | ❌ | ✅ |
| `truncate` | ❌ | ❌ | ✅ | ❌ |

### 3.3 DQL 六件套（查询的骨架）

```sql
select  <字段列表>       -- 投影
from    <表>
where   <行过滤>
group by <分组>
having  <组过滤>
order by <排序>
limit   <偏移, 数量>
```

🎯 **书写顺序口诀 S-F-W-G-H-O-L**：**S**elect **F**rom **W**here **G**roup by **H**aving **O**rder by **L**imit。

🎯 **执行顺序 F-W-G-H-S-O-L**：**F**rom → **W**here → **G**roup by → **H**aving → **S**elect → **O**rder by → **L**imit（这也解释了为什么 SELECT 里定义的别名在 WHERE 里用不了——WHERE 先执行）。

### 3.4 六件套逐个练

#### 3.4.1 投影与条件

```sql
select id, name, price from course;
select username as u, price as p from course;
select * from course where price >= 200;
select * from course where name like '哈他%';
select * from member where phone is not null and gender = 2;
```

常用运算符：`= != <> > < >= <= between and in like is null and or not`。

#### 3.4.2 排序 `order by`

```sql
select * from course order by price desc, create_time asc;
```

`desc` 降序、`asc` 升序（默认）。

#### 3.4.3 分页 `limit`

```sql
select * from course order by price desc limit 0, 5;   -- 第 1 页 5 条
select * from course order by price desc limit 5, 5;   -- 第 2 页 5 条
```

🎯 **分页公式**：`limit (page-1)*size, size`。

⚠️ `limit 5, 10` 里的 `5` 是**偏移量**（跳过前 5 条），不是页码。这是新手第一个大坑。

#### 3.4.4 聚合函数 5 兄弟

```sql
select
    count(*)   as total,
    avg(price) as avg_price,
    max(price) as max_price,
    min(price) as min_price,
    sum(price) as sum_price
from course;
```

#### 3.4.5 分组 `group by` + `having`

```sql
select category_id, count(*) as cnt, avg(price) as avg_price
from course
group by category_id
having count(*) > 2
order by cnt desc;
```

💡 **`where` vs `having`**：

- `where` 在**分组前**过滤行；
- `having` 在**分组后**过滤组，可以用聚合函数。

### 3.5 让 AI 造 100 条 mock 数据

上面练习没数据？让 AI 帮你造：

```text
帮我生成 100 条 insert into member(name, phone, gender, birthday, level, balance) values(...);
要求：
1. 姓名用真实中文姓名；
2. 手机号 11 位、必须唯一，13/15/17/18/19 开头；
3. gender 随机 1 或 2；
4. 生日在 1985-2005 年之间；
5. level 按 70% 普通、20% 黄金、10% 钻石分布；
6. 余额随机 0-9999.99。
```

在 DBeaver / DataGrip 里执行返回结果，`select count(*) from member;` 验证 100 条。

### 3.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `update` / `delete` 不带 `where` = 全表事故 | 生产上先 `begin` 试跑再 `commit` |
| `limit 5, 10` 里的 5 以为是页码 | 5 是**偏移**，跳过前 5 条 |
| SELECT 别名在 WHERE 里用不了 | 执行顺序 F-W 在 S 之前，WHERE 时别名还不存在 |
| `group by` 后 SELECT 出现非分组字段 | MySQL 8.0 严格模式下会报错，只能出现分组字段或聚合结果 |
| `where` 里想用 `count(*) > 2` | 用不了，改用 `having` |
| 中文乱码 | 建库 `utf8mb4` + JDBC url `useUnicode=true&characterEncoding=utf8` |

### 3.7 练习/思考

1. 在 `course` 表上完成 8 条查询：全查 / 单条件 / 多条件 / 模糊 / 分页 / 分组 / 聚合 / 排序，每条附截图。
2. 让 AI 生成 100 条 `member` 表 mock `insert` 数据（手机号唯一），执行后 `select count(*) from member;` 验证。
3. 写一条"每个会员等级的平均余额，按等级排序"的查询，然后思考"如果我想只显示平均余额 > 1000 的等级，应该用 `where` 还是 `having`？"，写 100 字解释。
4. **思考**：`update course set price = price * 0.9;` 忘记加 `where`，怎么补救？（提示：备份、二进制日志、事务）

---

## 第 4 讲：MyBatis 介绍 + 入门程序

### 4.1 引入：裸 JDBC 有多痛？

想象你要用纯 JDBC 查一次 `select * from category` 并封装成 `List<Category>`：

```java
Class.forName("com.mysql.cj.jdbc.Driver");
Connection conn = DriverManager.getConnection(url, user, pwd);
PreparedStatement ps = conn.prepareStatement("select * from category");
ResultSet rs = ps.executeQuery();
List<Category> list = new ArrayList<>();
while (rs.next()) {
    Category c = new Category();
    c.setId(rs.getInt("id"));
    c.setName(rs.getString("name"));
    c.setCode(rs.getString("code"));
    // ... 每个字段都要 setXxx
    list.add(c);
}
rs.close(); ps.close(); conn.close();
```

**痛点 3 连**：

1. 代码冗长（30 多行）；
2. 字段一个个 `rs.getXxx` 手动映射，字段一多就疯；
3. `close()` 忘记就是连接泄漏。

**MyBatis** 帮你把这 3 件事变成 3 行。

### 4.2 MyBatis 是什么

**MyBatis = 半自动化 ORM 框架**：

- **半自动**：程序员写 SQL、框架自动做**参数映射**和**结果封装**；
- 相比 Hibernate 的**全自动**（框架帮你生成 SQL），MyBatis 更贴近 SQL、性能可控、DBA 也看得懂；
- **国内 Java Web 项目主流选 MyBatis**。

| 维度 | 全自动 ORM（Hibernate） | 半自动 ORM（MyBatis） |
|---|---|---|
| SQL 谁写 | 框架生成 | 程序员写 |
| 学习成本 | 高 | 低 |
| 复杂查询 | 痛苦 | 灵活 |
| 性能可控性 | 弱 | 强 |
| 国内主流度 | 低 | **高** |

### 4.3 Spring Boot 集成三件套

| 步骤 | 内容 |
|---|---|
| ① pom.xml | `mybatis-spring-boot-starter:3.0.5+` + `mysql-connector-j` |
| ② application.yml | `spring.datasource` + `mybatis.configuration/mapper-locations/type-aliases-package` |
| ③ Mapper 接口 | 加 `@Mapper`，用 `@Select("...")` 写 SQL |

⚠️ **版本坑**：Spring Boot 4.0 必须用 `mybatis-spring-boot-starter:3.0.5+`。老版本 `2.x` 会在启动时报 `NoSuchMethodError`。

### 4.4 `pom.xml` 完整依赖

```xml
<dependencies>
    <!-- Spring Boot Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <!-- MyBatis Starter，兼容 Spring Boot 4 -->
    <dependency>
        <groupId>org.mybatis.spring.boot</groupId>
        <artifactId>mybatis-spring-boot-starter</artifactId>
        <version>3.0.5</version>
    </dependency>
    <!-- MySQL 驱动 -->
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
    </dependency>
    <!-- Lombok -->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
</dependencies>
```

### 4.5 `application.yml` 三段配置

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/yoga_member?serverTimezone=Asia/Shanghai&useSSL=false
    username: root
    password: '123456'
    driver-class-name: com.mysql.cj.jdbc.Driver

mybatis:
  configuration:
    map-underscore-to-camel-case: true                       # 下划线转驼峰
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl    # 打印 SQL 到控制台
  mapper-locations: classpath:mapper/*.xml                   # XML 映射文件位置
  type-aliases-package: com.yinxiang.yogamember.pojo         # 实体类包，XML 里可直接写类名
```

三段的作用：

- **`spring.datasource`**：数据库连接四件套（url / username / password / driver）；
- **`mybatis.configuration`**：MyBatis 运行时行为（驼峰映射、SQL 日志）；
- **`mapper-locations` + `type-aliases-package`**：告诉 MyBatis 去哪里找 XML、实体类叫什么。

### 4.6 前置准备：建 `category` 表 + 插数据

```sql
use yoga_member;

create table category (
    id          int primary key auto_increment,
    name        varchar(32) not null unique,
    code        varchar(32),
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '课程科目';

insert into category(name, code) values
('哈他',   'HATHA'),
('阿斯汤加','ASHTANGA'),
('阴瑜伽',  'YIN'),
('流瑜伽',  'VINYASA');
```

### 4.7 实体类 `Category`

```java
package com.yinxiang.yogamember.pojo;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Category {
    private Integer id;
    private String name;
    private String code;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
```

💡 数据库里 `create_time` 是下划线、实体里 `createTime` 是驼峰——靠 `map-underscore-to-camel-case: true` 自动打通。

### 4.8 第一个 Mapper 接口

```java
package com.yinxiang.yogamember.mapper;

import com.yinxiang.yogamember.pojo.Category;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface CategoryMapper {

    @Select("select * from category order by id")
    List<Category> selectAll();
}
```

`@Mapper` 让 Spring Boot Starter 在启动时**扫描接口 + 用动态代理生成实现类**，你不需要自己写实现。

### 4.9 用单元测试跑起来

```java
package com.yinxiang.yogamember;

import com.yinxiang.yogamember.mapper.CategoryMapper;
import com.yinxiang.yogamember.pojo.Category;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.List;

@SpringBootTest
class CategoryMapperTest {

    @Autowired
    CategoryMapper categoryMapper;

    @Test
    void selectAll() {
        List<Category> list = categoryMapper.selectAll();
        list.forEach(System.out::println);
    }
}
```

跑起来，控制台看到：

```text
==>  Preparing: select * from category order by id
==> Parameters:
<==      Total: 4
Category(id=1, name=哈他, code=HATHA, createTime=..., updateTime=...)
Category(id=2, name=阿斯汤加, code=ASHTANGA, ...)
Category(id=3, name=阴瑜伽, code=YIN, ...)
Category(id=4, name=流瑜伽, code=VINYASA, ...)
```

日志三段式：

- `Preparing`：最终执行的 SQL；
- `Parameters`：绑定的参数（无参数则为空）；
- `Total`：返回的行数。

### 4.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `NoSuchBeanDefinitionException: CategoryMapper` | 忘加 `@Mapper` 注解；或包扫描路径不覆盖 Mapper 目录 |
| 字段 `createTime = null` | 忘开 `map-underscore-to-camel-case: true` |
| `Communications link failure` | 数据库连接不通，检查 url / 服务是否启动 |
| 用 `2.x` 版本 Starter，启动报 `NoSuchMethodError` | 升到 `3.0.5+`（兼容 Spring Boot 4） |
| 控制台不打印 SQL | 没配 `log-impl: StdOutImpl`；或日志级别过高 |
| 中文乱码 | JDBC url 加 `useUnicode=true&characterEncoding=utf8` |

### 4.11 练习/思考

1. 完成 `category` 表 + `Category` 实体 + `CategoryMapper#selectAll` 全流程，控制台看到 SQL 日志 + 4 条数据。
2. 为 `CategoryMapper` 再加两个方法：`getById(Integer id)` 和 `getByCode(String code)`，用 `@Select` 注解写 SQL，写测试跑通。
3. 故意把 `map-underscore-to-camel-case` 改成 `false`，重新跑测试，观察日志，思考并写 100 字解释为什么 `createTime` 变成了 `null`。
4. **思考**：Mapper 接口没有实现类，是谁在运行时"生成"了它？（提示：JDK 动态代理）

---

## 第 5 讲：MyBatis CRUD 完整实现（Controller / Service / Mapper / DB 四层穿通）

### 5.1 引入：四层穿通

Day03 学的三层结构 + 今天的 MyBatis + MySQL，一共是 4 层：

```
Postman → Controller → Service → Mapper → MySQL
                             ↑↓  参数映射 & 结果封装
                             ↑↓  这一层就是 MyBatis
```

本讲目标：**在 Postman 里点一次 POST，数据落到 MySQL 里；点一次 GET，数据从 MySQL 一路吐回来**。

### 5.2 实体类 `Course`

```java
package com.yinxiang.yogamember.pojo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Course {
    private Integer id;
    private String name;
    private Integer categoryId;
    private Integer coachId;
    private Integer duration;
    private BigDecimal price;       // 金额用 BigDecimal，映射 decimal
    private String image;
    private String description;
    private Integer status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
```

⚠️ **金额一定用 `BigDecimal`**，不能用 `double`，否则又要重蹈"0.1 + 0.2 = 0.30000000000000004"的老路。

### 5.3 CourseMapper 完整 5 方法

```java
package com.yinxiang.yogamember.mapper;

import com.yinxiang.yogamember.pojo.Course;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface CourseMapper {

    @Select("select * from course order by update_time desc")
    List<Course> list();

    @Select("select * from course where id = #{id}")
    Course getById(Integer id);

    @Insert("insert into course(name, category_id, coach_id, duration, price, image, description, status, create_time, update_time) " +
            "values(#{name}, #{categoryId}, #{coachId}, #{duration}, #{price}, #{image}, #{description}, #{status}, now(), now())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Course course);

    @Update("update course set name=#{name}, category_id=#{categoryId}, coach_id=#{coachId}, " +
            "duration=#{duration}, price=#{price}, image=#{image}, description=#{description}, " +
            "status=#{status}, update_time=now() where id=#{id}")
    void update(Course course);

    @Delete("delete from course where id = #{id}")
    void deleteById(Integer id);
}
```

### 5.4 关键注解拆解

#### 5.4.1 参数占位 `#{}`

- 单参数：`@Select("... where id = #{id}")`
- 多参数：加 `@Param`：
  ```java
  @Select("select * from course where category_id = #{cid} and status = #{status}")
  List<Course> listByCategoryAndStatus(@Param("cid") Integer categoryId,
                                       @Param("status") Integer status);
  ```
- 实体：`#{name}` 直接取 `course.getName()`。

`#{}` 最终会翻译成 JDBC 的 `?`，**预编译、防 SQL 注入**。

#### 5.4.2 主键回填 `@Options`

```java
@Options(useGeneratedKeys = true, keyProperty = "id")
```

- `useGeneratedKeys = true`：使用数据库自增主键；
- `keyProperty = "id"`：把生成的主键值回填到 `course` 对象的 `id` 属性。

好处：`insert` 完之后可以直接 `course.getId()` 拿到刚插入的主键，用于**返回给前端**或**继续插入子表**。

#### 5.4.3 返回值

- 查列表：`List<Course>`
- 查单条：`Course`（找不到返回 `null`）
- 增改删：`void` 或 `int`（受影响行数）

### 5.5 Service 层

接口：

```java
package com.yinxiang.yogamember.service;

import com.yinxiang.yogamember.pojo.Course;
import java.util.List;

public interface CourseService {
    List<Course> list();
    Course getById(Integer id);
    void save(Course course);
    void update(Course course);
    void deleteById(Integer id);
}
```

实现（构造器注入，来自 Day03 的传统）：

```java
package com.yinxiang.yogamember.service.impl;

import com.yinxiang.yogamember.mapper.CourseMapper;
import com.yinxiang.yogamember.pojo.Course;
import com.yinxiang.yogamember.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseMapper courseMapper;

    public List<Course> list()              { return courseMapper.list(); }
    public Course getById(Integer id)       { return courseMapper.getById(id); }
    public void save(Course course)         { courseMapper.insert(course); }
    public void update(Course course)       { courseMapper.update(course); }
    public void deleteById(Integer id)      { courseMapper.deleteById(id); }
}
```

### 5.6 Controller 层

```java
package com.yinxiang.yogamember.controller;

import com.yinxiang.yogamember.pojo.Course;
import com.yinxiang.yogamember.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/course")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public List<Course> list() {
        return courseService.list();
    }

    @GetMapping("/{id}")
    public Course get(@PathVariable Integer id) {
        return courseService.getById(id);
    }

    @PostMapping
    public void save(@RequestBody Course course) {
        courseService.save(course);
    }

    @PutMapping
    public void update(@RequestBody Course course) {
        courseService.update(course);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Integer id) {
        courseService.deleteById(id);
    }
}
```

### 5.7 用 Postman / Apifox / IDEA HTTP Client 测试

```text
GET    http://localhost:8080/api/course
GET    http://localhost:8080/api/course/1

POST   http://localhost:8080/api/course
       Content-Type: application/json
       {
         "name": "高温 26 式",
         "categoryId": 1,
         "coachId": 2,
         "duration": 90,
         "price": 399.00,
         "status": 1
       }

PUT    http://localhost:8080/api/course
       Content-Type: application/json
       {
         "id": 5,
         "name": "高温 26 式 · 改版",
         "categoryId": 1,
         "coachId": 2,
         "duration": 90,
         "price": 459.00,
         "status": 1
       }

DELETE http://localhost:8080/api/course/5
```

⚠️ **POST/PUT 一定要设置 `Content-Type: application/json`**，否则会报 `415 Unsupported Media Type`。

### 5.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Invalid bound statement (not found)` | Mapper 接口方法名与 XML/注解 SQL id 不一致 |
| `BindingException: Parameter 'xxx' not found` | 多参未加 `@Param` |
| 字段全 `null` | 忘开 `map-underscore-to-camel-case: true` |
| POST 请求返回 415 | Postman 没设 `Content-Type: application/json` |
| POST 后 `course.getId()` 是 `null` | 忘加 `@Options(useGeneratedKeys=true, keyProperty="id")` |
| `@Insert` SQL 字符串拼接漏空格 | 每段字符串末尾留一个空格；或用 Java 21 文本块 `"""..."""` |
| 金额算错 | 实体属性用 `BigDecimal`，不用 `double` / `float` |
| 中文乱码 | JDBC url 加 `useUnicode=true&characterEncoding=utf8` |

### 5.9 练习/思考

1. 完成 `CourseMapper` 5 方法 + Service + Controller，用 Postman 完整测试 5 个端点，每个端点截图。
2. 仿照 `Course` 的写法，为 `Coach` 表实现完整 CRUD，暴露 `/api/coach` REST 接口。
3. 让通义灵码/Trae 一次性生成 `Member` 表的完整三层代码（4 个文件），你负责审读并修正 3 个不合理点（如：主键回填缺失、`@Mapper` 遗漏、`@RequestBody` 没写等），写 200 字复盘。
4. **思考**：`@Autowired` 和 `@RequiredArgsConstructor + final` 有什么区别？为什么 Spring 官方推荐后者？

---

## 第 6 讲：XML 映射进阶 + 动态 SQL 初识

### 6.1 引入：一句 SQL 引发的数据泄漏

看下面这段"看起来正常"的 SQL：

```sql
select * from user where name = '${name}'
```

如果攻击者把 `name` 传成：

```text
' or '1'='1
```

最终执行的 SQL 变成：

```sql
select * from user where name = '' or '1'='1'
```

**全表返回**，整个用户表被扫走。这就是**SQL 注入**。

罪魁祸首是 `${}`——**字符串直接拼接，不做预编译**。改成 `#{name}` 就能防住。

⚠️ **本讲最重要的一条**：**`${}` 是 SQL 注入直通车，除非表名/字段名/排序方向这种不能预编译的位置，其他一律用 `#{}`**。

### 6.2 XML 映射文件基本结构

XML 映射文件放在 `src/main/resources/mapper/CourseMapper.xml`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
    "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.yinxiang.yogamember.mapper.CourseMapper">

    <select id="list" resultType="Course">
        select * from course order by update_time desc
    </select>

</mapper>
```

三条关键规则：

1. `namespace` = **Mapper 接口的全限定类名**（一字不差）；
2. `<select>` 的 `id` = **Mapper 接口对应方法名**（一字不差）；
3. `resultType` 写实体类名（因为 `application.yml` 里配了 `type-aliases-package`，不用写全限定）。

💡 同一个方法**不要既有 `@Select` 又有 XML `<select>` 同名**——二者会冲突，XML 优先。工程实践建议**简单 SQL 用注解、复杂 SQL 用 XML**，二选一。

### 6.3 `#{}` vs `${}`

| 占位符 | 本质 | 防 SQL 注入 | 场景 |
|---|---|:---:|---|
| `#{}` | 预编译占位符 = JDBC `?` | ✅ | **99% 场景用这个**，传值 |
| `${}` | 字符串拼接 | ❌ | 表名/字段名/`order by` 方向 |

例：

```xml
<!-- ✅ 值用 #{} -->
<select id="getById" resultType="Course">
    select * from course where id = #{id}
</select>

<!-- ✅ 排序方向用 ${}（不能预编译） -->
<select id="listOrder" resultType="Course">
    select * from course order by price ${direction}
</select>
```

调 `listOrder("desc")` 会拼成 `order by price desc`。此时 `${direction}` 必须在**服务端白名单校验**（只允许 `asc` / `desc`），否则同样有注入风险。

### 6.4 `<resultMap>` 处理字段不对应

如果数据库字段和实体属性靠驼峰对应不上（如遗留系统字段叫 `course_name`、实体属性叫 `name`），用 `<resultMap>` 显式声明：

```xml
<resultMap id="CourseMap" type="Course">
    <id     property="id"     column="id"/>
    <result property="name"   column="course_name"/>
    <result property="price"  column="course_price"/>
</resultMap>

<select id="listWithCustom" resultMap="CourseMap">
    select id, course_name, course_price from course
</select>
```

`<id>` 用于主键、`<result>` 用于普通字段。

### 6.5 动态 SQL 三大标签

| 标签 | 作用 | 典型场景 |
|---|---|---|
| `<if>` | 条件片段 | 有条件才拼这段 |
| `<where>` | 智能 where | 自动去掉首个多余的 `and/or` |
| `<set>` | 智能 set（`update`） | 自动去掉多余逗号 |
| `<choose>/<when>/<otherwise>` | switch | 多分支 |
| `<foreach>` | 遍历集合 | `in (...)` / 批量 insert |
| `<sql>/<include>` | 片段复用 | 通用字段列表 |

### 6.6 案例 1：条件查询 `listByCondition`

Mapper 接口：

```java
List<Course> listByCondition(@Param("name") String name,
                             @Param("status") Integer status,
                             @Param("begin") java.time.LocalDate begin,
                             @Param("end") java.time.LocalDate end);
```

XML：

```xml
<select id="listByCondition" resultType="Course">
    select * from course
    <where>
        <if test="name != null and name != ''">
            and name like concat('%', #{name}, '%')
        </if>
        <if test="status != null">
            and status = #{status}
        </if>
        <if test="begin != null">
            and create_time &gt;= #{begin}
        </if>
        <if test="end != null">
            and create_time &lt;= #{end}
        </if>
    </where>
    order by update_time desc
</select>
```

`<where>` 会**自动去掉首个 `and`**，你不用担心第一个 `<if>` 里那个多余的 `and`。

调用示例：

```java
courseMapper.listByCondition("哈他", 1, null, null);
// SQL: select * from course where name like concat('%',?,'%') and status = ? order by update_time desc

courseMapper.listByCondition(null, null, null, null);
// SQL: select * from course order by update_time desc  (where 整段消失)
```

⚠️ **XML 里 `>` `<` 必须转义**：

- `>` → `&gt;`
- `<` → `&lt;`
- 或者用 `<![CDATA[ ... ]]>` 包裹整段 SQL

### 6.7 案例 2：批量删除 `deleteBatch`

Mapper 接口：

```java
void deleteBatch(@Param("ids") java.util.List<Integer> ids);
```

XML：

```xml
<delete id="deleteBatch">
    delete from course where id in
    <foreach collection="ids" item="id" open="(" close=")" separator=",">
        #{id}
    </foreach>
</delete>
```

调用：

```java
courseMapper.deleteBatch(List.of(3, 4, 5));
// SQL: delete from course where id in ( ? , ? , ? )
// Parameters: 3, 4, 5
```

`<foreach>` 的 5 个属性：

| 属性 | 作用 |
|---|---|
| `collection` | 遍历的集合参数名（这里是 `@Param("ids")`） |
| `item` | 每个元素在循环体里的变量名 |
| `open` | 开头字符 |
| `close` | 结尾字符 |
| `separator` | 元素之间的分隔符 |

### 6.8 `<if test>` 里的 OGNL 表达式

`<if test="name != null and name != ''">` 里的 `and` 是 **OGNL 表达式**的关键字，不是 SQL 的 `and`。常用写法：

```xml
<if test="name != null and name != ''">      <!-- 字符串不为空 -->
<if test="status != null">                    <!-- 数字非 null 用它，不要用 status != 0 -->
<if test="list != null and list.size() > 0">  <!-- 集合非空 -->
```

⚠️ 常见错：写成 `<if test="name != null && name != ''">`，`&&` 是 XML 关键字，报解析错误——OGNL 里用 `and` 而不是 `&&`。

### 6.9 XML 与注解如何取舍

| 场景 | 推荐方式 |
|---|---|
| 简单 SQL（一条 select / 单表 CRUD） | 注解（`@Select` / `@Insert` / `@Update` / `@Delete`） |
| 复杂多表 join | XML |
| 动态条件（`<if>` `<foreach>`） | XML |
| SQL 长度超过 200 字符 | XML |
| DBA 想审查 SQL | XML（集中在一处便于审计） |

### 6.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Invalid bound statement (not found)` | `namespace` 或 `<select id>` 写错，或 XML 没被 `mapper-locations` 扫到 |
| 传 `' or '1'='1` 全表泄漏 | 用了 `${}`，改成 `#{}` |
| `<if>` 里写 `&&` 报 XML 错误 | OGNL 用 `and` 不用 `&&` |
| XML 里 `>` `<` 报解析错 | 用 `&gt;` `&lt;` 或 `<![CDATA[...]]>` |
| 注解和 XML 同名冲突 | 二选一；工程建议简单用注解、复杂用 XML |
| `<foreach>` 传入空集合，SQL 变成 `in ()` 报错 | 调用前判断 `if (!ids.isEmpty())` 再调用 |

### 6.11 练习/思考

1. 为 `member` 表写 XML 版本的 `listByCondition`，支持"姓名模糊 + 等级 + 生日区间"三个可选条件，加上分页参数 `page/size`（用 `limit`）。
2. 写 `deleteBatch(List<Integer> ids)`，用 `<foreach>` 实现，在 Controller 暴露 `DELETE /api/course/batch?ids=1,2,3`。
3. 让通义灵码/Trae 给你解释"MyBatis 是怎么把 Mapper 接口和 XML 映射对应起来的"，然后自己在 IDEA 里 Ctrl 点进 `SqlSessionFactoryBean`，找到扫描 XML 的入口，截图并写 200 字复盘。
4. **思考**：如果我坚持想在 `where name = ?` 之前先做一次"表名动态切换"（业务上 `course` 表按月分表，如 `course_202601`、`course_202602`），应该用 `#{}` 还是 `${}`？为什么？如何防止注入？

---

## Day04 学完你应该会

1. ✅ 命令行 + 图形化客户端连接 MySQL 8.0，建库 `yoga_member`（`utf8mb4`）；
2. ✅ 写 `create table` 完成主线 4 张表 `course / member / coach / classroom`，字段注释齐全；
3. ✅ 熟练 DML `insert / update / delete` 三兄弟，牢记"必带 `where`"；
4. ✅ 熟练 DQL 六件套（S-F-W-G-H-O-L），能写条件、排序、分页、聚合、分组；
5. ✅ 集成 MyBatis Starter 三件套（pom + yml + `@Mapper`），跑通第一个 `CategoryMapper#selectAll`；
6. ✅ 用注解方式完整实现 `CourseMapper` 5 方法 + 主键回填 + `/api/course` REST 端点；
7. ✅ 用 XML + 动态 SQL 写"条件查询 + 批量删除"两个典型案例；
8. ✅ 说清 `#{}` vs `${}` 的差异，理解 SQL 注入的原理和防御。

---

## 附录：主线数据库 `sql/init.sql` 完整脚本

供你课后对照检查：

```sql
drop database if exists yoga_member;
create database yoga_member default charset utf8mb4;
use yoga_member;

create table category (
    id          int primary key auto_increment,
    name        varchar(32) not null unique,
    code        varchar(32),
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '课程科目';

insert into category(name, code) values
('哈他', 'HATHA'), ('阿斯汤加', 'ASHTANGA'),
('阴瑜伽', 'YIN'), ('流瑜伽', 'VINYASA');

create table coach (
    id          int primary key auto_increment,
    name        varchar(32) not null,
    phone       varchar(11) unique,
    level       tinyint default 1,
    intro       text,
    image       varchar(300),
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '教练表';

create table classroom (
    id          int primary key auto_increment,
    name        varchar(32) not null unique,
    capacity    int default 20,
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '教室表';

create table course (
    id           int primary key auto_increment,
    name         varchar(50) not null,
    category_id  int,
    coach_id     int,
    duration     int default 60,
    price        decimal(10,2) not null,
    image        varchar(300),
    description  text,
    status       tinyint default 1,
    create_time  datetime default current_timestamp,
    update_time  datetime default current_timestamp on update current_timestamp
) comment '瑜伽课程表';

create table member (
    id          int primary key auto_increment,
    name        varchar(32) not null,
    phone       varchar(11) unique,
    gender      tinyint,
    birthday    date,
    level       tinyint default 1,
    balance     decimal(10,2) default 0.00,
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '会员表';
```

## 附录：AI 辅助 —— 一次性生成完整 CRUD

在 IDEA 通义灵码 / Trae 侧栏发送：

```text
使用 Spring Boot 4.0 + MyBatis 3.5+ + Lombok，为 yoga-member 项目的 course 表生成完整三层代码：
1. Entity 类 Course（Lombok @Data，金额用 BigDecimal，时间用 LocalDateTime）
2. Mapper 接口（@Mapper，注解方式：list/getById/insert/update/deleteById，
   主键回填 @Options(useGeneratedKeys=true, keyProperty="id")）
3. Service 接口 + Impl（构造器注入，Lombok @RequiredArgsConstructor）
4. Controller（RESTful：/api/course，5 个标准端点：GET / GET /{id} / POST / PUT / DELETE /{id}，
   @RequestBody 收 JSON 体）
所有类放在 com.yinxiang.yogamember 包下。
```

拿到 AI 输出后**必须自己审读 5 个点**：

1. `@Mapper` 是否加？
2. `@Options` 主键回填是否加？
3. `@RequestBody` 是否加？
4. 金额是否用 `BigDecimal`？
5. `application.yml` 是否开了 `map-underscore-to-camel-case: true`？

**每段 AI 输出必须自己看懂再粘贴**——AI 是好用的第一版草稿工具，但工程质量的把关权永远在你手里。
