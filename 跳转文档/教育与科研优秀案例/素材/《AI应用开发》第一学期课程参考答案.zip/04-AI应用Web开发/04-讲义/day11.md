# 《AI 应用 Web 开发》 - 学生讲义（Day11：预约管理 CRUD + 拦截器 + JWT + 验证码）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day10 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、Redis 8、Spring Cache、`@Transactional` 传播行为、AOP 操作日志、DTO/VO 分层、Result 统一响应、全局异常处理、参数校验）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / Redis 8 / JJWT 0.12.6 / Kaptcha 2.3.2 / spring-security-crypto（BCrypt） / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day10 我们把 AOP 操作日志、Redis 缓存、`@Transactional` 三件套跑通，会员 / 课程 / 科目 三条业务线拿到了「审计 + 加速 + 一致」三大能力。Day11 前 2 讲把整个后端**最复杂**的一块业务——课程预约——从表结构到 REST 接口完整打穿：多约束校验、Redis 并发扣减、状态机流转、退课签到缺席、日历视图；中间 2 讲讲清 `HandlerInterceptor` 与 `WebMvcConfigurer` 的角色分工，做出后台登录接口 + BCrypt 加盐；最后 2 讲用 JJWT 0.12.6 完成「签发 → 拦截 → 刷新 → 强制下线」的完整鉴权链，并用 Kaptcha 图形验证码把登录接口最后一道门补上。跑完 Day11 六讲，第二部分（后端）**正式收官**，Day12 起切前端 Vue 3。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 预约业务建模 + 会员预约接口 | `tb_booking` 表 + 四态状态机 + `BookingService.create` 六步链路 |
| 第 2 讲 | 取消 / 签到 / 缺席 + 分页 + 日历视图 | `cancel` 五步 + `checkIn` 时间窗口 + `@Scheduled scanAbsent` + `Map<LocalDate, List<VO>>` 日历 |
| 第 3 讲 | Spring 拦截器：`HandlerInterceptor` + `WebMvcConfigurer` | `LogInterceptor` 骨架 + `@AuthIgnore` 注解 + 白名单 + 抛异常代替 `return false` |
| 第 4 讲 | 后台登录 / 退出 + BCrypt 加盐 | `tb_admin_user` 表 + `AdminUserService.checkLogin` + `LoginController` 骨架 |
| 第 5 讲 | JWT 签发与校验（JJWT 0.12.6） | `JwtUtils` 五段签发 / 三段解析 + `JwtInterceptor` + 滑动式 refresh + Redis 黑名单 |
| 第 6 讲 | Kaptcha 图形验证码 + 登录防护 | `/captcha` base64 接口 + `LoginDTO` 加 captcha 字段 + 失败次数锁定 15 分钟 |

---

## 第 1 讲：预约业务建模 + 会员预约接口

### 1.1 引入：一次点击「立即预约」到底要做几件事

Day10 我们把 AOP 操作日志跑通了，会员、教练、课程三个模块的 CRUD 都能被切面自动记录。今天开始收官——**预约**这块业务是整个后端最扎心的一块：一次点击「立即预约」，后端要同时校验会员卡、课程状态、名额、时段冲突、是否重复预约五件事，任何一件不通过都得整体回滚。灵魂问题一句：**10 个会员同时抢最后 1 个名额，你怎么保证只成功 1 个？**

🎯 **一句话目标**：**多约束业务 = 校验分层 + Redis 快通道 + DB UK 兜底 + 手工 Redis 补偿**——今天先把「预约创建」六步链路完整跑通，明天补上生命周期其余四个动作。

### 1.2 预约在业务里的位置

会馆业务链条：

```mermaid
flowchart LR
  M[会员] -- 预约 --> B[预约单]
  B -- 关联 --> C[课程]
  B -- 关联 --> M
  B -- 状态 --> S["已预约/已取消/已签到/缺席"]
  C -- 占用 --> R[教练+教室时段]
```

**预约单**串联了会员、课程、教练、教室四个模块，是**读写压力最大**的表。任何一次预约都涉及：

1. 会员卡是否有效、课时是否够扣；
2. 课程是否处于「报名中 / 已满」状态；
3. 名额是否已满；
4. 该会员是否已重复预约同一课程；
5. 是否与已预约的其他课程时间冲突。

**任一条不通过必须整体回滚**——这就是事务与并发控制的最佳教材。

### 1.3 `tb_booking` 表设计

```sql
CREATE TABLE tb_booking (
  id            BIGINT PRIMARY KEY AUTO_INCREMENT,
  booking_no    VARCHAR(32)  NOT NULL COMMENT '业务单号 YYYYMMDD+8位随机',
  member_id     BIGINT       NOT NULL,
  course_id     BIGINT       NOT NULL,
  card_id       BIGINT       NOT NULL COMMENT '会员卡 id',
  status        TINYINT      NOT NULL DEFAULT 1
                COMMENT '1 已预约 2 已取消 3 已签到 4 缺席',
  cancel_reason VARCHAR(255),
  check_in_time DATETIME,
  remark        VARCHAR(500),
  deleted       TINYINT      DEFAULT 0,
  create_time   DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time   DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_booking_no    (booking_no),
  UNIQUE KEY uk_member_course (member_id, course_id, deleted),
  KEY idx_course (course_id, status),
  KEY idx_member (member_id, create_time)
) COMMENT '预约单';
```

**设计要点**：

- `booking_no` —— 面向用户的业务号 `YYYYMMDD+8 位随机`，比自增 ID 更安全（不暴露业务量）；
- `status` 用 tinyint 加注释，代码里再定义枚举；
- `uk_member_course(member_id, course_id, deleted)` —— **数据库层面**保证同一会员不能对同一课程重复预约；`deleted` 参与 UK 让**软删记录不冲突**，即取消后可以重新预约（这是最容易被忽略的一处，漏了会导致「取消后无法再预约」）；
- 索引 `(course_id, status)` 支撑「查某课程有多少人预约」；`(member_id, create_time)` 支撑「查某会员最近预约」。

### 1.4 四态状态机

```mermaid
stateDiagram-v2
  [*] --> 已预约: 创建
  已预约 --> 已取消: 会员/管理员取消
  已预约 --> 已签到: 到场刷卡
  已预约 --> 缺席: 课程结束仍未签到
  已取消 --> [*]
  已签到 --> [*]
  缺席 --> [*]
```

允许的操作与起始状态：

| 操作 | 允许的起始状态 | 目标状态 |
|------|---------------|---------|
| create     | -           | 已预约 |
| cancel     | 已预约       | 已取消 |
| checkIn    | 已预约       | 已签到 |
| markAbsent | 已预约（定时任务触发） | 缺席 |

**终态一律不可逆**——签到之后不能再取消。

### 1.5 DTO / VO 定义

```java
@Data
public class BookingCreateDTO {
    @NotNull private Long   memberId;
    @NotNull private Long   courseId;
    @NotNull private Long   cardId;
    @Size(max = 500) private String remark;
}

@Data
public class BookingVO {
    private Long          id;
    private String        bookingNo;
    private Long          memberId;
    private String        memberName;
    private Long          courseId;
    private String        courseTitle;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String        coachName;
    private String        roomName;
    private Integer       status;
    private LocalDateTime checkInTime;
    private LocalDateTime createTime;
}
```

**要点**：`BookingVO` 里 `memberName / courseTitle / coachName / roomName` 都是**联表得到**的展示字段，一次查询前端全用——减少调用次数，提升首屏速度。

### 1.6 核心：`create` 六步

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class BookingService {

    private final BookingMapper       bookingMapper;
    private final CourseMapper        courseMapper;
    private final MemberCardService   cardService;
    private final StringRedisTemplate redis;

    @Transactional(rollbackFor = Exception.class)
    @OperationLog(value = "#{'创建预约：course=' + #dto.courseId}",
                  module = "booking",
                  targetIdEl = "#{#_ret}")
    public Long create(BookingCreateDTO dto) {

        // ① 课程校验
        Course c = courseMapper.getById(dto.getCourseId());
        if (c == null || c.getDeleted() == 1) {
            throw new BizException("课程不存在");
        }
        if (c.getStatus() != 2 && c.getStatus() != 3) {
            throw new BizException("当前课程不可预约");
        }
        if (c.getStartTime().isBefore(LocalDateTime.now().plusMinutes(30))) {
            throw new BizException("距课程开始不足 30 分钟，无法预约");
        }

        // ② 会员卡校验（有效期 + 剩余课时）
        MemberCard card = cardService.getUsable(dto.getMemberId(), dto.getCardId());

        // ③ 同一时段冲突（会员已预约的其他课程）
        int conflict = bookingMapper.countMemberConflict(
                dto.getMemberId(), c.getStartTime(), c.getEndTime());
        if (conflict > 0) {
            throw new BizException("同一时段已有其他预约");
        }

        // ④ 名额扣减（Redis 原子操作，并发安全）
        String bookedKey = "course:booked:" + c.getId();
        Long booked = redis.opsForValue().increment(bookedKey);
        if (booked != null && booked == 1) {
            // 首次自增：把 DB 已有的名额同步进来
            int dbCount = bookingMapper.countActive(c.getId());
            redis.opsForValue().set(bookedKey, String.valueOf(dbCount + 1));
            booked = (long) (dbCount + 1);
        }
        if (booked > c.getCapacity()) {
            redis.opsForValue().decrement(bookedKey);
            throw new BizException("名额已满");
        }

        try {
            // ⑤ 落库
            Booking b = new Booking();
            b.setBookingNo(genBookingNo());
            b.setMemberId(dto.getMemberId());
            b.setCourseId(dto.getCourseId());
            b.setCardId(dto.getCardId());
            b.setStatus(1);
            b.setRemark(dto.getRemark());
            bookingMapper.insert(b);

            // ⑥ 卡扣课时 + 课程状态改「已满」
            cardService.deduct(card.getId(), 1);
            if (booked.equals((long) c.getCapacity())) {
                courseMapper.updateStatus(c.getId(), 2, 3); // 2 报名中 → 3 已满
            }
            return b.getId();

        } catch (DuplicateKeyException dke) {
            redis.opsForValue().decrement(bookedKey);
            throw new BizException("请勿重复预约");
        } catch (Exception e) {
            redis.opsForValue().decrement(bookedKey);
            throw e;
        }
    }

    private String genBookingNo() {
        return LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)
             + String.format("%08d", ThreadLocalRandom.current().nextInt(100_000_000));
    }
}
```

🎯 **双保险模型**：**Redis 保证 99% 的并发不打到 DB，DB 唯一键兜底保证「万一 Redis 失效，重复预约也进不了库」**。

时段冲突 SQL（重叠区间判定）：

```xml
<select id="countMemberConflict" resultType="int">
  SELECT COUNT(*)
    FROM tb_booking b
    JOIN tb_course c ON b.course_id = c.id
   WHERE b.member_id = #{memberId}
     AND b.status IN (1, 3)
     AND b.deleted = 0
     AND NOT (c.end_time &lt;= #{start} OR c.start_time &gt;= #{end})
</select>
```

「区间重叠 = 不满足 (A 在 B 之前 或 A 在 B 之后)」是所有日历、会议室、排班业务通用的模板 SQL，抄下来存到自己的速查表。

### 1.7 Controller 骨架

```java
@RestController
@RequestMapping("/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService service;

    @GetMapping
    public Result<PageResult<BookingVO>> page(BookingPageQuery q) {
        return Result.success(service.page(q));
    }

    @GetMapping("/{id}")
    public Result<BookingVO> detail(@PathVariable Long id) {
        return Result.success(service.detail(id));
    }

    @PostMapping
    public Result<Long> create(@RequestBody @Valid BookingCreateDTO dto) {
        return Result.success(service.create(dto));
    }
}
```

**注意**：状态变更接口（取消 / 签到）全部用 `POST`，不要用 `GET`——`GET` 应当只做**幂等读**。

### 1.8 联调剧本

前置：会员 M1 持课时卡（剩 5 课时），课程 C1 容量 3、状态 = 2 报名中。

1. M1 预约 C1 → 200，Redis `course:booked:C1 = 1`，卡余 4；
2. M1 再次预约 C1 → 400「请勿重复预约」（UK 命中）；
3. 另开 3 个会员并发预约 C1 → 只有 2 个成功，第 3 个「名额已满」；DB `booked = 3`、课程状态 = 3 已满；
4. 手工把课程 `capacity` 改成 1，再让 M2 预约 → 走「名额已满」分支；观察 Redis 是否 `DECR` 回退。

### 1.9 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| 并发预约「多卖」 | Redis 首次 `INCR` 未同步 DB 已有数据；或抛异常时忘 `DECR` 回滚 |
| 取消后无法再预约 | `uk_member_course` 未包含 `deleted`——**软删列必须进 UK** |
| `booking_no` 偶发碰撞 | 8 位随机有 1/亿 的碰撞概率——**UK + 重试**兜底 |
| `@Transactional` 里 Redis 未回滚 | Redis 操作**不参与 Spring 事务**，DB 回滚后 Redis `INCR` 不会自动 `DECR`——**catch 里手工 `decrement`** |
| 课程状态被并发改乱 | `UPDATE tb_course SET status=3` 未加 `WHERE status=2`——**始终带 fromStatus 条件** |
| 时区错乱导致校验失败 | `System.currentTimeMillis()` 与 `LocalDateTime` 混用——**全项目统一 `LocalDateTime`** |
| `DuplicateKeyException` 抛到前端 | 未单独 catch 转成 `BizException("请勿重复预约")`——用户看到英文异常栈很不友好 |

### 1.10 练习 / 思考

1. **必做**：建 `tb_booking` 表、跑通「单人预约成功 → 重复预约被拒 → 名额已满」三种场景，交 3 张 Postman 截图（成功 200 / 400 请勿重复 / 400 名额已满）；
2. **必做**：写一段 `curl` 或 JMeter 循环脚本，对同一课程 `capacity=3` 用 10 个不同会员并发预约，验证「只有 3 个成功，其余全部『名额已满』」，交 Redis `course:booked:X = 3` 与 `tb_booking` 3 行成功记录的截图；
3. **思考**：`redis.opsForValue().increment(k)` 到底原子吗？为什么它能挡住 10 个并发线程？（提示：Redis 单线程执行命令，`INCR` 内部无中断）；
4. **挑战**：把 `booking_no` 生成器抽成独立的 `BookingNoGenerator` 组件，支持 `SNOWFLAKE / DATE_RANDOM / DATE_SEQUENCE` 三种策略，用 `@ConditionalOnProperty(name="yoga.booking-no.strategy")` 切换。

---

## 第 2 讲：取消 / 签到 / 缺席 + 分页 + 日历视图

### 2.1 引入：从「只能预约」到「完整生命周期」

上一讲跑通了预约创建，但学员上课当天早上 6 点起床发现下雨，想取消 7 点的瑜伽课——**会馆制度**：距开课不足 2 小时不允许取消（防止老师白跑一趟）。如果学员 8 点才到场，签到还允许吗？——**签到时间窗口**。今天把「已预约」这一态的三条出边（取消 / 签到 / 缺席）补齐，让预约模块真正可以上线。

🎯 **一句话目标**：**取消五步、签到窗口、缺席扫描、分页联表、日历视图**——预约模块生命周期闭环，Part 2 后端业务模块**全部收官**。

### 2.2 `cancel` 五步

```java
@Transactional(rollbackFor = Exception.class)
@OperationLog(value = "#{'取消预约：id=' + #id}", module = "booking", targetIdEl = "#{#id}")
public void cancel(Long id, String reason) {
    // ① 前置校验
    Booking b = bookingMapper.getById(id);
    if (b == null || b.getDeleted() == 1) throw new BizException("预约不存在");
    if (b.getStatus() != 1)                throw new BizException("当前状态不可取消");

    // ② 会馆制度：距开课 >= 2h
    Course c = courseMapper.getById(b.getCourseId());
    if (c.getStartTime().isBefore(LocalDateTime.now().plusHours(2))) {
        throw new BizException("距开课不足 2 小时，无法取消");
    }

    // ③ 乐观 UPDATE，防并发
    int rows = bookingMapper.updateStatus(id, 1, 2, reason);
    if (rows == 0) throw new BizException("并发操作，请重试");

    // ④ Redis 释放名额 + 课程状态回落
    redis.opsForValue().decrement("course:booked:" + c.getId());
    if (c.getStatus() == 3) {
        courseMapper.updateStatus(c.getId(), 3, 2);   // 已满 → 报名中
    }

    // ⑤ 卡课时退回
    cardService.refund(b.getCardId(), 1);
}
```

**顺序原则**：**先 DB 后 Redis**。DB 失败 Redis 不动；反之则 Redis 已减但 DB 没落，会出现短暂不一致窗口。

`updateStatus` XML：

```xml
<update id="updateStatus">
  UPDATE tb_booking
     SET status = #{toStatus},
         cancel_reason = #{reason},
         update_time = NOW()
   WHERE id = #{id}
     AND status = #{fromStatus}
     AND deleted = 0
</update>
```

`AND status = #{fromStatus}` 是**乐观锁核心**——多个线程同时点「取消」，只有第一条 `UPDATE` 影响行数 = 1，其余全部 = 0，走「并发操作」分支。

### 2.3 `checkIn` 签到时间窗口

```java
@OperationLog(value = "#{'签到：id=' + #id}", module = "booking", targetIdEl = "#{#id}")
public void checkIn(Long id) {
    Booking b = bookingMapper.getById(id);
    if (b == null)             throw new BizException("预约不存在");
    if (b.getStatus() != 1)    throw new BizException("当前状态不可签到");

    Course c = courseMapper.getById(b.getCourseId());
    LocalDateTime now = LocalDateTime.now();
    if (now.isBefore(c.getStartTime().minusMinutes(30))
     || now.isAfter(c.getEndTime())) {
        throw new BizException("签到时间不在允许范围内");
    }
    bookingMapper.checkIn(id, now);
}
```

允许区间：`[开课前 30min, 课程结束]`。太早、太晚一律拒。

### 2.4 `@Scheduled` 缺席扫描

```java
@Component
@RequiredArgsConstructor
@Slf4j
public class BookingScheduler {

    private final BookingMapper mapper;

    /** 每小时第 5 分钟扫一次 */
    @Scheduled(cron = "0 5 * * * *")
    public void scanAbsent() {
        int rows = mapper.markAbsent(LocalDateTime.now());
        log.info("[缺席扫描] 标记 {} 条", rows);
    }
}
```

```xml
<update id="markAbsent">
  UPDATE tb_booking b
    JOIN tb_course c ON b.course_id = c.id
     SET b.status = 4,
         b.update_time = NOW()
   WHERE b.status = 1
     AND b.deleted = 0
     AND c.end_time &lt;= #{now}
</update>
```

⚠️ **主启动类必须加 `@EnableScheduling`**，不然定时任务默默不执行，学生的第一坑。

多机部署时 `@Scheduled` 会在每台机器都跑一次——SQL 里的 `status=1` 判定让重复扫描不会出错，但日志会翻倍。Day13 引 ShedLock 或 Redisson 分布式锁解决。

### 2.5 分页 + 联表

`BookingPageQuery` 支持 `memberName / phone / courseTitle / status / beginTime / endTime` 六个查询字段：

```xml
<select id="page" resultMap="BookingVOMap">
  SELECT b.*,
         m.name  AS member_name, m.phone,
         c.title AS course_title, c.start_time, c.end_time,
         co.name AS coach_name,
         r.name  AS room_name
    FROM tb_booking b
    LEFT JOIN tb_member m  ON b.member_id = m.id
    LEFT JOIN tb_course c  ON b.course_id = c.id
    LEFT JOIN tb_coach  co ON c.coach_id  = co.id
    LEFT JOIN tb_room   r  ON c.room_id   = r.id
   WHERE b.deleted = 0
   <if test="memberName  != null and memberName  != ''"> AND m.name    LIKE CONCAT('%', #{memberName}, '%')</if>
   <if test="phone       != null and phone       != ''"> AND m.phone   =   #{phone}</if>
   <if test="courseTitle != null and courseTitle != ''"> AND c.title   LIKE CONCAT('%', #{courseTitle}, '%')</if>
   <if test="status      != null                   ">    AND b.status  =   #{status}</if>
   <if test="beginTime   != null                   ">    AND b.create_time &gt;= #{beginTime}</if>
   <if test="endTime     != null                   ">    AND b.create_time &lt;  #{endTimePlus1Day}</if>
   ORDER BY b.create_time DESC
</select>
```

**要点**：日期区间用 `&gt;= beginTime AND &lt; endTime + 1day`——避开「23:59:59 边界」的老坑。

### 2.6 日历视图接口

```java
public Map<LocalDate, List<BookingBriefVO>> calendar(Long memberId, YearMonth month) {
    LocalDate start = month.atDay(1);
    LocalDate end   = month.atEndOfMonth().plusDays(1);
    List<BookingBriefVO> list = bookingMapper.calendar(memberId,
            start.atStartOfDay(), end.atStartOfDay());
    return list.stream().collect(
        Collectors.groupingBy(BookingBriefVO::getDay,
                              LinkedHashMap::new, Collectors.toList()));
}
```

```xml
<select id="calendar" resultType="com.yoga.vo.BookingBriefVO">
  SELECT b.id, b.status,
         DATE(c.start_time) AS day,
         c.title, c.start_time, c.end_time
    FROM tb_booking b
    JOIN tb_course  c ON b.course_id = c.id
   WHERE b.member_id = #{memberId}
     AND b.deleted   = 0
     AND c.start_time &gt;= #{start}
     AND c.start_time &lt;  #{end}
   ORDER BY c.start_time
</select>
```

返回结构 `Map<LocalDate, List<BookingBriefVO>>`——前端日历组件按 key 渲染，无需二次分组。

### 2.7 Controller 补齐

```java
@PostMapping("/{id}/cancel")
public Result<Void> cancel(@PathVariable Long id,
                           @RequestParam(required = false) String reason) {
    service.cancel(id, reason);
    return Result.success();
}

@PostMapping("/{id}/check-in")
public Result<Void> checkIn(@PathVariable Long id) {
    service.checkIn(id);
    return Result.success();
}

@GetMapping("/calendar")
public Result<Map<LocalDate, List<BookingBriefVO>>> calendar(
        @RequestParam Long memberId,
        @RequestParam(required = false) String month) {
    YearMonth ym = month == null ? YearMonth.now() : YearMonth.parse(month);
    return Result.success(service.calendar(memberId, ym));
}
```

### 2.8 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| 并发下取消一条被 `DECR` 两次 | `updateStatus` 未加 `AND status=1`——**乐观锁靠 fromStatus 条件** |
| 定时任务默默不跑 | 主启动类漏 `@EnableScheduling` |
| 缺席扫描重复日志 | 多机部署下 `@Scheduled` 每机一次——SQL 里判 `status=1` 幂等；Day13 引 ShedLock |
| 分页日期少算一天 | 用 `<= endTime` 会漏掉 `23:59:59.999` 后的记录——改 `< endTime + 1day` |
| 日历跨月边界报错 | 自己写 `if (month==12)` 越界——**用 `YearMonth.atDay(1) / atEndOfMonth()`** |
| Redis 已减但 DB 未落 | 顺序颠倒（先 Redis 后 DB），DB 抛异常时 Redis 不会自动补——**先 DB 后 Redis** |
| 取消后课程状态不回落 | 忘 `if (c.getStatus() == 3) updateStatus(id, 3, 2)`——**已满 → 报名中** |

### 2.9 练习 / 思考

1. **必做**：完成 `cancel / checkIn / page / calendar` 四个接口，Postman 每个至少一张成功截图；整理「预约模块 8 个业务异常」速查表——重复预约 / 名额已满 / 距开课不足 30 分钟 / 距开课不足 2 小时取消 / 签到太早 / 签到太晚 / 并发操作 / 会员卡失效；
2. **必做**：故意把 `updateStatus` 里的 `AND status=1` 去掉，用两个 Postman Runner 同时点「取消」，观察 Redis 会不会被 `DECR` 两次、课程状态会不会被回落两次——把复现日志贴到作业里；
3. **思考**：`@Scheduled` 多机部署下如何避免重复执行？为什么本课不用 `synchronized` 而用「Redis 分布式锁」？（提示：`synchronized` 只在 JVM 内有效）；
4. **挑战**：实现「候补预约」——满员时允许排队进入 `tb_booking_wait`，取消时按 FIFO 自动上位（提示：Redis `List` 或 `ZSet`）。

---

## 第 3 讲：Spring 拦截器（`HandlerInterceptor` + `WebMvcConfigurer`）

### 3.1 引入：所有接口目前**任何人都能调**

Day01 到 Day11 第 2 讲，我们做了 40 多个接口，随便一个 URL 拿出来——未登录用户都能调，一个匿名请求就能删掉所有会员数据。今天开始给整个后端**装门神**。候选有三个：

- Servlet Filter；
- Spring MVC `HandlerInterceptor`；
- AOP `@Around`。

三选一看**能不能拿到方法上的注解**——只有 Interceptor 可以（Filter 拿不到 `HandlerMethod`，AOP 可以但生态偏重）。

🎯 **一句话目标**：**用 `HandlerInterceptor` 拦下所有请求，`@AuthIgnore` 注解标记免登接口**——为下一讲的 JWT 拦截器备好素材。

### 3.2 请求生命周期

```mermaid
flowchart LR
  A[Client] --> B[Servlet Filter]
  B --> C[DispatcherServlet]
  C --> D["HandlerInterceptor.preHandle"]
  D --> E["@Controller 方法"]
  E --> F["HandlerInterceptor.postHandle"]
  F --> G["视图/Response"]
  G --> H["HandlerInterceptor.afterCompletion"]
  H --> B
```

**Filter vs Interceptor 三大差异**：

| 维度 | Servlet Filter | HandlerInterceptor |
|------|---------------|-------------------|
| 能否拿到 `HandlerMethod` | ❌ 拿不到方法信息 | ✅ 可读方法 / 类头注解 |
| 依赖注入 | 麻烦（`FilterConfig`） | ✅ Spring 原生 |
| 执行链 | 早于 DispatcherServlet | 与 Controller 参数解析、异常处理无缝 |

**结论**：需要「读方法注解」的场景（`@AuthIgnore`、`@RateLimit`、`@Audit`）一律选 Interceptor。

### 3.3 三方法触发时机

| 方法 | 触发时机 | 返回 / 用途 |
|------|---------|-------------|
| `preHandle(req, res, handler)` | Controller 方法**执行前** | `return true` 放行；`return false` 拦下（响应体空，是坑）；也可以直接抛异常（推荐） |
| `postHandle(req, res, handler, mav)` | Controller 执行后、视图渲染前 | 前后端分离项目里几乎用不到 |
| `afterCompletion(req, res, handler, ex)` | 整个请求结束后 | 资源清理、访问日志、耗时统计 |

**常用只有 `preHandle`**，另两个偶尔用于监控。

### 3.4 一个极简的 `LogInterceptor`

```java
@Component
@Slf4j
public class LogInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
        // 静态资源 handler 不是 HandlerMethod，不判类型会 ClassCastException
        if (!(handler instanceof HandlerMethod)) return true;

        req.setAttribute("_start", System.currentTimeMillis());
        log.info("[LOG] preHandle {} {}", req.getMethod(), req.getRequestURI());
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest req, HttpServletResponse res,
                                 Object handler, Exception ex) {
        Object start = req.getAttribute("_start");
        if (start == null) return;
        long cost = System.currentTimeMillis() - (Long) start;
        log.info("[LOG] cost={}ms status={} uri={}", cost, res.getStatus(), req.getRequestURI());
    }
}
```

⚠️ **必须判 `handler instanceof HandlerMethod`**——静态资源（`/files/xxx.png`）的 handler 是 `ResourceHttpRequestHandler`，不判类型直接强转会 `ClassCastException`。

### 3.5 注册拦截器

```java
@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final LogInterceptor logInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry reg) {
        reg.addInterceptor(logInterceptor)
           .addPathPatterns("/**")
           .excludePathPatterns(
               "/error",             // ⚠️ 必须放行，否则拦截器抛异常后 forward 到 /error 又被拦一次，死循环
               "/files/**"
           );
    }
}
```

**注册顺序 = 执行顺序**。多个拦截器时：`preHandle` 顺序执行（先注册先跑），`afterCompletion` 逆序执行（后注册先跑）——形似「栈」。

### 3.6 `@AuthIgnore` 注解替代路径列表

```java
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface AuthIgnore {}
```

拦截器里判定：

```java
if (handler instanceof HandlerMethod hm) {
    if (hm.hasMethodAnnotation(AuthIgnore.class)
     || hm.getBeanType().isAnnotationPresent(AuthIgnore.class)) {
        return true;
    }
}
```

给需要免登的接口贴 `@AuthIgnore` 即可（`/login`、`/logout`、`/captcha`、`/refresh`）。**好处**：路径变了不用改配置，接口作者一贴注解即可放行；**坏处**：静态资源、错误页仍要走 `excludePathPatterns`。

### 3.7 `return false` vs 抛异常

**版本 A：`return false`**（不推荐）：

```java
if (!authed) {
    return false;  // 状态码 200、响应体空、前端不知道发生了什么
}
```

**版本 B：抛异常**（推荐）：

```java
if (!authed) throw new AuthException("未登录");
```

配合 `GlobalExceptionHandler`：

```java
@ExceptionHandler(AuthException.class)
public ResponseEntity<Result<Void>> auth(AuthException e) {
    return ResponseEntity.status(401).body(Result.fail(401, e.getMessage()));
}
```

Postman 收到：

```json
{"code": 401, "msg": "未登录"}
```

**本项目统一用抛异常**——状态码 + 错误消息一起交给全局异常处理，前端拦截器统一处理。

`AuthException` 定义：

```java
public class AuthException extends RuntimeException {
    public AuthException(String msg) { super(msg); }
}
```

### 3.8 联调剧本

1. 启动服务，随便点一个接口 → 控制台看到 `[LOG] preHandle GET /members`、Controller 内部日志、`[LOG] cost=Xms status=200 uri=/members`；
2. 访问 `/files/xxx.png` 静态资源 → 若代码里漏了 `instanceof HandlerMethod`，观察 `ClassCastException`；补齐后再访问，日志正常滚动；
3. 给 `LoginController.login` 贴 `@AuthIgnore`，其他接口不贴——手工模拟一个「未登录」判断，未贴的接口全 401，贴了的接口 200；
4. 版本 A：`return false` → Postman 200 空响应；版本 B：抛异常 → 401 + `{"code":401,"msg":"未登录"}`。

### 3.9 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| 访问静态资源 `ClassCastException` | `handler` 不是 `HandlerMethod`——必须 `instanceof` 判 |
| 拦截器抛异常后死循环 | 白名单没排除 `/error`——Spring 内部 forward 到 `/error` 又被拦一次 |
| 401 时前端拿不到消息 | `preHandle` 用 `return false`——响应体空；改为抛异常走全局异常处理 |
| 只想放行几个接口却堆一堆路径 | 用 `@AuthIgnore` 注解替代 `excludePathPatterns` 长列表 |
| 多个拦截器顺序不明 | 注册顺序 = 执行顺序；`afterCompletion` 逆序 |
| `postHandle` 修改视图无效 | 前后端分离项目里 Controller 返回 JSON，`postHandle` 时 `ModelAndView` 为 null |

### 3.10 练习 / 思考

1. **必做**：完成 `LogInterceptor`，`preHandle` 记入口 + 时间戳，`afterCompletion` 打耗时和状态码，注册到 `/**`，交控制台日志截图；
2. **必做**：新建 `@AuthIgnore` 注解，给 `/captcha`、`/login`、`/refresh` 三个方法贴上；
3. **思考**：`preHandle` 返回 `false` 时，`postHandle` 与 `afterCompletion` 会不会执行？（答：`postHandle` 不执行；`afterCompletion` 也不执行——只有 `preHandle` `return true` 之后才会走完整链路）；
4. **挑战**：写一个 `RateLimitInterceptor`——每个 IP 每秒最多 10 次请求（Redis `INCR + EXPIRE 1s`），超过抛 429 Too Many Requests。

---

## 第 4 讲：后台登录 / 退出 + BCrypt 加盐

### 4.1 引入：明文存密码 = 一夜之间数据裸奔

Day02 建 `tb_admin_user` 时，密码字段是 `VARCHAR(64)`——你们的初始密码是怎么存的？大部分回答是明文 `123456`。2011 年 CSDN 事件，600 万明文密码打包泄露到 GitHub，十几家大厂被撞库。今天把密码存储从「明文」升级到「BCrypt 加盐」，为下一讲的 JWT 登录接口备好用户表。

🎯 **一句话目标**：**BCrypt 加盐存密码 + 模糊化错误反馈 + 禁用位软控制**——把「明文密码」这颗雷从系统里彻底拆掉。

### 4.2 密码存储演进史

| 方案 | 抗撞库能力 | 代表事件 / 备注 |
|------|-----------|----------------|
| 明文 | ❌ 零防护 | CSDN 2011 教科书级反例 |
| MD5 | ❌ 彩虹表秒解 | `123456` 的 MD5 是 `e10adc3949ba59abbe56e057f20f883e` 常量 |
| MD5 + 固定盐 | ❌ 盐固定 = 彩虹表照旧成立 | 攻击者拿到 DB 就能反查 |
| MD5 + 每人随机盐 | ⚠️ 撞库变慢，但 MD5 本身便宜 | GPU 每秒 100 亿次 |
| **BCrypt** | ✅ cost=10 → 60ms 一次 → 撞库慢 **10 亿倍** | 加密工程唯一正确姿势 |

**BCrypt 关键三件事**：

1. **自适应工作因子**——`cost` 是对数，`cost=10` 表示迭代 `2^10 = 1024` 次；服务器越快，`cost` 越高，让攻击者永远追不上；
2. **盐存在密文里**——加密结果 `$2a$10$xxxxxxxxx...`：`$2a$` 版本、`10` cost、后 22 字符盐 + 31 字符 hash 拼接；
3. **每次加密结果都不同，但 `checkpw` 通过**——`checkpw(raw, hash)` 内部从密文提取盐，再哈希对比。

### 4.3 `tb_admin_user` 表设计

```sql
CREATE TABLE tb_admin_user (
  id              BIGINT PRIMARY KEY AUTO_INCREMENT,
  username        VARCHAR(50)  NOT NULL,
  password        VARCHAR(100) NOT NULL COMMENT 'BCrypt 密文（60 字节，留 100 兼容未来算法）',
  real_name       VARCHAR(50),
  status          TINYINT DEFAULT 1 COMMENT '1 启用 0 禁用',
  roles           VARCHAR(500) COMMENT '角色列表 JSON 数组 ["ADMIN","OP"]',
  last_login_time DATETIME,
  last_login_ip   VARCHAR(50),
  deleted         TINYINT DEFAULT 0,
  create_time     DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time     DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_username (username, deleted)
);
```

- `password VARCHAR(100)`：BCrypt 密文固定 60 字节，留 100 兼容未来算法（Argon2 等）；
- `roles` 存 JSON 数组 —— 小项目够用，大项目才拆 `tb_user_role` 关联表；
- `status = 0` 禁用位 —— 离职员工用软禁用，不删数据；
- `uk_username(username, deleted)` —— 允许软删同名用户回归。

### 4.4 依赖与 `BCrypt` API

```xml
<dependency>
  <groupId>org.springframework.security</groupId>
  <artifactId>spring-security-crypto</artifactId>
</dependency>
```

⚠️ **只引 `spring-security-crypto`，不要引整个 Spring Security**——BCrypt 是独立工具，本课程不需要引入完整安全框架（会与我们自写的 JWT 拦截器冲突）。

```java
import org.springframework.security.crypto.bcrypt.BCrypt;

// 加密（每次结果不同）
String hash = BCrypt.hashpw("123456", BCrypt.gensalt(10));
// →  $2a$10$UnVeK4WqQg3zXfLpqE1BWuHVhBpTNqB.g0nLh9WvOfrWzL9Ug8P4a

// 校验
boolean ok = BCrypt.checkpw("123456", hash);   // true
boolean ng = BCrypt.checkpw("wrong",  hash);   // false
```

### 4.5 生成初始 admin 密文

新建一个 `main` 方法（不要在 SQL 客户端里手打 `$2a`，`$` 会被当占位符替换掉）：

```java
public class BcryptGen {
    public static void main(String[] args) {
        String raw  = "123456";
        String hash = BCrypt.hashpw(raw, BCrypt.gensalt(10));
        System.out.println(hash);
        System.out.println(BCrypt.checkpw(raw, hash));  // true
    }
}
```

拿到密文字符串再执行 INSERT：

```sql
INSERT INTO tb_admin_user (username, password, real_name, status, roles)
VALUES ('admin', '$2a$10$UnVe...实际输出...', '超级管理员', 1, '["ADMIN"]');
```

同一密码执行 3 次 `hashpw` 结果都不同，但都能 `checkpw` 通过——这是**盐随机**的直观证据。

### 4.6 `AdminUserService.checkLogin`

```java
@Service
@RequiredArgsConstructor
public class AdminUserService {

    private final AdminUserMapper mapper;

    public AdminUser checkLogin(String username, String rawPwd) {
        AdminUser u = mapper.getByUsername(username);
        // ① 账号不存在 / 已禁用 —— 消息统一模糊化，防撞库
        if (u == null || u.getStatus() == 0) {
            throw new BizException("账号不存在或已禁用");
        }
        // ② 密码错 —— 消息同样模糊
        if (!BCrypt.checkpw(rawPwd, u.getPassword())) {
            throw new BizException("用户名或密码错误");
        }
        return u;
    }
}
```

**模糊化反馈**：不告诉攻击者「账号不存在」还是「密码错」，降低撞库反馈信号。

### 4.7 `LoginController` 骨架（先不签 JWT）

```java
@Data
public class LoginDTO {
    @NotBlank private String username;
    @NotBlank private String password;
    // 下一讲 5 再加：captchaKey / captchaCode
}

@Data
@AllArgsConstructor
public class LoginVO {
    private String       username;
    private String       realName;
    private List<String> roles;
    // 下一讲加：accessToken / refreshToken
}
```

```java
@RestController
@RequiredArgsConstructor
public class AuthController {

    private final AdminUserService userService;

    @AuthIgnore
    @PostMapping("/login")
    public Result<LoginVO> login(@RequestBody @Valid LoginDTO dto) {
        AdminUser u = userService.checkLogin(dto.getUsername(), dto.getPassword());
        return Result.success(new LoginVO(u.getUsername(), u.getRealName(),
                                          parseRoles(u.getRoles())));
    }

    @AuthIgnore
    @PostMapping("/logout")
    public Result<Void> logout() {
        // 现在没有 JWT，logout 逻辑很简单——返回成功；
        // 下一讲加「黑名单强制下线」
        return Result.success();
    }

    private List<String> parseRoles(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            return new ObjectMapper().readValue(json, new TypeReference<>() {});
        } catch (Exception e) {
            return List.of();
        }
    }
}
```

### 4.8 联调剧本

1. Postman `POST /login` body `{"username":"admin","password":"123456"}` → 200，返回 `{username, realName, roles}`；
2. 错密码 → 400「用户名或密码错误」；
3. 不存在的用户 `xxx` → 400「账号不存在或已禁用」（**与密码错误消息不同吗？** ——不同类别，同样含糊，但字面已足够混淆撞库脚本）；
4. `UPDATE tb_admin_user SET status = 0 WHERE username = 'admin'` → 再登录 → 400「账号不存在或已禁用」。

### 4.9 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| 存进 DB 的密文缺一个 `$` | 在 SQL 客户端里手打 `$2a` 被当占位符替换掉——**用 Java main 生成再复制** |
| 每次 `hashpw` 结果不同「担心校验错」 | 盐随机存在密文里，`checkpw` 内部提取盐再哈希——**这是正确行为** |
| `BCrypt.hashpw` 慢 60ms 「怕影响性能」 | 一天几万次登录以内不用担心；这就是「安全的代价」——cost 是安全与性能的旋钮 |
| 密码错 / 账号不存在给不同消息 | 帮攻击者撞库——**务必模糊化** |
| 明文存密码 | 一句「就是要炒鱿鱼的错误」——**永不明文** |
| 引了整个 Spring Security 导致所有接口 401 | 只引 `spring-security-crypto`；完整 Security 有自己的拦截链，与我们的 JwtInterceptor 冲突 |
| 用 `MessageDigest.getInstance("MD5")` 自己写「MD5+盐」 | **加密工程第一定律：不要造轮子**；用现成库 |

### 4.10 练习 / 思考

1. **必做**：跑通 `admin / 123456` 登录闭环——建表 + IDEA main 生成密文 + INSERT + Postman 三种场景（正确 / 密码错 / 禁用），交 3 张截图；
2. **必做**：把 BCrypt cost 从 10 改成 12，重新生成密文，用 `StopWatch` 打时间戳观察 `hashpw / checkpw` 耗时变化——感受「cost 每 +1 时间 x2」的规律；
3. **思考**：MD5 + 固定盐 加密方案的漏洞是什么？为什么随机盐比固定盐好？（提示：固定盐 = 攻击者提前算好一张彩虹表照样用）；
4. **挑战**：追加「登录失败次数」——同一账号 5 分钟内错 5 次锁 15 分钟（Redis `INCR + EXPIRE`），锁定期间即使密码对也返回「账号已锁定，X 秒后重试」；下一讲会详细讲。

---

## 第 5 讲：JWT 签发与校验（JJWT 0.12.6）

### 5.1 引入：登录成功后，**下一次请求怎么知道你是 admin 而不是 tom**？

上一讲 `LoginVO` 里 `username / realName / roles` 三个字段——前端拿到这些字段是能显示了，可下一次调 `GET /members` 时后端怎么知道调用者是谁？两条路：

- **Session**：服务端存登录状态。分布式部署需要 Redis 共享 Session 或 sticky session；
- **JWT**：无状态，签名后放 header，服务端只验签不查库——**分布式项目 100% 选 JWT**。

🎯 **一句话目标**：**JJWT 0.12.6 五段签发 + 三段解析 + Bearer 请求头 + `setAttribute` 上下文 + 黑名单强制下线**——让整个后端拿到「谁调的接口」这个上下文。

### 5.2 JWT 三段结构

```text
eyJhbG...j9UP...
└─ Header ─┘└─ Payload ─┘└─ Signature ─┘
```

| 段 | 内容 | 编码 |
|----|------|------|
| Header    | `{"alg":"HS256","typ":"JWT"}` | Base64URL |
| Payload   | `{"sub":"admin","uid":1,"roles":["ADMIN"],"iat":...,"exp":...}` | Base64URL |
| Signature | `HMACSHA256( base64(header) + "." + base64(payload), secret )` | 二进制 |

⚠️ **JWT 是签名不是加密**——Header 与 Payload 是**明文可读**（任何人复制到 [jwt.io](https://jwt.io) 都能解出来）：

- ❌ **不能放**：密码、身份证、卡号、手机号；
- ✅ **能放**：`uid`、`roles`、`exp`——「无所谓被看到但改了不算数」的字段。

Signature 是**签名保护**：payload 被改一个字节，验签就失败。

### 5.3 Session vs JWT 决策矩阵

| 维度 | Session | JWT |
|------|---------|-----|
| 服务端存储 | 需要 | 不需要 |
| 分布式 | 需 Redis 共享 | 天生适合 |
| 强制下线 | 直接删 Session | 需黑名单 / 换密钥 |
| Payload 大小 | 小（cookie ID） | 稍大（几百字节） |
| CSRF | 有风险 | 相对低（自定义 header） |
| XSS 泄露 | HttpOnly cookie 可防 | localStorage 存有风险 |

**本课程选 JWT**，但保留 Redis 存 refresh token + 黑名单——兼顾强制下线能力，让「无状态」JWT 在工程上也能「有状态可控」。

### 5.4 依赖

```xml
<dependency>
  <groupId>io.jsonwebtoken</groupId><artifactId>jjwt-api</artifactId>
  <version>0.12.6</version>
</dependency>
<dependency>
  <groupId>io.jsonwebtoken</groupId><artifactId>jjwt-impl</artifactId>
  <version>0.12.6</version><scope>runtime</scope>
</dependency>
<dependency>
  <groupId>io.jsonwebtoken</groupId><artifactId>jjwt-jackson</artifactId>
  <version>0.12.6</version><scope>runtime</scope>
</dependency>
```

**为什么后两个是 `runtime` scope**：工程代码只 `import io.jsonwebtoken.Jwts / Keys / Claims`（都在 `jjwt-api`），运行期通过 `ServiceLoader` 自动加载 `jjwt-impl` 与 `jjwt-jackson`——这样应用启动时才需要它们，编译期不用暴露实现细节。

**JJWT 0.12 vs 0.11**：API 差异很大。旧版 `setSubject / parseClaimsJws` 已废弃，新版用 `subject / parseSignedClaims`——**用 AI 生成时必须指定版本，否则一半概率翻车**。

### 5.5 配置

```yaml
yoga:
  jwt:
    secret: ${JWT_SECRET:pleaseUseAtLeast32ByteSecretInProd_xxxxxxxxxxxx}
    ttl: 2h            # access token
    refresh-ttl: 7d
    header: Authorization
    prefix: "Bearer "
```

⚠️ **HS256 的 secret 至少 32 字节**（256 位），不足会抛：

```
io.jsonwebtoken.security.WeakKeyException:
The specified key byte array is X bits which is not secure enough for any JWT HMAC-SHA algorithm.
```

生产必须用环境变量或 KMS 注入，不要硬编码。

### 5.6 `JwtUtils` 工具类

```java
@Component
public class JwtUtils {

    @Value("${yoga.jwt.secret}") private String   secret;
    @Value("${yoga.jwt.ttl}")    private Duration ttl;

    private SecretKey key;

    @PostConstruct
    public void init() {
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    /** 签发：五段式 */
    public String issue(String subject, Map<String, Object> claims) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(subject)
                .claims(claims)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plus(ttl)))
                .signWith(key, Jwts.SIG.HS256)
                .compact();
    }

    /** 验签 + 解析：三段式 */
    public Claims parse(String token) {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}
```

**签发五段**：`subject → claims → issuedAt → expiration → signWith`；
**验签三段**：`parser → verifyWith → parseSignedClaims`。

### 5.7 `AuthController.login` 追加签发

```java
@RestController
@RequiredArgsConstructor
public class AuthController {

    private final AdminUserService    userService;
    private final JwtUtils            jwt;
    private final StringRedisTemplate redis;

    @AuthIgnore
    @PostMapping("/login")
    public Result<LoginVO> login(@RequestBody @Valid LoginDTO dto) {
        AdminUser u = userService.checkLogin(dto.getUsername(), dto.getPassword());

        // 签发 access + refresh
        Map<String, Object> claims = Map.of(
            "uid",   u.getId(),
            "roles", parseRoles(u.getRoles())
        );
        String access  = jwt.issue(u.getUsername(), claims);
        String refresh = UUID.randomUUID().toString().replace("-", "");
        redis.opsForValue().set("rt:" + refresh, u.getUsername(),
                                Duration.ofDays(7));

        return Result.success(new LoginVO(access, refresh,
                u.getUsername(), u.getRealName(), parseRoles(u.getRoles())));
    }
}
```

`LoginVO` 补齐：

```java
@Data
@AllArgsConstructor
public class LoginVO {
    private String       accessToken;
    private String       refreshToken;
    private String       username;
    private String       realName;
    private List<String> roles;
}
```

### 5.8 `JwtInterceptor`

```java
@Component
@RequiredArgsConstructor
public class JwtInterceptor implements HandlerInterceptor {

    private final JwtUtils            jwt;
    private final StringRedisTemplate redis;

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
        // ① 只拦 Controller 方法
        if (!(handler instanceof HandlerMethod hm)) return true;

        // ② 白名单：方法或类头带 @AuthIgnore 直接放行
        if (hm.hasMethodAnnotation(AuthIgnore.class)
         || hm.getBeanType().isAnnotationPresent(AuthIgnore.class)) {
            return true;
        }

        // ③ 读 Authorization
        String header = req.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            throw new AuthException("未登录");
        }
        String token = header.substring(7);

        // ④ 黑名单查询（强制下线）
        String jti = DigestUtils.md5DigestAsHex(token.getBytes(StandardCharsets.UTF_8));
        if (Boolean.TRUE.equals(redis.hasKey("bl:" + jti))) {
            throw new AuthException("Token 已失效");
        }

        // ⑤ 验签 + 上下文注入
        try {
            Claims c = jwt.parse(token);
            req.setAttribute("currentUser",  c.getSubject());
            req.setAttribute("currentUid",   c.get("uid", Long.class));
            req.setAttribute("currentRoles", c.get("roles"));
            return true;
        } catch (ExpiredJwtException e) {
            throw new AuthException("登录已过期，请重新登录");
        } catch (JwtException e) {
            throw new AuthException("Token 非法");
        }
    }
}
```

**五步链路一句话**：`Bearer 拆头 → 黑名单查 → 验签 → 塞 setAttribute → 放行`。

**异常分层**：`ExpiredJwtException`（过期，提示重新登录）与 `JwtException`（签名错、格式错，一律 401 Token 非法）分开——用户体验更好。

注册（追加到 Day10 建过的 `WebMvcConfig`）：

```java
@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final LogInterceptor logInterceptor;
    private final JwtInterceptor jwtInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry reg) {
        reg.addInterceptor(logInterceptor)
           .addPathPatterns("/**")
           .excludePathPatterns("/error", "/files/**");

        reg.addInterceptor(jwtInterceptor)
           .addPathPatterns("/**")
           .excludePathPatterns(
               "/login", "/logout", "/refresh", "/captcha",
               "/files/**", "/error"
           );
    }
}
```

⚠️ **`/error` 必须放行**——拦截器抛异常后 Spring 内部 forward 到 `/error`，若被拦一次就会死循环。

### 5.9 全局异常处理追加

```java
@ExceptionHandler(AuthException.class)
public ResponseEntity<Result<Void>> auth(AuthException e) {
    return ResponseEntity.status(401).body(Result.fail(401, e.getMessage()));
}
```

### 5.10 Controller 中拿当前用户

```java
@GetMapping("/me")
public Result<Map<String, Object>> me(
        @RequestAttribute("currentUser") String username,
        @RequestAttribute("currentUid")  Long uid,
        @RequestAttribute("currentRoles") List<String> roles) {
    return Result.success(Map.of(
        "username", username,
        "uid",      uid,
        "roles",    roles));
}
```

`@RequestAttribute` 无需再从 header 手工解析——**上下文注入的价值**。

### 5.11 滑动式 refresh

Access token 短命（2h），refresh token 长命（7d）。前端在 access 过期时用 refresh 换新：

```java
@AuthIgnore
@PostMapping("/refresh")
public Result<LoginVO> refresh(@RequestParam String refreshToken) {
    String key = "rt:" + refreshToken;
    String username = redis.opsForValue().get(key);
    if (username == null) throw new AuthException("Refresh Token 已过期");

    AdminUser u = userService.getByUsername(username);
    Map<String, Object> claims = Map.of(
        "uid",   u.getId(),
        "roles", parseRoles(u.getRoles()));
    String access = jwt.issue(u.getUsername(), claims);

    // 滑动式：换新 refresh，旧的立即作废
    String newRt = UUID.randomUUID().toString().replace("-", "");
    redis.opsForValue().set("rt:" + newRt, username, Duration.ofDays(7));
    redis.delete(key);

    return Result.success(new LoginVO(access, newRt,
            u.getUsername(), u.getRealName(), parseRoles(u.getRoles())));
}
```

**滑动式（每次刷新都换新 refresh）安全性 > 固定 refresh**——旧 refresh 泄露也无法二次使用。

### 5.12 强制下线：Redis 黑名单

```java
@AuthIgnore
@PostMapping("/logout")
public Result<Void> logout(HttpServletRequest req) {
    String token = req.getHeader("Authorization");
    if (token != null && token.startsWith("Bearer ")) {
        String jti = DigestUtils.md5DigestAsHex(
            token.substring(7).getBytes(StandardCharsets.UTF_8));
        redis.opsForValue().set("bl:" + jti, "1", Duration.ofHours(2)); // 与 access ttl 同长
    }
    return Result.success();
}
```

**取舍**：让「无状态」JWT 恢复「有状态可强制下线」的代价是引入 Redis 状态——工程上完全可接受。

### 5.13 联调剧本（完整五幕）

1. `POST /login` → 200，返回 `access + refresh + username + roles`；
2. `GET /bookings` 不带 header → 401「未登录」；
3. `GET /bookings` 带 `Authorization: Bearer <access>` → 200 分页；
4. 把 `yoga.jwt.ttl` 临时改成 30 秒，等 access 过期 → 401「登录已过期，请重新登录」；
5. `POST /refresh?refreshToken=<refresh>` → 200，返回新 access + 新 refresh；再用旧 refresh → 401「Refresh Token 已过期」（滑动式作废）；
6. `POST /logout`（带旧 access）→ 200；再用同一 access → 401「Token 已失效」（黑名单命中）；
7. 手工把 `access` token 尾部改掉一个字符 → 401「Token 非法」（签名验证失败）。

### 5.14 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| `WeakKeyException` | secret < 32 字节；用足够长字符串或 `Keys.secretKeyFor(SIG.HS256)` 让库生成 |
| AI 生成用 `setSubject / parseClaimsJws` | 那是 JJWT 0.11 老 API，0.12 已废弃——**prompt 里必须写 0.12.6** |
| `HandlerMethod` 未判类型 → `ClassCastException` | 静态资源不是 `HandlerMethod`；先 `instanceof` |
| 白名单漏 `/error` | 拦截器抛异常 forward 到 `/error` 再被拦一次，死循环 |
| `request.getAttribute("currentUser")` 在 `@Async` 为 null | `HttpServletRequest` 是**请求作用域**——异步线程访问不到，用 `ThreadLocal / TaskDecorator` 显式传 |
| CORS 401「header 丢了」 | `Access-Control-Allow-Headers` 必须包含 `Authorization`；`allowCredentials(true)` 时 `allowedOrigins` 不能是 `*` |
| Payload 塞密码 / 身份证 | JWT 是 Base64 明文——**只放 `uid / roles / exp`**，敏感字段留 DB |
| `preHandle` 用 `return false` | 无法把 401 状态码 + 消息带出去——**统一抛 `AuthException`** |
| 前端把 JWT 存 `localStorage` 有 XSS 风险 | 生产可改 `httpOnly cookie + SameSite`；教学演示暂用 localStorage |
| 强制下线依赖黑名单反而「有状态」 | 这是设计上的自觉取舍，让 JWT 恢复可控——工程可接受 |

### 5.15 练习 / 思考

1. **必做**：完成 `JwtUtils / JwtInterceptor / AuthController.login / logout / refresh` 五件套，跑通「登录 → 请求 → 过期 → 刷新 → 下线」五幕联调，交 5 张 Postman 截图（登录成功 / 无 header 401 / 有 header 200 / 手动截断 token 401 / 过期后 401）；
2. **必做**：把 `yoga.jwt.ttl` 临时改成 30 秒，观察 access 过期后前端如何用 refresh 换新——加深「短命 access + 长命 refresh」的印象；
3. **必做**：把自己签出的一个 access token 复制到 [jwt.io](https://jwt.io)，把解码出的 Payload 截图贴到作业——**直观感受「JWT payload 是明文」**；
4. **思考**：JWT 的 secret 泄露了会怎样？（答：任何人都能签出合法 token = 系统裸奔——必须立即换密钥并把旧 token 全部作废）；
5. **挑战**：把 secret 改成「多密钥滚动」——`issue` 用 v2，`parse` 允许 v1/v2 都通过，用于生产环境无缝换密钥。

---

## 第 6 讲：Kaptcha 图形验证码 + 登录防护

### 6.1 引入：**shell 循环一秒能刷几百次登录**

上一讲登录接口跑通了，我现在写一段：

```bash
while true; do
  curl -X POST http://localhost:8080/login \
       -H 'Content-Type: application/json' \
       -d '{"username":"admin","password":"123456"}'
done
```

一秒能刷几百次——这就是**撞库**。`admin/123456` 也许扛得住，但普通用户的密码呢？今天给登录加一道**人类才能过的关卡**——图形验证码 + 登录失败次数锁定。

🎯 **一句话目标**：**Kaptcha 生成 base64 图片 → Redis 3 分钟 TTL → 一次性 nonce + 登录失败 5 次锁 15 分钟**——把登录接口最后一道门补上，Part 2 后端**正式收官**。

### 6.2 依赖

```xml
<dependency>
  <groupId>com.github.penggle</groupId>
  <artifactId>kaptcha</artifactId>
  <version>2.3.2</version>
</dependency>
```

### 6.3 `KaptchaConfig`

```java
@Configuration
public class KaptchaConfig {

    @Bean
    public DefaultKaptcha kaptcha() {
        Properties p = new Properties();
        p.put("kaptcha.textproducer.char.length", "4");
        p.put("kaptcha.textproducer.font.size",   "36");
        // ⚠️ 去掉容易混淆的 i l 1 0 o
        p.put("kaptcha.textproducer.char.string",
              "abcdefghjkmnpqrstuvwxyz23456789");
        // 教学演示用「无干扰」，生产可改回默认干扰线
        p.put("kaptcha.noise.impl",
              "com.google.code.kaptcha.impl.NoNoise");
        DefaultKaptcha k = new DefaultKaptcha();
        k.setConfig(new Config(p));
        return k;
    }
}
```

**字符集去掉 `i l 1 0 o`** 是给普通用户的善意——用眼睛读 `l1I` 三个字符就明白为什么。

### 6.4 `/captcha` 接口

```java
@RestController
@RequiredArgsConstructor
public class CaptchaController {

    private final DefaultKaptcha      kaptcha;
    private final StringRedisTemplate redis;

    @AuthIgnore
    @GetMapping("/captcha")
    public Result<CaptchaVO> get() throws IOException {
        // UUID 作 key（去掉 -），一次性 nonce
        String key  = UUID.randomUUID().toString().replace("-", "");
        String text = kaptcha.createText();
        BufferedImage image = kaptcha.createImage(text);

        try (ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            ImageIO.write(image, "jpg", bos);
            String b64 = "data:image/jpeg;base64,"
                       + Base64.getEncoder().encodeToString(bos.toByteArray());

            // Redis 存小写文本（忽略大小写校验），3 分钟 TTL
            redis.opsForValue().set("cap:" + key,
                                    text.toLowerCase(),
                                    Duration.ofMinutes(3));
            return Result.success(new CaptchaVO(key, b64));
        }
    }
}

@Data
@AllArgsConstructor
public class CaptchaVO {
    private String key;
    private String image;  // data:image/jpeg;base64,....
}
```

**为什么 base64 而不用流响应**：

1. 前端 `<img src="{{ img }}">` 直接展示，不用二次请求；
2. 不必设置 cookie（流响应绑用户 session）；
3. 前端把 `key + code` 一起传回来即可，逻辑最简单。

### 6.5 `LoginDTO` 加 captcha 字段

```java
@Data
public class LoginDTO {
    @NotBlank private String username;
    @NotBlank private String password;
    @NotBlank private String captchaKey;
    @NotBlank private String captchaCode;
}
```

### 6.6 `AuthController.login` 加验证码校验

```java
@AuthIgnore
@PostMapping("/login")
public Result<LoginVO> login(@RequestBody @Valid LoginDTO dto,
                              HttpServletRequest req) {
    // ① 校验验证码
    String capKey = "cap:" + dto.getCaptchaKey();
    String expect = redis.opsForValue().get(capKey);
    redis.delete(capKey);   // ⚠️ 不管对错都删（一次性 nonce，防复用）
    if (expect == null || !expect.equalsIgnoreCase(dto.getCaptchaCode())) {
        throw new BizException("验证码错误或已过期");
    }

    // ② 登录失败次数防护（前置检查）
    String failKey = "login:fail:" + dto.getUsername();
    String failStr = redis.opsForValue().get(failKey);
    int failCount = failStr == null ? 0 : Integer.parseInt(failStr);
    if (failCount >= 5) {
        throw new BizException("账号已锁定，请 15 分钟后再试");
    }

    // ③ 密码校验（失败则计数 +1）
    AdminUser u;
    try {
        u = userService.checkLogin(dto.getUsername(), dto.getPassword());
    } catch (BizException e) {
        redis.opsForValue().increment(failKey);
        if (failCount == 0) {
            redis.expire(failKey, Duration.ofMinutes(15));
        }
        throw e;
    }
    // 登录成功清空计数
    redis.delete(failKey);

    // ④ 签发 access + refresh
    Map<String, Object> claims = Map.of(
        "uid",   u.getId(),
        "roles", parseRoles(u.getRoles()));
    String access  = jwt.issue(u.getUsername(), claims);
    String refresh = UUID.randomUUID().toString().replace("-", "");
    redis.opsForValue().set("rt:" + refresh, u.getUsername(),
                            Duration.ofDays(7));

    return Result.success(new LoginVO(access, refresh,
            u.getUsername(), u.getRealName(), parseRoles(u.getRoles())));
}
```

**四个防护要点**：

1. **验证码不管对错都 `redis.delete`** —— 一次性 nonce，防复用与脚本试错；
2. **`equalsIgnoreCase`** —— 大小写不敏感，用户体验更好；
3. **失败次数锁账号而不是锁 IP** —— IP 可能是 NAT 或代理，账号才是攻击目标；
4. **只在 `failCount == 0` 时设 EXPIRE** —— 后续 `INCR` 不再刷新 TTL，避免用户被永久锁死。

### 6.7 联调剧本

1. `GET /captcha` → 200，返回 `{"key":"xxxx","image":"data:image/jpeg;base64,/9j/4AAQ..."}`；把 base64 字符串复制到浏览器地址栏，直接看到验证码图片；
2. `POST /login` 传错验证码 → 400「验证码错误或已过期」；
3. 立即再传对的验证码 → 400「验证码错误或已过期」（**已被删掉，防复用**）；
4. 重新 `GET /captcha` 拿新 key + 图，输对 code → 200，返回 `access + refresh`；
5. 连续 5 次输错密码（每次都要重新 `GET /captcha`）→ 第 6 次即使密码对也 400「账号已锁定，请 15 分钟后再试」；
6. 手工 `DEL login:fail:admin` 解锁 → 恢复正常。

### 6.8 pitfall 表

| 现象 | 原因 / 建议 |
|---|---|
| 已用一次的验证码还能通过 | 忘 `redis.delete(capKey)`——**一次性 nonce，用完必删** |
| 用户输小写 A 大写 A 报错 | 未 `equalsIgnoreCase`——用户体验差 |
| 攻击者按 IP 锁不住 | IP 是 NAT / 代理——**按账号锁**；如果账号被恶意锁死则要人工申诉 |
| 用户被永久锁 | 每次 `INCR` 都刷新 TTL——**只在 `failCount == 0` 时 EXPIRE** |
| 密码错和账号不存在不同消息 | 帮撞库——务必模糊化 |
| 验证码字符集含 `i l 1 0 o` | 眼睛看不清抱怨用户体验——**只用 `abcdefghjkmnpqrstuvwxyz23456789`** |
| 前端跨域后拿不到 Base64 | 跨域 header `Content-Type` 没配好；base64 是纯字符串，正确配 CORS 即可 |
| 短信验证码不做同样防护 | 短信 / 找回密码 / 发布评论——**所有可能被脚本刷的接口都要挂验证码 / 限流** |

### 6.9 Day09–Day11 知识地图

```mermaid
mindmap
  root((后端 Part 2))
    业务模块
      会员/教练/教室/科目
      课程 CRUD
      预约（多约束 + 并发扣减）
    公共能力
      文件上传 / OSS
      AOP 操作日志
      Redis 缓存 (Spring Cache)
      Redis 计数 (Template)
      Spring 事务
      JWT 登录 / 拦截器
      图形验证码
    工程实践
      DTO / VO 分层
      MyBatis 联表 / resultMap
      多约束校验
      并发扣减双保险
      分布式令牌
      模糊化错误反馈
```

### 6.10 能力自检

打 √ 你能独立做的：

- [ ] 独立完成一个「基本 CRUD + 多约束 + 并发扣减」业务模块（含多表联查）；
- [ ] 说清「幂等 UK + Redis 扣减 + 手工补偿」的并发方案；
- [ ] 会用 `@Aspect` 写一个自定义注解切面；
- [ ] 会用 `@Transactional` 保证多表写一致；
- [ ] 会用 Interceptor 拦截 + `@AuthIgnore` 白名单；
- [ ] 会签发 / 解析 JWT，能说清「过期 / 刷新 / 下线」流程；
- [ ] 会集成 Redis 8：Spring Cache + RedisTemplate 双路径；
- [ ] 会用 BCrypt 加盐 + 图形验证码 + 失败次数保护登录接口。

### 6.11 练习 / 思考

1. **必做**：完成 `/captcha + 改造 login + 登录失败次数` 三件套，交 5 张 Postman 截图（拿验证码 / 输错 / 输对 / 复用被拒 / 连续错 5 次被锁）；
2. **必做**：把 Day11 六讲代码合并成一个 PR，commit 信息按 conventional commits 分三次：`feat(booking): ...` / `feat(auth): ...` / `feat(captcha): ...`；
3. **思考**：验证码只保护登录够不够？（提示：短信发送、找回密码、评论等任何可被刷的接口都要挂）；为什么按账号锁而不按 IP？（提示：IP 可能是 NAT 或代理，账号是攻击目标）；
4. **挑战**：用 AI 助手生成「短信验证码登录」接口——`POST /sms/send`（手机号 + 图形验证码前置校验）+ `POST /login/sms`（手机号 + 短信码），复用今天所有防护逻辑；
5. **挑战**：把 `/captcha` 接口挂上限流——同一 IP 每分钟最多请求 20 次（Redis + `RateLimitInterceptor`）。

---

## 附录 A：Day11 交付物清单

**新增文件**：DTO/VO（`BookingCreateDTO / BookingPageQuery / LoginDTO / BookingVO / BookingBriefVO / LoginVO / CaptchaVO`）、entity（`Booking / AdminUser`）、mapper（`BookingMapper + xml`、`AdminUserMapper + xml`）、service（`BookingService / BookingScheduler / AdminUserService`）、controller（`BookingController / AuthController / CaptchaController`）、interceptor（`LogInterceptor / JwtInterceptor`）、config（`WebMvcConfig / KaptchaConfig`）、`util/JwtUtils`、`annotation/AuthIgnore`、`exception/AuthException` + 全局异常追加 `@ExceptionHandler(AuthException.class)`。

**数据库迁移**：`V11__create_tb_booking.sql`、`V11__create_tb_admin_user.sql`（含 admin BCrypt 初始 INSERT）。

**配置更新**：`application.yml` 增补 `yoga.jwt.secret / ttl / refresh-ttl / header / prefix`；主启动类加 `@EnableScheduling`。

**联调剧本汇总（15 步）**：`GET /captcha` → 错码 400 → 正确登录 → 无 header 401 → Bearer 200 → 预约成功 → 重复被拒 → 并发抢容量 → 距开课 <2h 取消被拒 → 开课前 30min 签到 → `scanAbsent` 缺席 → JWT ttl 到期 401 → refresh 换新 → logout 后旧 token 401 → 5 次密码错锁 15 分钟。

---

## 附录 C：AI 助手常犯错清单（六讲汇总）

1. Redis 首次 `INCR` 不同步 DB 已有数据；抛异常时忘 `DECR` 回滚；
2. `updateStatus` UPDATE 不带 `WHERE fromStatus` 条件；
3. 误以为事务内的 Redis 操作会随事务回滚；
4. 拦截器忘 `handler instanceof HandlerMethod` 判断；白名单漏 `/error`；
5. `preHandle` 用 `return false` 而非抛异常，无法带出 401 状态码；
6. 用 MD5 或明文存密码；BCrypt 密文 SQL 里丢 `$`（客户端把 `$` 当占位符）；
7. JWT secret 不足 32 字节 → `WeakKeyException`；
8. 用 JJWT 0.11 老 API（`setSubject / parseClaimsJws`）——**prompt 必须写 0.12.6**；
9. Payload 里塞密码 / 身份证等敏感字段；
10. 验证码只在成功时 `redis.delete`，失败时不删——可反复试错；
11. 验证码字符集含 `i l 1 0 o`；
12. 登录错误消息「账号不存在」与「密码错」区分开——帮撞库；
13. secret / AK 硬编码 `application.yml` 而非环境变量。

**推荐提示词模板要点**：明确写 Spring Boot 4.0.x + JJWT **0.12.6** + Kaptcha 2.3.2 + spring-security-crypto，指定 `Keys.hmacShaKeyFor + Jwts.builder().subject().claims()...signWith(key, SIG.HS256)` 新 API，明确「异常必手工 DECR」「验证码不管对错都删」「拦截器抛 AuthException 而非 return false」——AI 输出后逐条比对上面 13 条常犯错。

---

**Day11 收官**：预约六步 → 生命周期五动作 → 拦截器门神 → BCrypt 加盐 → JWT 五段签发 → 图形验证码防刷。后端 Part 2 完整闭环。Day12 起把这些接口搬到 Vue 3 前端——第一件事就是把今天的验证码 + 登录 + JWT 拦截在前端跑通。
