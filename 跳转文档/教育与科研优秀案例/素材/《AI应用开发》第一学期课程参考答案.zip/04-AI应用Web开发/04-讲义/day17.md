# 《AI 应用 Web 开发》 - 学生讲义（Day17：Docker 容器网络 + 全栈部署 + CI/CD + 课程回顾）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day16 的学生（掌握 Spring Boot 4.0.x 后端全链路、Vue 3 + TypeScript 全部业务页面、Linux 基础、Nginx 反代、Docker 单容器打包、Dockerfile 分层构建、镜像推送 ACR 全部前置能力）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / Vue 3.5+ / Vite 5.4+ / Ubuntu 22.04 LTS / Docker Engine 27.x / Docker Compose v2.29+ / Nginx 1.24（容器）/ MySQL 8.0（容器）/ Redis 8-alpine（容器）/ GitHub Actions（`actions/checkout@v4`、`setup-java@v4`、`docker/build-push-action@v6`、`docker/setup-buildx-action@v3`、`docker/login-action@v3`、`appleboy/ssh-action@v1`）/ 阿里云 ACR。

**Day17 主线**：Day16 我们把印想瑜伽的后端与前端**分别**塞进了 Docker 镜像，`docker run` 能起一个孤立容器——但真实生产是 **MySQL + Redis + Backend + Nginx** 四个容器**协同**工作，`docker run` 一堆参数写到手抽筋、启动顺序管不住、卷和网络没版本。Day17 就是把「零散容器」拧成「一台机器」的收官日：先讲 Docker 自定义 `bridge` 网络与 `host` 网络的差别 + 容器互联的服务名 DNS；再用一份 `docker-compose.yml` 把 4 个服务一键编排，把 `.env`、`depends_on` + `healthcheck`、命名卷、`restart: always` 逐字讲透；接着把 Nginx **容器化**成反向代理，前后端**同源**部署到服务器，浏览器打开 `https://yoga.example.com` 拿到真实数据；再把「本地 build + push + ssh + up」串成 **GitHub Actions** 自动流水线，`git push` 一次 CI 全绿；再写 `deploy.sh` 让服务器接受 tag 参数一键拉取、健康检查、失败回滚，再补 `mysqldump` 备份与监控告警；最后用一张 mindmap 把 17 天 34 章 107 技术点串成知识地图，给出 5 个拓展项目建议。**Day17 = 课程闭环 + 简历级作品链接**。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Docker 自定义网络 + 容器互联 | `yoga-net` 自定义 bridge · 服务名 DNS 打通 |
| 第 2 讲 | docker compose 一键编排四服务 | 一份 YAML + 一份 `.env` · `up -d` 全绿 |
| 第 3 讲 | Nginx 容器内反代 + 全栈上线 | 浏览器打开 `https://yoga/` · 登录 → 员工列表 |
| 第 4 讲 | GitHub Actions CI（自动构建 push 镜像） | `.github/workflows/backend-ci.yml` · `git push` 一次镜像自动可用 |
| 第 5 讲 | `deploy.sh` 一键部署 + 回滚 + 备份 | 60 秒回滚 · mysqldump 每日凌晨自动 |
| 第 6 讲 | 全栈课程回顾 + 5 个拓展项目建议 | 34 章 mindmap · 简历作品链接 |

---

## 第 1 讲：Docker 自定义网络（bridge / host）+ 容器互联

### 1.1 引入：容器 A 想连容器 B，A 该填什么

Day16 我们把后端打成镜像 `yoga/backend:1.0.0`，`docker run -p 8080:8080` 单独跑起来了——但连数据库的 `SPRING_DATASOURCE_URL` 写的是 `jdbc:mysql://localhost:3306/yoga`，而 MySQL 也在另一个容器里，`localhost` 指向的是 **backend 容器自己的回环地址**，根本连不上 MySQL。

请思考：**容器 A 想连容器 B，A 该填 B 的什么？IP？端口？还是容器名？** 拓扑如下：

```
┌──────────────┐        ┌──────────────┐
│ backend      │  ???   │ mysql        │
│ 172.18.0.3   │◄──────►│ 172.18.0.2   │
└──────────────┘        └──────────────┘
       └──────── docker network ─────────┘
```

🎯 **一句话目标**：**用自定义 bridge 网络让 backend 用 `mysql` 这个服务名连到 MySQL 容器**。今天先把「网络 + DNS」的基础打牢，下一讲直接进 compose 一键编排。

### 1.2 Docker 三种网络驱动的选型全景

| 驱动 | 定位 | 端口发布 | 隔离强度 | 容器名 DNS | 典型场景 |
|---|---|---|---|---|---|
| `bridge`（默认） | 装完自带的默认网桥，子网通常 `172.17.0.0/16` | 需 `-p` | NAT 隔离 | ❌ 不解析 | 只跑单容器时凑合 |
| `host` | 容器直接使用宿主机网络栈 | 不需 `-p`（用宿主端口） | 无隔离 | 无（就是宿主） | 极致性能、单机监控 |
| `none` | 只有回环 `lo` | 无 | 完全隔离 | 无 | 纯计算、安全隔离 |
| **自定义 bridge** | `docker network create yoga-net` | 需 `-p` | NAT 隔离 | ✅ 内置 DNS | **生产项目唯一推荐** |

🎯 **关键差别**：**默认 bridge 与自定义 bridge 唯一区别但极其致命**——**自定义 bridge 自带内置 DNS，容器名可当主机名互相解析**。生产项目**无一例外**都用自定义网络。

**为什么默认 bridge 有 DNS 更好、Docker 却默认不开**：**历史兼容**。早期版本用 `/etc/hosts` 静态方案，后来引入 embedded DNS 但为了不破坏遗留脚本，只在自定义网络上开启。官方文档明确写明「生产使用请建自定义网络」。

**`host` 网络的平台差异**：Linux 原生 Docker 上 `host` 模式生效，Docker Desktop（Mac / Windows）由于 VM 层原因**行为不完全一致**，本课以 Linux 服务器为目标。Mac 学生本地演示时切记切换心智。

### 1.3 自定义网络三条命令走通容器互联

```bash
# 1. 建一张自定义网络
docker network create yoga-net

# 2. 起 MySQL，加入 yoga-net，名字叫 mysql
docker run -d --name mysql --network yoga-net \
  -e MYSQL_ROOT_PASSWORD=Root@123 -e MYSQL_DATABASE=yoga mysql:8.0

# 3. 起 backend，同网络，连接串主机部分写 mysql（不是 localhost、不是 IP）
docker run -d --name backend --network yoga-net \
  -e SPRING_DATASOURCE_URL='jdbc:mysql://mysql:3306/yoga' \
  -e SPRING_DATASOURCE_USERNAME=root \
  -e SPRING_DATASOURCE_PASSWORD=Root@123 \
  -p 8080:8080 yoga/backend:1.0.0

# 4. 用容器名 ping 通——见证奇迹
docker exec backend ping -c 1 mysql
```

`SPRING_DATASOURCE_URL` 里主机部分**写 `mysql`**（就是上一条命令的 `--name mysql`），Docker 内置 DNS 会解析到当前 mysql 容器的内网 IP。**服务名 = 主机名**——这是容器化后端配置的黄金铁律。

### 1.4 端口发布语义：`-p 宿主:容器`

| 写法 | 宿主端口 | 容器端口 | 浏览器访问 |
|---|---|---|---|
| `-p 8080:8080` | 8080 | 8080 | `http://host:8080/` ✅ |
| `-p 80:8080` | 80 | 8080 | `http://host/` ✅ |
| `-p 8080:80` | 8080 | 80 | 只有容器内应用监听 80 时才通；监听 8080 就 404/拒绝 ❌ |

🎯 **警示**：**冒号左边永远是外部世界（宿主机）端口，冒号右边是容器内部应用监听端口**。学生极容易记反——记反后浏览器就打不开。

### 1.5 三种连接串写法结果对照

| 写法 | 结果 |
|---|---|
| `jdbc:mysql://localhost:3306/yoga` | 连自己容器 → **Connection refused** |
| `jdbc:mysql://172.18.0.2:3306/yoga` | 连硬编码 IP → 容器**重启后 IP 变**，失败 |
| `jdbc:mysql://mysql:3306/yoga` | 连服务名 → **成功**（自定义网络自带 DNS） |

### 1.6 排障工具：`docker network inspect`

```bash
docker network inspect yoga-net
```

关注 JSON 输出的三段：

- `Subnet`：子网 CIDR，如 `172.18.0.0/16`
- `Gateway`：网关 IP，如 `172.18.0.1`
- `Containers`：已连接的容器列表，每个容器的**内部 IP** 与 **MAC 地址**

排障口诀：**两容器互 ping 不通 → 先 inspect 看两个是不是在同一网络里 → 再看 IP 有没有分到**。

### 1.7 对照实验：默认 bridge vs 自定义 bridge

```bash
# —— 默认 bridge ——
docker run -dit --name a alpine sh
docker run -dit --name b alpine sh
docker exec a ping -c 1 b
# → bad address 'b'   ❌

docker rm -f a b

# —— 自定义 bridge ——
docker network create demo-net
docker run -dit --name a --network demo-net alpine sh
docker run -dit --name b --network demo-net alpine sh
docker exec a ping -c 1 b
# → 64 bytes from b   ✅
```

🎯 **一句话记住**：**自定义网络 = 免费送 DNS**。

### 1.8 常见坑

| 现象 | 原因 | 修复 |
|---|---|---|
| `docker exec a ping b` 报 `bad address` | 容器都在**默认 bridge**——无 DNS | 建自定义网络 + `--network yoga-net` 加入 |
| `Communications link failure to mysql:3306` | 后端连接串写 `localhost` | 改为服务名 `mysql`；确认两容器同网络 |
| 后端连接串里写死 IP，重启 MySQL 后连不上 | IP 每次启动动态分配 | **永远用服务名**，不要硬编码 IP |
| 浏览器 `http://localhost:9090` 拒绝连接（用了 `-p 8080:9090`） | 应用容器内监听的是 8080，`-p` 写反 | 改成 `-p 8080:8080` 或 `-p 9090:8080` |
| `host` 网络在 Mac 上 `-p` 被忽略仍能访问 | Docker Desktop VM 层介入 | 生产以 Linux 为准；Mac 上演示注意心智切换 |
| AI 生成的命令用 `--link mysql:mysql` | `--link` **已废弃**，Docker 20+ 不推荐 | 用 `--network` + 自定义网络代替 |

### 1.9 练习

1. **必做**：把 Day16 打好的 `yoga/backend:1.0.0` 与 `mysql:8.0` 用**自定义网络** `yoga-net` 起起来，`docker exec backend ping mysql` 通，`curl http://localhost:8080/actuator/health` 返回 `UP`，交 3 条命令 + 输出截图。
2. **必做**：故意把 `docker run` 换成默认 bridge（去掉 `--network yoga-net`），backend 启动后 30 秒内必然报 `Communications link failure`，交错误日志截图 + 简述「为什么默认 bridge 不通」的一段话。
3. **挑战**：用 `docker network inspect yoga-net` 查到 mysql 容器的内部 IP，重启 mysql 容器再查一次——观察 IP 是否变化，写一段结论解释「为什么 mysql 容器 IP 会变，而服务名不会失效」。

---

## 第 2 讲：docker compose 一键编排（MySQL + Redis + Backend + Nginx）

### 2.1 引入：4 服务 30 条命令 → 1 条命令拉起

第 1 讲我们用 `docker run` 手工连了两个容器——3 条命令，还能忍。但真实项目是 **MySQL + Redis + Backend + Nginx** 四个容器，每个 `docker run` 起码 8-12 个参数：

```bash
docker run -d --name mysql --network yoga-net \
  -e MYSQL_ROOT_PASSWORD=xxx -e MYSQL_DATABASE=yoga \
  -v mysql-data:/var/lib/mysql \
  --restart always mysql:8.0
# ...再写 3 遍 redis / backend / web，凑够 30 条命令
```

问题一目了然：

1. **参数长、顺序敏感**——backend 要在 MySQL 就绪后启动；
2. **无版本管理**——同事接手第一件事是问「你的 30 条命令呢」；
3. **无法一次启停**——`docker stop $(docker ps -q)` 会把宿主上所有容器一起停。

🎯 **一句话目标**：**写一份 `docker-compose.yml` + 一份 `.env`，`docker compose up -d` 一条命令拉起 mysql / redis / backend / web 四服务**。

### 2.2 compose 顶层三段结构与目录约定

Docker Compose v2 已**废弃** `version:` 字段（写了会警告）。顶层只有三段：

```yaml
services:   # 一堆服务
networks:   # 自定义网络
volumes:    # 命名卷
```

生产项目目录约定：

```text
/opt/yoga/
├── docker-compose.yml
├── .env                          # 敏感值（不入 Git）
├── nginx/conf.d/yoga.conf        # Nginx 站点配置
├── data/mysql/init/              # 初始化 SQL（首次启动执行）
├── data/certs/                   # HTTPS 证书
├── data/uploads/                 # 上传文件持久目录
└── logs/                         # backend / nginx 日志
```

🎯 **警示**：`.env` 与 `docker-compose.yml` 必须**同目录**且文件名精确是 `.env`，才会被自动加载。`.gitignore` 必加 `.env`——**敏感值绝不入库**。

### 2.3 `.env` + `${VAR}` 占位符

`/opt/yoga/.env`：

```bash
MYSQL_ROOT_PASSWORD=StrongRootPwd!
MYSQL_DATABASE=yoga
MYSQL_USER=yoga
MYSQL_PASSWORD=StrongUserPwd!
REDIS_PASSWORD=Yoga@Redis
JWT_SECRET=change-me-in-prod
BACKEND_IMAGE=registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
WEB_IMAGE=registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
```

`docker-compose.yml` 里所有敏感值全部走 `${VAR}` 占位符——本地开发、测试、生产切 `.env` 就切环境。

**渲染验证**：

```bash
docker compose config
```

会把 `${VAR}` 全部替换成实际值输出。学生第一次看会惊呼「原来 `.env` 是这样注入的」。

🎯 **警示**：`${MYSQL_PASSWORD}` 与 `$${LITERAL}` 前者被替换、后者保留字面 `$`——如果密码里含 `$` 要用 `$$` 转义。

### 2.4 四服务完整骨架

```yaml
services:
  mysql:
    image: mysql:8.0
    container_name: yoga-mysql
    restart: always
    environment:
      MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
      MYSQL_DATABASE:     ${MYSQL_DATABASE}
      MYSQL_USER:         ${MYSQL_USER}
      MYSQL_PASSWORD:     ${MYSQL_PASSWORD}
      TZ: Asia/Shanghai
    command:
      - --character-set-server=utf8mb4
      - --collation-server=utf8mb4_unicode_ci
      - --default-authentication-plugin=caching_sha2_password
    volumes:
      - mysql-data:/var/lib/mysql
      - ./data/mysql/init:/docker-entrypoint-initdb.d:ro
    networks: [yoga-net]
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-p${MYSQL_ROOT_PASSWORD}"]
      interval: 10s
      timeout:  5s
      retries:  10

  redis:
    image: redis:8-alpine
    container_name: yoga-redis
    restart: always
    command: ["redis-server", "--requirepass", "${REDIS_PASSWORD}", "--appendonly", "yes"]
    volumes:
      - redis-data:/data
    networks: [yoga-net]
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "PING"]
      interval: 10s
      timeout:  3s
      retries:  5

  backend:
    image: ${BACKEND_IMAGE}
    container_name: yoga-backend
    restart: always
    environment:
      SPRING_PROFILES_ACTIVE: prod
      SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/${MYSQL_DATABASE}?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai
      SPRING_DATASOURCE_USERNAME: ${MYSQL_USER}
      SPRING_DATASOURCE_PASSWORD: ${MYSQL_PASSWORD}
      SPRING_DATA_REDIS_HOST: redis
      SPRING_DATA_REDIS_PASSWORD: ${REDIS_PASSWORD}
      JWT_SECRET: ${JWT_SECRET}
      TZ: Asia/Shanghai
      JAVA_OPTS: "-Xms256m -Xmx512m"
    volumes:
      - ./logs/backend:/app/logs
      - ./data/uploads:/app/uploads
    depends_on:
      mysql: { condition: service_healthy }
      redis: { condition: service_healthy }
    networks: [yoga-net]
    expose: ["8080"]                # 内部暴露，不对外
    healthcheck:
      test: ["CMD-SHELL", "wget -qO- http://localhost:8080/actuator/health || exit 1"]
      interval: 30s
      timeout: 3s
      start_period: 40s
      retries: 3

  web:
    image: ${WEB_IMAGE}
    container_name: yoga-web
    restart: always
    depends_on:
      - backend
    volumes:
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./logs/nginx:/var/log/nginx
      - ./data/certs:/etc/nginx/certs:ro
    ports:
      - "80:80"
      - "443:443"
    networks: [yoga-net]

networks:
  yoga-net:
    driver: bridge

volumes:
  mysql-data:
  redis-data:
```

**十项常用字段速查**：

| 字段 | 作用 |
|---|---|
| `image` | 拉取的镜像坐标（可带 `${VAR}`） |
| `container_name` | 显式命名，`docker ps` 里好认 |
| `restart` | `always` 崩溃自动重启 |
| `environment` | 环境变量（键: 值） |
| `env_file` | 从外部文件读环境变量（可与 `.env` 混用） |
| `volumes` | 命名卷 `mysql-data:/var/lib/mysql` 或 bind `./nginx:/etc/nginx:ro` |
| `networks` | 加入哪些网络（本项目统一 `yoga-net`） |
| `ports` | 对外发布 `宿主:容器` |
| `expose` | 只内网可见（不发布到宿主） |
| `depends_on` | 启动顺序（配 `condition: service_healthy` 才等就绪） |
| `healthcheck` | 探针（`test` 用数组格式，别用字符串） |

### 2.5 `depends_on` + `healthcheck` 双保险

🎯 **难点重锤**：`depends_on` **只等启动、不等就绪**。MySQL 容器进程起了不等于 MySQL 就绪——它还要跑 30 秒初始化数据目录。这段时间 backend 冲上去就是 `Communications link failure`。

只有把 `healthcheck` 配上、`depends_on.condition` 写成 `service_healthy`，compose 才会**真正**等到 MySQL 探针连续通过再启动 backend。

**反面演示**：把 mysql 的 `healthcheck` 段整块注释掉，`depends_on.mysql.condition` 改回 `service_started`：

```bash
docker compose down && docker compose up -d
docker compose logs -f backend
# → 前 30 秒疯狂 Communications link failure to mysql:3306
# → Spring Boot 默认没配重试直接崩溃 → restart: always 又拉起 → 又崩
# → 启动死循环
```

恢复 healthcheck 后一次性起来。**启动 ≠ 就绪，depends_on 必须配 healthcheck**。

### 2.6 `expose` vs `ports`：安全边界

| 字段 | 可见范围 | 用途 |
|---|---|---|
| `expose: ["8080"]` | **只**同 compose 网络内可见 | backend 只面向 Nginx 反代 |
| `ports: ["80:80"]` | 对宿主发布，公网可达 | Nginx 面向浏览器 |

🎯 **安全铁律**：backend 只 `expose`、不 `ports`——**直接暴露 8080 是「两扇门」，攻击面翻倍**。所有对外流量必须走 Nginx。

### 2.7 命名卷 vs bind mount

| 类型 | 语法 | 适用 |
|---|---|---|
| **命名卷** | `mysql-data:/var/lib/mysql` | 数据库、Redis——Docker 全权管理，跨机迁移方便 |
| **bind mount** | `./nginx/conf.d:/etc/nginx/conf.d:ro` | 配置文件、日志——宿主可直接编辑、`nginx -s reload` 生效 |

**只读挂载 `:ro`** 用于配置与证书——防止容器进程被入侵后写坏文件。

### 2.8 日常五条命令

```bash
docker compose config              # 校验语法 + 渲染 ${VAR}
docker compose up -d               # 后台启动全部服务
docker compose up -d --build       # 顺便本地构建（有 build: 段时）
docker compose ps                  # 状态，理想是全部 Up (healthy)
docker compose logs -f backend     # 单服务日志
docker compose logs -f --tail 200  # 全部日志末尾 200 行
docker compose restart backend     # 重启单服务
docker compose stop                # 停全部（不删）
docker compose down                # 停止 + 移除容器和网络（卷保留）
docker compose down -v             # 连命名卷一起删（数据没了）
docker compose pull                # 拉新镜像
```

🎯 **警示**：`down -v` 会**删除命名卷**——数据库数据一起没了。生产上除非确定要重置数据，否则永远只用 `down`，不用 `-v`。

### 2.9 常见坑

| 现象 | 原因 | 修复 |
|---|---|---|
| `WARN[0000] version is obsolete` | 顶层还写着 `version: '3.8'` | 删掉 `version:` 那一行 |
| `env file .env not found` | `.env` 不在 compose 同目录 / 文件名错 | 精确 `.env`，与 `docker-compose.yml` 同目录 |
| backend 起来又崩、又起来又崩 | `depends_on` 缺 `service_healthy` | 加 healthcheck + `condition: service_healthy` |
| MySQL 中文乱码 | `command` 里没加字符集 | `--character-set-server=utf8mb4` |
| MySQL 密码含 `$` compose 解析失败 | `$` 被 compose 当成变量占位 | 密码里的 `$` 写成 `$$`，或用 `.env` 单引号形式 |
| `docker compose ps` 里 backend 一直 `starting` | healthcheck 命令探针有问题 | `test` 用数组格式；exec 进容器手动跑一次探针命令 |
| 生产上 `docker compose down -v` 后数据消失 | 命名卷被一并删除 | 事故预案：先 `mysqldump` 备份再操作；日常用 `down` |
| AI 生成的 compose 顶层加 `version: '3.8'` | AI 用了老知识 | 删掉；compose v2 不再需要 |
| AI 把密码写在 YAML 里 | 图省事 | 全部改 `${VAR}` + `.env`；`.env` 加进 `.gitignore` |

### 2.10 练习

1. **必做**：把讲义里的 `docker-compose.yml` + `.env` 拷贝到本地或云主机 `/opt/yoga/`（backend / web 镜像可先用 `nginx:1.24` 占位），`docker compose up -d` 起 4 个容器全部 `Up (healthy)`，交 `docker compose ps` 截图。
2. **必做**：把 `depends_on` 里的 `condition: service_healthy` 改回 `service_started` 再复现一次启动失败，看 `docker compose logs backend` 里 `Communications link failure` 的日志，交错误截图 + 一句话解释「为什么会失败」。
3. **挑战**：给 compose 增加一个 `adminer`（MySQL 图形化管理）服务，`image: adminer:latest`，`ports: 8081:8080`，`depends_on: mysql`，浏览器打开 `http://localhost:8081` 用服务名 `mysql` 登录数据库。

---

## 第 3 讲：Nginx 容器内反向代理 + 前后端全栈上线

### 3.1 引入：4 个容器 Up (healthy)，浏览器却打不开业务页

第 2 讲结尾我们看到 4 个容器 `Up (healthy)`，但浏览器打开 `http://localhost/` 显示 Nginx 默认欢迎页——因为**没配站点**。

请思考：**浏览器请求 `/api/emp/list` 该到哪去？请求 `/dashboard` 又该返回什么？** 前后端同域架构：

```
浏览器 https://yoga.example.com
         │
    ┌────┴────┐
    │ Nginx   │ 80/443 对外
    │ (web)   │
    └────┬────┘
    /api/*    /
    │         │
    ▼         ▼
 backend:8080  dist/index.html (SPA)
 (内网 expose)
```

🎯 **一句话目标**：**让浏览器 `http://yoga.local/` 打开是登录页、点登录后 `/api/auth/login` 走到 backend、拿 Token 后 `/api/emp/list` 拉到数据**。

### 3.2 Nginx 一份配置承担 3 件事

Nginx 在容器化全栈里承担三重角色：

1. **SPA 静态托管**：把 Vite 打包出的 `dist/` 放 `/usr/share/nginx/html`，`try_files` SPA fallback；
2. **API 反向代理**：`/api/*` 转发到 `http://backend:8080/`（容器内部服务名 DNS）；
3. **HTTPS 卸载**：证书装在 Nginx 侧，backend 依然裸 HTTP，简化配置与升级。

Day16 已经把前端打成 `yoga/web:1.0.0` 镜像（Dockerfile 用 `nginx:1.24-alpine` 作 base、把 `dist/` `COPY` 到 `/usr/share/nginx/html`）。compose 里 `web` 服务把宿主 `./nginx/conf.d` 挂载到容器 `/etc/nginx/conf.d:ro`——**配置放宿主、改完 reload 即生效**。

🎯 **原则**：**不要重新构建镜像来改配置**——配置应该是「运行时可注入」的资源。

### 3.3 完整 `nginx/conf.d/yoga.conf`（HTTP 版）

```nginx
server {
    listen      80;
    server_name yoga.local;
    root  /usr/share/nginx/html;
    index index.html;

    # SPA fallback：任何未命中的路径都回 index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 带 hash 的静态资源强缓存 1 年
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # API 反代到后端容器
    location /api/ {
        proxy_pass         http://backend:8080/;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_connect_timeout 5s;
        proxy_read_timeout    60s;

        # WebSocket 支持（可选，Day17 暂不用）
        proxy_set_header Upgrade    $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    client_max_body_size 20m;      # 允许 20MB 上传（头像 / 附件）

    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
    gzip_min_length 1024;

    access_log /var/log/nginx/yoga.access.log;
    error_log  /var/log/nginx/yoga.error.log warn;
}
```

**逐段拆解**：

- `server_name yoga.local`：匹配 `Host` 头；生产改为你的真实域名
- `root` + `index`：SPA 目录与首页
- `try_files $uri $uri/ /index.html`：**SPA fallback 铁律**——不写这一行，刷新 `/dashboard` 就 404
- `/assets/` 段：Vite 打包出来的 JS/CSS 都带 hash，可以放心 1 年强缓存
- `/api/` 段：反代 backend 容器，proxy_set_header 四件套让后端拿到真实客户端信息
- `client_max_body_size 20m`：Nginx 默认 1MB，上传大文件会 **413**——一定要显式设置
- Gzip：文本资源压缩，节省带宽

### 3.4 `proxy_pass` 末尾斜杠语义

🎯 **重锤难点**：`proxy_pass` **末尾斜杠决定是否剥掉 location 前缀**。

| 写法 | 客户端请求 | 后端收到 |
|---|---|---|
| `proxy_pass http://backend:8080/;`（有尾斜杠） | `/api/auth/login` | `/auth/login`（前缀 `/api` 被剥） |
| `proxy_pass http://backend:8080;`（无尾斜杠） | `/api/auth/login` | `/api/auth/login`（原样透传） |

Spring Boot 后端 Controller 通常写 `@RequestMapping("/auth")`——**必须**用带尾斜杠版本，才能匹配 handler。忘了尾斜杠 → 404。

`proxy_set_header` 四件套的作用：

| Header | 作用 |
|---|---|
| `Host` | 让后端知道客户端最初请求的域名，用于 URL 生成 |
| `X-Real-IP` | 客户端真实 IP（不带代理链） |
| `X-Forwarded-For` | 完整代理链 IP 列表 |
| `X-Forwarded-Proto` | `http` 或 `https`，用于后端判断是否安全连接 |

不配这四件套的后果：后端只看到 Nginx 容器的内网 IP `172.18.0.x`，日志与限流全废。

### 3.5 HTTPS 增量配置

有证书时把 80 端口改成 301 跳转，加一段 443：

```nginx
# 80 → 443 强制跳转
server {
    listen 80;
    server_name yoga.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yoga.example.com;

    ssl_certificate     /etc/nginx/certs/yoga.pem;
    ssl_certificate_key /etc/nginx/certs/yoga.key;
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_session_timeout 1d;
    ssl_session_cache   shared:SSL:10m;

    # ...其余 location 段与 HTTP 版一样
}
```

**证书两种来源**：

| 方案 | 命令 | 特点 |
|---|---|---|
| Let's Encrypt certbot | `sudo certbot certonly --standalone -d yoga.example.com` | 免费、90 天到期、需自动续期 |
| 云厂商托管（阿里云 / 腾讯云 / Cloudflare） | 控制台下载 `.pem` + `.key` | 免费一年 / 可托管、稳定 |

certbot 证书路径 `/etc/letsencrypt/live/yoga.example.com/fullchain.pem` + `privkey.pem`，拷到 `./data/certs/yoga.pem` + `yoga.key`，compose 挂 `./data/certs:/etc/nginx/certs:ro`。

**90 天自动续期**（cron / systemd timer）：

```bash
# /etc/cron.d/certbot-renew
0 3 * * * root certbot renew --quiet --deploy-hook "cd /opt/yoga && docker compose exec web nginx -s reload"
```

### 3.6 全栈闭环验收清单

依次跑完这五步，全栈上线才算真的通：

```bash
docker compose up -d                                # 1. 4 服务全 healthy
curl http://localhost/                              # 2. 拿到 index.html
curl -X POST http://localhost/api/auth/captcha      # 3. 后端返回 {key, image} —— API 反代通
```

4. 浏览器打开 `http://localhost/login` → 输 `admin / 123456 / 验证码` → 跳 `/dashboard` → 员工列表出现
5. Chrome DevTools Network 里所有 `/api/*` 请求都从 `http://localhost/` 发出——**同源、无 CORS 问题**

**「今天，你的项目真的能打开了」**。

### 3.7 常见坑

| 现象 | 原因 | 修复 |
|---|---|---|
| 后端 404，登录接口找不到 | `proxy_pass http://backend:8080`（无尾斜杠） | 加尾斜杠：`http://backend:8080/` |
| 刷新 `/dashboard` 白屏或 404 | 缺 `try_files $uri $uri/ /index.html` | 补上；末尾必须是 `/index.html`（前导斜杠） |
| 上传头像 413 Request Entity Too Large | Nginx 默认 body 上限 1MB | `client_max_body_size 20m;` |
| 后端日志里客户端 IP 全是 `172.18.0.x` | 少配 `proxy_set_header X-Real-IP / X-Forwarded-For` | 补齐 4 件套 |
| 反代 502 Bad Gateway | backend 没起 / 端口写错 / 不在同网络 | `docker compose logs backend`；确认 `expose 8080` 与 `proxy_pass http://backend:8080/` 一致 |
| 证书路径挂载 `:rw` | 容器进程被入侵可写坏证书 | 一定用 `:ro` 只读 |
| HTTPS 证书到期页面报错 | 忘了配 certbot renew | 加 cron 每日凌晨 renew + reload nginx |
| AI 生成 nginx 配置忘 `try_files` | AI 只写传统多页应用 | 手动补上；SPA 必须 |
| AI 用 `proxy_pass http://localhost:8080` | AI 忘了容器网络 | 改服务名 `http://backend:8080/` |

### 3.8 练习

1. **必做**：在本地或云主机上把 4 服务 compose 起来 + `nginx/conf.d/yoga.conf` 配好，浏览器打开 `http://localhost/` 完成登录 + 员工列表加载，交 2 张浏览器截图 + Chrome Network 的 `/api/auth/login` 200 截图。
2. **必做**：故意把 `proxy_pass` 末尾斜杠去掉，观察 backend 收到的 URL（在 `EmpController` 加一个日志打印 `HttpServletRequest.getRequestURI()`），交对照截图 + 一句话解释末尾斜杠的作用。
3. **挑战**：申请一个免费域名 + Let's Encrypt 证书，把 nginx 配置改成 HTTPS，浏览器打开 `https://<your-domain>/` 拿到绿色小锁——这就是你的第一个「可放简历的作品链接」。

---

## 第 4 讲：GitHub Actions CI（自动构建镜像 + push registry）

### 4.1 引入：本地上线 5 步，push 一周 20 次要疯

第 3 讲结尾学生做了一次手工上线：

```text
本地 build → docker push → SSH → docker compose pull → up -d
```

5 步、每步都要人肉、忘一步就出错。而且没人知道「v1.0.1 到底包含了哪些提交」——版本追溯全靠脑子。

**CI / CD** 是两个概念：

- **CI（Continuous Integration，持续集成）**：代码 push 后自动跑**构建 + 测试 + 打镜像 + 推仓库**
- **CD（Continuous Delivery / Deployment，持续交付 / 部署）**：CI 通过后自动或半自动**部署到目标环境**

入门课不追求全套 CD，先做最实用的一步：**代码推送 → CI 自动打镜像并推到镜像仓库**（第 5 讲再做 CD）。

🎯 **一句话目标**：**让 `git push origin main` 一次触发 GitHub Actions 自动构建两个镜像并推到 ACR**。

### 4.2 workflow 目录约定 + 三种触发

GitHub Actions 约定所有 workflow 文件放 `.github/workflows/*.yml`，一个仓库可以有多个：

```
.github/
└── workflows/
    ├── backend-ci.yml
    └── web-ci.yml
```

**触发规则** `on:` 三种最常用：

```yaml
on:
  push:
    branches: [main]              # 推 main 分支
    tags:     ['v*']              # 打 v 开头的 tag
    paths:                        # monorepo 过滤：只有 backend 变了才触发
      - 'backend/**'
      - '.github/workflows/backend-ci.yml'
  workflow_dispatch:              # 页面上手动点一下重跑
```

🎯 **关键**：`paths` 过滤器**必须**同时包含 `.github/workflows/backend-ci.yml` 自己——否则改 workflow 文件本身不触发，会一头雾水。

### 4.3 完整 `backend-ci.yml`

```yaml
name: backend-ci

on:
  push:
    branches: [main]
    tags:     ['v*']
    paths:
      - 'backend/**'
      - '.github/workflows/backend-ci.yml'
  workflow_dispatch:

env:
  IMAGE_NAME: yoga/backend
  REGISTRY:   registry.cn-hangzhou.aliyuncs.com

jobs:
  build-and-push:
    runs-on: ubuntu-latest
    permissions:
      contents: read

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 25
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '25'
          cache: maven

      - name: Unit test
        working-directory: backend
        run: ./mvnw -B -DskipTests=false test

      - name: Compute tag
        id: tag
        run: |
          TAG=${GITHUB_REF##*/}
          [[ "$GITHUB_REF" == refs/heads/* ]] && TAG=sha-${GITHUB_SHA:0:8}
          echo "tag=$TAG" >> $GITHUB_OUTPUT

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to ACR
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ secrets.ACR_USER }}
          password: ${{ secrets.ACR_TOKEN }}

      - name: Build & Push
        uses: docker/build-push-action@v6
        with:
          context: backend
          push:    true
          tags: |
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ steps.tag.outputs.tag }}
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest
          cache-from: type=gha
          cache-to:   type=gha,mode=max
```

**7 步流水线**：

| 步 | 动作 | 说明 |
|---|---|---|
| 1 | `actions/checkout@v4` | 拉源码到 Runner |
| 2 | `actions/setup-java@v4` | 装 Temurin JDK 25 + Maven 缓存 |
| 3 | `./mvnw test` | 单元测试；挂了后续步骤全跳过 |
| 4 | 计算 tag | 分支 → `sha-<8>` / 标签 → 同名 |
| 5 | `setup-buildx-action@v3` | 启用高级构建器 |
| 6 | `docker/login-action@v3` | 登录阿里云 ACR |
| 7 | `docker/build-push-action@v6` | 构建 + 推双 tag（版本 + latest） |

`distribution: temurin` 是 setup-java 支持的 OpenJDK 发行版（免登录、免协议），CI 场景选它；本地开发仍以 Oracle 官网下载的 JDK 25 为准。

### 4.4 tag 策略：让「提交 = 版本」天然对齐

```bash
TAG=${GITHUB_REF##*/}
[[ "$GITHUB_REF" == refs/heads/* ]] && TAG=sha-${GITHUB_SHA:0:8}
```

| 触发场景 | `GITHUB_REF` | 计算结果 |
|---|---|---|
| 推 `main` 分支 | `refs/heads/main` | `sha-a1b2c3d4`（前 8 位 commit hash） |
| 打 tag `v1.0.1` | `refs/tags/v1.0.1` | `v1.0.1`（保留完整语义化版本） |
| 打 tag `v2.0.0-rc.1` | `refs/tags/v2.0.0-rc.1` | `v2.0.0-rc.1` |

结果：**分支提交每次都有唯一可追溯的 tag，正式版本走 `vX.Y.Z` 语义化**。

`echo "tag=$TAG" >> $GITHUB_OUTPUT` 是 GitHub Actions 新语法（`::set-output` 已废弃），后续 step 通过 `${{ steps.tag.outputs.tag }}` 读取。

### 4.5 Secrets 配置与安全模型

仓库路径：**Settings → Secrets and variables → Actions → New repository secret**。

本讲需要配 2 个：

| Secret 名 | 值 | 来源 |
|---|---|---|
| `ACR_USER` | 阿里云 ACR 用户名 | ACR 控制台 → 访问凭证 |
| `ACR_TOKEN` | 阿里云 ACR 访问 Token | ACR 控制台 → 访问凭证 → 生成 Token |

🎯 **安全模型三条**：

1. **只写不读**：Secret 一旦创建**任何人都读不到**，连仓库 admin 也读不到。只能覆盖或删除。
2. **日志自动打码**：workflow 里如果误 `echo ${{ secrets.ACR_TOKEN }}`，输出会显示 `***`，防止意外泄露。
3. **Fork PR 拿不到 Secret**——GitHub 的安全设计。开源项目里陌生人的 PR 无法访问你的密钥。

🎯 **警示**：Secret 名字**大小写敏感**——`secrets.acr_token` 会返回空串、`login` 静默失败。

### 4.6 `type=gha` 层缓存：5 分钟压到 30 秒

```yaml
cache-from: type=gha
cache-to:   type=gha,mode=max
```

**原理**：GitHub Actions 提供仓库级 Cache API（10GB 上限），Docker Buildx 把每一层的构建产物按内容哈希缓存进去。下次构建时，未变化的层**直接命中缓存**，跳过重新构建。

| 场景 | 时间 |
|---|---|
| 首次构建（无缓存） | 3-5 分钟量级 |
| 二次构建，仅改了业务代码（前置层全命中） | 25-40 秒量级 |
| Dockerfile 前置层变了（如换 base 镜像） | 缓存失效，重回首次时长 |

🎯 **最佳实践**：Dockerfile 里把**变化频率低**的层放前面（`FROM`、`RUN apt install`、`COPY pom.xml && mvn dependency:go-offline`），**变化频率高**的层放最后（`COPY . .`、`RUN mvn package`），最大化层缓存命中。

### 4.7 前端 `web-ci.yml` 的差异

前端 workflow 几乎一样，只改 3 处：

```yaml
- name: Set up Node
  uses: actions/setup-node@v4
  with:
    node-version: '20'
    cache: pnpm

- name: Install
  working-directory: web
  run: pnpm install --frozen-lockfile

- name: Build
  working-directory: web
  run: pnpm build

# build-push 那步 context: web
```

其余触发规则、tag 计算、Secrets 完全复用。

### 4.8 从 `push` 到 CI 全绿的验收

```bash
# 本地
git add .github/workflows/backend-ci.yml backend/
git commit -m "ci: bootstrap backend pipeline"
git push origin main

# GitHub 仓库 → Actions Tab
# → 看到 backend-ci #1 在跑
# → 逐个 step 展开：checkout / setup-java（缓存命中 8s）/ mvn test（1m20s）
#    / buildx / build+push（首次 3m30s）
# → 全绿 ✅

# 阿里云 ACR 控制台
# → 看到 yoga/backend:sha-a1b2c3d4 + latest 两个 tag —— CI 成功
```

再改一行代码、`git push` 一次 → build+push **只花 25 秒**（层缓存命中）—— **`type=gha` 立竿见影**。

### 4.9 让 CI 挂一次：安全网价值

故意在 `EmpServiceTest.java` 加一个 `assertEquals(1, 2)`：

```bash
git commit -am "test: intentionally break"
git push
```

Actions 页面：`mvn test` step 红 ✗ → 邮件通知。**坏代码根本走不到 build 步，更不会污染 registry**——这就是 CI 的安全网。

修回来 → 再推 → 全绿。

🎯 **原则**：**CI = 每次 push 都自动跑测试，测试挂了根本推不出镜像**。这是把「保证代码质量」从人肉 review 变成机器强制的核心机制。

### 4.10 常见坑

| 现象 | 原因 | 修复 |
|---|---|---|
| Actions 页面 login 失败但日志显示 `***` | Secret 名字大小写不对 | 检查 `secrets.ACR_TOKEN` 与仓库设置里名字完全一致 |
| 改了 workflow 文件本身没触发 | `paths` 过滤器没包含 workflow 文件路径 | `paths` 加上 `.github/workflows/backend-ci.yml` |
| 二次构建时间没缩短 | Dockerfile 前置层被业务代码污染 | 把 `COPY . .` 挪到最后；`COPY pom.xml` + `mvn dependency:go-offline` 单独一层 |
| `mvn test` 超时 | Maven 依赖每次重下 | `cache: maven` 或 `actions/cache@v4` 缓存 `~/.m2` |
| Fork 的 PR CI 拿不到 Secret | GitHub 安全设计 | 正常现象；不是 bug，别改 |
| Dockerfile ARG 传敏感值 | AI 生成的常见错 | ARG 会写入镜像层，`docker history` 可读——**永远用 Secret + runtime env**，不要 build-time ARG |
| AI 用 `actions/checkout@v2` | AI 用了 5 年前的例子 | 手动改成 `@v4` |
| AI 忘了 `docker/setup-buildx-action` | 依赖顺序问题 | `build-push-action` 依赖 buildx 后端；必须加 |
| workflow 触发了却跑了 20 分钟没结果 | 没配 `cache-from/to` + `mvn` 每次全量拉依赖 | 加上 `type=gha` 缓存 + Maven 缓存 |

### 4.11 练习

1. **必做**：在自己的 GitHub 私仓写 `.github/workflows/backend-ci.yml` + `web-ci.yml`，配好 Secrets，push 一次后打开 Actions 页面看两个 workflow 全绿，交 workflow 列表截图 + ACR 镜像列表截图。
2. **必做**：故意让一个单元测试断言错，看 Actions 红 ✗ + 邮件通知，再修好 → 全绿，交对照截图 + 一句话总结「CI 的安全网价值」。
3. **挑战**：为 `backend-ci.yml` 增加 `on: pull_request` 触发（只测试、不 push 镜像），本地开一个 PR 分支验证：PR 打开时自动跑测试，合并到 main 才 push 镜像——这就是「分支保护 + CI 强制」的行业标准。

---

## 第 5 讲：`deploy.sh` 一键部署 + 版本回滚 + 备份监控

### 5.1 引入：镜像 push 到了 ACR，但服务器上还是老版本

第 4 讲把镜像 push 到了 ACR，但**没人 pull**——服务器上还是老版本。请思考：**难道每次上线都要 SSH 手工 `docker compose pull && up -d`？测试、灰度、生产三套怎么办？出 bug 了怎么回滚？**

🎯 **一句话目标**：**写 `deploy.sh`，让服务器接受 tag 参数一键拉取、健康检查、失败退出；再让 GitHub Actions 自动 SSH 触发**。

三级递进：

```text
1. 手工敲 5 步（人肉）
   ↓
2. deploy.sh 一条命令（脚本化）
   ↓
3. Actions SSH 触发 deploy.sh（自动化）
```

### 5.2 `set -euo pipefail` 严格模式四件套

生产脚本第一行**永远**是：

```bash
#!/usr/bin/env bash
set -euo pipefail
```

四件套含义：

| 选项 | 作用 |
|---|---|
| `-e` | 任何命令返回非 0 立即退出（不再执行后面） |
| `-u` | 使用未定义变量立即退出（拼错变量名不再静默） |
| `-o pipefail` | 管道中任何一环失败都算失败（默认只看最后一环） |

🎯 **原则**：**没有 `set -euo pipefail` 的部署脚本 = 定时炸弹**。见 5.6 反面演示。

### 5.3 完整 `/opt/yoga/deploy.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

usage() {
  echo "Usage: $0 <backend-tag> <web-tag>"
  exit 1
}
[[ $# -lt 2 ]] && usage

BACKEND_TAG=$1
WEB_TAG=$2
REGISTRY=registry.cn-hangzhou.aliyuncs.com

echo "==> update .env"
sed -i.bak \
  -e "s#^BACKEND_IMAGE=.*#BACKEND_IMAGE=${REGISTRY}/yoga/backend:${BACKEND_TAG}#" \
  -e "s#^WEB_IMAGE=.*#WEB_IMAGE=${REGISTRY}/yoga/web:${WEB_TAG}#" \
  .env

echo "==> docker compose pull"
docker compose pull backend web

echo "==> docker compose up -d"
docker compose up -d --remove-orphans

echo "==> health check"
sleep 5
for i in 1 2 3 4 5 6 7 8 9 10; do
  if curl -fsS http://localhost/api/actuator/health >/dev/null; then
    echo "OK"
    exit 0
  fi
  echo "waiting... ($i)"
  sleep 3
done

echo "backend not healthy, please check logs"
exit 1
```

**逐段拆解**：

| 段 | 作用 |
|---|---|
| `cd "$(dirname "$0")"` | 切到脚本所在目录（`/opt/yoga`），保证相对路径正确 |
| `[[ $# -lt 2 ]] && usage` | 参数不足直接打印用法并退出 |
| `sed -i.bak -e ...` | **原子替换** `.env` 里的镜像 tag；保留 `.env.bak` 备份 |
| `docker compose pull backend web` | 只拉这两个服务的镜像（mysql / redis 不动） |
| `docker compose up -d --remove-orphans` | 只重启有变化的服务；清理已从 compose 移除的旧容器 |
| `sleep 5` + `for` 10 次探针 | 累计 5 + 3*10 = 35 秒健康检查窗口 |
| 探针失败 `exit 1` | 让 CI / 调用方知道部署失败，不静默 |

用法：

```bash
./deploy.sh v1.0.1 v1.0.1
```

### 5.4 CI 触发 CD：`appleboy/ssh-action`

在 `backend-ci.yml` 末尾追加 Deploy step，让**打 tag 才自动部署**（普通分支 push 只构建、不上线）：

```yaml
- name: Deploy
  if: startsWith(github.ref, 'refs/tags/v')
  uses: appleboy/ssh-action@v1
  with:
    host:     ${{ secrets.SSH_HOST }}
    username: ${{ secrets.SSH_USER }}
    key:      ${{ secrets.SSH_KEY }}
    port:     ${{ secrets.SSH_PORT }}
    script: |
      /opt/yoga/deploy.sh ${{ steps.tag.outputs.tag }} ${{ steps.tag.outputs.tag }}
```

**新增 Secrets**：

| Secret | 值 |
|---|---|
| `SSH_HOST` | 服务器公网 IP 或域名 |
| `SSH_USER` | 部署账号（推荐 `yoga`，不要用 root） |
| `SSH_KEY` | **私钥完整内容**（不是路径），OpenSSH 或 PEM 格式 |
| `SSH_PORT` | SSH 端口（默认 22，非默认时必填） |

服务器侧 `~yoga/.ssh/authorized_keys` 加对应公钥，且 `~yoga/.ssh/` 权限 700、`authorized_keys` 权限 600。

🎯 **警示**：`SSH_KEY` 是**私钥内容**（`-----BEGIN OPENSSH PRIVATE KEY-----` 到 `-----END OPENSSH PRIVATE KEY-----` 全部粘贴），不是路径。学生常拷错。

### 5.5 版本回滚：60 秒回到上个版本

**语义化版本三段式**：

```text
v1.0.0  首发
v1.0.1  bug 修
v1.1.0  新功能（向后兼容）
v2.0.0  破坏性改动（不兼容）
```

**Git tag = Docker tag = 部署参数**，三者天然对齐。回滚只是一条命令：

```bash
./deploy.sh v1.0.0 v1.0.0
```

60 秒内服务器切回上个版本。

🎯 **数据库回滚警告**：**镜像回滚 ≠ 数据回滚**。如果 v1.0.1 加了 `ADD COLUMN` 或 `DROP COLUMN`，回滚镜像后数据表结构还是新的（或旧的），可能导致启动崩溃或数据损坏。

**对策**：

1. 上线前用 **Flyway / Liquibase 的 shadow 库先跑一遍迁移**，验证可逆性；
2. 破坏性迁移分两步上线：**先加字段（v1.1.0）→ 观察一周稳定 → 再删旧字段（v1.2.0）**；
3. 关键数据每天定时 `mysqldump` 备份（下节讲）。

### 5.6 反面演示：缺 `set -euo pipefail` 的后果

把 `deploy.sh` 开头 `set -euo pipefail` 注释掉，故意让 `docker compose pull` 失败（拔网线 / 改 registry 地址）：

```text
==> update .env             ← OK
==> docker compose pull     ← 失败，但没退出
==> docker compose up -d    ← 拿的是旧镜像（还在本地），继续
==> health check            ← 旧版本本来就 healthy，返回 OK
exit 0                       ← 假成功
```

学生以为部署成功，其实还是老版本——**静默失败**，最可怕的 bug。

加回 `set -euo pipefail` → pull 失败立刻 `exit 1` → CI 红灯 → 邮件通知 → 有人查。

🎯 **铁律**：**脚本第一行永远是 `set -euo pipefail`**。

### 5.7 mysqldump 每日凌晨备份

`/etc/cron.daily/yoga-mysql-backup.sh`：

```bash
#!/bin/bash
set -e

DATE=$(date +%F)
BACKUP_DIR=/opt/yoga/backup
mkdir -p "$BACKUP_DIR"

# 从 .env 读密码，避免走 argv 泄露
source /opt/yoga/.env

docker exec yoga-mysql \
  mysqldump -uroot -p"$MYSQL_ROOT_PASSWORD" \
  --single-transaction --routines --triggers \
  --databases yoga \
  | gzip > "$BACKUP_DIR/yoga-$DATE.sql.gz"

# 保留 14 天
find "$BACKUP_DIR" -name 'yoga-*.sql.gz' -mtime +14 -delete
```

**关键参数**：

| 参数 | 作用 |
|---|---|
| `--single-transaction` | InnoDB 表**一致性快照**，业务无阻塞 |
| `--routines` | 备份存储过程 |
| `--triggers` | 备份触发器 |
| `--databases yoga` | 输出会带 `CREATE DATABASE`，方便还原到新库 |
| `\| gzip` | 压缩节省空间，一般能压到原体积的 15% |
| `find -mtime +14 -delete` | 保留最近 14 天，防止磁盘爆 |

🎯 **安全警示**：`docker exec yoga-mysql mysqldump -p"$MYSQL_ROOT_PASSWORD"` 中的密码走 argv，会在其他用户 `ps` 里泄露。生产上应改 `--defaults-extra-file=/etc/yoga/mysql.cnf`（cnf 里写 `[client] password=xxx`，权限 600）。

🎯 **异地备份**：本地备份**不算真备份**——服务器炸了本地文件也没了。定时把 `.sql.gz` 同步到对象存储（阿里云 OSS / AWS S3），才是真备份。

### 5.8 监控与安全清单（入门）

**监控**（了解即可，生产上再深入）：

| 层 | 工具 |
|---|---|
| 应用侧 | Spring Boot Actuator + Prometheus + Grafana |
| 主机侧 | node-exporter / netdata / 云厂商监控 |
| 告警 | 企业微信 / 钉钉 / 飞书 webhook |

**安全清单**（生产必查）：

- [ ] SSH 用密钥登录（禁用密码），配 `fail2ban`
- [ ] 服务器只开必要端口：22 / 80 / 443
- [ ] 数据库、Redis 密码强、**只监听内网**（127.0.0.1 或 docker 内网）
- [ ] HTTPS 全站，加 HSTS 头
- [ ] 图形 & 短信验证码防刷
- [ ] 接口鉴权全走 JWT + 拦截器
- [ ] 敏感值走 `.env` 或 KMS，**绝不入 Git**
- [ ] 定期 `docker compose pull` 更新基础镜像补 CVE

### 5.9 常见坑

| 现象 | 原因 | 修复 |
|---|---|---|
| 部署脚本报「静默成功」但线上没更新 | 缺 `set -euo pipefail` | 加上；故意断网复现一次记住 |
| `sed -i` 修改后 `.env` 损坏无法回滚 | 无备份 | 用 `sed -i.bak` 保留 `.env.bak` |
| `deploy.sh` 健康检查等 30 秒就报失败 | Spring Boot 慢启动，backend 起来要 40 秒 | 循环 10 次 * 3 秒 = 30 秒不够；改成 20 次或增大 `sleep` |
| `appleboy/ssh-action` 报 `handshake failed` | `SSH_KEY` 传的是路径不是内容 | 直接粘贴私钥文件全文进 Secret |
| SSH 拒绝：`Permission denied (publickey)` | 公钥没加到服务器 authorized_keys | `ssh-copy-id yoga@server`；确认权限 700/600 |
| CD 自动跑到所有 push（非 tag）都触发 | 忘 `if: startsWith(github.ref, 'refs/tags/v')` | 加上；只 vX.Y.Z tag 才自动部署 |
| 备份脚本半夜失败没人知道 | 没告警 | cron 里加 `\|\| curl -X POST 企微 webhook` 失败告警 |
| 备份文件只在本机 | 服务器炸了备份也没了 | rclone / ossutil 同步到对象存储 |
| `mysqldump` 密码在 `ps` 里可见 | 走 argv | 改 `--defaults-extra-file` 或用 stdin `<<<` |
| AI 生成的 `deploy.sh` 无参数校验 | AI 图省事 | 加 `[[ $# -lt 2 ]] && usage` |
| AI 用 `docker compose up -d` 不带 `--remove-orphans` | 旧服务容器残留 | 加 `--remove-orphans` |

### 5.10 练习

1. **必做**：把 `deploy.sh` 放到自己服务器 `/opt/yoga/`，`chmod +x`，跑一次 `./deploy.sh v1.0.0 v1.0.0` 观察输出全部 OK；再改一行文案 `git tag v1.0.1 && git push --tags` 触发 CI 自动 CD，60 秒内看到线上更新；交 Actions 页面截图 + 浏览器截图。
2. **必做**：把 `yoga-mysql-backup.sh` 放到 `/etc/cron.daily/`，`chmod +x`，等次日凌晨看 `/opt/yoga/backup/` 出现 `yoga-YYYY-MM-DD.sql.gz`；交 `ls -la` 截图 + `zcat yoga-*.sql.gz | head -20` 截图确认数据完整。
3. **挑战**：给 `deploy.sh` 增加「部署前打日志到企业微信 / 钉钉群机器人 webhook」的功能——用 `curl -X POST` 发一条「发布 vX.Y.Z 开始 / 完成」消息，让整个团队都能感知上线动作。

---

## 第 6 讲：全栈课程回顾 + 5 个拓展项目建议

### 6.1 引入：从 `<h1>Hello</h1>` 到线上可访问的 Web 系统

17 天前，你只会写 `<h1>Hello</h1>`。今天，你已经**上线了一个能被真实用户使用的 Web 系统**——有登录、有 CRUD、有权限、有 HTTPS、有 CI/CD、有备份。

回头看看，你到底学了些什么？下一步该往哪走？

今天两个议题：**① 回望走过的路 / ② 展望前面的山**。

🎯 **一句话目标**：**用一张 mindmap 把 17 天 34 章 107 技术点串起来，再给出 5 个可以立刻上手的拓展项目建议**。今天没有新代码，是「整理知识」和「规划下一步」的一天——但可能是全课程**最值钱**的一天。

### 6.2 课程全景 mindmap（4 部分 34 章 107 技术点）

```mermaid
mindmap
  root((AI 应用 Web 开发))
    第一部分 基础 (Day01-Day04)
      HTML / CSS / JavaScript / jQuery
      Java 语法 + Maven
      Spring Boot + MyBatis + MySQL
      IDEA / Postman / AI 辅助编码
    第二部分 后端实战 (Day05-Day09)
      印想瑜伽会馆项目
      Git 协作 + 分模块
      CRUD + 分页 + 上传
      日志 + AOP + 全局异常
      Redis + Spring Cache
      JWT + 拦截器
      图形验证码
      多环境配置 (dev/test/prod)
    第三部分 前端实战 (Day10-Day14)
      Vue 3 + Vite + TypeScript
      Vue Router
      Axios 封装
      Pinia 状态管理
      Element Plus + ECharts
      登录 + 全部 CRUD 页面
      表单校验 + 权限按钮
    第四部分 部署 (Day15-Day17)
      Linux + SSH + systemd + Nginx
      Docker + Dockerfile
      docker compose
      Nginx 反代 + HTTPS
      CI / CD (GitHub Actions)
      版本回滚 + 备份
```

**关键数字**：**34 章 / 107 技术点 / 1 个真实项目**。这是你的技术资产地图，也是简历上第一个「我做过什么」的完整答案。

### 6.3 印想瑜伽会馆项目的技术选型理由

| 选型 | 为什么选它 | 为什么不选替代品 |
|---|---|---|
| **Spring Boot 4** | Java 生态最成熟、企业级市场份额第一、JDK 25 长期支持 | Node.js 单线程回调深、Go 生态更年轻、Python Django 性能天花板低 |
| **Vue 3 + TypeScript** | 中文文档、学习曲线平缓、Element Plus 组件库现成 | React 更主流但 JSX 心智负担高、Angular 太重、Svelte 生态不足 |
| **MySQL 8** | 最流行的开源关系数据库、云厂商托管选择多 | PostgreSQL 更强但学习曲线陡、SQLite 单机受限 |
| **Redis 8** | 缓存 + Session + 简单队列全能选手 | Memcached 只有缓存、KeyDB 生态薄 |
| **Docker + Compose** | 环境一致性 + 一键部署事实标准 | K8s 单机项目过度设计、裸金属 systemd 升级维护痛 |
| **GitHub Actions** | 免费额度大、生态成熟、与仓库无缝集成 | Jenkins 需自建、GitLab CI 需 GitLab 仓库、CircleCI 收费重 |

**给面试的一句话**：**技术选型没有对错，只有「在你的业务约束下，哪个更快达到 MVP」**。

### 6.4 5 个拓展项目建议（能放简历）

#### ① 读书笔记 AI 助手

- **业务**：录入读书笔记 → RAG 检索 → 用 AI 生成「这本书讲了什么」的摘要 + 长期回顾
- **栈**：Spring Boot + Vue + PostgreSQL + `pgvector` 向量插件 + OpenAI Embedding / 通义千问
- **难点**：
  - Embedding 存储与相似度查询（余弦距离）
  - Prompt 工程（Few-shot 示例 + 结构化输出）
  - 长文本切片（chunk size 500-1000 token，overlap 100）
- **杀手锏**：AI 时代的 killer app，简历一眼被看到

#### ② 健身打卡社区

- **业务**：用户打卡 + 好友互赞 + 排行榜 + AI 生成动作分析
- **栈**：Spring Boot + Vue + MySQL + Redis Sorted Set 排行 + WebSocket 实时通知
- **难点**：
  - 好友关系图查询（谁关注了谁）
  - 排行榜性能（Sorted Set 天然支持）
  - 实时推送（STOMP over WebSocket）
- **杀手锏**：把 Day09 的 Redis + Day13 的 WebSocket 综合到极致

#### ③ 二手书城

- **业务**：卖家发布 → 买家搜索 → 站内消息 → 微信支付
- **栈**：Spring Boot + Vue + MySQL + Elasticsearch 全文检索 + 微信支付 API
- **难点**：
  - ES 中文分词与相关性排序
  - 支付回调幂等（同一订单不能扣两次款）
  - 交易状态机（待付款 → 待发货 → 已完成 / 售后）
- **杀手锏**：涉及真金白银，能展示「工程严谨性」

#### ④ AI 智能日记

- **业务**：写日记 → AI 情感分析 + 关键词提取 + 长期回顾（「今年你最开心的一天」）
- **栈**：Spring Boot + Vue + MySQL + OpenAI / 本地开源 LLM（Ollama）
- **难点**：
  - LLM 调用编排（Function Calling 让 AI 主动查数据库）
  - 隐私加密（日记内容敏感，端到端加密或字段级 AES）
  - Function Calling 规范
- **杀手锏**：情感 + 隐私两大用户痛点，故事性强

#### ⑤ 团队协作 Kanban（Trello Lite）

- **业务**：多人协作看板 + 拖拽卡片 + 实时同步 + 权限
- **栈**：Spring Boot + Vue + MySQL + Redis + Socket.IO / STOMP + JWT + RBAC
- **难点**：
  - CRDT / OT 并发编辑算法
  - 多人实时同步（低延迟 + 断线重连）
  - RBAC 权限模型（角色 - 资源 - 操作三元组）
- **杀手锏**：Trello / Notion / Jira 都属这个赛道，能对标商业产品

### 6.5 后续学习方向（6 大分支）

| 方向 | 关键词 | 推荐入口 |
|---|---|---|
| **深入 Spring** | Spring Security / Spring Cloud / Spring Batch / Reactive | 官方 Guides |
| **深入前端** | TypeScript 进阶 / Nuxt SSR / Vitest / Playwright / 微前端 | Vue 官方生态 |
| **数据库** | SQL 调优 / MySQL 主从 / Redis 集群 / Elasticsearch | 《高性能 MySQL》 |
| **架构** | DDD / CQRS / 事件驱动 / Kafka / RabbitMQ | 《领域驱动设计》Eric Evans |
| **云原生** | Kubernetes / Helm / Istio / Serverless | KodeKloud / CNCF 官方文档 |
| **AI 融合** | RAG / Embedding / Function Calling / Agent | LangChain / LlamaIndex 文档 |

**学习方法**：**找一个自己感兴趣的真实业务（读书笔记、健身打卡、二手书城…），用课程学到的栈从零上线，再逐步引入更复杂的技术点。用得上才是真的学会**。

### 6.6 「用 AI 干活」的正确姿势

AI 是**放大器**——快速产出代码骨架、写文档、排错误，但**品位与判断在你**。

**三个 AI 反模式**（血泪总结）：

| 反模式 | 后果 | 正确姿势 |
|---|---|---|
| 复制 AI 代码不 review | 埋雷：SQL 注入、密钥泄露、幂等丢失 | AI 写完先自己读一遍，把每一行说给自己听 |
| 让 AI 做架构决策 | AI 不懂你的业务约束，选出「大而全」的方案 | 架构你决定，AI 只写落地代码 |
| 让 AI 直接接触生产密钥 | 一次泄露永久风险 | 密钥永远在 Secret / KMS 里，AI 环境永远拿不到 |

**结语**：**AI 时代的开发者，最稀缺的不是写代码的手，而是提出好问题的脑**。

### 6.7 常见坑（课程全局）

| 现象 | 教训 |
|---|---|
| 学完就忘 | 每周至少写一次代码；只看视频不动手 = 没学 |
| 追新技术追不停 | 用得上才学；主线业务 + 冷门技术永远选主线 |
| 完美主义拖延上线 | V0.1 能跑就发；用户反馈比自己臆测有价值 100 倍 |
| 面试只背八股 | 有一个上线的作品 > 背 100 篇八股文 |
| 遇到问题只问 AI 不看源码 | AI 会瞎编；关键路径务必看官方文档和源码 |
| 独自摸索 | 找个学习伙伴 / 加社群 / 参加 Meetup，进步会快很多 |

### 6.8 练习

1. **必做**：在自己的 GitHub 建一个新仓库，写 `README.md` 起草下一个个人项目：题材 + 用户画像 + 技术栈 + 3 个里程碑（V0.1 能跑通 / V0.5 能给别人用 / V1.0 上线）；提交后把仓库链接贴到本课程作业区。
2. **必做**：把印想瑜伽项目部署到自己的**真实域名**上（可以用免费的 Vercel / Netlify 前端 + 阿里云轻量 backend），拿到一个公开可访问的 URL，作为**第一版简历作品**。
3. **挑战**：从 5 个拓展项目里选一个，用 AI 辅助（通义灵码 / Cursor / Claude Code）花一个周末做出 V0.1——至少能登录 + 完成一个核心业务操作。做完后写一篇 500 字博客总结「AI 帮我做对了什么、做错了什么」，发到掘金 / 知乎 / 个人博客。

---

## Day17 结课语

> 你从一个 HTML 页面出发，用 17 天搭起一整套「前端 + 后端 + 数据库 + 部署 + CI/CD」的现代 Web 应用。
> 更重要的是，你在整个过程中学会了**如何与 AI 协作**：让它写代码、写文档、写脚本、排查错误。
> AI 是放大器——它放大你的效率，也放大你的品位与判断。
> 保持好奇，动手写、动手改、动手上线，你会走得比想象中更远。
>
> **加油，未来的 AI 时代开发者。**

---
