# 《AI 应用 Web 开发》 - 学生讲义（Day07：统一日志处理与全局异常 + 教练管理与教室管理）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day06 的学生（掌握 Spring Boot 4.0、MyBatis 3.5+、DTO/VO 分层、Bean Validation、Result 雏形、日志与配置基础）**

**技术版本基线**：Spring Boot 4.0 / Java 25 / Vue 3.5+ / pnpm 9 / MyBatis 3.5+ / MySQL 8.0 / Redis 8.x / Docker 24+ / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day01–Day06 已经把会员模块的注册、登录、CRUD、分页、Bean Validation 全部打通。可是接口上线三天，就冒出四条噪音：（1）前端 axios 拦截器区分不出「校验失败 / 业务失败 / 系统崩溃」；（2）Service 层到处 `try-catch` + `log.error`，日志重复十几遍；（3）线上 Whitelabel 错误页把 SQL 表结构泄给了浏览器；（4）业务对手方（Day08 要接课程模块）催得急，教练、教室两张主数据表还没建。Day07 就把这四件事一次收拾干净——前 3 讲把「异常 + 日志」的统一底座打好，后 3 讲用同一份 AI 提示词把教练、教室两个「结构对称」的模块批量长出来，同时把 Day05 学到的双重唯一校验、软删除唯一键联合 `deleted` 这些团队约定复习一遍。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 统一响应结构 `Result` + 业务异常 `BizException` | `Result<T>` / `BizException` 源码 + 错误码分区约定 |
| 第 2 讲 | 全局异常处理器 + 404 统一 | `GlobalExceptionHandler` 六大分支 + Whitelabel 关闭 |
| 第 3 讲 | Logback 生产配置 + 打印规范 + AI 生成异常骨架 | `logback-spring.xml` + 敏感字段脱敏工具 |
| 第 4 讲 | 教练模块 `tb_coach` + DTO 分层 + 双重唯一校验 | `CoachAddDTO/UpdateDTO/QueryDTO` + `CoachService` 校验骨架 |
| 第 5 讲 | 教练 Mapper 关键 SQL + Controller 完整实现 | `CoachMapper.xml` + `CoachController` 六端点 |
| 第 6 讲 | 教室模块 `tb_room` + AI 一次生成两模块 + 联调 | `RoomController` + 双模块批量生成提示词 |

---

## 第 1 讲：统一响应结构 Result 与业务异常 BizException

### 1.1 引入：为什么前端同学在吐槽？

Day06 结束时，会员注册接口已经跑通。可是本周站会前端同学甩来一段截图：

```text
> 你这个 /api/members POST：
> - 成功时给我 200 + {code:0, msg:"OK", data:{...}}
> - 校验失败给我 200 + {code:400, msg:"phone 格式不正确"}
> - 手机号重复给我 500 + 一坨 Spring 堆栈
> - URL 拼错给我 200 + Whitelabel HTML
> 我的 axios 拦截器根本不好写，是走 then 分支还是 catch 分支？
```

🎯 **一句话痛点**：**同一个接口，前端从「HTTP 状态码 + 响应体结构」两条线拿不到一致的错误信号，就没法写通用错误提示。**

统一响应 + 全局异常这套组合拳，就是要让前端**任何时候都拿到同一份 `Result<T>` 结构**，`code` 表业务成功与否，`msg` 表用户可见提示，`data` 表业务负载。HTTP 状态码只区分「连没连上、路由对不对」，业务层面成败**只看响应体里的 `code`**。

### 1.2 「不统一」的三条现实后果

划重点：不统一并不是「代码不好看」这么轻。它有三条真实伤害：

1. **前端拦截器变成 `if / else if / else if` 树**——每个后端接口一种响应，前端要一个个特判，页面报错文案永远不一致。
2. **后端日志爆炸**——每个 Service 方法都 `catch + log.error`，一次业务失败在日志里出现 4 遍（Controller、Service、Mapper、GlobalHandler 各一遍）。
3. **敏感信息裸奔**——Whitelabel 页会把类似 `NullPointerException: Cannot invoke "MemberMapper.selectById"` 这种带包名、带 SQL 表结构的堆栈直接吐给浏览器，等于免费给攻击者画了张系统蓝图。

💡 **口诀**：**响应结构统一 + 日志只在最外层打栈 + 系统异常永远只给用户看「稍后再试」**。这三条是全套体系的地基。

### 1.3 核心概念：Result<T> 是什么

`Result<T>` 是一个泛型信封，把「业务是否成功」「给人看的话」「给程序看的数据」三件事塞在同一个 JSON 里。

```json
{
  "code": 0,
  "msg": "OK",
  "data": { "id": 12, "name": "张小雅" },
  "timestamp": 1721030400000
}
```

字段含义：

| 字段 | 类型 | 含义 |
|---|---|---|
| `code` | `Integer` | `0` 表业务成功；非 `0` 表业务失败，分区见 1.5 |
| `msg` | `String` | 用户可见的提示；成功固定 `"OK"`，失败给可读原因 |
| `data` | `T` | 业务负载；失败时为 `null` |
| `timestamp` | `Long` | 服务器毫秒时间戳，前端排错时用 |

⚠️ **特别注意**：`code` 不要和 HTTP 状态码混。HTTP 层始终 `200`（除非真的是 4xx/5xx 网关级错误），`Result.code` 才是业务信号。这样 axios 拦截器写起来只需要一句 `if (res.data.code !== 0) toast(res.data.msg)`。

### 1.4 Result<T> 源码

放到 `com.yinxiang.common.Result`：

```java
package com.yinxiang.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一响应信封。
 * <p>约定：HTTP 层永远返回 200；业务层面成败只看 code 字段。
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Result<T> {

    /** 0 表业务成功；非 0 表业务失败，分区见 ResultCode。 */
    private Integer code;

    /** 用户可见提示；成功固定 "OK"。 */
    private String msg;

    /** 业务负载；失败时为 null。 */
    private T data;

    /** 服务器毫秒时间戳。 */
    private Long timestamp;

    // ---------------- 静态工厂 ----------------

    public static <T> Result<T> ok() {
        return new Result<>(0, "OK", null, System.currentTimeMillis());
    }

    public static <T> Result<T> ok(T data) {
        return new Result<>(0, "OK", data, System.currentTimeMillis());
    }

    public static <T> Result<T> ok(String msg, T data) {
        return new Result<>(0, msg, data, System.currentTimeMillis());
    }

    public static <T> Result<T> fail(int code, String msg) {
        return new Result<>(code, msg, null, System.currentTimeMillis());
    }

    public static <T> Result<T> fail(String msg) {
        return fail(500, msg);
    }
}
```

🎯 **三个静态工厂的分工**：

- `ok()` —— 无返回值的写操作（新增、修改、删除的成功回执）；
- `ok(T)` —— 有返回值的读操作（查询详情、分页结果）；
- `ok(msg, T)` —— 需要自定义提示语（如「已发送，5 分钟内有效」）；
- `fail(code, msg)` —— 全局异常处理器使用；
- `fail(msg)` —— 快捷方式，默认 code 为 500。

### 1.5 错误码分区约定

`code` 是一个 `Integer`，不做严格枚举，但按**区段**统一约定，方便前端拦截器分级处理：

| 区段 | 含义 | 示例 |
|---|---|---|
| `0` | 成功 | `Result.ok(data)` |
| `400 - 499` | 客户端错误（参数、认证、权限） | 400 参数校验；401 未登录；403 无权限 |
| `500 - 599` | 服务端错误（不该发生但发生了） | 500 兜底；503 依赖服务不可用 |
| `10000 - 19999` | 业务错误，可按模块细分 | 11xxx 会员；12xxx 教练；13xxx 教室；14xxx 课程 |

💡 **口诀**：**HTTP 状态码看层次，Result.code 看业务**。前端只需要 `>= 10000` 走「toast + 停在当前页」，`400-499` 走「表单红字」，`500-599` 走「兜底弹窗」，三级即可覆盖所有场景。

### 1.6 业务异常 BizException：什么时候该抛，什么时候不该抛

`BizException` 是**业务预期内**的异常——预料得到、有明确用户话术、需要中断当前流程但不该在日志里留栈。

**该抛**的场景：

| 场景 | 抛法示例 |
|---|---|
| 手机号已被注册 | `throw new BizException(11001, "手机号已被注册")` |
| 教练工号重复 | `throw new BizException(12001, "工号已存在")` |
| 教练不存在或已离职 | `throw new BizException(12404, "教练不存在或已离职")` |
| 课程已满员 | `throw new BizException(14002, "课程已满员")` |
| 余额不足 | `throw new BizException(11005, "余额不足")` |

**不该抛**的场景（交给对应的处理器，不要自己吞）：

| 场景 | 交给谁 |
|---|---|
| 字段格式错、`@NotBlank` 失败 | Bean Validation → `MethodArgumentNotValidException` |
| 数据库唯一键冲突 | JDBC → `DuplicateKeyException` |
| 数据库外键冲突 | JDBC → `DataIntegrityViolationException` |
| 空指针、数组越界 | JVM → 最外层 `Throwable` 兜底 |
| URL 拼错 | Spring MVC → `NoHandlerFoundException` |

⚠️ **特别注意**：**不要用 `BizException` 去包装校验错误**。校验框架已经能给出「字段级 + 消息级」的完整定位，你自己拼一个 `"phone 格式不正确"` 反而丢掉了 Spring 提供的 `BindingResult`。

### 1.7 BizException 源码

放到 `com.yinxiang.common.exception.BizException`：

```java
package com.yinxiang.common.exception;

import lombok.Getter;

/**
 * 业务异常：可预期、给用户看的错误。
 * <p>抛出后由 GlobalExceptionHandler 转成 Result.fail(code, msg)，不打完整栈。
 */
@Getter
public class BizException extends RuntimeException {

    /** 业务错误码，配合 Result.code 使用。 */
    private final int code;

    public BizException(String msg) {
        super(msg);
        this.code = 500;
    }

    public BizException(int code, String msg) {
        super(msg);
        this.code = code;
    }

    /** 允许携带原因链（如包装第三方异常）。 */
    public BizException(int code, String msg, Throwable cause) {
        super(msg, cause);
        this.code = code;
    }
}
```

设计要点：

1. **继承 `RuntimeException`**——不强制方法签名 `throws`，Service 层随处可抛；
2. **`code` 是 `final int`**——一次赋值不再改，避免中途被误改；
3. **只带 `code + msg`**，不带栈信息——业务异常在日志里只打一行 `warn`，栈完全没必要。

### 1.8 Service 层使用示例

以会员注册为例，看看 `BizException` 在实战里的位置：

```java
package com.yinxiang.service;

import com.yinxiang.common.exception.BizException;
import com.yinxiang.mapper.MemberMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MemberService {

    private final MemberMapper mapper;

    public Long register(MemberAddDTO dto) {
        // 1. 业务预查：手机号是否已注册
        if (mapper.existsByPhone(dto.getPhone(), null) > 0) {
            throw new BizException(11001, "手机号已被注册");
        }

        // 2. 组装实体并落库
        Member entity = new Member();
        BeanUtils.copyProperties(dto, entity);
        mapper.insert(entity);

        log.info("[会员注册] id={} phone={}", entity.getId(), mask(dto.getPhone()));
        return entity.getId();
    }
}
```

🎯 **三条纪律**：

1. **`throw` 之前不要 `log.warn`**——GlobalExceptionHandler 会统一打一行；
2. **`throw` 之后不要 `return`**——RuntimeException 会中断方法执行；
3. **敏感字段进日志前先脱敏**——`mask(phone)` 见第 3 讲。

### 1.9 联调剧本（最小版）

第 1 讲 GlobalExceptionHandler 还没写完，本节只验证 `Result.ok` 走通。

curl 请求：

```bash
curl -X POST http://localhost:8080/api/members \
  -H "Content-Type: application/json" \
  -d '{"phone":"13800138001","name":"张小雅","password":"a1b2c3d4"}'
```

期望响应：

```json
{
  "code": 0,
  "msg": "OK",
  "data": 12,
  "timestamp": 1721030400000
}
```

再抛一次业务异常（此时还会 500，因为没有全局处理器）：

```bash
curl -X POST http://localhost:8080/api/members \
  -H "Content-Type: application/json" \
  -d '{"phone":"13800138001","name":"张小雅","password":"a1b2c3d4"}'
```

服务端会打印 `BizException: 手机号已被注册`，前端拿到的仍是 Spring 默认 500 JSON——**这正是第 2 讲要解决的**。

### 1.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `Result.data` 序列化后为 `null` 但前端要「不显示 null 字段」 | Jackson 全局配置 `spring.jackson.default-property-inclusion: non_null`；或者接受统一保留 |
| 抛了 `BizException` 前端仍看到 500 堆栈 | 全局异常处理器还没生效（见第 2 讲）或类没被 Spring 扫描到 |
| `code` 用了 `long` / `Long` 前端整数溢出 | 保持 `Integer`；纯数字 ID 需要 `String` 建议在响应体单独字段做 |
| `Result` 里塞 `Map<String, Object>` 当数据 | 前端 TypeScript 无法生成类型，务必用具体 `VO` 或明确泛型 |

### 1.11 练习 / 思考

1. **必做**：把 `Result` 复制到自己项目的 `common` 包下，写一个 `HealthController.ping()` 返回 `Result.ok("pong")`，curl 观察响应结构。
2. **必做**：在 `MemberService.register` 里加一个 `BizException(11001, "手机号已被注册")`，用同一个手机号连续 POST 两次，观察第二次响应体（此时还是 500 是正常的）。
3. **思考**：为什么 `BizException` 继承 `RuntimeException` 而不是 `Exception`？如果继承 `Exception` 会给 Service 层带来什么样的写法负担？
4. **挑战**：把 `code` 抽成 `ResultCode` 枚举（如 `MEMBER_PHONE_DUPLICATED(11001, "手机号已被注册")`），改造 `BizException` 支持 `throw new BizException(ResultCode.MEMBER_PHONE_DUPLICATED)`。

---

## 第 2 讲：全局异常处理器与 404 统一

### 2.1 引入：如果每个 Controller 都 try-catch……

上一讲结束时，`MemberService.register` 抛出的 `BizException` 到了 Controller 层没人接，最后被 Spring 转成 500 + 默认 JSON。如果按「谁抛谁接」的思路，Controller 就会写成这样：

```java
// ❌ 反面教材：Controller 层堆满 try-catch
@PostMapping
public Result<Long> register(@RequestBody @Valid MemberAddDTO dto) {
    try {
        return Result.ok(service.register(dto));
    } catch (BizException e) {
        log.warn("业务异常: {}", e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    } catch (DuplicateKeyException e) {
        log.warn("唯一冲突: {}", e.getMessage());
        return Result.fail(409, "数据已存在");
    } catch (Exception e) {
        log.error("系统异常", e);
        return Result.fail(500, "系统繁忙");
    }
}
```

⚠️ **特别注意**：这段代码有三个致命问题——**（1）每个方法都要抄一遍；（2）漏抄一个类型就漏一种异常；（3）Controller 层不再薄，变成了业务和处理器混杂的粘合层。**

Spring 提供了 `@RestControllerAdvice`——**一次注册，全局拦截**。所有 Controller 方法抛出的异常，都会被 Advice 里对应的 `@ExceptionHandler` 接住，Controller 恢复到极致清爽的状态。

### 2.2 核心概念：@RestControllerAdvice + @ExceptionHandler

**`@RestControllerAdvice`** = `@ControllerAdvice` + `@ResponseBody`。前者声明「这是一个跨 Controller 的增强类」，后者保证返回值走 Jackson 序列化成 JSON 而不是走视图解析。

**`@ExceptionHandler(某异常.class)`** 是 Advice 类里的方法注解——声明该方法负责处理这一类异常。Spring 会按「异常继承树最具体的匹配」派发。

### 2.3 处理器矩阵：6 种最常见的异常

在动手写代码前先画一张矩阵，避免边写边补：

| # | 异常类型 | 出现场景 | HTTP 层观感 | 返回 code | 日志级别 |
|---|---|---|---|---|---|
| 1 | `BizException` | Service 主动抛 | 业务失败 | `e.getCode()` | `warn` |
| 2 | `MethodArgumentNotValidException` | `@RequestBody @Valid` 校验失败 | 参数错 | `400` | `warn` |
| 3 | `ConstraintViolationException` | `@RequestParam @Min/@Max` 校验失败 | 参数错 | `400` | `warn` |
| 4 | `DuplicateKeyException` | 数据库唯一键冲突（并发下 Service 预查漏了） | 冲突 | `409` | `warn` |
| 5 | `DataIntegrityViolationException` | 外键冲突、字段过长、类型不匹配 | 数据错 | `400` | `warn` |
| 6 | `Throwable` | 兜底：空指针、连接超时、任何未预料 | 系统崩 | `500` | `error` + 完整栈 |

💡 **口诀**：**具体到抽象、业务到系统**。`Throwable` 永远放最后当兜底，前面每一个都是「更具体的」子集。

再补两条常用但独立列出的：

| # | 异常类型 | 出现场景 | 返回 code |
|---|---|---|---|
| 7 | `NoHandlerFoundException` | URL 拼错找不到路由 | `404` |
| 8 | `HttpRequestMethodNotSupportedException` | 请求方法不匹配（POST 打到 GET） | `405` |
| 9 | `MissingServletRequestParameterException` / `MethodArgumentTypeMismatchException` | 缺参数、类型转换失败 | `400` |

### 2.4 GlobalExceptionHandler 完整源码

放到 `com.yinxiang.common.exception.GlobalExceptionHandler`：

```java
package com.yinxiang.common.exception;

import com.yinxiang.common.Result;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.util.stream.Collectors;

/**
 * 全局异常处理器。
 * <p>「具体到抽象、业务到系统」：Throwable 永远放最后当兜底。
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 1. 业务异常 —— 只打一行 warn，绝不打栈
    @ExceptionHandler(BizException.class)
    public Result<Void> handleBiz(BizException e) {
        log.warn("[业务异常] code={} msg={}", e.getCode(), e.getMessage());
        return Result.fail(e.getCode(), e.getMessage());
    }

    // 2. @RequestBody + @Valid 校验失败
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(f -> f.getField() + ": " + f.getDefaultMessage())
                .collect(Collectors.joining("; "));
        log.warn("[参数校验失败] {}", msg);
        return Result.fail(400, msg);
    }

    // 3. @RequestParam / @PathVariable 上的 @Min/@Max/@Pattern 校验失败
    @ExceptionHandler(ConstraintViolationException.class)
    public Result<Void> handleConstraint(ConstraintViolationException e) {
        String msg = e.getConstraintViolations().stream()
                .map(v -> v.getPropertyPath() + " " + v.getMessage())
                .collect(Collectors.joining("; "));
        log.warn("[Query 校验失败] {}", msg);
        return Result.fail(400, msg);
    }

    // 4. 数据库唯一键冲突（业务预查漏掉的并发场景）
    @ExceptionHandler(DuplicateKeyException.class)
    public Result<Void> handleDup(DuplicateKeyException e) {
        log.warn("[唯一键冲突] {}", e.getMostSpecificCause().getMessage());
        return Result.fail(409, "数据已存在，请检查唯一字段");
    }

    // 5. 外键 / 字段类型 / 字段过长
    @ExceptionHandler(DataIntegrityViolationException.class)
    public Result<Void> handleIntegrity(DataIntegrityViolationException e) {
        log.warn("[数据完整性异常] {}", e.getMostSpecificCause().getMessage());
        return Result.fail(400, "数据不合法：字段过长、外键缺失或类型不匹配");
    }

    // 6. 缺参 / 参数类型不匹配
    @ExceptionHandler({
            MissingServletRequestParameterException.class,
            MethodArgumentTypeMismatchException.class
    })
    public Result<Void> handleBadRequest(Exception e) {
        return Result.fail(400, "请求参数错误：" + e.getMessage());
    }

    // 7. 请求方法不匹配（POST 打到 GET）
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Result<Void> handleMethod(HttpRequestMethodNotSupportedException e) {
        return Result.fail(405, "不支持的请求方法：" + e.getMethod());
    }

    // 8. 404 未匹配路由
    @ExceptionHandler(NoHandlerFoundException.class)
    public Result<Void> handle404(NoHandlerFoundException e) {
        return Result.fail(404, "接口不存在：" + e.getRequestURL());
    }

    // 9. 兜底 —— 只在这里打完整栈，只对外说「稍后再试」
    @ExceptionHandler(Throwable.class)
    public Result<Void> handleAll(Throwable e) {
        log.error("[系统异常] ", e);
        return Result.fail(500, "系统繁忙，请稍后再试");
    }
}
```

🎯 **关键三点**：

1. **顺序无所谓**——Spring 按类型继承树自动选最具体的分支，写代码时按业务→系统的思路排列，方便读代码；
2. **`Throwable` 分支是唯一打栈的地方**——其他分支只打一行 `warn`，让日志文件保持干净；
3. **对外提示与对内日志分离**——用户永远只看到「稍后再试」，运维通过 `log.error` 拿到完整栈。

### 2.5 关闭默认 Whitelabel 错误页

Spring Boot 默认情况下遇到未映射的 URL 会走 `BasicErrorController` 返回 `Whitelabel Error Page` 或一份 JSON，此时**根本不会抛 `NoHandlerFoundException`**——所以 2.4 里的第 8 号分支根本接不到。需要在 `application.yml` 里做两个调整：

```yaml
spring:
  mvc:
    throw-exception-if-no-handler-found: true   # 找不到路由时抛异常而不是走默认页
  web:
    resources:
      add-mappings: false                       # 关闭静态资源默认映射，才能真的抛出上面的异常

server:
  error:
    whitelabel:
      enabled: false                            # 关闭 whitelabel HTML 页
    include-message: never                      # 默认 error 响应不再暴露 msg 字段（防泄漏兜底）
    include-stacktrace: never                   # 默认 error 响应不再暴露 stacktrace
```

⚠️ **特别注意**：如果项目里确实有静态资源（如 `favicon.ico`），关闭 `add-mappings` 后需要在 `WebMvcConfigurer.addResourceHandlers` 里显式重新注册——本项目暂不涉及静态资源，可放心关闭。

### 2.6 联调剧本：五种异常一次跑通

先启动应用，然后依次跑五条 curl。**每一条都用同一个 `Result` 结构响应**，只是 `code / msg / data` 值不同。

（1）**404 未匹配路由**：

```bash
curl -i http://localhost:8080/api/no-such-endpoint
```

期望响应：

```json
{
  "code": 404,
  "msg": "接口不存在：/api/no-such-endpoint",
  "data": null,
  "timestamp": 1721030400000
}
```

（2）**校验失败（缺字段）**：

```bash
curl -X POST http://localhost:8080/api/members \
  -H "Content-Type: application/json" \
  -d '{"name":"张小雅"}'
```

期望响应：

```json
{
  "code": 400,
  "msg": "phone: 手机号不能为空; password: 密码不能为空",
  "data": null,
  "timestamp": 1721030400000
}
```

（3）**校验失败（格式错）**：

```bash
curl -X POST http://localhost:8080/api/members \
  -H "Content-Type: application/json" \
  -d '{"phone":"1381234","name":"张小雅","password":"a1b2c3d4"}'
```

期望响应：

```json
{
  "code": 400,
  "msg": "phone: 手机号格式不正确",
  "data": null,
  "timestamp": 1721030400000
}
```

（4）**业务异常（手机号已存在）**：

```bash
curl -X POST http://localhost:8080/api/members \
  -H "Content-Type: application/json" \
  -d '{"phone":"13800138001","name":"张小雅","password":"a1b2c3d4"}'
```

期望响应：

```json
{
  "code": 11001,
  "msg": "手机号已被注册",
  "data": null,
  "timestamp": 1721030400000
}
```

（5）**请求方法不匹配**：

```bash
curl -i -X DELETE http://localhost:8080/api/members
```

期望响应：

```json
{
  "code": 405,
  "msg": "不支持的请求方法：DELETE",
  "data": null,
  "timestamp": 1721030400000
}
```

🎯 **验收标准**：五条 curl HTTP 状态码都是 200（除非 `throw-exception-if-no-handler-found` 未生效导致 404 走了默认处理），响应体全是同一份 `Result` 结构。前端拦截器一句 `if (res.data.code !== 0) toast(res.data.msg)` 就能通用。

### 2.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 抛 `BizException` 前端仍看到 500 堆栈 | `GlobalExceptionHandler` 类没被扫描，检查包路径是否在 `@SpringBootApplication` 主类同级或下级 |
| `NoHandlerFoundException` 抓不到 | 没关闭 `spring.web.resources.add-mappings` 或 `throw-exception-if-no-handler-found: false` |
| `Throwable` 分支放在最前面 | 会「短路」掉下面所有 `@ExceptionHandler`；虽然 Spring 自己有优先匹配，但为可读性建议放最后 |
| `handleAll` 里再抛异常 | Advice 里再抛会导致响应体为空，返回 500 空 body；所有分支都要 `try` 兜底 |
| 异常 msg 里带 SQL / 表结构 | `DuplicateKeyException.getMessage()` 会含完整 SQL 语句，**不要直接返给前端**，要转成通用提示 |
| axios 拦截器仍走 catch 分支 | 检查后端 HTTP 状态码是否被中间件（如 Nginx）改写；业务错误 HTTP 层应保持 200 |

### 2.8 练习 / 思考

1. **必做**：把 2.4 完整源码复制到项目，按 2.6 剧本一次跑完五条 curl，截图五份响应体。
2. **必做**：故意在 `MemberService.register` 里写一句 `String x = null; x.length();`，触发 `NullPointerException`，观察响应体是否为 `{code:500, msg:"系统繁忙，请稍后再试"}`，同时日志里是否有完整栈。
3. **思考**：为什么要单独处理 `DuplicateKeyException`——Service 层不是已经预查过手机号了吗？（提示：并发场景）
4. **挑战**：新增一个 `@RestControllerAdvice(basePackages = "com.yinxiang.admin.controller")`，让管理后台的 500 兜底返回英文 `"Internal Server Error"`，前台仍返回中文。

---

## 第 3 讲：Logback 生产配置、打印规范与 AI 生成异常骨架

### 3.1 引入：上线一周日志占了 50G

Day06 项目上线之后，第三天运维在群里 @人：

```text
> yoga-member 的 /var/log 目录被日志撑满了：
> - app.log 单文件 47GB，vim 打不开
> - 里面 90% 是 org.mybatis.mapper DEBUG 输出的 SQL
> - 关键的 [业务异常] 只有 3 条，全被 SQL 淹了
```

🎯 **两条痛点**：（1）日志级别没分环境，DEBUG 上线跟着跑；（2）没有滚动策略，单文件无限膨胀，磁盘迟早写满。

本讲先用 `application.yml` 做「够用即可」的快速调优，再用 `logback-spring.xml` 做「生产级」的精细控制，最后落到打印规范和敏感字段脱敏。

### 3.2 application.yml 快速调优

**适用场景**：单模块小项目、开发/测试环境、还没上线的原型系统。

```yaml
logging:
  level:
    root: INFO                     # 全局默认 INFO
    com.yinxiang: DEBUG            # 项目自身包开 DEBUG（本地调试）
    org.springframework.web: INFO
    org.mybatis: DEBUG             # 打印 SQL；上线前调 INFO
  file:
    name: logs/yoga-member.log     # 相对启动路径
  pattern:
    console: "%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"
    file:    "%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"
  logback:
    rollingpolicy:
      max-file-size: 50MB          # 单文件上限
      max-history: 14              # 保留天数
      total-size-cap: 2GB          # 全部日志文件总量上限
```

💡 **口诀**：**根 INFO、自己 DEBUG、Mybatis 上线转 INFO、单文件 50MB、保留 14 天、总量 2GB**。这是 80% 项目的合理值。

⚠️ **特别注意**：`application.yml` 里的日志配置只覆盖 Spring Boot 内置的滚动策略；如果需要控制台/文件不同 pattern、单独 error 文件、`<springProfile>` 生效等，必须切到 `logback-spring.xml`。

### 3.3 logback-spring.xml：生产级三 appender

**适用场景**：多环境部署、需要按天+按大小双维度滚动、需要单独 error 文件、需要异步写盘。

放在 `src/main/resources/logback-spring.xml`（**文件名必须是 `logback-spring.xml`**，不能是 `logback.xml`，否则 `<springProfile>` 不生效）：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>

  <springProperty name="APP" source="spring.application.name" defaultValue="yoga-member"/>
  <springProperty name="LOG_HOME" source="logging.file.path" defaultValue="logs"/>

  <!-- ① 控制台 appender：本地开发看颜色 -->
  <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %highlight(%-5level) %cyan(%logger{36}) - %msg%n</pattern>
    </encoder>
  </appender>

  <!-- ② 文件 appender：按天 + 按大小双维度滚动，超过一天或达到 500MB 就切 -->
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>${LOG_HOME}/${APP}.log</file>
    <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
      <fileNamePattern>${LOG_HOME}/${APP}.%d{yyyy-MM-dd}.%i.log.gz</fileNamePattern>
      <maxFileSize>500MB</maxFileSize>
      <maxHistory>30</maxHistory>
      <totalSizeCap>20GB</totalSizeCap>
    </rollingPolicy>
    <encoder>
      <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>

  <!-- ③ 单独的 error 文件：运维配报警只盯它 -->
  <appender name="ERROR_FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>${LOG_HOME}/${APP}-error.log</file>
    <filter class="ch.qos.logback.classic.filter.ThresholdFilter">
      <level>ERROR</level>
    </filter>
    <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
      <fileNamePattern>${LOG_HOME}/${APP}-error.%d{yyyy-MM-dd}.log.gz</fileNamePattern>
      <maxHistory>90</maxHistory>
    </rollingPolicy>
    <encoder>
      <pattern>%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n%ex</pattern>
    </encoder>
  </appender>

  <!-- ④ 异步 appender：包装 FILE，减轻业务线程写盘阻塞 -->
  <appender name="ASYNC_FILE" class="ch.qos.logback.classic.AsyncAppender">
    <appender-ref ref="FILE"/>
    <queueSize>1024</queueSize>
    <discardingThreshold>0</discardingThreshold>      <!-- 0 表队列满时不丢 INFO 及以上 -->
    <neverBlock>false</neverBlock>                    <!-- 队列满时业务线程会阻塞，宁可慢也不丢 -->
    <includeCallerData>false</includeCallerData>
  </appender>

  <!-- 默认根：写控制台 + 异步文件 + error 独立文件 -->
  <root level="INFO">
    <appender-ref ref="CONSOLE"/>
    <appender-ref ref="ASYNC_FILE"/>
    <appender-ref ref="ERROR_FILE"/>
  </root>

  <!-- dev / prod profile 分级 -->
  <springProfile name="dev">
    <logger name="com.yinxiang" level="DEBUG"/>
    <logger name="org.mybatis" level="DEBUG"/>
  </springProfile>

  <springProfile name="prod">
    <logger name="com.yinxiang" level="INFO"/>
    <logger name="org.mybatis" level="INFO"/>
  </springProfile>

</configuration>
```

🎯 **四点配置解读**：

1. **`SizeAndTimeBasedRollingPolicy`**——按天生成一个基础文件名，同一天内超过 500MB 就切 `%i` 后缀（`.0.log.gz`、`.1.log.gz`）；
2. **`.gz` 后缀**——Logback 会自动压缩滚动出去的历史文件，通常能省 80% 空间；
3. **`ThresholdFilter ERROR`**——只有 ERROR 级别及以上才进 error 文件，运维报警脚本只需要 `tail -f *-error.log`；
4. **`AsyncAppender`**——把慢 IO 从业务线程剥离，`queueSize=1024` 意味着峰值可缓冲 1024 条；`discardingThreshold=0 + neverBlock=false` 组合表示「宁可业务线程等一等，也不丢 INFO 及以上」。

### 3.4 打印规范：五个级别的分工

划重点：**日志级别不是打给自己看的**，是给运维和监控系统看的。级别错了，报警要么爆炸要么静默。

| 级别 | 使用场景 | 正例 | 反例 |
|---|---|---|---|
| `TRACE` | 极细粒度，方法进出、循环内每次迭代 | `log.trace("循环第 {} 次", i)` | 生产禁用，只在本地临时排错 |
| `DEBUG` | 开发/联调阶段的关键路径 | `log.debug("SQL: {}", sql)` | 生产不要开，MyBatis 打印 SQL 也走 DEBUG |
| `INFO` | 关键业务节点、有价值的运营信息 | `log.info("[会员注册] id={} phone={}", id, mask(phone))` | 不要用来打「进入方法 / 离开方法」，会淹没 |
| `WARN` | 可预期的失败、业务异常 | `log.warn("[业务异常] code={} msg={}", code, msg)` | 不要用来打「参数缺失」这种应该走 400 校验的信息 |
| `ERROR` | 不该发生但发生了、需要运维介入 | `log.error("[系统异常] ", e)` 附完整栈 | 不要 `log.error("用户输入了非法字符")` —— 那是 WARN |

💡 **口诀**：**INFO 记录业务发生了什么、WARN 记录预期内失败、ERROR 只留给不该发生的**。运维报警脚本只盯 ERROR。

三条打印纪律：

1. **占位符 `{}` 而不是字符串拼接**——`log.info("id={}", id)` 比 `log.info("id=" + id)` 快，因为级别没到不会真触发拼接；
2. **不要在正常路径 `catch + log.error`**——让全局异常处理器在最外层打一次；
3. **敏感字段永远脱敏**——见下一节。

### 3.5 敏感字段脱敏工具

放到 `com.yinxiang.common.util.MaskUtil`：

```java
package com.yinxiang.common.util;

/** 敏感字段脱敏工具。 */
public final class MaskUtil {

    private MaskUtil() {}

    /** 手机号：138****5678 */
    public static String phone(String raw) {
        if (raw == null || raw.length() < 11) return raw;
        return raw.substring(0, 3) + "****" + raw.substring(7);
    }

    /** 身份证：110***********234 */
    public static String idCard(String raw) {
        if (raw == null || raw.length() < 8) return raw;
        return raw.substring(0, 3) + "***********" + raw.substring(raw.length() - 3);
    }

    /** 姓名：张*雅 / 王* / 欧阳** */
    public static String name(String raw) {
        if (raw == null || raw.isEmpty()) return raw;
        if (raw.length() == 1) return raw;
        if (raw.length() == 2) return raw.charAt(0) + "*";
        return raw.charAt(0) + "*".repeat(raw.length() - 2) + raw.charAt(raw.length() - 1);
    }

    /** 密码：永远返回 [MASKED]，不写到日志。 */
    public static String password() {
        return "[MASKED]";
    }
}
```

使用：

```java
log.info("[会员注册] id={} name={} phone={}",
         entity.getId(),
         MaskUtil.name(dto.getName()),
         MaskUtil.phone(dto.getPhone()));
```

⚠️ **特别注意**：**密码永远不进日志**——不是脱敏，是**完全不写**。哪怕临时排查也要用 `[MASKED]`，别偷懒。上线三年后你会庆幸自己养成了这个肌肉记忆。

### 3.6 请求日志切面预告（不写实现，只描述效果）

Day08 会用 `@Around` 切面在 Controller 层统一打入参出参耗时，效果类似：

```text
2026-07-18 14:22:31.412 INFO  [http-nio-8080-exec-3] c.y.log.LogAspect - [进入] POST /api/coaches ip=127.0.0.1 body={"name":"李教练","phone":"138****0010",...}
2026-07-18 14:22:31.548 INFO  [http-nio-8080-exec-3] c.y.log.LogAspect - [响应] POST /api/coaches cost=136ms {"code":0,"msg":"OK","data":12}
```

本讲只需要理解**目标形态**：每次请求两行日志，`[进入]` 打脱敏后的入参，`[响应]` 打耗时和响应体摘要。真正的实现（`@Around` + `ProceedingJoinPoint` + 敏感字段过滤）放到 Day08 讲切面时再展开。

### 3.7 用 AI 生成异常处理骨架

**提示词模板**（一次生成 `Result` + `BizException` + `GlobalExceptionHandler` 三件套）：

```text
我在做 Spring Boot 4.0 + Java 25 + MyBatis 3.5 + Bean Validation 3 的项目，包名 com.yinxiang。
请一次性生成三份代码：

（1）com.yinxiang.common.Result<T>：字段 code(Integer, 0 成功)、msg(String)、data(T)、timestamp(Long)；
    提供静态工厂 ok()、ok(T)、ok(String, T)、fail(int, String)、fail(String)。

（2）com.yinxiang.common.exception.BizException：继承 RuntimeException，字段 int code；
    提供 BizException(String)、BizException(int, String)、BizException(int, String, Throwable) 三个构造器。

（3）com.yinxiang.common.exception.GlobalExceptionHandler，@Slf4j @RestControllerAdvice，覆盖以下矩阵：
    - BizException                              → code=e.getCode(), 日志级别 warn
    - MethodArgumentNotValidException            → code=400, 拼接字段级错误
    - ConstraintViolationException               → code=400
    - DuplicateKeyException                      → code=409, 提示「数据已存在」不要泄露 SQL
    - DataIntegrityViolationException            → code=400
    - MissingServletRequestParameterException / MethodArgumentTypeMismatchException → code=400
    - HttpRequestMethodNotSupportedException     → code=405
    - NoHandlerFoundException                    → code=404
    - Throwable                                  → code=500, log.error 打完整栈, 对外只提示「系统繁忙」

规则约定：
- 所有分支返回 Result<Void>；
- 只有 Throwable 分支打完整栈，其他都只打一行 warn；
- 不允许在异常处理里再抛异常。
```

🎯 **收到 AI 输出后必做的四项校验**：

1. **`log.warn` 与 `log.error` 是否严格按矩阵分级**——错级别会让运维报警爆炸或静默；
2. **`Throwable` 分支是否是最后一个**——放中间会短路后面所有分支；
3. **异常 `msg` 是否会把 SQL / 表结构暴露给前端**——`DuplicateKeyException.getMessage()` 常带原始 SQL，要转通用提示；
4. **是否所有分支都返回 `Result` 而不是 `ResponseEntity`**——不然响应结构不一致，前端拦截器又要写特判。

### 3.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `<springProfile>` 不生效 | 文件名必须是 `logback-spring.xml`，`logback.xml` 是 Logback 原生文件，Boot 不会介入 |
| 日志时间戳没带时区 | 生产环境跨时区排查会看错时间；`pattern` 中加 `%d{yyyy-MM-dd HH:mm:ss.SSS,Asia/Shanghai}` |
| 异步 appender 队列满导致丢日志 | `discardingThreshold=0 + neverBlock=false` 保证不丢；如果性能敏感可调 `queueSize` 到 4096 |
| `log.info("id=" + id)` 拼接 | 即使级别不到也会拼字符串；改成 `log.info("id={}", id)` |
| 密码 / 身份证 / 银行卡直接进日志 | 事故级问题，Code Review 必须一票否决 |
| 单文件写到 100GB 才被发现 | `max-history` 和 `totalSizeCap` 一定要一起配，只配 `max-history` 不管尺寸 |

### 3.9 练习 / 思考

1. **必做**：把 3.3 的 `logback-spring.xml` 复制到项目，启动后观察 `logs/` 目录下有几个文件、每个文件的滚动阈值。
2. **必做**：写一个 `MaskUtilTest`，覆盖手机号、身份证、姓名脱敏各 3 组样例（含短字符串边界）。
3. **思考**：`AsyncAppender.queueSize=1024`，如果每秒进 5000 条 INFO 会发生什么？（提示：`neverBlock=false` 意味着队列满时业务线程会阻塞等待写盘）
4. **挑战**：用 3.7 的提示词让 AI 生成一份代码，然后按 3.7 的四项校验清单打分，写一段 100 字总结指出 AI 输出漏了什么。

---

## 第 4 讲：教练模块——tb_coach 表设计 + DTO 分层 + 双重唯一校验

### 4.1 引入：教练模块和会员模块的 CRUD 有什么本质区别？

Day04 学完会员模块的 CRUD，本讲马上开教练模块——常见反问：

```text
> 教练和会员不都是「一张主数据表 + 6 个接口」吗？为什么要单独开一讲？
```

🎯 **两个本质差别**：

1. **教练有两个唯一字段**：手机号 + 身份证号（会员一般只有手机号唯一）；
2. **教练的字段更「行业化」**：`hire_date`（入职日期）、`specialty`（专长）、`status`（在职/休假/离职），需要专门校验。

同时把教练模块和教室模块放到 Day07 后半天连续开发的原因是——**它们结构高度对称**，是训练「模板化思维 + AI 批量生成」的最好时机。第 4、5 讲把教练做扎实，第 6 讲让 AI 把教室模块「照抄一遍」。

### 4.2 核心概念：对称设计

看这张对比表就明白为什么它俩要放一起：

| 维度 | 教练模块 | 教室模块 |
|---|---|---|
| 表名 | `tb_coach` | `tb_room` |
| 唯一字段 | `phone` + `id_card`（双重） | `name`（单一） |
| 独有字段 | `hire_date`、`specialty`、`birth_date` | `capacity`、`location`、`equipment` JSON、`hourly_rate` |
| 状态枚举 | 1 在职 / 2 休假 / 3 离职 | 1 可用 / 2 维护中 / 3 停用 |
| 查询模糊 | 姓名 / 手机号 / 身份证 | 名称 / 位置 |
| 软删除 | `deleted` + 联合唯一键 | `deleted` + 联合唯一键 |
| 六大接口 | POST/PUT/DELETE/GET id/GET page/GET available | POST/PUT/DELETE/GET id/GET page/GET available |

💡 **口诀**：**结构对称、字段各异；DAO 模板可复用，Service 校验因业务而异**。

### 4.3 tb_coach 表 DDL

```sql
DROP TABLE IF EXISTS tb_coach;
CREATE TABLE tb_coach (
  id           BIGINT       PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
  name         VARCHAR(50)  NOT NULL      COMMENT '姓名',
  phone        VARCHAR(20)  NOT NULL      COMMENT '手机号',
  id_card      VARCHAR(20)  NOT NULL      COMMENT '身份证号',
  gender       TINYINT      DEFAULT 0     COMMENT '性别 0 未知 1 女 2 男',
  birth_date   DATE                       COMMENT '出生日期',
  hire_date    DATE         NOT NULL      COMMENT '入职日期',
  specialty    VARCHAR(255)               COMMENT '专长（多个用逗号分隔）',
  intro        TEXT                       COMMENT '简介',
  avatar       VARCHAR(255)               COMMENT '头像 URL',
  status       TINYINT      DEFAULT 1     COMMENT '状态 1 在职 2 休假 3 离职',
  deleted      TINYINT      DEFAULT 0     COMMENT '逻辑删除 0 未删 1 已删',
  create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_phone_deleted   (phone,   deleted),
  UNIQUE KEY uk_idcard_deleted  (id_card, deleted),
  KEY idx_status (status),
  KEY idx_hire_date (hire_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教练';
```

🎯 **四个设计要点**：

1. **`phone` / `id_card` 双唯一**——两个物理层面上都不能重复，DB 兜底并发；
2. **唯一键联合 `deleted`**——`(phone, deleted)`：软删除后同一个手机号可以重新入职（旧行 `deleted=1` 与新行 `deleted=0` 组合不冲突）；
3. **`status`、`hire_date` 建普通索引**——分页查询「在职教练按入职时间倒序」是最高频查询；
4. **`intro` 用 `TEXT`**——`VARCHAR(255)` 装不下老板娘写的教练小传。

### 4.4 三层 DTO：Add / Update / Query

Day05 已经学过 DTO 分层的意义——不同接口不同校验规则，用一个 DTO 打天下会出现「新增时 `id` 必须为空但更新时必须有」这种自相矛盾。教练模块的三层长这样：

**（1）CoachAddDTO** —— POST 用，所有必填字段都要有：

```java
package com.yinxiang.coach.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CoachAddDTO {

    @NotBlank(message = "姓名不能为空")
    @Size(max = 50, message = "姓名不能超过 50 字符")
    private String name;

    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    @NotBlank(message = "身份证号不能为空")
    @Pattern(regexp = "^\\d{17}[\\dXx]$", message = "身份证号格式不正确")
    private String idCard;

    @Min(value = 0, message = "性别值不合法")
    @Max(value = 2, message = "性别值不合法")
    private Integer gender;

    @Past(message = "出生日期必须早于今天")
    private LocalDate birthDate;

    @NotNull(message = "入职日期不能为空")
    private LocalDate hireDate;

    @Size(max = 255, message = "专长不能超过 255 字符")
    private String specialty;

    @Size(max = 2000, message = "简介不能超过 2000 字符")
    private String intro;

    @Size(max = 255)
    private String avatar;

    @Min(value = 1) @Max(value = 3)
    private Integer status;
}
```

**（2）CoachUpdateDTO** —— PUT 用，必须带 `id`：

```java
package com.yinxiang.coach.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CoachUpdateDTO {

    @NotNull(message = "id 不能为空")
    private Long id;

    @NotBlank(message = "姓名不能为空")
    @Size(max = 50)
    private String name;

    @NotBlank(message = "手机号不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;

    @NotBlank(message = "身份证号不能为空")
    @Pattern(regexp = "^\\d{17}[\\dXx]$", message = "身份证号格式不正确")
    private String idCard;

    @Min(0) @Max(2)          private Integer gender;
    @Past                    private LocalDate birthDate;
    @NotNull                 private LocalDate hireDate;
    @Size(max = 255)         private String specialty;
    @Size(max = 2000)        private String intro;
    @Size(max = 255)         private String avatar;
    @Min(1) @Max(3)          private Integer status;
}
```

**（3）CoachQueryDTO** —— GET 分页用，字段全部可空：

```java
package com.yinxiang.coach.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class CoachQueryDTO {

    /** 姓名 / 手机号 / 身份证号 三字段模糊匹配 */
    private String keyword;

    /** 状态 1 在职 2 休假 3 离职 */
    @Min(1) @Max(3)
    private Integer status;

    /** 分页 —— 页码从 1 开始 */
    @Min(value = 1, message = "页码从 1 开始")
    private Integer page = 1;

    @Min(value = 1)  @Max(value = 100)
    private Integer size = 10;

    /** 排序字段：hire_date | create_time */
    private String sortBy = "hire_date";

    /** 排序方向：asc | desc */
    private String sortDir = "desc";
}
```

⚠️ **特别注意**：查询 DTO 里的字段**不加 `@NotBlank`**——所有条件都应该是可选的，用户传什么就按什么筛。

### 4.5 Bean Validation 注解速查

第 4 讲用到的注解，做一张速查表：

| 注解 | 作用 | 常用示例 |
|---|---|---|
| `@NotBlank` | 字符串非空且去空格后长度 > 0 | `name` |
| `@NotNull` | 对象引用非 null（可为空串） | `hireDate` |
| `@NotEmpty` | 字符串/集合非空 | 少用，`@NotBlank` 更严 |
| `@Size(max=?)` | 字符串/集合长度上限 | `name` 50 |
| `@Pattern(regexp=?)` | 字符串正则匹配 | `phone` / `idCard` |
| `@Min` / `@Max` | 数值区间 | `gender` 0-2 |
| `@Past` | 日期早于今天 | `birthDate` |
| `@Future` | 日期晚于今天 | `expireDate` |
| `@Email` | 邮箱格式 | 会员邮箱 |
| `@Valid` | 触发嵌套对象校验 | Controller 参数上 |

正则速查：

```text
手机号：       ^1[3-9]\d{9}$
身份证 18 位：  ^\d{17}[\dXx]$
邮箱：         ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$
教练工号（备）：^C\d{3,6}$
```

⚠️ **特别注意**：`@Pattern` 一定要加 `^` 和 `$` 锚点，否则 `^1[3-9]\d{9}` 会匹配到 `138001380011` 的前 11 位——手机号平白多一位。

### 4.6 双重唯一性校验：为什么不能只靠 DB？

划重点：这是本讲最容易被 AI 生成骨架时**遗漏**的一个规矩。

**方案 A：只靠 DB 的 UNIQUE KEY**（错误示范）

```java
public void save(CoachAddDTO dto) {
    Coach c = new Coach();
    BeanUtils.copyProperties(dto, c);
    mapper.insert(c);   // 若手机号重复，抛 DuplicateKeyException
}
```

问题：

- 抛出来的是 `DuplicateKeyException`，消息是英文 SQL 异常，前端**无法区分**「到底是手机号冲突还是身份证冲突」；
- 全局异常处理器只能返回统一的「数据已存在」，用户看到之后完全不知道改哪里。

**方案 B：只靠 Service 层 SQL 预查**（并发漏洞）

```java
public void save(CoachAddDTO dto) {
    if (mapper.existsByPhone(dto.getPhone(), null) > 0)
        throw new BizException(12001, "手机号已被占用");
    // ... 中间可能被另一请求插队
    mapper.insert(c);
}
```

问题：两个请求同时进入 `existsByPhone`，都返回 0，都通过校验，然后都往数据库插入——**并发下两条同手机号的数据都进了库**。

**方案 C：双重校验（正确姿势）**

```java
public void save(CoachAddDTO dto) {
    // 1. Service 层预查 —— 提供友好的错误消息
    if (mapper.existsByPhone(dto.getPhone(), null) > 0)
        throw new BizException(12001, "手机号已被占用");
    if (mapper.existsByIdCard(dto.getIdCard(), null) > 0)
        throw new BizException(12002, "身份证号已被占用");

    // 2. DB 层 UNIQUE KEY 兜底 —— 拦截并发漏网之鱼
    Coach c = new Coach();
    BeanUtils.copyProperties(dto, c);
    mapper.insert(c);   // 万一并发插队，UNIQUE 抛 DuplicateKeyException, GlobalHandler 转 409
}
```

🎯 **口诀**：**Service 层预查给友好提示，DB 层 UNIQUE 兜底并发**。两条防线缺一不可。

### 4.7 Service 完整代码骨架

```java
package com.yinxiang.coach.service;

import com.yinxiang.coach.dto.CoachAddDTO;
import com.yinxiang.coach.dto.CoachUpdateDTO;
import com.yinxiang.coach.entity.Coach;
import com.yinxiang.coach.mapper.CoachMapper;
import com.yinxiang.common.exception.BizException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CoachService {

    private final CoachMapper mapper;

    @Transactional(rollbackFor = Exception.class)
    public Long add(CoachAddDTO dto) {
        // ① Service 预查 —— 双重唯一
        if (mapper.existsByPhone(dto.getPhone(), null) > 0)
            throw new BizException(12001, "手机号已被占用");
        if (mapper.existsByIdCard(dto.getIdCard(), null) > 0)
            throw new BizException(12002, "身份证号已被占用");

        // ② 组装实体
        Coach c = new Coach();
        BeanUtils.copyProperties(dto, c);
        if (c.getStatus() == null) c.setStatus(1);

        // ③ 落库 —— DB UNIQUE 兜底并发
        mapper.insert(c);
        log.info("[教练新增] id={} name={}", c.getId(), c.getName());
        return c.getId();
    }

    @Transactional(rollbackFor = Exception.class)
    public void update(CoachUpdateDTO dto) {
        // ① 存在性检查
        Coach exist = mapper.selectById(dto.getId());
        if (exist == null) throw new BizException(12404, "教练不存在或已离职");

        // ② 双重唯一（排除自身）
        if (mapper.existsByPhone(dto.getPhone(), dto.getId()) > 0)
            throw new BizException(12001, "手机号已被其它教练占用");
        if (mapper.existsByIdCard(dto.getIdCard(), dto.getId()) > 0)
            throw new BizException(12002, "身份证号已被其它教练占用");

        // ③ 组装 + 落库
        Coach c = new Coach();
        BeanUtils.copyProperties(dto, c);
        int rows = mapper.update(c);
        if (rows == 0) throw new BizException(12405, "教练已被删除");
        log.info("[教练更新] id={}", dto.getId());
    }

    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        int rows = mapper.logicDeleteById(id);
        if (rows == 0) throw new BizException(12404, "教练不存在或已删除");
        log.info("[教练删除] id={}", id);
    }

    public Coach getById(Long id) {
        Coach c = mapper.selectById(id);
        if (c == null) throw new BizException(12404, "教练不存在");
        return c;
    }
}
```

🎯 **五个 Service 层规矩**：

1. **`@Transactional(rollbackFor = Exception.class)`**——默认只回滚 `RuntimeException`，加 `Exception.class` 才对受检异常也生效；
2. **预查 → 组装 → 落库** 三段式，不要把 SQL 混在业务逻辑里；
3. **更新时先 `selectById` 存在性检查**——直接 `update` 拿不到「不存在」和「未变更」的区别；
4. **`existsByX(value, excludeId)`** 是双重校验的标准签名——更新时排除自身；
5. **日志用参数化 + 关键 ID**——不要打完整实体，实体带敏感字段。

### 4.8 联调剧本（Service 层单测视角）

第 5 讲写完 Controller 才能跑完整 curl，本节先用 IDEA 内置的 Test 或 `main` 方法验证 Service 逻辑：

```java
@SpringBootTest
class CoachServiceTest {

    @Autowired CoachService service;

    @Test
    void 正常新增() {
        CoachAddDTO dto = new CoachAddDTO();
        dto.setName("李教练");
        dto.setPhone("13800138010");
        dto.setIdCard("110101199001011234");
        dto.setHireDate(LocalDate.of(2024, 3, 1));
        Long id = service.add(dto);
        assertNotNull(id);
    }

    @Test
    void 手机号重复() {
        CoachAddDTO dto = new CoachAddDTO();
        dto.setName("王教练");
        dto.setPhone("13800138010");     // 与上例重复
        dto.setIdCard("110101199001019999");
        dto.setHireDate(LocalDate.of(2024, 3, 1));
        BizException ex = assertThrows(BizException.class, () -> service.add(dto));
        assertEquals(12001, ex.getCode());
    }
}
```

### 4.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 软删除后同手机号无法再入职 | 唯一键漏加 `deleted`，应该是 `UNIQUE KEY uk_phone_deleted (phone, deleted)` |
| 事务里 `catch DuplicateKeyException` 之后事务还是回滚 | Spring 事务遇到 `RuntimeException` 会标记回滚，`catch` 之后要么用 `Propagation.REQUIRES_NEW`，要么让它抛出去让全局处理器接 |
| `Pattern` 手机号未加锚点 | `^1[3-9]\d{9}` 少 `$`，会匹配到 `138001380011` 前缀 |
| 出生日期用 `Date` 而不是 `LocalDate` | `Date` 带时区，跨时区展示会差 8 小时；用 `LocalDate` 表纯日期 |
| `BeanUtils.copyProperties` 复制不过来 | 属性名不一致（如 `hire_date` vs `hireDate`）；Java 一侧用驼峰，MyBatis 侧用 `map-underscore-to-camel-case: true` |
| 更新时不传 `id` | `CoachUpdateDTO` 里 `@NotNull` 会挡下，返回 400 |

### 4.10 练习 / 思考

1. **必做**：把 4.3 的 DDL 跑到本地 MySQL 8.0，用 `SHOW CREATE TABLE tb_coach` 观察联合唯一键的实际 SQL 语句。
2. **必做**：写 `CoachAddDTO / UpdateDTO / QueryDTO` 三个类，在 IDEA 里用 `Ctrl+F12` 查看每个字段上都有哪些注解。
3. **思考**：为什么 `existsByPhone(phone, excludeId)` 需要第二个参数？如果没有 `excludeId`，更新自己的手机号会发生什么？
4. **挑战**：把 `@Past(birthDate)` 换成「年龄必须 18-65 岁之间」的自定义注解 `@AgeRange(min=18, max=65)`。

---

## 第 5 讲：教练 Mapper 关键 SQL 与 Controller 完整实现

### 5.1 引入：Controller 应该多薄？

Day04 讲过一个原则：**Controller 只做「拆包 + 分发 + 组装 Result」**。可到底多薄叫薄？看这个坏例子：

```java
// ❌ 反面教材
@PostMapping
public Result<Long> add(@RequestBody @Valid CoachAddDTO dto) {
    if (mapper.existsByPhone(dto.getPhone(), null) > 0)   // 业务规则跑到了 Controller
        return Result.fail(12001, "手机号已被占用");
    Coach c = new Coach();
    BeanUtils.copyProperties(dto, c);
    mapper.insert(c);                                     // Controller 直接调 Mapper
    return Result.ok(c.getId());
}
```

问题：（1）Service 层被绕过，业务规则散落在 Controller；（2）事务边界不明——`@Transactional` 加在 Controller 上会导致视图渲染阶段仍在事务里。

✅ **正确的 Controller 应该长这样**：

```java
@PostMapping
public Result<Long> add(@RequestBody @Valid CoachAddDTO dto) {
    return Result.ok(service.add(dto));
}
```

一行——拆包（`@RequestBody @Valid` 触发校验），分发（`service.add`），组装（`Result.ok`）。本讲就把教练模块的 Mapper SQL 和这个「薄 Controller」补齐。

### 5.2 CoachMapper.xml 完整 SQL

放到 `src/main/resources/mapper/CoachMapper.xml`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.yinxiang.coach.mapper.CoachMapper">

  <!-- 通用字段列 -->
  <sql id="cols">
    id, name, phone, id_card, gender, birth_date, hire_date,
    specialty, intro, avatar, status, create_time, update_time
  </sql>

  <!-- 新增 -->
  <insert id="insert" parameterType="com.yinxiang.coach.entity.Coach"
          useGeneratedKeys="true" keyProperty="id">
    INSERT INTO tb_coach (name, phone, id_card, gender, birth_date, hire_date,
                          specialty, intro, avatar, status)
    VALUES (#{name}, #{phone}, #{idCard}, #{gender}, #{birthDate}, #{hireDate},
            #{specialty}, #{intro}, #{avatar}, #{status})
  </insert>

  <!-- 更新（不动 deleted / create_time） -->
  <update id="update" parameterType="com.yinxiang.coach.entity.Coach">
    UPDATE tb_coach
    <set>
      <if test="name        != null">name        = #{name},</if>
      <if test="phone       != null">phone       = #{phone},</if>
      <if test="idCard      != null">id_card     = #{idCard},</if>
      <if test="gender      != null">gender      = #{gender},</if>
      <if test="birthDate   != null">birth_date  = #{birthDate},</if>
      <if test="hireDate    != null">hire_date   = #{hireDate},</if>
      <if test="specialty   != null">specialty   = #{specialty},</if>
      <if test="intro       != null">intro       = #{intro},</if>
      <if test="avatar      != null">avatar      = #{avatar},</if>
      <if test="status      != null">status      = #{status},</if>
    </set>
    WHERE id = #{id} AND deleted = 0
  </update>

  <!-- 逻辑删除 -->
  <update id="logicDeleteById">
    UPDATE tb_coach SET deleted = 1 WHERE id = #{id} AND deleted = 0
  </update>

  <!-- 详情 -->
  <select id="selectById" resultType="com.yinxiang.coach.entity.Coach">
    SELECT <include refid="cols"/>
    FROM tb_coach
    WHERE id = #{id} AND deleted = 0
  </select>

  <!-- 分页 —— 关键 SQL -->
  <select id="selectPage" resultType="com.yinxiang.coach.entity.Coach">
    SELECT <include refid="cols"/>
    FROM tb_coach
    <where>
      deleted = 0
      <if test="keyword != null and keyword != ''">
        AND (name    LIKE CONCAT('%', #{keyword}, '%')
          OR phone   LIKE CONCAT('%', #{keyword}, '%')
          OR id_card LIKE CONCAT('%', #{keyword}, '%'))
      </if>
      <if test="status != null">
        AND status = #{status}
      </if>
    </where>
    ORDER BY hire_date DESC, id DESC
  </select>

  <!-- 双重唯一：手机号已存在？(可排除某个 id) -->
  <select id="existsByPhone" resultType="int">
    SELECT COUNT(1) FROM tb_coach
    WHERE phone = #{phone} AND deleted = 0
    <if test="excludeId != null">AND id != #{excludeId}</if>
  </select>

  <!-- 双重唯一：身份证已存在？(可排除某个 id) -->
  <select id="existsByIdCard" resultType="int">
    SELECT COUNT(1) FROM tb_coach
    WHERE id_card = #{idCard} AND deleted = 0
    <if test="excludeId != null">AND id != #{excludeId}</if>
  </select>

  <!-- 可排课教练：在职 + 未删除 -->
  <select id="selectAvailable" resultType="com.yinxiang.coach.entity.Coach">
    SELECT id, name, phone, specialty
    FROM tb_coach
    WHERE deleted = 0 AND status = 1
    ORDER BY hire_date DESC
  </select>

</mapper>
```

对应的 Java 接口 `CoachMapper.java`：

```java
package com.yinxiang.coach.mapper;

import com.yinxiang.coach.dto.CoachQueryDTO;
import com.yinxiang.coach.entity.Coach;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CoachMapper {

    int insert(Coach c);
    int update(Coach c);
    int logicDeleteById(@Param("id") Long id);

    Coach selectById(@Param("id") Long id);
    List<Coach> selectPage(CoachQueryDTO q);
    List<Coach> selectAvailable();

    int existsByPhone (@Param("phone")  String phone,  @Param("excludeId") Long excludeId);
    int existsByIdCard(@Param("idCard") String idCard, @Param("excludeId") Long excludeId);
}
```

### 5.3 MyBatis `<if>` 里的空串陷阱

划重点：这是新人 90% 都会踩的坑。

前端传 `keyword=""` 到后端，MyBatis 里 `<if test="keyword != null">` **会通过**，因为 `""` 不是 `null`。结果 SQL 拼出来变成：

```sql
WHERE deleted = 0 AND (name LIKE CONCAT('%', '', '%') OR ...)
```

`LIKE '%%'` 等价于「任何非空字符串都匹配」，看起来「像」是正常查询，其实用户的意图是「不筛」。**正确判断要同时排除 `null` 和空串**：

```xml
<if test="keyword != null and keyword != ''">
```

⚠️ **特别注意**：MyBatis 的 OGNL 表达式里字符串比较用 `!=`（引号里可以直接写 `''`），不是 Java 语法的 `!keyword.isEmpty()`。

同类陷阱：`<if test="status != null">` 是正确的（`Integer` 只需判 `null`），但如果字段是 `String`，务必两个条件都写。

### 5.4 CoachController 六大端点

放到 `com.yinxiang.coach.controller.CoachController`：

```java
package com.yinxiang.coach.controller;

import com.yinxiang.coach.dto.CoachAddDTO;
import com.yinxiang.coach.dto.CoachQueryDTO;
import com.yinxiang.coach.dto.CoachUpdateDTO;
import com.yinxiang.coach.entity.Coach;
import com.yinxiang.coach.service.CoachService;
import com.yinxiang.common.Result;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coaches")
@RequiredArgsConstructor
@Validated
public class CoachController {

    private final CoachService service;

    /** 新增：POST /api/coaches */
    @PostMapping
    public Result<Long> add(@RequestBody @Valid CoachAddDTO dto) {
        return Result.ok(service.add(dto));
    }

    /** 修改：PUT /api/coaches/{id} */
    @PutMapping("/{id}")
    public Result<Void> update(@PathVariable Long id,
                               @RequestBody @Valid CoachUpdateDTO dto) {
        dto.setId(id);          // 以 path 为准，避免前端 body 与 URL 不一致
        service.update(dto);
        return Result.ok();
    }

    /** 逻辑删除：DELETE /api/coaches/{id} */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return Result.ok();
    }

    /** 详情：GET /api/coaches/{id} */
    @GetMapping("/{id}")
    public Result<Coach> get(@PathVariable Long id) {
        return Result.ok(service.getById(id));
    }

    /** 分页列表：GET /api/coaches?page=1&size=10&keyword=x&status=1 */
    @GetMapping
    public Result<PageInfo<Coach>> page(@Valid CoachQueryDTO q) {
        PageHelper.startPage(q.getPage(), q.getSize());
        List<Coach> list = service.list(q);
        return Result.ok(new PageInfo<>(list));
    }

    /** 可排课教练：GET /api/coaches/available */
    @GetMapping("/available")
    public Result<List<Coach>> available() {
        return Result.ok(service.listAvailable());
    }
}
```

对应的 Service 补两个方法：

```java
public List<Coach> list(CoachQueryDTO q) {
    return mapper.selectPage(q);
}

public List<Coach> listAvailable() {
    return mapper.selectAvailable();
}
```

🎯 **六个端点的语义速查**：

| 方法 | 路径 | 语义 | 返回 |
|---|---|---|---|
| `POST` | `/api/coaches` | 新增一条 | `Result<Long>` 新 id |
| `PUT` | `/api/coaches/{id}` | 全量更新 | `Result<Void>` |
| `DELETE` | `/api/coaches/{id}` | 逻辑删除 | `Result<Void>` |
| `GET` | `/api/coaches/{id}` | 详情 | `Result<Coach>` |
| `GET` | `/api/coaches` | 分页列表 | `Result<PageInfo<Coach>>` |
| `GET` | `/api/coaches/available` | 可排课的教练下拉 | `Result<List<Coach>>` |

### 5.5 @Valid 与 @Validated 的区别与选用

新人经常混：一个类上 `@Validated`，方法参数上 `@Valid`，到底啥关系？

| 注解 | 提供方 | 作用位置 | 触发范围 |
|---|---|---|---|
| `@Valid` | JSR 380 (`jakarta.validation`) | 参数 / 字段 | 触发单个对象或嵌套对象的校验 |
| `@Validated` | Spring (`org.springframework.validation.annotation`) | 类 / 方法 / 参数 | 触发**方法级校验**（`@RequestParam` / `@PathVariable` 上的 `@Min` 等），也支持**分组校验** |

**用法组合**：

- **`@RequestBody + @Valid`**：触发 DTO 内部字段校验（`@NotBlank`、`@Pattern` 等）；
- **类上加 `@Validated`**：触发 Controller 方法参数上的 `@Min` / `@Max` / `@Pattern`；
- **`@Valid` 支持嵌套校验**（DTO 里再嵌一个 `@Valid` 字段）；`@Validated` 不支持嵌套。

💡 **口诀**：**DTO 用 `@Valid`，Query/Path 用类级 `@Validated`**。两者一起用不冲突。

失败后抛的异常不同：

- `@Valid` 校验失败 → `MethodArgumentNotValidException`；
- `@Validated` 方法级校验失败 → `ConstraintViolationException`。

第 2 讲 GlobalExceptionHandler 分别处理了两种。

### 5.6 联调剧本：curl 完整跑一遍教练模块

先造种子数据：

```sql
INSERT INTO tb_coach (name, phone, id_card, gender, hire_date, specialty, status)
VALUES ('李教练', '13800138010', '110101199001011234', 1, '2024-03-01', '哈他,阴瑜伽', 1),
       ('王教练', '13800138011', '110101199202029876', 2, '2024-06-15', '流瑜伽',    1),
       ('张教练', '13800138012', '110101199508084321', 1, '2025-01-10', '孕产瑜伽',  2);
```

（1）**新增成功**：

```bash
curl -X POST http://localhost:8080/api/coaches \
  -H "Content-Type: application/json" \
  -d '{
    "name":"赵教练",
    "phone":"13800138020",
    "idCard":"110101199912123333",
    "gender":1,
    "birthDate":"1999-12-12",
    "hireDate":"2026-01-05",
    "specialty":"哈他,冥想"
  }'
```

响应：

```json
{"code":0,"msg":"OK","data":4,"timestamp":1721030400000}
```

（2）**手机号重复**：

```bash
curl -X POST http://localhost:8080/api/coaches \
  -H "Content-Type: application/json" \
  -d '{
    "name":"孙教练",
    "phone":"13800138010",
    "idCard":"110101199811115555",
    "hireDate":"2026-02-01"
  }'
```

响应：

```json
{"code":12001,"msg":"手机号已被占用","data":null,"timestamp":1721030400000}
```

（3）**身份证重复**：

```bash
curl -X POST http://localhost:8080/api/coaches \
  -H "Content-Type: application/json" \
  -d '{
    "name":"周教练",
    "phone":"13800138021",
    "idCard":"110101199001011234",
    "hireDate":"2026-02-01"
  }'
```

响应：

```json
{"code":12002,"msg":"身份证号已被占用","data":null,"timestamp":1721030400000}
```

（4）**字段格式错**：

```bash
curl -X POST http://localhost:8080/api/coaches \
  -H "Content-Type: application/json" \
  -d '{"name":"钱教练","phone":"1381234","idCard":"110101","hireDate":"2026-02-01"}'
```

响应：

```json
{"code":400,"msg":"phone: 手机号格式不正确; idCard: 身份证号格式不正确","data":null,"timestamp":1721030400000}
```

（5）**分页 + 关键字模糊**：

```bash
curl "http://localhost:8080/api/coaches?page=1&size=2&keyword=李"
```

响应结构（截取要点）：

```json
{
  "code": 0,
  "msg": "OK",
  "data": {
    "pageNum": 1,
    "pageSize": 2,
    "total": 1,
    "pages": 1,
    "list": [
      { "id": 1, "name": "李教练", "phone": "13800138010", "status": 1 }
    ]
  }
}
```

（6）**修改**：

```bash
curl -X PUT http://localhost:8080/api/coaches/1 \
  -H "Content-Type: application/json" \
  -d '{
    "name":"李教练",
    "phone":"13800138099",
    "idCard":"110101199001011234",
    "hireDate":"2024-03-01",
    "status":1
  }'
```

响应：

```json
{"code":0,"msg":"OK","data":null,"timestamp":1721030400000}
```

（7）**逻辑删除**：

```bash
curl -X DELETE http://localhost:8080/api/coaches/3
```

响应：

```json
{"code":0,"msg":"OK","data":null,"timestamp":1721030400000}
```

（8）**可排课教练下拉**：

```bash
curl http://localhost:8080/api/coaches/available
```

响应：

```json
{
  "code": 0,
  "msg": "OK",
  "data": [
    { "id": 1, "name": "李教练", "phone": "13800138099", "specialty": "哈他,阴瑜伽" },
    { "id": 2, "name": "王教练", "phone": "13800138011", "specialty": "流瑜伽" },
    { "id": 4, "name": "赵教练", "phone": "13800138020", "specialty": "哈他,冥想" }
  ]
}
```

（张教练已休假 `status=2`，不在可排课列表；被删除的教练更不会出现。）

### 5.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `PUT /api/coaches/1` 的 body 里 `id=99`，最终改到了 99 号 | Controller 里必须 `dto.setId(id)` 以 URL 为准 |
| GET 传数组 `?ids=1,2,3` 拿不到 | Spring MVC 默认按 `?ids=1&ids=2&ids=3` 解析；或者用 `@RequestParam("ids") List<Long> ids` + 前端逗号，然后自己 split |
| `@PathVariable Long id` 收到字符串 `"abc"` | 抛 `MethodArgumentTypeMismatchException` → 全局处理返回 400 |
| 分页查询 `PageHelper.startPage` 之后没紧接 SQL | 线程本地变量会污染下一次查询；`startPage` 必须紧邻着 `mapper.selectXxx` |
| `<if test="keyword != null">` 空串没排除 | 前端传空串会拼成 `LIKE '%%'`，第 5.3 节详细讲 |
| 类上没加 `@Validated`，`@RequestParam @Min(1)` 不生效 | Query/Path 参数的方法级校验必须靠类级 `@Validated` |

### 5.8 练习 / 思考

1. **必做**：把 5.2 完整 Mapper.xml 抄到项目，按 5.6 剧本跑完 8 条 curl，截图 5、6、8 三条的响应。
2. **必做**：修改 `<if test="keyword != null">` 去掉 `and keyword != ''`，然后传空串测试，观察 SQL 日志里的 `LIKE '%%'`。
3. **思考**：`PUT /api/coaches/{id}` 的 `id` 走了 path，body 里 `CoachUpdateDTO.id` 还需要 `@NotNull` 吗？如果强制以 path 为准，`@NotNull` 是不是多余？
4. **挑战**：把 `POST /api/coaches` 从「全量新增」拆成 `POST /api/coaches`（基本资料）+ `POST /api/coaches/{id}/certificates`（证书上传，Day09 会讲），观察哪些字段可以延迟填写。

---

## 第 6 讲：教室模块 tb_room + AI 一次生成两模块 + 联调收官

### 6.1 引入：如果教练模块能用，教室模块几乎可以复制粘贴——但是……

第 4、5 讲把教练模块打透之后，看下面这段拷问：

```text
> 教室不就是「一张主数据表 + 6 个 CRUD 接口」吗？
> 我把 tb_coach 的 SQL 全 replace 成 tb_room，name 保留，删掉 phone/id_card，加 capacity/location，是不是就完事了？
```

答对了大半，但是——**至少有 5 处不能盲改的差异**，本讲会一条条拆开。同时用 AI「一次生成两个模块」的提示词把这个「重复率 80%、差异率 20%」的场景吃下来。

### 6.2 教练 vs 教室：五处不能盲改的差异

| # | 维度 | 教练 | 教室 |
|---|---|---|---|
| 1 | 唯一字段 | `phone` + `id_card` 双唯一 | `name` 单唯一 |
| 2 | 特有字段 | `hire_date`、`birth_date`、`specialty` | `capacity`、`location`、`equipment`、`hourly_rate` |
| 3 | 数值字段类型 | 无 | `hourly_rate` 用 `DECIMAL(10,2)` 而非 `double` |
| 4 | JSON 字段 | 无 | `equipment` 用 `JSON` 类型（MySQL 8+） |
| 5 | 状态枚举 | 1 在职 / 2 休假 / 3 离职 | 1 可用 / 2 维护中 / 3 停用 |

⚠️ **特别注意**：**`hourly_rate` 千万别用 `double` / `Double`**——浮点数无法精确表示 `0.1`，前端算三节课乘 99 元最终可能显示 `296.9999999999`。表用 `DECIMAL(10,2)`，Java 一侧用 `BigDecimal`。

### 6.3 tb_room 表 DDL

```sql
DROP TABLE IF EXISTS tb_room;
CREATE TABLE tb_room (
  id           BIGINT       PRIMARY KEY AUTO_INCREMENT COMMENT '主键',
  name         VARCHAR(50)  NOT NULL      COMMENT '教室名称，如 阳光厅',
  capacity     INT          NOT NULL      COMMENT '容量（人）',
  location     VARCHAR(100)               COMMENT '位置，如 3 楼 302',
  equipment    JSON                       COMMENT '设施（JSON 数组）',
  hourly_rate  DECIMAL(10,2) NOT NULL     COMMENT '时租（元）',
  intro        TEXT                       COMMENT '简介',
  status       TINYINT      DEFAULT 1     COMMENT '状态 1 可用 2 维护中 3 停用',
  deleted      TINYINT      DEFAULT 0     COMMENT '逻辑删除 0 未删 1 已删',
  create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_name_deleted (name, deleted),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教室';
```

🎯 **三个和教练表不同的关键点**：

1. **`equipment JSON`**——MySQL 8.0+ 才支持原生 JSON 类型，前端传 `["镜面","音响","地暖"]` 会以 JSON 数组形式存到列里；早期版本可以退化为 `VARCHAR(255)` 加逗号分隔；
2. **`hourly_rate DECIMAL(10,2)`**——最多 10 位数字、小数 2 位；`999999999.99` 上限已经够用，同时不丢精度；
3. **`UNIQUE KEY uk_name_deleted (name, deleted)`**——软删除后同一个「阳光厅」可以复用名字，这条规矩和教练模块一致。

### 6.4 RoomAddDTO / RoomUpdateDTO / RoomQueryDTO

```java
package com.yinxiang.room.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class RoomAddDTO {

    @NotBlank(message = "教室名称不能为空")
    @Size(max = 50, message = "教室名称不能超过 50 字符")
    private String name;

    @NotNull(message = "容量不能为空")
    @Min(value = 1,   message = "容量至少 1 人")
    @Max(value = 200, message = "容量最多 200 人")
    private Integer capacity;

    @Size(max = 100)
    private String location;

    /** 设施：JSON 数组，如 ["镜面","音响"] */
    @Size(max = 20, message = "最多 20 项设施")
    private List<@NotBlank @Size(max = 30) String> equipment;

    @NotNull(message = "时租不能为空")
    @DecimalMin(value = "0.00", inclusive = true, message = "时租不能为负")
    @DecimalMax(value = "99999999.99", message = "时租超上限")
    @Digits(integer = 8, fraction = 2, message = "时租最多 8 位整数 2 位小数")
    private BigDecimal hourlyRate;

    @Size(max = 2000) private String intro;
    @Min(1) @Max(3)   private Integer status;
}
```

```java
@Data
public class RoomUpdateDTO {

    @NotNull(message = "id 不能为空")
    private Long id;

    @NotBlank                              @Size(max = 50)  private String name;
    @NotNull @Min(1) @Max(200)             private Integer capacity;
    @Size(max = 100)                       private String location;
    @Size(max = 20)                        private List<@NotBlank @Size(max = 30) String> equipment;
    @NotNull @DecimalMin("0.00")
    @DecimalMax("99999999.99")
    @Digits(integer = 8, fraction = 2)     private BigDecimal hourlyRate;
    @Size(max = 2000)                      private String intro;
    @Min(1) @Max(3)                        private Integer status;
}
```

```java
@Data
public class RoomQueryDTO {

    /** 名称 / 位置 两字段模糊匹配 */
    private String keyword;

    @Min(1) @Max(3)
    private Integer status;

    @Min(1)                    private Integer page = 1;
    @Min(1)  @Max(100)         private Integer size = 10;

    /** 排序字段：hourly_rate | create_time */
    private String sortBy = "create_time";
    private String sortDir = "desc";
}
```

🎯 **教室特有的三个校验**：

1. **`@DecimalMin("0.00")`**——时租不能是负数；
2. **`@Digits(integer=8, fraction=2)`**——JVM 一侧拦截「前端传 3 位小数」的场景，避免 DB 因精度截断而静默丢数据；
3. **集合字段的嵌套校验** `List<@NotBlank @Size(max=30) String> equipment`——用元素级注解限制每个设施名不为空且不超过 30 字。

### 6.5 Service 与教练模块的差异

结构 95% 相同，但有两处**不能盲改**：

**（1）唯一校验只有一个字段**：

```java
@Transactional(rollbackFor = Exception.class)
public Long add(RoomAddDTO dto) {
    if (mapper.existsByName(dto.getName(), null) > 0)
        throw new BizException(13001, "教室名称已被占用");

    Room r = new Room();
    BeanUtils.copyProperties(dto, r);
    if (r.getStatus() == null) r.setStatus(1);
    r.setEquipmentJson(toJson(dto.getEquipment()));   // ★ 差异点

    mapper.insert(r);
    log.info("[教室新增] id={} name={}", r.getId(), r.getName());
    return r.getId();
}
```

**（2）`equipment` 的 JSON 存取转换**：

```java
private String toJson(List<String> list) {
    if (list == null) return null;
    try {
        return new ObjectMapper().writeValueAsString(list);
    } catch (JsonProcessingException e) {
        throw new BizException(500, "设施序列化失败", e);
    }
}
```

如果所有 Service 都要手写 `toJson`/`fromJson`，代码里全是重复。更工程化的做法是配 MyBatis 的 `TypeHandler`——把 `List<String>` ↔ `VARCHAR/JSON` 的转换封装到 `JsonArrayTypeHandler`，Service 层就完全不感知：

```java
@MappedTypes(List.class)
@MappedJdbcTypes(JdbcType.VARCHAR)
public class JsonArrayTypeHandler extends BaseTypeHandler<List<String>> {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i,
                                    List<String> parameter, JdbcType jdbcType) throws SQLException {
        try { ps.setString(i, MAPPER.writeValueAsString(parameter)); }
        catch (JsonProcessingException e) { throw new SQLException(e); }
    }

    @Override public List<String> getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return parse(rs.getString(columnName));
    }
    @Override public List<String> getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return parse(rs.getString(columnIndex));
    }
    @Override public List<String> getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return parse(cs.getString(columnIndex));
    }

    private List<String> parse(String json) throws SQLException {
        if (json == null || json.isEmpty()) return null;
        try { return MAPPER.readValue(json, new TypeReference<List<String>>() {}); }
        catch (JsonProcessingException e) { throw new SQLException(e); }
    }
}
```

在 `Room` 实体上标注：

```java
@Data
public class Room {
    private Long id;
    private String name;
    private Integer capacity;
    private String location;

    @TableField(typeHandler = JsonArrayTypeHandler.class)
    private List<String> equipment;

    private BigDecimal hourlyRate;
    private String intro;
    private Integer status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
```

Mapper.xml 里对应字段声明 `typeHandler`：

```xml
<result property="equipment" column="equipment"
        typeHandler="com.yinxiang.common.handler.JsonArrayTypeHandler"/>
```

💡 **口诀**：**Service 层永远面对 `List<String>`，`String` 是 JDBC 的事**。TypeHandler 一劳永逸。

### 6.6 RoomController 六大端点

结构和 `CoachController` 完全对称，只是路径、类型换掉：

```java
package com.yinxiang.room.controller;

import com.yinxiang.common.Result;
import com.yinxiang.room.dto.*;
import com.yinxiang.room.entity.Room;
import com.yinxiang.room.service.RoomService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
@Validated
public class RoomController {

    private final RoomService service;

    @PostMapping
    public Result<Long> add(@RequestBody @Valid RoomAddDTO dto) {
        return Result.ok(service.add(dto));
    }

    @PutMapping("/{id}")
    public Result<Void> update(@PathVariable Long id,
                               @RequestBody @Valid RoomUpdateDTO dto) {
        dto.setId(id);
        service.update(dto);
        return Result.ok();
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return Result.ok();
    }

    @GetMapping("/{id}")
    public Result<Room> get(@PathVariable Long id) {
        return Result.ok(service.getById(id));
    }

    @GetMapping
    public Result<PageInfo<Room>> page(@Valid RoomQueryDTO q) {
        PageHelper.startPage(q.getPage(), q.getSize());
        List<Room> list = service.list(q);
        return Result.ok(new PageInfo<>(list));
    }

    @GetMapping("/available")
    public Result<List<Room>> available() {
        return Result.ok(service.listAvailable());
    }
}
```

🎯 **对比 CoachController**：改动的只有 5 处——`@RequestMapping` 路径、DTO 类名、实体类名、Service 类名、方法内部业务参数。**其他一模一样**，是训练 AI 批量生成的最佳素材。

### 6.7 用 AI 一次生成两个模块

**提示词模板**（把两张表 DDL 一次性给 AI）：

```text
项目：Spring Boot 4.0 + Java 25 + MyBatis 3.5 + PageHelper + Bean Validation 3 + MySQL 8.0
包名：com.yinxiang
已完成：com.yinxiang.common.Result / BizException / GlobalExceptionHandler / MaskUtil
已完成：会员模块 tb_member 的 CRUD（结构与本次一致）

请**用相同的模式**，一次性生成以下两个模块的完整 4 层代码（Controller / Service / Mapper.java / Mapper.xml + DTO + Entity）：

【模块 A：教练管理 /api/coaches】
CREATE TABLE tb_coach (
  id BIGINT PK AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,
  phone VARCHAR(20) NOT NULL,               -- 双唯一 (phone, deleted)
  id_card VARCHAR(20) NOT NULL,             -- 双唯一 (id_card, deleted)
  gender TINYINT DEFAULT 0,
  birth_date DATE,
  hire_date DATE NOT NULL,
  specialty VARCHAR(255),
  intro TEXT,
  avatar VARCHAR(255),
  status TINYINT DEFAULT 1,                 -- 1 在职 2 休假 3 离职
  deleted TINYINT DEFAULT 0,
  create_time DATETIME, update_time DATETIME
);
校验规则：phone `^1[3-9]\d{9}$`，id_card `^\d{17}[\dXx]$`，birthDate @Past。

【模块 B：教室管理 /api/rooms】
CREATE TABLE tb_room (
  id BIGINT PK AUTO_INCREMENT,
  name VARCHAR(50) NOT NULL,                -- 唯一 (name, deleted)
  capacity INT NOT NULL,                    -- 1-200
  location VARCHAR(100),
  equipment JSON,                           -- List<String>
  hourly_rate DECIMAL(10,2) NOT NULL,       -- ≥ 0，8 位整数 2 位小数
  intro TEXT,
  status TINYINT DEFAULT 1,                 -- 1 可用 2 维护中 3 停用
  deleted TINYINT DEFAULT 0,
  create_time DATETIME, update_time DATETIME
);
校验规则：capacity 1-200，hourlyRate DecimalMin=0，Digits(integer=8, fraction=2)。

每个模块提供六大接口：
- POST   /api/xxx        新增
- PUT    /api/xxx/{id}   全量更新
- DELETE /api/xxx/{id}   逻辑删除
- GET    /api/xxx/{id}   详情
- GET    /api/xxx        分页 + keyword 全字段模糊 + status 精确
- GET    /api/xxx/available  下拉候选

约束：
- 双重唯一：Service 层预查 existsByX(value, excludeId) + DB UNIQUE 兜底
- 软删除唯一键必须联合 deleted
- 返回 Result<T>，业务异常抛 BizException(code, msg)，code 教练走 12xxx，教室走 13xxx
- 敏感字段（phone / idCard）进日志前用 MaskUtil 脱敏
- equipment 用 TypeHandler 做 List<String> ↔ JSON 转换
```

**收到 AI 输出后必须做的 5 项校验**（不做等于没做）：

| # | 检查项 | 通过标准 |
|---|---|---|
| 1 | 唯一键联合 `deleted` | Mapper.xml 里 `UNIQUE KEY (name, deleted)` 而不是 `UNIQUE (name)` |
| 2 | 双重唯一 `existsByX(value, excludeId)` 签名齐 | Mapper 接口第二个参数是 `excludeId` |
| 3 | Service 事务 `@Transactional(rollbackFor = Exception.class)` | 检查而不是默认 `RollbackFor` |
| 4 | `equipment` 用 `TypeHandler` 而非 String 手动 JSON | `Room` 实体里字段类型是 `List<String>` |
| 5 | 日志脱敏 | `MaskUtil.phone(...)` 出现在 log.info 里 |

⚠️ **特别注意**：**AI 生成 4-5 个模块时会出现「字段串味」**——把教练的 `id_card` 塞进教室的 SQL、教室的 `hourly_rate` 塞进教练的 DTO。控制在两个模块一次生成是安全边界，超过就分批喂。

### 6.8 联调剧本：跨模块串场

先造种子数据：

```sql
INSERT INTO tb_room (name, capacity, location, equipment, hourly_rate, status) VALUES
 ('阳光厅', 20, '3 楼 302', '["镜面","音响","地暖"]',   99.00,  1),
 ('月光厅', 12, '3 楼 305', '["镜面","音响"]',           79.00,  1),
 ('星空厅', 30, '4 楼 401', '["镜面","音响","投影仪"]',  129.00, 2);
```

curl 跑一遍：

（1）**新增教室**：

```bash
curl -X POST http://localhost:8080/api/rooms \
  -H "Content-Type: application/json" \
  -d '{
    "name":"翠竹厅",
    "capacity":15,
    "location":"2 楼 208",
    "equipment":["镜面","地暖"],
    "hourlyRate":89.00
  }'
```

响应：

```json
{"code":0,"msg":"OK","data":4,"timestamp":1721030400000}
```

（2）**容量越界**：

```bash
curl -X POST http://localhost:8080/api/rooms \
  -H "Content-Type: application/json" \
  -d '{
    "name":"巨型厅",
    "capacity":250,
    "hourlyRate":199.00
  }'
```

响应：

```json
{"code":400,"msg":"capacity: 容量最多 200 人","data":null,"timestamp":1721030400000}
```

（3）**时租传 3 位小数**：

```bash
curl -X POST http://localhost:8080/api/rooms \
  -H "Content-Type: application/json" \
  -d '{
    "name":"测试厅",
    "capacity":10,
    "hourlyRate":99.999
  }'
```

响应：

```json
{"code":400,"msg":"hourlyRate: 时租最多 8 位整数 2 位小数","data":null,"timestamp":1721030400000}
```

（4）**名称重复**：

```bash
curl -X POST http://localhost:8080/api/rooms \
  -H "Content-Type: application/json" \
  -d '{"name":"阳光厅","capacity":10,"hourlyRate":50.00}'
```

响应：

```json
{"code":13001,"msg":"教室名称已被占用","data":null,"timestamp":1721030400000}
```

（5）**分页查看**：

```bash
curl "http://localhost:8080/api/rooms?page=1&size=5&keyword=厅"
```

响应（截取）：

```json
{
  "code": 0,
  "msg": "OK",
  "data": {
    "pageNum": 1,
    "pageSize": 5,
    "total": 4,
    "list": [
      {"id":1,"name":"阳光厅","capacity":20,"equipment":["镜面","音响","地暖"],"hourlyRate":99.00,"status":1},
      {"id":2,"name":"月光厅","capacity":12,"equipment":["镜面","音响"],       "hourlyRate":79.00,"status":1}
    ]
  }
}
```

（6）**跨模块场景预告**：Day08 开始做课程模块 `tb_course`，字段里会有 `coach_id`、`room_id` 两个外键——「教练李教练在阳光厅上一节流瑜伽」就是典型的跨模块串联。今天先建好这两张主数据表，为 Day08 铺路。

### 6.9 本日回顾（一句话概括 6 讲）

划重点：Day07 只做了两件事——**（1）把「异常 + 日志 + 响应」统一成一套地基**（第 1-3 讲），**（2）用这套地基长出教练、教室两个「结构对称」的业务模块，训练 AI 批量生成**（第 4-6 讲）。

- **第 1 讲**：`Result<T>` 和 `BizException` 建立统一响应约定；
- **第 2 讲**：`GlobalExceptionHandler` 六大分支 + 404 统一，Controller 从此不写 try-catch；
- **第 3 讲**：`logback-spring.xml` + 敏感字段脱敏 + AI 生成异常骨架的提示词模板；
- **第 4 讲**：`tb_coach` + 三层 DTO + 双重唯一校验（Service 预查 + DB UNIQUE 兜底）；
- **第 5 讲**：`CoachMapper.xml` + `<if>` 空串陷阱 + 六大薄 Controller；
- **第 6 讲**：`tb_room` + `TypeHandler` 处理 JSON 字段 + 一次提示词生成两模块 + 五项校验清单。

💡 **今日一句话**：**「统一的响应结构 + 全局异常 + 分级日志」是所有后续模块的地基，「双重唯一 + 软删除唯一键联合 deleted」是所有主数据表的通用规矩，「AI 一次生成两个对称模块」是团队常用的效率倍增器**。

### 6.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `equipment` 用 `VARCHAR(255)` + 逗号分隔 | 无法查「包含镜面」这种查询，也无法结构化存取；MySQL 8.0+ 用原生 `JSON` 类型 |
| `hourly_rate` 用 `double` / `Double` | 浮点精度丢失；表用 `DECIMAL(10,2)`，Java 用 `BigDecimal` |
| 软删除后想复用同名教室名 | 唯一键必须是 `(name, deleted)` 联合，才允许旧行 `deleted=1` 与新行 `deleted=0` 共存 |
| AI 一次生成 4 模块出现字段串味 | 一次 ≤ 2 模块；生成后过 6.7 的五项校验清单 |
| `List<String> equipment` 直接映射 `JSON` 报错 | 必须用 `TypeHandler` 或用 `MyBatis-Plus` 的 `@TableField(typeHandler=...)` |
| 前端传 `equipment: null` 存进 DB | 是允许的，但查询时要注意 `JSON_CONTAINS` 对 null 的行为——最简单的兜底是入库前用 `Collections.emptyList()` 替代 null |

### 6.11 练习 / 思考

1. **必做**：跑通 6.8 的 6 条 curl，交 4、5、6 三条的响应截图（含分页结构）。
2. **必做**：用 6.7 提示词让 AI 生成一份代码，然后按 6.7 五项校验清单打分——列出 AI 遗漏的项，动手补齐。
3. **思考**：如果 `equipment` 字段以后要支持「按设施筛选教室」（如 `?equipment=投影仪`），MyBatis SQL 应该怎么写？（提示：MySQL 8 的 `JSON_CONTAINS` 函数）
4. **挑战**：把 `DELETE /api/rooms/{id}` 改造为「删除前检查是否有未开始的课程占用该教室」——Day08 会补上 `tb_course` 表，这里先留 `TODO(ch15)` 标记，练习伏笔式编码。

---

**Day07 收尾**：写到这里，`Result` + `BizException` + `GlobalExceptionHandler` + `logback-spring.xml` 这套地基已经把项目所有「异常处理 / 日志 / 响应结构」的痛点解决；`tb_coach` + `tb_room` 两张主数据表和它们的 12 个接口也上线可用。Day08 会在这份地基上加入课程模块（多表关联查询、状态机、外键约束），并把「请求日志切面」真正落地——那时候你会体会到，今天多花的时间是**为未来所有模块都省时间**。
