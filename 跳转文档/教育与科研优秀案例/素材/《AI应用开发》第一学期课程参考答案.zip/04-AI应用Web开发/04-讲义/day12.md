# 《AI 应用 Web 开发》 - 学生讲义（Day12：Vue 3 工程化 + Router + Axios + Element Plus）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day11 的学生（掌握 Spring Boot 4.0.x 后端、JWT 登录、统一 Result、AOP 操作日志，且具备 HTML/CSS/JS 基础，能读懂 ES6 语法）**

**技术版本基线**：Node.js 20 LTS / pnpm 9.x / Vue 3.5.x / Vite 5.x / TypeScript 5.x / vue-router 4.x / pinia 3.x / axios 1.7+ / element-plus 3.x / IDEA 2024.3+（前端可用 VS Code 或 WebStorm）/ 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统前端 `yoga-admin`。Day11 结束时，你已经拥有一份完整的后端服务，跑在 `http://localhost:8080`，具备 JWT 登录、统一 Result、AOP 操作日志。Day12 就把与之配对的**前端管理后台**从零建起来：Vite 建项目、组合式 API 写页面、VueRouter 4 组织路由、Axios 二次封装、Element Plus 换皮、目录规范落地——最终交付一个可运行的**会员列表页 Demo**（搜索 + 分页表格 + 编辑 / 删除按钮）。这份底座会一路支撑到 Day18，之后的所有会员、教练、课程、预约业务页面，都是往这个底座上「加菜」而已。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Vue 3 概述 + Vite 创建 yoga-admin 项目 | `pnpm create vite` 一键脚手架 + `vite.config.ts` 的 `@` 别名与 `/api` 代理 |
| 第 2 讲 | 选项式 API vs 组合式 API（setup / ref / reactive / computed） | 一份登录表单雏形：`form / loading / canSubmit / submit` 四件套 |
| 第 3 讲 | VueRouter 4 路由配置 + 导航守卫 | 三条路由（`/login` `/dashboard` `/members`）+ `beforeEach` 未登录守卫 |
| 第 4 讲 | Axios 二次封装 + 拦截器 + 环境变量 | `src/api/request.ts` + `useAuthStore` + `BizError`，登录闭环 |
| 第 5 讲 | Element Plus 安装 + 常用组件（Menu/Table/Form/Message） | 按需自动引入 + 主题色 + 侧栏顶栏布局 + 登录页升级 |
| 第 6 讲 | 前端脚手架 + 目录规范 + 会员列表 Mock 联调 | `src/` 八目录 + PageContainer/SearchBar/ProTable + 会员列表 Demo |

---

## 第 1 讲：Vue 3 概述 + Vite 创建 yoga-admin 项目

### 1.1 从「HTML+CDN」到「工程化」

之前学过用 `<script src="vue.global.js">` 写简单页面：

```html
<div id="app">{{ msg }}</div>
<script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
<script>
  Vue.createApp({ data() { return { msg: 'Hello' } } }).mount('#app')
</script>
```

简单直接，但真项目里根本用不了，有 5 个致命短板：

1. **没有模块系统**：所有代码都塞进一个 `<script>` 标签里，随着页面变多迅速失控；
2. **无法用 `.vue` 单文件组件**：模板 / 脚本 / 样式无法在同一文件里；
3. **无法使用 ES6+ / TypeScript**：老浏览器兼容问题一堆；
4. **没有构建时优化**：没有 tree-shaking、压缩、代码分割、懒加载；
5. **没有开发环境热更新**：改一行代码得刷浏览器。

**工程化 = 引入构建工具**。本教程选 **Vite**：Vue 官方钦定 + 冷启动秒级，代替了老一代的 Webpack。

### 1.2 工具链五件套：与后端一一对照

| 工具 | 定位 | 后端类比 |
|---|---|---|
| Node.js 20 LTS | JS 运行时 | JDK |
| pnpm 9.x | 包管理器 | Maven |
| Vite 5.x | 构建工具 + Dev Server | Maven package + Tomcat |
| TypeScript 5.x | 类型系统（可选） | Java |
| Vue 3.5.x | 视图框架 | Spring MVC |

一条命令验版本：

```bash
node -v           # 期望 v20.x
pnpm -v           # 期望 9.x
```

若无 pnpm，先装：

```bash
npm i -g pnpm@9
```

**为什么用 pnpm 而不是 npm**：pnpm 通过全局仓库 + 软链复用，磁盘占用比 npm 小约 60%，多个项目共用同一份依赖。工程里跑同样的 `pnpm install`，一分钟能完成的事情，npm 可能要三分钟。

### 1.3 创建项目

进入你的工作目录（**用纯英文路径**，避免中文路径怪异问题）：

```bash
cd D:/workspace
pnpm create vite@latest yoga-admin -- --template vue-ts
cd yoga-admin
pnpm install
pnpm dev
```

看到终端输出：

```text
  VITE v5.x.x  ready in 512 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: use --host to expose
```

浏览器打开 `http://localhost:5173`，Vue logo 页面出现——项目跑起来了。

### 1.4 脚手架六件套

新建的 `yoga-admin/` 目录里，六个文件先认识：

```text
yoga-admin/
├── index.html            # 唯一 HTML 入口，含 <div id="app"> 与 <script src="/src/main.ts">
├── package.json          # 依赖清单 + scripts（dev / build / preview）
├── vite.config.ts        # Vite 配置：插件 / 别名 / 代理 / 端口
├── tsconfig.json         # TypeScript 编译配置
├── src/
│   ├── main.ts           # JS 入口：createApp(App).mount('#app')
│   └── App.vue           # 根组件（SFC 三段式）
└── node_modules/         # pnpm 装的依赖，勿手动改
```

**SFC = Single File Component**，就是 `.vue` 文件，三段式：

```vue
<template>
  <!-- HTML 模板 -->
</template>

<script setup lang="ts">
  // 组合式 API 脚本
</script>

<style scoped>
  /* 只作用于本组件的样式 */
</style>
```

### 1.5 改造 `vite.config.ts`：加别名 + 代理

打开 `vite.config.ts`，替换成：

```ts
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) }
  },
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: p => p.replace(/^\/api/, '')
      }
    }
  }
})
```

**两处修改的意义**：

- **`@` 别名**：以后写 `import router from '@/router'` 而不是 `import router from '../../router'`——告别相对路径地狱；
- **`/api` 代理**：Vite 把所有 `/api/**` 请求转发到 `http://localhost:8080`，浏览器看到的是同源请求，**绕开 CORS**。生产环境由 nginx 反代做同样事情（第 29 章）。

同步改 `tsconfig.json`，让 TS 也认识 `@/*`（否则 IDE 会飘红线）：

```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": { "@/*": ["src/*"] }
  }
}
```

### 1.6 环境变量：`.env.development` 与 `.env.production`

在项目根目录（不是 src 里）建两个文件：

`.env.development`：
```env
VITE_API_BASE = /api
VITE_APP_TITLE = 印想瑜伽-管理后台（DEV）
```

`.env.production`：
```env
VITE_API_BASE = /api
VITE_APP_TITLE = 印想瑜伽-管理后台
```

**铁律**：**只有以 `VITE_` 开头的变量才会被打包进前端**。密钥、敏感配置永远**不能**放这里，前端代码是**明文交付**的，任何人都能在浏览器里看到。

在组件里读环境变量：

```ts
const title = import.meta.env.VITE_APP_TITLE
console.log(title)      // 印想瑜伽-管理后台（DEV）
```

### 1.7 常见踩坑

1. **Node 版本不对**：装了 Node 16 或 22——务必换成 20 LTS，`.msi` 从 nodejs.org 下载；
2. **pnpm 首次报「Unknown Command」**：执行 `corepack enable`，或直接 `npm i -g pnpm@9`；
3. **中文路径怪异**：Windows 下 `D:/项目/yoga-admin` 偶发路径解析出错，务必用英文路径；
4. **`@` IDE 飘红线**：漏改 `tsconfig.json` 的 `paths`；
5. **`/api/**` 请求 404**：`proxy.rewrite` 忘配，导致真实请求变成 `http://localhost:8080/api/xxx` 而不是 `http://localhost:8080/xxx`。

### 1.8 本讲小结

至此，`yoga-admin` 脚手架完成，`pnpm dev` 能起 5173，`vite.config.ts` 有别名 + 代理，环境变量文件就位。下一讲把 `App.vue` 从 hello 世界改成一份**登录表单雏形**，正式认识 Vue 3 组合式 API。

---

## 第 2 讲：选项式 API vs 组合式 API（setup / ref / reactive / computed）

### 2.1 两种 API 风格

Vue 3 支持两种写组件的风格：

**Options API**（Vue 2 遗产，Vue 3 兼容）：
```vue
<script>
export default {
  data() { return { count: 0 } },
  computed: {
    double() { return this.count * 2 }
  },
  methods: {
    inc() { this.count++ }
  }
}
</script>
```

- 特点：**按种类分块**。`data` / `computed` / `methods` 各归各家；
- 一个业务点的三段逻辑被分散在三处；
- 想复用逻辑很麻烦（要用 mixins，容易命名冲突）。

**Composition API**（Vue 3 推荐，`<script setup>` 语法糖）：
```vue
<script setup lang="ts">
import { ref, computed } from 'vue'
const count = ref(0)
const double = computed(() => count.value * 2)
function inc() { count.value++ }
</script>
```

- 特点：**按业务聚合**。同一业务的代码相邻几行；
- 逻辑复用直接抽 `composables/` 里的普通函数；
- TS 类型推断更好。

**本教程一律用 `<script setup>`**。Options API 只在维护老代码时看得懂即可。

### 2.2 `ref` 与 `reactive`

Vue 3 的响应式核心是「**你告诉 Vue 我要追踪哪些变量，Vue 就在这些变量变化时更新视图**」。声明响应式变量有两种方式：

**`ref(value)`**：适合基本类型（`number / string / boolean`）
```ts
import { ref } from 'vue'
const count = ref(0)
count.value++            // ✅ 修改
console.log(count.value) // ✅ 读取
```

- `ref` 返回一个 `{ value: T }` 对象；
- 在 `<script>` 里必须用 `.value` 访问；
- 在 `<template>` 里 Vue 编译器**自动解 ref**，直接写 `{{ count }}`。

**`reactive(obj)`**：适合对象 / 数组
```ts
import { reactive } from 'vue'
const form = reactive({ username: '', password: '' })
form.username = 'zhangsan'    // ✅ 直接改
```

- 返回一个 Proxy 代理对象；
- 属性访问不用 `.value`；
- **陷阱**：解构会丢响应性：
  ```ts
  const { username } = form   // ❌ username 是普通字符串了
  ```
  必须用 `toRefs()` 或不解构。

**选型口诀**：**基本类型用 `ref`、表单/对象用 `reactive`**。

### 2.3 `computed`：派生状态

```ts
import { ref, computed } from 'vue'

const form = reactive({ username: '', password: '' })

const canSubmit = computed(() =>
  form.username.trim().length >= 3 &&
  form.password.length >= 6
)
```

- `canSubmit` 是**派生值**，依赖 `form.username / form.password`；
- 依赖不变时**有缓存**，不重复计算；
- 比 `methods` 里的函数快，可放心在 `<template>` 里反复引用。

**`computed` vs `methods`**：

| | computed | methods |
|---|---|---|
| 缓存 | ✅ 有 | ❌ 无，每次调用重算 |
| 参数 | ❌ 只能用外部响应式变量 | ✅ 可传参 |
| 调用 | `{{ canSubmit }}` | `{{ canSubmit() }}` |

### 2.4 `watch` 与 `watchEffect`：监听副作用

```ts
import { watch, watchEffect } from 'vue'

// watch：惰性，只在依赖变化时触发
watch(() => form.username, (newVal, oldVal) => {
  console.log(`用户名从「${oldVal}」变为「${newVal}」`)
})

// watchEffect：立即执行一次 + 自动收集依赖
watchEffect(() => {
  console.log('当前表单：', form.username, form.password)
})
```

**选型**：
- 关心「变化后干什么」用 `watch`；
- 「有依赖就跑一次」用 `watchEffect`（很多副作用场景更方便）。

### 2.5 完整示例：登录表单雏形

`src/App.vue` 改成：

```vue
<template>
  <div style="max-width:360px;margin:80px auto;font-family:sans-serif">
    <h2>{{ title }}</h2>
    <input v-model="form.username" placeholder="用户名"><br><br>
    <input v-model="form.password" type="password" placeholder="密码"><br><br>
    <button :disabled="!canSubmit" @click="submit">
      {{ loading ? '登录中…' : '登录' }}
    </button>
    <p style="color:#999">canSubmit = {{ canSubmit }}</p>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, computed, watch } from 'vue'

const title = import.meta.env.VITE_APP_TITLE
const form = reactive({ username: '', password: '' })
const loading = ref(false)

const canSubmit = computed(() =>
  form.username.trim().length >= 3 &&
  form.password.length >= 6 &&
  !loading.value
)

watch(() => form.username, v => console.log('用户名变化：', v))

async function submit() {
  loading.value = true
  await new Promise(r => setTimeout(r, 800))     // 模拟接口
  console.log('提交：', form)
  loading.value = false
}
</script>
```

保存后浏览器自动刷新（HMR），你能看到：

- 输入用户名不足 3 位时按钮禁用；
- 密码不足 6 位时按钮禁用；
- 双方都够长时按钮亮起；
- 点登录 → 按钮变灰 800ms → 恢复；
- Console 打印用户名变化 + 最终提交对象。

### 2.6 常见踩坑

1. **忘写 `.value`**：
   ```ts
   const count = ref(0)
   count++          // ❌ count 是对象，不能 ++
   count.value++    // ✅
   ```
2. **解构 reactive 丢响应性**：
   ```ts
   const { username } = form   // ❌
   ```
   解决方案：不解构，或用 `toRefs(form)`。
3. **在 `<script>` 里把 `computed` 当函数调**：
   ```ts
   const canSubmit = computed(() => ...)
   if (canSubmit()) { ... }   // ❌ canSubmit 是 ref，不是函数
   if (canSubmit.value) { ... } // ✅
   ```
4. **`<template>` 里加了 `.value`**：Vue 编译时会自动解 ref，写 `{{ count.value }}` 是多余的（不会报错但不地道）。

### 2.7 本讲小结

`<script setup>` + `ref/reactive/computed/watch` 四件套已经覆盖 90% 单文件组件场景。下一讲把这些孤立组件挂到 VueRouter 4 里，让 `/login`、`/dashboard`、`/members` 三条路径能互相跳转。

---

## 第 3 讲：VueRouter 4 路由配置 + 导航守卫

### 3.1 为什么需要路由

目前 `App.vue` 只是一个孤立组件。我们要让 `/login` 显示登录页、`/dashboard` 显示仪表盘、`/members` 显示会员列表——**URL 路径与组件之间的映射**，就是路由系统的职责。

Vue 官方推荐 `vue-router@4`（Vue 3 专属，Vue 2 用 3.x 版本）。

### 3.2 安装

```bash
pnpm add vue-router@4 pinia
```

一并装上 pinia（下一讲用）。

### 3.3 目录规约

从这里开始，`src/` 目录长这样：

```text
src/
├── api/            # 接口封装
├── assets/         # 图片 + 全局样式
├── components/     # 通用组件
├── layouts/        # 布局组件（DefaultLayout）
├── router/         # 路由
│   └── index.ts
├── stores/         # Pinia
├── views/          # 页面级组件
│   ├── login/
│   ├── member/
│   └── DashboardView.vue
├── App.vue
└── main.ts
```

**目录职责铁律**：
- `views/` 只写页面；
- `layouts/` 只放布局；
- `components/` 只放通用组件；
- `router/` 只做路由配置。

### 3.4 声明路由表

`src/router/index.ts`：

```ts
import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    component: () => import('@/views/login/LoginView.vue'),
    meta: { public: true, title: '登录' }
  },
  {
    path: '/',
    component: () => import('@/layouts/DefaultLayout.vue'),
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/DashboardView.vue'),
        meta: { title: '首页' }
      },
      {
        path: 'members',
        component: () => import('@/views/member/MemberListView.vue'),
        meta: { title: '会员管理' }
      },
      {
        path: 'courses',
        component: () => import('@/views/course/CourseListView.vue'),
        meta: { title: '课程管理' }
      }
    ]
  },
  {
    path: '/:pathMatch(.*)*',
    component: () => import('@/views/NotFoundView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
```

**四个要点**：

1. **`createWebHistory()`**：HTML5 history 模式，URL 无 `#`。生产环境需要 nginx 配 `try_files`（第 29 章讲），否则刷新 404；
2. **懒加载**：`component: () => import(...)` 语法让打包时拆 chunk，页面按需加载，首屏更快；
3. **嵌套路由**：父级 `DefaultLayout` 里有 `<RouterView>` 作为**子路由占位**；
4. **通配符 404**：`/:pathMatch(.*)*` 匹配任意未定义路径。

### 3.5 挂载路由

`src/main.ts`：

```ts
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'

const app = createApp(App)
app.use(createPinia())    // 先 Pinia
app.use(router)           // 后 Router
app.mount('#app')
```

**挂载顺序**：Pinia 先、Router 后。这是因为后续 Router 守卫里会调 `useAuthStore()`，Pinia 必须已 install。

`src/App.vue` 瘦身到只剩一行：

```vue
<template>
  <RouterView />
</template>
```

### 3.6 建三个页面

`src/views/DashboardView.vue`：

```vue
<template>
  <h2>Dashboard</h2>
  <p>欢迎回来，这里是印想瑜伽会馆管理后台。</p>
</template>
```

`src/views/member/MemberListView.vue`：

```vue
<template>
  <h2>会员管理</h2>
  <p>（列表马上来）</p>
</template>
```

`src/views/login/LoginView.vue`：把第 2 讲的登录表单雏形搬过来。

### 3.7 建 Layout

`src/layouts/DefaultLayout.vue`：

```vue
<template>
  <div class="layout">
    <nav>
      <RouterLink to="/dashboard">首页</RouterLink>
      <RouterLink to="/members">会员管理</RouterLink>
      <RouterLink to="/courses">课程管理</RouterLink>
    </nav>
    <main>
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
.layout { display: flex; }
nav { width: 180px; padding: 20px; background: #f4f6f5; }
nav a { display: block; padding: 8px; color: #333; text-decoration: none; }
nav a.router-link-active { color: #5AA372; font-weight: bold; }
main { flex: 1; padding: 20px; }
</style>
```

`<RouterLink>` 会自动加 `router-link-active` 类，可以用来做当前项高亮。

### 3.8 导航守卫：未登录跳登录页

```ts
router.beforeEach((to, _from, next) => {
  document.title = `${to.meta.title || ''} · ${import.meta.env.VITE_APP_TITLE}`
  const token = localStorage.getItem('token')     // 下一讲换成 store
  if (to.meta.public) return next()               // 白名单直接放行
  if (!token) {
    return next({ path: '/login', query: { redirect: to.fullPath } })
  }
  next()
})
```

**四个 `next()` 用法**：
- `next()`：放行；
- `next('/login')` 或 `next({ path: '/login' })`：改跳到目标路径；
- `next(false)`：阻止跳转，停在原页；
- `next(new Error('xxx'))`：报错终止。

**必须调 `next()`**，忘调 → 路由卡死没反应。

### 3.9 试跑

`pnpm dev` → 浏览器：

1. 直接访问 `http://localhost:5173/dashboard` → 自动跳 `/login?redirect=/dashboard`；
2. 手工在 DevTools Console 里 `localStorage.setItem('token', 'fake')` → 刷新 → 能进 dashboard 了；
3. 点 nav 中「会员管理」→ URL 变 `/members` + 内容切换，页面不刷新（SPA 体验）；
4. `pnpm build` → 打开 `dist/assets/`，看到 `LoginView-xxx.js` / `DashboardView-xxx.js` 等**独立 chunk**——这就是懒加载的产物。

### 3.10 常见踩坑

1. **`next()` 忘调**：路由卡死没反应，代码里所有 `if` 分支都要 return next；
2. **Pinia 与 Router 挂载顺序颠倒**：守卫里 `useAuthStore()` 报「getActivePinia not set」；
3. **history 模式刷新 404**：Vite 有 fallback 不会，但 build 后部署到 nginx 需配 `try_files $uri $uri/ /index.html`（第 29 章讲）；
4. **`<RouterLink>` 拼错**：`<router-link>` 也能用（kebab-case），但项目里统一 PascalCase 更规范。

### 3.11 本讲小结

路由表 + 懒加载 + `<RouterView>` + `beforeEach` 守卫，前端从「一张页面」升级为「多页面 SPA」。下一讲把「假 token」换成真的 Axios 登录接口 + Pinia store，实现真正的登录闭环。

---

## 第 4 讲：Axios 二次封装 + 拦截器 + 环境变量

### 4.1 为什么要二次封装

如果 20 个页面每个都手写：

```ts
const res = await axios.get('/api/members', {
  headers: { Authorization: 'Bearer ' + localStorage.getItem('token') }
})
if (res.data.code === 200) {
  return res.data.data
} else {
  ElMessage.error(res.data.msg)
  throw new Error(res.data.msg)
}
```

一份代码变 20 份，改一处要改 20 处。**Axios 二次封装 = 用拦截器把这些横切逻辑抽出去**——思想上与 Day10 学过的后端 AOP 完全一致。

### 4.2 安装

```bash
pnpm add axios
```

### 4.3 创建独立 axios 实例

`src/api/request.ts`：

```ts
import axios, { type AxiosResponse, type InternalAxiosRequestConfig } from 'axios'
import { useAuthStore } from '@/stores/auth'
import router from '@/router'

const request = axios.create({
  baseURL: import.meta.env.VITE_API_BASE,
  timeout: 15_000
})
```

**为什么用 `axios.create()`**：全局默认 `axios` 谁都能改，会互相污染。独立实例保证配置隔离。

### 4.4 请求拦截：注入 JWT

```ts
request.interceptors.request.use((cfg: InternalAxiosRequestConfig) => {
  const auth = useAuthStore()                      // ← 必须在函数内调
  if (auth.token) {
    cfg.headers.set('Authorization', `Bearer ${auth.token}`)
  }
  return cfg
})
```

**关键点**：`useAuthStore()` **只能在函数内调**。如果写在 `request.ts` 顶层，模块加载时 Pinia 还没 install，会报「getActivePinia not set」——**这是必栽的坑**。

### 4.5 响应拦截：统一解包 + 错误分发

```ts
let alertingLogin = false     // 防抖锁

request.interceptors.response.use(
  (res: AxiosResponse) => {
    const body = res.data
    // 后端约定：{ code: 200, msg, data }
    if (body && typeof body === 'object' && 'code' in body) {
      if (body.code === 200) return body.data
      throw new BizError(body.code, body.msg || '请求失败')
    }
    return body
  },
  async err => {
    if (!err.response) {
      throw new BizError(-1, '网络异常，请稍后再试')
    }
    const { status, data } = err.response
    if (status === 401) {
      const auth = useAuthStore()
      auth.reset()
      if (!alertingLogin) {
        alertingLogin = true
        try {
          window.alert(data?.msg || '登录已过期，请重新登录')
        } finally {
          alertingLogin = false
          router.push({
            path: '/login',
            query: { redirect: router.currentRoute.value.fullPath }
          })
        }
      }
      throw new BizError(401, data?.msg || '未登录')
    }
    if (status === 403) throw new BizError(403, '无权限访问')
    if (status >= 500)  throw new BizError(status, '服务异常，请稍后再试')
    throw new BizError(status, data?.msg || '请求失败')
  }
)

export class BizError extends Error {
  constructor(public code: number, public msg: string) { super(msg) }
}

export default request
```

**关键设计**：

1. **成功响应直接返回 `data`**：业务代码就写 `const list = await memberApi.page(q)`，不必再 `.data.data.list`；
2. **`code != 200` 直接 throw BizError**：上层用 `try/catch` 或 `.catch()` 统一处理；
3. **401 防抖锁**：并发多个请求同时收到 401，只弹一次登录过期，不至于弹 10 次；
4. **网络断连分支**：`err.response` 为 undefined 说明服务器根本没响应（断网、后端未启动、超时）。

### 4.6 Pinia：`useAuthStore`

`src/stores/auth.ts`（**setup 风格**，与 `<script setup>` 一致）：

```ts
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { loginApi, logoutApi } from '@/api/auth'

export const useAuthStore = defineStore('auth', () => {
  const token    = ref<string>(localStorage.getItem('token') || '')
  const username = ref<string>(localStorage.getItem('u')     || '')
  const realName = ref<string>(localStorage.getItem('rn')    || '')
  const roles    = ref<string[]>(JSON.parse(localStorage.getItem('roles') || '[]'))

  const isLogin = computed(() => !!token.value)

  async function login(p: { username: string; password: string }) {
    const data = await loginApi(p)
    token.value    = data.accessToken
    username.value = data.username
    realName.value = data.realName
    roles.value    = data.roles
    persist()
  }

  async function logout() {
    try { await logoutApi() } catch { /* ignore */ }
    reset()
  }

  function reset() {
    token.value = ''; username.value = ''; realName.value = ''; roles.value = []
    persist()
  }

  function persist() {
    localStorage.setItem('token', token.value)
    localStorage.setItem('u',     username.value)
    localStorage.setItem('rn',    realName.value)
    localStorage.setItem('roles', JSON.stringify(roles.value))
  }

  return { token, username, realName, roles, isLogin, login, logout, reset }
})
```

**为什么用 setup 风格**：类型推断更好、和 `<script setup>` 无缝共用 `ref/computed`。Options 风格保留仅为兼容 Vue 2 用户习惯，本教程一律用 setup。

### 4.7 API 模块

`src/api/auth.ts`：

```ts
import request from './request'

export interface LoginResult {
  accessToken: string
  refreshToken: string
  username: string
  realName: string
  roles: string[]
}

export function loginApi(p: {
  username: string
  password: string
}): Promise<LoginResult> {
  return request.post('/login', p)
}

export function logoutApi(): Promise<void> {
  return request.post('/logout')
}
```

`src/api/member.ts`：

```ts
import request from './request'

export interface MemberVO {
  id: number
  name: string
  phone: string
  status: number
}

export interface PageResult<T> {
  total: number
  records: T[]
}

export const memberApi = {
  page: (q: any) =>
    request.get<any, PageResult<MemberVO>>('/members', { params: q }),
  detail: (id: number) =>
    request.get<any, MemberVO>(`/members/${id}`),
  create: (p: any) =>
    request.post<any, number>('/members', p),
  update: (p: any) =>
    request.put<any, void>('/members', p),
  remove: (ids: number[]) =>
    request.delete<any, void>('/members', { data: ids })
}
```

### 4.8 把守卫换成真 store

`src/router/index.ts` 里的 `beforeEach`：

```ts
router.beforeEach((to, _from, next) => {
  document.title = `${to.meta.title || ''} · ${import.meta.env.VITE_APP_TITLE}`
  const auth = useAuthStore()
  if (to.meta.public) return next()
  if (!auth.token) {
    return next({ path: '/login', query: { redirect: to.fullPath } })
  }
  next()
})
```

### 4.9 LoginView 联登录逻辑

```vue
<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { useRouter, useRoute } from 'vue-router'
import { BizError } from '@/api/request'

const auth = useAuthStore()
const router = useRouter()
const route = useRoute()
const form = reactive({ username: '', password: '' })
const loading = ref(false)
const error = ref('')

async function submit() {
  error.value = ''
  loading.value = true
  try {
    await auth.login(form)
    router.replace((route.query.redirect as string) || '/dashboard')
  } catch (e) {
    error.value = e instanceof BizError ? e.msg : '登录失败'
  } finally {
    loading.value = false
  }
}
</script>
```

### 4.10 联调

前置：后端服务在 8080 已启动，第 22 章的登录接口能用。

1. `pnpm dev` → 浏览器 `http://localhost:5173`；
2. 未登录访问 `/dashboard` → 自动跳 `/login?redirect=/dashboard`；
3. 输入用户名密码 → 登录成功 → 回到 dashboard；
4. DevTools → Application → LocalStorage 有 `token / u / rn / roles`；
5. 手工把 `token` 改成乱码 → 刷新 → 弹「登录已过期」并跳登录。

### 4.11 常见踩坑

1. **顶层调 `useAuthStore()`**：模块加载时 Pinia 未 install，报「getActivePinia not set」——必须在拦截器函数体内调；
2. **401 不加防抖**：并发多个请求都 401，弹窗弹到用户想砸键盘；
3. **`err.response` 忘判 undefined**：网络断连时 `err.response` 是 undefined，直接读 `.status` 会报 TypeError；
4. **`baseURL` 与 proxy 不匹配**：`.env.development` 里 `VITE_API_BASE=/api`，与 `vite.config.ts` 的 `proxy: { '/api': ... }` 必须对齐。

### 4.12 本讲小结

Axios 只封一次，全项目共用。`baseURL / 拦截器 / BizError / Pinia store` 就位，登录闭环打通。下一讲把丑陋的原型登录页升级成 Element Plus 版，同时把 Layout 换成企业级侧栏顶栏布局。

---

## 第 5 讲：Element Plus 安装 + 常用组件（Menu / Table / Form / Message）

### 5.1 为什么选 Element Plus

后台管理页面 90% 是表单 + 表格，重新造轮子不经济。业界主流 UI 库对比：

| 库 | 定位 | 组件数 | 生态 |
|---|---|---|---|
| Element Plus | Vue 3 后台首选 | 60+ | 中文文档、开源活跃 |
| Ant Design Vue | 阿里风格 | 55+ | 类型好、样式偏企业 |
| Naive UI | Vue 3 原生、TS 友好 | 90+ | 主题灵活但组件门槛稍高 |
| PrimeVue | 国际风 | 80+ | 国内案例较少 |

**教学首选 Element Plus**：文档中文、社区大、招聘岗位需求高。

### 5.2 安装与按需自动引入

```bash
pnpm add element-plus @element-plus/icons-vue
pnpm add -D unplugin-vue-components unplugin-auto-import
```

修改 `vite.config.ts`：

```ts
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
      dts: 'src/auto-imports.d.ts'
    }),
    Components({
      resolvers: [ElementPlusResolver()],
      dts: 'src/components.d.ts'
    })
  ],
  // ... alias / proxy 同前
})
```

**两插件分工**：
- `unplugin-auto-import` → 自动引入**逻辑 API**（`ElMessage / ElMessageBox / ElNotification`）；
- `unplugin-vue-components` → 自动注册**模板组件**（`<el-button> <el-input>` 等）；
- **不必写 `import { ElButton } from 'element-plus'`**，Tree-shaking 也不会引入用不到的组件。

首次 `pnpm dev` 会自动生成 `src/auto-imports.d.ts` 与 `src/components.d.ts` 两个 TS 声明文件——**别删、别改**，它们让 IDE 认识自动引入的名字。

### 5.3 挂载样式与图标

`src/main.ts` 加：

```ts
import 'element-plus/dist/index.css'
import 'element-plus/theme-chalk/dark/css-vars.css'    // 暗色模式
import '@/assets/main.css'                              // 自定义覆盖

// 图标全局注册
import * as Icons from '@element-plus/icons-vue'
for (const [name, comp] of Object.entries(Icons)) {
  app.component(name, comp as any)
}
```

之后模板直接 `<User />` `<Reading />` `<HomeFilled />`——无需 import。

### 5.4 主题色定制（CSS 变量）

Element Plus 3.x 用 **CSS 变量**而非 SCSS 变量。项目色以印想瑜伽绿 `#5AA372` 为主。

`src/assets/main.css`：

```css
:root {
  --el-color-primary:            #5AA372;
  --el-color-primary-light-3:    #7CB58E;
  --el-color-primary-light-5:    #A6CDB2;
  --el-color-primary-light-7:    #D0E2D6;
  --el-color-primary-light-8:    #E3EEE7;
  --el-color-primary-light-9:    #EEF7F1;
  --el-color-primary-dark-2:     #468B57;

  --app-header-height:  56px;
  --app-sidebar-width:  220px;
}

html.dark {
  --el-color-primary: #6EB584;
}

html, body, #app { height: 100%; margin: 0; }
```

**注意**：**必须成套覆盖** `-light-3/5/7/8/9`，否则按钮 hover / disabled 时颜色不对——这是新手常踩的第一个坑。

### 5.5 升级 LoginView：Element Plus 版

```vue
<!-- src/views/login/LoginView.vue -->
<template>
  <div class="login-wrap">
    <el-card class="login-card">
      <div class="login-brand">
        <el-icon color="#5AA372" :size="24"><Sunny /></el-icon>
        <span>印想瑜伽会馆 · 管理后台</span>
      </div>
      <el-form ref="formRef" :model="form" :rules="rules"
               label-position="top" @submit.prevent="submit">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" prefix-icon="User"
                    placeholder="请输入用户名" size="large"/>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" show-password
                    prefix-icon="Lock" placeholder="请输入密码" size="large"
                    @keyup.enter="submit"/>
        </el-form-item>
        <el-button type="primary" size="large" class="submit-btn"
                   :loading="loading" @click="submit">登 录</el-button>
      </el-form>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import type { FormInstance, FormRules } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import { useRouter, useRoute } from 'vue-router'
import { BizError } from '@/api/request'

const auth = useAuthStore()
const router = useRouter()
const route = useRoute()
const formRef = ref<FormInstance>()
const form = reactive({ username: '', password: '' })
const loading = ref(false)

const rules: FormRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少 6 位', trigger: 'blur' }
  ]
}

async function submit() {
  const ok = await formRef.value?.validate().catch(() => false)
  if (!ok) return
  loading.value = true
  try {
    await auth.login(form)
    ElMessage.success('登录成功')
    router.replace((route.query.redirect as string) || '/dashboard')
  } catch (e) {
    ElMessage.error(e instanceof BizError ? e.msg : '登录失败')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-wrap { height: 100vh; display: flex; align-items: center; justify-content: center;
              background: linear-gradient(135deg, #EEF7F1 0%, #D0E2D6 100%); }
.login-card { width: 380px; padding: 20px 10px; }
.login-brand { display: flex; align-items: center; gap: 8px; margin-bottom: 20px;
               font-size: 18px; font-weight: 600; color: #5AA372; }
.submit-btn { width: 100%; }
</style>
```

### 5.6 升级 DefaultLayout：侧栏 + 顶栏

```vue
<template>
  <el-container class="app-container">
    <el-aside :width="collapsed ? '64px' : 'var(--app-sidebar-width)'">
      <div class="brand" :class="{collapsed}">
        <el-icon><Sunny /></el-icon>
        <span v-if="!collapsed">印想瑜伽后台</span>
      </div>
      <el-menu :default-active="route.path"
               :collapse="collapsed"
               router
               background-color="#1f2f27"
               text-color="#dbe6df"
               active-text-color="#ffffff">
        <el-menu-item index="/dashboard">
          <el-icon><HomeFilled /></el-icon><template #title>首页</template>
        </el-menu-item>
        <el-menu-item index="/members">
          <el-icon><User /></el-icon><template #title>会员管理</template>
        </el-menu-item>
        <el-menu-item index="/courses">
          <el-icon><Reading /></el-icon><template #title>课程管理</template>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="app-header">
        <el-icon class="collapse-btn" @click="collapsed = !collapsed">
          <Fold v-if="!collapsed" /><Expand v-else />
        </el-icon>
        <el-breadcrumb separator="/">
          <el-breadcrumb-item v-for="m in matched" :key="m.path" :to="m.path">
            {{ m.meta?.title }}
          </el-breadcrumb-item>
        </el-breadcrumb>
        <div class="flex-1" />
        <el-dropdown @command="onCmd">
          <span class="user-info">
            <el-avatar :size="28">{{ auth.realName?.[0] || 'U' }}</el-avatar>
            <span>{{ auth.realName || auth.username }}</span>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-header>

      <el-main class="app-main">
        <RouterView />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const auth = useAuthStore()
const route = useRoute()
const router = useRouter()
const collapsed = ref(false)

const matched = computed(() =>
  route.matched.filter(m => m.meta?.title)
)

async function onCmd(cmd: string) {
  if (cmd === 'logout') {
    await ElMessageBox.confirm('确认退出登录？', '提示', { type: 'warning' })
                      .catch(() => Promise.reject())
    await auth.logout()
    router.replace('/login')
  }
}
</script>

<style scoped>
.app-container { height: 100vh; }
.el-aside { background: #1f2f27; transition: width .2s; }
.brand { color: #fff; height: var(--app-header-height); display: flex;
         align-items: center; gap: 8px; padding: 0 16px; font-weight: 600; }
.app-header { display: flex; align-items: center; gap: 12px;
              border-bottom: 1px solid #eee; padding: 0 16px; background: #fff; }
.collapse-btn { cursor: pointer; font-size: 20px; }
.flex-1 { flex: 1; }
.user-info { display: flex; align-items: center; gap: 8px; cursor: pointer; }
.app-main { background: #f4f6f5; padding: 16px; }
</style>
```

### 5.7 四大常用组件速览

| 组件 | 用途 | 关键属性 |
|---|---|---|
| `<el-menu>` | 侧栏导航 | `router` `default-active` `collapse` |
| `<el-form>` | 表单 | `:model` `:rules` `<el-form-item prop>` `formRef.validate()` |
| `<el-table>` | 表格 | `:data` `<el-table-column prop label>` |
| `<el-pagination>` | 分页 | `v-model:current-page` `v-model:page-size` `:total` |

**两大 API**：

```ts
// 消息条（自动关闭）
ElMessage.success('保存成功')
ElMessage.error('保存失败')
ElMessage.warning('注意')
ElMessage.info('提示')

// 确认框（返回 promise，取消时 reject）
try {
  await ElMessageBox.confirm('确认删除？', '提示', { type: 'warning' })
  // 用户点了确定
} catch {
  // 用户点了取消——必须 catch，否则 unhandledRejection
}
```

**必栽的坑**：`ElMessageBox.confirm` 取消时 reject，必须 `.catch(()=>{})` 或 `try/catch`，否则浏览器 Console 会堆一堆 `Uncaught (in promise) cancel` 报错。

### 5.8 常见踩坑

1. **忘引 CSS**：`import 'element-plus/dist/index.css'` 漏掉 → 组件光秃秃没样式；
2. **只覆盖主色不覆盖 light 系列**：hover 时颜色回到蓝色；
3. **`el-menu default-active` 没绑当前路径**：刷新页面后菜单激活项丢失；
4. **`ElMessageBox.confirm` 忘 `.catch`**：Console 报 unhandledRejection。

### 5.9 本讲小结

按需自动引入 + CSS 变量覆盖 + Menu/Form/Table/Message 四大组件——UI 层从原型皮升级为交付级。下一讲把这些组件整合成一份完整的**会员列表 Demo**：搜索栏 + 分页表格 + 编辑 / 删除按钮，联上 Mock 数据。

---

## 第 6 讲：前端脚手架 + 目录规范 + 会员列表 Mock 联调

### 6.1 `src/` 八目录职责铁律

到 Day12 结束时，`yoga-admin/src/` 目录长这样：

```text
yoga-admin/
├── src/
│   ├── api/                   # 接口封装（一个业务一文件）
│   │   ├── request.ts         # axios 实例
│   │   ├── auth.ts
│   │   ├── member.ts
│   │   └── mock.ts            # mock 数据（可选）
│   ├── assets/                # 图片 + 全局样式
│   │   └── main.css
│   ├── components/            # 通用组件
│   │   ├── PageContainer.vue
│   │   ├── SearchBar.vue
│   │   └── ProTable.vue
│   ├── layouts/               # 布局组件
│   │   └── DefaultLayout.vue
│   ├── router/                # 路由
│   │   └── index.ts
│   ├── stores/                # Pinia
│   │   └── auth.ts
│   ├── utils/                 # 纯函数
│   │   ├── date.ts
│   │   └── dict.ts
│   ├── views/                 # 页面级组件
│   │   ├── login/LoginView.vue
│   │   ├── DashboardView.vue
│   │   ├── member/MemberListView.vue
│   │   ├── course/CourseListView.vue
│   │   └── NotFoundView.vue
│   ├── App.vue
│   └── main.ts
├── .env.development
├── .env.production
├── vite.config.ts
├── tsconfig.json
├── package.json
└── README.md
```

**职责铁律**：
- `api/` **只做接口**，不放业务逻辑；
- `views/` **只写页面**，复用逻辑抽 `components/`；
- `stores/` **管全局状态**，不写业务方法（业务写在 view 里调 store）；
- `utils/` **无副作用纯函数**，不能引用 store（避免循环依赖）；
- `components/` **通用组件**，不与具体业务耦合（不能里面写 `import { memberApi }`）。

### 6.2 通用组件三件套

#### PageContainer.vue：统一页面外框

```vue
<!-- src/components/PageContainer.vue -->
<template>
  <div class="page">
    <div class="page-head" v-if="title || $slots.actions">
      <div class="page-title">
        <el-icon v-if="back" class="back" @click="$router.back()">
          <ArrowLeft />
        </el-icon>
        <span>{{ title }}</span>
      </div>
      <div class="page-actions"><slot name="actions" /></div>
    </div>
    <div class="page-body"><slot /></div>
  </div>
</template>

<script setup lang="ts">
defineProps<{ title?: string; back?: boolean }>()
</script>

<style scoped>
.page       { padding: 0; }
.page-head  { display: flex; align-items: center; margin-bottom: 12px; }
.page-title { font-size: 16px; font-weight: 600;
              display: flex; gap: 8px; align-items: center; }
.back       { cursor: pointer; }
.page-actions { margin-left: auto; display: flex; gap: 8px; }
.page-body  { background: #fff; border-radius: 6px; padding: 16px; }
</style>
```

#### SearchBar.vue：搜索表单

```vue
<!-- src/components/SearchBar.vue -->
<template>
  <el-form :inline="true" :model="model" class="search-bar"
           @submit.prevent="onSearch">
    <slot />
    <el-form-item>
      <el-button type="primary" @click="onSearch">
        <el-icon><Search /></el-icon>查询
      </el-button>
      <el-button @click="onReset">
        <el-icon><Refresh /></el-icon>重置
      </el-button>
    </el-form-item>
  </el-form>
</template>

<script setup lang="ts">
const props = defineProps<{ model: Record<string, any> }>()
const emit = defineEmits<{
  (e: 'search'): void
  (e: 'reset'): void
}>()

function onSearch() { emit('search') }
function onReset() {
  for (const k of Object.keys(props.model)) props.model[k] = undefined
  emit('reset')
}
</script>

<style scoped>
.search-bar { padding: 8px 4px 0; }
</style>
```

#### ProTable.vue：一站式分页表格

```vue
<!-- src/components/ProTable.vue -->
<template>
  <div>
    <el-table :data="data" v-loading="loading" border stripe
              @selection-change="v => emit('selectionChange', v)"
              @sort-change="onSort">
      <slot />
    </el-table>
    <el-pagination class="pager"
      background layout="total, sizes, prev, pager, next, jumper"
      :page-sizes="[10, 20, 50, 100]"
      :total="total"
      v-model:current-page="pageInfo.pageNum"
      v-model:page-size="pageInfo.pageSize"
      @size-change="refresh"
      @current-change="refresh" />
  </div>
</template>

<script setup lang="ts" generic="T">
import { reactive, ref } from 'vue'

const props = defineProps<{
  loader: (params: any) => Promise<{ total: number; records: T[] }>
  query?: Record<string, any>
}>()
const emit = defineEmits<{
  (e: 'selectionChange', v: T[]): void
}>()

const data = ref<T[]>([])
const total = ref(0)
const loading = ref(false)
const pageInfo = reactive({ pageNum: 1, pageSize: 10, sortBy: '', sortDir: '' })

async function refresh() {
  loading.value = true
  try {
    const r = await props.loader({ ...(props.query || {}), ...pageInfo })
    data.value = r.records
    total.value = r.total
  } finally {
    loading.value = false
  }
}

function onSort({ prop, order }: any) {
  pageInfo.sortBy = prop || ''
  pageInfo.sortDir = order === 'ascending' ? 'asc'
                   : order === 'descending' ? 'desc' : ''
  pageInfo.pageNum = 1
  refresh()
}

defineExpose({
  refresh,
  resetToFirst() { pageInfo.pageNum = 1; refresh() }
})

refresh()      // 首次加载
</script>

<style scoped>
.pager { margin-top: 12px; justify-content: flex-end; display: flex; }
</style>
```

**这三份代码是本教程赠送的底件**，后面所有列表页都直接组合它们。

### 6.3 Mock 数据方案

现实中常见三个方案：

| 方案 | 优点 | 缺点 |
|---|---|---|
| `vite-plugin-mock` | 写法像 express，dev 时生效 | 引入额外插件 |
| `msw` | Service Worker，dev/prod 都能拦 | 稍复杂，需注册 sw |
| **手写 mock 函数** | 零依赖，最简 | 需要在 API 里加分支判断 |

本教程选**方案 3**：最简、最直白，后端就绪后一行删除 mock 分支即可。

`.env.development` 加：

```env
VITE_USE_MOCK = true
```

`src/api/mock.ts`：

```ts
import type { MemberVO, PageResult } from './member'

const seed: MemberVO[] = Array.from({ length: 87 }, (_, i) => ({
  id: i + 1,
  name: `会员${i + 1}`,
  phone: `139${String(10000000 + i).padStart(8, '0')}`,
  status: (i % 3 === 0 ? 2 : 1)
}))

export function mockMembersPage(q: any): Promise<PageResult<MemberVO>> {
  let list = seed
  if (q.name) list = list.filter(m => m.name.includes(q.name))
  if (q.phone) list = list.filter(m => m.phone.includes(q.phone))
  const pageNum = q.pageNum || 1
  const pageSize = q.pageSize || 10
  const start = (pageNum - 1) * pageSize
  return new Promise(resolve => setTimeout(
    () => resolve({
      total: list.length,
      records: list.slice(start, start + pageSize)
    }),
    200        // 模拟 200ms 网络延时
  ))
}
```

`src/api/member.ts` 加分支：

```ts
import request from './request'
import { mockMembersPage } from './mock'

export interface MemberVO {
  id: number
  name: string
  phone: string
  status: number
}
export interface PageResult<T> { total: number; records: T[] }

export const memberApi = {
  page: (q: any): Promise<PageResult<MemberVO>> => {
    if (import.meta.env.VITE_USE_MOCK === 'true') {
      return mockMembersPage(q)
    }
    return request.get('/members', { params: q })
  }
}
```

**后端就绪后**：把 `.env.development` 的 `VITE_USE_MOCK` 改成 `false`，或直接删除 `member.ts` 里的分支——**主流程零改动**。

### 6.4 会员列表页 Demo

`src/views/member/MemberListView.vue`：

```vue
<template>
  <PageContainer title="会员管理">
    <template #actions>
      <el-button type="primary" @click="onCreate">
        <el-icon><Plus /></el-icon>新增会员
      </el-button>
    </template>

    <SearchBar :model="q" @search="onSearch" @reset="onSearch">
      <el-form-item label="姓名">
        <el-input v-model="q.name" placeholder="姓名模糊" clearable />
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="q.phone" placeholder="手机号模糊" clearable />
      </el-form-item>
    </SearchBar>

    <ProTable ref="tableRef" :loader="memberApi.page" :query="q">
      <el-table-column prop="id"    label="ID"   width="80" />
      <el-table-column prop="name"  label="姓名" />
      <el-table-column prop="phone" label="手机号" />
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'warning'">
            {{ row.status === 1 ? '正常' : '冻结' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="160">
        <template #default="{ row }">
          <el-button size="small" @click="onEdit(row)">编辑</el-button>
          <el-button size="small" type="danger" @click="onDel(row)">删除</el-button>
        </template>
      </el-table-column>
    </ProTable>
  </PageContainer>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import PageContainer from '@/components/PageContainer.vue'
import SearchBar from '@/components/SearchBar.vue'
import ProTable from '@/components/ProTable.vue'
import { memberApi, type MemberVO } from '@/api/member'

const q = reactive({ name: '', phone: '' })
const tableRef = ref()

function onSearch() {
  tableRef.value?.resetToFirst()
}
function onCreate() {
  ElMessage.info('新增功能后续讲')
}
function onEdit(row: MemberVO) {
  ElMessage.info('编辑：' + row.name)
}
async function onDel(row: MemberVO) {
  await ElMessageBox.confirm(`确定删除「${row.name}」？`, '提示',
                             { type: 'warning' })
                    .catch(() => Promise.reject())
  ElMessage.success('已删除（mock）')
  tableRef.value?.refresh()
}
</script>
```

### 6.5 试跑

`pnpm dev` → 登录后进入「会员管理」页面，你会看到：

1. 默认 10 条数据 + 分页控件 + 总数 87；
2. 在「姓名」框输入「会员 1」→ 点查询 → 结果只剩包含「会员 1」的行；
3. 点「编辑」按钮 → 右上 toast「编辑：会员 1」；
4. 点「删除」按钮 → 弹确认框 → 点确定 → toast「已删除」+ 表格刷新；
5. 点分页 2 → 显示第 11–20 条数据；
6. 页面右上「新增会员」按钮 → toast「新增功能后续讲」。

**至此 Day12 交付物完整**：一份可运行的 `yoga-admin` 项目，会员列表 Demo 上线。

### 6.6 交付：打包 + README

**打包**：

```bash
pnpm build         # 生成 dist/
pnpm preview       # 本地 4173 端口验证
```

`dist/` 产物：
- `dist/index.html`（体积小，只挂 script）；
- `dist/assets/index-xxxxxxxx.js`（主 chunk）；
- `dist/assets/LoginView-xxxxxxxx.js`（懒加载 chunk）；
- `dist/assets/MemberListView-xxxxxxxx.js`；
- `dist/assets/index-xxxxxxxx.css`。

**README.md 模板**：

````markdown
# yoga-admin

印想瑜伽会馆客户管理系统 · 管理后台前端

## 快速开始

```bash
# 前置：Node.js 20 LTS + pnpm 9.x
pnpm install
pnpm dev            # 开发环境 http://localhost:5173
pnpm build          # 打包
pnpm preview        # 本地预览打包产物
```

## 目录结构

```text
src/
├── api/         接口封装（一个业务一文件）
├── assets/      图片 + 全局样式
├── components/  通用组件
├── layouts/     布局
├── router/      路由
├── stores/      Pinia
├── utils/       纯函数
└── views/       页面
```

## 联调说明

- 后端地址由 `.env.*` 的 `VITE_API_BASE` 控制
- 开发环境 Vite 代理 `/api/**` → `http://localhost:8080`
- Mock 开关：`.env.development` 的 `VITE_USE_MOCK`（`true` 走 mock，`false` 走真接口）
````

### 6.7 常见踩坑

1. **把 mock.ts 写在 views/ 或 stores/ 里**：违反目录职责，mock 也属于 api 层；
2. **`ElMessageBox.confirm` 忘 `.catch`**：Console 堆 unhandledRejection；
3. **`ProTable` 的 `loader` 传成 `memberApi.page(q)`**：错，应该传函数引用 `memberApi.page`——加 `()` 就是**立即调用**了；
4. **`resetToFirst()` 忘调**：查询后停在第 N 页，用户以为没结果；
5. **README 不写**：前端项目可交付性 = 代码 + 文档，缺一不可。

### 6.8 本讲小结

至此 Day12 六讲全部完成：

- **第 1 讲**：Vite 建 yoga-admin，环境变量与代理就位；
- **第 2 讲**：组合式 API 四件套（ref / reactive / computed / watch）；
- **第 3 讲**：VueRouter 4 + 导航守卫；
- **第 4 讲**：Axios 二次封装 + Pinia auth store，登录闭环打通；
- **第 5 讲**：Element Plus 按需引入 + 侧栏顶栏布局 + 登录页升级；
- **第 6 讲**：目录八件套 + 三件通用组件 + 会员列表 Mock Demo。

**你现在拥有的**：一个可运行、可打包、可交付的 `yoga-admin` 前端项目。之后 Day13 起，我们把会员、教练、课程、预约四大业务前端全部铺开，并逐一联调 Day01–Day11 的后端接口。这个底座会一路支撑到 Day18 交付上线。

---

## Day12 结语

前端从零到一的一天，你从只会写 HTML+CDN 的水平，升级到了能独立搭一份工程化 Vue 3 项目的开发者。这不是一门 Vue 教程的终点，而是**印想瑜伽会馆全栈项目**的关键中点：后端在 8080、前端在 5173，两者用 JWT + Result 契约对上号，登录 → dashboard → 会员管理这条链路已经跑通。Day13 起，前后端联调的强度会明显加大——祝你稳住这份底座。
