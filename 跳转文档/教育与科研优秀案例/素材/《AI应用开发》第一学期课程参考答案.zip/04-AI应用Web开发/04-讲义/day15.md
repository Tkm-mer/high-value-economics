# 《AI 应用 Web 开发》 - 学生讲义（Day15：JWT 登录前端 + Nginx 部署 + Linux 基础）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day14 的学生（掌握 Spring Boot 4.0.x 后端全链路、JWT 后端签发与拦截器、Vue 3 + TypeScript + Pinia + Vue Router + Element Plus 全部前端页面、Axios 封装、ECharts、表单校验）**

**技术版本基线**：Spring Boot 4.0.x / Java 25 / Vue 3.5+ / Vite 5.4+ / Pinia 2.2+ / Vue Router 4.4+ / Axios 1.7+ / Element Plus 2.8+ / Ubuntu 22.04 LTS / Nginx 1.24 / OpenJDK 25 / MySQL 8.0 / IDEA 2024.3+ / 通义灵码 + Trae。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day13–Day14 完成 8 大业务页面之后，「本地能跑」到「用户打开浏览器就能用」还差最后一公里。Day15 前 3 讲把「登录前端闭环」补齐：登录页 + 验证码 + Pinia AuthStore + Axios 双拦截 + 路由守卫 + 401 兜底跳转 + 不活跃自登出；第 4 讲把 `pnpm build` 打出的 `dist/` 目录逐字节讲透——`manualChunks` 拆包、`hash` 长缓存、`index.html` 不缓存；第 5–6 讲把项目搬上 Ubuntu 22.04 服务器：SSH 密钥登录、`apt` 装 JDK / MySQL / Nginx、Nginx 反向代理 `/api/` + SPA fallback、`systemd` 托管 Jar、`deploy.sh` 一键部署。**Day15 结束后手里的作品链接可以直接投到简历**。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 登录页开发（表单 + 验证码 + 提交） | `LoginView.vue` 完整实现，打通「拿 Token」 |
| 第 2 讲 | JWT 存储 + Axios 注入 + 401 拦截 | `stores/auth.ts` + `api/request.ts` 双拦截 |
| 第 3 讲 | 路由守卫 + 退出 + 不活跃自登出 | `router.beforeEach` 三段判断 + `v-perm` 按钮级权限 |
| 第 4 讲 | Vue 项目打包 + dist 分析 | `manualChunks` 分包 + hash 长缓存 |
| 第 5 讲 | Linux 基础 + SSH + 装机 | 密钥登录 + `apt` 装 JDK/MySQL/Nginx |
| 第 6 讲 | Nginx 反代 + 静态部署 + systemd | 一份 Nginx 配置 + `yoga.service` + `deploy.sh` |

---

## 第 1 讲：登录页开发（表单 + 验证码 + 提交）

### 1.1 引入：从「后台能跑」到「有一张能登录的脸」

Day14 结尾的项目：8 大业务页面写完了，能用 Postman 拿 Token 手动放到 Header 联调。但把项目给别人看的时候，一打开 `/courses` 就看到一片空白 + 一堆 401——**用户找不到入口**。

🎯 **一句话目标**：**把登录页从「一张 UI 稿」推进到「能真把 Token 拿回来的能用页面」**。

登录接口的两次握手时序：

```
① 页面加载：
   GET  /api/auth/captcha
   ⇐ { key: \"abc123\", image: \"data:image/png;base64,...\" }

② 用户输完账号密码 + 验证码：
   POST /api/auth/login
   { username, password, captchaKey: \"abc123\", captchaCode: \"AB12\" }
   ⇐ { token: \"eyJhbGciOiJIUzI1NiJ9...\", user: { username, roles, perms } }
```

🎯 **一次性 key**：`captchaKey` 由后端签发，提交一次即失效。**同一个 key 提交两次**会返回 400——防重放攻击。

### 1.2 定义 DTO 与 API

`src/api/auth.ts`：

```ts
import request from './request'

export interface LoginDTO {
  username:    string
  password:    string
  captchaKey:  string
  captchaCode: string
}

export interface UserInfoVO {
  id:       number
  username: string
  realName: string
  avatar?:  string
  roles:    string[]
  perms:    string[]
}

export interface CaptchaVO {
  key:   string   // 一次性 UUID
  image: string   // data:image/png;base64,....
}

export const authApi = {
  captcha: () => request.get<any, CaptchaVO>('/auth/captcha'),
  login:   (dto: LoginDTO) =>
    request.post<any, { token: string; user: UserInfoVO }>('/auth/login', dto),
  logout:  () => request.post<any, void>('/auth/logout'),
  me:      () => request.get<any, UserInfoVO>('/auth/me')
}
```

🎯 **字段名与后端严格对齐**：`captchaKey` / `captchaCode`（不是 `captcha_key`），驼峰命名。后端 DTO 用 `@JsonNaming` 或前端约定一致——**契约先定、代码后写**。

### 1.3 `LoginView.vue` 完整实现

```vue
<script setup lang=\"ts\">
import { reactive, ref, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import type { FormInstance, FormRules } from 'element-plus'
import { authApi, type LoginDTO } from '@/api/auth'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const route  = useRoute()
const auth   = useAuthStore()

const form = reactive<LoginDTO>({
  username:    '',
  password:    '',
  captchaKey:  '',
  captchaCode: ''
})

const captchaImg = ref('')
const submitting = ref(false)
const formRef    = ref<FormInstance>()

const rules: FormRules<LoginDTO> = {
  username:    [{ required: true, message: '请输入账号', trigger: 'blur' }],
  password:    [{ required: true, message: '请输入密码', trigger: 'blur' },
                { min: 6, max: 20, message: '密码 6-20 位', trigger: 'blur' }],
  captchaCode: [{ required: true, message: '请输入验证码', trigger: 'blur' },
                { len: 4, message: '验证码 4 位', trigger: 'blur' }]
}

async function refreshCaptcha() {
  const r = await authApi.captcha()
  form.captchaKey  = r.key       // ⚠️ key 与 image 必须原子替换
  captchaImg.value = r.image
  form.captchaCode = ''          // 用户重新输
}

onMounted(refreshCaptcha)

async function onSubmit() {
  try {
    await formRef.value?.validate()
  } catch { return }             // 校验未通过

  submitting.value = true
  try {
    await auth.login(form)
    ElMessage.success('登录成功')
    const redirect = (route.query.redirect as string) || '/dashboard'
    router.replace(redirect)
  } catch (e: any) {
    // ⚠️ 统一提示，不透露具体原因防用户名枚举
    ElMessage.error(e?.message || '账号或密码错误')
    refreshCaptcha()              // 一次性 key 已消耗，立即刷新
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <div class=\"login-page\">
    <el-form
      ref=\"formRef\"
      class=\"login-form\"
      :model=\"form\"
      :rules=\"rules\"
      label-position=\"top\"
      @keyup.enter=\"onSubmit\"
    >
      <h2 class=\"title\">印想瑜伽 · 管理后台</h2>

      <el-form-item label=\"账号\" prop=\"username\">
        <el-input v-model=\"form.username\" placeholder=\"请输入账号\" clearable />
      </el-form-item>

      <el-form-item label=\"密码\" prop=\"password\">
        <el-input v-model=\"form.password\" type=\"password\" show-password placeholder=\"请输入密码\" />
      </el-form-item>

      <el-form-item label=\"验证码\" prop=\"captchaCode\">
        <div class=\"captcha-row\">
          <el-input v-model=\"form.captchaCode\" placeholder=\"4 位字符\" maxlength=\"4\" />
          <img
            class=\"captcha-img\"
            :src=\"captchaImg\"
            alt=\"验证码\"
            title=\"点击刷新\"
            @click=\"refreshCaptcha\"
          />
        </div>
      </el-form-item>

      <el-button type=\"primary\" class=\"btn-login\" :loading=\"submitting\" @click=\"onSubmit\">
        登 录
      </el-button>
    </el-form>
  </div>
</template>

<style scoped>
.login-page      { min-height: 100vh; display: flex; align-items: center; justify-content: center;
                   background: linear-gradient(135deg, #667eea, #764ba2); }
.login-form      { width: 380px; padding: 32px 28px; background: #fff; border-radius: 8px;
                   box-shadow: 0 8px 24px rgba(0,0,0,.12); }
.title           { text-align: center; margin: 0 0 24px; color: #303133; }
.captcha-row     { display: flex; gap: 12px; align-items: center; width: 100%; }
.captcha-img     { height: 40px; width: 120px; cursor: pointer; border: 1px solid #dcdfe6;
                   border-radius: 4px; }
.btn-login       { width: 100%; margin-top: 8px; }
</style>
```

### 1.4 关键设计点

**`reactive` vs `ref`**：`el-form` 的 `:model` 属性**只接受响应式对象**。`reactive({...})` 直接暴露字段（`form.username`），`ref({...})` 需要 `.value.username` 解引用，`el-form` 内部不会自动解——所以**表单模型必须用 `reactive`**。

**校验规则 `trigger`**：
- `blur`：失焦时校验——适合输入类字段
- `change`：值变化时校验——适合下拉、单选、多选
- 两者可以同时传数组：`trigger: ['blur', 'change']`

**Promise 化 `validate`**：Element Plus 3.x 的 `validate()` 返回 `Promise<boolean>`——`await` 后再判断，语法比回调式清爽。如果校验失败会 `reject`，用 `try/catch` 包住。

**回车提交**：`el-form` 上加 `@keyup.enter=\"onSubmit\"`——用户按回车不用鼠标点。

**loading 状态**：`:loading=\"submitting\"` 绑到按钮——按下后 spinner + disable，防止双击提交。

### 1.5 反面案例：漏 `captchaKey` 会发生什么

如果 `refreshCaptcha` 里忘记赋值 `form.captchaKey = r.key`：

1. 第一次登录：`form.captchaKey` 是空串 → 后端 400；
2. 用户点图刷新 → `captchaImg` 换了但 `key` 还是空；
3. 用户第二次输 → 依然 400；
4. 用户懵。

🎯 **原子操作原则**：`key` 与 `image` 是一对孪生变量，任何一次更新都必须**同时**替换。这类「变量组必须原子更新」的模式在前端很常见——分页的 `total / list / pageNum`、多选的 `selectedIds / selectedRows`。

### 1.6 常见 AI 生成错误清单

1. `form` 用 `ref` 而不是 `reactive`——`el-form` 校验拿不到，控制台无报错但按钮点了没反应；
2. 验证码用 `<img :src=\"/api/auth/captcha\">` 直接拉——每次校验都请求一次，浪费带宽且服务端一次性 key 不生效；
3. 忘 `@keyup.enter`——用户体验掉一档；
4. 登录失败 `ElMessage.error(err.msg)` 把「用户不存在」原样透传——**账号枚举漏洞**，攻击者可以试出哪些用户名存在；
5. `refreshCaptcha` 挪到 `onBeforeMount` 而不是 `onMounted`——`ref` 还没绑上，虽然当前场景没差别但不严谨。

### 1.7 联调三种场景

| 场景 | 表现 | 排查点 |
|---|---|---|
| ✅ 账号正确 | 200 → 跳 `/dashboard` | Network 面板 Response 里有 `token` |
| ❌ 密码错 | 400 → 提示「账号或密码错误」 | 后端返回 `{code:1001,msg:\"...\"}` |
| ❌ 验证码错 | 400 → 提示 + 自动刷新验证码 | 检查 `captchaKey` 是否随提交发过去 |
| ❌ 网络断 | Axios timeout → 提示「网络异常」 | Network 面板红色 |

---

## 第 2 讲：JWT 存储 + Axios 注入 + 401 拦截

### 2.1 引入：Token 拿到手了，然后呢？

第 1 讲结束时，`auth.login(form)` 里已经拿到 `token`。但如果只把它塞进 `authStore.token` 这个内存变量——**刷新页面就没了**。此外用户跳到 `/courses` 后，Axios 发的请求头里**没有 Authorization**，后端返 401。

🎯 **一句话目标**：**让 Token 一次登录、全项目自动带；一次过期、全项目跳登录**。

### 2.2 `useAuthStore`：Pinia + localStorage 兜底

`src/stores/auth.ts`：

```ts
import { defineStore } from 'pinia'
import { authApi, type LoginDTO, type UserInfoVO } from '@/api/auth'

const TOKEN_KEY = 'yx_token'
const USER_KEY  = 'yx_user'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem(TOKEN_KEY) || '',
    user:  JSON.parse(localStorage.getItem(USER_KEY) || 'null') as UserInfoVO | null,
    permCache: null as Set<string> | null
  }),

  getters: {
    isLoggedIn: s => !!s.token,
    username:   s => s.user?.username || '',
    realName:   s => s.user?.realName || '',
    roles:      s => s.user?.roles || [],
    perms:      s => s.user?.perms || []
  },

  actions: {
    async login(dto: LoginDTO) {
      const r = await authApi.login(dto)
      this.token = r.token
      this.user  = r.user
      this.permCache = new Set(r.user.perms)
      localStorage.setItem(TOKEN_KEY, r.token)
      localStorage.setItem(USER_KEY,  JSON.stringify(r.user))
    },

    async logout() {
      try { await authApi.logout() } catch { /* 忽略网络错误 */ }
      this.clear()
    },

    clear() {
      this.token = ''
      this.user  = null
      this.permCache = null
      localStorage.removeItem(TOKEN_KEY)
      localStorage.removeItem(USER_KEY)
    },

    hasPerm(code: string): boolean {
      if (!this.permCache) this.permCache = new Set(this.user?.perms || [])
      return this.permCache.has(code) || this.permCache.has('*')
    }
  }
})
```

🎯 **`state` 是工厂函数**：`state: () => ({...})`——每次创建 store 时执行一次。**这里读一次 `localStorage`** 就是刷新页面兜底的关键，不放这里放哪里？答案：只能放这里，因为 Pinia 初始化时机就在这。

🎯 **key 前缀 `yx_`**：避免与同域下其他项目（其他子项目也用 `token` 做 key）冲突。

🎯 **`permCache` 用 `Set`**：Vue 项目里权限校验会被调很多次，`Set.has()` O(1) 比 `Array.includes()` O(n) 快得多；`clear()` 时置 `null`——下次 `hasPerm` 触发懒重建。

### 2.3 Axios 请求 / 响应双拦截

`src/api/request.ts`：

```ts
import axios, { AxiosError } from 'axios'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import router from '@/router'

export class BizError extends Error {
  constructor(public code: number, public msg: string) {
    super(msg)
    this.name = 'BizError'
  }
}

const instance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 15000
})

// ---------- 请求拦截 ----------
instance.interceptors.request.use(cfg => {
  const auth = useAuthStore()
  if (auth.token) {
    cfg.headers.Authorization = `Bearer ${auth.token}`
  }
  return cfg                  // ⚠️ 必须 return，否则请求发不出去
})

// ---------- 响应拦截 ----------
let redirecting = false       // 模块级布尔，防并发洪水

instance.interceptors.response.use(
  resp => {
    // blob 响应（下载）直接返回
    if (resp.config.responseType === 'blob') return resp.data

    const body = resp.data
    if (body && typeof body === 'object' && 'code' in body) {
      if (body.code === 0) return body.data
      throw new BizError(body.code, body.msg || '业务错误')
    }
    return body
  },

  async (err: AxiosError<any>) => {
    // 401：Token 过期或无效
    if (err.response?.status === 401 && !redirecting) {
      redirecting = true
      useAuthStore().clear()
      ElMessage.warning('登录已过期，请重新登录')
      await router.replace({
        path:  '/login',
        query: { redirect: router.currentRoute.value.fullPath }
      })
      redirecting = false
      return Promise.reject(new BizError(401, '未登录'))
    }

    // 其他错误
    if (err.response?.data?.msg) {
      throw new BizError(err.response.data.code ?? -1, err.response.data.msg)
    }
    throw new BizError(-1, err.message || '网络异常')
  }
)

export default instance
```

### 2.4 逐段解读

**请求拦截**只做两件事：拿 `authStore.token` → 塞 `Authorization` 头。**必须 `return cfg`**，忘写请求会挂在 pending 状态。

`useAuthStore()` **只能在函数体内调**——放到模块顶层会在 Pinia 初始化前执行，报「no active pinia」。

**响应拦截**三段判断：
1. `blob`（下载）→ 原样返回，不做 JSON 解析；
2. 后端 `Result` 结构 `{ code, data, msg }`：`code === 0` 拆包返回 `data`；`code !== 0` 抛 `BizError` 让业务代码 `try/catch` 捕获；
3. 其他响应（如第三方 API 直接返 JSON）→ 原样返回。

**401 兜底**：
- `clear()`：Pinia + localStorage 全清；
- `ElMessage.warning`：提示用户；
- `router.replace`（不是 `push`）：不留历史记录，用户按后退不会回到 401 页；
- `query.redirect`：登录后回原页。

### 2.5 `redirecting` 全局开关：防 401 洪水

场景：进入 Dashboard 页，`onMounted` 里并发调了 5 个接口。如果 Token 已经过期，5 个接口都会 401 触发拦截器。**如果没有 `redirecting`**：

- `ElMessage.warning` 弹 5 次；
- `router.replace('/login')` 走 5 次（Vue Router 会去重但触发多次 hook）；
- Pinia `clear()` 调 5 次（幂等但浪费）；
- 用户看到屏幕上抖动 + 5 层 message 叠加。

**加了 `redirecting`**：第 1 个 401 进入分支后设置 `true`，后续 4 个进入拦截器时 `!redirecting` 为 `false` 直接跳过——**只弹一次、只跳一次**。

🎯 为什么是模块级变量而不是 store 字段？因为它是**跨请求共享的临时状态**，不是业务意义上的 state（比如「用户」「Token」）。放 store 里语义混乱。

### 2.6 联调验证

**成功路径**：
1. `/login` 登录 → Network 看到 `POST /api/auth/login 200`；
2. 跳 `/dashboard` → Network 里每个 `/api/*` 请求 Header 有 `Authorization: Bearer eyJ...`；
3. F12 → Application → Local Storage → 看到 `yx_token`、`yx_user`；
4. 刷新页面 → 依然登录着（localStorage 兜底生效）。

**过期路径**：
1. F12 手动 `localStorage.setItem('yx_token', 'aaa')` 篡改 Token；
2. 刷新 → 一次 `ElMessage.warning`，跳 `/login?redirect=/dashboard`；
3. 重新登录 → 自动回到 `/dashboard`。

### 2.7 常见 AI 生成错误清单

1. 没考虑并发——每个 401 请求都跳一次；
2. 用 `window.location.href` 而不是 `router.replace`——全页刷新，Pinia 状态丢；
3. `err.response` 没做 `?.` 可选链，网络断线时 `err.response is undefined` 又崩一次；
4. `useAuthStore()` 放在模块顶层——报「no active pinia」；
5. `state: { token: ... }` 写成对象而不是工厂函数——多个组件共享同一份对象。

### 2.8 双 Token 机制（选做）

生产项目通常用 Access Token（15 分钟）+ Refresh Token（7 天）双 Token。响应拦截升级：

```ts
async (err: AxiosError<any>) => {
  const origReq = err.config
  if (err.response?.status === 401 && !origReq._retry) {
    origReq._retry = true
    try {
      const newToken = await refreshToken()   // 用 refresh 换新 access
      origReq.headers.Authorization = `Bearer ${newToken}`
      return instance(origReq)                // 重放原请求
    } catch {
      useAuthStore().clear()
      router.replace('/login')
      throw new BizError(401, '登录已过期')
    }
  }
  // ...
}
```

🎯 **`_retry` 标记**：防止 refresh 本身也 401 触发无限循环。

---

## 第 3 讲：路由守卫 + 退出 + 不活跃自登出

### 3.1 引入：让浏览器换 URL 前先过一道大脑

第 2 讲结束时——Axios 401 会跳登录，但用户体验是「先看到 layout 骨架 → 接口 401 弹提示 → 才跳登录」，中间会闪一下。**在路由进入前**就判断有没有登录才是真本事。

🎯 **一句话目标**：**让浏览器换 URL 时先过一道大脑再显示页面——未登录跳登录、无权限跳首页**。

### 3.2 定义路由 + `meta` 元信息

`src/router/index.ts`：

```ts
import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import DefaultLayout from '@/layouts/DefaultLayout.vue'

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    component: () => import('@/views/login/LoginView.vue'),
    meta: { public: true, title: '登录' }
  },
  {
    path: '/',
    component: DefaultLayout,
    redirect: '/dashboard',
    children: [
      { path: 'dashboard', component: () => import('@/views/DashboardView.vue'),
        meta: { title: '首页' } },
      { path: 'members',   component: () => import('@/views/member/MemberListView.vue'),
        meta: { title: '会员管理', perm: 'member:view' } },
      { path: 'coaches',   component: () => import('@/views/coach/CoachListView.vue'),
        meta: { title: '教练管理', perm: 'coach:view' } },
      { path: 'rooms',     component: () => import('@/views/room/RoomListView.vue'),
        meta: { title: '教室管理', perm: 'room:view' } },
      { path: 'courses',   component: () => import('@/views/course/CourseListView.vue'),
        meta: { title: '课程管理', perm: 'course:view' } },
      { path: 'courses/edit/:id?', component: () => import('@/views/course/CourseEditView.vue'),
        meta: { title: '编辑课程', perm: 'course:edit' } },
      { path: 'bookings',  component: () => import('@/views/booking/BookingListView.vue'),
        meta: { title: '预约管理', perm: 'booking:view' } },
      { path: 'logs',      component: () => import('@/views/opLog/OpLogListView.vue'),
        meta: { title: '操作日志', perm: 'log:view' } }
    ]
  },
  {
    path: '/:pathMatch(.*)*',
    component: () => import('@/views/error/NotFound.vue'),
    meta: { public: true, title: '页面不存在' }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, _from) => {
  const auth = useAuthStore()
  // 副作用：更新浏览器标题
  document.title = `${to.meta.title || '后台'} | 印想瑜伽`

  // ① 白名单直接放行
  if (to.meta.public) return true

  // ② 未登录跳登录
  if (!auth.isLoggedIn) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }

  // ③ 权限码校验
  if (to.meta.perm && !auth.hasPerm(to.meta.perm as string)) {
    ElMessage.error('权限不足')
    return { path: '/dashboard' }
  }

  return true
})

export default router
```

### 3.3 `meta` 三层元信息

| 字段 | 值示例 | 作用 |
|---|---|---|
| `public` | `true` | 白名单，任何人可访问（登录、404） |
| `title` | `'会员管理'` | 浏览器标题 + 侧边栏菜单显示 |
| `perm` | `'member:view'` | 权限码，缺失时跳首页 |

🎯 **`meta` 继承**：Vue Router 4 里子路由的 `meta` **不会自动继承父路由的**——如果需要给整个 `/` 下的子路由都加 `meta.requiresAuth`，得每个子路由自己写。项目里我们用**白名单反向逻辑**（除了 `meta.public: true` 都要登录），避免重复。

🎯 **`return` 三形态**：
- `return true` 或 `undefined`：放行；
- `return false`：中止导航；
- `return { path, query? }`：跳到新路径。

🎯 **不要用 `router.push` 在守卫里跳转**——会造成守卫内套守卫，一定要用 `return`。

### 3.4 三层权限过滤

**路由级**：`meta.perm` 在守卫里兜底。

**菜单级**（侧边栏 `SidebarMenu.vue`）：

```vue
<el-menu-item
  v-if=\"auth.hasPerm('member:view')\"
  index=\"/members\"
>
  <el-icon><User /></el-icon>
  <span>会员管理</span>
</el-menu-item>
```

**按钮级**（自定义指令 `v-perm`）：

`src/directives/perm.ts`：

```ts
import type { Directive } from 'vue'
import { useAuthStore } from '@/stores/auth'

export const vPerm: Directive<HTMLElement, string> = {
  mounted(el, binding) {
    if (!useAuthStore().hasPerm(binding.value)) {
      el.parentNode?.removeChild(el)
    }
  }
}
```

`main.ts` 注册：

```ts
import { vPerm } from '@/directives/perm'
app.directive('perm', vPerm)
```

使用：

```vue
<el-button v-perm=\"'member:delete'\" type=\"danger\" @click=\"remove\">
  删除
</el-button>
```

🎯 **前端权限只是体验优化，后端才是最终防线**。攻击者可以直接调 API 绕过前端过滤，所以后端必须**每个接口都要拦截器 + 权限注解**。前端过滤的价值：让**合法用户**看不到无权限的按钮，避免点了报 403 的困惑。

### 3.5 退出登录

侧边栏用户下拉里：

```vue
<el-dropdown @command=\"handleCommand\">
  <span class=\"user\">
    <el-avatar :src=\"auth.user?.avatar\" />
    <span>{{ auth.realName }}</span>
  </span>
  <template #dropdown>
    <el-dropdown-menu>
      <el-dropdown-item command=\"profile\">个人资料</el-dropdown-item>
      <el-dropdown-item command=\"logout\" divided>退出登录</el-dropdown-item>
    </el-dropdown-menu>
  </template>
</el-dropdown>

<script setup lang=\"ts\">
async function handleCommand(cmd: string) {
  if (cmd === 'logout') {
    await ElMessageBox.confirm('确定退出登录吗？', '提示', { type: 'warning' })
    await auth.logout()
    router.push('/login')
  }
}
</script>
```

`auth.logout()` 内部流程：
1. 调后端 `/auth/logout`（后端把 Token 加 Redis 黑名单）；
2. `try/catch` 吞掉网络错误——**无论后端能否成功都要清本地**；
3. `clear()` 清 Pinia + localStorage；
4. 组件里 `router.push('/login')`。

### 3.6 不活跃自动登出

`App.vue`：

```vue
<script setup lang=\"ts\">
import { onMounted, onBeforeUnmount } from 'vue'
import { ElMessageBox, ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import { useRouter } from 'vue-router'

const auth   = useAuthStore()
const router = useRouter()

const IDLE_TIMEOUT = 30 * 60 * 1000     // 30 分钟
const WARNING_TIME =  1 * 60 * 1000     // 提前 1 分钟弹确认

let idleTimer:    ReturnType<typeof setTimeout> | null = null
let warningTimer: ReturnType<typeof setTimeout> | null = null

function resetTimer() {
  if (!auth.isLoggedIn) return          // 未登录不启动计时器

  if (idleTimer)    clearTimeout(idleTimer)
  if (warningTimer) clearTimeout(warningTimer)

  warningTimer = setTimeout(async () => {
    try {
      await ElMessageBox.confirm(
        '长时间未操作，1 分钟后自动登出',
        '登录状态即将过期',
        { confirmButtonText: '继续操作', cancelButtonText: '立即登出', type: 'warning' }
      )
      resetTimer()                       // 用户点「继续操作」重置
    } catch {
      forceLogout()                      // 用户点「立即登出」或超时
    }
  }, IDLE_TIMEOUT - WARNING_TIME)

  idleTimer = setTimeout(forceLogout, IDLE_TIMEOUT)
}

async function forceLogout() {
  await auth.logout()
  ElMessage.warning('已自动登出')
  router.push('/login')
}

const events = ['mousemove', 'keydown', 'click', 'scroll'] as const

onMounted(() => {
  events.forEach(evt => window.addEventListener(evt, resetTimer, { passive: true }))
  resetTimer()
})

onBeforeUnmount(() => {
  events.forEach(evt => window.removeEventListener(evt, resetTimer))
  if (idleTimer)    clearTimeout(idleTimer)
  if (warningTimer) clearTimeout(warningTimer)
})
</script>
```

🎯 **`{ passive: true }`**：告诉浏览器这个监听器不会 `preventDefault`——`scroll` / `touchmove` 类事件用 passive 能显著提升滚动性能。

🎯 **`onBeforeUnmount` 必须清理**：否则内存泄漏 + 计时器还在跑，很快就有奇怪 bug。

🎯 **只在登录后启动**：`resetTimer` 里先判 `auth.isLoggedIn`——未登录用户没必要计时。

### 3.7 反面案例：白名单遗漏 `/404`

如果 `NotFound.vue` 的路由没加 `meta.public: true`——未登录用户访问 `/random-path` 时：
1. 匹配到 `*` 通配路由；
2. `beforeEach` 判断 `!auth.isLoggedIn` → 跳 `/login`；
3. 登录后 `redirect=/random-path` → 又匹配到 404；
4. 404 页正常显示——**但用户以为自己访问了非法资源被强制登录了**。

🎯 白名单要**覆盖所有不需要登录的页面**：登录、404、公开分享页、隐私协议页等。

### 3.8 常见 AI 生成错误清单

1. 用 `next()` 老风格 API（Vue Router 4 已过时，直接 return 更清晰）；
2. 白名单漏 `/404` 造成 404 页登录死循环；
3. 不用 `redirect` 参数——登录后一律跳首页体验差；
4. `beforeEach` 里 `router.push('/login')`——守卫内套守卫；
5. 不活跃自登出忘了 `removeEventListener`——内存泄漏。

---

## 第 4 讲：Vue 项目打包（vite build）+ dist 分析

### 4.1 引入：从「本地能跑」到「Nginx 能托管」

前 3 讲代码在本地跑得飞起——`vite dev` 的 Proxy 把 `/api` 转到 8080，HMR 热更新秒生效。但**发布到服务器时**：
- 用户没有 5173 端口；
- 用户没有 Node.js；
- 用户浏览器只能拿静态文件（HTML/JS/CSS）。

`pnpm build` 就是把 Vue 单文件组件 + TypeScript + Sass 全部**编译打包**成浏览器能直接消化的静态资源。

🎯 **一句话目标**：**把 `pnpm dev` 环境的产物打包成 Nginx 能直接托管的 `dist/`，并把首屏包压到 500KB gzip 以下**。

### 4.2 环境变量：`.env.development` vs `.env.production`

Vite 按 `import.meta.env.MODE` 自动加载对应文件：
- `pnpm dev` → 读 `.env` + `.env.development` + `.env.development.local`
- `pnpm build` → 读 `.env` + `.env.production` + `.env.production.local`

`.env.development`：

```text
VITE_APP_TITLE=印想瑜伽 · 开发环境
VITE_API_BASE_URL=/api
```

`.env.production`：

```text
VITE_APP_TITLE=印想瑜伽 · 管理后台
VITE_API_BASE_URL=/api
```

🎯 **`VITE_` 前缀是必须的**：Vite 只把 `VITE_` 开头的变量注入客户端——**防止把敏感变量误暴露到前端**（比如 `DATABASE_PASSWORD` 就不该被前端读到）。

`vite dev` 里怎么把 `/api` 转发到 `http://localhost:8080`？`vite.config.ts` 里配 `server.proxy`：

```ts
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8080',
      changeOrigin: true,
      rewrite: p => p.replace(/^\/api/, '')
    }
  }
}
```

生产环境不再走 proxy——Nginx 会替代 Vite 的角色（第 6 讲）。

### 4.3 `vite.config.ts` 生产优化

```ts
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig(({ mode }) => ({
  plugins: [vue()],
  resolve: {
    alias: { '@': path.resolve(__dirname, 'src') }
  },
  base: '/',                                // 部署路径，子路径部署改 '/admin/'
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: p => p.replace(/^\/api/, '')
      }
    }
  },
  build: {
    outDir: 'dist',
    sourcemap: mode !== 'production',        // 生产不出 sourcemap 防泄漏
    chunkSizeWarningLimit: 800,              // 抑制警告（我们已经拆包了）
    rollupOptions: {
      output: {
        manualChunks: {
          'vue-vendor':     ['vue', 'vue-router', 'pinia'],
          'ele':            ['element-plus', '@element-plus/icons-vue'],
          'echarts-vendor': ['echarts', 'vue-echarts'],
          'utils':          ['axios', 'dayjs', 'lodash-es']
        }
      }
    }
  }
}))
```

### 4.4 逐段解读

**`base: '/'`**：应用挂在域名根路径。`index.html` 里的资源引用会变成 `/assets/xxx.js`。如果部署在子路径（如 `https://example.com/admin/`），要改成 `base: '/admin/'`，否则资源全部 404。

**`sourcemap: false`**：生产环境**不出 sourcemap** 有三个理由：
1. 产物大小几乎翻倍——`.js.map` 比 `.js` 还大；
2. **暴露源码结构**——攻击者能反推业务逻辑；
3. 出错时靠 Sentry + 内部保留的 sourcemap 就够了。

**`chunkSizeWarningLimit: 800`**：Rollup 默认 500KB 就警告，但 Element Plus 单个 chunk 就 620KB——**已经通过 `manualChunks` 拆到最小**，警告可以调高。

**`manualChunks`**：把大依赖手动拆包。**为什么要拆**：
- 首屏体验：4 个 chunk 浏览器并发下载（HTTP/2 更强）；
- 二次访问：`vue-vendor` 极少变——用户改一次业务代码只有 `index-xxx.js` 变，其他 3 个 chunk 命中缓存；
- 长期演进：升级 Vue 版本只影响 `vue-vendor.js`，不用重新下载 `ele.js`。

### 4.5 dist 产物解读

`pnpm build` 完成后：

```text
dist/
├─ index.html                                       (1.5KB)
├─ favicon.ico                                      (4.2KB)
└─ assets/
   ├─ index-a1b2c3d4.js                             (210KB)  ← 业务代码
   ├─ index-a1b2c3d4.css                            (48KB)
   ├─ vue-vendor-e5f6g7h8.js                        (89KB)   ← vue + router + pinia
   ├─ ele-i9j0k1l2.js                               (620KB)  ← Element Plus
   ├─ ele-i9j0k1l2.css                              (330KB)
   ├─ echarts-vendor-m3n4o5p6.js                    (410KB)  ← ECharts
   └─ utils-q7r8s9t0.js                             (58KB)
```

🎯 **文件名带 hash**：`vue-vendor-e5f6g7h8.js` 里的 `e5f6g7h8` 是**打包时算出的内容指纹**（默认取内容 hash 前 8 位）。文件内容变了 → hash 变了 → 文件名变了 → 浏览器不会命中旧缓存——**版本切换即时生效的物理基础**。

🎯 **`index.html` 里的引用**：

```html
<!doctype html>
<html>
  <head>
    <script type=\"module\" crossorigin src=\"/assets/index-a1b2c3d4.js\"></script>
    <link rel=\"modulepreload\" crossorigin href=\"/assets/vue-vendor-e5f6g7h8.js\">
    <link rel=\"modulepreload\" crossorigin href=\"/assets/ele-i9j0k1l2.js\">
    <link rel=\"stylesheet\" href=\"/assets/index-a1b2c3d4.css\">
  </head>
  <body><div id=\"app\"></div></body>
</html>
```

`modulepreload` 告诉浏览器**提前加载**这些依赖 chunk——首屏并发下载。

### 4.6 缓存策略：静态长缓存 + `index.html` 不缓存

配合 Nginx（第 6 讲）：

```nginx
location ~* ^/assets/.+\.(js|css|png|jpg|jpeg|gif|svg|woff2?)$ {
  expires 30d;
  add_header Cache-Control \"public, immutable\";
}

location = /index.html {
  add_header Cache-Control \"no-cache, no-store, must-revalidate\";
  add_header Pragma \"no-cache\";
  add_header Expires 0;
}
```

🎯 **`immutable`** 是新版 HTTP 缓存头——告诉浏览器「这个文件永远不会变，不用发 If-None-Match 校验」。因为 hash 变名，`immutable` 是安全的。

🎯 **`index.html` 强制 `no-cache`** 的原因：`index.html` 里引用的 chunk 文件名会随构建变化——如果浏览器缓存了旧 `index.html`，就会去请求旧 hash 的 JS/CSS，服务器上已经删了→ 404 白屏。

**版本切换三原则**：
1. 静态资源带 hash 长缓存——**性能**；
2. `index.html` 永不缓存——**即时切换**；
3. 每次上线**先传静态、后替换 `index.html`**——**避免半新半旧**。

### 4.7 `pnpm preview` 本地验证

```bash
pnpm build
pnpm preview           # 默认 4173 端口
```

`vite preview` 起一个**只做静态服务**的 HTTP 服务器——**HMR 关、Proxy 关**，行为与 Nginx 更接近。

如果 `preview` 页面能跑但 API 全 500——因为没有 Proxy 转发，需要提前起 Nginx 或改 `vite.config.ts` 的 `preview.proxy`。

### 4.8 分包收益量化

未分包：`index.js` 1.4MB → gzip 后 420KB → 首屏 3G 网络加载 ~2 秒。

分包后：
| Chunk | 大小 | gzip | 用途 |
|---|---|---|---|
| `index.js` | 210KB | 65KB | 业务代码，**每次上线变** |
| `vue-vendor.js` | 89KB | 32KB | Vue 全家桶，**极少变** |
| `ele.js` | 620KB | 180KB | Element Plus，**升级才变** |
| `echarts-vendor.js` | 410KB | 130KB | ECharts，**升级才变** |
| `utils.js` | 58KB | 20KB | 工具库，**极少变** |

**首次访问**：全下 → 1.38MB / 427KB gzip，与未分包相近。

**二次访问**：命中 4 个 vendor chunk 缓存 → 只下 `index.js` 65KB gzip → **网络流量减少 85%**。

🎯 **正确的分包不是「越细越好」**。分太细会导致 HTTP 请求数暴涨——特别是 HTTP/1.1 时代（1 个域名并发 6 个连接）。经验值：**首屏关键 chunk 3~6 个**。

### 4.9 常见 AI 生成错误清单

1. 把每个 `node_modules` 依赖单独一 chunk（HTTP 请求爆炸）；
2. 忘 `chunkSizeWarningLimit` 造成控制台警告刷屏；
3. 没开 `sourcemap: false`——生产泄漏源码；
4. `base` 不写默认 `/`——子路径部署时报 404；
5. `manualChunks` 用了函数形式却写错依赖判断——运行时报 `Cannot read property of undefined`。

---

## 第 5 讲：Linux 基础 + SSH + JDK / MySQL / Nginx 安装

### 5.1 引入：为什么要学 Linux

**生产环境 99% 的 Web 服务运行在 Linux**（Ubuntu、CentOS、阿里云 Linux 等）。哪怕你在 Windows 开发，最终代码要跑在 Linux 上。

学 Linux 不是要成为运维专家，而是能：
- 登录服务器
- 定位文件、看日志、启停进程
- 安装软件、开端口、给权限
- 读懂常见错误提示

本课程用 **Ubuntu 22.04 LTS**（阿里云、腾讯云均支持一键创建）。

🎯 **一句话目标**：**一台裸的 Ubuntu 22.04 变成能跑印想瑜伽项目的生产服务器**。

### 5.2 网络四层示意

```text
自己电脑 ─── ssh ───▶ 云服务商公网 IP:22
                         │
                         ▼
                 云安全组（22/80/443）
                         │
                         ▼
                 主机 ufw（22/80/443）
                         │
                         ▼
                 Nginx :80 → 上游 Java :8080
```

两道墙：**云安全组是外墙、ufw 是内墙**——两道都要开对应端口才能通。云厂商界面上开安全组，主机内 `ufw` 命令行操作。

### 5.3 SSH 密钥登录

**为什么密钥比密码好**：
- 密码 8 位有 6.6 亿种组合，暴力破解几小时内可破；
- ed25519 密钥有 2^256 种组合，宇宙热寂前破不出来；
- 密钥文件 + 可选口令 = **双因素**。

**生成密钥对**（本地机器）：

```bash
ssh-keygen -t ed25519 -C \"you@example.com\"
# 默认存 ~/.ssh/id_ed25519（私钥）+ id_ed25519.pub（公钥）
# 会问是否设置密码，回车即空密码（简单场景可以）
```

**把公钥交给服务器**：

```bash
# 方式 1：一键命令（推荐）
ssh-copy-id root@1.2.3.4

# 方式 2：手动
scp ~/.ssh/id_ed25519.pub root@1.2.3.4:/tmp/
ssh root@1.2.3.4
cat /tmp/id_ed25519.pub >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
chmod 700 ~/.ssh
```

🎯 **权限检查**：SSH 服务端对权限特别严格：
| 文件 / 目录 | 权限 |
|---|---|
| `~/.ssh` | `700` (`drwx------`) |
| `~/.ssh/authorized_keys` | `600` (`-rw-------`) |
| `~/.ssh/id_ed25519`（私钥） | `600` (`-rw-------`) |

**任何一个权限太开** SSH 服务端就拒绝使用该密钥，学生第一次踩坑的必经之路。

**配置 SSH 别名**——`~/.ssh/config`：

```text
Host yoga
    HostName     1.2.3.4
    User         root
    Port         22
    IdentityFile ~/.ssh/id_ed25519
    ServerAliveInterval 60
```

之后 `ssh yoga` 一键连接。`ServerAliveInterval 60` 让连接每 60 秒发一次心跳，防止 NAT 超时断开。

### 5.4 SSH 服务端安全加固

`/etc/ssh/sshd_config` 常用调整：

```text
Port 22                             # 生产可改 26522 避扫描
PermitRootLogin prohibit-password   # 允许 root 密钥登录但禁密码
PasswordAuthentication no           # 全局禁密码（前提是密钥能用）
MaxAuthTries 3
AllowUsers deploy root
```

改完 `sudo systemctl restart sshd`。**改之前必须先确认密钥能免密登录**——否则改错就把自己踢出。

### 5.5 目录结构约定

```text
/                          根
├─ home/deploy/            普通用户 home
├─ root/                   root 用户 home
├─ etc/                    系统配置（nginx / ssh / cron）
├─ var/                    可变数据
│  ├─ log/                 系统日志
│  └─ lib/mysql/           MySQL 数据文件
├─ opt/                    第三方软件（手动安装的项目）
│  └─ yoga/
│     ├─ web/              前端 dist/
│     ├─ app/yoga-boot.jar 后端 Fat Jar
│     └─ logs/             应用日志
├─ usr/                    系统程序与库
└─ tmp/                    临时文件（重启清空）
```

🎯 **约定**：应用装 `/opt` 或 `/usr/local`；数据放 `/var/lib/xxx`；日志放 `/var/log/xxx` 或应用目录下 `logs/`；用户代码放 `/home` 或 `/opt`。

### 5.6 常用命令速查

| 命令 | 作用 | 示例 |
|---|---|---|
| `pwd` | 当前路径 | `pwd` |
| `ls -alh` | 详细列表 | `ls -alh /var/log` |
| `cd` | 切换 | `cd /opt` / `cd ~` / `cd -`（回上次） |
| `mkdir -p` | 递归创建 | `mkdir -p /opt/yoga/logs` |
| `rm -rf` | 强删（危险） | `rm -rf tmp/` |
| `cp -r` | 复制 | `cp -r src/ dst/` |
| `mv` | 重命名/移动 | `mv a.log a.old` |
| `touch` | 建空文件 | `touch a.log` |
| `find` | 查找 | `find /var/log -name \"*.log\" -mtime -1` |
| `du -sh *` | 目录大小 | `du -sh * \| sort -h` |
| `df -h` | 磁盘使用 | `df -h` |

**文本查看**：

```bash
cat  file.txt                       # 全部输出
less file.txt                       # 分页浏览（q 退出）
head -n 20  file.log
tail -n 100 file.log
tail -f app.log                     # 实时追加
grep \"error\" app.log                # 关键字搜索
grep -rn \"TODO\" src/                # 递归 + 行号
awk '{print $1}' access.log         # 列切分
```

### 5.7 用户与权限

```bash
sudo adduser deploy                 # 创建用户 + home
sudo passwd  deploy                 # 设密码
sudo usermod -aG sudo deploy        # 加入 sudo 组
su - deploy                         # 切换到 deploy
whoami                              # 当前是谁
```

**权限九位**：`-rwxr-xr--`
- 第 1 位：`-` 文件 / `d` 目录 / `l` 软链
- 2-4 位：owner；5-7 位：group；8-10 位：other
- `r=4 w=2 x=1`，`755` = `rwxr-xr-x`

```bash
chmod 755 script.sh                 # 数字模式
chmod +x  script.sh                 # 加执行位
chown deploy:deploy /opt/yoga       # 改属主/组
chown -R deploy:deploy /opt/yoga    # 递归改
```

🎯 **常见坑**：Jar 用 `deploy` 用户跑，但 `/opt/yoga/` 是 `root:root` 属主——**Jar 无权限读**。上线前必须 `chown -R deploy:deploy /opt/yoga`。

### 5.8 进程与端口

```bash
ps aux | grep java                  # 查进程
top / htop                          # 实时监控
kill -15 <pid>                      # 优雅退出（推荐）
kill -9  <pid>                      # 强杀（不到万不得已别用）

ss -tlnp                            # 监听端口
netstat -anp | grep :8080
lsof -i :8080                       # 端口占用详情
```

### 5.9 `apt` 装三大件

**先更新软件源索引**（不装任何东西）：

```bash
sudo apt update
```

**装 JDK / MySQL / Nginx**：

```bash
sudo apt install -y openjdk-25-jdk mysql-server nginx
```

**验证**：

```bash
java -version                       # openjdk version \"25\" ...
mysql --version                     # mysql  Ver 8.0.x
nginx -v                            # nginx version: nginx/1.24.x
```

如果 `openjdk-25-jdk` 找不到，用 `apt search openjdk` 查可用版本，或退到 `openjdk-21-jdk`（Java 25 与 21 都可跑 Spring Boot 4）。

### 5.10 MySQL 首次配置

Ubuntu 22.04 的 `mysql-server` 首装通常**没有 root 密码**——直接 `sudo mysql` 免密进：

```bash
sudo mysql

-- 进入 MySQL 后
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'YourStrongPwd@2026';
FLUSH PRIVILEGES;

CREATE DATABASE yoga CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'yoga'@'localhost' IDENTIFIED BY 'YogaAppPwd@2026';
GRANT ALL PRIVILEGES ON yoga.* TO 'yoga'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

**安全加固**：

```bash
sudo mysql_secure_installation
# → 设 root 密码策略
# → 禁远程 root 登录
# → 删匿名用户
# → 删 test 库
# → 立即刷新权限
```

**导入项目 SQL**：

```bash
mysql -u yoga -p yoga < yoga.sql
```

### 5.11 `systemctl` 五件套

`systemd` 是 Ubuntu 22.04 的默认服务管理器：

```bash
sudo systemctl start   nginx        # 启动
sudo systemctl stop    nginx        # 停止
sudo systemctl restart nginx        # 重启
sudo systemctl reload  nginx        # 平滑重载（不断开当前连接）
sudo systemctl status  nginx        # 查看状态
sudo systemctl enable  nginx        # 开机自启
sudo systemctl disable nginx        # 取消开机自启

sudo journalctl -u nginx -f         # 实时看 systemd 日志
sudo journalctl -u nginx --since \"1 hour ago\"
```

`reload` vs `restart`：Nginx `reload` 只重新读配置**不断连接**（生产必备）；`restart` 是完全重启。

### 5.12 `ufw` 防火墙

```bash
sudo ufw allow 22/tcp               # SSH
sudo ufw allow 80/tcp               # HTTP
sudo ufw allow 443/tcp              # HTTPS
sudo ufw enable                     # 启用（此时之外全拒）
sudo ufw status verbose             # 查看规则
```

🚨 **顺序不能错**：**必须先放通 22 再 `enable`**——`ufw` 默认策略是拒绝所有入站，先 enable 会立即把 SSH 会话踢掉，只能通过云厂商 Web VNC 补救。

### 5.13 文件传输

**`scp`**：简单单次同步。

```bash
# 本地 → 远程
scp yoga-boot.jar yoga:/opt/yoga/app/
scp -r dist/ yoga:/opt/yoga/web/

# 远程 → 本地
scp yoga:/var/log/nginx/access.log ./
```

**`rsync`**：增量同步，大目录同步效率高。

```bash
rsync -avz --delete dist/ yoga:/opt/yoga/web/
```

参数：
- `-a` 归档模式（保权限、时间、递归）
- `-v` 详细输出
- `-z` 传输时压缩
- `--delete` **目标端删除源端不存在的文件**——保持严格一致

🎯 `--delete` 是双刃剑——如果源目录写错，目标目录会被清空。写脚本时**目标路径必须写死绝对路径**。

### 5.14 常见 AI 生成错误清单

1. 用 `apt-get` 老命令（`apt` 更现代）；
2. 装 `default-jdk` 而不指定版本——各 Ubuntu 版本默认 JDK 不同；
3. 忘 `apt update` 直接 install 会用旧索引；
4. ufw 顺序错——先 enable 后 allow 22 把自己踢掉；
5. 不加 `chown` 造成 Jar 无权限读文件。

### 5.15 一键初始化脚本（参考）

`init-server.sh`：

```bash
#!/usr/bin/env bash
set -euo pipefail

echo \"→ 换阿里源\"
sudo sed -i 's|http://.*archive.ubuntu.com|http://mirrors.aliyun.com|g' /etc/apt/sources.list

echo \"→ 更新与升级\"
sudo apt update && sudo apt upgrade -y

echo \"→ 安装基础工具\"
sudo apt install -y git curl vim htop unzip fail2ban ca-certificates

echo \"→ 安装 JDK / MySQL / Nginx\"
sudo apt install -y openjdk-25-jdk mysql-server nginx

echo \"→ 创建 deploy 用户\"
if ! id deploy &>/dev/null; then
  sudo adduser --disabled-password --gecos '' deploy
  sudo usermod -aG sudo deploy
  sudo mkdir -p /home/deploy/.ssh
  sudo cp /root/.ssh/authorized_keys /home/deploy/.ssh/
  sudo chown -R deploy:deploy /home/deploy/.ssh
  sudo chmod 700 /home/deploy/.ssh
  sudo chmod 600 /home/deploy/.ssh/authorized_keys
fi

echo \"→ 建立项目目录\"
sudo mkdir -p /opt/yoga/{web,app,logs}
sudo chown -R deploy:deploy /opt/yoga

echo \"→ 防火墙\"
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

echo \"→ 时区与语言\"
sudo timedatectl set-timezone Asia/Shanghai
sudo apt install -y language-pack-zh-hans
sudo hostnamectl set-hostname yoga-prod

echo \"✅ 初始化完成\"
```

执行：`sudo bash init-server.sh`。

---

## 第 6 讲：Nginx 反向代理 + 静态部署 + Jar 后台 + systemd

### 6.1 引入：把所有拼图拼上

前 5 讲都是准备：登录页、Pinia、路由守卫、`dist/`、Ubuntu 装机。今天把它们拼成一个用户可访问的域名。

请求流：

```text
浏览器 GET /                → Nginx → 返 index.html + dist/*
浏览器 GET /courses         → Nginx → try_files → 返 index.html（SPA fallback）
浏览器 GET /api/courses     → Nginx → proxy_pass → Java :8080
浏览器 GET /assets/xxx.js   → Nginx → 静态资源直返 + 长缓存头
```

🎯 **一句话目标**：**Nginx 一份配置接管静态与后端两条路径，systemd 让 Jar 挂了自己爬起来**。

### 6.2 Nginx 完整配置

`/etc/nginx/conf.d/yoga.conf`：

```nginx
# --- 后端上游池 ---
upstream yoga_backend {
  server 127.0.0.1:8080;
  keepalive 32;
}

# --- HTTP → HTTPS 强制跳转（有域名 + 证书时打开）---
# server {
#   listen 80;
#   server_name yoga.example.com;
#   return 301 https://$host$request_uri;
# }

# --- 主服务（本课程先用 80 演示，生产改 443 + SSL） ---
server {
  listen 80;
  server_name yoga.example.com;   # 或直接用公网 IP

  # 上传大小
  client_max_body_size 20m;

  # Gzip
  gzip              on;
  gzip_min_length   1k;
  gzip_comp_level   6;
  gzip_types        text/plain text/css application/json application/javascript
                    application/xml image/svg+xml;
  gzip_vary         on;

  # 日志
  access_log /var/log/nginx/yoga.access.log;
  error_log  /var/log/nginx/yoga.error.log warn;

  # ---------- 前端静态资源 ----------
  root /opt/yoga/web;
  index index.html;

  # 带 hash 的资源长缓存
  location ~* ^/assets/.+\.(js|css|png|jpg|jpeg|gif|svg|woff2?)$ {
    expires 30d;
    add_header Cache-Control \"public, immutable\";
    try_files $uri =404;
  }

  # index.html 不缓存
  location = /index.html {
    add_header Cache-Control \"no-cache, no-store, must-revalidate\";
    add_header Pragma \"no-cache\";
    add_header Expires 0;
  }

  # SPA fallback
  location / {
    try_files $uri $uri/ /index.html;
  }

  # ---------- API 反向代理 ----------
  location /api/ {
    proxy_pass         http://yoga_backend/;          # ⚠️ 末尾斜杠决定是否剥前缀
    proxy_http_version 1.1;
    proxy_set_header   Host              $host;
    proxy_set_header   X-Real-IP         $remote_addr;
    proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header   X-Forwarded-Proto $scheme;
    proxy_set_header   Connection        \"\";
    proxy_read_timeout 30s;
    proxy_send_timeout 30s;
  }
}
```

### 6.3 逐段解读

| 段 | 作用 | 关键点 |
|---|---|---|
| `upstream` + `keepalive 32` | 后端连接池 + 长连接复用 | 与 `proxy_http_version 1.1` + `Connection \"\"` 配合 |
| `client_max_body_size 20m` | 允许上传 20MB | 默认 1MB，头像 / 视频接口必调 |
| `gzip on` + `gzip_types` | JSON 与静态资源压缩 | **别忘 `application/json`**，否则 API 响应不压 |
| `access_log` / `error_log` | 独立日志 | 每个 vhost 分开写，便于分析 |
| `root /opt/yoga/web` | 静态根目录 | 前端 `dist/` 内容全部放这里 |
| `/assets/*` 长缓存 | 静态资源 30 天 | hash 变名 → `immutable` 安全 |
| `= /index.html` 不缓存 | 版本切换即时生效 | 必须！否则用户看老版本 |
| `try_files $uri /index.html` | SPA fallback | vue-router history 模式必备 |
| `location /api/` | 后端反代 | **末尾斜杠决定前缀是否剥离** |
| `X-Forwarded-*` | 传递真实 IP + 协议 | 后端记 IP、生成 HTTPS 绝对 URL 用得上 |

### 6.4 `proxy_pass` 末尾斜杠陷阱

这是 Nginx 里最容易踩的坑：

| `proxy_pass` 写法 | 请求 `/api/courses` 转到后端时变成 |
|---|---|
| `proxy_pass http://yoga_backend/;`（**带斜杠**） | `/courses` — **剥掉 `/api` 前缀** |
| `proxy_pass http://yoga_backend;`（**不带斜杠**） | `/api/courses` — 保留完整路径 |

本项目**统一带斜杠**——后端 Controller `@RequestMapping(\"/courses\")` 不用管前缀，简洁清晰。

如果后端 Controller 写了 `@RequestMapping(\"/api/courses\")`，那 Nginx 就要用**不带斜杠**版本。**契约必须前后一致**。

🎯 **调试方法**：在服务器上 `sudo tail -f /var/log/nginx/yoga.access.log`，浏览器发一次请求，看 Nginx 转给后端的路径是什么。

### 6.5 后端配合

`application-prod.yml`：

```yaml
server:
  port: 8080
  address: 127.0.0.1                  # 只监听回环，防止外网直连
  forward-headers-strategy: framed    # 信任 X-Forwarded-* 头

spring:
  profiles:
    active: prod
  datasource:
    url:      jdbc:mysql://localhost:3306/yoga?useSSL=false&characterEncoding=utf8mb4&serverTimezone=Asia/Shanghai
    username: yoga
    password: YogaAppPwd@2026

logging:
  file:
    name: /opt/yoga/logs/yoga.log
  level:
    root: INFO
    com.yinxiang: DEBUG
```

🎯 **`address: 127.0.0.1`**：Spring Boot 只监听本地回环——外网无法直连 8080，只能通过 Nginx 转发。**多一层防护**。

🎯 **`forward-headers-strategy: framed`**：让 Spring Security / MVC 信任 `X-Forwarded-For` 头——`request.getRemoteAddr()` 拿到真实用户 IP 而不是 `127.0.0.1`。

### 6.6 `systemd` 单元文件

`/etc/systemd/system/yoga.service`：

```ini
[Unit]
Description=Yoga Boot Backend
After=network.target mysql.service

[Service]
Type=simple
User=deploy
Group=deploy
WorkingDirectory=/opt/yoga/app
ExecStart=/usr/bin/java -Xms512m -Xmx1024m -jar -Dspring.profiles.active=prod yoga-boot.jar
Restart=on-failure
RestartSec=5
StandardOutput=append:/opt/yoga/logs/stdout.log
StandardError=append:/opt/yoga/logs/stderr.log

# 资源限制
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
```

**四要素**：
- `ExecStart`——启动命令
- `User=deploy`——以 deploy 身份运行（不用 root）
- `Restart=on-failure`——**退出码非 0 时自动重启**
- `RestartSec=5`——等 5 秒再重启，避免循环崩溃占 CPU

**启用**：

```bash
sudo systemctl daemon-reload          # 每次改 .service 都要
sudo systemctl enable --now yoga      # 开机自启 + 立即启动
sudo systemctl status yoga
sudo journalctl -u yoga -f            # 实时看日志
```

🎯 **`Restart=on-failure` vs `always`**：
- `on-failure`：只在退出码非 0 时重启——正常退出（`systemctl stop`）不会重启
- `always`：无论退出码都重启——包括 `stop` 之后又自己起来，运维会疯

生产用 `on-failure` 更合理。

### 6.7 一键部署脚本

本地 `scripts/deploy.sh`：

```bash
#!/usr/bin/env bash
set -euo pipefail

HOST=deploy@yoga.example.com

echo \"→ build backend\"
( cd backend && ./mvnw clean package -DskipTests )

echo \"→ build frontend\"
( cd frontend && pnpm build )

echo \"→ upload backend jar\"
scp backend/target/yoga-boot.jar \"$HOST:/opt/yoga/app/yoga-boot.jar\"

echo \"→ upload frontend dist\"
rsync -avz --delete frontend/dist/ \"$HOST:/opt/yoga/web/\"

echo \"→ restart backend\"
ssh \"$HOST\" 'sudo systemctl restart yoga'

echo \"→ health check\"
for i in 1 2 3 4 5; do
  if curl -fsS http://yoga.example.com/api/health >/dev/null; then
    echo \"✅ up\"; exit 0
  fi
  echo \"  waiting... ($i/5)\"
  sleep 3
done
echo \"❌ health check failed\"
exit 1
```

流程：**build → upload → restart → health check**。

后端加健康检查接口：

```java
@RestController
@RequestMapping(\"/health\")
public class HealthController {
    @GetMapping
    public Map<String, Object> health() {
        return Map.of(\"status\", \"UP\", \"time\", LocalDateTime.now());
    }
}
```

Nginx 里放行（默认已经在 `/api/` 里）——`deploy.sh` 里 `curl /api/health` 就能拿到。

### 6.8 上线操作步骤

初次上线：

```bash
# 1. 服务器初始化（第 5 讲的 init-server.sh）
scp init-server.sh yoga:/tmp/
ssh yoga 'sudo bash /tmp/init-server.sh'

# 2. 上传 Nginx 配置
scp nginx/yoga.conf yoga:/tmp/
ssh yoga 'sudo mv /tmp/yoga.conf /etc/nginx/conf.d/ && sudo nginx -t && sudo systemctl reload nginx'

# 3. 上传 systemd 单元
scp systemd/yoga.service yoga:/tmp/
ssh yoga 'sudo mv /tmp/yoga.service /etc/systemd/system/ && sudo systemctl daemon-reload'

# 4. 首次部署
bash scripts/deploy.sh

# 5. 后端启动
ssh yoga 'sudo systemctl enable --now yoga'

# 6. 浏览器打开 http://yoga.example.com
```

后续每次改代码：

```bash
bash scripts/deploy.sh
```

### 6.9 常见部署坑

**1. 刷新 404**
Nginx 缺 `try_files ... /index.html` 或 vue-router 用了 hash 模式后又切 history。
排查：`/courses` 直接访问是否 404？加 `try_files $uri $uri/ /index.html` 即可。

**2. 登录一次成功、刷新掉登录**
`localStorage` 存了但 Pinia state 初始化时机不对。
排查：`stores/auth.ts` 的 `state()` 工厂函数里是否读 `localStorage`？

**3. CORS 报错**
同源部署下不该有——若出现说明前端 `VITE_API_BASE_URL=http://another-host`。
修正：改成 `/api`，让 Nginx 转发。

**4. 文件上传 413**
Nginx `client_max_body_size` 默认 1MB。
修正：`client_max_body_size 20m`（按业务需要调整）。

**5. 后端拿到 IP 全是 `127.0.0.1`**
忘配 `X-Forwarded-For` 或 `forward-headers-strategy: framed`。

**6. 静态资源 MIME 错误**
Nginx `mime.types` 缺，`.woff2` 变成 `application/octet-stream`。
修正：用官方发行版的 `nginx.conf`，不要手删 include。

**7. Gzip 对 API 无效**
`gzip_types` 忘加 `application/json`——只压缩了静态资源。

**8. 部署 `deploy` 用户无权读 Jar**
`chown -R deploy:deploy /opt/yoga` 之后再启动。

**9. `proxy_pass` 斜杠陷阱**
后端 404 或 URL 拼错。用 `tail -f /var/log/nginx/yoga.access.log` 看转发路径。

**10. systemd 服务启动失败**
`sudo journalctl -u yoga --no-pager -n 100` 看详细报错。

### 6.10 项目完整验收清单

**功能**：
- [ ] 登录：账号密码 + 验证码，错误提示清晰
- [ ] 登录后自动跳回原页面（`?redirect=...`）
- [ ] 会员 / 教练 / 教室 / 科目：完整 CRUD
- [ ] 课程：CRUD + 冲突检测 + 状态流转
- [ ] 预约：CRUD + 名额控制 + 状态机
- [ ] 系统日志：查询、详情、导出 CSV
- [ ] 首页 Dashboard：4 数字卡片 + 2 图表 + 最近日志
- [ ] 退出登录、Token 过期自动跳登录
- [ ] 30 分钟不活跃自动登出

**质量**：
- [ ] 全局错误处理：BizError 弹通知，网络异常兜底
- [ ] 表单校验：字段级 + 跨字段 + 异步唯一性
- [ ] 分页 / 排序 / 多选 / 批量操作
- [ ] Loading / Disabled 状态齐全

**性能**：
- [ ] 首屏 JS gzip 后 < 200KB
- [ ] `manualChunks` 拆包正确
- [ ] 静态资源长缓存 + `index.html` 不缓存

**部署**：
- [ ] Nginx SPA fallback + Gzip
- [ ] 后端 systemd 托管，故障自愈
- [ ] 一键 `deploy.sh` 覆盖 build → upload → restart → health check
- [ ] `ufw` 只放通 22 / 80 / 443
- [ ] MySQL root 密码复杂 + 禁远程

**安全（选做）**：
- [ ] HTTPS + `certbot` 自动续签
- [ ] HSTS 头 `Strict-Transport-Security`
- [ ] `fail2ban` 防 SSH 爆破

### 6.11 本讲小结

- **Nginx 一份配置**接管静态与 API 两条路径
- `try_files $uri $uri/ /index.html` 是 SPA fallback 的标准写法
- `proxy_pass` 末尾斜杠决定前缀是否剥离——**契约先定后写**
- `X-Forwarded-*` 头让后端拿到真实 IP 与 HTTPS 状态
- `systemd` 托管 Jar → 崩溃自愈、开机自启
- `deploy.sh` 一键脚本 = build + upload + restart + health check
- 至此从 Day01 到今天的印想瑜伽后台管理系统**从零到线上**全流程走通

### 6.12 课后作业

1. **必做**：完成印想瑜伽项目的**完整生产部署**，域名 / IP 交作业时一并提交，课后随机抽查在线服务。
2. **必做**：写一份 `deploy.sh` 一键脚本（build → rsync → ssh restart → curl health check）交到 GitHub 项目 `scripts/` 目录。
3. **挑战**：给项目加 HTTPS——用 `certbot` 申请 Let's Encrypt 免费证书 + 强制 HTTP → HTTPS 跳转 + 加 HSTS 头 `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`。
4. **挑战**：用 GitHub Actions 写一个 CI/CD 工作流——`push` 到 `main` 分支自动 build → 部署到 staging → 人工审批 → 部署到 prod。

---

## Day15 全景回顾

从 Day01 的「HTML/CSS 基础」到 Day14 的「课程管理页」，你已经把印想瑜伽后台管理系统的每一根神经都亲手接通。Day15 完成了最后一公里：

| 阶段 | 内容 | 产出 |
|---|---|---|
| 登录闭环 | LoginView + AuthStore + Axios 拦截 + 路由守卫 | 401 兜底、redirect 回原页、不活跃自登出 |
| 打包上线 | vite build + manualChunks + hash 长缓存 | dist/ 首屏 <200KB gzip |
| Linux 基础 | SSH 密钥 + apt 三件套 + systemctl + ufw | 一台裸机变生产服务器 |
| Nginx 部署 | 反代 + SPA fallback + Gzip + systemd | 一份配置接管全站流量 |

**你手里的这个作品链接可以直接投到简历**——它覆盖了从产品需求到 UI 设计、从前端组件到后端 API、从数据库表结构到 Nginx 配置的**全栈交付能力**。

从 Day16 开始，我们进入进阶：Docker 化、CI/CD 流水线、Prometheus 监控、灰度发布、Sentry 错误上报。**基础闭环已经打通，接下来是让它更可靠、更快、更好维护**。
