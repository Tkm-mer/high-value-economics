# 《AI 应用 Web 开发》 - 学生讲义（Day03：Maven 依赖管理 + Spring Boot 入门）

**总讲次：6 讲**
**适用对象：具备 Java 基础语法能力的大二/大三本科生（已完成 Day01/Day02，能熟练使用 IDEA 2024.3+ 与 JDK 25）**

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 全部案例围绕主线项目展开，Maven 坐标统一使用 `com.yinxiang:yoga-member`，Spring Boot 演示以 `/api/course/list` 返回瑜伽课程列表为主。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Maven 介绍 + 安装配置 + 阿里云镜像 | 完成 Maven 3.9 安装 + `mvn -v` 成功 |
| 第 2 讲 | IDEA 集成 Maven + 坐标 GAV + 项目结构 | 在 IDEA 里建出第一个 `yoga-member` Maven 项目 |
| 第 3 讲 | 依赖管理 + scope + 冲突 + 生命周期 | 能用 `mvn dependency:tree` 排查依赖树 |
| 第 4 讲 | Spring Boot 介绍 + HelloController | 跑通 `http://localhost:8080/hello` |
| 第 5 讲 | 分层解耦 + Controller/Service/DAO + IOC/DI | 跑通 `/api/course/list` 三层结构 |
| 第 6 讲 | Spring Boot 启动原理 + `@SpringBootApplication` | 拆解三大注解 + `application.yml` + profile |

---

## 第 1 讲：Maven 介绍 + 安装配置 + 阿里云镜像

### 1.1 引入：为什么需要 Maven？

想象你要开发一个中型 Java Web 项目，需要用到：MySQL 驱动、JSON 处理库、日志框架、单元测试库……大概 40+ 个第三方 jar。

**没有 Maven 的时代**：
- 引入 MySQL 驱动 → 上官网下载 jar → 手动放进 `lib/` 目录；
- 依赖冲突 → 满硬盘搜索、比版本号；
- 项目分模块 → 一个个手动 build；
- 换电脑 → 从头再来。

**有了 Maven 之后**：
- 一行 `<dependency>` 自动下载 jar 及其**所有传递依赖**；
- 命令行 `mvn package` 一键打包；
- 全世界共享 [中央仓库](https://repo.maven.apache.org/maven2/)，你需要的库几乎都有。

**Maven 定位**：Apache 基金会推出的 Java 项目**构建 + 依赖管理**工具，被誉为 Java 世界的"瑞士军刀"。

### 1.2 三大核心概念

```
POM ──────► pom.xml 文件描述整个项目
 │
 ├─ 坐标 GAV ── groupId:artifactId:version（唯一定位一个库）
 │
 └─ 仓库 ────┬─ 本地仓库（~/.m2/repository/）
             └─ 远程仓库（中央仓库 / 阿里云镜像 / 私服 Nexus）
```

- **POM**（Project Object Model）：一个 `pom.xml` 文件描述项目名、版本、依赖、构建方式；
- **坐标（GAV）**：`groupId + artifactId + version` 三元组，是 Maven 世界的"身份证"，例如 `com.mysql:mysql-connector-j:8.3.0`；
- **仓库**：第一次构建时依赖从远程下载到本地，之后直接读本地；本地仓库默认在 `~/.m2/repository/`，可通过 `settings.xml` 改到别的盘。

🎯 **口诀**：**POM 一张纸、GAV 三兄弟、仓库两层楼（远程 → 本地）**。

### 1.3 安装 Maven（Windows）

版本基线：**Maven 3.9+**，本讲以 3.9.9 为例。

#### 步骤 1：下载解压

- 官网：<https://maven.apache.org/download.cgi>
- 下载 `apache-maven-3.9.9-bin.zip`，解压到 **无中文、无空格** 的路径，如 `D:\dev\apache-maven-3.9.9`。

⚠️ **特别注意**：路径含中文或空格会导致后续依赖下载/编译莫名报错，血泪教训。

#### 步骤 2：配置环境变量

`此电脑 → 右键 → 属性 → 高级系统设置 → 环境变量`：

- 新增系统变量 `MAVEN_HOME` = `D:\dev\apache-maven-3.9.9`
- 编辑 `Path` → 追加 `%MAVEN_HOME%\bin`

#### 步骤 3：验证

**关闭并重新打开** cmd/PowerShell，执行：

```bash
mvn -v
```

看到类似输出即成功：

```
Apache Maven 3.9.9 (...)
Maven home: D:\dev\apache-maven-3.9.9
Java version: 25, vendor: Oracle Corporation
```

⚠️ **特别注意**：修改环境变量后必须**关闭旧终端窗口重开**才会生效，Windows 不会自动刷新已打开的终端。

### 1.4 配置阿里云镜像与本地仓库

中央仓库在国外，下载慢且经常超时。国内开发必须换成 **阿里云镜像**。

编辑 `%MAVEN_HOME%\conf\settings.xml`，找到 `<mirrors>` 节点，改为：

```xml
<!-- 本地仓库位置（放到非中文盘） -->
<localRepository>D:/mvn-repo</localRepository>

<mirrors>
    <mirror>
        <id>aliyun-public</id>
        <mirrorOf>central</mirrorOf>
        <name>阿里云公共仓库</name>
        <url>https://maven.aliyun.com/repository/public</url>
    </mirror>
</mirrors>
```

**验证配置生效**：

```bash
mvn help:effective-settings
```

在输出里能看到 `<localRepository>D:/mvn-repo</localRepository>` 与阿里云 URL 即成功。

### 1.5 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `mvn -v` 报"不是内部或外部命令" | 环境变量未生效，**关闭终端重开**；确认 `Path` 里的 `%MAVEN_HOME%\bin` |
| 依赖下载卡住不动或报网络错误 | 没配阿里云镜像；或 `<mirrorOf>` 写错（要写 `central`） |
| 下载失败报路径异常 | `localRepository` 路径含中文/空格；`MAVEN_HOME` 路径含中文 |
| `mvn` 走了 JDK 8 而不是 JDK 25 | `JAVA_HOME` 指向了错的 JDK；`mvn -v` 输出的 Java version 与预期不符 |
| Windows 家庭版找不到"高级系统设置" | `Win + R` → `sysdm.cpl` → 高级 → 环境变量 |

### 1.6 练习/思考

1. 完成 Maven 3.9.9 安装并让 `mvn -v` 输出 Maven + JDK 25 版本，截图保存。
2. 配置阿里云镜像后，执行 `mvn help:effective-settings`，找出镜像 URL 段。
3. **思考**：为什么中央仓库和阿里云镜像里同样一个 `mysql-connector-j:8.3.0` 内容一定是一致的？（提示：GAV 不可变原则）

---

## 第 2 讲：IDEA 集成 Maven + 坐标 GAV + 项目结构

### 2.1 引入：命令行 vs IDEA

上一讲让 Maven 在命令行跑起来了，但实际开发我们**很少用命令行**——90% 时间在 IDEA 里。今天要让 IDEA 认识你自己装的 Maven，然后建出第一个 `yoga-member` Maven 项目。

### 2.2 IDEA 里 Maven 的三处路径

`File → Settings → Build, Execution, Deployment → Build Tools → Maven`：

| 路径 | 值 | 说明 |
|---|---|---|
| Maven home path | `D:/dev/apache-maven-3.9.9` | 告诉 IDEA 用你装的 Maven，而不是 IDEA 自带的 Bundled |
| User settings file | `D:/dev/apache-maven-3.9.9/conf/settings.xml` **勾选 Override** | 决定用哪个镜像 |
| Local repository | 自动读取 = `D:/mvn-repo` | 从 `settings.xml` 自动读，一般不用改 |

⚠️ **特别注意**：**必须勾选 Override**，否则 IDEA 会用它自带的 Bundled Maven（版本可能不同）——这是最常见的踩坑点。

### 2.3 新建 Maven 项目

`File → New → Project → Maven Archetype`（或空模板）：

| 字段 | 值 |
|---|---|
| Name | `yoga-member` |
| Location | `D:/workspace/yoga-member` |
| Language | Java |
| JDK | 25 |
| Archetype | **空**（不选任何 archetype 最干净） |
| GroupId | `com.yinxiang` |
| ArtifactId | `yoga-member` |
| Version | `1.0-SNAPSHOT` |

点击 Create。IDEA 自动生成结构 + `pom.xml`，并触发一次 Reload。

### 2.4 Maven 标准目录结构

```
yoga-member/
├── pom.xml                     ← 项目描述文件
├── src/
│   ├── main/
│   │   ├── java/               ← Java 源码
│   │   │   └── com/yinxiang/
│   │   └── resources/          ← 配置文件（yml/properties/xml）
│   └── test/
│       ├── java/               ← 单元测试
│       └── resources/
└── target/                     ← 编译产物（首次 build 后才有）
```

🎯 **约定优于配置**：只要按标准放代码，Maven 就自动认识。**不要**自己创造 `code/`、`config/` 之类的目录名。

### 2.5 `pom.xml` 骨架剖析

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>

    <!-- 坐标 GAV：项目自己的身份证 -->
    <groupId>com.yinxiang</groupId>
    <artifactId>yoga-member</artifactId>
    <version>1.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <!-- 属性：定义可复用变量 -->
    <properties>
        <maven.compiler.source>25</maven.compiler.source>
        <maven.compiler.target>25</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <!-- 依赖：项目需要的第三方库 -->
    <dependencies>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>5.10.2</version>
            <scope>test</scope>
        </dependency>
    </dependencies>
</project>
```

**`<packaging>` 三个常用值**：

- `jar`：普通 Java 库或 Spring Boot 应用（默认）；
- `war`：传统 Web 应用（要部署到外部 Tomcat）；
- `pom`：父项目/聚合项目，不产出 jar，只组织子模块。

### 2.6 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| IDEA 用了 Bundled Maven 而非你装的 3.9.9 | 没勾 Override User settings file，重新 Settings 检查 |
| 新建项目一直卡在下载 | 首次会下 Maven 元数据，观察右下角进度条，别中断 |
| 生成了 `App.java` `AppTest.java` 觉得奇怪 | 选了 `maven-archetype-quickstart`；改选"空模板"或删掉重来 |
| `pom.xml` 修改后 IDEA 未生效 | 右键 → Maven → **Reload Project**，或点右上角小图标 |
| JDK 25 报错但 `Properties` 里写了 25 | 检查 `File → Project Structure → Project → SDK` 是否也选了 25 |

### 2.7 练习/思考

1. 在 IDEA 里完成 Maven 三处路径配置并截图。
2. 新建 `yoga-member` 项目，手写 `App.java` 输出"Hello, 印想瑜伽!"，Run 起来。
3. **思考**：为什么 `pom.xml` 的 `groupId` 一般用**倒过来的域名**（如 `com.yinxiang`）？（提示：全球唯一性）

---

## 第 3 讲：Maven 依赖管理 + scope + 冲突 + 生命周期

### 3.1 引入：一个依赖带来一坨 jar

在 `pom.xml` 里加一行：

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <version>4.0.0</version>
</dependency>
```

Reload 完执行：

```bash
mvn dependency:tree
```

你会看到输出 30+ 行——**你只写了 1 行，Maven 却帮你下了 30 多个 jar**（tomcat、jackson、spring-core、spring-web、spring-mvc……）。这就是**传递性依赖**：A 依赖 B、B 依赖 C，你只写 A，Maven 把 C 也拉进来。

### 3.2 坐标从哪里来

访问 [https://mvnrepository.com](https://mvnrepository.com)，搜 `mysql-connector-j`，第一个结果就是：

```xml
<dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <version>8.3.0</version>
</dependency>
```

复制粘贴到 `pom.xml` 即可。**Usages 数字高的通常是稳妥版本**，别乱挑最新预览版。

### 3.3 依赖范围 scope（考点）

| scope | 编译 | 测试 | 运行 | 打包 | 典型代表 |
|-------|:---:|:---:|:---:|:---:|---------|
| `compile`（默认） | ✅ | ✅ | ✅ | ✅ | Spring、Guava、业务库 |
| `test` | ✕ | ✅ | ✕ | ✕ | JUnit、Mockito |
| `provided` | ✅ | ✅ | ✕ | ✕ | servlet-api（容器已有）、Lombok（部分场景） |
| `runtime` | ✕ | ✅ | ✅ | ✅ | JDBC 驱动（编译期只用接口） |

🎯 **口诀**：**编译 provided 有、运行 provided 无；编译 runtime 无、运行 runtime 有**。

💡 **典型场景**：
- MySQL 驱动 `runtime`：编译时你的代码只依赖 `java.sql.*` 接口，运行时才需要驱动实现；
- Lombok 一般是 `<optional>true</optional>`，编译期生成字节码后运行期不再需要。

### 3.4 传递性依赖 + 依赖树

看依赖树：

```bash
mvn dependency:tree
```

典型输出（局部）：
```
[INFO] com.yinxiang:yoga-member:jar:1.0-SNAPSHOT
[INFO] +- org.springframework.boot:spring-boot-starter-web:jar:4.0.0:compile
[INFO] |  +- org.springframework.boot:spring-boot-starter:jar:4.0.0:compile
[INFO] |  +- org.springframework.boot:spring-boot-starter-tomcat:jar:4.0.0:compile
[INFO] |  |  +- org.apache.tomcat.embed:tomcat-embed-core:jar:...
[INFO] |  |  \- org.apache.tomcat.embed:tomcat-embed-el:jar:...
[INFO] |  \- org.springframework:spring-webmvc:jar:...:compile
```

**+-** 是直接依赖，**|** 缩进是传递依赖。

### 3.5 排除依赖 `<exclusions>`

不想要某个传递依赖，可以排除：

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
    <exclusions>
        <exclusion>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-logging</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```

### 3.6 版本冲突：短路径原则

同一个库出现多个版本时，Maven 采用：

1. **短路径优先**（依赖链短的胜）；
2. 路径相同 → **声明顺序优先**（`pom.xml` 里先写的胜）；
3. 想强制指定版本 → 在当前 `pom.xml` **显式声明**，或用 `<dependencyManagement>` 统一管控。

💡 **示例**：
- A 库 → B 库 → guava 20.0（路径长 = 3）
- 直接 `<dependency>` 声明 guava 31.0（路径长 = 1）
- **Maven 选 31.0**（短路径胜）

### 3.7 Maven 生命周期 7 阶段

```
validate → compile → test → package → verify → install → deploy
```

**关键规则**：**调用后一个阶段，会自动执行前面所有阶段**。所以你直接 `mvn install`，相当于跑了 `validate → compile → test → package → verify → install` 全套。

### 3.8 常用命令（背下来 6 条即可应付日常）

```bash
mvn clean                # 清理 target/
mvn compile              # 编译主代码
mvn test                 # 运行测试
mvn package              # 打包成 jar/war
mvn install              # 打包并安装到本地仓库
mvn dependency:tree      # 查看依赖树
```

**进阶**：

```bash
mvn dependency:analyze     # 找出未使用的依赖 / 未声明但用了的传递依赖
mvn -DskipTests package    # 跳过测试打包（不推荐但常用）
mvn -U clean package       # 强制刷新 SNAPSHOT 依赖
```

### 3.9 IDEA Maven 面板

IDEA 右侧栏 → Maven 图标 → 展开 `Lifecycle`：
- 双击 `clean` = 命令行 `mvn clean`
- 双击 `install` = 命令行 `mvn install`

新手推荐用 IDEA 面板，不用记命令。

### 3.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `dependency:tree` 输出乱码 | 终端编码问题；改用 IDEA 内置终端或加 `-Dfile.encoding=UTF-8` |
| 修改了 `pom.xml` 版本但依赖未刷新 | Reload Project；用 `mvn -U` 强制刷新 SNAPSHOT |
| 声明了 `<version>` 但没生效 | 被父项目/BOM 覆盖了；用 `mvn dependency:tree -Dincludes=xxx` 定位 |
| `provided` 依赖在打的 jar 里找不到 | 这是正常行为，运行时由容器提供 |
| 引入了同一个库的两个版本 | 用 `<exclusion>` 排掉一个，或在自己 `pom.xml` 显式声明 |

### 3.11 练习/思考

1. 在 `yoga-member` 里引入 `commons-lang3:3.14.0` 和 `mysql-connector-j:8.3.0`（scope=`runtime`），Reload 后执行 `mvn dependency:tree`，把输出保存为 `day03-03-tree.txt`。
2. 故意引入 `guava:31.0` 和 `guava:20.0`（一个直接、一个通过其他库间接），用依赖树观察 Maven 选了哪个版本。
3. **思考**：为什么 JDBC 驱动通常用 `runtime` 而不是 `compile`？（提示：面向接口编程 + 编译期防误用）

---

## 第 4 讲：Spring Boot 介绍 + Web 入门（HelloController）

### 4.1 引入：从 Spring 到 Spring Boot

传统 Spring 写一个 `/hello` 接口要多少代码？

- `web.xml`（配 Servlet）
- `applicationContext.xml`（配 Bean）
- `spring-mvc.xml`（配 MVC）
- `HelloController.java`

3 个 XML 一屏都装不下——**繁琐得令人发指**。

Spring Boot 让同样的事情变成：**1 个 `main()` + `@SpringBootApplication` + `@RestController` 就跑起来**。这就是 Spring Boot 的价值：**约定优于配置 + 自动装配**。

### 4.2 Spring Boot 四大特性

| 特性 | 说明 |
|---|---|
| **自动配置** | `@EnableAutoConfiguration`，根据类路径自动装配组件 |
| **起步依赖** | `spring-boot-starter-*` 一键引入功能族（web/data-jpa/security…） |
| **内嵌服务器** | Tomcat/Jetty/Undertow 内置，无需部署 war |
| **生产就绪** | `Actuator` 提供指标、健康检查、监控端点 |

**本课程版本基线**：Spring Boot 4.0.x + Java 25 + Maven 3.9+

### 4.3 用 IDEA 内置 Spring Initializr 生成项目

`File → New → Project → Spring Initializr`：

| 字段 | 值 |
|---|---|
| Name | `yoga-member` |
| Group | `com.yinxiang` |
| Artifact | `yoga-member` |
| Type | Maven |
| Language | Java |
| Packaging | Jar |
| JDK | 25 |
| Java | 25 |
| Spring Boot | 4.0.0 |
| Dependencies | **Spring Web、Lombok** |

💡 如果向导默认走 `start.spring.io` 网速慢，把 URL 换成阿里云镜像 `https://start.aliyun.com/`（IDEA 里可配）。

生成后目录：

```
yoga-member/
├── pom.xml
└── src/main/
    ├── java/com/yinxiang/yogamember/
    │   └── YogaMemberApplication.java
    └── resources/
        ├── application.properties
        └── static/
```

### 4.4 启动类：一个 `main()` 就够了

```java
package com.yinxiang.yogamember;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YogaMemberApplication {
    public static void main(String[] args) {
        SpringApplication.run(YogaMemberApplication.class, args);
    }
}
```

`@SpringBootApplication` 是三个注解的**组合注解**（第 6 讲详解）：
- `@SpringBootConfiguration`（= `@Configuration`）：这是一个配置类；
- `@EnableAutoConfiguration`：打开自动装配；
- `@ComponentScan`：扫描**当前包及子包**里的 `@Component/@Service/@Controller` 等。

⚠️ **特别注意**：因为 `@ComponentScan` 默认从启动类所在包开始扫描，所以你写的 `Controller`、`Service` 必须放在**启动类同包或子包**下，否则 Spring 找不到它们。

### 4.5 写第一个 Controller

在 `com.yinxiang.yogamember.controller` 包下建 `HelloController.java`：

```java
package com.yinxiang.yogamember.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String hello() {
        return "Hello, 印想瑜伽!";
    }
}
```

**注解速记**：

| 注解 | 作用 |
|---|---|
| `@RestController` | 组合注解 = `@Controller + @ResponseBody`，返回内容直接作为 HTTP 响应体（JSON/字符串） |
| `@GetMapping("/hello")` | 处理 GET `/hello` 请求，等价 `@RequestMapping(value="/hello", method=GET)` |
| `@PostMapping / @PutMapping / @DeleteMapping` | 对应 POST / PUT / DELETE 请求 |
| `@RequestParam` | 绑定 URL 参数（`?name=xxx`） |
| `@PathVariable` | 绑定路径变量（`/user/{id}`） |
| `@RequestBody` | 绑定 JSON 请求体 |

### 4.6 运行与访问

1. 点击 `YogaMemberApplication` 类左侧绿色三角 → Run；
2. 控制台看到：`Started YogaMemberApplication in 1.234 seconds`；
3. 浏览器访问 <http://localhost:8080/hello> → 返回 `Hello, 印想瑜伽!`。

### 4.7 三种参数接收方式

```java
// ① URL 参数：/user?name=Alice
@GetMapping("/user")
public String query(@RequestParam String name) { return name; }

// ② 路径变量：/user/123
@GetMapping("/user/{id}")
public String byId(@PathVariable Integer id) { return "id=" + id; }

// ③ JSON Body：POST /user  { "id":1, "name":"Alice" }
@PostMapping("/user")
public User create(@RequestBody User user) { return user; }
```

### 4.8 主线小案例：`/api/course/list`

在 `HelloController` 旁边再加一个方法：

```java
@GetMapping("/api/course/list")
public List<String> listCourses() {
    return List.of("哈他瑜伽", "阴瑜伽", "阿斯汤加", "流瑜伽");
}
```

访问 <http://localhost:8080/api/course/list> → 返回 JSON 数组：

```json
["哈他瑜伽","阴瑜伽","阿斯汤加","流瑜伽"]
```

💡 **为什么直接返回 `List<String>` 就变 JSON？**——`@RestController` 内含 `@ResponseBody`，Spring MVC 用 Jackson 自动把对象序列化为 JSON。

### 4.9 修改端口与上下文路径

`src/main/resources/application.yml`（推荐用 yml 替代默认的 properties）：

```yaml
server:
  port: 8888
  servlet:
    context-path: /yoga
```

访问变为 <http://localhost:8888/yoga/hello>。

### 4.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 访问 `/hello` 报 404 | Controller 类没放在启动类的同包/子包下；或忘了 `@RestController` |
| 启动报 `Port 8080 was already in use` | 改 `server.port` 到别的端口；或用 `netstat -ano \| findstr 8080` 查占用 |
| 浏览器看到中文乱码 | 加 `application.yml`：`server.servlet.encoding.force=true` |
| Lombok 注解不生效 | IDEA 里 `Settings → Compiler → Annotation Processors` 勾"Enable" |
| 用了 `@Controller` 而不是 `@RestController` | 会当成视图返回，需要额外加 `@ResponseBody` |

### 4.11 练习/思考

1. 用 Spring Initializr 生成 `yoga-member` 项目并跑通 `/hello`，截图。
2. 写 `/api/course/list` 接口返回瑜伽课程 JSON 数组，截图。
3. 修改端口为 8888、上下文为 `/yoga`，访问 <http://localhost:8888/yoga/api/course/list> 验证。
4. **思考**：如果不用 Spring Initializr，你能否手写一个纯 `pom.xml` 只引入 `spring-boot-starter-web:4.0.0`，跑出同样效果？

---

## 第 5 讲：分层解耦 + Controller/Service/Mapper + IOC/DI

### 5.1 引入：把所有代码塞进 Controller 会怎样？

假设一段 200 行的 Controller，同时干了 4 件事：**参数校验 + SQL 拼接 + 业务判断 + 返回 JSON**。会有什么问题？

- 一个改动波及全局（改 SQL 要碰 Controller）；
- 测试无从下手（业务逻辑和 HTTP 混在一起）；
- 无法复用（同一段逻辑要在 Controller 和定时任务里各写一遍）；
- 团队协作困难（前端、后端、DBA 都在改同一个类）。

**解决之道：分层 = 关注点分离**。

### 5.2 经典三层架构

```
┌────────────────────────────┐
│  Controller  表现层         │  @RestController / @Controller
│  接收请求、参数校验、返回响应 │
└─────────────┬──────────────┘
              ↓
┌────────────────────────────┐
│  Service    业务层          │  @Service
│  业务规则、事务边界          │
└─────────────┬──────────────┘
              ↓
┌────────────────────────────┐
│  Mapper/DAO 持久层          │  @Mapper（MyBatis）/ @Repository
│  数据库访问                 │
└─────────────┬──────────────┘
              ↓
          (MySQL)
```

🎯 **一句话记忆**：**Controller 接请求、Service 讲逻辑、Mapper 拿数据**。

### 5.3 IOC 与 DI

- **IOC**（Inversion of Control，控制反转）：对象的**创建**交给 Spring 容器；
- **DI**（Dependency Injection，依赖注入）：容器把依赖**送到**对象里。

💡 **类比**：从前你自己去菜市场买菜（`new UserMapper()`）；现在你告诉厨师你要吃什么，食材他会送到你面前（`@Autowired`）。

**Bean 的声明**（把类交给 Spring 管）：

| 注解 | 用于 |
|---|---|
| `@Component` | 通用组件 |
| `@Service` | 业务组件（Service 层） |
| `@Repository` | 数据访问组件（DAO 层） |
| `@Controller` / `@RestController` | 表现层组件 |
| `@Configuration` + `@Bean` | 配置类里手动声明 Bean |

**依赖的注入**（把依赖送进来）：

| 方式 | 写法 | 评价 |
|---|---|---|
| **字段注入** | `@Autowired private XxxService xxx;` | 简洁但难做单元测试，不推荐 |
| **构造器注入** ✅ | Lombok `@RequiredArgsConstructor` + `private final XxxService xxx;` | 官方推荐，`final` 保证不可变 |
| **Setter 注入** | 写 setter 加 `@Autowired` | 少用 |

**`@Autowired` vs `@Resource`**：

| 注解 | 出身 | 匹配方式 |
|---|---|---|
| `@Autowired` | Spring | 按**类型**匹配，找不到唯一时按名字兜底 |
| `@Resource` | JSR-250（Java 标准） | 按**名字**匹配 |

### 5.4 主线代码示例：`/api/course/list`

#### 持久层 CourseMapper

```java
package com.yinxiang.yogamember.mapper;

import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface CourseMapper {
    List<String> findAll();
}
```

> 💡 本讲暂不连数据库，第 4 天讲 MyBatis 时再补充 SQL。当前实现可先在 Service 里返回硬编码。

#### 业务层接口 CourseService

```java
package com.yinxiang.yogamember.service;

import java.util.List;

public interface CourseService {
    List<String> list();
}
```

#### 业务层实现 CourseServiceImpl

```java
package com.yinxiang.yogamember.service.impl;

import com.yinxiang.yogamember.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    // 构造器注入（Lombok 自动生成构造器）
    // private final CourseMapper courseMapper;

    @Override
    public List<String> list() {
        // 暂时硬编码，Day04 学 MyBatis 后改为 courseMapper.findAll()
        return List.of("哈他瑜伽", "阴瑜伽", "阿斯汤加", "流瑜伽");
    }
}
```

#### 表现层 CourseController

```java
package com.yinxiang.yogamember.controller;

import com.yinxiang.yogamember.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/course")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;   // ✅ 构造器注入

    @GetMapping("/list")
    public List<String> list() {
        return courseService.list();
    }
}
```

**运行结果**：访问 <http://localhost:8080/api/course/list> 返回：

```json
["哈他瑜伽","阴瑜伽","阿斯汤加","流瑜伽"]
```

### 5.5 为什么要"接口 + 实现类"？

- **可替换**：`CourseServiceImpl` 换成 `CachedCourseServiceImpl`，Controller 一行不改；
- **可测试**：单元测试可用 Mock 实现替代真实实现；
- **面向接口编程**：Java 界的通用原则。

### 5.6 Bean 作用域

- `singleton`（默认）：整个应用只有一个实例，**Controller/Service/Mapper 全用它**；
- `prototype`：每次获取都是新对象；
- `request` / `session`（Web 环境）：请求或会话级。

📌 大多数 Spring Bean 都是 `singleton`，注意**不要在 Bean 里存请求相关状态**（否则并发时会串数据）。

### 5.7 配置文件 `application.yml`

```yaml
server:
  port: 8080

spring:
  application:
    name: yoga-member

logging:
  level:
    com.yinxiang: debug
```

推荐 yml 而非 properties——层级用 2 空格缩进，更直观。

### 5.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 启动报 `NoSuchBeanDefinitionException` | 类没加 `@Service` / `@Mapper`；或类不在启动类的子包 |
| 字段注入 + Lombok `@RequiredArgsConstructor` 不生效 | 字段要加 `final`，且不要用 `@Autowired`；反之字段注入不要加 `final` |
| 一个接口有两个实现类，`@Autowired` 报歧义 | 用 `@Qualifier("beanName")` 或 `@Primary` |
| Mapper 类没写 `@Mapper` 就直接 `@Autowired` | 报错。要么加 `@Mapper`，要么在启动类加 `@MapperScan("com.yinxiang.yogamember.mapper")` |
| Service 里直接 `new UserMapper()` | 破坏了 IOC，Bean 之间必须**通过容器**关联 |

### 5.9 练习/思考

1. 按三层结构完成 `/api/course/list` 接口，浏览器返回瑜伽课程 JSON 数组。
2. 再写一个 `/api/member/count` 接口（返回硬编码 128），走完整三层。
3. 让通义灵码为 `Category`（id/name/code/createTime）生成完整三层 CRUD 骨架，跑通 GET `/api/category`。
4. **思考**：如果去掉 `CourseService` 接口，只保留实现类，代码还能跑吗？会失去什么好处？

---

## 第 6 讲：Spring Boot 启动原理 + `@SpringBootApplication` 剖析

### 6.1 引入：Spring Boot 的"魔法"

**为什么加个 `@SpringBootApplication` 就能自动跑起来？内嵌 Tomcat 谁启动的？我只写了一个 `main()` 啊！**

今天揭开这层魔法。

### 6.2 `@SpringBootApplication` 拆解

用 IDEA `Ctrl` + 点 `@SpringBootApplication`，你会看到源码：

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
@SpringBootConfiguration          // ①
@EnableAutoConfiguration          // ②
@ComponentScan(...)               // ③
public @interface SpringBootApplication { ... }
```

**三大注解**：

| 注解 | 作用 | 底层 |
|---|---|---|
| **① `@SpringBootConfiguration`** | 声明这是一个配置类 | 等价于 `@Configuration` |
| **② `@EnableAutoConfiguration`** | 打开自动装配开关 | 内含 `@Import(AutoConfigurationImportSelector.class)` |
| **③ `@ComponentScan`** | 扫描 `@Component/@Service/...` 声明的 Bean | 默认从启动类所在包开始 |

🎯 **一句话**：`@SpringBootApplication` = 配置类 + 自动装配 + 组件扫描。

### 6.3 自动装配的秘密：`AutoConfiguration.imports`

Spring Boot 4 起（2.7 之前叫 `spring.factories`），自动配置类清单放在：

```
META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
```

打开 `spring-boot-autoconfigure-4.0.0.jar`，你会看到几百行：

```
org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration
org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration
org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration
... (200+ 行)
```

**流程**：

1. 启动时读该文件，把所有 `xxxAutoConfiguration` 类都加载进来；
2. 每个 `AutoConfiguration` 类头部有 `@ConditionalOnXxx` 判定条件；
3. **条件成立才生效**——引入 `spring-boot-starter-web` 就自动装配 Spring MVC + Tomcat，没引入就跳过。

**举例**：`WebMvcAutoConfiguration` 头部：

```java
@AutoConfiguration
@ConditionalOnClass({Servlet.class, DispatcherServlet.class})
@ConditionalOnWebApplication(type = Type.SERVLET)
@ConditionalOnMissingBean(WebMvcConfigurationSupport.class)
public class WebMvcAutoConfiguration { ... }
```

翻译：**类路径下有 Servlet 和 DispatcherServlet + 是 Servlet 型 Web 应用 + 用户没自定义 WebMvcConfigurationSupport → 才生效**。

### 6.4 常见 `@ConditionalOnXxx`

| 注解 | 条件 |
|---|---|
| `@ConditionalOnClass` | 类路径下有某个类 |
| `@ConditionalOnMissingClass` | 类路径下**没有**某个类 |
| `@ConditionalOnBean` | 容器里已有某个 Bean |
| `@ConditionalOnMissingBean` | 容器里**没有**某个 Bean（用户没自定义时才生效） |
| `@ConditionalOnProperty` | 配置文件里指定属性=某值 |
| `@ConditionalOnWebApplication` | 是 Web 应用 |

### 6.5 Spring Boot 启动 7 步

```
① main()
   ↓
② SpringApplication.run(App.class, args)
   ↓
③ 创建 ApplicationContext（IOC 容器）
   ↓
④ 读取 META-INF/spring/AutoConfiguration.imports
   ↓
⑤ 按 @ConditionalOnXxx 过滤，装配生效的 AutoConfiguration
   ↓
⑥ 扫描 @Component / @Service / ... 注册 Bean
   ↓
⑦ 若是 Web 项目 → 启动内嵌 Tomcat（默认 8080）
   ↓
   打印 "Started XXX in x.xxx seconds"
```

### 6.6 `application.yml` + 多环境 profile

**主配置** `application.yml`：

```yaml
server:
  port: 8080
  servlet:
    context-path: /api

spring:
  application:
    name: yoga-member
  profiles:
    active: dev              # 激活 dev 环境

logging:
  level:
    com.yinxiang: debug
```

**开发环境** `application-dev.yml`：

```yaml
server:
  port: 8080

spring:
  datasource:
    url: jdbc:mysql://localhost:3306/yoga
    username: root
    password: 123456
```

**生产环境** `application-prod.yml`：

```yaml
server:
  port: 80

spring:
  datasource:
    url: jdbc:mysql://prod-db:3306/yoga
    username: yoga_prod
    password: ${DB_PWD}      # 从环境变量读，不硬编码密码
```

**切换环境**：改 `spring.profiles.active` 为 `dev` / `prod` / `test` 即可。启动日志会看到：

```
The following 1 profile is active: "dev"
```

### 6.7 常用 Spring Boot 注解速查

| 注解 | 作用 |
|---|---|
| `@SpringBootApplication` | 启动类三合一注解 |
| `@RestController` | `@Controller + @ResponseBody`，返回 JSON |
| `@RequestMapping` | 通用路径映射 |
| `@GetMapping/@PostMapping/...` | REST 语义映射 |
| `@RequestParam` | 绑定 URL 参数 |
| `@PathVariable` | 绑定路径变量 |
| `@RequestBody` | 绑定 JSON 请求体 |
| `@Autowired` | 按类型注入（Spring） |
| `@Resource` | 按名字注入（JSR-250） |
| `@Component/@Service/@Repository/@Controller` | 声明 Bean |
| `@Value("${...}")` | 注入配置项 |
| `@ConfigurationProperties(prefix="...")` | 注入配置对象 |

### 6.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Ctrl 点进 `@SpringBootApplication` 一层一层迷失 | 只看一层就退回来，别追到 JDK 底层 |
| 明明加了 `application-dev.yml` 但没生效 | 主 `application.yml` 里没写 `spring.profiles.active: dev` |
| 想禁用某个自动配置 | 用 `@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})` |
| 配置文件里的中文乱码 | 保存为 UTF-8；IDEA `Settings → File Encodings → Properties Files` 勾"Transparent native-to-ascii" |
| 感觉自动装配"太多"担心慢 | 只有满足 `@ConditionalOnXxx` 的会生效，实际大约几十个，不用担心 |

### 6.9 练习/思考

1. Ctrl 点进 `@SpringBootApplication`，找到并截图三大注解组合。
2. 打开 `spring-boot-autoconfigure-4.0.0.jar` 里的 `AutoConfiguration.imports`，数一数有多少个 AutoConfiguration 类。
3. 为 `yoga-member` 建立 dev / prod 两套配置，dev 端口 8080、prod 端口 80，切换 `spring.profiles.active` 验证日志。
4. **思考**：如果我把 `HelloController` 挪到 `com.other.pkg` 包（不在启动类子包），访问 `/hello` 会怎样？为什么？

---

## Day03 学完你应该会

1. ✅ 在 Windows 下装好 Maven 3.9.9 并配好阿里云镜像；
2. ✅ 在 IDEA 里用 Spring Initializr 新建 `yoga-member` Spring Boot 4 项目；
3. ✅ 读懂 `pom.xml` 骨架，会加依赖、看依赖树、排冲突；
4. ✅ 记住 Maven 6 条常用命令：`clean / compile / test / package / install / dependency:tree`；
5. ✅ 写出 `@RestController` + `@GetMapping` 跑通 `/hello`；
6. ✅ 用三层结构完成 `/api/course/list`：Controller → Service → Mapper；
7. ✅ 说清 `@SpringBootApplication` 的三大注解组合和自动装配原理；
8. ✅ 会用 `application.yml` + `spring.profiles.active` 切换多环境。

## 附录：主线项目 `pom.xml` 参考

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>4.0.0</version>
    </parent>

    <groupId>com.yinxiang</groupId>
    <artifactId>yoga-member</artifactId>
    <version>1.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <properties>
        <java.version>25</java.version>
        <maven.compiler.source>25</maven.compiler.source>
        <maven.compiler.target>25</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

## 附录：AI 辅助写代码（通义灵码 / Trae）

在 IDEA 侧栏发送：

```text
使用 Spring Boot 4 + Lombok，为 yoga-member 项目的实体 Category（id, name, code, createTime）生成：
1. Entity 类（Lombok @Data）
2. Mapper 接口（@Mapper，MyBatis 注解方式：findAll/findById/insert/update/deleteById）
3. Service 接口 + Impl（构造器注入）
4. Controller（RESTful：GET/POST/PUT/DELETE /api/category）
5. 返回类型统一用 List<Category> / Category / Void
```

AI 会一次性输出 4—5 个文件。**每段 AI 输出必须自己看懂再粘贴**，注意 4 个点：
1. `@Mapper` 有没有加？
2. `@Service` 有没有加？
3. 是不是构造器注入（`@RequiredArgsConstructor` + `private final`）？
4. Controller 类是不是在启动类的**子包**下？
