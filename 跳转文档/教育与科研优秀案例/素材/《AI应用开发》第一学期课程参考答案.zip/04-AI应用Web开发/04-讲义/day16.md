# 《AI 应用 Web 开发》 - 学生讲义（Day16：Docker 入门 + Dockerfile 镜像构建）

**总讲次：6 讲**
**适用对象：已完成 Day01–Day15 的学生（掌握 Spring Boot 4.0.x 后端全链路、Vue 3 + Vite 前端全部页面、`pnpm build` 打包、Ubuntu 22.04 服务器 SSH 登录、Nginx 反代 + systemd 托管 Jar、`deploy.sh` 一键部署）**

**技术版本基线**：Docker 24.0+ / Docker Compose v2 / OpenJDK 25 / Spring Boot 4.0.x / Node 20 LTS / pnpm 9 / Vue 3.5+ / Vite 5.4+ / Nginx 1.27-alpine / MySQL 8 / Redis 8-alpine / Ubuntu 22.04 LTS。

**课程主线项目**：印想瑜伽会馆客户管理系统（`yoga-member`）。Day15 用「手工 apt 装 JDK / MySQL / Nginx + systemd + `deploy.sh` scp jar」把项目搬上了 Ubuntu 22.04，链路能跑；但**换个服务器就得重新装一次**、**JDK 版本一升级 systemd 就崩**、**MySQL 数据升级要备份还原**——工业交付的最后一公里还差一步。Day16 用 Docker 把这一公里彻底铺平：前 3 讲把 Docker「壳」讲透——镜像 / 容器概念、`docker run` 一条命令起 MySQL / Redis / Nginx 一线中间件、`-p` / `-v` / `-e` 三大参数把「端口 / 数据 / 配置」外置；中间 1 讲把 Dockerfile 从零讲到会写；后 2 讲用多阶段构建把 `yoga-server`（Spring Boot + JDK 25 jar）和 `yoga-web`（Vue + Vite dist）都打成体积可控的镜像。**Day16 结束后你的项目从此可复制、可回滚、可跨机迁移**，为 Day17 用 `docker compose` 一次拉起整个技术栈铺路。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | Docker 安装与快速入门（镜像 / 容器概念） | `docker version` + 加速配置 + `hello-world` 六步解读 |
| 第 2 讲 | 常用命令 + MySQL 容器实战 | 一条 `docker run` 起 MySQL 8，DBeaver 直连 |
| 第 3 讲 | 数据卷（bind mount vs named volume）+ Redis 持久化 | 容器随便删、数据不丢 |
| 第 4 讲 | Dockerfile 基础语法 | `hello:v1` 从零手写 |
| 第 5 讲 | 多阶段构建 + Spring Boot 镜像 | `yoga-backend:1.0.0` < 250MB · healthy |
| 第 6 讲 | Vue 项目镜像 + 镜像优化 | `yoga-web:1.0.0` < 60MB · SPA fallback · `/api/` 反代 |

---

## 第 1 讲：Docker 安装与快速入门（镜像 / 容器概念）

### 1.1 引入：从「本地能跑」到「可复制交付」

Day15 我们把 `yoga-member` 搬上了 Ubuntu 22.04：`apt` 装 JDK 25、MySQL 8、Nginx 1.24，`systemctl` 托管 jar，`ufw` 放通防火墙——一切都能跑。但今天有人问你：「我这有台新买的云主机，帮我十分钟内跑起来」。你会发现三个痛点扑面而来：

1. **环境不一致**——新主机上 JDK 是 21 不是 25，MySQL 是 5.7 不是 8，Nginx 端口 80 被 Apache 占用；
2. **升级易崩**——JDK 升级、MySQL 升级都可能触发 systemd 单元找不到路径；
3. **迁移昂贵**——每换一台机器都要重跑一遍 30 分钟的装机脚本。

🎯 **一句话目标**：**理解容器是什么、装好 Docker 24、跑通 hello-world 六步日志、能背四大概念**。

### 1.2 容器 vs 虚拟机

**容器**是把应用及其运行时依赖打包在一起的**标准化交付单元**。核心与虚拟机的差别在于「共享 Host OS 内核」：

| 项 | 虚拟机 | 容器 |
|----|--------|------|
| 隔离层 | Hypervisor + Guest OS | 共享 Host OS 内核 + namespace/cgroup |
| 启动 | 几十秒 | 亚秒级 |
| 镜像 | GB 级 | MB 级 |
| 密度 | 单机 10~20 台 | 单机数百容器 |
| 隔离强度 | 强 | 中（够用） |

**Docker 解决的核心问题**：「在我机器上能跑，你那不行」——容器把环境固化成镜像，跑到哪儿都是同一份。

🎯 **警示**：容器共享内核意味着**内核漏洞可能跨容器逃逸**，不适合跑不受信任的第三方代码。生产级隔离仍用虚拟机 + 容器双层。

### 1.3 四合一关系：Dockerfile / Image / Container / Registry

```
Dockerfile ──build──▶ Image ──run──▶ Container
                         │
                         └──push──▶ Registry（DockerHub / 阿里 ACR / 私有仓库）
```

四者的定位：

- **Dockerfile**：一份文本文件，描述「如何从零构建一个镜像」——类似菜谱；
- **Image**：分层文件系统的只读模板，可传输、可版本化——类似类；
- **Container**：镜像的运行实例，多一层可写层——类似对象；
- **Registry**：镜像的仓库，多台机器共享同一份镜像的中转站——类似 Maven Central。

**关键类比**：**Image : Container = 类 : 对象**。一个镜像可以起 N 个容器，每个容器独立可写层，删了不影响别的。

### 1.4 安装 Docker 24 on Ubuntu 22.04

**官方一键脚本**（推荐）：

```bash
# 一键装 Docker Engine（客户端 + dockerd + containerd）
curl -fsSL https://get.docker.com | sudo bash

# 免 sudo（重开终端才生效）
sudo usermod -aG docker $USER
newgrp docker

# 验证
docker version
docker run hello-world
```

装完后 `docker version` 应输出**客户端 + 服务端两段**版本号，都是 24+。

🎯 **警示**：`apt install docker.io` 装的是 Ubuntu 仓库里的社区旧版（20.x），**不要用**。走上面的官方脚本，或按 [Docker 官方 apt 源指引](https://docs.docker.com/engine/install/ubuntu/) 加官方仓库。

### 1.5 配置国内镜像加速

不配加速，`docker pull` 常常卡死。编辑 `/etc/docker/daemon.json`：

```json
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com"
  ]
}
```

生效并验证：

```bash
sudo systemctl restart docker
docker info | grep -A2 "Registry Mirrors"
```

若能看到列出的两个 URL 即配置成功。

🎯 **警示**：国内公共加速源经常变动，最新可用列表参考 https://docker-practice.github.io/。企业环境应搭建私有 Registry 或购买阿里云 / 腾讯云 ACR。

### 1.6 Docker Desktop（Windows / Mac 开发机）

- Windows：官网下载 Docker Desktop，安装时勾选 **WSL2 集成**；家庭版需先启用 WSL2；BIOS 中打开 VT-x / SVM 虚拟化；
- Mac：官网下载 Docker Desktop for Mac（Intel / Apple Silicon 各有版本）；
- 装完后 `docker version` 一样能看到「客户端 + 服务端」，服务端跑在虚拟机里。

### 1.7 hello-world 六步日志解读

`docker run hello-world` 首次运行输出的关键六行：

```
① Unable to find image 'hello-world:latest' locally
② latest: Pulling from library/hello-world
③ Digest: sha256:...
④ Status: Downloaded newer image for hello-world:latest
⑤ Hello from Docker!
⑥ 1. The Docker client contacted the Docker daemon.
   2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
   3. The Docker daemon created a new container from that image ...
```

对应六步流水线：

- ① 本地未命中 → ② 从 Docker Hub 拉 → ③ 内容校验（sha256）→ ④ 存入本地镜像库 → ⑤ 容器实际输出 → ⑥ 官方总结的六步。

### 1.8 镜像的可传输性

镜像本质是一个**分层 tar 包**，可 save / load：

```bash
docker save nginx:1.27 -o nginx-1.27.tar   # 200MB 左右
docker rmi nginx:1.27                       # 删本地
docker load -i nginx-1.27.tar               # 装回
docker images | grep nginx                  # 验证还在
```

意味着**镜像可以走 U 盘、走 scp、走内网仓库**——离线机房也能交付。

### 1.9 本讲小结

- Docker = 把应用 + 依赖打包成**标准可传输镜像**的引擎；
- 装机三步：`get.docker.com` 一键脚本 → `usermod -aG` 免 sudo → `daemon.json` 加速；
- 校验三条：`docker version` / `docker info` / `docker run hello-world`；
- 四合一关系：**Dockerfile → build → Image → run → Container；Image → push → Registry**。

---

## 第 2 讲：常用命令（pull / run / exec / logs / rm / rmi）+ MySQL 容器实战

### 2.1 引入：一条命令 vs 30 分钟装机

Day15 装 MySQL 8 的步骤：`apt install` → `mysql_secure_installation` → 改 `my.cnf` → 建库建用户授权 → `systemctl restart`，至少 30 分钟。Day16 只需一条命令：

```bash
docker run -d --name mysql -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=root \
  -e MYSQL_DATABASE=yoga \
  -e TZ=Asia/Shanghai \
  mysql:8
```

🎯 **一句话目标**：**熟练镜像四剑客 + 容器七剑客，用一条 `docker run` 起 MySQL 8 并从宿主机连上**。

### 2.2 镜像操作四剑客

```bash
# 搜索
docker search mysql

# 拉取
docker pull mysql:8
docker pull redis:8-alpine
docker pull nginx:1.27-alpine

# 列出本地镜像
docker images

# 打标签（换个名字，指向同一个 image ID）
docker tag mysql:8 my-mysql:dev

# 删除
docker rmi my-mysql:dev

# 清理悬空镜像（<none>:<none>）
docker image prune -f
```

镜像名格式：`[registry/]namespace/name:tag`，例如 `registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0`。缺省 registry = Docker Hub，缺省 namespace = `library/`，缺省 tag = `latest`。

### 2.3 容器操作七剑客

```bash
# 运行
docker run -d --name web -p 8080:80 nginx:1.27-alpine
#   -d           后台守护
#   --name web   命名（不给会随机分配）
#   -p 8080:80   端口映射 host:container

# 列表
docker ps            # 只看运行中
docker ps -a         # 全部（含退出）

# 日志
docker logs web
docker logs -f --tail 100 web       # 实时跟随 + 只看最近 100 行

# 进入容器（新会话）
docker exec -it web sh              # alpine 没 bash，用 sh
docker exec -it mysql bash          # mysql 有 bash

# 启停
docker stop  web
docker start web
docker restart web

# 删除（-f 强杀 + 删）
docker rm -f web

# 复制文件（双向）
docker cp index.html web:/usr/share/nginx/html/
docker cp web:/var/log/nginx/access.log ./
```

**`docker run` 三大黄金参数**：

| 参数 | 含义 | 反例 |
|------|------|------|
| `-d` | 后台守护 | 不加 → 前台阻塞，Ctrl+C 直接退容器 |
| `--name` | 容器命名 | 不加 → 随机名（如 `admiring_einstein`）不好后续操作 |
| `-p host:container` | 端口映射 | 写反 → 宿主机连不上 |

### 2.4 `exec -it` 的 `-it` 是什么

`docker exec -it mysql bash` 中：

- `-i`（`--interactive`）：保持 STDIN 打开——你键盘输入的字符能传进容器；
- `-t`（`--tty`）：分配伪终端——`bash` 需要 TTY 才不会秒退；
- **缺一不可**，缺了看起来「进去了但立刻退出」。

🎯 **警示**：alpine 基础的镜像（如 `nginx:1.27-alpine`、`redis:8-alpine`）**不带 bash**，只能用 `sh`。

### 2.5 MySQL 容器实战

**一条命令起 MySQL 8**：

```bash
docker run -d --name mysql \
  -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=root \
  -e MYSQL_DATABASE=yoga \
  -e TZ=Asia/Shanghai \
  mysql:8
```

**观察启动**：

```bash
docker logs -f mysql
# 等到看到 “ready for connections. Version: '8.x.x'”
```

**从宿主机连**：

- DBeaver / Navicat / IDEA Database：`localhost:3306` / root / root，选库 `yoga`；
- 命令行：`mysql -h 127.0.0.1 -P 3306 -uroot -proot yoga`。

**进容器内**：

```bash
docker exec -it mysql bash
mysql -uroot -p                    # 输 root
use yoga;
create table yoga_test(id int primary key, name varchar(20));
insert into yoga_test values (1, 'demo');
select * from yoga_test;
exit
exit
```

**验证宿主机能看到刚才建的表**——DBeaver 里刷新，同一份数据。

### 2.6 容器一起就挂：先看日志

故意犯一个错：

```bash
docker run -d --name mysql-bad mysql:8     # 漏了 MYSQL_ROOT_PASSWORD
```

容器几秒后自动退出。诊断流程：

```bash
docker ps -a                       # 状态 Exited (1)
docker logs mysql-bad              # 输出错误说明
# You need to specify one of the following as an environment variable:
#   - MYSQL_ROOT_PASSWORD
#   - MYSQL_ALLOW_EMPTY_PASSWORD ...
```

**容器一起就挂 → 第一反应 `docker logs`**，别再重启浪费时间。

### 2.7 端口映射的三种写法

```bash
docker run -d -p 8080:80 nginx:1.27-alpine          # host 8080 → 容器 80
docker run -d -p 80:80  nginx:1.27-alpine           # 直接暴露 80（需要 root 或 CAP_NET_BIND_SERVICE）
docker run -d -p 127.0.0.1:8080:80 nginx:1.27-alpine # 只监听本机 → 外网访问不了
docker run -d -P nginx:1.27-alpine                   # 随机分配 host 端口，docker ps 里看具体端口
```

🎯 **警示**：容器端口是**容器内部的**（对应容器里进程监听的端口），宿主机上访问要用 host 端口。防火墙 / 云安全组要放通 host 端口，容器内部端口对外不可见。

### 2.8 一次性容器：`--rm`

```bash
docker run --rm -it alpine sh          # 退出即自动删除
docker run --rm alpine echo "hello"    # 跑一次立刻消失
```

调试临时用，不留垃圾容器。

### 2.9 `docker cp` 双向传文件

```bash
# 宿主 → 容器
echo "SELECT 1;" > q.sql
docker cp q.sql mysql:/tmp/
docker exec mysql mysql -uroot -proot -e "source /tmp/q.sql"

# 容器 → 宿主
docker cp mysql:/var/log/mysql/error.log ./
```

### 2.10 常见坑

- **端口被占** `port is already allocated` → `ss -tlnp | grep 3306` 找到占用者；
- **exec 秒退** → `-it` 少了；alpine 用 `sh` 不是 `bash`；
- **DBeaver 连不上**：先 `docker ps` 确认 `0.0.0.0:3306->3306/tcp` 在；再确认 root 密码对；
- **MySQL 8 认证** `caching_sha2_password` 与老客户端不兼容 → 换新版 Navicat / DBeaver 或 `--default-authentication-plugin=mysql_native_password`；
- **中文乱码 / 时区错**：`-e TZ=Asia/Shanghai` + `--character-set-server=utf8mb4`；
- **容器随手删就丢数据**——下一讲挂卷解决。

### 2.11 本讲小结

- 镜像四剑客：`pull` / `images` / `tag` / `rmi`；
- 容器七剑客：`run` / `ps` / `logs` / `exec` / `stop` / `start` / `rm`；
- `docker run` 三黄金：`-d` / `--name` / `-p`；
- 一条命令起 MySQL 8：`docker run -d --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root mysql:8`；
- 排障公式：容器一挂 → `docker ps -a` → `docker logs`。

---

## 第 3 讲：数据卷（bind mount vs named volume）+ Redis 数据持久化

### 3.1 引入：`restart` 数据还在，`rm` 数据没了

上一讲的作业：Redis `SET name yoga` → `docker restart redis` → `GET name` 返回什么？**返回 `"yoga"`**。因为 `restart` 只是重启容器进程，容器的**可写层**没销毁。但如果 `docker rm -f redis`，那这一层就没了，重新 run 一个新容器数据就是空的。

🎯 **一句话目标**：**理解容器分层存储，掌握两种数据持久化方式（命名卷 / 绑定挂载），让 MySQL / Redis 随便删也不丢数据**。

### 3.2 容器分层存储模型

```
┌───────────────────┐
│  可写层（容器）    │   ← rm 时销毁
├───────────────────┤
│  只读层 3          │
│  只读层 2          │   ← 镜像层，多个容器共享
│  只读层 1          │
└───────────────────┘
```

每层是上一层的 diff（叠加文件系统，通常是 overlay2）。容器写入的所有变更进「可写层」；镜像层只读、多容器共享。

**数据持久化的解法：把关键目录挂到容器外部的 Volume**：

```
容器 ────挂载 ────▶  Volume（宿主机 /var/lib/docker/volumes/... 或 host 绝对路径）
                    ↑ 数据独立于容器生命周期
```

### 3.3 命名卷（Named Volume）

Docker 管理路径、生命周期独立、生产数据首选。

```bash
# 显式创建（run 时若卷不存在也会自动创建）
docker volume create yoga-mysql

# 列出
docker volume ls

# 查详情
docker volume inspect yoga-mysql
# 关键字段 Mountpoint: /var/lib/docker/volumes/yoga-mysql/_data

# 挂给容器
docker run -d --name mysql \
  -p 3306:3306 \
  -v yoga-mysql:/var/lib/mysql \
  -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=yoga \
  mysql:8
```

**验证「容器随便删」**：

```bash
# 建表插数据（DBeaver 或 docker exec 都行）
docker rm -f mysql                        # 删容器
docker run -d --name mysql \
  -p 3306:3306 -v yoga-mysql:/var/lib/mysql \
  -e MYSQL_ROOT_PASSWORD=root mysql:8     # 用同一个卷起新容器
# → 老数据还在，能查得到
```

### 3.4 绑定挂载（Bind Mount）

直接把宿主机某个目录挂进容器。开发场景（改代码即时同步）、配置文件、日志目录首选。

```bash
sudo mkdir -p /var/www/yoga
echo "<h1>hello yoga</h1>" | sudo tee /var/www/yoga/index.html

docker run -d --name web \
  -p 8080:80 \
  -v /var/www/yoga:/usr/share/nginx/html:ro \
  nginx:1.27-alpine
```

- `:ro` 表示容器内**只读**，防误改；
- 修改宿主机 `/var/www/yoga/index.html`，浏览器刷 `localhost:8080`——**秒变**，同一份文件；
- **必须绝对路径**——写 `./data:/data` Docker 会当成命名卷或报错。

### 3.5 命名卷 vs 绑定挂载对比

| 维度 | 命名卷 | 绑定挂载 |
|------|--------|----------|
| 路径管理者 | Docker | 你自己 |
| 存储位置 | `/var/lib/docker/volumes/<name>/_data` | 宿主机你指定的路径 |
| 备份方式 | `docker run --rm -v vol:/data alpine tar czf - /data` | 直接 `tar czf ... /host/path` |
| 跨机迁移 | 卷本身要打包传输 | 目录直接 `rsync` |
| 权限管理 | Docker 自动匹配 UID | 你自己 `chown` |
| 生产推荐 | ★★★★★ | 配置 / 日志 / 静态资源 |
| 开发推荐 | ★★★ | ★★★★★（代码热挂载） |

**选型口诀**：**「数据库数据用命名卷；配置 / 日志 / 静态资源用 bind mount + `:ro`」**。

### 3.6 权限 UID 坑

MySQL 官方镜像里 `mysqld` 用 UID `999` 运行。如果你把宿主机某目录 bind mount 到 `/var/lib/mysql`，而该目录属主是 `root:root`——容器内进程**没有写权限**，启动直接挂：

```bash
sudo chown -R 999:999 /path/on/host   # 手工改属主
```

或者：**用命名卷代替 bind mount**，Docker 会自动处理属主，一劳永逸。

### 3.7 Redis 持久化实战

```bash
docker volume create yoga-redis

docker run -d --name redis \
  -p 6379:6379 \
  -v yoga-redis:/data \
  redis:8-alpine \
  --appendonly yes --requirepass "yoga123"
```

- `-v yoga-redis:/data`：Redis 数据目录挂到卷；
- `--appendonly yes`：开启 AOF 追加持久化，写命令实时落 `/data/appendonly.aof`；
- `--requirepass "yoga123"`：强制密码。

**验证**：

```bash
docker exec -it redis redis-cli -a yoga123
> SET name yoga
> exit

docker rm -f redis                             # 删掉

docker run -d --name redis -p 6379:6379 \
  -v yoga-redis:/data \
  redis:8-alpine --appendonly yes --requirepass "yoga123"

docker exec -it redis redis-cli -a yoga123
> GET name
"yoga"                                          # 还在！
```

### 3.8 Nginx 配置热更实战

生产 Nginx 常用做法：静态目录挂 bind mount（改文件秒生效）、配置目录挂 bind mount 只读（改后 reload）。

```bash
sudo mkdir -p /opt/yoga/nginx/conf.d
sudo tee /opt/yoga/nginx/conf.d/default.conf > /dev/null <<'EOF'
server {
    listen 80;
    server_name _;
    root  /usr/share/nginx/html;
    index index.html;
    gzip on;
}
EOF

docker run -d --name nginx \
  -p 8080:80 \
  -v /var/www/yoga:/usr/share/nginx/html:ro \
  -v /opt/yoga/nginx/conf.d:/etc/nginx/conf.d:ro \
  nginx:1.27-alpine
```

修改宿主机 `default.conf` 后：

```bash
docker exec nginx nginx -s reload      # 平滑 reload，不断连接
```

比 `docker restart nginx` 优雅得多——**restart 会杀掉所有现有连接**。

### 3.9 卷的空间清理

```bash
docker volume ls
docker volume rm yoga-mysql            # 明确删除
docker volume prune                    # 删所有无引用卷（危险）
docker system prune -a --volumes       # 一网打尽——生产不要用
```

🎯 **警示**：`docker system prune -a --volumes` 会**连同数据卷一起删**，生产误跑 = 灾难。养成「只 `docker volume prune`」的习惯。

### 3.10 常见坑

- `-v` 路径必须绝对（Linux / Mac），Windows Docker Desktop 上 `C:\path` 会自动转成 `/host_mnt/c/path`；
- WSL2 里 bind mount 挂 `/mnt/c/...`（Windows 文件系统）性能奇差——建议项目放 WSL2 内部 `~/projects/...`；
- 命名卷备份：`docker run --rm -v yoga-mysql:/data -v $(pwd):/backup alpine tar czf /backup/mysql.tar.gz /data`；
- 卷跨主机迁移：`docker save` 只导镜像不导卷——卷要单独 tar；
- `--volumes-from` 复用别的容器的卷（不推荐，语义混乱）。

### 3.11 本讲小结

- 容器可写层 = rm 即销毁；数据要活得比容器长 → 挂 Volume；
- 命名卷「数据」；绑定挂载「配置 / 日志 / 静态」；
- `-v` 语法：`<name>:<path>` 或 `<host-abs-path>:<container-path>[:ro]`；
- Redis 持久化：`-v yoga-redis:/data` + `--appendonly yes`；
- Nginx 配置热更：bind mount `conf.d` + `nginx -s reload`。

---

## 第 4 讲：Dockerfile 基础语法（FROM / COPY / RUN / CMD / EXPOSE / ENV）

### 4.1 引入：DockerHub 上没有你的项目

前 3 讲用别人的镜像（mysql、redis、nginx）跑得飞起——但 DockerHub 上**没有** `yoga-server` 镜像。要打自己的镜像，就得写 Dockerfile。

🎯 **一句话目标**：**掌握 Dockerfile 九件套语法，能写并构建一个 `hello:v1` 镜像**。

### 4.2 Dockerfile 是什么

Dockerfile = **用一份文本文件描述如何从零构建一个镜像**：

- 每条指令是一层（Layer），层与层之间可缓存；
- 结果是可重复、可版本化、可交付的镜像。

**核心工作流**：

```
写 Dockerfile → docker build → 得到 Image → docker push → 服务器 pull → docker run
```

### 4.3 九件套速览

| 指令 | 作用 | 示例 |
|------|------|------|
| `FROM`       | 基础镜像 | `FROM eclipse-temurin:25-jre-alpine` |
| `WORKDIR`    | 工作目录（自动 mkdir） | `WORKDIR /app` |
| `COPY`       | 复制文件到镜像 | `COPY target/*.jar app.jar` |
| `ADD`        | 类似 COPY，还支持解压、URL（不推荐） | — |
| `RUN`        | **构建时**执行命令 | `RUN apt update && apt install -y curl && rm -rf /var/lib/apt/lists/*` |
| `CMD`        | **运行时**默认命令 | `CMD ["java","-jar","app.jar"]` |
| `ENTRYPOINT` | 入口点（与 CMD 联用） | `ENTRYPOINT ["java","-jar","app.jar"]` |
| `ENV`        | 环境变量 | `ENV TZ=Asia/Shanghai` |
| `ARG`        | 构建参数（`docker build --build-arg`） | `ARG JAR_FILE=target/app.jar` |
| `EXPOSE`     | 声明端口（**只是文档**，不做映射） | `EXPOSE 8080` |
| `USER`       | 切换运行用户 | `USER nobody` |
| `VOLUME`     | 声明卷挂载点 | `VOLUME /data` |
| `HEALTHCHECK`| 健康检查 | `HEALTHCHECK CMD wget -qO- http://localhost:8080/health || exit 1` |

### 4.4 CMD vs ENTRYPOINT

| 场景 | 表现 |
|------|------|
| 只 CMD | `docker run img` 跑 CMD；`docker run img other` 用 `other` **覆盖** CMD |
| 只 ENTRYPOINT | `docker run img` 跑 ENTRYPOINT；`docker run img x` = `ENTRYPOINT x` |
| 两者同时 | `docker run img` = `ENTRYPOINT + CMD`；`docker run img x` = `ENTRYPOINT + x`，CMD 被覆盖 |

**推荐组合**：`ENTRYPOINT ["java","-jar","app.jar"]` + `CMD ["--spring.profiles.active=prod"]`——运行时 `docker run img --spring.profiles.active=dev` 一句切环境。

**shell 形式 vs exec 形式**：

- shell：`CMD java -jar app.jar` → 实际跑 `/bin/sh -c "java -jar app.jar"`，多一层 sh 挡住信号；
- exec：`CMD ["java","-jar","app.jar"]` → 直接 exec，java 就是 PID 1，能正确接收 SIGTERM 优雅关机。

🎯 **警示**：**生产一律用 exec 形式**。shell 形式在 `docker stop` 时 java 收不到 SIGTERM，10 秒后被 SIGKILL 强杀，Spring Boot 无法执行 `@PreDestroy` / 优雅关闭连接池。

### 4.5 Hello Dockerfile

新建 `hello/`：

```
hello/
├── Dockerfile
└── hello.sh
```

`hello.sh`：

```bash
#!/bin/sh
echo "Hello from container at $(date)"
```

`Dockerfile`：

```dockerfile
FROM alpine:3.20
WORKDIR /app
COPY hello.sh .
RUN chmod +x hello.sh
CMD ["./hello.sh"]
```

构建 + 运行：

```bash
cd hello
docker build -t hello:v1 .
docker run --rm hello:v1
# Hello from container at Fri Jul 17 12:34:56 UTC 2026
```

**关键点**：

- 最后那个 `.` 是**构建上下文**——Docker 会把整个当前目录打包送给 daemon；
- `-t hello:v1` 打标签，格式 `name:tag`；
- `chmod +x hello.sh` 必须在 `COPY` 之后——**指令顺序 = 层顺序**。

### 4.6 `.dockerignore`

语法同 `.gitignore`，务必忽略构建产物、依赖、敏感文件。

**后端项目 `.dockerignore`**：

```text
.git
.gitignore
target/*
!target/*.jar
*.iml
.idea/
Dockerfile
docker-compose.yml
.env*
```

**前端项目 `.dockerignore`**：

```text
.git
node_modules
dist
.env
.env.local
.vscode
.DS_Store
```

不写 `.dockerignore` 的两个恶果：

1. **上下文传输巨大**——把整个 `.git/` `node_modules/` `target/` 都传给 daemon，构建慢；
2. **敏感文件泄进镜像**——`.env` 里的密码被 `COPY . .` 打进镜像，任何人 `docker run` 都能看到。

### 4.7 分层缓存的艺术

Docker 每条指令是一层，**从头开始第一条变化后的所有层都失效**。所以：

- 变得**少**的放前面（依赖清单、apt install）；
- 变得**多**的放后面（源代码）。

**反例**（改一行代码就重装所有依赖）：

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN pnpm i
RUN pnpm build
```

**正例**（依赖层稳定复用）：

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN npm i -g pnpm@9 && pnpm i --frozen-lockfile
COPY . .
RUN pnpm build
```

### 4.8 RUN 合并省层

反例（三层，缓存清不干净）：

```dockerfile
FROM ubuntu:22.04
RUN apt update
RUN apt install -y curl
RUN rm -rf /var/lib/apt/lists/*
```

正例（一层，缓存彻底清）：

```dockerfile
FROM ubuntu:22.04
RUN apt update \
    && apt install -y curl \
    && rm -rf /var/lib/apt/lists/*
```

镜像更小、层更少。

### 4.9 shell 形式的信号传递陷阱

演示：写两个 Dockerfile，一份 shell 一份 exec，都跑一个「循环 sleep 打时间」的 shell 脚本，`docker stop` 试一下：

- **shell 形式**：`docker stop` 后 10 秒才退出（超时 SIGKILL）；
- **exec 形式**：`docker stop` 后立即退出（进程收到 SIGTERM 正常终止）。

### 4.10 build 常用参数

```bash
docker build -t yoga-backend:1.0.0 .                # 最常用
docker build -t yoga-backend:1.0.0 -f Dockerfile.prod .   # 指定 Dockerfile
docker build --no-cache -t yoga-backend:1.0.0 .     # 强制不用缓存
docker build --build-arg VERSION=1.0.0 -t yoga-backend:1.0.0 .   # 传 ARG
docker build --platform linux/amd64 -t yoga-backend:1.0.0 .      # 强制目标架构（Mac M 系列必备）
```

### 4.11 常见坑

- `CMD ./hello.sh`（字符串） → 实际是 shell 形式；生产用 `CMD ["./hello.sh"]`；
- `RUN chmod +x hello.sh` 放在 `COPY hello.sh .` 之前 → 失败（还没复制过来）；
- alpine 里没 `bash`：`RUN /bin/bash -c "..."` 会失败；
- Mac M1/M2 打的镜像是 `linux/arm64`，push 到 `linux/amd64` 服务器上 `exec format error`——加 `--platform linux/amd64`；
- `COPY target/*.jar app.jar` 的通配符必须在 `target/*.jar` 只有一个匹配时才行——多个会报错，Spring Boot 应确认 `spring-boot-maven-plugin` 的 `<repackage>` 生效。

### 4.12 本讲小结

- 九件套：`FROM` / `WORKDIR` / `COPY` / `ADD` / `RUN` / `CMD` / `ENTRYPOINT` / `ENV` / `EXPOSE`；
- `CMD` vs `ENTRYPOINT`：默认命令（可覆盖）vs 固定入口；
- **生产一律 exec 形式**：`CMD ["cmd","arg"]`，让进程能收到 SIGTERM；
- `RUN` 合并省层 + `.dockerignore` 上下文瘦身；
- `docker build -t name:tag .` 里最后的 `.` 是构建上下文。

---

## 第 5 讲：多阶段构建 + Spring Boot 应用镜像（JDK 25 + jar）

### 5.1 引入：为什么单阶段不够

单阶段 Dockerfile 把 Maven / JDK 全打进最终镜像，体积 800MB+；而且要求**本地先 `./mvnw package`**——构建环境与本地机器绑死。

🎯 **一句话目标**：**用多阶段构建把 `yoga-server` 打成 `yoga-backend:1.0.0` 镜像，体积 < 250MB，构建过程完全在 Docker 内完成**。

### 5.2 单阶段 Dockerfile（起点）

前置：`./mvnw clean package -DskipTests` 已在本地生成 `target/yoga-server-1.0.0.jar`。

```dockerfile
FROM eclipse-temurin:25-jre-alpine
ENV TZ=Asia/Shanghai \
    JAVA_OPTS="-Xms256m -Xmx512m"

WORKDIR /app
COPY target/yoga-server-*.jar app.jar

EXPOSE 8080
ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]
```

构建 + 运行：

```bash
docker build -t yoga-backend:1.0.0 .
docker run -d --name yoga-backend -p 8080:8080 yoga-backend:1.0.0
docker logs -f yoga-backend                # 看 Spring Boot banner
```

🎯 **镜像发行版说明**：`eclipse-temurin:25-jre-alpine` 是 DockerHub 上广泛使用的 OpenJDK 官方发布镜像，与 Oracle JDK 基于同一份 OpenJDK 源码，运行时行为一致；容器场景选它是因为**镜像小、无需登录 Oracle 账号即可拉取**。本地开发（Day01–Day15）用 Oracle 官网下载的 JDK 25 完全不冲突。

**单阶段的两个缺陷**：

1. 构建依赖本机——CI 上得先装 JDK / Maven；
2. 镜像里没有构建工具，但也没做 Maven 依赖缓存优化——每次 `mvn package` 慢。

### 5.3 多阶段构建（正式版）

```dockerfile
# ============ Stage 1: 构建 ==============
FROM maven:3.9-eclipse-temurin-25 AS builder

WORKDIR /build

# 先复制 pom 与 wrapper，利用缓存下载依赖
COPY pom.xml .
COPY .mvn .mvn
COPY mvnw .
RUN chmod +x mvnw && ./mvnw dependency:go-offline -B

# 再复制源码构建
COPY src ./src
RUN ./mvnw clean package -DskipTests -B

# ============ Stage 2: 运行 ==============
FROM eclipse-temurin:25-jre-alpine
ENV TZ=Asia/Shanghai \
    JAVA_OPTS="-Xms256m -Xmx512m"

WORKDIR /app
COPY --from=builder /build/target/*.jar app.jar

EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s --start-period=30s \
  CMD wget -qO- http://localhost:8080/actuator/health || exit 1
ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]
```

**关键点逐段解析**：

- `FROM maven:3.9-eclipse-temurin-25 AS builder`：**AS builder** 给这个阶段起名，后面 `--from=builder` 引用；
- 依赖下载与源码构建**分层**——只改代码时依赖层缓存复用；
- `COPY --from=builder /build/target/*.jar app.jar`：跨阶段只拷 jar 产物，Maven / JDK 全丢；
- `HEALTHCHECK --start-period=30s`：Spring Boot 启动前 30 秒不算 unhealthy；
- `ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]` 里的 `exec` 关键——让 java 接替 sh 成 PID 1，`docker stop` 时 SIGTERM 直达 Spring Boot 触发优雅关机。

### 5.4 分层缓存实测

第 1 次 `docker build`：全量下载 Maven 依赖，耗时较长；
改一个 Controller 的字符串常量；
第 2 次 `docker build`：只跑 `COPY src ./src` 及之后的层，约 30 秒；

**加速倍数** = 6x。核心原理：**pom.xml 稳定 → 依赖层缓存复用 → 只重新构建代码层**。

### 5.5 `.dockerignore` 后端版

```text
.git
.gitignore
target
.idea
*.iml
Dockerfile
docker-compose.yml
.env*
*.log
```

- 挡 `target`：让 Docker 内 Maven 从头构建纯净版，不受本地历史构建产物影响；
- 挡 `.env*`：防敏感信息泄漏；
- 挡 `.git`：几 GB 的 `.git` 目录一起传给 daemon 会拖慢构建。

### 5.6 HEALTHCHECK 生效验证

起容器后：

```bash
docker ps                                # 状态 Up 2 seconds (health: starting)
# 等 30 秒
docker ps                                # 状态 Up 30 seconds (healthy)
docker inspect --format='{{json .State.Health}}' yoga-backend | jq
```

Compose、Kubernetes 都会消费 `healthy` 状态做流量准入、失败重启决策。

### 5.7 `JAVA_OPTS` 外部注入

生产 JVM 参数一般不写死在 Dockerfile 里，通过环境变量注入：

```bash
docker run -d --name yoga-backend -p 8080:8080 \
  -e JAVA_OPTS="-Xms512m -Xmx1024m -Duser.timezone=Asia/Shanghai" \
  yoga-backend:1.0.0
```

`docker exec yoga-backend jps -v` 应能看到新的参数生效。

### 5.8 构建、推送、拉取

```bash
# 打生产标签
docker build -t yoga-backend:1.0.0 .

# 打远程 registry 标签
docker tag yoga-backend:1.0.0 registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
docker tag yoga-backend:1.0.0 registry.cn-hangzhou.aliyuncs.com/yoga/backend:latest

# 登录 registry
docker login registry.cn-hangzhou.aliyuncs.com -u <user>

# 推送
docker push registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
docker push registry.cn-hangzhou.aliyuncs.com/yoga/backend:latest

# 服务器上拉取运行
docker pull registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
docker run -d --name backend -p 8080:8080 \
  registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
```

**镜像标签策略**：`1.0.0`（语义化） + `latest`（指向最新） + `sha-<git commit>`（追踪源码）。

### 5.9 常见坑

- 构建卡在 `dependency:go-offline`——Maven Central 慢，配阿里云仓库：`RUN mkdir -p /root/.m2 && cp settings.xml /root/.m2/`；
- jar 找不到 main class——Spring Boot Maven Plugin 未生效，确认 pom 里 `spring-boot-maven-plugin` 带 `<goal>repackage</goal>`；
- Mac M 系列 arm64 打的镜像跑不了 x86 服务器：`docker build --platform linux/amd64 -t yoga-backend:1.0.0 .`；
- `exec java` 忘写：`docker stop` 10 秒后强杀，Spring Boot 无法优雅关机；
- `.mvn` 目录漏拷：`mvnw` 起不来——两条 `COPY .mvn .mvn` / `COPY mvnw .` 都要。

### 5.10 镜像大小对比

| Dockerfile | 最终镜像大小 |
|------------|--------------|
| 单阶段 + JDK full 基础 | ≈ 700MB |
| 单阶段 + `jre-alpine` | ≈ 240MB |
| 多阶段 + `jre-alpine` | ≈ 200MB |

**目标：< 250MB**。

### 5.11 本讲小结

- 多阶段 = 构建阶段 + 运行阶段；`COPY --from=builder` 只搬产物；
- 分层缓存靠「pom 先复制、依赖先下、源码后拷、构建最后」；
- `ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]` 让 JVM 收到 SIGTERM；
- `HEALTHCHECK` + `/actuator/health` 让 `docker ps` 显示 `(healthy)`；
- 打标签 → 登录 → 推送 → 服务器 pull → run，一次构建多处运行。

---

## 第 6 讲：Vue 项目镜像（node build → nginx serve）+ 镜像优化

### 6.1 引入：前端也要标准化

Day15 里前端是「本地 `pnpm build` → scp `dist/` → Nginx 目录」。反问：dist 有版本号吗？回滚方便吗？换台 CDN 换台服务器再上一次多累？

🎯 **一句话目标**：**用多阶段 Dockerfile 把 `yoga-web` 打成 `yoga-web:1.0.0` 镜像，能被浏览器打开、二级路由刷新不 404、`/api/` 反代到后端**。

### 6.2 前端多阶段 Dockerfile

目录结构：

```
yoga-web/
├── Dockerfile
├── nginx.conf
├── .dockerignore
├── package.json
├── pnpm-lock.yaml
└── src/  public/  vite.config.ts  ...
```

`Dockerfile`：

```dockerfile
# ============ Stage 1: 打包 ==============
FROM node:20-alpine AS builder

WORKDIR /build

# 先复制 lock 装依赖，利用缓存
COPY package.json pnpm-lock.yaml ./
RUN npm i -g pnpm@9 && pnpm i --frozen-lockfile

# 再复制源码构建
COPY . .
RUN pnpm build

# ============ Stage 2: 静态托管 ==============
FROM nginx:1.27-alpine

# 覆盖默认站点配置
COPY nginx.conf /etc/nginx/conf.d/default.conf

# 拷贝构建产物
COPY --from=builder /build/dist /usr/share/nginx/html

EXPOSE 80
CMD ["nginx","-g","daemon off;"]
```

**关键点**：

- Stage 1 用 `node:20-alpine`（Node 20 LTS + alpine，≈ 60MB），只做「装依赖 + 打包」；
- `pnpm i --frozen-lockfile`：严格按 lockfile 装，CI 一致性保证；
- Stage 2 用 `nginx:1.27-alpine`（≈ 45MB），只保留 dist + nginx.conf；
- `CMD ["nginx","-g","daemon off;"]`：让 Nginx 前台跑，容器 PID 1 直接是 nginx。

### 6.3 配套 `nginx.conf`

```nginx
server {
    listen 80;
    server_name _;

    root  /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://backend:8080/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    gzip on;
    gzip_types text/plain text/css application/json application/javascript;
}
```

**逐段解析**：

- `root /usr/share/nginx/html`：静态资源根目录，与 Dockerfile 里 `COPY --from=builder /build/dist /usr/share/nginx/html` 对齐；
- `try_files $uri $uri/ /index.html`：**SPA fallback**——先找真实文件、再找目录、都没有兜底给 `index.html`。Vue Router `history` 模式必备，不然刷新 `/courses` 直接 404；
- `proxy_pass http://backend:8080/`：`backend` 是**容器名**，需要和后端在同一个 Docker 网络（Day17 compose 时会自动配好）；
- `proxy_pass` 末尾**斜杠**决定 URL 是否重写：
  - 带斜杠：`/api/user/list` → `/user/list`（截掉 `/api/`）
  - 不带斜杠：`/api/user/list` → `/api/user/list`（原样转发）

🎯 **推荐**：**带斜杠**——前端习惯写 `/api/xxx`，后端 Controller 不需要重复加 `/api` 前缀。

### 6.4 `.dockerignore` 前端版

```text
.git
.gitignore
node_modules
dist
.env
.env.local
.env.production.local
.vscode
.DS_Store
Dockerfile
docker-compose.yml
```

- 挡 `node_modules`：本地那份可能是 Windows / Mac 版，进 Linux 容器直接坏；
- 挡 `dist`：让 Docker 内 pnpm build 从头来；
- 挡 `.env*`：敏感信息不进镜像。

### 6.5 构建 + 验证

```bash
docker build -t yoga-web:1.0.0 .

docker run -d --name yoga-web -p 80:80 yoga-web:1.0.0

# 浏览器 http://localhost/ → 首页出
# 刷新 http://localhost/courses → 仍出（SPA fallback 生效）
# 打 http://localhost/api/xxx → 502（后端还没起，Day17 compose 联通）
```

### 6.6 镜像层分析

```bash
docker history yoga-web:1.0.0
```

前端镜像典型层：

```
nginx:1.27-alpine 基础层  ≈ 45MB
+ COPY nginx.conf         ≈ 1KB
+ COPY --from=builder dist ≈ 8MB
─────────────────────────────
= 总大小                  ≈ 53MB
```

**优秀**——如果不用多阶段、把 Node 也打进去，就是 60 + 53 ≈ 113MB。

### 6.7 基础镜像三档对比

| 基础镜像 | Stage 1 镜像大小 | 特点 |
|----------|------------------|------|
| `node:20` | 1.1GB | 完整 Debian，兼容性最好，构建最慢 |
| `node:20-slim` | 240MB | Debian slim，多数场景够用 |
| `node:20-alpine` | 60MB | musl libc，构建最快，某些原生模块（sharp / node-canvas）可能装不上 |

**推荐**：普通 Vue 项目用 `alpine`；用了 sharp / canvas 等原生模块的项目换 `slim`；实在装不动用 `node:20`。

**注意**：Stage 2 是独立的，Stage 1 用哪个基础镜像不影响最终镜像大小——**只影响构建速度和依赖装配兼容性**。

### 6.8 镜像大小优化四板斧

1. **alpine 基础镜像**：`FROM eclipse-temurin:25-jre-alpine` 而非 `eclipse-temurin:25-jdk`；
2. **多阶段丢弃构建工具**：Maven / Node / gcc 全丢在 builder 阶段；
3. **`RUN` 合并 + 清缓存**：
   ```dockerfile
   RUN apt update && apt install -y curl \
       && rm -rf /var/lib/apt/lists/*
   ```
   ```dockerfile
   RUN npm i -g pnpm && pnpm i --frozen-lockfile \
       && npm cache clean --force
   ```
4. **`.dockerignore` 拒绝无关文件**：`.git` / `node_modules` / `target` / `.env`。

**目标**：**后端 < 250MB · 前端 < 60MB**。

### 6.9 生产标签 + 推送

```bash
docker tag yoga-web:1.0.0 registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
docker push registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
```

服务器上：

```bash
docker pull registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
docker run -d --name yoga-web -p 80:80 \
  registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
```

### 6.10 常见坑

- **忘了 `try_files`** → 首页能开、刷新 `/courses` 404；
- **`proxy_pass` 末尾斜杠错误** → 后端 URL 前缀和 Controller 对不上，全 404；
- **`backend` 名字解析不到** → 前端 / 后端容器不在同一个 Docker 网络（`docker network create yoga-net && docker run --network yoga-net ...`；Day17 用 compose 自动处理）；
- **alpine 装 sharp / node-canvas 失败** → 换 `node:20-slim` 或 `RUN apk add --no-cache python3 make g++ vips-dev`；
- **`pnpm-lock.yaml` 未提交** → CI 里 `pnpm i --frozen-lockfile` 报错 —— 一定要 commit lockfile；
- **前端环境变量硬编码到 dist** → Vite 的 `VITE_*` 变量在**构建时**注入，运行时无法改；生产往往用 `nginx.conf` 反代 + 相对路径 `/api/` 规避；
- **CORS 报错** → 前端反代 `/api/` 到后端就没跨域了；开发用 Vite `server.proxy` 做类似效果。

### 6.11 一次跑齐 4 个容器（预告 Day17）

Day16 结束时，你手上有四个可跑的东西：

```bash
# MySQL
docker run -d --name mysql -p 3306:3306 \
  -v yoga-mysql:/var/lib/mysql \
  -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=yoga \
  mysql:8

# Redis
docker run -d --name redis -p 6379:6379 \
  -v yoga-redis:/data \
  redis:8-alpine --appendonly yes --requirepass "yoga123"

# 后端
docker run -d --name yoga-backend -p 8080:8080 \
  yoga-backend:1.0.0

# 前端
docker run -d --name yoga-web -p 80:80 \
  yoga-web:1.0.0
```

四个容器都 `docker ps` 可见——但**它们互相看不见**。前端里 `proxy_pass http://backend:8080/` 找不到 `backend`；后端里 `DB_HOST=mysql` 找不到 `mysql`。要联通得手工建 network：

```bash
docker network create yoga-net
docker network connect yoga-net mysql
docker network connect yoga-net redis
docker network connect yoga-net yoga-backend
docker network connect yoga-net yoga-web
```

**Day17 用 `docker compose` 一句 `docker compose up -d` 自动完成上面所有的动作**。

### 6.12 本讲小结

- 前端两阶段：`node:20-alpine` 打 dist → `nginx:1.27-alpine` 托管；
- `nginx.conf` 三件事：静态托管 · SPA fallback · `/api/` 反代；
- 四板斧优化：alpine · 多阶段 · `RUN` 合并 · `.dockerignore`；
- 目标镜像：前端 < 60MB、后端 < 250MB；
- 下节课：`docker compose` 把这四个容器一键拉起并联通。

---

## Day16 全日复盘

### 关键命令速查

```bash
# 镜像
docker pull <image>
docker images
docker tag <src> <dst>
docker rmi <image>
docker save <image> -o file.tar
docker load -i file.tar
docker history <image>

# 容器
docker run -d --name <n> -p <h>:<c> -v <vol>:<path> -e KEY=val <image>
docker ps [-a]
docker logs [-f] [--tail N] <n>
docker exec -it <n> sh|bash
docker stop/start/restart <n>
docker rm [-f] <n>
docker cp <src> <n>:<dst>
docker stats
docker inspect <n>

# 数据卷
docker volume create <n>
docker volume ls
docker volume inspect <n>
docker volume rm <n>

# 网络
docker network create <n>
docker network connect <net> <container>
docker network ls

# 构建
docker build -t <name>:<tag> [-f Dockerfile] [--no-cache] [--build-arg K=V] [--platform linux/amd64] .

# 推送
docker login <registry>
docker push <registry>/<ns>/<name>:<tag>

# 清理
docker image prune -a
docker volume prune
docker system df
```

### Dockerfile 骨架模板

**后端（Spring Boot + JDK 25）**：

```dockerfile
FROM maven:3.9-eclipse-temurin-25 AS builder
WORKDIR /build
COPY pom.xml .
COPY .mvn .mvn
COPY mvnw .
RUN chmod +x mvnw && ./mvnw dependency:go-offline -B
COPY src ./src
RUN ./mvnw clean package -DskipTests -B

FROM eclipse-temurin:25-jre-alpine
ENV TZ=Asia/Shanghai JAVA_OPTS="-Xms256m -Xmx512m"
WORKDIR /app
COPY --from=builder /build/target/*.jar app.jar
EXPOSE 8080
HEALTHCHECK --interval=30s --timeout=3s --start-period=30s \
  CMD wget -qO- http://localhost:8080/actuator/health || exit 1
ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]
```

**前端（Vue + Vite + Nginx）**：

```dockerfile
FROM node:20-alpine AS builder
WORKDIR /build
COPY package.json pnpm-lock.yaml ./
RUN npm i -g pnpm@9 && pnpm i --frozen-lockfile
COPY . .
RUN pnpm build

FROM nginx:1.27-alpine
COPY nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=builder /build/dist /usr/share/nginx/html
EXPOSE 80
CMD ["nginx","-g","daemon off;"]
```

### 三条心法

1. **镜像 = 类，容器 = 对象**——同一镜像可起 N 个容器，删了不影响别的；
2. **数据活得比容器长**——用 Volume；命名卷放数据、bind mount 放配置 / 日志；
3. **多阶段 = 把用完就丢的工具留在前 stage**——builder 装 Maven / Node，runtime 只留 JRE / Nginx。

### 下一天预告

Day17：**Docker 容器网络互连 + `docker compose` 一键部署**——用一份 `docker-compose.yml` 把 MySQL + Redis + `yoga-backend` + `yoga-web` 四个容器同时拉起、自动联网、按依赖启动。今天四条 `docker run` 就是明天四段 compose 服务定义。
