# 《AI 应用 Web 开发》 - 学生讲义（Day05：项目启动 + Git + Maven 分模块）

**总讲次：6 讲**
**适用对象：具备 Java 基础语法能力的大二/大三本科生（已完成 Day01~Day04，能熟练使用 IDEA 2024.3+、JDK 25、Maven 3.9+、Spring Boot 4.0.x、MyBatis 基础）**

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 是整个后端项目的**正式开跑日**：把前 4 天学到的 Java + Maven + Spring Boot + MyBatis 全部集成到一个真实工程里，用 Git 做版本管理，用 Maven 分模块做分层解耦，用 Knife4j 做接口文档。Maven 坐标统一为 `com.yinxiang:yoga-member`，Gitee 仓库示例地址 `git@gitee.com:xxx/yoga-member.git`。

## 本日概览

| 讲次 | 主题 | 核心产出 |
|---|---|---|
| 第 1 讲 | 项目需求分析 + 技术选型 + 仓库规划 | Gitee `yoga-member` 私有仓库创建成功 |
| 第 2 讲 | Git 本地仓库 + 基本工作流 | 本地 `git init` + 首次 commit 完成 |
| 第 3 讲 | 远程仓库 + SSH + push/pull + .gitignore | SSH 免密登录 + 首次 push 成功 |
| 第 4 讲 | 分支开发 + 冲突解决 + 团队协作流 | 完成一次冲突解决实战 |
| 第 5 讲 | Maven 分模块 + 父 POM + 子模块 | 5 模块拆分 + `mvn clean install` 成功 |
| 第 6 讲 | 项目基础（库/Result/Knife4j/规范） | Knife4j `/doc.html` 打开成功 |

---

## 第 1 讲：项目需求分析 + 技术选型 + 仓库规划

### 1.1 引入：从今天起写一个"真项目"

过去 4 天你写的是**练习项目**——单文件、单模块、跑通就删。今天开始，我们要写一个**真项目**：《印想瑜伽会馆客户管理系统》。它的意义在于：

- 有明确的业务边界；
- 有版本历史，可回滚；
- 有分模块结构，可长期演化；
- 有代码规范，可交接给同事；
- 有接口文档，可交给前端。

**这才是你以后工作里 90% 时间要写的代码**。

### 1.2 主线项目业务定位

印想瑜伽会馆是一家假想的连锁瑜伽馆，业务系统需要覆盖四大核心域：

| 业务域 | 英文 | 核心数据 |
|---|---|---|
| 会员管理 | Member | 手机号、会员卡、剩余次数、到期日 |
| 课程管理 | Course | 课程分类、时间、教练、容量 |
| 预约管理 | Reservation | 会员预约、签到、取消 |
| 教练管理 | Coach | 基本信息、授课资质、排班 |

🎯 **本课程 Day05~Day10 聚焦"会员 + 课程分类 + 教练"三条主线**，其余作为拓展。

### 1.3 技术栈版本基线（必背）

| 层次 | 技术 | 版本 | 用途 |
|---|---|---|---|
| 语言 | Java | 25 | 主体开发语言 |
| 构建 | Maven | 3.9+ | 依赖管理 + 分模块 |
| 框架 | Spring Boot | 4.0.x | Web + IOC + 自动装配 |
| 持久层 | MyBatis | 3.0.x | ORM |
| 数据库 | MySQL | 8.0 | 数据存储 |
| 版本控制 | Git | 2.45+ | 代码版本 |
| IDE | IDEA | 2024.3+ | 开发环境 |
| AI 辅助 | 通义灵码 + Trae | 最新 | 编码助手 |
| 接口文档 | Knife4j | 4.5+ | Swagger 增强 |

💡 **口诀**：**Java 25、Boot 4.0、Maven 3.9、Git 2.45、MySQL 8**——五个数字背熟，面试可直接说\"我的项目版本基线是……\"。

### 1.4 代码仓库规划

| 项 | 值 | 说明 |
|---|---|---|
| 仓库名 | `yoga-member` | 小写 + 连字符，不用 `YogaMember` |
| 平台 | Gitee | 国内速度快 |
| 可见性 | Private | 学习期防止抄袭 |
| SSH 地址 | `git@gitee.com:xxx/yoga-member.git` | `xxx` 替换为你的 Gitee 用户名 |
| Maven 坐标 | `com.yinxiang:yoga-member:1.0-SNAPSHOT` | 全局唯一 |

### 1.5 创建 Gitee 空仓库

`gitee.com → 右上角 + → 新建仓库`：

- 仓库名：`yoga-member`
- 仓库介绍：\"印想瑜伽会馆客户管理系统 · AI 应用 Web 开发课程主线项目\"
- 是否开源：**私有**
- 分支模型：默认
- ⚠️ **不勾选任何初始化选项**（不要 README、不要 .gitignore、不要开源许可证）——保持仓库完全空，本地推送时更少冲突。

创建完毕在仓库主页切到 SSH 页签，复制形如 `git@gitee.com:xxx/yoga-member.git` 的地址备用。

### 1.6 让 AI 生成 README 初稿

打开通义灵码（IDEA 侧栏），发送：

```text
请为一个名为 yoga-member 的 Spring Boot 4.0 + MyBatis + MySQL 8.0 项目
生成一份中文 README.md 骨架，包含：
1. 项目简介
2. 技术栈（版本基线）
3. 目录结构
4. 启动方式
5. 贡献指南
```

把 AI 输出保存为本地 `D:/workspace/yoga-member/README.md`。**AI 是同事，不是替身**——生成后自己通读一遍，检查是否有幻觉。

### 1.7 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 手机号收不到 Gitee 验证短信 | 换邮箱验证；国际号段需 +86 前缀 |
| 仓库归属误选到组织 | 归属下拉必须选\"个人\" |
| 首次 push 报 \"rejected non-fast-forward\" | 建仓时勾了 Readme 初始化，本地和远程有分歧；重开一个空仓 |
| 用大写命名 `YogaMember` | 部分系统区分大小写，URL 里易踩坑；坚持小写 |
| 用中文用户名注册 Gitee | 后续 SSH 有可能因 HOME 路径含中文异常，可创建新账号或改环境变量 |

### 1.8 练习 / 思考

1. 完成 Gitee `yoga-member` 私有仓库的创建，截图保存。
2. 让通义灵码生成 README 初稿，本地保存到 `D:/workspace/yoga-member/README.md`（先手动建目录）。
3. **思考**：为什么本课程要求仓库 Private？如果你想给面试官看代码，什么时候可以转 Public？

---

## 第 2 讲：Git 本地仓库 + 基本工作流

### 2.1 引入：文件命名地狱

想象一下你的桌面：

```
毕业设计.zip
毕业设计_修改版.zip
毕业设计_final.zip
毕业设计_final_真_final.zip
毕业设计_老师要的版本.zip
```

这是每一个没学过 Git 的大学生的宿命。**Git 就是让你不再靠文件名区分版本**——每次 commit 就是一个可回溯的历史节点。

### 2.2 三种版本控制形态

```
本地拷贝（stone age）
   → copy 项目 项目_v1
   → 无协作、无回溯、易丢失

集中式（SVN）
   → 只有中央服务器有完整历史
   → 客户端只有当前工作副本
   → 断网不能提交

分布式（Git）✅
   → 每人本地都有完整仓库
   → 本地可 commit、diff、branch
   → 网络恢复后一次 push 同步
```

🎯 **口诀**：**分布式 + 快照 + 分支廉价** —— Git 的三张王牌。

### 2.3 Git 三区模型（考点）

```
工作区（Working Dir）
   ↓  git add
暂存区（Index / Staging）
   ↓  git commit
本地仓库（HEAD / .git/）
   ↓  git push
远程仓库（origin）
```

| 区 | 位置 | 内容 |
|---|---|---|
| 工作区 | IDE 里打开的文件 | 你正在改的内容 |
| 暂存区 | `.git/index` | `git add` 之后候选提交的快照 |
| 本地仓库 | `.git/` 目录 | 所有历史 commit |
| 远程仓库 | Gitee / GitHub | 云端备份 + 协作中心 |

💡 **暂存区的价值**：让你在 10 个改动里挑 6 个作为一次"逻辑完整"的提交，而不是一股脑全交。

### 2.4 全局配置三件套

首次装 Git 后，Git Bash 里执行一次：

```bash
git --version                                       # 版本 ≥ 2.45
git config --global user.name  "Zhang San"
git config --global user.email "zs@example.com"
git config --global init.defaultBranch main
git config --list | grep user                       # 验证
```

⚠️ **特别注意**：**先配置再 `git init`**，否则默认分支叫 `master`，后期 push 到 `main` 会不一致。

### 2.5 8 条本地基础命令

```bash
git init                                   # 初始化仓库

git status                                 # 看当前状态
git add .                                  # 全部暂存
git add src/main/java/                     # 部分暂存
git commit -m "feat: 首次提交 README"
git log --oneline --graph                  # 看历史

git diff                                   # 看工作区改动
git diff --staged                          # 看暂存区改动

git restore <file>                         # 撤销工作区改动
git restore --staged <file>                # 撤销暂存
git reset --hard HEAD^                     # 回退到上一次提交（慎用）
```

🎯 **口诀**：**status 先看清，add 挑一挑，commit 写清楚，log 看得懂**。

### 2.6 首次 commit 完整流程

在你 Day05 建好的 `yoga-member/` 目录（含 AI 生成的 README.md）：

```bash
cd D:/workspace/yoga-member
git init
ls -a                              # 看到 .git 目录

git status                         # README.md 显示 untracked
git add README.md
git status                         # README.md 变绿 staged
git commit -m "chore: 项目初始化 README"

git log --oneline
```

再改一次 README（比如加一行技术栈说明）：

```bash
git status                         # modified
git diff                           # 看具体差异
git add README.md
git diff --staged                  # 看暂存差异
git commit -m "docs: 完善技术栈说明"

git log --oneline --graph
```

### 2.7 Conventional Commits 规范

```
<type>(<scope>): <subject>
```

| type | 用途 |
|---|---|
| `feat` | 新功能 |
| `fix` | 修 Bug |
| `docs` | 文档 |
| `style` | 格式（不影响功能） |
| `refactor` | 重构 |
| `test` | 测试 |
| `chore` | 构建/杂项 |

示例：

- `feat(member): 新增会员分页查询接口`
- `fix(login): 修复空密码 NPE`
- `docs(readme): 完善部署说明`
- `chore: 项目初始化`

💡 **规范提交的价值**：三个月后翻 `git log` 时能秒懂每次改动干了什么。

### 2.8 撤销三兄弟

| 场景 | 命令 | 效果 |
|---|---|---|
| 改了工作区文件，还没 add | `git restore <file>` | 回到 HEAD 状态 |
| 已经 add 了但还没 commit | `git restore --staged <file>` | 从暂存区撤出，工作区不变 |
| 已经 commit 了想删掉 | `git reset --hard HEAD^` | 回退到上一次，⚠️ 慎用 |
| 已 push 到远程想撤 | `git revert <commit>` | 生成一个反向 commit，团队协作首选 |

### 2.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 默认分支叫 `master` 不是 `main` | 没配 `init.defaultBranch=main`；先配置再 init |
| `git commit` 弹出 vim 卡死 | 忘写 `-m "..."`；`Esc` + `:q!` 强退，再重来带 -m |
| `git status` 显示中文文件名乱码 | `git config --global core.quotepath false` |
| 想撤销但 commit 已 push | 不能 reset，改用 `git revert <commit>` |
| Windows 用户名含中文导致 gitconfig 异常 | 用 Git Bash 而非 PowerShell；或改 HOME 环境变量 |
| `.git/` 被误删 | 所有历史丢失，只能从远程 clone 恢复；**永远不要手动动 .git**  |

### 2.10 练习 / 思考

1. 完成 `git config --global` 三项配置，`git config --list | grep user` 截图保存。
2. 在 `yoga-member/` 完成首次 `git init` + commit README.md。
3. 再改一次 README，做 `restore` 撤销练习，观察 `git status` 输出。
4. **思考**：`git reset --hard` 之后 30 天内还能救回代码吗？（提示：查 `git reflog`）

---

## 第 3 讲：远程仓库 + SSH 密钥 + push/pull/clone + .gitignore

### 3.1 引入：本地备份 ≠ 真备份

上一讲代码 commit 到了本地——**只在你自己硬盘上**，硬盘坏了照样丢。今天要把代码推到 Gitee 云端，实现真正的备份 + 支持团队协作。

### 3.2 为什么用 SSH 而不是 HTTPS

| 特性 | HTTPS | SSH ✅ |
|---|---|---|
| 首次配置 | 无需 | 生成密钥 + 上传公钥 |
| 后续操作 | 每次要账号/密码 | 完全免密 |
| 安全性 | Token 有过期 | 私钥永久有效 |
| 推荐场景 | 一次性 clone | 长期开发（本课程） |

**结论**：一次配置终身免密 —— 我们全程走 SSH。

### 3.3 SSH 密钥原理

```
本机                             Gitee 服务器
┌──────┐   签名验证              ┌──────────┐
│ 私钥 │  ────────────────►      │ 公钥（你上传的）  │
│ id_  │                         │ 用公钥验证签名    │
│ ed25519 │                      │ 通过 → 放行       │
└──────┘                         └──────────┘
```

- **私钥** `~/.ssh/id_ed25519`：**永不外传**，保存在本机；
- **公钥** `~/.ssh/id_ed25519.pub`：可以传到任何服务器；
- 服务器用公钥验证签名——签名对得上 = 你就是你，无需密码。

⚠️ **特别注意**：私钥泄漏 = 攻击者可以以你的身份 push 代码。别把 `id_ed25519` 传到聊天群或云盘！

### 3.4 生成 SSH 密钥

```bash
ssh-keygen -t ed25519 -C "zs@example.com"
# 回车（默认路径 ~/.ssh/id_ed25519）
# 回车（Enter passphrase：留空）
# 回车（确认）
cat ~/.ssh/id_ed25519.pub
```

💡 **-t ed25519** 是现代推荐算法，比老的 RSA 更短更安全；**-C** 是注释（一般写邮箱）。

### 3.5 把公钥添加到 Gitee

复制 `cat` 出来的整行 `ssh-ed25519 AAAA...zs@example.com`，然后：

```
Gitee → 右上角头像 → 设置 → 安全设置 → SSH 公钥 → 添加公钥
标题：yoga-dev-pc
公钥：<粘贴>
```

**验证连接**：

```bash
ssh -T git@gitee.com
```

看到 `Hi 用户名! You've successfully authenticated...` 即成功。

### 3.6 5 条远程命令

```bash
git remote add origin git@gitee.com:xxx/yoga-member.git
git remote -v                        # 查看当前远程

git push -u origin main              # 首次推送：-u 建立跟踪关系
git push                             # 之后简化为一句 push

git pull                             # 拉取并合并
git fetch                            # 只拉取不合并（更安全）

git clone git@gitee.com:xxx/yoga-member.git
```

🎯 **口诀**：**先 pull 再 push，别做单向暴力**——协作时永远先 pull 检查冲突，再 push 上去。

### 3.7 首次推送完整流程

在 `yoga-member/` 目录：

```bash
cd D:/workspace/yoga-member
git remote -v                                        # 空
git remote add origin git@gitee.com:xxx/yoga-member.git
git remote -v                                        # 看到 origin

git branch                                           # 看到 main
git push -u origin main
```

刷新 Gitee 仓库网页，能看到 README.md 出现即成功。

### 3.8 `.gitignore` 规则

在项目根目录新建 `.gitignore`：

```gitignore
# Maven
target/
*.class

# IDEA
.idea/
*.iml

# VS Code
.vscode/

# Logs
*.log
logs/

# OS
.DS_Store
Thumbs.db

# Secrets & local
application-local.yml
application-secret.yml
.env
```

添加后：

```bash
git add .gitignore
git commit -m "chore: 添加 .gitignore"
git push
```

⚠️ **特别注意**：`.gitignore` **只对未追踪的文件生效**。如果你已经把 `target/` commit 过了，再加 `.gitignore` 是没用的——必须先从索引移除：

```bash
git rm --cached -r target/         # 从索引移除，磁盘保留
git commit -m "chore: 移除已入库的 target 目录"
```

### 3.9 clone 验证

在另一个目录测试克隆：

```bash
cd D:/tmp
git clone git@gitee.com:xxx/yoga-member.git yoga-clone
cd yoga-clone && ls
```

看到 README.md、`.gitignore` 已经在——**clone 自动完成 remote 关联 + 分支跟踪**，不需要再 `remote add`。

### 3.10 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| `ssh -T` 报 `Permission denied` | 公钥没加到 Gitee 或加错了；`cat` 命令重复一次仔细复制 |
| `push` 报 `rejected non-fast-forward` | 远程有你本地没有的 commit（多半是建仓时勾了 Readme）；`git pull --rebase` 或重建仓 |
| Windows 找不到 `~/.ssh/` 目录 | 在 `C:\Users\<用户名>\.ssh\`；用 Git Bash 里 `cd ~/.ssh` 更简单 |
| `ssh-keygen` 卡在 passphrase | 三次回车全部留空即可 |
| 公司/学校封 22 端口 | 改用 `ssh.gitee.com:443` 或临时换 HTTPS |
| 已 commit target/ 后再加 gitignore 无效 | `git rm --cached -r target/` 再 commit |

### 3.11 练习 / 思考

1. 完成 SSH 密钥生成 + 上传 Gitee + `ssh -T` 验证成功。
2. 完成首次 `git push -u origin main`，Gitee 网页刷新验证。
3. 补齐 `.gitignore` 并再推一次。
4. **思考**：如果你同时要给 GitHub 和 Gitee 推代码，可以用同一把 SSH 私钥吗？（提示：可以，但公钥要分别上传两边）

---

## 第 4 讲：分支开发 + 冲突解决 + 团队协作流

### 4.1 引入：直接改 main 分支的血泪

某创业公司 4 个后端全在 main 上直接改代码，某周五张三改登录、李四改支付，同时 push——第二天上线全线崩溃，因为他们相互覆盖了对方的改动。

**分支 = 平行宇宙 = 每个功能独立开发不打架**。

### 4.2 分支的本质

```
c1 ── c2 ── c3 ── c4 ── c5
                        ↑
                     main / HEAD
```

**分支就是一个指针，指向某个 commit**：

- 新建分支 = 复制一份指针（**不复制文件**）；
- 切换分支 = 移动 HEAD 到不同指针；
- 删除分支 = 只删指针，commit 不丢。

🎯 **这就是 Git 分支为什么便宜的原因**：不搬文件，只搬指针。

### 4.3 4 条分支命令

```bash
git branch                              # 看当前所有分支
git branch feat/member                  # 新建，不切换
git switch feat/member                  # 切换（现代写法，替代旧 checkout）
git switch -c feat/member               # 新建 + 切换（推荐）

git merge feat/member                   # 把 feat/member 合并到当前分支
git branch -d feat/member               # 已合并的分支删除
git branch -D feat/member               # 强制删除未合并的
```

### 4.4 两种合并类型

**快进合并（fast-forward）** —— 主干没动：

```
main         feat
 ↓            ↓
c1 ── c2 ── c3
           ↓ merge
c1 ── c2 ── c3
             ↑
          main / feat
```

**三方合并（3-way merge）** —— 主干也动了，产生 merge commit：

```
main            merge commit
 ↓              ↓
c1 ── c2 ── c4 ─── c5
      └── c3 ──────┘
             ↑
           feat
```

💡 团队协作里几乎全是三方合并，快进合并只在你自己一个人的临时练习里出现。

### 4.5 主干开发四类分支

```
main（稳定发布）
  ↑ PR
dev（日常集成）
  ↑ merge
feat/xxx（功能分支）
fix/xxx（Bug 修复分支）
```

| 分支 | 作用 | 谁能 push |
|---|---|---|
| `main` | 稳定发布 | 只接受 PR / MR |
| `dev` | 日常集成 | 后端团队合并 feat |
| `feat/xxx` | 功能开发 | 个人 |
| `fix/xxx` | Bug 修复 | 个人 |

🎯 **命名规范**：`feat/member`、`feat/course-list`、`fix/login-npe` —— 全小写 + 短横线。

### 4.6 正常合并演示（快进）

```bash
git switch -c feat/hello
echo "hello from feat" >> README.md
git add README.md
git commit -m "feat: 演示分支合并"

git switch main
git merge feat/hello                # 快进合并
git log --oneline --graph
git branch -d feat/hello            # 用完删掉
```

### 4.7 冲突场景与解决

**场景**：main 和 feat 都改了同一个文件的同一行。

```bash
# Step 1 —— main 改标题
git switch main
# 编辑 README.md 第 1 行：# 印想瑜伽会馆客户管理系统 v1
git add README.md && git commit -m "docs: main 改标题 v1"

# Step 2 —— feat 也改标题
git switch -c feat/title
# 编辑 README.md 第 1 行：# 印想瑜伽 · 会馆管理平台
git add README.md && git commit -m "docs: feat 改标题为会馆管理平台"

# Step 3 —— main 再改一次
git switch main
# 编辑 README.md 第 1 行：# 印想瑜伽会馆客户管理系统 v2
git add README.md && git commit -m "docs: main 改标题 v2"

# Step 4 —— 合并 feat → main
git merge feat/title
# CONFLICT (content): Merge conflict in README.md
```

打开 `README.md` 会看到冲突标记：

```
<<<<<<< HEAD
# 印想瑜伽会馆客户管理系统 v2
=======
# 印想瑜伽 · 会馆管理平台
>>>>>>> feat/title
```

| 标记 | 含义 |
|---|---|
| `<<<<<<< HEAD` ~ `=======` | 当前分支（main）的内容 |
| `=======` ~ `>>>>>>> feat/title` | 合并进来的分支内容 |

**解决三步**：

1. 手动编辑文件，删除三个标记行，保留你想要的最终内容；
2. `git add README.md`；
3. `git commit`（Git 已备好合并 commit message，直接保存即可）。

⚠️ **特别注意**：`<<<<<<< / ======= / >>>>>>>` 这三行必须**完全删除**，不能作为代码留在文件里——否则程序编译或运行会崩。

### 4.8 IDEA 图形化冲突解决

`右键冲突文件 → Git → Resolve Conflicts`：

```
┌────────┬────────┬────────┐
│ Their  │ Result │ Yours  │  ← 三栏并排
│（合入）│（最终） │（当前）│
├────────┴────────┴────────┤
│ 点箭头逐段合并            │
└──────────────────────────┘
```

比命令行更直观，**新手强烈推荐**。

### 4.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 未 commit 就 switch 分支被拒 | 先 `git stash` 暂存或 commit 一个 wip 提交 |
| 合并后 `<<<<<<<` 标记忘删 | 编译报错；grep `<<<<<<<` 全库扫一遍 |
| 分支越删越多，`git branch` 一屏 | 合并即删；`git branch --merged` 查已合并的一次清 |
| IDEA 冲突面板 Their/Yours 反了 | 版本差异；看清标签，别机械选\"左\" |
| 想撤销合并 | `git merge --abort` 立即回到合并前状态 |
| 分支名带大写 / 空格 | 部分 shell 处理异常；坚持全小写 + 短横线 |

### 4.10 练习 / 思考

1. 完成一次快进合并（feat 加一行 → 合回 main → 删除 feat）。
2. 故意制造并解决一次冲突，`git log --oneline --graph` 截图。
3. 用 IDEA 图形化工具重做一次冲突解决，对比命令行差异。
4. **思考**：`git rebase` 和 `git merge` 有什么区别？为什么公司里\"合并到主干用 merge、本地整理用 rebase\"？

---

## 第 5 讲：Maven 分模块开发 + 父 POM + 子模块拆分

### 5.1 引入：单模块的痛点

Day03 我们做了单模块 `yoga-member`，一段时间后你会遇到：

- 代码量过大，一改就要编译全部；
- Controller / Service / Mapper / Entity 全塞一个包，找类只能全文搜索；
- Result / PageResult 想在别的项目复用？**只能复制粘贴**；
- 想分 dev/prod 不同环境部署？打包全塞一个 jar，太重。

**分模块 = 关注点分离 + 代码复用 + 独立部署**。

### 5.2 两种主流拆分风格

| 风格 | 目录 | 适用场景 |
|---|---|---|
| **按层拆** ✅ 本课程采用 | common / pojo / mapper / service / web | 学习期首选，直观 |
| 按业务拆 | common / member / course / web | 大型系统，微服务前身 |

🎯 按层拆完整目录：

```
yoga-member/                     ← 父工程
├── yoga-common                  ← 通用工具、常量、Result
├── yoga-pojo                    ← 实体、DTO、VO
├── yoga-mapper                  ← 持久层
├── yoga-service                 ← 业务层
└── yoga-web                     ← 启动器 + Controller
```

### 5.3 父 POM 三大要素

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.yinxiang</groupId>
    <artifactId>yoga-member</artifactId>
    <version>1.0.0</version>
    <packaging>pom</packaging>            <!-- ① 父工程必须 pom -->

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>4.0.0</version>
    </parent>

    <modules>                             <!-- ② 聚合子模块 -->
        <module>yoga-common</module>
        <module>yoga-pojo</module>
        <module>yoga-mapper</module>
        <module>yoga-service</module>
        <module>yoga-web</module>
    </modules>

    <properties>
        <java.version>25</java.version>
        <mybatis.version>3.0.5</mybatis.version>
        <hutool.version>5.8.32</hutool.version>
    </properties>

    <dependencyManagement>                <!-- ③ 只声明版本 -->
        <dependencies>
            <dependency>
                <groupId>org.mybatis.spring.boot</groupId>
                <artifactId>mybatis-spring-boot-starter</artifactId>
                <version>${mybatis.version}</version>
            </dependency>
            <dependency>
                <groupId>cn.hutool</groupId>
                <artifactId>hutool-all</artifactId>
                <version>${hutool.version}</version>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <!-- 所有子模块共用（真正传递） -->
    <dependencies>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
    </dependencies>
</project>
```

🎯 **三大要素记忆口诀**：**packaging=pom、modules 列子、dependencyManagement 管版本**。

💡 **`<dependencyManagement>` vs `<dependencies>`**：

| 标签 | 作用 | 子模块是否自动引入 |
|---|---|---|
| `<dependencyManagement>` | **只声明版本**，做"版本备案" | ❌ 不引入；子模块要用要自己写，但可省 version |
| `<dependencies>` | **真正引入依赖** | ✅ 自动传递到所有子模块 |

### 5.4 子模块 POM

```xml
<project>
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>com.yinxiang</groupId>
        <artifactId>yoga-member</artifactId>
        <version>1.0.0</version>
    </parent>

    <artifactId>yoga-common</artifactId>

    <dependencies>
        <dependency>
            <groupId>cn.hutool</groupId>
            <artifactId>hutool-all</artifactId>
            <!-- version 省略，走父的 dependencyManagement -->
        </dependency>
    </dependencies>
</project>
```

🎯 **子模块的 groupId 和 version 都从父继承，可以省略**。

### 5.5 模块间依赖关系

```
yoga-web ──► yoga-service ──► yoga-mapper ──► yoga-pojo ──► yoga-common
   │                                                          ▲
   └──────────────────────────────────────────────────────────┘
```

**规则**：**上层能依赖下层，下层绝不能依赖上层**（否则循环依赖，Maven 会拒绝）。

`yoga-service/pom.xml` 依赖示例：

```xml
<dependencies>
    <dependency>
        <groupId>com.yinxiang</groupId>
        <artifactId>yoga-mapper</artifactId>
        <version>1.0.0</version>
    </dependency>
    <dependency>
        <groupId>com.yinxiang</groupId>
        <artifactId>yoga-pojo</artifactId>
        <version>1.0.0</version>
    </dependency>
</dependencies>
```

### 5.6 yoga-web 特殊配置

只有 `yoga-web` 是**可执行模块**，需要 Spring Boot 打包插件：

```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>com.yinxiang</groupId>
        <artifactId>yoga-service</artifactId>
        <version>1.0.0</version>
    </dependency>
</dependencies>

<build>
    <plugins>
        <plugin>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-maven-plugin</artifactId>
        </plugin>
    </plugins>
</build>
```

### 5.7 启动类的关键调整

`yoga-web/src/main/java/com/yinxiang/YogaMemberApplication.java`：

```java
package com.yinxiang;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.yinxiang")
@MapperScan("com.yinxiang.mapper")
public class YogaMemberApplication {
    public static void main(String[] args) {
        SpringApplication.run(YogaMemberApplication.class, args);
    }
}
```

⚠️ **特别注意**：分模块后代码分散在多个 jar 里，`@SpringBootApplication` 默认扫\"启动类所在包及其子包\"——因为各模块都以 `com.yinxiang` 为根，**必须显式写 `scanBasePackages = "com.yinxiang"`** 才能扫全；Mapper 也要 `@MapperScan`。

### 5.8 Maven 命令

```bash
# 在父工程根目录执行，一次性构建所有子模块
mvn clean install

# 只构建 web 模块及其依赖模块（-am 表示 also make）
mvn -pl yoga-web -am clean install

# 跳过测试
mvn clean install -DskipTests

# 运行 web 模块
mvn -pl yoga-web spring-boot:run
```

### 5.9 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| 父工程 `<packaging>` 忘写 pom | 默认 jar，构建报\"jar 不能包含 modules\"；改为 pom |
| 子模块 `<parent>` 写错版本 | Maven 找不到父；确认 groupId + artifactId + version 三者一致 |
| `mvn clean install` 报循环依赖 | 下层错误地依赖了上层；重画依赖图查一遍 |
| Bean 注入报 `Could not find bean` | `scanBasePackages` 没写或写错；改为 `"com.yinxiang"` |
| Mapper 无法注入 | `@MapperScan` 忘写或包名写错 |
| `mvn package` 生成不可执行 jar | `yoga-web` 没加 `spring-boot-maven-plugin` |
| IDEA 重构后爆红一大片 | 索引未完成；等右下角进度条走完再判断 |

### 5.10 练习 / 思考

1. 在 IDEA 完成 5 模块拆分，父 POM 使用 `<packaging>pom</packaging>`。
2. `mvn clean install` 通过 5 次 BUILD SUCCESS 截图保存。
3. 在 `yoga-web` 里加一个 `HelloController` 返回 \"Hello, 印想瑜伽!\"，浏览器验证。
4. **思考**：如果你要新加一个 `yoga-quartz` 定时任务模块，它应该放在依赖链的哪一层？（提示：多半和 `service` 平级或者依赖 `service`）

---

## 第 6 讲：项目基础环境（建库 + Result + Knife4j + 开发规范）

### 6.1 引入：接口调试的痛

你写了一个 `/api/course/list` 接口，前端同学 QQ 上问：

- 路径是啥？
- 参数怎么传？
- 返回什么结构？
- 需要 token 吗？

你手动打字回答。三天后又问同一个问题。**Knife4j 让接口自己描述自己**——前端一看即懂，你也不用重复解释。

### 6.2 建库建表

用 IDEA Database 面板或 MySQL Workbench 执行：

```sql
CREATE DATABASE yoga_member
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE yoga_member;

CREATE TABLE t_category (
  id           BIGINT       PRIMARY KEY AUTO_INCREMENT,
  name         VARCHAR(64)  NOT NULL COMMENT '课程分类名',
  code         VARCHAR(32)  NOT NULL COMMENT '编码',
  sort         INT          DEFAULT 0,
  create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='课程分类';

INSERT INTO t_category(name, code, sort) VALUES
('哈他瑜伽', 'HATHA', 1),
('阴瑜伽',   'YIN',   2),
('流瑜伽',   'FLOW',  3);
```

🎯 **命名规范**：表名以 `t_` 前缀 + 小写下划线，字段名用小写下划线 + `create_time` / `update_time` 双时间戳。

### 6.3 `application-dev.yml` 完整配置

`yoga-web/src/main/resources/application.yml`：

```yaml
server:
  port: 8080

spring:
  application:
    name: yoga-member
  profiles:
    active: dev
```

`yoga-web/src/main/resources/application-dev.yml`：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/yoga_member?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai
    username: root
    password: 123456
    driver-class-name: com.mysql.cj.jdbc.Driver

mybatis:
  mapper-locations: classpath*:mapper/*.xml
  configuration:
    map-underscore-to-camel-case: true

logging:
  level:
    com.yinxiang: debug
```

⚠️ **特别注意**：MySQL 8.0 JDBC URL 里**必须加 `serverTimezone=Asia/Shanghai`**，否则会报 `The server time zone value ... is unrecognized`。

### 6.4 `Result<T>` 通用返回

`yoga-common/src/main/java/com/yinxiang/common/Result.java`：

```java
package com.yinxiang.common;

import lombok.Data;
import java.io.Serializable;

@Data
public class Result<T> implements Serializable {
    private Integer code;   // 1 成功 0 失败
    private String  msg;
    private T       data;

    public static <T> Result<T> success()              { return build(1, "success", null); }
    public static <T> Result<T> success(T data)        { return build(1, "success", data); }
    public static <T> Result<T> error(String msg)      { return build(0, msg, null); }

    private static <T> Result<T> build(int code, String msg, T data) {
        Result<T> r = new Result<>();
        r.code = code;
        r.msg  = msg;
        r.data = data;
        return r;
    }
}
```

`yoga-common/src/main/java/com/yinxiang/common/PageResult.java`：

```java
package com.yinxiang.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class PageResult<T> {
    private long total;
    private List<T> rows;
}
```

改造 `HelloController`：

```java
@GetMapping("/hello")
public Result<String> hello() {
    return Result.success("Hello, 印想瑜伽!");
}
```

浏览器访问看到：

```json
{"code":1,"msg":"success","data":"Hello, 印想瑜伽!"}
```

🎯 **所有 Controller 都必须返回 `Result<T>`**——统一响应结构是前后端约定的基本礼仪。

### 6.5 Knife4j 集成三步

**Step 1** —— `yoga-web/pom.xml` 加依赖：

```xml
<dependency>
    <groupId>com.github.xiaoymin</groupId>
    <artifactId>knife4j-openapi3-jakarta-spring-boot-starter</artifactId>
    <version>4.5.0</version>
</dependency>
```

**Step 2** —— `application.yml` 追加：

```yaml
springdoc:
  swagger-ui:
    enabled: true
  api-docs:
    enabled: true

knife4j:
  enable: true
  setting:
    language: zh_cn
```

**Step 3** —— Controller 加 OpenAPI 3 注解：

```java
package com.yinxiang.controller;

import com.yinxiang.common.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "课程分类", description = "课程分类管理接口")
@RestController
@RequestMapping("/api/category")
public class CategoryController {

    @Operation(summary = "分类列表")
    @GetMapping("/list")
    public Result<String> list() {
        return Result.success("分类列表 - 空实现");
    }
}
```

启动 `yoga-web`，浏览器打开：

```
http://localhost:8080/doc.html
```

看到 Knife4j 首页 + 左侧分组 \"课程分类\" + 右侧接口详情即成功。

💡 **OpenAPI 3 注解对照**（相对旧 Swagger 2）：

| 旧 Swagger 2 | 新 OpenAPI 3 |
|---|---|
| `@Api(tags="")` | `@Tag(name="")` |
| `@ApiOperation("")` | `@Operation(summary="")` |
| `@ApiParam("")` | `@Parameter(description="")` |
| `@ApiModel` | `@Schema` |

### 6.6 开发规范速览（必背）

| 项 | 规范 |
|---|---|
| 包命名 | `com.yinxiang.<模块>.<层>`，全小写，反向域名开头 |
| 类命名 | Pascal：`XxxController` / `XxxService` / `XxxServiceImpl` / `XxxMapper` / `XxxEntity` / `XxxDTO` / `XxxVO` |
| 常量命名 | `static final` + 全大写 + 下划线：`DEFAULT_PASSWORD` |
| SQL 表名 | `t_` 前缀 + 小写下划线：`t_category`、`t_member` |
| SQL 字段 | 小写下划线：`create_time`、`update_time` |
| Git 分支 | 全小写 + 短横线：`feat/member-list`、`fix/login-npe` |
| Git commit | Conventional Commits：`feat / fix / docs / style / refactor / test / chore` |
| REST 路径 | 复数名词：`/api/categories`、`/api/members`（本课程为简化统一 `/api/category`） |
| 接口注解 | 每个 Controller `@Tag`、每个方法 `@Operation` |

🎯 **口诀**：**包路径反着写、类名 Pascal、常量大写、表 t_ 前缀、字段下划线**。

### 6.7 一次完整 commit 到 Gitee

```bash
git switch -c feat/base-env
# 完成本讲所有改动
git add .
git status
git commit -m "feat: 集成 Knife4j 与统一 Result 返回"
git switch main
git merge feat/base-env
git push
git branch -d feat/base-env
```

### 6.8 pitfall / 注意

| 现象 | 原因 / 建议 |
|---|---|
| Knife4j 4.3 及以下报 `javax.servlet` 找不到 | Spring Boot 4 用 jakarta；升级到 4.5+ 的 `-jakarta-` 版本 |
| `/doc.html` 404 | 依赖没加 `-starter`；或 `knife4j.enable=false` |
| MySQL 8 连接报 timezone | JDBC URL 加 `serverTimezone=Asia/Shanghai` |
| Result 泛型序列化不出 data 字段 | Lombok 未生效；确认 `@Data` 加了 + IDEA 装了 Lombok 插件 |
| CategoryController 不出现在 Knife4j | Controller 不在 `com.yinxiang` 或子包下；或 `scanBasePackages` 未配 |
| 接口文档全英文 | `knife4j.setting.language: zh_cn` |
| 中文乱码 | JDBC URL `characterEncoding=UTF-8` + IDEA File Encoding 全 UTF-8 |

### 6.9 练习 / 思考

1. 建库 `yoga_member` + `t_category` 表 + 3 条种子数据。
2. 在 `yoga-common` 完成 `Result<T>` + `PageResult<T>`。
3. 集成 Knife4j，浏览器 `/doc.html` 打开成功截图。
4. 把今天所有改动按 `feat: 集成 Knife4j 与统一 Result 返回` 一次 commit 并 push。
5. **思考**：如果你的接口要返回一个 \"分类列表 + 总数\" 结构，应该用 `Result<List<Category>>` 还是 `Result<PageResult<Category>>`？为什么？

---

## Day05 学完你应该会

1. ✅ 说清印想瑜伽会馆项目的四大业务域与整套技术栈版本基线；
2. ✅ 在 Gitee 创建 `yoga-member` 私有仓库；
3. ✅ 用 `git init / add / commit / log / restore` 完成本地基本工作流；
4. ✅ 生成 SSH 密钥并添加到 Gitee，`ssh -T` 验证通过；
5. ✅ 用 `git remote add + push -u origin main` 完成首次远程推送；
6. ✅ 写出覆盖 Maven + IDEA + 敏感文件的 `.gitignore`，理解已追踪文件的处理方式；
7. ✅ 熟练使用 `switch -c / merge / branch -d`，能手工解决一次冲突；
8. ✅ 把单模块项目拆分为 5 个模块，`mvn clean install` 全绿；
9. ✅ 在 `yoga-common` 定义 `Result<T>` + `PageResult<T>`，Controller 全部包一层；
10. ✅ 集成 Knife4j 4.5，`/doc.html` 成功打开；
11. ✅ 背下项目开发规范：包/类/常量命名 + Conventional Commits。

---

## 附录：Day05 主线项目最终目录结构

做完 Day05 后，你的项目结构应该是这样：

```text
yoga-member/                     ← 父工程 + Git 仓库根
├── .git/
├── .gitignore
├── README.md
├── pom.xml                      ← 父 POM，packaging=pom
├── yoga-common/
│   ├── pom.xml
│   └── src/main/java/com/yinxiang/common/
│       ├── Result.java
│       └── PageResult.java
├── yoga-pojo/
│   ├── pom.xml
│   └── src/main/java/com/yinxiang/pojo/
│       ├── entity/
│       ├── dto/
│       └── vo/
├── yoga-mapper/
│   ├── pom.xml
│   ├── src/main/java/com/yinxiang/mapper/
│   └── src/main/resources/mapper/
├── yoga-service/
│   ├── pom.xml
│   └── src/main/java/com/yinxiang/service/
│       ├── CategoryService.java
│       └── impl/
└── yoga-web/
    ├── pom.xml
    ├── src/main/java/com/yinxiang/
    │   ├── YogaMemberApplication.java
    │   ├── controller/
    │   │   ├── HelloController.java
    │   │   └── CategoryController.java
    │   └── config/
    │       └── Knife4jConfig.java
    └── src/main/resources/
        ├── application.yml
        ├── application-dev.yml
        └── application-prod.yml
```

## 附录：父 POM 完整参考

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>4.0.0</version>
    </parent>

    <groupId>com.yinxiang</groupId>
    <artifactId>yoga-member</artifactId>
    <version>1.0.0</version>
    <packaging>pom</packaging>

    <modules>
        <module>yoga-common</module>
        <module>yoga-pojo</module>
        <module>yoga-mapper</module>
        <module>yoga-service</module>
        <module>yoga-web</module>
    </modules>

    <properties>
        <java.version>25</java.version>
        <maven.compiler.source>25</maven.compiler.source>
        <maven.compiler.target>25</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <mybatis.version>3.0.5</mybatis.version>
        <hutool.version>5.8.32</hutool.version>
        <knife4j.version>4.5.0</knife4j.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>org.mybatis.spring.boot</groupId>
                <artifactId>mybatis-spring-boot-starter</artifactId>
                <version>${mybatis.version}</version>
            </dependency>
            <dependency>
                <groupId>cn.hutool</groupId>
                <artifactId>hutool-all</artifactId>
                <version>${hutool.version}</version>
            </dependency>
            <dependency>
                <groupId>com.github.xiaoymin</groupId>
                <artifactId>knife4j-openapi3-jakarta-spring-boot-starter</artifactId>
                <version>${knife4j.version}</version>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <dependencies>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
    </dependencies>
</project>
```

## 附录：完整 `.gitignore` 参考

```gitignore
# Maven
target/
*.class
!.mvn/wrapper/maven-wrapper.jar

# IDEA
.idea/
*.iml
*.iws
*.ipr
out/

# Eclipse / VS Code
.project
.classpath
.settings/
.vscode/

# Logs
*.log
logs/

# OS
.DS_Store
Thumbs.db
desktop.ini

# Secrets & local
application-local.yml
application-secret.yml
.env
.env.local

# JVM crash
hs_err_pid*
replay_pid*
```

## 附录：AI 辅助（通义灵码 / Trae）常用提示词

**1. 生成 README 骨架**

```text
请为一个名为 yoga-member 的 Spring Boot 4.0 + MyBatis + MySQL 8.0 项目
生成一份中文 README.md 骨架，包含：项目简介、技术栈、目录结构、启动方式、贡献指南。
```

**2. 生成 Conventional commit message**

```text
以下是我当前的 git diff，请根据 Conventional Commits 规范帮我写一条 commit message：
<粘贴 git diff --staged>
```

**3. 生成分模块重构方案**

```text
我有一个单模块 Spring Boot 4 项目 yoga-member，包结构 com.yinxiang.controller/service/mapper/pojo，
请给出改造为 Maven 多模块项目的完整方案，包括：
1. 父 POM（含 dependencyManagement）
2. 5 个子模块（common/pojo/mapper/service/web）各自的 pom
3. 各模块之间的依赖关系图
4. 迁移步骤（含 @SpringBootApplication 与 @MapperScan 的调整）
```

**4. 生成 Result / PageResult / 异常类**

```text
请为 yoga-common 模块生成：
1. 泛型 Result<T> 类（code/msg/data + 静态工厂方法 success/error）
2. 泛型 PageResult<T> 类（total + rows）
3. 自定义异常 BizException（继承 RuntimeException）
4. 错误码枚举 ErrorCode（LOGIN_FAIL / PARAM_INVALID / DB_ERROR 等 10 个）
5. Result 与 ErrorCode 联动的 Result.error(ErrorCode) 重载
```

⚠️ AI 生成的每段代码**必须自己看懂再粘贴**，重点检查：
1. 包名是否为 `com.yinxiang.common`；
2. 是否加了 `@Data` `@Serializable`；
3. 泛型 `<T>` 有没有在返回类型和参数一致出现；
4. `static` 方法有没有正确使用 `<T>` 声明。
