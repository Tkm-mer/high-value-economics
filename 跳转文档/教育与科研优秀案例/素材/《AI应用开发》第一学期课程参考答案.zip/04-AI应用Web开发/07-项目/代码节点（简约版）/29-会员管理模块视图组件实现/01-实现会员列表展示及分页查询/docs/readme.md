

创建工具类 api.js。

```javascript
import axios from 'axios';

const api = axios.create({
    baseURL: '/api',
    timeout: 3000
});

api.interceptors.response.use(resp => {
    return resp.data;
}, error => {
    return {
        code: 500,
        success: false,
        msg: "服务器异常，请稍候再试"
    }
});

function createRestApi(baseUrl) {
    return {
        findAll(pageNo = 1, pageSize = 10, params = {}) {
            return api({
                url: baseUrl,
                method: 'get',
                params: {
                    pageNo,
                    pageSize,
                    ...params
                }
            });
        },
        save(model, params = {}) {
            return api({
                url: baseUrl,
                method: 'post',
                params,
                data: model
            });
        },
        update(model, params = {}) {
            return api({
                url: baseUrl,
                method: 'put',
                params,
                data: model
            });
        },
        deleteByIds(ids, params = {}) {
            return api({
                url: baseUrl,
                method: 'delete',
                params,
                data: ids
            })
        }
    };
}

export {api, createRestApi};
```



在 memberApi.js 中编写代码：

```javascript
import {createRestApi} from "@/utils/api.js";

const MemberApi = createRestApi("/members");

export default MemberApi;
```



编写 Member.vue，代码如下：

```html
<template>
  <div class="main">
    <el-table class="grid" :data="members" stripe border>
      <el-table-column prop="id" label="ID" width="80" fixed="left"/>
      <el-table-column prop="username" label="账号" width="150" fixed="left"/>
      <el-table-column prop="name" label="姓名" width="150" fixed="left"/>
      <el-table-column prop="pinyin" label="拼音" width="180"/>
      <el-table-column prop="sex" label="性别" width="60" align="center"/>
      <el-table-column prop="birthday" label="出生日期" align="center" width="130"/>
      <el-table-column prop="height" label="身高" width="140"/>
      <el-table-column prop="weight" label="体重" width="140"/>
      <el-table-column prop="email" label="邮箱" width="240"/>
      <el-table-column prop="phone" label="手机号" width="140"/>
      <el-table-column prop="qq" label="QQ" width="180"/>
      <el-table-column prop="wechat" label="微信" width="240"/>
      <el-table-column prop="idCardNo" label="身份证号" width="180"/>
      <el-table-column prop="address" label="住址" width="180"/>
      <el-table-column prop="addressDetail" label="地址详情" width="180"/>
      <el-table-column prop="description" label="备注" width="240" show-overflow-tooltip/>
      <el-table-column prop="createdTime" label="创建时间" width="180"/>
      <el-table-column prop="createdBy" label="创建人" width="120"/>
      <el-table-column prop="updatedTime" label="修改时间" width="180"/>
      <el-table-column prop="updatedBy" label="修改人" width="120"/>
    </el-table>
    <!-- 分页条中的页面大小必须和查询函数中的页面大小匹配，否则会出现多次查询 -->
    <el-pagination class="paginate-bar"
                   v-model:current-page="pi.pageNo"
                   v-model:page-size="pi.pageSize"
                   :total="pi.total"
                   :page-sizes="[10, 20, 30, 50, 100]" background
                   layout="total, sizes, prev, pager, next, jumper"
                   @change="findAll"/>
  </div>
</template>

<style scoped>
.grid {
  --el-table-row-hover-bg-color: #e8f5e9;
  --el-table-header-bg-color: #66bb6a;
  --el-table-header-text-color: #ffffff;
}

.paginate-bar {
  margin-top: 10px;
}
</style>

<script setup>
import {onMounted, ref} from "vue";
import MemberApi from "@/api/memberApi.js";

onMounted(() => {
  findAll();
});

const members = ref();
const pi = ref({
  pageNo: 1,
  pageSize: 10,
  total: 0
});

async function findAll(pageNo = 1, pageSize = 10) {
  let resp = await MemberApi.findAll(pageNo, pageSize);
  console.log(resp);
  members.value = resp.data.list;
  pi.value.pageNo = resp.data.pageNum;
  pi.value.pageSize = resp.data.pageSize;
  pi.value.total = resp.data.total;
}


</script>
```

