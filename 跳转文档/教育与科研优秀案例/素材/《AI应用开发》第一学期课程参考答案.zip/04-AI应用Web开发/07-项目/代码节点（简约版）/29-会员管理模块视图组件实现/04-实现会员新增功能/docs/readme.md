新增功能代码实现：

```vue
<template>
  <div class="main">
    <!--  条件区  -->
    <el-form inline :model="searchModel" :label-width="70" label-position="right" ref="searchFormRef">
      <el-form-item label="ID：" prop="id">
        <el-input v-model="searchModel.id" placeholder="请输入会员ID"/>
      </el-form-item>
      <el-form-item label="姓名：" prop="name">
        <el-input v-model="searchModel.name" placeholder="请输入会员姓名"/>
      </el-form-item>
      <el-form-item label="性别：" prop="sex">
        <el-select v-model="searchModel.sex" placeholder="请选择性别" :empty-values="[null]"
                   :value-on-clear="null"
                   style="width: 160px;">
          <el-option label="不限" value=""/>
          <el-option label="男" value="男"/>
          <el-option label="女" value="女"/>
        </el-select>
      </el-form-item>
      <el-form-item label="出生日期：" prop="birthdayRange" label-width="90">
        <el-date-picker v-model="searchModel.birthdayRange" type="daterange"
                        value-format="YYYY-MM-DD" start-placeholder="日期从" end-placeholder="日期至"
                        range-separator="~"/>
      </el-form-item>
      <el-form-item label="手机号：" prop="phone">
        <el-input v-model="searchModel.phone" placeholder="请输入会员手机号"/>
      </el-form-item>
      <el-form-item label="邮箱：" prop="email">
        <el-input v-model="searchModel.email" placeholder="请输入会员邮箱"/>
      </el-form-item>
    </el-form>

    <!-- 按钮区 -->
    <div class="action">
      <el-button type="primary" :icon="CirclePlus" @click="add">新增</el-button>
      <el-button type="primary" :icon="Edit">修改</el-button>
      <el-button type="primary" :icon="Search" @click="findAll()">查询</el-button>
      <el-button type="primary" :icon="Refresh" @click="resetSearchForm">重置</el-button>
      <el-button type="danger" :icon="Delete" @click="deleteAll">删除</el-button>
    </div>

    <!--  数据展示区  -->
    <el-table class="grid" :data="members" stripe border @row-click="tblRowClick" ref="tblRef">
      <el-table-column type="selection" align="center"/>
      <el-table-column prop="id" label="ID" width="80" fixed="left"/>
      <el-table-column prop="username" label="账号" width="150" fixed="left"/>
      <el-table-column prop="name" label="姓名" width="150" fixed="left"/>
      <el-table-column prop="pinyin" label="拼音" width="180"/>
      <el-table-column label="性别" width="60" align="center">
        <template #default="scope">
          <el-tag :type="scope.row.sex==='男'?'primary':'danger'">{{ scope.row.sex }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="birthday" label="出生日期" align="center" width="130"/>
      <el-table-column prop="height" label="身高" width="140"/>
      <el-table-column prop="weight" label="体重" width="140"/>
      <el-table-column prop="email" label="邮箱" width="240"/>
      <el-table-column prop="phone" label="电话" width="140"/>
      <el-table-column prop="qq" label="QQ" width="180"/>
      <el-table-column prop="wechat" label="微信" width="240"/>
      <el-table-column prop="idCardNo" label="身份证号" width="180"/>
      <el-table-column prop="address.fullName" label="住址" width="300" show-overflow-tooltip/>
      <el-table-column prop="addressDetail" label="住址详情" width="240" show-overflow-tooltip/>
      <el-table-column prop="description" label="备注" width="240" show-overflow-tooltip/>
      <el-table-column prop="createdTime" label="创建时间" width="180"/>
      <el-table-column prop="createdBy" label="创建人" width="120"/>
      <el-table-column prop="updatedTime" label="修改时间" width="180"/>
      <el-table-column prop="updatedBy" label="修改人" width="120"/>
      <el-table-column label="操作" fixed="right" width="180" align="center">
        <template #default="scope">
          <el-button size="small" type="primary" :icon="Edit">修改</el-button>
          <el-button size="small" type="danger" :icon="Delete" @click.stop="rowDel(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页条中的页面大小必须和查询函数中的页面大小匹配，否则会出现多次查询 -->
    <el-pagination class="paginate-bar"
                   v-model:current-page="pi.pageNo"
                   v-model:page-size="pi.pageSize"
                   :total="pi.total"
                   :page-sizes="[10, 20, 30, 50, 100]" background
                   layout="total, sizes, prev, pager, next, jumper"
                   @change="findAll"/>


    <!-- 弹出新增对话框 -->
    <el-dialog :title="dialogTitle" v-model="showDialog" draggable :close-on-click-modal="false"
               @close="onCloseDialog" style="width: 700px">
      <div>
        <el-form label-width="100" :model="memberModel" :rules="rules" ref="memberFormRef">
          <el-row>
            <el-col :span="12">
              <el-form-item label="账号：" prop="username">
                <el-input v-model="memberModel.username" placeholder="请输入会员账号"/>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="密码：" prop="password">
                <el-input v-model="memberModel.password" type="password" placeholder="请输入会员密码"/>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <el-col :span="12">
              <el-form-item label="姓名：" prop="name">
                <el-input v-model="memberModel.name" placeholder="请输入会员姓名"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="拼音：" prop="pinyin">
                <el-input v-model="memberModel.pinyin" placeholder="请输入会员姓名拼音"></el-input>
              </el-form-item>
            </el-col>
          </el-row>

          <el-row>
            <el-col :span="12">
              <el-form-item label="性别：" prop="sex">
                <el-radio-group v-model="memberModel.sex">
                  <el-radio value="男">男</el-radio>
                  <el-radio value="女">女</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="出生日期：" prop="birthday">
                <el-date-picker v-model="memberModel.birthday" value-format="YYYY-MM-DD"
                                type="date" placeholder="请输入会员出生日期" style="width: 100%"/>
              </el-form-item>
            </el-col>
          </el-row>


          <el-row>
            <el-col :span="12">
              <el-form-item label="身高：" prop="height">
                <el-input-number v-model="memberModel.height" :min="100" :max="300"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="体重：" prop="weight">
                <el-input-number v-model="memberModel.weight" :min="30" :max="200"/>
              </el-form-item>
            </el-col>
          </el-row>


          <el-row>
            <el-col :span="12">
              <el-form-item label="邮箱：" prop="email">
                <el-input v-model="memberModel.email" placeholder="请输入会员电子邮箱"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="电话：" prop="phone" required>
                <el-input v-model="memberModel.phone" placeholder="请输入会员手机号"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="QQ：" prop="qq">
                <el-input v-model="memberModel.qq" placeholder="请输入会员QQ号"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="微信：" prop="wechat">
                <el-input v-model="memberModel.wechat" placeholder="请输入会员微信号"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="身份证号：" prop="idCardNo">
                <el-input v-model="memberModel.idCardNo" placeholder="请输入会员身份证号"/>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="住址：" prop="addressId">
                <el-tree-select
                    v-model="memberModel.addressId"
                    lazy
                    :load="load"
                    :props="props"
                >
                  <template #default="{ data }">
                    <span>{{ data.name }}</span>
                  </template>
                </el-tree-select>
              </el-form-item>
            </el-col>

            <el-col :span="24">
              <el-form-item label="住址详情：" prop="addressDetail">
                <el-input v-model="memberModel.addressDetail" placeholder="请输入住址详情"/>
              </el-form-item>
            </el-col>

            <el-col :span="24">
              <el-form-item label="备注：" prop="description">
                <el-input v-model="memberModel.description" type="textarea" :rows="5" placeholder="请输入会员备注"/>
              </el-form-item>
            </el-col>
          </el-row>

        </el-form>
      </div>
      <template #footer>
        <div class="footer">
          <el-button type="primary" @click="submitAdd">确定</el-button>
          <el-button @click="showDialog = false">取消</el-button>
        </div>
      </template>
    </el-dialog>

  </div>
</template>

<style scoped>
.main {
  height: 100%;
  padding: 8px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.grid {
  --el-table-row-hover-bg-color: #e8f5e9;
  --el-table-header-bg-color: #66bb6a;
  --el-table-header-text-color: #ffffff;
}

.paginate-bar, .grid {
  margin-top: 10px;
}
</style>

<script setup>
import {onMounted, reactive, ref, toRaw} from "vue";
import MemberApi from "@/api/memberApi.js";
import {CirclePlus, Delete, Edit, Refresh, Search} from "@element-plus/icons-vue";
import {ElMessage, ElMessageBox} from "element-plus";
import RegionApi from "@/api/regionApi.js";


//树属性
const props = {
  label: 'fullName',
  isLeaf: 'isLeaf'
}

//加载省市区域四级地址
const load = (node, resolve) => {
  if (node.level === 4) {
    return resolve([]);
  }

  let parentId = node.data.id;
  if (node.level === 0) {
    parentId = 0;
  }

  RegionApi.findByParentId(parentId).then(resp => {
    if (resp.success) {
      let arr = resp.data;
      arr.forEach(item => {
        item.value = item.id;
        item.isLeaf = item.level === 4;
      });
      resolve(arr);
    }
  });
}


onMounted(() => {
  findAll();
});

const members = ref();
const pi = ref({
  pageNo: 1,
  pageSize: 10,
  total: 0
});

async function findAll(pageNo = 1, pageSize = 10) {
  let params = toRaw(searchModel);

  if (params.birthdayRange) {
    params.birthdayFrom = params.birthdayRange[0];
    params.birthdayTo = params.birthdayRange[1];
    delete params.birthdayRange;
  }

  let resp = await MemberApi.findAll(pageNo, pageSize, params);
  members.value = resp.data.list;
  pi.value.pageNo = resp.data.pageNum;
  pi.value.pageSize = resp.data.pageSize;
  pi.value.total = resp.data.total;
}

///////////////////////
// 查询表单双向绑定数据
const searchModel = reactive({
  id: null,
  name: null,
  sex: null,
  birthdayRange: [],
  phone: null,
  email: null
});

const searchFormRef = ref();

function resetSearchForm() {
  searchFormRef.value.resetFields();
}

////////////////////////////////////
//表格引用
const tblRef = ref();

//表格行单击事件
function tblRowClick(row) {
  tblRef.value.toggleRowSelection(row);
}

// 批量删除全部
function deleteAll() {
  let rows = tblRef.value.getSelectionRows();
  let ids = rows.map(t => t.id);
  if (ids.length === 0) {
    ElMessage.warning("请选择您要删除的行");
  } else {
    ElMessageBox.confirm("是否确认删除选中的行?", "警告", {
      type: "warning"
    }).then(() => {
      deleteByIds(ids);
    });
  }
}

//批量删除
async function deleteByIds(ids) {
  let resp = await MemberApi.deleteByIds(ids);
  if (resp.success) {
    ElMessage.success("操作成功，共删除" + resp.data + "行");
    await findAll();//重新加载
  } else {
    ElMessage.error(resp.msg || "操作失败");
  }
}

//删除单行
function rowDel(row) {
  ElMessageBox.confirm("是否确认删除选中的行?", "警告", {
    type: "warning"
  }).then(() => {
    deleteByIds([row.id]);
  });
}


///////////////////////////////////////////新增
const dialogTitle = ref("新增");
const showDialog = ref(false);
const memberFormRef = ref();
let mode = "add";//操作模式

// 添加或修改会员的表单数据
const memberModel = reactive({
  username: null,
  password: null,
  name: null,
  pinyin: null,
  sex: "男",
  birthday: null,
  height: null,
  weight: null,
  email: null,
  phone: null,
  qq: null,
  wechat: null,
  idCardNo: null,
  addressId: null,
  addressDetail: null,
  description: null
});

// 表单验证规则
const rules = {
  username: [{
    required: true, message: "账号不可为空", trigger: "blur"
  }],
  password: [{
    validator: validatePassword, trigger: "blur"
  }],
  name: [{
    required: true, message: "姓名不可为空", trigger: "blur"
  }],
  email: [{
    required: true, message: "邮箱不可为空", trigger: "blur"
  }, {
    type: "email", message: "邮箱格式不正确", trigger: "blur"
  }],
  phone: [{
    required: true, message: "手机号不可为空", trigger: "blur"
  }, {
    pattern: /^1\d{10}$/, message: "手机号必须是11位", trigger: "blur"
  }]
};

function validatePassword(rule, value, cb) {
  if (value === null || value.trim() === '') {
    if (mode === "add") {
      cb("密码不可为空");
    } else {
      cb();
    }
  } else {
    if (value.length < 6) {
      cb("密码长度不能小于6位");
    } else {
      cb();
    }
  }
}

//关闭对话框时触发
function onCloseDialog() {
  memberFormRef.value.resetFields();//重置表单内容
}

function add() {
  dialogTitle.value = "新增";
  showDialog.value = true;
  mode = "add";
}

//提交会员数据
async function submitAdd() {
  let member = toRaw(memberModel);
  let resp = await MemberApi.save(member);

  if (resp.success) {
    ElMessage.success("新增会员成功");
    showDialog.value = false;//关闭窗口
    await findAll();
  } else {
    ElMessage.error(resp.msg || "新增会员失败");
  }
}


</script>
```





