

Member.vue 代码示例如下：

```html
<template>
  <div class="main">
    <el-form inline :model="searchModel" :label-width="70" label-position="right" ref="searchFormRef">
      <el-form-item label="ID：" prop="id">
        <el-input v-model="searchModel.id" placeholder="请输入会员ID"/>
      </el-form-item>
      <el-form-item label="姓名：" prop="name">
        <el-input v-model="searchModel.name" placeholder="请输入会员姓名"/>
      </el-form-item>
      <el-form-item label="性别：" prop="sex">
        <el-select v-model="searchModel.sex" placeholder="请选择性别" :empty-values="[null]"
                   :value-on-clear="null"
                   style="width: 160px;">
          <el-option label="不限" value=""/>
          <el-option label="男" value="男"/>
          <el-option label="女" value="女"/>
        </el-select>
      </el-form-item>
      <el-form-item label="出生日期：" prop="birthdayRange" label-width="90">
        <el-date-picker v-model="searchModel.birthdayRange" type="daterange"
                        value-format="YYYY-MM-DD" start-placeholder="日期从" end-placeholder="日期至"
                        range-separator="~"/>
      </el-form-item>
      <el-form-item label="手机号：" prop="phone">
        <el-input v-model="searchModel.phone" placeholder="请输入会员手机号"/>
      </el-form-item>
      <el-form-item label="邮箱：" prop="email">
        <el-input v-model="searchModel.email" placeholder="请输入会员邮箱"/>
      </el-form-item>
    </el-form>

    <!-- 按钮区 -->
    <div class="action">
      <el-button type="primary" :icon="CirclePlus">新增</el-button>
      <el-button type="primary" :icon="Edit">修改</el-button>
      <el-button type="primary" :icon="Search" @click="findAll()">查询</el-button>
      <el-button type="primary" :icon="Refresh" @click="resetSearchForm">重置</el-button>
      <el-button type="danger" :icon="Delete">删除</el-button>
    </div>

    <!--  数据展示区  -->
    <el-table class="grid" :data="members" stripe border>
      <el-table-column prop="id" label="ID" width="80" fixed="left"/>
      <el-table-column prop="username" label="账号" width="150" fixed="left"/>
      <el-table-column prop="name" label="姓名" width="150" fixed="left"/>
      <el-table-column prop="pinyin" label="拼音" width="180"/>
      <el-table-column prop="sex" label="性别" width="60" align="center"/>
      <el-table-column prop="birthday" label="出生日期" align="center" width="130"/>
      <el-table-column prop="height" label="身高" width="140"/>
      <el-table-column prop="weight" label="体重" width="140"/>
      <el-table-column prop="email" label="邮箱" width="240"/>
      <el-table-column prop="phone" label="手机号" width="140"/>
      <el-table-column prop="qq" label="QQ" width="180"/>
      <el-table-column prop="wechat" label="微信" width="240"/>
      <el-table-column prop="idCardNo" label="身份证号" width="180"/>
      <el-table-column prop="address.fullName" label="住址" width="300" show-overflow-tooltip/>
      <el-table-column prop="addressDetail" label="地址详情" width="180"/>
      <el-table-column prop="description" label="备注" width="240" show-overflow-tooltip/>
      <el-table-column prop="createdTime" label="创建时间" width="180"/>
      <el-table-column prop="createdBy" label="创建人" width="120"/>
      <el-table-column prop="updatedTime" label="修改时间" width="180"/>
      <el-table-column prop="updatedBy" label="修改人" width="120"/>
    </el-table>
    <!-- 分页条中的页面大小必须和查询函数中的页面大小匹配，否则会出现多次查询 -->
    <el-pagination class="paginate-bar"
                   v-model:current-page="pi.pageNo"
                   v-model:page-size="pi.pageSize"
                   :total="pi.total"
                   :page-sizes="[10, 20, 30, 50, 100]" background
                   layout="total, sizes, prev, pager, next, jumper"
                   @change="findAll"/>
  </div>
</template>

<style scoped>
.main {
  height: 100%;
  padding: 8px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.grid {
  --el-table-row-hover-bg-color: #e8f5e9;
  --el-table-header-bg-color: #66bb6a;
  --el-table-header-text-color: #ffffff;
}

.paginate-bar, .grid {
  margin-top: 10px;
}
</style>

<script setup>
import {onMounted, reactive, ref, toRaw} from "vue";
import MemberApi from "@/api/memberApi.js";
import {CirclePlus, Delete, Edit, Refresh, Search} from "@element-plus/icons-vue";

onMounted(() => {
  findAll();
});

const members = ref();
const pi = ref({
  pageNo: 1,
  pageSize: 10,
  total: 0
});

async function findAll(pageNo = 1, pageSize = 10) {
  let params = toRaw(searchModel);

  if (params.birthdayRange) {
    params.birthdayFrom = params.birthdayRange[0];
    params.birthdayTo = params.birthdayRange[1];
    delete params.birthdayRange;
  }

  let resp = await MemberApi.findAll(pageNo, pageSize, params);
  members.value = resp.data.list;
  pi.value.pageNo = resp.data.pageNum;
  pi.value.pageSize = resp.data.pageSize;
  pi.value.total = resp.data.total;
}

///////////////////////
// 查询表单双向绑定数据
const searchModel = reactive({
  id: null,
  name: null,
  sex: null,
  birthdayRange: [],
  phone: null,
  email: null
});

const searchFormRef = ref();

function resetSearchForm() {
  searchFormRef.value.resetFields();
}

</script>
```

