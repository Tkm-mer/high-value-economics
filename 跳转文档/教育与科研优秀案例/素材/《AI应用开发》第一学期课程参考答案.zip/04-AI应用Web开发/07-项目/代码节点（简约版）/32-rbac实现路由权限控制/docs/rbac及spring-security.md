# RBAC 及 Spring Security 权限控制


## **一、RBAC 概述**

### **1、RBAC 模型概述**

RBAC 模型（Role-Based Access Control：基于角色的访问控制）模型是 20 世纪 90 年代研究出来的一种新模型，但其实在 20 世纪 70 年代的多用户计算时期，这种思想就已经被提出来，直到 20 世纪 90 年代中后期，RBAC 才在研究团体中得到一些重视，并先后提出了许多类型的 RBAC 模型。其中以美国 George Mason大学信息安全技术实验室（LIST）提出的 RBAC96 模型最具有代表，并得到了普遍的公认。

RBAC 认为权限授权的过程可以抽象地概括为：`Who 是否可以对 What 进行 How 的访问操作`，并对这个逻辑表达式进行判断是否为 True 的求解过程，也即是将权限问题转换为 What、How 的问题，Who、What、How 构成了访问权限三元组；

### **2、RBAC 的组成**

在 RBAC 模型里面，有 3 个基础组成构件，分别是：用户、角色和权限。

RBAC 通过定义角色的权限，并对用户授予某个角色从而来控制用户的权限，实现了用户和权限的逻辑分离，极大地方便了权限的管理：

+ User（用户）：每个用户都有唯一的 UID 识别，并被授予不同的角色
+ Role（角色）：不同角色具有不同的权限
+ Permission（权限）：访问及操作权限
+ 用户-角色映射：可通过中间表实现，用于反映用户和角色之间的映射关系
+ 角色-权限映射：可通过中间表实现，用于反映角色和权限之间的映射

它们之间的关系如下图所示
![](./assets/1729472304252-ba1b2909-c7d4-4b7c-975f-f8cc27196329.png)

如下图，管理员和普通用户被授予不同的权限，普通用户只能去修改和查看个人信息，而不能创建创建用户和冻结用户，而管理员由于被授 予所有权限，所以可以做所有操作。
![](./assets/1729472304302-5ca4452e-159b-4565-ad44-3ade44c46a66.png)

### **3、RBAC 支持的安全原则**

RBAC 支持三个著名的安全原则：最小权限原则、责任分离原则和数据抽象原则

+ 最小权限原则：RBAC 可以将角色配置成其完成任务所需的最小权限集合。
+ 责任分离原则：可以通过调用相互独立互斥的角色来共同完成敏感的任务，例如要求一个计账员和财务管理员共同参与统一过账操作。
+ 数据抽象原则：可以通过权限的抽象来体现，例如财务操作用借款、存款等抽象权限，而不是使用典型的读、写、执行权限。

### **4、RBAC 的优缺点**

（1）优点：简化了用户和权限的关系，易扩展、易维护

（2）缺点：RBAC 模型没有提供操作顺序的控制机制，这一缺陷使得 RBAC 模型很难适应哪些对操作次序有严格要求的系统

### **5、RBAC 的 3 种模型**

（1）RBAC0

RBAC0，是最简单、最原始的实现方式，也是其它 RBAC 模型的基础。
![](./assets/1729472304299-a314b950-3028-4382-9b75-3d7d33376363.png)

在该模型中，用户和角色之间可以是多对多的关系，即一个用户在不同场景下是可以有不同的角色，例如：项目经理也可能是组长，也可能是架构师。同时每个角色都至少有一个权限。这种模型下，用户和权限被分离独立开来，使得权限的授权认证更加灵活。

（2）RBAC1

基于 RBAC0 模型，引入了角色间的继承关系，即角色上有了上下级的区别。
![](./assets/1729472304294-47ab7b9c-563f-4ee9-9cd4-bb660f350df5.png)

角色间的继承关系可分为一般继承关系和受限继承关系。一般继承关系仅要求角色继承关系是一个绝对偏序关系，允许角色间的多继承。而受限继承关系则进一步要求角色继承关系是一个树结构，实现角色间的单继承。

这种模型适合于角色之间层次分明，可以给角色分组分层。

（3）RBAC2

RBAC2，基于 RBAC0 模型的基础上，进行了角色的访问控制。
![](./assets/1729472304315-83df6a4d-ac5b-4558-a8b1-750d0d63f6a4.png)

RBAC2 中的一个基本限制是互斥角色的限制，互斥角色是指各自权限可以互相制约的两个角色。对于这类角色一个用户在某一次活动中只能被分配其中的一个角色，不能同时获得两个角色的使用权。

该模型有以下几种约束：

+ 互斥角色：同一用户只能分配到一组互斥角色集合中至多一个角色，支持责任分离的原则。互斥角色是指各自权限互相制约的两个角色。对于这类角色一个用户在某一次活动中只能被分配其中的一个角色，不能同时获得两个角色的使用权。常举的例子：在审计活动中，一个角色不能同时被指派给会计角色和审计员角色。
+ 基数约束：一个角色被分配的用户数量受限；一个用户可拥有的角色数目受限；同样一个角色对应的访问权限数目也应受限，以控制高级权限在系统中的分配。例如公司的领导人有限的；
+ 先决条件角色：可以分配角色给用户仅当该用户已经是另一角色的成员；对应的可以分配访问权限给角色，仅当该角色已经拥有另一种访问权限。指要想获得较高的权限，要首先拥有低一级的权限。就像我们生活中，国家主席是从副主席中选举的一样。
+ 运行时互斥：例如，允许一个用户具有两个角色的成员资格，但在运行中不可同时激活这两个角色。

### **6、RBAC 的实现方式**

+ 开发者自行实现，这种情况在实际业务中并不少见，甚至可以说比较多。
+ Apache Shiro 框架：相对于 Spring Security 来说，功能简略一点，上手比较容易，使用上也比较简单。
+ Spring Security 框架：优点是可以和 Spring 自家产品良好的兼容性，易于整合。
+ 第三方权限框架：如 sa-token（[https://sa-token.cc/](https://sa-token.cc/)），易用性强，简单方便。

自定义实现参考：

1. 常见构件：用户，身份，用户组，角色，权限，权限组，资源（目标对象）
2. 每个用户拥有唯一的用户名（使用用户名登录）。
3. 每个用户可拥有多个身份，但同一时刻，同一场景，只能使用一个身份使用系统（类似于会话机制）。可以使用默认身份登入系统，在系统中随时切换身份。身份可以理解为用户的深层标识，不能被其他用户重用，每个用户可以无限制的定义任何身份。
4. 用户组用于组织管理用户，一个用户组可以包含多个用户。注意：用户组管理的是用户身份，也就是说，以用户名及其身份作为标识。
5. 用户组可拥有多个角色。添加角色时，使用“角色添加规则接口”来检测是否允许添加。
6. 角色。根据需要可选择使用继承，或使用组合的方式。
7. 权限。
8. 权限组，可以包含多项权限。
9. 资源（目标对象）。

注意事项：权限表的设计，由于存在大量的多对多关系，需要创建大量的中间表，如用户-用户组关联表、用户组-角色关联表、角色-权限组关联表、权限组-权限关联表等等。而实际业务中，某些多对多关系，属于稀疏多对多关系，比如：大多数用户只拥有一个或少数几个用户组，大多数用户组只拥有一个或少数几个角色，对于这种稀疏多对多关系，额外设计一个中间表过于浪费。推荐以下解决方案：

1. 在 mysql 中，不设中间表，通过 json 类型字段来实现，使用 json 数据类型可以同时指定多个数据。缺点：对于这种多对多关系的 CRUD 要涉及到 mysql 底层对 json 操作的语法。
2. 如果使用了 mybatis 框架，那么可以自定义 TypeHandler，对某一列的数据进行自定义的类型转换。缺点：与 mybatis 紧耦合。

## **二、Spring Security 核心原理**

### **1、核心原理**

**Authentication**：认证对象接口，包含认证信息和权限信息。

**AuthenticationManager**：认证管理器接口，可以对 Authentication 对象进行认证，并返回一个经认证过的 Authentication 对象（认证过之后，可赋予权限）。

**SecurityContext**：权限上下文对象，持有一个 Authentication 对象。

**SecurityContextHolder**：本地线程实例（ThreadLocal），持有一个 SecurityContext 对象。

**AccessDecisionManager**：鉴权管理器接口，用于判定是否拥有访问某个目标资源的权限。在 spring security 6 中已废弃，使用 AuthorizationManager 替代。

核心原理俟补。

### **2、Web 应用中集成 Spring Security 的核心原理**

`俟补。`

## **三、Spring Boot 整合 Spring Security**

### **1、Spring Security 之认证 Hello World**

引入依赖：在 springboot 项目中，无需指定版本号，从父项目管理的依赖中直接获取。

```xml
<!--认证与鉴权框架-->
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

> 注：spring-boot 3.0.6 对应的 Spring Seucirty 版本为 6.0.3

启动 springboot 程序，在控制台会有如下日志提示：


![](./assets/1729472304907-fed3c4e3-2619-423d-9c64-14d05201061c.png)

表示生成随机密码，但仅用于测试或调试。

访问任意地址，会直接跳转到 spring security 内置的登录页面。这个默认的登录页，使用的是前端 bootstrap（国外 cdn）框架，如果不翻墙，有可能会加载很慢（默认的注销页面也一样）。


![](./assets/1729472305115-0bc4e174-39ae-460f-a6e2-c9afa4dfd25d.png)

使用用户名 user 和控制台打印的密码即可登录，错误的用户名和密码将跳转到登录失败页。

Spring Security 的默认登录页面是在 `DefaultLoginPageGeneratingFilter` 类里面的 `generateLoginPageHtml` 产生的，如下：

```java
private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
throws IOException, ServletException {
    boolean loginError = isErrorPage(request);
    boolean logoutSuccess = isLogoutSuccess(request);
    if (isLoginUrlRequest(request) || loginError || logoutSuccess) {
        //构建用于认证的html（即登录页），在内存中构建
        String loginPageHtml = generateLoginPageHtml(request, loginError, logoutSuccess);
        response.setContentType("text/html;charset=UTF-8");
        response.setContentLength(loginPageHtml.getBytes(StandardCharsets.UTF_8).length);
        response.getWriter().write(loginPageHtml);
        return;
    }
    chain.doFilter(request, response);
}
```

创建认证页面的代码：

```java
 private String generateLoginPageHtml(HttpServletRequest request, boolean loginError, boolean logoutSuccess) {
    ...
    String contextPath = request.getContextPath();
    StringBuilder sb = new StringBuilder();
    sb.append("<!DOCTYPE html>\n");
    sb.append("<html lang=\"en\">\n");
    sb.append("  <head>\n");
    sb.append("    <meta charset=\"utf-8\">\n");
    sb.append("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n");
    sb.append("    <meta name=\"description\" content=\"\">\n");
    sb.append("    <meta name=\"author\" content=\"\">\n");
    sb.append("    <title>Please sign in</title>\n");
    ...
    return sb.toString();
 }
```

### **2、自定义认证表单**

**2.1 spring security 5.4 之后的新配置方法**

在 springboot 的配置类中创建 Bean，使用 HttpSecurity 的链式方法调用，构建包含一系列过滤器的过滤器链（SecurityFilterChain）。

其原理如下图：


![](./assets/1729472305138-92e7ea41-7f61-468c-9fa1-8b5baaf5ed8d.png)

其中，FilterChainProxy 就是一个 Filter 代理，其内部又包含了一系列的 Security Filter（可以叫 Filter，也可以叫 Interceptor，总之是 Spring Security 的内部构件）

有的时候，我们可能需要针对不同类型的请求，配置多个 SecurityFilterChain 来实现对多种访问控制策略，示例图如下：


![](./assets/1729472305158-a4107772-8702-4165-bf57-e7c5fddc789d.png)

以上示例图，表示对某一个路径规则，单独设置一个 SecurityFilterChain。

配置的参考代码如下：

```java
/**
 * 适配spring security 6
 * 如果引入的是spring-boot-starter-security，则无需添加@EnableWebSecurity，会自动启用。
 * 如果是单纯引入spring-security，则需添加@EnableWebSecurity注解
 */
@Configuration
@EnableWebSecurity
public class MySS6Config {
    //自定义的全局启用SpringSecurity的开头
    @Value("${spring.security.enabled:true}")
    private boolean securityEnabled;

    /**
     * 构建Spring Security的内部过滤器链。
     * 返回用户信息的实现（UserDetailService的实现）定义在UserServiceImpl类中，并加入到spring容器
     * <p>
     * 注意：在Spring Security 6中，FilterSecurityInterceptor已被标注为过时，使用AuthorizationFilter替代，以下注释中，凡涉及到FilterSecurityInterceptor的，在Spring Security 6中，均已不存在，也不建议使用
     *
     * @param hs              HttpSecurity实例，用于构建Spring Security的内部过滤器链
     * @param securityService 用于获取权限元数据的业务接口
     * @return 内部过滤器链
     * @throws Exception 异常
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity hs, SecurityService securityService) throws Exception {
        if (!securityEnabled) {
            //如果不开启spring security，则不进行鉴权，全部放行
            return hs.authorizeHttpRequests().requestMatchers("/**").permitAll().and().build();
        }
        //一、禁用csrf
        //关闭csrf，默认是开启的，开启后会导致我们的登录被拦截，导致登录失败
        hs.csrf().disable().headers().frameOptions().disable();

        //二、认证表单相关配置。
        //认证过程主要依赖UsernamePasswordAuthenticationFilter实现，此过滤器调用formLogin之后就会被激活。如果想实现自定义认证，可参考此过滤器的实现。
        //其抽象父类AbstractAuthenticationProcessingFilter实现了通用业务逻辑，及成功、失败之后的处理，通过模板方法设计模式，调用子类的attemptAuthentication方法，而UsernamePasswordAuthenticationFilter的实现，就是组装登录表单数据(自定义的重要部分)，
        //然后调用父类注入的AuthenticationManager，实现最后的认证过程。而AuthenticationManager就是一个认证接口，开发者也可完全自定义。
        hs.formLogin()  //调用此方法就会激活UsernamePasswordAuthenticationFilter过滤器
                .loginPage("/login") //设置登录页地址，缺省为"/login"，如果想自定义的话，不管是否"/login"，都必须如此显式设置，如果不进行显式设置的话，则依然会跳转到内置的登录页
                //.usernameParameter("username") //设置用户名表单名称，缺省即为username
                //.passwordParameter("password") //设置密码表单名称，缺省即为password
                //.loginProcessingUrl("/login") //认证提交认证的地址，缺省即为"/login"，类型为post。注意：此请求无需开发者处理，而是用来设置在登录表单上的action属性上的，spring security会自动拦截进行认证处理

                .defaultSuccessUrl("/", false) //设置认证成功后默认的重定向地址，第二个参数表示是否始终重定向到此页面，如果不指定，可能会跳转到登录前的地址（若有）。如果在重写向过程中，地址出现了?continue字样，这是spring security的处理，是正常的
                //.successForwardUrl("/index") //认证成功后，转发到的地址，如果配置了此项，则defaultSuccessUrl失效
                //认证成功之后的自定义登录处理。注意：如果设置了successHandler，则defaultSuccessUrl和successForwardUrl会失效。本质上，设置defaultSuccessUrl或successForwardUrl最后也会包装成一个SuccessHandler
                //认证逻辑详见AbstractAuthenticationProcessingFilter类的doFilter方法
                //.successHandler((request, response, authentication) -> {})

                //.failureForwardUrl("/loginFailure") //认证失败后的转发地址，因为是登录校验之后转发，所以依然是post类型。注：可通过error请求参数获取错误信息
                .failureHandler((request, response, exception) -> {
                    request.getSession().setAttribute("exception", exception);
                    response.sendRedirect(request.getContextPath() + "/loginFailure");
                });//认证失败之后的处理。注意：如果设置了failureHandler，则failureForwardUrl将失效。详见AbstractAuthenticationFilterConfigurer类的failureUrl(String authenticationFailureUrl)方法

        //此permitAll()方法用于对开发者显式自定义的请求地址(仅包括loginPage、loginProcessingUrl、failureForwardUrl)进行忽略过滤
        //在spring security 5上，调用此方法就会在过滤器链中添加FilterSecurityInterceptor，所以此句注释是为了不再添加FilterSecurityInterceptor到SecurityFilterChain中，对于要放行的请求地址，可由开发者自行处理。
        //而在spring security 6中，FilterSecurityInterceptor已标注为过时(使用AuthorizationFilter)。调用此方法，则在后续步骤中，必须调用authorizeHttpRequests()方法，否则不会创建AuthorizationFilter，配置放行的白名单就无效了。
        //.permitAll();

        //三、白名单配置：
        //此句配置会创建一个过滤一切请求，但对指定白名单地址放行的AuthorizationFilter。由于我们要自定义鉴权过滤器，所以此句注释了。
        //hs.authorizeHttpRequests().requestMatchers("/loginFailure").permitAll();

        //四、鉴权配置：
        //在spring security 5中，调用permitAll方法或authorizeRequests方法，会在过滤器链中添加FilterSecurityInterceptor这个过滤器
        //在spring security 6中，调用authorizeHttpRequests方法，会在过滤器中添加AuthorizationFilter，调用permitAll不再自动添加过滤器，需要用户手动配置，如果未配置，会报异常

        //以下示例配置用以配置一个过滤一切请求，但只需通过认证即可AuthorizationFilter
        /*hs
                //.userDetailsService() //由开发者指定UserDetailService实例(用于获取指定用户名的用户实体)，也可创建为Spring的Bean，spring security会自动注入
                //.authenticationManager() //由开发者指定AuthenticateManager实例，也可建为Spring的Bean，spring security会自动注入
                .authorizeHttpRequests(customizer -> customizer.anyRequest().authenticated() //表示任意请求路径都需要先通过认证
                );*/


        //通过securityService获取所有权限元数据，返回一个Map实例，键为uri，值为访问此uri所需要的权限。注意：uri支持使用ant pattern。
        Map<String, Collection<ConfigAttribute>> configAttributeMap = securityService.findAllSecurityAuthorities();
        //权限元数据，在spring security 6中，SecurityMetadataSource已不是一个必须组件。
        SecurityMetadataSource securityMetadataSource = new MySS6MetadataSource(configAttributeMap);

        //自定义基于请求路径的鉴权管理器
        AuthorizationManager<HttpServletRequest> authorizationManager = new MySS6AuthorizationManager(securityMetadataSource);

        //不进行权限过滤，直接放行的白名单。此白名单的不足是，并未对请求方法(get/post/delete/patch/put)进行判定
        Set<String> ignoreUrls = Set.of("/login/**", "/logout/**", "/loginFailure/**", "/authorizeFailure/**");
        //此过滤器不能作为bean，暴露给spring容器，否则下方代码又再次将过滤器加入到spring security的内部过滤器链，就会造成同一个过滤器被加入两次的情况
        MySS6Filter filter = new MySS6Filter(authorizationManager, ignoreUrls);

        //五、添加自定义过滤器。有三种添加方式：
        //addFilterBefore：表示在某个目标过滤器之前添加
        //addFilterAfter：表示在某个目标过滤器之后添加
        //addFilterAt：表示在某个目标过滤器的位置添加，添加之后，两个过滤器拥有相同的顺序值。注意：此操作并不会覆盖目标过滤器。
        //addFilter：要求参数必须是内置过滤器的实现类或子类，根据其类型（继承类型），自动查询其顺序值，然后添加到过滤器链中，不会覆盖原过滤器

        //重点：此处的MySS6Filter实例并没有创建为Spring的Bean，原因是如果创建为Spring的Bean，则会被Spring自动添加到过滤器链中，同时又使用addFilter，会出现添加两个重复的过滤器，进而出现一个url被过滤两次的情况
        //重点：MySS6Filter功能与FilterSecurityInterceptor(AuthorizationFilter)的功能是类似而相斥的，不应同时存在，否则会出现同一个url被执行重复业务操作的情况（如鉴权两次）
        hs.addFilter(filter).exceptionHandling()
                //.accessDeniedHandler((request, response, accessDeniedException) -> {}) //自定义AccessDeniedHandler，有更大的灵活性和自由性
                .accessDeniedPage("/authorizeFailure"); //指定鉴权失败后的转发页面，否则将默认转发到"/error"，并响应一个403状态码
        return hs.build();
    }

    /**
     * 密码加密器，必须配置，有多个内置实现，开发者也可自定义实现
     * 在DaoAuthenticationProvider类中的additionalAuthenticationChecks方法中会用到，用以进行密码校验
     *
     * @return 密码加密器实例
     */
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
```

**2.2 认证逻辑源码导读**

通过 HttpSecurity 的链式操作，返回的`SecurityFilterChain` 即相当于定制一系列过滤器。

其中 **formLogin() **方法用于创建 **UsernamePasswordAuthenticationFilter**，此过滤器继承自 **AbstractAuthenticationProcessingFilter**，后者关键源码如下：

```java
 private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
     throws IOException, ServletException {
     if (!requiresAuthentication(request, response)) {
         chain.doFilter(request, response);
         return;
     }
     try {
         //attemptAuthentication是模板方法设计模式
         //调用子类UsernamePasswordAuthenticationFilter的attemptAuthentication方法进行认证，返回认证后的Authentication实例
         //子类UsernamePasswordAuthenticationFilter主要用于从请求中获取username和password，并通过内部持有的AuthenticationManager进行认证
         Authentication authenticationResult = attemptAuthentication(request, response);
         if (authenticationResult == null) {
             // return immediately as subclass has indicated that it hasn't completed
             return;
         }
         this.sessionStrategy.onAuthentication(authenticationResult, request, response);
         // Authentication success
         if (this.continueChainBeforeSuccessfulAuthentication) {
             chain.doFilter(request, response);
         }
         //跳转到认证成功处理函数
         successfulAuthentication(request, response, chain, authenticationResult);
     }
     catch (InternalAuthenticationServiceException failed) {//内部认证服务异常
         this.logger.error("An internal error occurred while trying to authenticate the user.", failed);
         //跳转到认证失败处理函数
         unsuccessfulAuthentication(request, response, failed);
     }
     catch (AuthenticationException ex) {//认证失败异常
         // Authentication failed
         //跳转到认证失败处理函数
         unsuccessfulAuthentication(request, response, ex);
     }
 }
```

认证成功处理函数如下：

```java
 protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
                                         Authentication authResult) throws IOException, ServletException {
     //1.创建安全上下文实例
     SecurityContext context = SecurityContextHolder.createEmptyContext();
     //2.将认证信息存入上下文实例
     context.setAuthentication(authResult);
     //3.使用本地线程变量持有安全上下文实例，在任意时刻都可通过SecurityContextHolder获取安全上下文对象
     SecurityContextHolder.setContext(context);
     this.securityContextRepository.saveContext(context, request, response);
     if (this.logger.isDebugEnabled()) {
         this.logger.debug(LogMessage.format("Set SecurityContextHolder to %s", authResult));
     }
     this.rememberMeServices.loginSuccess(request, response, authResult);
     if (this.eventPublisher != null) {
         this.eventPublisher.publishEvent(new InteractiveAuthenticationSuccessEvent(authResult, this.getClass()));
     }
     //4.调用认证成功处理器进行后置处理，successHandler可由开发者通过HttpSecurity的successHandler方法指定
     //注意：一旦使用了successHandler方法，则指定的successForwardUrl将失效。
     this.successHandler.onAuthenticationSuccess(request, response, authResult);
 }
```

认证失败处理函数如下：

```java
 protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                           AuthenticationException failed) throws IOException, ServletException {
     //1.清空安全上下文
     SecurityContextHolder.clearContext();
     this.logger.trace("Failed to process authentication request", failed);
     this.logger.trace("Cleared SecurityContextHolder");
     this.logger.trace("Handling authentication failure");
     this.rememberMeServices.loginFail(request, response);
     //2.调用认证失败处理器进行后置处理，failureHandler可由开发者通过HttpSecurity的方法failureHandler指定
     //注意：一旦使用了failureHandler方法，则指定的failureForwardUrl将失效
     //在failureHandler的onAuthenticationFailure方法中,可以获取到AuthenticationException实例，进而进行不同的后续处理
     this.failureHandler.onAuthenticationFailure(request, response, failed);
 }
```

我们再来看`UsernamePasswordAuthenticationFilter`类的认证过程

```java
 @Override
 public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
       throws AuthenticationException {
    if (this.postOnly && !request.getMethod().equals("POST")) {
       throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
    }
    String username = obtainUsername(request);
    username = (username != null) ? username.trim() : "";
    String password = obtainPassword(request);
    password = (password != null) ? password : "";
    UsernamePasswordAuthenticationToken authRequest = UsernamePasswordAuthenticationToken.unauthenticated(username,
          password);
    // Allow subclasses to set the "details" property
    setDetails(request, authRequest);
    //委托AuthenticationManager实例进行认证
    return this.getAuthenticationManager().authenticate(authRequest);
 }
```

`AuthenticationManager` 开发者可自行实现，暴露为 spring 的 Bean 即可，否则将使用 Spring Security 的内置默认实现。其默认实现为 ProviderManager，ProviderManager 持有一个由 `AuthenticationProvider` 构成的 List，每一个 `AuthenticationProvider` 都是一个认证器，可由外部提供，其默认的实现为 `DaoAuthenticationProvider` 类，`DaoAuthenticationProvider` 继承自 `AbstractUserDetailsAuthenticationProvider`（实现了 `AuthenticationProvider` 接口）。

`ProviderManager` 类关键代码如下：

```java
 @Override
 public Authentication authenticate(Authentication authentication) throws AuthenticationException {
     ...
     //遍历所有AuthenticationProvider进行认证，默认由DaoAuthenticationProvider来完成认证。
     for (AuthenticationProvider provider : getProviders()) {
         ...
         try {
             result = provider.authenticate(authentication);
             if (result != null) {
                 copyDetails(authentication, result);
                 break;
             }
         }
         catch (AccountStatusException | InternalAuthenticationServiceException ex) {
             prepareException(ex, authentication);
             // SEC-546: Avoid polling additional providers if auth failure is due to
             // invalid account status
             throw ex;
         }
         catch (AuthenticationException ex) {
             lastException = ex;
         }
     }
     ...
 }
```

`DaoAuthenticationProvider` 继承自 `AbstractUserDetailsAuthenticationProvider`，关键代码如下：

```java
 @Override
 public Authentication authenticate(Authentication authentication) throws AuthenticationException {
    ...
    String username = determineUsername(authentication);
    boolean cacheWasUsed = true;
    UserDetails user = this.userCache.getUserFromCache(username);
    if (user == null) {
       cacheWasUsed = false;
       try {
          //由子类DaoAuthenticationProvider获取UserDetail实例，子类又委托UserDetialService实现
          user = retrieveUser(username, (UsernamePasswordAuthenticationToken) authentication);
       }
       catch (UsernameNotFoundException ex) {
          this.logger.debug("Failed to find user '" + username + "'");
          if (!this.hideUserNotFoundExceptions) {
             throw ex;
          }
          throw new BadCredentialsException(this.messages
                .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
       }
       Assert.notNull(user, "retrieveUser returned null - a violation of the interface contract");
    }
    try {
       //初步检查UserDetail实例，比如是否过期，是否权限过期，是否锁定等。
       this.preAuthenticationChecks.check(user);
       //判断用户名和密码是否匹配，其过程由子类DaoAuthenticationProvider实现，子类通过PasswordEncoder进行匹配判断
       additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken) authentication);
    }
    catch (AuthenticationException ex) {
       if (!cacheWasUsed) {
          throw ex;
       }
       // There was a problem, so try again after checking
       // we're using latest data (i.e. not from the cache)
       cacheWasUsed = false;
       user = retrieveUser(username, (UsernamePasswordAuthenticationToken) authentication);
       this.preAuthenticationChecks.check(user);
       additionalAuthenticationChecks(user, (UsernamePasswordAuthenticationToken) authentication);
    }
    this.postAuthenticationChecks.check(user);
    if (!cacheWasUsed) {
       this.userCache.putUserInCache(user);
    }
    Object principalToReturn = user;
    if (this.forcePrincipalAsString) {
       principalToReturn = user.getUsername();
    }
    return createSuccessAuthentication(principalToReturn, authentication, user);
 }
```

子类 `DaoAuthenticationProvider` 的认证过程：

```java
 protected void additionalAuthenticationChecks(UserDetails userDetails,
       UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
    if (authentication.getCredentials() == null) {
       this.logger.debug("Failed to authenticate since no credentials provided");
       throw new BadCredentialsException(this.messages
             .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
    }
    //获取用户通过表单提交的密码
    String presentedPassword = authentication.getCredentials().toString();
    //通过密码验证器来验证从UserDetailService获取到的userDetail实例中的密码，与用户提交的密码是否匹配
    //此处的passwordEncoder可由开发者指定，暴露给spring，由spring容器管理即可。
    if (!this.passwordEncoder.matches(presentedPassword, userDetails.getPassword())) {
       this.logger.debug("Failed to authenticate since password does not match stored value");
       throw new BadCredentialsException(this.messages
             .getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
    }
 }
```

`UserDetailService`实例和`PasswordEncoder`是在`InitializeUserDetailsBeanManagerConfigurer`类中被设置的，此类会从spring上下文中获取对应的实现。

故自定义的`UserDetailService`和`PasswordEncoder`，只需开发者创建好之后，交由 spring 容器管理即可。

### **3、Spring Security 实现 Remeber Me 功能**

`俟补。`

### **4、Spring Security 实现 JWT 无状态认证**

`俟补。`

### **5、鉴权设计**

Spring Security 支持多种多样的鉴权方式，比如：

1. 在业务类的方法上添加注解，用以判断是否有权限调用。
2. 在模板引擎上使用 Spring Security 的标签库，用以判断是否有权限显示指定的 dom 元素，如 jsp 或 thymeleaf。
3. 判断用户是否有权限访问某个请求路径（推荐）。

按照权限分配是否支持动态调整，又可分为：

1. 静态权限控制：指将权限的校验以硬编码的方式写死到代码中，无法在程序运行期间动态更改。比如：在模板引擎中使用权限校验标记，在业务类方法上使用权限校验标记等等。
2. 半动态权限控制：将权限分配编写到配置文件上，通过更改配置文件，实现一定的动态权限控制能力。
3. 全动态权限控制：可在程序运行期间，完全动态的（自由的）对权限进行变更。

本文档，示范一种判断用户是否拥有权限访问某请求地址的方式，此种业务场景比较常见。优点是可以对任意请求地址进行鉴权，缺点是无法对业务方法、业务数据及视图层进行鉴权。

既然是对用户的请求进行鉴权，那么其实现的原理，自然是通过过滤器，拦截一切请求（白名单放行），然后通过一个鉴权管理器（AccessDecisionManager）来进行鉴权。

所有资源（即请求地址数据）、用户、角色、权限等均存储在数据库，可以进行动态配置，路径匹配使用 AntRequestMatcher，支持使用表达式。

参考配置类代码如下：

```java
/**
 * 适配spring security 6
 * 如果引入的是spring-boot-starter-security，则无需添加@EnableWebSecurity，会自动启用。
 * 如果是单纯引入spring-security，则需添加@EnableWebSecurity注解
 */
@Configuration
@EnableWebSecurity
public class MySS6Config {
    //自定义的全局启用SpringSecurity的开头
    @Value("${spring.security.enabled:true}")
    private boolean securityEnabled;

    /**
     * 构建Spring Security的内部过滤器链。
     * 返回用户信息的实现（UserDetailService的实现）定义在UserServiceImpl类中，并加入到spring容器
     * <p>
     * 注意：在Spring Security 6中，FilterSecurityInterceptor已被标注为过时，使用AuthorizationFilter替代，以下注释中，凡涉及到FilterSecurityInterceptor的，在Spring Security 6中，均已不存在，也不建议使用
     *
     * @param hs              HttpSecurity实例，用于构建Spring Security的内部过滤器链
     * @param securityService 用于获取权限元数据的业务接口
     * @return 内部过滤器链
     * @throws Exception 异常
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity hs, SecurityService securityService) throws Exception {
        if (!securityEnabled) {
            //如果不开启spring security，则不进行鉴权，全部放行
            return hs.authorizeHttpRequests().requestMatchers("/**").permitAll().and().build();
        }
        //一、禁用csrf
        //关闭csrf，默认是开启的，开启后会导致我们的登录被拦截，导致登录失败
        hs.csrf().disable().headers().frameOptions().disable();

        //二、认证表单相关配置。
        //认证过程主要依赖UsernamePasswordAuthenticationFilter实现，此过滤器调用formLogin之后就会被激活。如果想实现自定义认证，可参考此过滤器的实现。
        //其抽象父类AbstractAuthenticationProcessingFilter实现了通用业务逻辑，及成功、失败之后的处理，通过模板方法设计模式，调用子类的attemptAuthentication方法，而UsernamePasswordAuthenticationFilter的实现，就是组装登录表单数据(自定义的重要部分)，
        //然后调用父类注入的AuthenticationManager，实现最后的认证过程。而AuthenticationManager就是一个认证接口，开发者也可完全自定义。
        hs.formLogin()  //调用此方法就会激活UsernamePasswordAuthenticationFilter过滤器
                .loginPage("/login") //设置登录页地址，缺省为"/login"，如果想自定义的话，不管是否"/login"，都必须如此显式设置，如果不进行显式设置的话，则依然会跳转到内置的登录页
                //.usernameParameter("username") //设置用户名表单名称，缺省即为username
                //.passwordParameter("password") //设置密码表单名称，缺省即为password
                //.loginProcessingUrl("/login") //认证提交认证的地址，缺省即为"/login"，类型为post。注意：此请求无需开发者处理，而是用来设置在登录表单上的action属性上的，spring security会自动拦截进行认证处理

                .defaultSuccessUrl("/", false) //设置认证成功后默认的重定向地址，第二个参数表示是否始终重定向到此页面，如果不指定，可能会跳转到登录前的地址（若有）。如果在重写向过程中，地址出现了?continue字样，这是spring security的处理，是正常的
                //.successForwardUrl("/index") //认证成功后，转发到的地址，如果配置了此项，则defaultSuccessUrl失效
                //认证成功之后的自定义登录处理。注意：如果设置了successHandler，则defaultSuccessUrl和successForwardUrl会失效。本质上，设置defaultSuccessUrl或successForwardUrl最后也会包装成一个SuccessHandler
                //认证逻辑详见AbstractAuthenticationProcessingFilter类的doFilter方法
                //.successHandler((request, response, authentication) -> {})

                //.failureForwardUrl("/loginFailure") //认证失败后的转发地址，因为是登录校验之后转发，所以依然是post类型。注：可通过error请求参数获取错误信息
                .failureHandler((request, response, exception) -> {
                    request.getSession().setAttribute("exception", exception);
                    response.sendRedirect(request.getContextPath() + "/loginFailure");
                });//认证失败之后的处理。注意：如果设置了failureHandler，则failureForwardUrl将失效。详见AbstractAuthenticationFilterConfigurer类的failureUrl(String authenticationFailureUrl)方法

        //此permitAll()方法用于对开发者显式自定义的请求地址(仅包括loginPage、loginProcessingUrl、failureForwardUrl)进行忽略过滤
        //在spring security 5上，调用此方法就会在过滤器链中添加FilterSecurityInterceptor，所以此句注释是为了不再添加FilterSecurityInterceptor到SecurityFilterChain中，对于要放行的请求地址，可由开发者自行处理。
        //而在spring security 6中，FilterSecurityInterceptor已标注为过时(使用AuthorizationFilter)。调用此方法，则在后续步骤中，必须调用authorizeHttpRequests()方法，否则不会创建AuthorizationFilter，配置放行的白名单就无效了。
        //.permitAll();

        //三、白名单配置：
        //此句配置会创建一个过滤一切请求，但对指定白名单地址放行的AuthorizationFilter。由于我们要自定义鉴权过滤器，所以此句注释了。
        //hs.authorizeHttpRequests().requestMatchers("/loginFailure").permitAll();

        //四、鉴权配置：
        //在spring security 5中，调用permitAll方法或authorizeRequests方法，会在过滤器链中添加FilterSecurityInterceptor这个过滤器
        //在spring security 6中，调用authorizeHttpRequests方法，会在过滤器中添加AuthorizationFilter，调用permitAll不再自动添加过滤器，需要用户手动配置，如果未配置，会报异常

        //以下示例配置用以配置一个过滤一切请求，但只需通过认证即可AuthorizationFilter
        /*hs
                //.userDetailsService() //由开发者指定UserDetailService实例(用于获取指定用户名的用户实体)，也可创建为Spring的Bean，spring security会自动注入
                //.authenticationManager() //由开发者指定AuthenticateManager实例，也可建为Spring的Bean，spring security会自动注入
                .authorizeHttpRequests(customizer -> customizer.anyRequest().authenticated() //表示任意请求路径都需要先通过认证
                );*/


        //通过securityService获取所有权限元数据，返回一个Map实例，键为uri，值为访问此uri所需要的权限。注意：uri支持使用ant pattern。
        Map<String, Collection<ConfigAttribute>> configAttributeMap = securityService.findAllSecurityAuthorities();
        //权限元数据，在spring security 6中，SecurityMetadataSource已不是一个必须组件。
        SecurityMetadataSource securityMetadataSource = new MySS6MetadataSource(configAttributeMap);

        //自定义基于请求路径的鉴权管理器
        AuthorizationManager<HttpServletRequest> authorizationManager = new MySS6AuthorizationManager(securityMetadataSource);

        //不进行权限过滤，直接放行的白名单。此白名单的不足是，并未对请求方法(get/post/delete/patch/put)进行判定
        Set<String> ignoreUrls = Set.of("/login/**", "/logout/**", "/loginFailure/**", "/authorizeFailure/**");
        //此过滤器不能作为bean，暴露给spring容器，否则下方代码又再次将过滤器加入到spring security的内部过滤器链，就会造成同一个过滤器被加入两次的情况
        MySS6Filter filter = new MySS6Filter(authorizationManager, ignoreUrls);

        //五、添加自定义过滤器。有三种添加方式：
        //addFilterBefore：表示在某个目标过滤器之前添加
        //addFilterAfter：表示在某个目标过滤器之后添加
        //addFilterAt：表示在某个目标过滤器的位置添加，添加之后，两个过滤器拥有相同的顺序值。注意：此操作并不会覆盖目标过滤器。
        //addFilter：要求参数必须是内置过滤器的实现类或子类，根据其类型（继承类型），自动查询其顺序值，然后添加到过滤器链中，不会覆盖原过滤器

        //重点：此处的MySS6Filter实例并没有创建为Spring的Bean，原因是如果创建为Spring的Bean，则会被Spring自动添加到过滤器链中，同时又使用addFilter，会出现添加两个重复的过滤器，进而出现一个url被过滤两次的情况
        //重点：MySS6Filter功能与FilterSecurityInterceptor(AuthorizationFilter)的功能是类似而相斥的，不应同时存在，否则会出现同一个url被执行重复业务操作的情况（如鉴权两次）
        hs.addFilter(filter).exceptionHandling()
                //.accessDeniedHandler((request, response, accessDeniedException) -> {}) //自定义AccessDeniedHandler，有更大的灵活性和自由性
                .accessDeniedPage("/authorizeFailure"); //指定鉴权失败后的转发页面，否则将默认转发到"/error"，并响应一个403状态码
        return hs.build();
    }

    /**
     * 密码加密器，必须配置，有多个内置实现，开发者也可自定义实现
     * 在DaoAuthenticationProvider类中的additionalAuthenticationChecks方法中会用到，用以进行密码校验
     *
     * @return 密码加密器实例
     */
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
```

其中，使用 HttpSecurity 添加自定义过滤器有三种方式：

+ addFilterBefore：表示在某个目标过滤器之前添加
+ addFilterAfter：表示在某个目标过滤器之后添加
+ addFilterAt：表示在某个目标过滤器的位置添加，添加之后，两个过滤器拥有相同的顺序值。注意：此操作并不会覆盖目标过滤器。
+ addFilter：要求参数必须是内置过滤器的实现类或子类，根据其类型，自动找出其顺序值，然后添加到过滤器链中，不会覆盖原过滤器

在配置类中自定义过滤器参考代码如下（注意：本类没有创建为 Spring 的 Bean，防止过滤器被添加两次）：

```java
/**
 * @author snow1k
 * @version 1.0.0
 * <p>
 * <p>
 * 动态权限过滤器，用于实现基于路径的动态权限过滤。
 * <p>
 * created by snow1k on 2023-05-04
 */
public class MySS6Filter extends AuthorizationFilter {
    private final Collection<String> ignoreUrls;//支持ant路径匹配

    public MySS6Filter(AuthorizationManager<HttpServletRequest> authorizationManager) {
        this(authorizationManager, null);
    }

    public MySS6Filter(AuthorizationManager<HttpServletRequest> authorizationManager, Collection<String> ignoreUrls) {
        super(authorizationManager);
        this.ignoreUrls = ignoreUrls;
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;

        //若有白名单，则直接放行，不进行权限过滤
        if (this.ignoreUrls != null) {
            for (String ignoreUrl : this.ignoreUrls) {
                RequestMatcher matcher = AntPathRequestMatcher.antMatcher(ignoreUrl);
                if (matcher.matches(request)) {
                    filterChain.doFilter(servletRequest, servletResponse);
                    return;
                }
            }
        }

        super.doFilter(servletRequest, servletResponse, filterChain);
    }
}
```

调用父类 `AuthorizationFilter` 的 doFilter 方法。

```java
HttpServletRequest request = (HttpServletRequest) servletRequest;
HttpServletResponse response = (HttpServletResponse) servletResponse;

if (this.observeOncePerRequest && isApplied(request)) {
    chain.doFilter(request, response);
    return;
}

if (skipDispatch(request)) {
    chain.doFilter(request, response);
    return;
}

String alreadyFilteredAttributeName = getAlreadyFilteredAttributeName();
request.setAttribute(alreadyFilteredAttributeName, Boolean.TRUE);
try {
    //此处进行权限检查，判断是否拥有访问request的权限，authoritionManager是MySS6Filter类中注入的
    AuthorizationDecision decision = this.authorizationManager.check(this::getAuthentication, request);
    this.eventPublisher.publishAuthorizationEvent(this::getAuthentication, request, decision);
    if (decision != null && !decision.isGranted()) {
       throw new AccessDeniedException("Access Denied");
    }
    chain.doFilter(request, response);
}
finally {
    request.removeAttribute(alreadyFilteredAttributeName);
}
```

下面看看自定义的 `MySS6AuthorizationManager` 实现（注意：在 Spring Security 6 中，AccessDecisionManager 已被标注为过时，使用 AuthorizationManager 替代）：

```java
/**
 * 鉴权管理器，用于判断是否有权限访问指定的目标对象
 *
 * @author sno1k
 * @version 1.0.0
 * <p>
 * created by snow1k on 2023-05-04
 */
public record MySS6AuthorizationManager(
        SecurityMetadataSource securityMetadataSource) implements AuthorizationManager<HttpServletRequest> {

    @Override
    public AuthorizationDecision check(Supplier<Authentication> authentication, HttpServletRequest request) {
        Authentication au = authentication.get();
        if (au == null || !au.isAuthenticated()) {
            return new AuthorizationDecision(false);
        }

        boolean granted = false;
        //字符串格式的权限集合
        Collection<String> needed = getNeededAuthorities(request).stream().map(ConfigAttribute::getAttribute).collect(Collectors.toSet());

        //以下代码也可换成lambda表达式
        for (GrantedAuthority grantedAuthority : au.getAuthorities()) {
            if (needed.contains(grantedAuthority.getAuthority())) {
                granted = true;
                break;
            }
        }
        return new AuthorityAuthorizationDecision(granted,
                au.getAuthorities().stream().map(t -> (GrantedAuthority) t).collect(Collectors.toSet()));
    }

    /**
     * 获取访问指定请求路径所需要的权限
     */
    private Collection<ConfigAttribute> getNeededAuthorities(HttpServletRequest request) {
        //注意：在spring security 6中，SecurityMetadataSource已不是一个必须组件
        return this.securityMetadataSource.getAttributes(request);
    }
}
```

此类逻辑比较简单，其中方法 getNeededAuthorities 的返回值，即访问目标资源（request）所需要的权限，这是一个集合，认证用户拥有此集合中的任意一项权限即可认为拥有访问此路径的权限。当然用户拥有的权限也是一个集合，通过 **authentication.getAuthorities()** 获取。

configAttributes 由 `SecurityMeatadataSource` 实例获取，这是一个接口，可由开发者在外部自行创建。

权限元数据参考代码如下：

```java
/**
 * 权限元数据。注意：在spring security 6中，SecurityMetadataSource已不是一个必须组件，开发才可使用自己的方式获取权限元数据
 *
 */
public class MySS6MetadataSource implements SecurityMetadataSource {
    /**
     * 存储所有路径对应的所有权限集合，key为路径模式，值为所需要的权限集合
     */
    private Map<String, Collection<ConfigAttribute>> configAttributeMap = null;

    public MySS6MetadataSource(Map<String, Collection<ConfigAttribute>> configAttributeMap) {
        this.setConfigAttributeMap(configAttributeMap);
    }

    public void setConfigAttributeMap(Map<String, Collection<ConfigAttribute>> configAttributeMap) {
        this.configAttributeMap = configAttributeMap;
    }

    /**
     * 返回访问目标资源所需要的权限集合
     *
     * @param object 访问目标资源，FilterInvocation类型
     * @return 访问目标资源object所需要的权限
     * @throws IllegalArgumentException 非法参数异常
     */
    @Override
    public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
        Set<ConfigAttribute> configAttributes = new HashSet<>();

        //获取当前访问的路径
        HttpServletRequest request = (HttpServletRequest) object;

        //获取访问该路径所需资源，从configAttributeMap获取
        for (String pattern : configAttributeMap.keySet()) {
            RequestMatcher matcher = AntPathRequestMatcher.antMatcher(pattern);

            if (matcher.matches(request)) {
                configAttributes.addAll(configAttributeMap.get(pattern));
            }
        }
        // 未设置操作请求权限，返回空集合
        return configAttributes;
    }

    /**
     * 返回所有权限集合
     *
     * @return 权限集合
     */
    @Override
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        /*
        Set<ConfigAttribute> allAttributes = new HashSet<>();
        this.configAttributeMap.values().forEach(allAttributes::addAll);
        return allAttributes;
        */

        return this.configAttributeMap.values().stream().flatMap(Collection::stream).collect(Collectors.toSet());
    }

    /**
     *
     */
    @Override
    public boolean supports(Class<?> clazz) {
        return HttpServletRequest.class.isAssignableFrom(clazz);
    }
}
```

下面我们再看看当出现非法权限访问异常的时候，异常会被过滤器链中的 `ExceptionTranslationFilter` 捕获并进行处理：

```java
private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
      throws IOException, ServletException {
   try {
      chain.doFilter(request, response);
   }
   catch (IOException ex) {
      throw ex;
   }
   catch (Exception ex) {
      // Try to extract a SpringSecurityException from the stacktrace
      Throwable[] causeChain = this.throwableAnalyzer.determineCauseChain(ex);
      RuntimeException securityException = (AuthenticationException) this.throwableAnalyzer
            .getFirstThrowableOfType(AuthenticationException.class, causeChain);
      if (securityException == null) {
         securityException = (AccessDeniedException) this.throwableAnalyzer
               .getFirstThrowableOfType(AccessDeniedException.class, causeChain);
      }
      if (securityException == null) {
         rethrow(ex);
      }
      if (response.isCommitted()) {
         throw new ServletException("Unable to handle the Spring Security Exception "
               + "because the response is already committed.", ex);
      }
      //处理spring security的异常
      handleSpringSecurityException(request, response, chain, securityException);
   }
}
```

跳转到下面这个方法：

```java
 private void handleSpringSecurityException(HttpServletRequest request, HttpServletResponse response,
       FilterChain chain, RuntimeException exception) throws IOException, ServletException {
    if (exception instanceof AuthenticationException) {//如果是认证异常，下面处理
       handleAuthenticationException(request, response, chain, (AuthenticationException) exception);
    }
    else if (exception instanceof AccessDeniedException) {//如果是鉴权异常，下面处理
       //鉴权失败，跳转到下面这个方法
       handleAccessDeniedException(request, response, chain, (AccessDeniedException) exception);
    }
 }
```

再跳转到下面这个方法：

```java
 private void handleAccessDeniedException(HttpServletRequest request, HttpServletResponse response,
       FilterChain chain, AccessDeniedException exception) throws ServletException, IOException {
    //获取认证对象
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    //判断是否匿名用户
    boolean isAnonymous = this.authenticationTrustResolver.isAnonymous(authentication);
    if (isAnonymous || this.authenticationTrustResolver.isRememberMe(authentication)) {
       //...
       //如果是匿名用户，则开始进入认证过程，然后跳转到登录页面
       sendStartAuthentication(request, response, chain,
             new InsufficientAuthenticationException(
                   this.messages.getMessage("ExceptionTranslationFilter.insufficientAuthentication",
                         "Full authentication is required to access this resource")));
    }
    else {
       if (logger.isTraceEnabled()) {
          logger.trace(
                LogMessage.format("Sending %s to access denied handler since access is denied", authentication),
                exception);
       }
       //如果不是匿名用户，则由AccessDeniedHandler处理鉴权异常，AccessDeniedHandler可由外部开发者实现，默认的内置实现是AccessDeniedHandlerImpl，此实现是转发到/error，就响应一个403 Forbidden状态
       this.accessDeniedHandler.handle(request, response, exception);
    }
 }
```

如果是匿名用户，则跳转到这个方法：

```java
 protected void sendStartAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
       AuthenticationException reason) throws ServletException, IOException {
    SecurityContext context = SecurityContextHolder.createEmptyContext();
    SecurityContextHolder.setContext(context);
    this.requestCache.saveRequest(request, response);
    //由AuthenticationEntryPoint实例进行处理，此实例可由开发者外部定义，默认内部实现为LoginUrlAuthenticationEntryPoint
    this.authenticationEntryPoint.commence(request, response, reason);
 }
```

进入 `LoginUrlAuthenticationEntryPoint` 的 commence 方法：

```java
 @Override
 public void commence(HttpServletRequest request, HttpServletResponse response,
       AuthenticationException authException) throws IOException, ServletException {
    if (!this.useForward) {//如果不转发
       //获取重定向地址，即认证地址
       String redirectUrl = buildRedirectUrlToLoginPage(request, response, authException);
       //重定向到用户认证地址
       this.redirectStrategy.sendRedirect(request, response, redirectUrl);
       return;
    }
    String redirectUrl = null;
    if (this.forceHttps && "http".equals(request.getScheme())) {
       // First redirect the current request to HTTPS. When that request is received,
       // the forward to the login page will be used.
       redirectUrl = buildHttpsRedirectUrlForRequest(request);
    }
    if (redirectUrl != null) {
       this.redirectStrategy.sendRedirect(request, response, redirectUrl);
       return;
    }
    String loginForm = determineUrlToUseForThisRequest(request, response, authException);
    logger.debug(LogMessage.format("Server side forward to: %s", loginForm));
    RequestDispatcher dispatcher = request.getRequestDispatcher(loginForm);
    dispatcher.forward(request, response);
    return;
 }
```

如果是鉴权失败，也就是无权访问，则将由 AccessDeniedHandler 实例处理异常，此实例可由开发者提供外部实现，默认的内置实现是 `AccessDeniedHandlerImpl`，其逻辑是转发请求到 `/error`，且响应一个 403 状态码（Forbidden）。`AccessDeniedHandler` 实例可在 `ExceptionTranslationFilter` 过滤器中通过 `setAccessDeniedHandler` 方法设置。

### **6、在接口或业务方法上进行静态鉴权控制**

`俟补。`

### **7、Spring Security 在 jsp 上实现视图权限**

`俟补。`

### **8、Spring Security 在 thymeleaf 上实现视图权限**

`俟补。`

---

