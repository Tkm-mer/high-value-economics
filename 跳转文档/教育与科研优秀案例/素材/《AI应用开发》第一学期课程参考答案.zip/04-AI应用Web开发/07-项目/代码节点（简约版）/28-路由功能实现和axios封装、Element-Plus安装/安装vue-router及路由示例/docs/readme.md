1. 安装 vue-router。

```bash
pnpm install vue-router
```



2. 配置 src 别名。

```javascript
import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {resolve} from 'path'

// https://vite.dev/config/
export default defineConfig({
    plugins: [vue()],
    server: {
        host: "localhost",
        port: 3000,
        open: true
    },
    resolve: {
        alias: {
            "@": resolve(import.meta.dirname, "src")
        }
    }
})
```

3. src/router/index.js 内容。

```javascript
import {createRouter, createWebHashHistory} from 'vue-router'

const routes = [
    {
        name: 'login',
        path: '/login',
        component: () => import('@/views/Login.vue'),
    },
    {
        name: 'main',
        path: '/main',
        component: () => import('@/views/Main.vue'),
    },
    {
        name: 'member',
        path: '/member',
        component: () => import('@/views/Member.vue'),
    },
    {
        name: 'index',
        path: '/',
        redirect: '/main'
    }
]

const router = createRouter({
    routes,
    history: createWebHashHistory()
})

export default router
```

