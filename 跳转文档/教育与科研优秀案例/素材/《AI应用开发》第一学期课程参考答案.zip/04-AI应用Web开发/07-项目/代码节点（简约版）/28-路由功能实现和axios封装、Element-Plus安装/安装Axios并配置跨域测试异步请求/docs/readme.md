### 配置跨域

1. 在 Spring Boot 的控制器上添加注解，仅支持单个控制器。

```java
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
@RestController
@RequestMapping(value = "/api/members", produces = MediaType.APPLICATION_JSON_VALUE)
public class MemberApi {
    //pass
}
```


2. 创建配置类 CorsConfig，集中配置。

```java
@Configuration
public class CorsConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // 1. 允许所有路径
                .allowedOriginPatterns("*") // 2. 允许的来源（注意与上文的区别）
                .allowedMethods("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS") // 3. 允许的HTTP方法
                .allowedHeaders("*") // 4. 允许的请求头
                .allowCredentials(true) // 5. 允许携带凭证（Cookie）
                .maxAge(3600); // 6. 预检请求缓存时间（秒）
    }
}
```


3. 如果项目中使用 Spring Security 框架，还要做如下配置。

```java
@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(request -> {
                CorsConfiguration config = new CorsConfiguration();
                config.setAllowedOriginPatterns(Arrays.asList("*"));
                config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
                config.setAllowedHeaders(Arrays.asList("*"));
                config.setAllowCredentials(true);
                config.setMaxAge(3600L);
                return config;
            }))
            // ... 其他安全配置
        return http.build();
    }
}
```

4. 在前端 vite.config.js 配置反向代理：

```javascript
import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'
import {resolve} from 'path'

// https://vite.dev/config/
export default defineConfig({
    plugins: [vue()],
    server: {
        host: "localhost",
        port: 3000,
        open: true,
        // 配置代理，解决跨域问题，仅限于开发模式下，生产环境需要在nginx中配置
        proxy: {
            "/api": {
                target: "http://localhost:8080",
                changeOrigin: true,
                //rewrite: url => url.replace(/^\/api/, "/api/v1")
            }
        }
    },
    resolve: {
        alias: {
            "@": resolve(import.meta.dirname, "src")
        }
    }
})
```

5. 编写 axios 请求。

```javascript
function useCallback() {
  axios.get('/api/members?pageNo=1&pageSize=10').then(resp => {
    console.log(resp.data);
  });
}


async function useAwait() {
  let resp = await axios.get('/api/members?pageNo=1&pageSize=10');
  console.log(resp.data);
}
```

