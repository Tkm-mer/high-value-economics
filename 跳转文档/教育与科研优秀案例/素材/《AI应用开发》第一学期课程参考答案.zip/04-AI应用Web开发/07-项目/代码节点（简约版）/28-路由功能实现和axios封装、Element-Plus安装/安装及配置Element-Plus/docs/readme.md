

安装依赖：

```bash
pnpm install element-plus
pnpm install @element-plus/icons-vue
```



在 main.js 中配置 Element-Plus 组件。

```javascript
import {createApp} from 'vue'
import '@/style.css'
import App from '@/App.vue'
import router from '@/router'

// 导入ElementPlus
import ElementPlus from 'element-plus'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import 'element-plus/dist/index.css'

const app = createApp(App)

app.use(router)

// 使用ElementPlus，并配置国际化  
app.use(ElementPlus, {
    locale: zhCn
});

app.mount('#app')
```





