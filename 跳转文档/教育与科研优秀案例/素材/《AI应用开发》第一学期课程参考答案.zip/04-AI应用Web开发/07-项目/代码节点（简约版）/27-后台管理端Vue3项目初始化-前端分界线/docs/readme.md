



1. 安装 Node.js。
2. 安装 pnpm。使用指令：`npm install -g pnpm@latest`

3. 创建 Vite 项目。

```bash
pnpm create vite@latest insoul2026-web

#配置淘宝镜像站
pnpm config set registry https://registry.npmmirror.com
```

<img src="./assets/image-20260812230832417.png" alt="image-20260812230832417" style="zoom:67%;" />

<img src="./assets/image-20260812231003270.png" alt="image-20260812231003270" style="zoom:67%;" />

<img src="./assets/image-20260812231043872.png" alt="image-20260812231043872" style="zoom:67%;" />

4. 在浏览器中访问 http://localhost:5173，即可看到如下页面。

<img src="./assets/image-20260812231135955.png" alt="image-20260812231135955" style="zoom:67%;" />

5. 创建的 Vue 3 项目目录结构如下。

<img src="./assets/image-20260812231439138.png" alt="image-20260812231439138" style="zoom:67%;" />

5. 使用 idea 打开 Vue 3 项目。

6. 配置 vite.config.js。

```javascript
import {defineConfig} from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vite.dev/config/
export default defineConfig({
    plugins: [vue()],
    server: {
        host: "localhost",
        port: 3000,
        open: true
    }
})

```



