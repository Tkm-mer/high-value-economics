# Excel 导入与导出

历史渊源：

- **EasyExcel 停更（背景）**：由于原作者的离职，阿里巴巴官方宣布停止维护 EasyExcel。其 GitHub 仓库已于 2025 年 9 月 4 日归档，进入只读状态。
- **FastExcel 诞生（过渡）**：为继续维护和升级项目，原 EasyExcel 作者（jipengfei, Jiaju Zhuang）于 2024 年底创建了新项目 FastExcel。它完全兼容 EasyExcel，只需更换包名和依赖即可无缝升级。从 2024 年 12 月到 2025 年 8 月，FastExcel 陆续发布了 1.0.0 到 1.3.0 等数个稳定版本。
- **FastExcel 捐赠与更名（现状）**：2025 年 9 月 17 日，FastExcel 项目被正式捐赠给 Apache 软件基金会，成为其孵化项目，并更名为 **Apache Fesod (Incubating)**。“Fesod”是“Fast Easy Spreadsheet and Other Documents”的缩写。



1. 在 pom.xml 文件中引入依赖。

```xml
<!--easy-excel的更名版-->
<!-- https://mvnrepository.com/artifact/cn.idev.excel/fastexcel -->
<dependency>
    <groupId>cn.idev.excel</groupId>
    <artifactId>fastexcel</artifactId>
    <version>1.3.0</version>
</dependency>
```



2. 模型类添加注解。

```java
@Getter
@Setter
@ToString(callSuper = true)
public class Member extends AuditEntity {
    @ExcelProperty("编号")
    private Integer id;//主键

    @ExcelProperty("用户名")
    private String username;//账号

    //密码为null或空串，则不进行修改
    @ExcelIgnore
    private String password;//密码

    @ExcelProperty("姓名")
    private String name;//姓名

    @ExcelProperty("姓名拼音")
    private String pinyin;

    @ExcelProperty("性别")
    private String sex;//性别

    @ExcelProperty("出生日期")
    private LocalDate birthday;

    @ExcelProperty("手机号")
    private String phone;//手机号

    @ExcelProperty("微信")
    private String wechat;

    @ExcelProperty("邮箱")
    private String email;

    @ExcelProperty("qq")
    private String qq;

    @ExcelProperty("身份证号")
    private String cardId;

    @ExcelProperty("备注")
    private String description;

    //头像
    @ExcelIgnore
    private String avatar;

    @ExcelIgnore
    private Boolean isDel;
}
```



3. 编写导出逻辑。

```java
//导出会员到excel
//excel导出库https://github.com/fast-excel/fastexcel
@PostMapping(value = "/export", produces = "application/vnd.ms-excel")
public void export(@RequestParam(defaultValue = "1") Integer page,
                   @RequestParam(defaultValue = "-1") Integer limit,
                   MemberSearchBean msb, HttpServletResponse resp) throws Exception {
    //查询会员
    Page<Member> p = new Page<>(page, limit);
    p = memberService.findAll(p, msb);
    //会员列表
    List<Member> members = p.getRecords();

    LocalDateTime now = LocalDateTime.now();
    String fileName = "会员信息表-" + now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
    // 这里URLEncoder.encode可以防止中文乱码 当然这和easy-excel没有关系
    fileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8).replaceAll("\\+", "%20");
    resp.setHeader("Content-Disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

    //handler为要排除的属性，此属性比较特殊，并不是直接定义在Member这个类中，而是定义在Member的动态代理子类之中（由MyBatis通过Javassist创建），
    //EasyExcel并不能从Member这个类中探测到这个字段，所以依旧会进行转换并导出，此处手动将此属性排除
    //对于原生使用Member类型，未创建动态代理类型的则无需考虑上述问题
    List<String> excludeProperties = List.of("handler");

    //链式操作，既可以通过白名单设置要包含的列（仅导出包含列），也可以通过黑名单设置要排除的列（除排除列全部导出）。
    //此处配置的白名单列和黑名单列，会覆盖模型类中的注解定义（优先级比注解定义高），如：@ExcelProperty和@ExcelIgnore。
    //registerConverter表示全局适用，而写在属性的注解中，表示仅所属注解适用
    FastExcel.write(resp.getOutputStream(), Member.class)
        .excludeColumnFieldNames(excludeProperties).sheet("会员信息表")
        .doWrite(members);
}
```

4. 编写导入逻辑。

```java
/**
     * 从excel文件中导入会员数据
     *
     * @param file 会员模板文件
     */
@PostMapping("import")
public ResponseEntity<JsonResult> importFromExcel(MultipartFile file) throws Exception {
    InputStream is = file.getInputStream();
    UploadListener listener = new UploadListener(memberService);

    FastExcel.read(is, Member.class, listener).sheet().doRead();

    return ResponseEntity.ok(JsonResult.success(listener.count()));
}

//excel上传监听器
private static class UploadListener implements ReadListener<Member> {
    private final List<Member> members = new ArrayList<>();
    private final MemberService memberService;

    public UploadListener(MemberService memberService) {
        this.memberService = memberService;
    }

    @Override
    public void invoke(Member member, AnalysisContext analysisContext) {
        members.add(member);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        for (Member member : members) {
            member.setId(null);//保存时不应有id
        }
        this.memberService.batchSave(members);
    }

    public int count() {
        return members.size();
    }
}
```

5. 编写业务类代码。

```java
@Transactional(rollbackFor = Exception.class)
@Override
public int batchSave(List<Member> members) {
    int count = 0;
    for (Member member : members) {
        //此处需要使用代理，如果不使用代理，无法触发aop，不会自动添加审计字段
        boolean success = self().save(member);
        if (success) {
            count++;
        }
    }
    return count;
}

private MemberService self() {
    return (MemberService) AopContext.currentProxy();
}
```



---



