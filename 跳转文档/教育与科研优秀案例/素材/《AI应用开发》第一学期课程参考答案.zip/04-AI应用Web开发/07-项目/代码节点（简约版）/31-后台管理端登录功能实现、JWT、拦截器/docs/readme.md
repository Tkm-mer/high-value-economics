# 实现登录界面及 jwt 身份认证

## 一、实现验证码显示

1. 引入依赖。

```xml
<!--验证码生成-->
<!-- Source: https://mvnrepository.com/artifact/com.github.whvcse/easy-captcha -->
<dependency>
    <groupId>com.github.whvcse</groupId>
    <artifactId>easy-captcha</artifactId>
    <version>1.6.2</version>
    <scope>compile</scope>
</dependency>
```

2. 在控制器中编写生成验证码的代码。

```java
//获取验证码
@GetMapping(value = "/captcha", produces = MediaType.IMAGE_GIF_VALUE)
public void captcha(String id, HttpServletResponse resp) throws IOException {
    SpecCaptcha captcha = new SpecCaptcha(110, 45, 5);

    //将验证码存储到redis中
    this.redisTemplate.opsForValue().set("captcha-" + id,
            captcha.text().toLowerCase(), Duration.ofMinutes(2));

    resp.setContentType("image/gif");
    resp.setHeader("Pragma", "No-cache");
    resp.setHeader("Cache-Control", "no-cache");
    resp.setDateHeader("Expires", 0);
    captcha.out(resp.getOutputStream());
}
```

> 注：前端需传递 id，用于区分不同会话的验证码。另外，验证码答案存储在 Redis 中。

3. 前端使用 img 标记，使用 src 属性发请求即可。

## 二、登录并颁发 JWT

1. 引入依赖。

```xml
<!--jwt生成和解密-->
<!-- Source: https://mvnrepository.com/artifact/com.auth0/java-jwt -->
<dependency>
    <groupId>com.auth0</groupId>
    <artifactId>java-jwt</artifactId>
    <version>4.6.0</version>
</dependency>

<!--加密解密库-->
<!-- Source: https://mvnrepository.com/artifact/org.jasypt/jasypt -->
<dependency>
    <groupId>org.jasypt</groupId>
    <artifactId>jasypt</artifactId>
    <version>1.9.3</version>
    <scope>compile</scope>
</dependency>
```

2. 编写登录逻辑。

```java
//提交登录
@PostMapping("/login")
public JsonResult login(@Validated @RequestBody AccountDto account, HttpServletResponse resp) {
    var answer = this.redisTemplate.opsForValue().get("captcha-" + account.getCaptchaId());
    if (!account.getCaptchaAnswer().equals(answer)) {
        return JsonResult.fail(400, "验证码不正确");
    }

    UserEntity dbUser = this.userService.findByUsername(account.getUsername());

    if (dbUser == null) {
        return JsonResult.fail(404, "用户名不存在");
    }

    if (!PE.checkPassword(account.getPassword(), dbUser.getPassword())) {
        return JsonResult.fail(500, "密码不正确");
    }

    //颁发jwt
    String jwt = WebAppUtils.buildJwt(dbUser, Map.of(),
            Instant.now().plus(30, ChronoUnit.MINUTES), jwtSecret);

    resp.setHeader("jwt", jwt);

    return JsonResult.success(jwt);
}
```

3. 创建 JWT 的逻辑。

```java
//构建jwt
public static String buildJwt(UserEntity ue, Map<String, Object> payload,
                              Instant expired, String secret) {
    JWTCreator.Builder builder = JWT.create();

    builder.withIssuedAt(Instant.now())
            .withExpiresAt(expired)
            .withAudience("https://api.qdsitu.com")
            .withSubject(ue.getUsername());
    if (payload != null && !payload.isEmpty()) {
        builder.withPayload(payload);
    }
    return builder.sign(Algorithm.HMAC256(secret));
}
```

## 三、存储 JWT 并在请求时携带 JWT

1. 编写 JWT 的存储和获取方法。

```javascript
UserApi.setJwt = function (jwt) {
    sessionStorage.setItem(jwtKey, jwt);
};

UserApi.getJwt = function () {
    return sessionStorage.getItem(jwtKey);
}

UserApi.removeJwt = function () {
    sessionStorage.removeItem(jwtKey);
}
```

2. 编写 Axios 响应拦截器。

```javascript
api.interceptors.response.use(resp => {
    let jwt = resp.headers["jwt"];
    if (jwt) {
        UserApi.setJwt(jwt);
    }

    return resp.data;
}, error => {
    let resp = error.response;

    if (resp.status === 401) {
        return {
            code: 401,
            success: false,
            msg: "尚未认证，请先登录"
        }
    }

    return {
        code: 500,
        success: false,
        msg: "服务器异常，请稍候再试"
    }
});
```

3. 编写 Axios 请求拦截器。

```javascript
api.interceptors.request.use(config => {
    let jwt = UserApi.getJwt();
    if (jwt) {
        config.headers["Authorization"] = "Bearer " + jwt;
    }
    return config;
}, error => {
    return Promise.reject(error);
});
```

4. 编写后端请求拦截器，进行 JWT 认证。

```java
@Slf4j
@Component
public class AuthorizationInterceptor implements HandlerInterceptor {
    @Value("${my.jwt.secret}")
    private String jwtSecret;

    @Override
    public boolean preHandle(@NonNull HttpServletRequest req, @NonNull HttpServletResponse resp, @NonNull Object handler) throws Exception {
        String jwt = req.getHeader("Authorization");
        if (jwt == null || jwt.isBlank()) {
            jwt = req.getParameter("jwt");
        } else {
            jwt = jwt.replaceFirst("Bearer ", "");
        }
        if (jwt == null || jwt.isBlank()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return false;
        }

        try {
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256(jwtSecret)).build();
            DecodedJWT dj = verifier.verify(jwt);
            String username = dj.getSubject();

            UserEntity ue = new UserEntity();
            ue.setUsername(username);
            WebAppUtils.setCurrentUser(ue);

            return true;
        } catch (Exception e) {
            log.error("解析jwt失败", e);
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return false;
        }
    }
}

```

5. 配置请求拦截器。

```java
@Configuration
public class CommonConfig implements WebMvcConfigurer {
    private AuthorizationInterceptor authorizationInterceptor;

    @Autowired
    public void setAuthorizationInterceptor(AuthorizationInterceptor authorizationInterceptor) {
        this.authorizationInterceptor = authorizationInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(authorizationInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/users/captcha", "/api/users/login");

    }
}

```

