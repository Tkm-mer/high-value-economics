# 《AI 应用 Web 开发》 - 教师教案（Day16：Docker 入门 + Dockerfile 镜像构建）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day15 的学生（掌握 Spring Boot 4.0.x 后端全链路、Vue 3 + Vite 前端全部页面、`pnpm build` 打包、Ubuntu 22.04 服务器 SSH 登录、Nginx 反代 + systemd 托管 Jar、`deploy.sh` 一键部署）**
**知识点覆盖：** 第 31 章 Docker 常见命令、操作示例与数据卷（容器 / 镜像概念、`pull` / `run` / `exec` / `logs` / `rm` / `rmi`、`-p` / `-v` / `-e` 三大参数、bind mount vs named volume、`docker network`）+ 第 32 章 Dockerfile 语法与自定义镜像（`FROM` / `COPY` / `RUN` / `CMD` / `EXPOSE` / `ENV` / `WORKDIR` / `ENTRYPOINT`、`.dockerignore`、分层缓存、多阶段构建、Spring Boot + JDK 25 后端镜像、Vue + Nginx 前端镜像、镜像大小优化）。

**技术版本基线**：Docker 24.0+ / Docker Compose v2 / OpenJDK 25 / Spring Boot 4.0.x / Node 20 LTS / pnpm 9 / Vue 3.5+ / Vite 5.4+ / Nginx 1.27-alpine / MySQL 8 / Redis 8-alpine / Ubuntu 22.04 LTS。

**Day16 主线**：Day15 我们把印想瑜伽会馆客户管理系统（`yoga-member`）用「手工 apt 装 JDK / MySQL / Nginx + systemd + `deploy.sh` scp jar」的方式搬上了 Ubuntu 22.04 服务器——链路能跑，但**换个服务器就得重新装一次**，**JDK 版本一升级 systemd 就崩**，**MySQL 数据一升级就要备份还原**。今天 6 课时给这最后一公里换个「工业化交付」的姿势：前 3 个课时把 Docker 的「壳」讲透——什么是镜像、什么是容器、`docker run` 一条命令跑起 MySQL / Redis / Nginx 等一线中间件，`-p` / `-v` / `-e` 三大参数把「端口 / 数据 / 配置」外置；中间 1 个课时把 Dockerfile 从零讲到会写；后 2 个课时用多阶段构建把 `yoga-server`（Spring Boot + JDK 25 jar）和 `yoga-web`（Vue + Vite dist）都打成体积可控的镜像，为 Day17 用 `docker compose` 一次拉起整个技术栈铺路。Day16 结束后学生的项目从此**可复制、可回滚、可跨机迁移**。

---

## 第 1 课时：Docker 安装与快速入门（镜像 / 容器概念）

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能用「Hypervisor + Guest OS」与「共享 Host 内核 + 命名空间隔离」两张图对比讲清容器与虚拟机的差异，并背出「启动时间、镜像大小、单机密度、隔离强度」四项指标；
2. 能在 Ubuntu 22.04 上用官方一键脚本 `curl -fsSL https://get.docker.com | sudo bash` 安装 Docker 24+，并把当前用户 `usermod -aG docker $USER` 免 sudo；
3. 能配置国内镜像加速（`/etc/docker/daemon.json` 写 USTC / 网易源）并用 `docker info | grep -A2 "Registry Mirrors"` 验证；
4. 能背出「Dockerfile → build → Image → run → Container → push → Registry」六步流水线，并解释每一步在哪台机器上跑；
5. 能一条命令 `docker run hello-world` 完成安装校验，并能读懂输出的六步日志「客户端联系守护进程 → 找不到本地镜像 → 从 DockerHub 拉取 → 创建容器 → 运行 → 输出打招呼」。

#### 1.1.2 过程与方法目标
1. 通过让学生「先在自己电脑上 `apt install openjdk-25-jdk` 再想想给 200 个同学装同一版本」的对照体验，引出「环境标准化」的痛点，为容器化埋伏笔；
2. 通过「拉一次 nginx 镜像然后 `docker save` 出 tar 再 `docker load`」的动手实验，让学生亲眼看到镜像 = 一份可传输的文件。

### 1.2 教学重难点
- **重点**：容器 / 镜像 / Dockerfile / 仓库四个名词的区别与联系；`docker run` 后台守护进程的启动链路；镜像分层 + 只读层 + 可写层的存储模型；国内镜像加速配置文件 `daemon.json` 的写法与生效验证。
- **难点**：为什么容器**不是**「轻量虚拟机」——共享内核意味着**内核漏洞会跨容器逃逸**，隔离强度不如 KVM；为什么 `docker run hello-world` 时 `pull` 步骤如果卡住，**多半是没配镜像加速**而不是网络挂了；`docker` 客户端和 `dockerd` 守护进程的分离结构——Windows Docker Desktop 里的客户端在 Windows，守护进程在 WSL2 Linux 虚拟机里。

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
Day15 结尾同学们把项目搬上了 Ubuntu 22.04，用 systemd 托管着 jar 跑起来了。反问一句：「我今天换一台机器给客户演示，你能不能十分钟内把整套项目在新机器上跑起来？」等学生回答「重跑一遍 deploy.sh」，追问：「新机器上 JDK 版本是 21 不是 25，MySQL 是 5.7 不是 8，Nginx 端口 80 被别人占了——你的 deploy.sh 挡得住吗？」板书写下今天要解决的三个痛点：

```
痛点 1：环境不一致——「我这能跑，你那不行」
痛点 2：升级易崩——JDK / MySQL / Nginx 版本相互纠缠
痛点 3：迁移昂贵——每换一台机器都要装一遍
```

在黑板右侧画出今天的技术栈变化：

```
Day15：宿主机 apt → JDK 25 / MySQL 8 / Nginx 1.24 / yoga.jar
Day16：宿主机 Docker → 镜像 mysql:8 / redis:8-alpine / nginx:1.27-alpine / yoga-backend:1.0
```

一句话点题：「今天开始，你的项目**不再依赖服务器上装了什么**」。

#### 目标（2 分钟）
本课时目标：**把 Docker 24 装好、加速配好、hello-world 跑通、四大概念说清**。板书目标交付物：

```
✓ docker version 打印客户端 + 服务端两段版本
✓ docker info 显示 Registry Mirrors 有 USTC 或网易
✓ docker run hello-world 输出「Hello from Docker!」
✓ 能背出：镜像 / 容器 / Dockerfile / 仓库 四者关系
```

#### 重难点（2 分钟）
黑板标记两个 🔴：
- 🔴 容器共享 Host 内核 → 隔离强度**中**，不适合跑不受信任的第三方代码；
- 🔴 Docker Desktop 上「客户端在 Windows / 守护进程在 WSL2」双层结构 → 学生看到 `docker version` 显示两个 OS 别慌张。

#### 新知讲授（14 分钟）

1. **容器 vs 虚拟机对比图**（4 分钟）：
   - 黑板画双柱图，左柱虚拟机四层：`硬件 → Hypervisor → Guest OS × N → App`；右柱容器三层：`硬件 → Host OS 内核 → 容器（namespace + cgroup 隔离）× N → App`；
   - 引导学生看出「共享内核」是容器省资源的根本——Guest OS 这一整层全部去掉；
   - 抽一位同学上黑板画「亚秒级启动 vs 几十秒启动」的时间轴，强调容器启动 = **进程启动**。

2. **镜像 / 容器 / Dockerfile / 仓库四合一**（5 分钟）：
   - 现场投影演示 `docker pull nginx:1.27` → `docker images` → `docker run -d --name web -p 8080:80 nginx:1.27` → `curl http://localhost:8080` 五步；
   - 边跑边解释：`pull` 是从仓库把「镜像」拉到本地，`run` 是把「镜像」实例化成「容器」，`nginx:1.27` 里的 `1.27` 是 tag；
   - 板书四合一关系图：
     ```
     Dockerfile ──build──▶ Image ──run──▶ Container
                              │
                              └──push──▶ Registry
     ```
   - 强调「Image 是模板、Container 是实例」——同一个镜像可以起 N 个容器，就像同一个 class 可以 new N 个对象。

3. **Ubuntu 22.04 安装 Docker 24 + 镜像加速**（5 分钟）：
   - 投影跑 `curl -fsSL https://get.docker.com | sudo bash`，边跑边讲脚本干了什么：加 apt 源、装 `docker-ce` + `containerd.io` + `docker-compose-plugin`、启 `dockerd` 守护进程、把服务加 systemd；
   - 装完 `sudo usermod -aG docker $USER` 后**必须重开终端**才能免 sudo；
   - 现场编辑 `/etc/docker/daemon.json`：
     ```json
     { "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn", "https://hub-mirror.c.163.com"] }
     ```
   - `sudo systemctl restart docker` → `docker info | grep -A2 "Registry Mirrors"` 验证。

#### 案例演示（12 分钟）

案例 1：**Hello World 六步解剖**（6 分钟）
- 敲 `docker run hello-world`，让学生逐行读输出：
  1. `Unable to find image 'hello-world:latest' locally`
  2. `latest: Pulling from library/hello-world`
  3. `Digest: sha256:...`
  4. `Status: Downloaded newer image for hello-world:latest`
  5. `Hello from Docker!`
  6. `... 1. The Docker client contacted the Docker daemon.`
- 板书六步流水线对应输出，学生自己填空。

案例 2：**镜像的可传输性**（6 分钟）
- 现场跑 `docker save nginx:1.27 -o nginx-1.27.tar`，让学生看 tar 文件大小 ≈ 200MB；
- `docker rmi nginx:1.27` 删除本地镜像；
- `docker load -i nginx-1.27.tar` 装回来；
- `docker images | grep nginx` 验证还在。板书结论：**镜像就是一个 tar 包**，可以走 U 盘、走 scp、走内网仓库。

#### 小结（3 分钟）
一句话：**Docker = 把应用及依赖打成可传输的标准包**。板书今天的四个动词：`pull`（拉镜像）、`run`（起容器）、`images`（列镜像）、`ps`（列容器）——下节课把它们全部串起来跑 MySQL。

#### 作业布置（3 分钟）
- 必做：在自己电脑 / 云服务器上装好 Docker 24，`docker version` 截图上传到班级群；
- 拓展：读 `docker info` 的完整输出，找到 `Storage Driver`（多半是 `overlay2`）并查它是什么。

### 1.4 板书设计

```
┌── Day16 · 第 1 课时 · Docker 入门 ─────────────────────┐
│                                                        │
│  容器 vs 虚拟机：                                       │
│    共享 Host 内核 · 亚秒级启动 · MB 级镜像              │
│                                                        │
│  四合一关系：                                           │
│    Dockerfile ─build→ Image ─run→ Container            │
│                          └──push─→ Registry            │
│                                                        │
│  安装 3 步：                                            │
│    ① curl -fsSL https://get.docker.com | sudo bash     │
│    ② usermod -aG docker $USER                          │
│    ③ /etc/docker/daemon.json 配镜像加速                │
│                                                        │
│  校验 3 条：                                            │
│    docker version / docker info / docker run hello     │
│                                                        │
│  🔴 内核共享 = 隔离中等                                 │
│  🔴 pull 卡住 90% 是没配加速                            │
└────────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. 装好 Docker 24 + 配镜像加速，截图 `docker info | grep Mirror` 输出；
2. `docker run hello-world`，把输出的六步日志与板书对应，写一段 100 字的解释交作业；
3. 拓展：查 Docker Desktop 与 Docker Engine 的区别，回答「Windows 上装哪个」。

### 1.6 教学反思提示
- 学生装机常见坑：Ubuntu 22.04 上 `apt install docker.io` 装的是社区旧版（20.x）——一定要走官方脚本或官方 apt 源才是 24+；
- Docker Desktop 在 Windows 家庭版下要求打开 WSL2，家庭版无 Hyper-V 但可用 WSL2 后端——遇到「未启用虚拟化」要指导学生进 BIOS 打开 VT-x / SVM；
- 授课时不要让镜像加速的地址写死在讲稿——USTC 源经常调整，实时查 https://docker-practice.github.io/ 拿最新。

---

## 第 2 课时：常用命令（pull / run / exec / logs / rm / rmi）+ MySQL 容器实战

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能熟练使用镜像操作四剑客：`docker pull` / `docker images` / `docker tag` / `docker rmi`；
2. 能熟练使用容器操作七剑客：`docker run` / `docker ps` / `docker logs` / `docker exec` / `docker stop` / `docker start` / `docker rm`；
3. 能背出并使用 `docker run` 的三大黄金参数：`-d` 后台、`--name` 命名、`-p host:container` 端口映射；
4. 能一条命令跑起 MySQL 8 容器：`docker run -d --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root -e TZ=Asia/Shanghai mysql:8`，并用 DBeaver / `mysql` 客户端从宿主机连上；
5. 能用 `docker exec -it mysql bash` 进入容器内部，跑 `mysql -uroot -p` 建库建表，理解「容器内 = 独立 Linux 空间」。

#### 2.1.2 过程与方法目标
1. 通过「一条命令 vs Day15 手工装 MySQL 30 步」的时间对比，让学生真切体会容器化交付的效率碾压；
2. 通过让学生故意 `docker rm -f mysql` 删掉容器再重启一个新容器的对照实验，感受**没挂卷时数据必丢**——为下一课时数据卷伏笔。

### 2.2 教学重难点
- **重点**：`docker run` 三大参数 `-d` / `--name` / `-p`；`docker exec -it` 与 `docker attach` 的区别（前者开新会话，后者接管现有进程）；`docker logs -f --tail 100` 实时跟随日志；`docker ps` 与 `docker ps -a` 的差异；`--rm` 一次性容器；`docker cp` 双向拷贝文件。
- **难点**：`docker exec -it mysql bash` 的 `-it` 到底是什么——`-i` 让 STDIN 保持打开，`-t` 分配伪终端，缺一不可（否则 `bash` 立刻退出）；alpine 镜像里没有 `bash` 只有 `sh`；`-p 3306:3306` 前是 host 端口后是 container 端口，写反的话「宿主机连不上」；MySQL 8 默认 `caching_sha2_password` 认证插件，老客户端连不上要么换驱动、要么改 `--default-authentication-plugin`。

### 2.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课装好了 Docker，跑了 hello-world，但那只是一个「打个招呼就退出」的玩具。今天要跑一个**真正的服务**——MySQL。反问：「Day15 装 MySQL 我们跑了多少步？」`apt install → mysql_secure_installation → 改 my.cnf → 建库 → 建用户 → 授权 → systemctl restart` 至少 30 分钟。板书写下今天的对比目标：

```
Day15 装 MySQL：≥ 30 分钟 · 8 条命令 · 3 个配置文件
Day16 起 MySQL：≤ 30 秒 · 1 条命令
```

#### 目标（2 分钟）
一句话：**「用一条 `docker run` 起一个能被 DBeaver 连上、数据在 `docker rm` 后就消失的 MySQL 8 容器」**。今天先跑通「起 → 连 → 造 → 停 → 删」五步，数据持久化留到下一课时。

#### 重难点（2 分钟）
黑板标记两个 🔴：
- 🔴 `-p 宿主机:容器`，写反宿主连不上；
- 🔴 `-it` 的 `-i` + `-t` 缺一不可，`bash` 会秒退。

#### 新知讲授（14 分钟）

1. **镜像操作四剑客**（4 分钟）：
   - `docker pull mysql:8` 拉镜像，让学生看输出「Pulling from library/mysql / a1b2: Pull complete / …」——分层下载；
   - `docker images` 看本地列表，重点看 `REPOSITORY`、`TAG`、`IMAGE ID`、`SIZE` 四列；
   - `docker tag mysql:8 my-mysql:dev` 打别名，`docker images` 再看——同一个 ID 出现两次；
   - `docker rmi my-mysql:dev` 只删别名，`mysql:8` 还在。

2. **容器操作七剑客**（6 分钟）：
   - 逐条演示 `docker run` / `ps` / `logs` / `exec` / `stop` / `start` / `rm`；
   - 特别强调 `docker run` 的三大参数：
     ```
     -d           后台跑（缺省是前台）
     --name web   命名（缺省是 admiring_einstein 随机名）
     -p 8080:80   端口映射（左宿主机右容器）
     ```
   - `docker exec -it web sh`（nginx alpine 没 bash），让学生进容器里 `cat /etc/nginx/nginx.conf`；
   - 讲师提问：「为啥 `docker start web` 之后 `curl :8080` 又通了？」引导答：**端口映射是启动时定的、start 复用原参数**。

3. **MySQL 容器实战**（4 分钟）：
   - 现场敲：
     ```bash
     docker run -d --name mysql \
       -p 3306:3306 \
       -e MYSQL_ROOT_PASSWORD=root \
       -e MYSQL_DATABASE=yoga \
       -e TZ=Asia/Shanghai \
       mysql:8
     ```
   - `docker logs -f mysql` 跟随日志直到看到 `ready for connections. Version: '8.x.x'`；
   - 打开宿主机 DBeaver 连 `localhost:3306` / root / root，建表 `yoga_test(id, name)` 插一条数据；
   - `docker exec -it mysql bash` 进容器，`mysql -uroot -p` 输密码进 CLI，`use yoga; show tables;` 看到刚才建的表——**宿主机操作和容器内数据是一份**。

#### 案例演示（12 分钟）

案例 1：**故意删容器让数据消失**（4 分钟）
- `docker rm -f mysql` 强杀 + 删除；
- 用同样的命令再跑一次容器，DBeaver 重新连，`show tables;`——**空的**。让学生一起说：「容器可写层随容器销毁而销毁」。这个坑为下节课「数据卷」埋下最直接的动机。

案例 2：**日志诊断**（4 分钟）
- 故意跑 `docker run -d --name mysql-bad mysql:8`（漏了 `MYSQL_ROOT_PASSWORD`），秒退；
- `docker ps -a` 看到状态 `Exited (1)`；
- `docker logs mysql-bad` 输出「You need to specify one of the following as an environment variable: MYSQL_ROOT_PASSWORD ...」；
- 训练学生「容器一起就挂 → 先 `docker logs` 而不是重启」的排查条件反射。

案例 3：**docker cp 双向传文件**（4 分钟）
- `echo "SELECT 1;" > q.sql` → `docker cp q.sql mysql:/tmp/` → `docker exec mysql mysql -uroot -proot -e "source /tmp/q.sql"`；
- 反过来 `docker cp mysql:/var/log/mysql/error.log ./` 拷回宿主。

#### 小结（3 分钟）
板书总结：

```
docker pull / images / tag / rmi         镜像四剑客
docker run / ps / logs / exec / stop     容器五连招
        / start / rm                    
docker run 三黄金：-d / --name / -p
一条命令跑 MySQL：docker run -d --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root mysql:8
🔴 容器删掉，数据没了 → 下课时讲数据卷
```

#### 作业布置（3 分钟）
必做：
1. 用 `docker run` 起 MySQL 8、Redis 8、Nginx 1.27-alpine 三个容器，`docker ps` 截图（三个容器同时在跑）；
2. 分别用 DBeaver、`redis-cli`、浏览器验证三个服务从宿主机可访问；
3. 挑一个故意 `docker rm -f` 删掉，再 `docker run` 起一个新的，观察数据 / 配置消失情况，写一段观察记录。

### 2.4 板书设计

```
┌── Day16 · 第 2 课时 · 常用命令 & MySQL 实战 ────────────┐
│                                                        │
│  镜像四剑客：pull · images · tag · rmi                  │
│  容器七剑客：run · ps · logs · exec · stop · start · rm │
│                                                        │
│  docker run 三黄金：                                    │
│    -d             后台守护                              │
│    --name mysql   容器命名                              │
│    -p 3306:3306   端口 host:container                   │
│                                                        │
│  MySQL 一键起：                                         │
│    docker run -d --name mysql -p 3306:3306 \            │
│      -e MYSQL_ROOT_PASSWORD=root \                      │
│      -e MYSQL_DATABASE=yoga \                           │
│      -e TZ=Asia/Shanghai \                              │
│      mysql:8                                            │
│                                                        │
│  exec -it：                                             │
│    -i STDIN 保持    -t 分配 TTY                        │
│    alpine 镜像 → sh 不是 bash                          │
│                                                        │
│  🔴 容器删掉 → 数据丢 → 下课时数据卷                    │
└────────────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. 三容器齐跑：MySQL 8 + Redis 8-alpine + Nginx 1.27-alpine，`docker ps` 截图；
2. `docker exec -it redis redis-cli` 手动 `SET name yoga` / `GET name`，然后 `docker restart redis`，再 `GET name` 观察结果——**记住这个现象，下课时解释**；
3. 拓展：查 `docker inspect mysql` 输出的 `Mounts` / `NetworkSettings.Ports` 两段，看看容器状态是怎么被 Docker 记录的。

### 2.6 教学反思提示
- 常见误操作：学生把 `-p 3306:3306` 写成 `-p 3306` → 变成随机 host 端口，讲清 `-p` 的三种写法（`host:container` / `ip:host:container` / `-P` 随机）；
- 学生第一次 `docker exec -it mysql bash` 秒退：多半漏了 `-i` 或 `-t`；alpine 用 `sh` 别用 `bash`；
- MySQL 8 与 Navicat 老版本认证不兼容：讲一下 `caching_sha2_password`，让学生知道有这坑就好，不深入。

---

## 第 3 课时：数据卷（bind mount vs named volume）+ Redis 数据持久化

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能画出「容器读写层 vs 数据卷」的分层图，解释为什么容器一删数据就消失；
2. 能区分并选择两种挂载方式：**命名卷（named volume）** 由 Docker 管理路径、适合生产数据；**绑定挂载（bind mount）** 直接把宿主机目录挂进容器、适合开发场景与配置文件；
3. 能用 `docker volume create` / `ls` / `inspect` / `rm` 管理命名卷；
4. 能给 MySQL、Redis 两个容器都挂上数据卷，并 `docker rm -f` 再重启后**数据仍在**；
5. 能给 Nginx 容器同时挂两个 bind mount：静态资源目录（读写）、配置目录（`:ro` 只读），修改宿主机文件立刻生效。

#### 3.1.2 过程与方法目标
1. 通过上节课作业「Redis `SET` 后 `docker restart` 数据居然还在，但 `docker rm` 数据就没了」的现象引出「重启 ≠ 重建」的关键概念；
2. 通过让学生一次挂命名卷、一次挂 bind mount 各起一次 MySQL，对比 `docker volume ls` 与宿主机目录的可见性，训练「数据到底存在哪」的直觉。

### 3.2 教学重难点
- **重点**：`-v <name>:<path>` 与 `-v <host-abs-path>:<container-path>[:ro]` 两种 `-v` 语法；`docker volume create` / `ls` / `inspect` / `prune`；命名卷的实际存储路径 `/var/lib/docker/volumes/<name>/_data`；`:ro` 只读挂载。
- **难点**：为什么 `docker restart` 容器**不丢数据**——容器还是同一个可写层；而 `docker rm` 才真的销毁；`bind mount` 的宿主机路径**必须绝对路径**，写相对路径 Docker 会当成命名卷；MySQL 容器进程 UID = 999，bind mount 到宿主机某目录时**目录属主必须 chown 999:999** 否则「权限拒绝」；Windows / WSL2 下 bind mount 挂 `/mnt/c/...` 存在**性能陷阱**（跨文件系统 IO 很慢）。

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课作业问了一个问题：「Redis `SET name yoga` 后 `docker restart redis` 数据还在吗？」抽两位同学答。**是的还在**——因为 `restart` 只是重启容器进程，容器的**可写层**没销毁。但 `docker rm redis` 就完了。板书画出容器分层：

```
┌───────────────────┐
│  可写层（容器）    │   ← rm 时销毁
├───────────────────┤
│  只读层 3          │
│  只读层 2          │   ← 镜像层，多个容器共享
│  只读层 1          │
└───────────────────┘
```

再画一条**外接数据卷**：

```
容器 ──── mount ────▶  Volume（宿主机 /var/lib/docker/volumes/...）
                       ↑ 数据独立于容器生命周期
```

一句话点题：**把数据放进卷里，容器就随便删**。

#### 目标（2 分钟）
一句话：**「让 MySQL 和 Redis 都能 `docker rm -f` 再重启而数据不丢」**。板书目标交付物：

```
✓ docker volume ls 看到 yoga-mysql / yoga-redis 两个卷
✓ rm 容器 → run 新容器 → 老数据还在
✓ Nginx bind mount 挂静态目录，改 html 秒生效
```

#### 重难点（2 分钟）
黑板 🔴：
- 🔴 命名卷「Docker 管路径」；bind mount「宿主机绝对路径」；
- 🔴 `-v` 路径**必须绝对**——`./data` 会被识别成卷名。

#### 新知讲授（15 分钟）

1. **命名卷全套流程**（5 分钟）：
   - `docker volume create yoga-mysql` → `docker volume ls` → `docker volume inspect yoga-mysql`；
   - 观察 `Mountpoint: /var/lib/docker/volumes/yoga-mysql/_data`——这就是数据的物理落地；
   - 现场跑：
     ```bash
     docker rm -f mysql
     docker run -d --name mysql \
       -p 3306:3306 \
       -v yoga-mysql:/var/lib/mysql \
       -e MYSQL_ROOT_PASSWORD=root -e MYSQL_DATABASE=yoga \
       mysql:8
     ```
   - DBeaver 建表插数据，`docker rm -f mysql`，再跑一遍一样的命令——**数据还在**。

2. **绑定挂载（bind mount）**（5 分钟）：
   - 宿主机 `mkdir -p /var/www/yoga && echo "<h1>hello yoga</h1>" > /var/www/yoga/index.html`；
   - `docker run -d --name nginx -p 8080:80 -v /var/www/yoga:/usr/share/nginx/html:ro nginx:1.27-alpine`；
   - 浏览器 `localhost:8080` 看到 hello yoga；
   - 宿主机改 `index.html` 内容，浏览器刷新——**秒变**，因为**同一份文件**；
   - 强调 `:ro` 只读挂载，容器内 `echo x >> index.html` 会 permission denied——安全保护。

3. **命名卷 vs bind mount 选型**（3 分钟）：
   - 板书对比表：
     | 场景 | 选择 |
     |------|------|
     | 数据库数据 | 命名卷 |
     | 服务日志（长期归档） | bind mount 到 host 目录 |
     | 配置文件（人肉编辑） | bind mount + `:ro` |
     | 前端静态资源 | bind mount + `:ro` |
     | 一次性测试 | 不挂 |

4. **权限 UID 坑**（2 分钟）：
   - MySQL 官方镜像用 UID 999 跑 `mysqld`；bind mount 到 host 目录时若属主是 root，MySQL 无法写 → 启动挂；
   - 解决：`sudo chown -R 999:999 /path/on/host`；或干脆用命名卷（Docker 自动处理属主）。

#### 案例演示（10 分钟）

案例 1：**Redis 持久化实战**（5 分钟）
```bash
docker volume create yoga-redis
docker run -d --name redis -p 6379:6379 \
  -v yoga-redis:/data \
  redis:8-alpine --appendonly yes --requirepass "yoga123"
```
- `docker exec -it redis redis-cli -a yoga123` → `SET name yoga` → `exit`；
- `docker rm -f redis` → 同一条命令再起 → `GET name` → `"yoga"`——**卷做到了**。
- 板书写：`--appendonly yes` 开 AOF 追加持久化，Redis 写命令进 `/data/appendonly.aof`；`--requirepass` 强制密码。

案例 2：**Nginx 配置热更**（5 分钟）
- 宿主机 `mkdir -p /opt/yoga/nginx/conf.d && cat > /opt/yoga/nginx/conf.d/default.conf <<EOF
server { listen 80; root /usr/share/nginx/html; index index.html; }
EOF`；
- `docker run -d --name nginx -p 8080:80 -v /var/www/yoga:/usr/share/nginx/html:ro -v /opt/yoga/nginx/conf.d:/etc/nginx/conf.d:ro nginx:1.27-alpine`；
- 改宿主机 conf.d/default.conf 加 gzip；`docker exec nginx nginx -s reload`——生效。
- 抽一位同学解释：为什么改 conf 之后要 `nginx -s reload` 而不是 `docker restart`？—— reload 平滑不断连接；restart 会杀连接。

#### 小结（3 分钟）

```
容器可写层 → rm 销毁
Volume → 独立生命周期
命名卷：数据；bind mount：配置 / 日志 / 静态
-v 语法：name:path 或 /host/abs/path:/ctr/path[:ro]
🔴 UID 权限 · 🔴 绝对路径
```

#### 作业布置（3 分钟）
1. 用命名卷跑 MySQL 8，`docker rm -f mysql` 之后重启新容器数据仍在；
2. 用 bind mount 跑 Nginx，宿主机改 index.html 即时生效；
3. 拓展：`docker volume prune` 是什么行为？为什么生产环境不要随手跑？

### 3.4 板书设计

```
┌── Day16 · 第 3 课时 · 数据卷 ──────────────────────────┐
│                                                        │
│  容器分层：                                             │
│    ┌ 可写层 ┐   ← rm 销毁                              │
│    ├ 只读层 ┤   ← 镜像共享                             │
│    └────────┘                                          │
│    Volume ⇒ 挂到容器某目录 ⇒ 独立寿命                  │
│                                                        │
│  两种挂载：                                             │
│    -v yoga-mysql:/var/lib/mysql         命名卷         │
│    -v /var/www/yoga:/usr/share/...:ro   bind mount     │
│                                                        │
│  Redis 持久化：                                         │
│    docker run -d --name redis -p 6379:6379 \           │
│      -v yoga-redis:/data \                             │
│      redis:8-alpine --appendonly yes                   │
│                                                        │
│  🔴 命名卷用于数据 · bind 用于配置/日志                │
│  🔴 -v 路径必须绝对 · MySQL UID 999                   │
└────────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. 给 MySQL 挂命名卷，给 Nginx 挂两份 bind mount（静态目录 rw、配置目录 ro）；
2. 观察 `docker volume inspect yoga-mysql` 的 `Mountpoint`，`sudo ls` 那个目录看看能不能直接读；
3. 拓展：用 `docker run --rm -v yoga-mysql:/data alpine tar czf - /data > mysql-backup.tar.gz` 做卷备份，说说这条命令的意思。

### 3.6 教学反思提示
- Windows / WSL2 下 bind mount 挂 `/mnt/c/...` 性能奇差——授课时如果学生用 Docker Desktop，建议把项目目录放到 WSL2 内部（`~/projects/...`）而不是 `/mnt/c/...`；
- 学生常把 `-v yoga:/data` 与 `-v ./yoga:/data` 混用，前者是命名卷、后者是相对路径 bind mount → Docker 会把 `./yoga` 当命名卷（Linux 早期版本）或报错（新版），务必强调「绝对路径」；
- 权限坑要现场演示一次：先故意用 root 属主挂 MySQL，让学生看到 `chown: changing ownership: Operation not permitted` 报错，再演示 `chown 999:999` 修复。

---

## 第 4 课时：Dockerfile 基础语法（FROM/COPY/RUN/CMD/EXPOSE/ENV）

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能背出 Dockerfile 九大常用指令：`FROM` / `WORKDIR` / `COPY` / `ADD` / `RUN` / `CMD` / `ENTRYPOINT` / `ENV` / `EXPOSE`；
2. 能写出一个 `hello:v1` 镜像的 Dockerfile：基于 alpine、复制脚本、`chmod +x`、`CMD` 执行；
3. 能用 `docker build -t <name>:<tag> .` 构建镜像，理解「上下文（build context）」的含义；
4. 能区分 `CMD` 与 `ENTRYPOINT`：CMD 会被 `docker run image xxx` 覆盖，ENTRYPOINT 固定入口 + CMD 补参数；
5. 能写 `.dockerignore` 文件（语法同 `.gitignore`），把 `.git` / `node_modules` / `target` / `.env` 挡在构建上下文之外。

#### 4.1.2 过程与方法目标
1. 通过「用命令行敲一遍 vs 用 Dockerfile 写一遍」的对比，让学生体会「可版本化」的价值；
2. 通过让学生故意漏 `.dockerignore` 跑一次 `docker build`，观察「Sending build context to Docker daemon 1.2GB」的巨大传输，训练「上下文瘦身」的直觉。

### 4.2 教学重难点
- **重点**：`FROM` / `WORKDIR` / `COPY` / `RUN` / `CMD` / `EXPOSE` / `ENV` 七件套的用法；shell 形式 `CMD echo hi` vs exec 形式 `CMD ["echo","hi"]` 的区别；`docker build -t name:tag .` 里最后那个 `.` 是**构建上下文**；`.dockerignore` 的重要性。
- **难点**：`CMD` vs `ENTRYPOINT` 的组合矩阵——「只 CMD / 只 ENTRYPOINT / 二者同时」三种场景各自的行为；`RUN apt update` 与 `RUN apt install` 必须**合并成一条 RUN**——两条会导致两层 layer，且第二次执行时 apt 缓存已被前一层的清理干掉；`COPY` 和 `ADD` 的区别（`ADD` 支持 URL 和自动解压 tar，但**副作用多，实战一律用 COPY**）；`EXPOSE 8080` **只是文档**，不做端口映射，映射靠 `docker run -p`。

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
前 3 课时用别人的镜像（mysql / redis / nginx）跑得挺顺——**但你自己写的项目 yoga-server 呢？** DockerHub 上没有 yoga-server 镜像。反问：「怎么办？」引导答：**自己写 Dockerfile 打一个**。板书写下今天要打的三个自定义镜像目标（第 5、6 课时才真正实现）：

```
今天：hello:v1   （一个 shell 脚本容器）  → 学语法
下课：yoga-backend:1.0.0  （Spring Boot jar）
下下课：yoga-web:1.0.0    （Vue dist + Nginx）
```

#### 目标（2 分钟）
一句话：**「用 Dockerfile 写一个 hello 镜像，能被 `docker run` 起来输出当前时间」**。今天专攻语法，业务镜像下节课开始。

#### 重难点（2 分钟）
黑板 🔴：
- 🔴 `CMD` 是**默认命令**，可被 run 时覆盖；`ENTRYPOINT` 是**固定入口**；
- 🔴 `RUN` 合并省层数，`RUN apt update && apt install curl && rm -rf /var/lib/apt/lists/*`。

#### 新知讲授（16 分钟）

1. **Dockerfile 结构与九件套**（4 分钟）：
   - 板书九件套表格（同章节 32.2）；
   - 讲每条指令的定位：`FROM` 决定基础镜像、`WORKDIR` 相当于 `cd`、`COPY` 从宿主到镜像、`RUN` 构建时跑命令、`CMD` 运行时默认命令、`ENV` 环境变量、`EXPOSE` 声明端口。

2. **Hello Dockerfile 从零手写**（4 分钟）：
   - 现场目录 `~/day16/hello`：
     ```
     hello/
     ├── Dockerfile
     └── hello.sh
     ```
   - `hello.sh`：
     ```bash
     #!/bin/sh
     echo "Hello from container at $(date)"
     ```
   - `Dockerfile`：
     ```dockerfile
     FROM alpine:3.20
     WORKDIR /app
     COPY hello.sh .
     RUN chmod +x hello.sh
     CMD ["./hello.sh"]
     ```
   - `docker build -t hello:v1 .` → `docker run --rm hello:v1`——看到 hello。
   - 学生问：**最后那个 `.` 是什么？**——**构建上下文**（当前目录整体打包送给 daemon）。

3. **shell vs exec 形式**（3 分钟）：
   - `CMD echo hi`（shell 形式）→ 实际跑的是 `/bin/sh -c "echo hi"`；
   - `CMD ["echo","hi"]`（exec 形式）→ 直接 exec，没有额外 sh；
   - **生产一律 exec 形式**——信号传递正确、进程树浅，容器 stop 时 SIGTERM 能直达进程；
   - 反例：`CMD java -jar app.jar` 与 `CMD ["java","-jar","app.jar"]`——前者 stop 时 Spring Boot 收不到 SIGTERM 会被强杀，后者优雅关机。

4. **CMD vs ENTRYPOINT 矩阵**（3 分钟）：
   - 板书：
     ```
     CMD 单独：docker run img → 跑 CMD；docker run img other → 覆盖成 other
     ENTRYPOINT 单独：docker run img → 跑 ENTRYPOINT；docker run img x → ENTRYPOINT x
     二者同时：docker run img → ENTRYPOINT + CMD；docker run img x → ENTRYPOINT + x
     ```
   - 实战常用组合：`ENTRYPOINT ["java","-jar","app.jar"]` + `CMD ["--spring.profiles.active=prod"]`——学生 `docker run img --spring.profiles.active=dev` 即可切环境。

5. **`.dockerignore`**（2 分钟）：
   - 语法同 `.gitignore`；
   - 后端典型：
     ```text
     .git
     target/*
     !target/*.jar
     .idea
     *.iml
     ```
   - 前端典型：
     ```text
     .git
     node_modules
     dist
     .env
     .env.local
     ```
   - 不写会把大目录都上传给 daemon，慢且容易把 `.env` 泄进镜像。

#### 案例演示（12 分钟）

案例 1：**上下文瘦身**（4 分钟）
- 故意在 hello 目录里 `dd if=/dev/urandom of=big.bin bs=1M count=200`；
- 不写 `.dockerignore` 跑 `docker build -t hello:v2 .`，看输出「Sending build context to Docker daemon 210MB」；
- 加 `.dockerignore` 里写 `big.bin`，重跑，「1.5MB」——瘦身 99.3%。

案例 2：**RUN 合并省层**（4 分钟）
- 反例 Dockerfile：
  ```dockerfile
  FROM ubuntu:22.04
  RUN apt update
  RUN apt install -y curl
  RUN rm -rf /var/lib/apt/lists/*
  ```
- 正例：
  ```dockerfile
  FROM ubuntu:22.04
  RUN apt update && apt install -y curl && rm -rf /var/lib/apt/lists/*
  ```
- 分别 `docker build`，`docker history` 看层数——3 层 vs 1 层，且反例最终镜像里 apt 缓存**没清干净**（因为 `rm -rf` 是新层，前一层的缓存已在 diff 里）。

案例 3：**ENTRYPOINT + CMD 组合**（4 分钟）
- 构建 `echo-tool`：
  ```dockerfile
  FROM alpine:3.20
  ENTRYPOINT ["echo"]
  CMD ["hello"]
  ```
- `docker run --rm echo-tool` → `hello`；
- `docker run --rm echo-tool world` → `world`（CMD 被覆盖）。
- 板书这个组合是「工具型镜像」的经典模式——运行时接受参数。

#### 小结（3 分钟）

```
九件套：FROM WORKDIR COPY ADD RUN CMD ENTRYPOINT ENV EXPOSE
CMD vs ENTRYPOINT：默认命令 vs 固定入口
exec 形式：["cmd","arg"] · 信号能达
RUN 合并省层 · .dockerignore 上下文瘦身
build -t name:tag . （.= 构建上下文）
```

#### 作业布置（3 分钟）
1. 写一个 `time-tool` 镜像：alpine 基础，`ENTRYPOINT ["date"]`，`docker run --rm time-tool` 打时间、`docker run --rm time-tool +%s` 打时间戳；
2. 写一个 `echo-env` 镜像：`ENV NAME=world` + `CMD echo hello $NAME`，观察 `docker run --rm -e NAME=yoga echo-env` 输出；
3. 拓展：查 `docker history <image>` 是干什么的，能看到什么信息。

### 4.4 板书设计

```
┌── Day16 · 第 4 课时 · Dockerfile 语法 ─────────────────┐
│                                                        │
│  九件套：                                               │
│    FROM       基础镜像                                  │
│    WORKDIR    工作目录（自动 mkdir）                    │
│    COPY       宿主机 → 镜像                             │
│    ADD        （不推荐，只用 COPY）                     │
│    RUN        构建时命令                                │
│    CMD        运行时默认命令（可覆盖）                  │
│    ENTRYPOINT 固定入口（推荐 exec 形式）                │
│    ENV        环境变量                                  │
│    EXPOSE     声明端口（文档作用）                      │
│                                                        │
│  hello Dockerfile：                                     │
│    FROM alpine:3.20                                    │
│    WORKDIR /app                                        │
│    COPY hello.sh .                                     │
│    RUN chmod +x hello.sh                               │
│    CMD ["./hello.sh"]                                  │
│                                                        │
│  build 3 元素：                                         │
│    -t name:tag  · Dockerfile · 构建上下文 .            │
│                                                        │
│  🔴 CMD vs ENTRYPOINT                                   │
│  🔴 RUN 合并 · .dockerignore 瘦身                       │
└────────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. 写 `hello:v1`，能被 `docker run --rm hello:v1` 输出当前时间；
2. 写 `.dockerignore` 挡住 `.git` 和随手生成的 200MB 大文件，观察构建上下文大小变化；
3. 拓展：`docker history hello:v1` 看每层的大小与命令，思考「哪一层最胖」。

### 4.6 教学反思提示
- 学生第一次写 Dockerfile 常见错：把 `CMD` 写成 `CMD "./hello.sh"`（字符串没数组），实际会跑 `/bin/sh -c "./hello.sh"`，多包了一层 sh；讲清 exec 形式的重要性；
- `RUN chmod +x hello.sh` 如果放在 `COPY hello.sh .` 之前会失败——**指令顺序 = 层顺序**；
- 上课时可以提前把 `.dockerignore` 案例的 `big.bin` 生成好，节省课堂时间；
- alpine 基础镜像是 `sh` 不是 `bash`，`RUN` 里如果写 bash 特性（如 `[[ ]]`）会失败——授课时提一下。

---

## 第 5 课时：多阶段构建 + Spring Boot 应用镜像（JDK 25 + jar）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能写出「单阶段 Dockerfile」把已经 `./mvnw package` 好的 `target/yoga-server-*.jar` 打进 `eclipse-temurin:25-jre-alpine` 基础镜像；
2. 能写出「多阶段 Dockerfile」：`maven:3.9-eclipse-temurin-25` 阶段构建 + `eclipse-temurin:25-jre-alpine` 阶段运行，两阶段之间用 `COPY --from=builder /build/target/*.jar app.jar` 转移产物；
3. 能通过「依赖下载层与源码层分离」使得**只改代码不重装依赖**，构建从 3 分钟提速到 30 秒；
4. 能设置 `ENV JAVA_OPTS="-Xms256m -Xmx512m"` + `ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]` 让内存参数可外部注入；
5. 能给镜像加 `HEALTHCHECK --interval=30s CMD wget -qO- http://localhost:8080/actuator/health || exit 1`，`docker ps` 里看到 `(healthy)` 状态。

#### 5.1.2 过程与方法目标
1. 通过对比「单阶段镜像 800MB vs 多阶段镜像 200MB」的实测差值，让学生真切体会「多阶段就是把构建工具丢掉」；
2. 通过让学生故意把 `COPY src ./src` 放到 `COPY pom.xml .` 前面再改一行代码重构建，观察「整个 Maven 依赖被重新下载」，训练**分层缓存**的直觉。

### 5.2 教学重难点
- **重点**：多阶段构建的三件套「`FROM x AS builder` + 中间构建 + `FROM y` + `COPY --from=builder`」；「pom 先复制、依赖先下载、源码后复制、代码后构建」四步分层缓存；`JAVA_OPTS` 外注入内存参数；`HEALTHCHECK` 与 `actuator/health` 联动；`.dockerignore` 后端版。
- **难点**：为什么 `maven:3.9-eclipse-temurin-25` 阶段的 `.m2` 缓存**不会**跟到 runtime 阶段——`COPY --from=builder /build/target/*.jar` 只拷了 jar；`ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]` 里的 `exec` 极重要——让 java 进程接替 sh 成为 PID 1，`docker stop` 时 SIGTERM 才能直达 Spring Boot 触发优雅关机；`--platform linux/amd64` 在 Mac M 系列上构建 Linux 生产镜像的坑；`HEALTHCHECK` 的 `--start-period=30s` 是给 Spring Boot 启动预留的时间窗口。

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
Day15 我们的部署脚本是「本地 `./mvnw package` → scp jar → 服务器 `systemctl restart`」。反问：「如果我今天在 Windows 用 JDK 21 打的包，服务器 JDK 25 会怎样？」引出「本地构建环境不一致」的隐患。板书写今天的目标：

```
把 yoga-server 打成 yoga-backend:1.0.0 镜像
特性：
  1. 构建过程发生在 Docker 内 → 与本地机器无关
  2. 依赖变了才重下载 → 增量构建 30 秒
  3. 最终镜像 200MB 左右 → 只含 JRE + jar
  4. 内置健康检查 → docker ps 显示 healthy
```

#### 目标（2 分钟）
一句话：**「用一份多阶段 Dockerfile 让 yoga-server 从源码到镜像全流程自动化」**。

#### 重难点（2 分钟）
黑板 🔴：
- 🔴 `AS builder` + `--from=builder` 两句配套；
- 🔴 pom / src 分层复制 → 依赖缓存 → 秒级增量。

#### 新知讲授（16 分钟）

1. **单阶段构建（起点）**（4 分钟）：
   - 前置：`./mvnw clean package -DskipTests` 已在本地生成 `target/yoga-server-1.0.0.jar`；
   - Dockerfile：
     ```dockerfile
     FROM eclipse-temurin:25-jre-alpine
     ENV TZ=Asia/Shanghai \
         JAVA_OPTS="-Xms256m -Xmx512m"
     WORKDIR /app
     COPY target/yoga-server-*.jar app.jar
     EXPOSE 8080
     ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]
     ```
   - `docker build -t yoga-backend:1.0.0 .` → `docker run -d --name yoga-backend -p 8080:8080 yoga-backend:1.0.0`；
   - `docker logs -f yoga-backend` 看到 Spring Boot 起动 banner。
   - 缺点：**本地必须先 `mvnw package`**——构建环境依赖本机。

2. **多阶段构建（正式版）**（8 分钟）：
   - 现场敲 Dockerfile，边敲边讲：
     ```dockerfile
     # ============ Stage 1: 构建 ==============
     FROM maven:3.9-eclipse-temurin-25 AS builder
     WORKDIR /build

     # 先复制 pom 和 wrapper，利用缓存下载依赖
     COPY pom.xml .
     COPY .mvn .mvn
     COPY mvnw .
     RUN chmod +x mvnw && ./mvnw dependency:go-offline -B

     # 再复制源码构建
     COPY src ./src
     RUN ./mvnw clean package -DskipTests -B

     # ============ Stage 2: 运行 ==============
     FROM eclipse-temurin:25-jre-alpine
     ENV TZ=Asia/Shanghai \
         JAVA_OPTS="-Xms256m -Xmx512m"
     WORKDIR /app
     COPY --from=builder /build/target/*.jar app.jar

     EXPOSE 8080
     HEALTHCHECK --interval=30s --timeout=3s --start-period=30s \
       CMD wget -qO- http://localhost:8080/actuator/health || exit 1
     ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS -jar app.jar"]
     ```
   - 逐段讲：
     - Stage 1 的基础镜像是 `maven:3.9-eclipse-temurin-25`——Maven 3.9 + JDK 25 一体的官方镜像；
     - `dependency:go-offline` 是 Maven 的「把依赖全下下来」目标，配合 pom 先复制，实现依赖层缓存；
     - Stage 2 只 `COPY --from=builder /build/target/*.jar app.jar` 拷 jar，Maven / JDK 全丢；
     - `HEALTHCHECK` 每 30 秒打一次 `/actuator/health`，`start-period` 给启动 30 秒宽限；
     - `ENTRYPOINT ["sh","-c","exec java ..."]` 里 `exec` 是关键——让 java 接替 sh 成 PID 1，收得到 SIGTERM。

3. **`.dockerignore` 后端版**（2 分钟）：
   ```text
   .git
   target
   .idea
   *.iml
   Dockerfile
   docker-compose.yml
   .env*
   ```
   - `target` 挡住本地已有产物，让 Docker 内 Maven 从头构建纯净版；
   - `.env*` 挡住敏感信息。

4. **构建、推送、拉取**（2 分钟）：
   ```bash
   docker build -t yoga-backend:1.0.0 .
   docker tag yoga-backend:1.0.0 registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
   docker login registry.cn-hangzhou.aliyuncs.com -u <user>
   docker push registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
   ```
   - 服务器上 `docker pull` 后 `docker run`——**一次构建、多处运行**。

#### 案例演示（12 分钟）

案例 1：**分层缓存实测**（5 分钟）
- 第 1 次 `docker build`：全量下载依赖，约 3 分钟；
- 改一个 Controller 里的字符串常量；
- 第 2 次 `docker build`：只跑 `COPY src ./src` 及之后的层，约 30 秒；
- 板书总结：**变得少的放前面**——pom.xml 稳定 → 依赖缓存复用。

案例 2：**HEALTHCHECK 生效**（4 分钟）
- 起容器；
- 立即 `docker ps` → 状态 `Up 2 seconds (health: starting)`；
- 30 秒后 `docker ps` → `Up 30 seconds (healthy)`；
- 让学生进容器 `kill 1`（其实杀不掉 PID 1），或 `docker exec` 停掉 Spring Boot 进程，再看 `docker ps` → `(unhealthy)`。

案例 3：**JAVA_OPTS 外注入**（3 分钟）
- `docker run -d --name yoga-backend -p 8080:8080 -e JAVA_OPTS="-Xms512m -Xmx1024m -Duser.timezone=Asia/Shanghai" yoga-backend:1.0.0`；
- `docker exec yoga-backend jps -v` 看进程参数生效。

#### 小结（3 分钟）

```
多阶段 = 构建阶段 + 运行阶段
  Stage 1: maven:3.9-eclipse-temurin-25 打 jar
  Stage 2: eclipse-temurin:25-jre-alpine 只跑 jar
分层缓存：pom 先 · 依赖后 · 源码最后
镜像目标：< 250MB · healthy · 优雅关机（exec java）
```

#### 作业布置（3 分钟）
1. 给 `yoga-server` 写多阶段 Dockerfile，构建出 `yoga-backend:1.0.0`；
2. `docker run` 起来后浏览器打 `http://localhost:8080/actuator/health` 返回 `{"status":"UP"}`；
3. 观察前后两次 `docker build` 的日志时间对比，写下加速倍数。

### 5.4 板书设计

```
┌── Day16 · 第 5 课时 · 多阶段 + Spring Boot 镜像 ───────┐
│                                                        │
│  Stage 1  builder                                       │
│    FROM maven:3.9-eclipse-temurin-25 AS builder        │
│    WORKDIR /build                                       │
│    COPY pom.xml . / .mvn / mvnw                        │
│    RUN ./mvnw dependency:go-offline -B                  │
│    COPY src ./src                                       │
│    RUN ./mvnw package -DskipTests -B                    │
│                                                        │
│  Stage 2  runtime                                       │
│    FROM eclipse-temurin:25-jre-alpine                  │
│    ENV TZ / JAVA_OPTS                                   │
│    COPY --from=builder /build/target/*.jar app.jar     │
│    EXPOSE 8080                                          │
│    HEALTHCHECK ... /actuator/health                     │
│    ENTRYPOINT ["sh","-c","exec java $JAVA_OPTS ..."]   │
│                                                        │
│  分层缓存：pom → 依赖 → src → 构建                      │
│  🔴 exec 让 java 成 PID 1                              │
│  🔴 --from=builder 只拷产物                            │
└────────────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. 完整给自己 `yoga-server` 项目写多阶段 Dockerfile + `.dockerignore`，构建 `yoga-backend:1.0.0`；
2. `docker run` 起来，浏览器验证 `http://localhost:8080/actuator/health` 与业务 API；
3. `docker images yoga-backend:1.0.0` 记录镜像大小，目标 < 250MB；
4. 拓展：把镜像 push 到自己账号的阿里云 ACR（可选，没有账号可以 skip）。

### 5.6 教学反思提示
- Mac M 系列（arm64）学生构建的镜像默认是 `linux/arm64`，push 到 linux/amd64 服务器上会 `exec format error`——**必加** `docker build --platform linux/amd64 ...`；
- 中国大陆 Maven Central 拉包慢：让学生在 `.m2/settings.xml` 里配阿里云镜像；或在 Dockerfile 里 `COPY settings.xml /root/.m2/`；
- `mvnw` 权限问题：`RUN chmod +x mvnw` 别漏；有时 checkout 到 Windows 后 `mvnw` 的 CRLF 换行会导致容器内 `bash: ./mvnw: bad interpreter`——建议 git config `core.autocrlf=false`；
- 讲 `exec java` 的时候强调「不 exec 就是两层进程 → sh 挡住信号 → docker stop 10 秒后被强杀」，最好现场演示一次「不 exec」版本的挂法。

---

## 第 6 课时：Vue 项目镜像（node build → nginx serve）+ 镜像优化

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能写出 Vue 3 前端项目的多阶段 Dockerfile：`node:20-alpine` 阶段 `pnpm build` 出 `dist/`，`nginx:1.27-alpine` 阶段托管 `dist/`；
2. 能写配套的 `nginx.conf` 处理三件事：`root /usr/share/nginx/html` 静态托管、`location /` SPA fallback（`try_files $uri $uri/ /index.html`）、`location /api/` 反向代理到 `backend:8080`；
3. 能通过「`package.json` + `pnpm-lock.yaml` 先复制、依赖先装、`.` 后复制」实现前端分层缓存；
4. 能背出四大镜像优化手段：alpine 基础镜像、多阶段丢弃构建工具、`RUN` 合并、`.dockerignore` 拒不相关文件；目标前端镜像 < 40MB；
5. 能用 `docker history` / `docker image inspect` / `dive` 三种工具分析镜像层组成，发现「哪一层最胖、能不能减小」。

#### 6.1.2 过程与方法目标
1. 通过前端与后端镜像的多阶段结构类比，让学生把「多阶段」抽象成一个通用模式：**用完就丢的工具在前 stage，只保留最终产物**；
2. 通过让学生把 `-alpine` 换成 `-slim` 换成默认标签，实测三个镜像的大小差别，训练镜像选型直觉。

### 6.2 教学重难点
- **重点**：Vue 前端 Dockerfile 两阶段结构；`nginx.conf` 的 SPA fallback（Vue Router history 模式必备）；`proxy_pass http://backend:8080/` 里末尾斜杠的含义；`pnpm i --frozen-lockfile` 严格用 lockfile；`.dockerignore` 前端版。
- **难点**：为什么 `proxy_pass http://backend:8080/` **末尾斜杠**决定 URL 是否重写——带斜杠会把 `location /api/` 前缀替换掉，不带斜杠会保留 `/api/` 传给后端；`backend` 是**容器名**，只有把前端和后端放同一个 `docker network` 里才能解析（第 33 章 compose）；`node:20-alpine` 里 `pnpm i` 有时报 `SSL error`——是 alpine 的 `libc` 差异，或换 `node:20-slim` 或加 `RUN apk add --no-cache python3 make g++ openssl` 拷 native 依赖；镜像层缓存 vs BuildKit 缓存挂载（`--mount=type=cache`）——进阶提一下。

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课把 yoga-server 打成了镜像。反问：「前端 yoga-web 怎么打？dist 静态文件而已，直接 `docker cp` 到 Nginx 容器行不行？」引导答：**能，但没版本管理**——今天要把前端也标准化。板书写下今天的目标结构：

```
前端 Dockerfile（多阶段）：
  Stage 1  node:20-alpine  → pnpm build → dist/
  Stage 2  nginx:1.27-alpine → 托管 dist/
最终镜像：yoga-web:1.0.0 · 目标 < 40MB
```

#### 目标（2 分钟）
一句话：**「用一份多阶段 Dockerfile 把 Vue 前端打成能被浏览器打开的 Nginx 镜像，且能反代 `/api/` 到后端」**。

#### 重难点（2 分钟）
黑板 🔴：
- 🔴 SPA fallback：`try_files $uri $uri/ /index.html`，否则 Vue Router 刷新 404；
- 🔴 `proxy_pass ... /` **末尾斜杠**决定前缀是否重写。

#### 新知讲授（15 分钟）

1. **前端多阶段 Dockerfile**（6 分钟）：
   ```dockerfile
   # ============ Stage 1: 打包 ==============
   FROM node:20-alpine AS builder
   WORKDIR /build

   # 先复制 lock 装依赖，利用缓存
   COPY package.json pnpm-lock.yaml ./
   RUN npm i -g pnpm@9 && pnpm i --frozen-lockfile

   # 再复制源码构建
   COPY . .
   RUN pnpm build

   # ============ Stage 2: 静态托管 ==============
   FROM nginx:1.27-alpine

   # 覆盖默认站点配置
   COPY nginx.conf /etc/nginx/conf.d/default.conf

   # 拷贝 dist
   COPY --from=builder /build/dist /usr/share/nginx/html

   EXPOSE 80
   CMD ["nginx","-g","daemon off;"]
   ```
   - 逐段讲：
     - `node:20-alpine`：Node 20 LTS + alpine，镜像 ≈ 60MB；
     - `pnpm i --frozen-lockfile`：严格按 lockfile 装，CI 一致性保证；
     - `COPY . .` 之前**先** `COPY package.json pnpm-lock.yaml`——分层缓存的核心；
     - Stage 2 用 `nginx:1.27-alpine`，只 ≈ 45MB，加上 dist 通常 < 40MB 总大小；
     - `nginx -g "daemon off;"` 让 Nginx 前台跑，容器 PID 1 直接就是 nginx。

2. **配套 `nginx.conf`**（5 分钟）：
   ```nginx
   server {
       listen 80;
       server_name _;

       root  /usr/share/nginx/html;
       index index.html;

       location / {
           try_files $uri $uri/ /index.html;
       }

       location /api/ {
           proxy_pass http://backend:8080/;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }

       gzip on;
       gzip_types text/plain text/css application/json application/javascript;
   }
   ```
   - `try_files $uri $uri/ /index.html`：先找真实文件、再找目录、都没有兜底给 index.html——SPA 路由的救命；
   - `proxy_pass http://backend:8080/`：`backend` 是**容器名**（需要和后端在同一个 Docker 网络），末尾 `/` 会把 `/api/xxx` 重写成 `/xxx` 转发；
   - gzip 压缩省流量。

3. **`.dockerignore` 前端版**（2 分钟）：
   ```text
   .git
   node_modules
   dist
   .env
   .env.local
   .vscode
   .DS_Store
   ```
   - `node_modules` 必须挡——本地那份可能是 Windows / Mac 版，进 Linux 容器直接坏；
   - `dist` 挡本地已有产物，Docker 内 pnpm build 从头来。

4. **镜像大小优化四板斧**（2 分钟）：
   - 板书：
     ```
     ① 基础镜像用 alpine / slim
     ② 多阶段丢弃构建工具（Node / Maven）
     ③ RUN 合并 + 清缓存（npm cache clean、apt rm）
     ④ .dockerignore 拒无关文件
     ```
   - 目标：后端 < 250MB、前端 < 40MB。

#### 案例演示（14 分钟）

案例 1：**构建 + 验证**（5 分钟）
- 目录：
  ```
  yoga-web/
  ├── Dockerfile
  ├── nginx.conf
  ├── .dockerignore
  ├── package.json
  ├── pnpm-lock.yaml
  └── src/  public/  vite.config.ts  ...
  ```
- `docker build -t yoga-web:1.0.0 .`；
- `docker run -d --name yoga-web -p 80:80 yoga-web:1.0.0`；
- 浏览器 `http://localhost/` 打开——**首页出**。刷新几个二级路由（`/courses` / `/students`）都能命中 SPA fallback。
- 打 `/api/xxx` 会 502——因为还没起 backend 容器；下一天用 compose 联通。

案例 2：**镜像分层可视化**（5 分钟）
- `docker history yoga-web:1.0.0` 看每一层的 SIZE；
- 前端镜像典型层：
  ```
  nginx 基础镜像层 ≈ 45MB
  + COPY nginx.conf     ≈ 1KB
  + COPY --from=builder dist ≈ 8MB
  = 总 ≈ 53MB
  ```
- 让学生看到「dist 才 8MB」——但如果没多阶段、把 Node 也带进来就是 60+53 ≈ 113MB。

案例 3：**镜像大小三档对比**（4 分钟）
- 让学生把基础镜像换三档跑三次 build：
  ```
  node:20        → Stage 1 镜像 1.1GB（含完整 Debian）
  node:20-slim   → Stage 1 镜像 240MB
  node:20-alpine → Stage 1 镜像 60MB
  ```
- 讲解「最终 Stage 2 都不含这一层，所以选哪个只影响构建速度和 npm install 兼容性」，alpine 有时因 musl libc 差异装原生模块（如 sharp）失败——`slim` 是折中方案。

#### 小结（3 分钟）

```
前端两阶段：node 打包 → nginx 托管
nginx.conf 三件事：静态 · SPA fallback · /api 反代
四板斧优化：alpine · 多阶段 · RUN 合并 · dockerignore
🔴 try_files $uri $uri/ /index.html
🔴 proxy_pass 末尾 /
下一天：docker compose 一次拉起 mysql/redis/backend/web
```

#### 作业布置（3 分钟）
1. 给 `yoga-web` 项目写多阶段 Dockerfile + `nginx.conf` + `.dockerignore`，构建 `yoga-web:1.0.0`；
2. `docker run` 起来后浏览器打开首页正常，二级路由刷新不 404；
3. `docker images yoga-web:1.0.0` 记录大小，目标 < 60MB；
4. 综合作业：整理 Day16 全部 6 个课时的关键命令，用 AI 生成一份 `docker-cheatsheet.md`（不超过 2 页 A4）。

### 6.4 板书设计

```
┌── Day16 · 第 6 课时 · Vue 镜像 + 优化 ─────────────────┐
│                                                        │
│  Stage 1  builder                                       │
│    FROM node:20-alpine AS builder                       │
│    WORKDIR /build                                       │
│    COPY package.json pnpm-lock.yaml ./                  │
│    RUN pnpm i --frozen-lockfile                         │
│    COPY . .                                             │
│    RUN pnpm build                                       │
│                                                        │
│  Stage 2  runtime                                       │
│    FROM nginx:1.27-alpine                              │
│    COPY nginx.conf /etc/nginx/conf.d/default.conf      │
│    COPY --from=builder /build/dist /usr/share/nginx/html│
│    EXPOSE 80                                            │
│    CMD ["nginx","-g","daemon off;"]                    │
│                                                        │
│  nginx.conf 三件事：                                    │
│    root + index                                        │
│    try_files $uri $uri/ /index.html   ← SPA           │
│    location /api/  proxy_pass ... /   ← 反代          │
│                                                        │
│  优化四板斧：                                           │
│    alpine · 多阶段 · RUN 合并 · dockerignore           │
│  目标：后端 < 250MB · 前端 < 40MB                       │
│                                                        │
│  🔴 SPA fallback · 🔴 proxy_pass 末尾 /                │
└────────────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. 给 `yoga-web` 完整写 Dockerfile + `nginx.conf` + `.dockerignore`，构建 `yoga-web:1.0.0`，`docker run` 通、首页 + 二级路由刷新都正常；
2. 记录三档基础镜像（`node:20` / `node:20-slim` / `node:20-alpine`）构建后的镜像大小；
3. 综合复盘：把整个 Day16 的 6 个课时抽象出「Docker 命令速查」+「Dockerfile 骨架模板」两份文档提交。

### 6.6 教学反思提示
- 学生常见坑：忘了写 `try_files` → 首页能开、刷 `/courses` 404，一定要现场演示复现一次；
- `proxy_pass` 的斜杠陷阱要**画图**讲——请求路径 `/api/user/list` 在带斜杠 / 不带斜杠情况下分别传给后端的 URL 差异；
- alpine 装 native 模块失败：如果学生用 sharp、node-canvas 等，讲一下换 `node:20-slim` 或 `RUN apk add --no-cache python3 make g++`；
- 最后一节课的时间要给学生留 5-8 分钟自测——把 6 个课时的动手成果串起来跑一遍：MySQL 容器 + Redis 容器 + yoga-backend 镜像 + yoga-web 镜像同时在 `docker ps` 里，为 Day17 compose 铺路；
- 布置作业时明确「Day17 会用 compose 把这四个容器拉到一张网络里做联调」，让学生带着期待走。

---

## Day16 整体教学反思

- 6 个课时循序渐进：**命令 → 概念 → 数据 → 语法 → 后端镜像 → 前端镜像**，每两个课时形成一个「用别人的镜像」→「造自己的镜像」的闭环；
- 时间分配建议：如果学生第 1 课时装机卡壳（Docker Desktop / WSL2 / apt 冲突）超过 20 分钟，把「案例演示」压缩到 8 分钟保底进度；
- 版本一致性：全部代码示例都锚定 Docker 24+ / JDK 25 / Node 20 LTS / Nginx 1.27-alpine / MySQL 8 / Redis 8-alpine——授课前跑一遍所有命令确认能出结果；
- 与 Day15 的关系：Day15 是「宿主机 apt 装」，Day16 是「Docker 装同一份东西」，让学生亲历「手工 → 容器化」的迁移，为 Day17 compose 与 Day18 生产化部署做技术栈铺垫；
- 学生分层：能力强的学生可以提前研究 BuildKit `--mount=type=cache` 加速依赖缓存、`docker buildx` 多架构构建；基础弱的重点保证「一条 `docker run` 起 MySQL」+「一份多阶段 Dockerfile 打 jar」两个能落地的成果。
