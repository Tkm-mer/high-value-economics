# 《AI 应用 Web 开发》 - 教师教案（Day14：课程管理前端 + 表单校验体系 + 系统日志前端）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day13 的学生（掌握 Spring Boot 4.0.x 后端全链路、JWT 登录、AOP 操作日志、课程 / 教练 / 教室后端接口、Vue 3 工程化、VueRouter 4、Axios 二次封装、Pinia、Element Plus 按需引入、PageContainer / SearchBar / ProTable 三件套、会员管理前端）**
**知识点覆盖：** 第 27 章 课程管理前端页面（列表页 + 独立路由编辑页 + 级联下拉 + 冲突预检） + 第 28 章 表单校验体系与系统日志前端（Element Plus 校验分层、`validators.ts` 抽取、系统日志页面、JSON 美化、CSV 导出、Axios 全局异常处理）

**技术版本基线**：Node.js 20 LTS / pnpm 9.x / Vue 3.5.x / Vite 5.x / TypeScript 5.x / vue-router 4.x / pinia 3.x / axios 1.7+ / element-plus 3.x / @vueuse/core 10.x / dayjs 1.11+ / IDEA 2024.3+ / VS Code / 通义灵码 + Trae。

**Day14 主线**：Day13 我们已经把会员管理这条业务线完整搬进 `yoga-admin` 前端——一份「列表 + 弹窗表单」的 CRUD 模板；但真实项目里，课程这类实体的字段数是会员的两倍、外键关联三方、还带时段冲突这样的业务级校验，一个弹窗根本装不下。Day14 前 3 个课时把**课程管理前端**从零落地：先把「列表页 + 多条件搜索 + 关联展示」的骨架搭起来（第 1 课时），再把独立路由的**编辑页**与「科目 → 教练」级联下拉、教室下拉、日期时段选择器一起交付（第 2 课时），最后把课程发布 / 下架 / 单删 / 批删的**业务确认弹窗**接上第 15-16 章后端（第 3 课时）。中间 1 个课时（第 4 课时）把 Element Plus 的**表单校验体系**做一次系统性总结——分层图 + 内置规则 + 异步 `validator` + 跨字段校验 + 抽取到 `utils/validators.ts` 的团队级复用。第 5 课时把**系统操作日志**页面落地：对接 Day10 交付的 `/op-logs` 后端，时间区间 + 状态 + 模块过滤，抽屉详情页展示 JSON 美化的请求参数、返回结果、异常堆栈，附带 CSV 导出。最后 1 个课时把「前端异常处理体系」补齐——Axios 拦截器统一处理 401 / 403 / 500 / 网络错误，`ElMessage` 与 `ElNotification` 的语义分工、`toastErr` 工具函数、页面级 `try-catch` 与全局 `unhandledrejection` 兜底。Day14 结束后，`yoga-admin` 前端管理后台已经覆盖了「会员 / 课程 / 教练 / 教室 / 日志」全部业务模块，具备完整的**校验 + 反馈 + 审计**能力，可以作为一个真实可交付的管理端产品。

---

## 第 1 课时：课程列表页 —— 多条件搜索与关联展示

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出「课程列表页」在字段维度、关联对象、时间语义、状态流转、校验复杂度、交互形态六个方面比会员管理复杂的差异表；
2. 能定义完整的 `CourseVO` / `CourseFormDTO` / `ConflictVO` TypeScript 接口，并写出 `src/api/course.ts` 中 `page / detail / create / update / publish / offline / remove / checkConflict` 八个方法；
3. 能在 `CourseListView.vue` 中使用 `SearchBar` 组合出「课程名 + 科目 + 教练 + 状态 + 开课时段」5 个筛选条件，并说清 `dateRange` 拆成 `startBegin / startEnd` 两个 query 参数的原因；
4. 能使用 `ProTable` 完成列表渲染，配置 `selection / prop / min-width / fixed / 自定义 template` 五种列类型；
5. 能实现「报名进度」`enrolled / capacity` 满员橙色高亮的 `class` 绑定，理解 `:class="{ full: row.enrolled >= row.capacity }"` 的对象式写法；
6. 能在 `onMounted` 中用 `Promise.all` 并发拉取「科目字典 + 教练字典」，并用 `toastErr` 统一处理失败。

#### 1.1.2 过程与方法目标
1. 通过与 Day13 会员管理页的**结构对照**，让学生把已掌握的模板复用出来，聚焦在「新东西」上，降低认知负担；
2. 通过「先搭骨架再填肉」的迭代方式，训练分层实现的工程习惯——先让空表格能翻页，再补搜索，再补关联渲染，避免一上来就写 300 行。

### 1.2 教学重难点
- **重点**：`CourseVO` 中「id + 冗余字段」的建模思路（`subjectId + subjectName` 一起返回，避免前端二次查字典）／`SearchBar` + `ProTable` 的 `q` 对象共享／`dateRange` 用 `watch` 拆分到 `q.startBegin / q.startEnd`／状态字典 `COURSE_STATUS` 的集中管理（`{ label, type }`）
- **难点**：**冗余字段** vs **前端字典 join** 两种做法的取舍——后端 join 一次省掉 N 次前端翻译，但字段变化不敏感；本项目选后端 join／`el-table-column` 中 `template #default="{ row }"` 的解构写法与 slot 作用域数据流／状态过滤器 `+k` 强制转 number 的原因（`el-select` 的 value 保留字符串会导致后端类型不匹配）／`filterable` 教练下拉的搜索性能考虑

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
用 Day13 结尾学生刚跑通的会员管理页对照今天的目标——同样是列表 + CRUD，但打开 UED 给的高保真原型，让学生自己数一数课程页有多少个筛选条件、多少列、编辑弹窗如果塞 15 个字段有多别扭。抛出结论：**课程页要拆成「列表页 + 独立路由编辑页」，本节课先把列表骨架搭出来**。板书打出六维对比表：

```
维度         会员         课程
字段数       8            15+
关联对象     无           科目 / 教练 / 教室
时间字段     生日          开课~结束 + 报名截止
状态流转     正常/冻结    未发布→报名中→已满→已开课→已结束
校验复杂度   字段级       字段级 + 业务级冲突检测
交互形态     单弹窗       弹窗新增 + 独立路由编辑页
```

#### 新知讲授（12 分钟）

1. **API 层定义**（4 分钟）：`src/api/course.ts` 里把 8 个方法和 3 个 TS 接口先摆出来。强调 `CourseVO` 里冗余带 `subjectName / coachName / roomName`——这是**后端 join 一次**，前端不再翻译。`CourseFormDTO` 里的 `timeRange: [string, string]` 是**前端表单专用**，提交时会拆成 `startTime / endTime`。`ConflictVO` 结构 `{ coachConflict?, roomConflict? }` 承载后端预检返回。

2. **列表页字段规划**（4 分钟）：**5 个筛选条件**：课程名（模糊）、科目（select）、教练（filterable select）、状态（枚举 select）、开课时段（daterange）。**9 列表格**：多选、课程名（跳编辑）、科目、教练、教室、时间、报名进度（满员高亮）、价格、状态 tag、操作。所有列宽都是**斟酌过的**——`min-width` 用于主要展示列，`width` 固定宽度用于短字段，`fixed="right"` 让操作列在横向滚动时贴右。

3. **状态字典的集中管理**（4 分钟）：`@/utils/dict.ts` 中定义 `COURSE_STATUS`：

   ```ts
   export const COURSE_STATUS = {
     1: { label: '未发布', type: 'info'    },
     2: { label: '报名中', type: 'success' },
     3: { label: '已满',   type: 'warning' },
     4: { label: '已开课', type: 'primary' },
     5: { label: '已结束', type: 'info'    }
   } as const
   ```

   讲清 `as const` 的作用（把 label 和 type 收窄成字面量类型），以及 `el-select` 里 `+k` 把 Object.keys 返回的字符串强制转为 number。

#### 示例演示（15 分钟）

1. **搭列表骨架**（5 分钟）：直接把 `CourseListView.vue` 的 `<PageContainer>` + `<SearchBar>` + `<ProTable>` 骨架敲出来，`ProTable` 只挂 `:loader="courseApi.page"` 与 `:query="q"`；`q` 只带 `pageNum: 1, pageSize: 10`。启动 dev，看空数据渲染。

2. **补搜索栏 5 项**（5 分钟）：一项一项加，加一项刷新一次看效果。特别在「开课时段」这里演示 `watch(dateRange, v => { q.startBegin = v?.[0]; q.startEnd = v?.[1] })` 的写法——为什么要用 `watch` 而不是直接 `v-model="q.dateRange"`：因为后端接口约定的是两个字段。

3. **补 9 列表格 + 状态过滤 + 关联渲染**（5 分钟）：重点讲 `<template #default="{ row }">` 的解构、`row.enrolled / row.capacity` 的分数展示、`:class="{ full: ... }"` 的条件类、`el-tag :type="COURSE_STATUS[row.status].type"` 的动态类型。

#### 学生练习（8 分钟）

1. **P1（3 分钟）**：把项目里的会员管理页 `MemberListView.vue` 复制一份改名 `CourseListView.vue`，用作起手骨架；
2. **P2（3 分钟）**：把搜索栏改造成本节课要求的 5 个条件，注意「开课时段」用 `daterange`；
3. **P3（2 分钟）**：`onMounted` 里并发拉科目字典与教练字典，用 `Promise.all` + `toastErr` 兜底。

#### 提问与巡视（3 分钟）
- 关注学生的搜索栏 `q` 对象是否被 `SearchBar` 的 `@search` 事件正确 reset 到第一页；
- 常见错误：忘记给状态 `<el-select>` 的 `:value` 用 `+k`，导致 select 选中显示为字符串状态；`dateRange` 类型写成 `ref<[string,string]>()` 而 daterange 会返回 `null` 引发运行时报错。

#### 小结（3 分钟）
- 课程列表页 = SearchBar 5 项 + ProTable 9 列 + 状态字典
- 冗余字段策略：后端 join 一次，前端只渲染
- 关键差异：状态多、字段多、时段有语义、关联外键——这些是课程页比会员页复杂的**根因**

### 1.4 板书设计
```
Day14-第1课时  课程列表页
1. 差异对比：字段 / 关联 / 时段 / 状态 / 校验 / 交互
2. API：CourseVO + CourseFormDTO + ConflictVO
3. 骨架：SearchBar 5 项 + ProTable 9 列
4. 状态字典：COURSE_STATUS
5. dateRange watch 拆分
```

---

## 第 2 课时：课程新增 / 修改 —— 独立路由页 + 级联下拉

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能说清「独立路由编辑页」相较「弹窗表单」的三条选型标准：字段 >10 / 有联动预检 / 有嵌入子表；
2. 能在 `router/index.ts` 中配置 `courses/edit/:id?` 这类**可选参数**路由，并说清 `:id?` 的 `?` 使新增/编辑共用同一个组件；
3. 能实现「科目 → 教练」的**前端过滤联动**：`coachesFiltered = computed(() => coaches.filter(c => c.subjectIds?.includes(form.subjectId)))`；
4. 能写出**冲突预检**的防抖调用：`useDebounceFn(async () => await courseApi.checkConflict(...), 300)`，并在返回体上渲染 `el-alert`；
5. 能配置 `el-date-picker type="datetimerange"` 的 `value-format` 拿到字符串数组，并用 `disabled-date` 禁掉过去日期。

#### 2.1.2 过程与方法目标
1. 通过对照「弹窗方案」与「独立页方案」两种做法的**信息密度差**，让学生理解交互形态选型不是喜好而是**字段密度决定**；
2. 通过冲突预检的**防抖 + 不阻断保存**的设计，让学生体会「体验优化」与「兜底安全」的边界——前端可绕过，后端不可少。

### 2.2 教学重难点
- **重点**：路由配置 `courses/edit/:id?` 的可选参数写法／`isEdit` 与 `editId` 两个 `computed` 的分工／`onMounted` 里 `Promise.all` 并发拉字典 + 详情／`Object.assign(form, d)` 反填表单／`coachesFiltered` 的 computed 依赖／防抖冲突预检的 debounce 时长选择（300ms 是键盘操作的舒适阈值）
- **难点**：**路由复用陷阱**——同一个 `CourseEditView` 组件从 `/courses/edit/1` 跳到 `/courses/edit`（新增）时不会重新 mount，`onMounted` 不再触发；解决方案是给 `<router-view :key="$route.fullPath">`／`disabled-date: (d: Date) => d < new Date(Date.now() - 864e5)` 中减一天的用意（否则今天上午的场次也会被禁）／`onSubjectChange` 中清 `coachId` 的时机与条件（只有当前选中教练不在过滤后的列表里才清）

### 2.3 教学过程设计（45 分钟）

#### 复习（4 分钟）
上节课列表页交付了，现在点「新增课程」按钮跳到 `/courses/edit`——但页面是 404。今天补上编辑页。回顾昨天列表页里 `$router.push('/courses/edit')` 和 `$router.push('/courses/edit/${row.id}')` 两个入口，都指向同一个组件，路由带 `:id?` 让这套 UI 复用。

#### 新知讲授（12 分钟）

1. **路由配置**（3 分钟）：`router/index.ts` 里加：

   ```ts
   {
     path: 'courses/edit/:id?',
     component: () => import('@/views/course/CourseEditView.vue'),
     meta: { title: '编辑课程' }
   }
   ```

   `:id?` 的 `?` 是关键——**冒号带问号**意味着参数可选，`/courses/edit` 与 `/courses/edit/42` 都能匹配到这条路由。组件里通过 `route.params.id` 判断 `isEdit`：

   ```ts
   const isEdit = computed(() => !!route.params.id)
   const editId = computed(() => Number(route.params.id))
   ```

2. **表单结构**（5 分钟）：15 个字段拆成 4 组：
   - **基础信息组**：课程名（带 `maxlength=40 show-word-limit`）
   - **关联组**：科目 select / 教练 select（`filterable :disabled`） / 教室 select
   - **时间组**：开课时段（`datetimerange`）/ 报名截止（`datetime`，选填）
   - **业务组**：容量 `el-input-number` / 价格 / 封面 / 简介
   讲清每种控件的选型逻辑——`filterable` 为什么用在教练但不用在科目：科目 <10 个不需要搜索，教练可能有几十上百个。

3. **级联下拉的三种做法**（4 分钟）：
   - **前端过滤**（本项目）：教练列表全量拉一次，本地 `computed` 过滤；教练量 <200 时最舒适
   - **接口筛选**：每次调 `/coaches?subjectId=xx`；教练量大或权限差异时用
   - **`el-cascader`**：三层以上嵌套时用
   本项目教练是简单字典，选**前端过滤**。

#### 示例演示（15 分钟）

1. **搭编辑页骨架**（4 分钟）：先把 `<PageContainer :title="isEdit ? '编辑课程' : '新增课程'" back>` 与顶栏取消/保存按钮铺出来，`<el-form :model="form" :rules="rules" label-width="110px">` 挂上。把 `form` 的初值 `{ title: '', capacity: 20, price: 0 }` 敲进去。

2. **补关联下拉与联动**（5 分钟）：并发拉三个字典 → `coachesFiltered` computed → 教练 select 的 `:disabled="!form.subjectId"` → `onSubjectChange` 清教练。要点是 `onSubjectChange` 里的判断：

   ```ts
   function onSubjectChange() {
     if (form.coachId && !coachesFiltered.value.some(c => c.id === form.coachId)) {
       form.coachId = undefined
     }
   }
   ```

   为什么不无脑清？——如果学生同一个科目下换教练，`onSubjectChange` 不该触发，只有科目变了导致教练不在新列表里才清。

3. **冲突预检 + 提示区**（6 分钟）：`useDebounceFn` 300ms 防抖，教练/教室/时段任一变化时都触发，参数带 `id`（编辑态排除自身）。返回体用 `Object.assign(conflict, c)`，`el-alert` 分别渲染 `coachConflict` 与 `roomConflict`。演示改时间后 300ms alert 弹出的效果。

#### 学生练习（8 分钟）

1. **P1（3 分钟）**：把 `router/index.ts` 里加 `courses/edit/:id?` 路由，跑通 `/courses/edit` 页面不是 404；
2. **P2（3 分钟）**：把 15 个表单字段全部铺上，只做 UI，先不管校验和联动；
3. **P3（2 分钟）**：加 `coachesFiltered` computed，观察科目切换后教练下拉的变化。

#### 提问与巡视（3 分钟）
- 关注 `datetimerange` 的 `value-format` 是否正确设为 `'YYYY-MM-DD HH:mm'`——很多学生会漏掉这行，拿到 `Date` 对象；
- 常见错误：`Object.assign(form, d)` 之后 timeRange 没有反填成 `[d.startTime, d.endTime]`；`disabled-date` 类型错写成 `Date | null`。

#### 小结（3 分钟）
- 独立路由编辑页 = `path: '/courses/edit/:id?'` + 组件里 `isEdit` computed
- 级联下拉 = 前端 computed 过滤 + 主动清空不合法值
- 冲突预检 = 防抖 300ms + `el-alert` + 不阻断保存

### 2.4 板书设计
```
Day14-第2课时  编辑页 + 联动
1. 路由：courses/edit/:id? （可选参数）
2. 4 组字段：基础 / 关联 / 时间 / 业务
3. 级联：coachesFiltered = computed
4. onSubjectChange：只清不合法的 coachId
5. 冲突预检：useDebounceFn 300ms + el-alert
```

---

## 第 3 课时：课程删除 + 业务确认（发布 / 下架 / 单删 / 批删）

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能使用 `ElMessageBox.confirm` 生成语义化的**业务确认弹窗**：发布用 `type: 'success'`，下架用 `type: 'warning'`，删除加 `confirmButtonClass: 'el-button--danger'`；
2. 能实现单条 / 批量两种删除路径，并说清「按钮 `disabled` 联动 `selected.length`」是防止空选提交的第一道防线；
3. 能设计**保存路径中的冲突二次确认**——`if (conflict.coachConflict || conflict.roomConflict)` 再弹一次 confirm；
4. 能配置**按状态显示 / 隐藏按钮**：`v-if="row.status===1"` 只有未发布才能发布，`v-if="[2,3].includes(row.status)"` 只有报名中/已满才能下架，杜绝非法操作路径；
5. 能在保存成功后用 `router.replace('/courses')` 返回列表并触发刷新。

#### 3.1.2 过程与方法目标
1. 通过对照「灰按钮 vs 隐藏按钮」两种做法，让学生理解**权限性**与**状态性**的按钮显隐差异——权限相关灰按钮，业务状态相关直接隐藏；
2. 通过 `ElMessageBox` 的 reject 分支必须 `catch(()=>{})`，让学生养成「所有 async 都要处理拒绝」的严谨习惯。

### 3.2 教学重难点
- **重点**：`ElMessageBox.confirm` 的三种 type 语义／`confirmButtonClass` 让删除按钮变红／`selected.length` 与批删按钮 disabled 联动／保存路径中的双重确认（表单校验 + 冲突二次确认）／`router.replace` vs `router.push` 的区别（编辑保存后不该在浏览器历史里留下编辑页）
- **难点**：**`ElMessageBox` 的 reject 一定要 `catch`**，否则控制台一堆红字警告——这在生产上会被监控系统误报／保存失败时 `saving.value = false` 必须走 `finally`（try 里 return 前不能忘记）／`await courseApi.remove([row.id])` 单删也要用数组，因为后端接口统一

### 3.3 教学过程设计（45 分钟）

#### 复习（3 分钟）
上节课编辑页把表单和联动做完了，还差保存按钮真的调后端。今天把删除、发布、下架、批删这些**业务动作**接上，同时把编辑页的保存流打通。

#### 新知讲授（10 分钟）

1. **业务确认的三种语义**（4 分钟）：
   - **发布**：`type: 'success'` + 「确认发布『课程 A』？」文案，绿勾图标
   - **下架**：`type: 'warning'` + 「下架后无法再报名，确认下架？」文案，黄叹号图标
   - **删除**：`type: 'warning'` + `confirmButtonClass: 'el-button--danger'` + 「确认删除？」文案，红色确认按钮
   核心是让用户**看到图标就知道后果**，减少误点损失。

2. **按状态显示按钮**（3 分钟）：
   ```vue
   <el-button v-if="row.status===1" @click="onPublish">发布</el-button>
   <el-button v-if="[2,3].includes(row.status)" @click="onOffline">下架</el-button>
   ```
   为什么用 `v-if` 而不是 `:disabled`？——业务状态触发的操作**只在特定状态可用**，其他状态下按钮存在只会让 UI 变胖并诱导误操作；权限相关（比如「非管理员看不到」）才用 disable + tooltip。

3. **保存路径的双重确认**（3 分钟）：
   ```ts
   const ok = await formRef.value?.validate().catch(() => false)
   if (!ok) return
   if (conflict.coachConflict || conflict.roomConflict) {
     await ElMessageBox.confirm('存在冲突，仍要保存吗？', '确认冲突', { type: 'warning' })
   }
   ```
   第一层拦字段校验错误；第二层拦冲突。任一 reject 都会抛错，`await` 自然跳出。

#### 示例演示（16 分钟）

1. **`onPublish / onOffline / onDelete` 三兄弟**（6 分钟）：
   ```ts
   async function onPublish(row: CourseVO) {
     await ElMessageBox.confirm(`确认发布「${row.title}」？`, '发布确认', { type: 'success' })
     try {
       await courseApi.publish(row.id)
       ElMessage.success('发布成功')
       tableRef.value?.refresh()
     } catch (e) { toastErr(e) }
   }
   ```
   三个方法几乎一模一样，差别只在 confirm 文案 / type 和调用的 api。演示三个按钮点击 → confirm 弹窗 → 后端接口 → 列表刷新的完整链路。

2. **批删**（4 分钟）：
   ```ts
   async function onBatchDelete() {
     const ids = selected.value.map(c => c.id)
     await ElMessageBox.confirm(`即将删除 ${ids.length} 门课程，是否继续？`, '批量删除', { type:'warning' })
     try { await courseApi.remove(ids); ElMessage.success('已删除'); tableRef.value?.refresh() }
     catch (e) { toastErr(e) }
   }
   ```
   讲清「按钮 `disabled` 依赖 `selected.length`」是第一道防线，弹窗里显示数字是第二道，最后后端还要做权限校验是第三道。

3. **编辑页保存链路**（6 分钟）：`submit()` 完整流程 → validate → 冲突二次确认 → 组装 DTO（`timeRange` 拆成 `startTime / endTime`） → 判断 create/update → success 提示 → `router.replace('/courses')`。重点强调 `saving.value` 与 `finally` 的搭配。

#### 学生练习（7 分钟）

1. **P1（3 分钟）**：把 `onPublish / onOffline / onDelete` 三个函数写完，点击真的能改后端状态；
2. **P2（2 分钟）**：把批删接上，观察 `selected.length` 与按钮 disabled 的联动；
3. **P3（2 分钟）**：编辑页保存按钮接通，走一次「新增课程 → 列表出现新行」。

#### 提问与巡视（3 分钟）
- 关注 ElMessageBox reject 分支是否被吞掉——学生经常忘记 `.catch(()=>{})`，控制台一片红警告；
- 常见错误：`router.push` 而不是 `router.replace`，浏览器返回按钮回到编辑页；批删按钮上没有 `:disabled="!selected.length"`，点空的会报后端异常。

#### 小结（3 分钟）
- 业务确认 = ElMessageBox.confirm + 语义化 type + 关键文案
- 状态相关按钮用 `v-if` 直接隐藏
- 保存 = validate → 冲突二次确认 → API → replace 返回
- 单删/批删共用后端接口 `remove(ids[])`

### 3.4 板书设计
```
Day14-第3课时  业务动作
1. confirm 三色：success 发布 / warning 下架 / danger 删除
2. v-if 按状态显隐
3. 保存双重确认：校验 + 冲突
4. router.replace 返列表
5. selected.length 联动 disabled
```

---

## 第 4 课时：Element Plus 表单校验体系（同步 + 异步 + 自定义）

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能画出**六层校验分层图**：前端字段级 → 前端跨字段 → 前端预检 → 后端字段级 → 后端业务级 → DB 约束，并说清每层的职责与代价；
2. 能罗列 Element Plus `FormItemRule` 的 10 个常用字段：`required / type / min / max / len / pattern / enum / whitespace / message / trigger`；
3. 能写出三种 `validator` 风格（callback / Promise / 同步 return）并说清「Promise 风格根治 `callback()` 忘调这个经典坑」；
4. 能实现**跨字段校验**：以「二次密码」为例，用 `watch(() => form.password, () => formRef.value?.validateField('password2'))` 触发被依赖字段重新校验；
5. 能把公共校验规则抽到 `@/utils/validators.ts`：`phoneRule / idCardRule / strongPasswordRule / urlRule` 常量 + `required(label) / lenRange(min,max) / uniqueRule(check)` 工厂函数；
6. 能改造 Day13 的会员表单，把手机号规则从内嵌切换成 `uniqueRule(memberApi.checkPhone)`，体验**校验规则去重**的收益。

#### 4.1.2 过程与方法目标
1. 通过「前端可绕过，后端不可少」这条铁律，让学生理解校验体系的**冗余**不是重复劳动而是防御性架构；
2. 通过 `validators.ts` 的抽取过程，训练「重复三次以上就抽公共模块」的重构直觉。

### 4.2 教学重难点
- **重点**：六层校验分层图与职责／`FormItemRule` 常用字段 10 项／三种 `validator` 风格的差异／跨字段校验的 `validateField` 主动触发／`validators.ts` 的常量 + 工厂函数模式
- **难点**：**`callback()` 忘调导致 validate 永远 pending 这个坑**——推荐一律用 Promise 风格根治／**异步 validator 竞态**——用户快速改字段时早请求晚返回覆盖新答案，需要用 seq 或最新一次生效的策略／`type: 'array'` + `required: true` 与「至少选 1 项」的语义等价

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
课程编辑页里我们已经写了 6-7 条校验规则，但都是零散铺在组件里。今天做一次系统总结，把校验分层图讲清、把项目里已经写过 3 次的手机号规则抽出来。

#### 新知讲授（14 分钟）

1. **六层校验分层图**（5 分钟）：

   ```
   用户输入 → 前端字段级（rules）→ 前端跨字段（validator）→ 前端预检 API →
   提交 → 后端 JSR-303 → 后端业务规则 → DB 约束（唯一 / FK）
   ```

   每层职责与代价：

   | 层级 | 谁负责 | 例子 | 代价 |
   |-----|-------|-----|------|
   | 前端字段级 | rules | 手机号格式 | 0 网络 |
   | 前端跨字段 | validator | 结束>开始 | 0 网络 |
   | 前端预检 | API | 手机号已注册 | 1 次请求 |
   | 后端字段级 | JSR-303 | @Pattern | 后端处理 |
   | 后端业务级 | Service | 冲突检测 | 后端处理 |
   | DB 约束 | Unique/FK | 唯一索引 | DB 处理 |

   铁律：**前端提升体验，后端兜住安全**。

2. **`FormItemRule` 常用字段**（4 分钟）：

   ```ts
   const rule: FormItemRule = {
     required: true,                   // 必填
     type:     'string' | 'number' | 'array' | 'date' | 'email' | 'url',
     min:      2, max: 20,
     len:      11,                     // 精确长度
     pattern:  /^1[3-9]\d{9}$/,
     enum:     ['A','B'],
     whitespace: true,
     message:  '请输入姓名',
     trigger:  'blur' | 'change' | ['blur','change'],
     validator: (rule, value, callback) => { ... }
   }
   ```

   多规则组合按数组顺序执行；一旦前一条 reject，后一条不再执行。

3. **三种 validator 风格**（5 分钟）：
   - **callback 风格**（老 API）：`callback()` 通过；`callback(new Error(...))` 失败；**忘调等于永远 pending**
   - **Promise 风格**（推荐）：`throw new Error(...)` 失败；正常 return 通过
   - **同步 return**：仅 boolean，无自定义消息

   现场演示一个 callback 忘调导致 `validate()` 挂起的例子，然后改成 Promise 风格解决。

#### 示例演示（16 分钟）

1. **跨字段校验：二次密码**（5 分钟）：

   ```ts
   const rules: FormRules = {
     password:  [{ required: true, min: 8, trigger: 'blur' }],
     password2: [{ required: true, trigger: 'blur' },
                 { validator: (_r,v) => {
                     if (v !== form.password) throw new Error('两次密码不一致')
                   }, trigger: 'blur' }]
   }
   watch(() => form.password, () => {
     if (form.password2) formRef.value?.validateField('password2')
   })
   ```

   核心是 `watch` 里主动 `validateField('password2')`——被依赖字段变了必须**主动触发**依赖字段重新校验。

2. **抽 `validators.ts`**（6 分钟）：把项目里已经出现过 3 次的手机号规则、身份证规则、URL 规则挪进 `src/utils/validators.ts`：

   ```ts
   export const phoneRule: FormItemRule = {
     pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur'
   }
   export const idCardRule: FormItemRule = { pattern: /* 18位 */, ... }
   export const strongPasswordRule: FormItemRule = {
     validator: (_r, v) => {
       if (!v) return
       if (v.length < 8) throw new Error('至少 8 位')
       if (!/[A-Z]/.test(v)) throw new Error('需包含大写字母')
       if (!/[a-z]/.test(v)) throw new Error('需包含小写字母')
       if (!/\d/.test(v))    throw new Error('需包含数字')
     }, trigger: 'blur'
   }
   export const required = (label: string, trigger: FormItemRule['trigger'] = 'blur'): FormItemRule =>
     ({ required: true, message: `请输入${label}`, trigger })
   export const lenRange = (min: number, max: number): FormItemRule =>
     ({ min, max, message: `${min}~${max} 字符`, trigger: 'blur' })
   export function uniqueRule(check: (v:any) => Promise<boolean>, message = '已存在'): FormItemRule {
     return {
       trigger: 'blur',
       validator: async (_r, v) => {
         if (!v) return
         const exists = await check(v)
         if (exists) throw new Error(message)
       }
     }
   }
   ```

3. **改造会员表单**（5 分钟）：把 Day13 的 `MemberEditView` 里的 `rules` 拆成两版对比：

   **改造前**：
   ```ts
   phone: [
     { required: true, message: '请输入手机号', trigger: 'blur' },
     { pattern: /^1[3-9]\d{9}$/, message: '格式不对', trigger: 'blur' },
     { validator: async (_r, v) => {
         if (!v) return
         const e = await memberApi.checkPhone(v)
         if (e) throw new Error('已注册')
       }, trigger: 'blur' }
   ]
   ```

   **改造后**：
   ```ts
   phone: [required('手机号'), phoneRule, uniqueRule(memberApi.checkPhone, '手机号已注册')]
   ```

   一目了然。

#### 学生练习（8 分钟）

1. **P1（3 分钟）**：新建 `src/utils/validators.ts`，落地 phoneRule / required / lenRange / uniqueRule 四个工具；
2. **P2（3 分钟）**：把会员表单的 rules 全部改成新工具调用；
3. **P3（2 分钟）**：给注册页加二次密码校验 + watch 触发 validateField。

#### 提问与巡视（3 分钟）
- 关注 uniqueRule 是否使用了 Promise 风格；
- 常见错误：`throw` 抛的不是 `new Error(...)` 而是字符串，导致 message 显示 undefined；`watch` 忘写触发 validateField，改前一个字段后一个字段红字不消失。

#### 小结（3 分钟）
- 校验分六层：前端 3 层体验 + 后端 3 层安全
- validator 一律 Promise 风格
- 跨字段：watch + validateField
- 公共规则抽 validators.ts

### 4.4 板书设计
```
Day14-第4课时  校验体系
1. 六层图：字段/跨字段/预检 - JSR303/业务/DB
2. FormItemRule 10 字段
3. validator：callback / Promise / return
4. 跨字段：watch + validateField
5. validators.ts：常量 + 工厂函数
```

---

## 第 5 课时：系统日志前端页面（对接 AOP + 时间区间 + 导出）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能定义 `OpLogVO` 接口的 15 个字段（`operator / operatorRealName / module / action / method / uri / params / result / error / ip / costMs / status / createTime` 等）并对应 Day10 的后端 `tb_op_log` 表；
2. 能实现 `OpLogListView.vue` 的搜索栏（操作人 / 模块 / 状态 / 时间区间）与 9 列表格（时间可排序 / 操作人双行 / 方法 tag + uri / IP / 耗时 >500ms 橙色 / 状态 tag）；
3. 能用 `el-drawer` + `el-descriptions` + `el-tabs` 三段式做**详情抽屉**，通过 `defineExpose({ open })` 让父组件命令式调用；
4. 能封装通用 `JsonBlock.vue` 组件：`JSON.parse` 美化 + 失败回退原文 + 复制按钮 + 折叠开关；
5. 能实现 **CSV 导出**：`responseType: 'blob'` + `URL.createObjectURL` + `<a download>` + `revokeObjectURL`。

#### 5.1.2 过程与方法目标
1. 通过对接 Day10 的 AOP 日志，让学生看到**前后端全链路**——切面采集 → 落库 → 前端查询 → 导出——的完整闭环；
2. 通过 `JsonBlock` 的**回退设计**（`JSON.parse` 失败仍能显示原文），训练防御性编程直觉。

### 5.2 教学重难点
- **重点**：`OpLogVO` 15 字段建模／搜索栏 4 项 + `timeRange` watch 拆分／`method` 与 tag 类型映射（GET-info / POST-success / PUT-warning / DELETE-danger）／`costMs > 500` 橙色高亮／详情抽屉的 `defineExpose({ open })` 命令式接口／`JsonBlock` 的 `raw` 字符串 + `JSON.parse` 美化 + 回退／CSV 导出的 4 行式套路
- **难点**：**`JSON.parse` 失败要回退**——参数可能不是 JSON（如短参数字符串）／**`navigator.clipboard` 非 https 域名 undefined**——用 `document.execCommand('copy')` 兜底／**CSV 中文乱码**——后端写 BOM `\uFEFF` 头或前端拼接／**日志表大时 OFFSET 分页越翻越慢**——游标分页 + 前端「加载更多」的备选方案

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
Day10 我们已经用 `@OperationLog` 切面把每次会员/课程操作都落进 `tb_op_log` 表。今天把这些日志**可视化**——不然运维要 SSH 到服务器 `SELECT * FROM tb_op_log`，一是不方便，二是给他们数据库权限风险大。用一句话总结今天：**让每次后台点击的痕迹都能被审计和追溯**。

#### 新知讲授（12 分钟）

1. **`OpLogVO` 建模**（4 分钟）：

   ```ts
   export interface OpLogVO {
     id: number
     operator: string
     operatorRealName: string
     module: string
     action: string
     method: string          // POST/GET/...
     uri: string
     params: string          // JSON 字符串（可能很长）
     result?: string
     error?: string
     ip: string
     costMs: number
     status: 1 | 2           // 1 成功 2 失败
     createTime: string
   }
   export const opLogApi = {
     page:   (q) => request.get('/op-logs', { params: q }),
     detail: (id) => request.get(`/op-logs/${id}`),
     remove: (ids) => request.delete('/op-logs', { data: ids }),
     exportCsv: (q) => request.get('/op-logs/export', { params: q, responseType: 'blob' })
   }
   ```

2. **列表布局要点**（4 分钟）：
   - **可排序时间列**：`prop="createTime" sortable="custom"`，让运维快速按最近查
   - **操作人双行**：`{{ realName }} <span style="color:#999">({{ operator }})</span>`
   - **method + uri 一列**：tag 涂色 + 灰色 URI，节省列宽
   - **耗时高亮**：`class="slow"` 用 CSS `color:#E6A23C` 醒目提示慢接口
   - **状态 tag**：成功绿失败红

3. **CSV 导出四步式**（4 分钟）：
   ```ts
   async function onExport() {
     const blob = await opLogApi.exportCsv(q) as any as Blob
     const url = URL.createObjectURL(blob)
     const a = document.createElement('a')
     a.href = url; a.download = `op-logs-${Date.now()}.csv`
     a.click()
     URL.revokeObjectURL(url)
   }
   ```
   强调 `revokeObjectURL` 释放内存；文件名带时间戳避免同名覆盖。

#### 示例演示（15 分钟）

1. **搭列表 + 4 项搜索**（5 分钟）：直接把 `OpLogListView.vue` 铺开，`SearchBar` 挂 operator / module / status / timeRange。`timeRange` 用 `type="datetimerange"` 精确到秒，与后端日志时间精度对齐。

2. **详情抽屉**（6 分钟）：

   ```vue
   <el-drawer v-model="visible" title="操作日志详情" size="640" :destroy-on-close>
     <el-descriptions :column="2" border size="small">
       <el-descriptions-item label="时间">{{ data.createTime }}</el-descriptions-item>
       <el-descriptions-item label="耗时">{{ data.costMs }} ms</el-descriptions-item>
       ...
     </el-descriptions>
     <el-tabs style="margin-top:12px">
       <el-tab-pane label="请求参数"><JsonBlock :raw="data.params"/></el-tab-pane>
       <el-tab-pane label="返回结果" v-if="data.result"><JsonBlock :raw="data.result"/></el-tab-pane>
       <el-tab-pane label="异常信息" v-if="data.error"><pre class="err">{{ data.error }}</pre></el-tab-pane>
     </el-tabs>
   </el-drawer>
   ```

   父组件通过 `drawerRef.value?.open(row.id)` 命令式调用，`defineExpose({ open })` 暴露。

3. **`JsonBlock.vue`**（4 分钟）：

   ```ts
   const pretty = computed(() => {
     if (!props.raw) return '(空)'
     try { return JSON.stringify(JSON.parse(props.raw), null, 2) }
     catch { return props.raw }
   })
   ```

   核心两点：`try...catch` 回退原文；复制用 `navigator.clipboard.writeText` + `catch` 兜底提示。

#### 学生练习（8 分钟）

1. **P1（3 分钟）**：`src/api/opLog.ts` 完成接口层；
2. **P2（3 分钟）**：`OpLogListView.vue` 列表页跑通，能看到 Day10 落的那些日志；
3. **P3（2 分钟）**：详情按钮打开抽屉，参数 tab 里看到 JSON 美化。

#### 提问与巡视（3 分钟）
- 关注 `JsonBlock` 是否处理了 `raw` 为空字符串的情况；
- 常见错误：CSV 中文乱码——需要后端 BOM 头；`navigator.clipboard` 在 http 环境报错。

#### 小结（3 分钟）
- 日志页 = 4 项搜索 + 9 列表格 + 详情抽屉 + CSV 导出
- `JsonBlock` 通用组件：parse 美化 + 回退原文
- 命令式抽屉：`defineExpose({ open })`
- CSV 导出四步：blob → URL → a.click → revoke

### 5.4 板书设计
```
Day14-第5课时  系统日志前端
1. OpLogVO 15 字段
2. 搜索 4 项 + 表格 9 列
3. 抽屉 = descriptions + tabs
4. JsonBlock：parse + 回退
5. CSV：blob → objectURL → a.click → revoke
```

---

## 第 6 课时：前端异常处理体系 + 友好提示

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能画出**前端异常四层处理**：Axios 响应拦截器 → API 层 try-catch → 组件层 `toastErr` → 全局 `unhandledrejection`；
2. 能在 `request.ts` 里实现响应拦截器：`response.data.code === 200` 通过，非 200 抛 `BizError`；HTTP 状态码 401 / 403 / 500 / 网络错误分别处理；
3. 能说清 `ElMessage` 与 `ElNotification` 的**语义分工**：Message 用于短反馈（成功/警告/普通错误），Notification 用于**长内容 / 需要用户注意 / 富文本**；
4. 能写一个通用 `toastErr(e)` 工具函数：识别 `BizError` / `AxiosError` / 普通 Error / 未知错误，分别用合适的组件提示；
5. 能在 `main.ts` 挂全局 `window.addEventListener('unhandledrejection', ...)` 兜底所有漏网 Promise 拒绝。

#### 6.1.2 过程与方法目标
1. 通过对照「每个组件写 try-catch」与「拦截器 + toastErr」两种方式，让学生看到**统一处理**的代码密度收益；
2. 通过全局 `unhandledrejection` 兜底，训练学生「所有异常都要有归宿」的架构思维。

### 6.2 教学重难点
- **重点**：响应拦截器的**双层错误**分支（业务码非 200 抛 BizError / HTTP 层网络错误）／`ElMessage` 用于短反馈、`ElNotification` 用于长内容或需强调的错误／`toastErr` 的类型分支识别／`unhandledrejection` 的全局兜底
- **难点**：**401 拦截后自动跳登录页**要防止**重复弹提示** + 无限循环（token 刷新失败也是 401）——用 `isRedirecting` 标志位／**Axios 的 blob 请求异常**——`content-type` 判断，把 blob 转成 text 再 parse 出真实 message／**`ElMessage` 频繁弹出**会让 UI 抖动——限流：同一消息 3 秒内只弹一次

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
一路做下来，学生已经在多个组件里手写过 `try { ... } catch (e) { ElMessage.error(e.message) }`。今天做一次收敛：**让异常处理有全局规范、有分层职责、有兜底机制**——同时兼顾用户友好。

#### 新知讲授（14 分钟）

1. **四层异常处理架构**（4 分钟）：

   ```
   ┌─────────────────────────────────────┐
   │ 全局 unhandledrejection（兜底）      │
   ├─────────────────────────────────────┤
   │ 组件层 toastErr(e)（识别类型 + 提示）│
   ├─────────────────────────────────────┤
   │ API 层 try-catch（可选：本地处理）   │
   ├─────────────────────────────────────┤
   │ Axios 响应拦截器（统一预处理）       │
   └─────────────────────────────────────┘
   ```

2. **Axios 响应拦截器**（5 分钟）：

   ```ts
   let isRedirecting = false
   request.interceptors.response.use(
     (res) => {
       // 已经是 blob（导出接口）直接返回
       if (res.config.responseType === 'blob') return res.data
       const { code, msg, data } = res.data
       if (code === 200) return data
       throw new BizError(code, msg)
     },
     (err) => {
       const status = err.response?.status
       if (status === 401) {
         if (!isRedirecting) {
           isRedirecting = true
           ElMessage.warning('登录已过期，请重新登录')
           useAuthStore().logout()
           router.replace('/login')
           setTimeout(() => isRedirecting = false, 1500)
         }
         return Promise.reject(new BizError(401, '未登录'))
       }
       if (status === 403) return Promise.reject(new BizError(403, '无权访问'))
       if (status >= 500)  return Promise.reject(new BizError(status, '服务异常，请稍后重试'))
       if (!err.response)  return Promise.reject(new BizError(-1, '网络异常，请检查连接'))
       return Promise.reject(err)
     }
   )
   ```

3. **`ElMessage` vs `ElNotification`**（5 分钟）：

   | 场景 | 组件 | 停留时长 | 特点 |
   |------|-----|--------|-----|
   | 保存成功 | Message.success | 3s | 顶部一行 |
   | 表单校验错 | Message.error | 3s | 顶部一行 |
   | 权限不足 | Message.warning | 3s | 顶部一行 |
   | 服务 500 | Notification.error | 手动关 | 右下富文本 |
   | 有异步任务通知 | Notification.info | 手动关 | 带标题+内容 |

   核心原则：**短反馈用 Message，需要用户读一段文字用 Notification**。

#### 示例演示（15 分钟）

1. **`BizError` + `toastErr`**（5 分钟）：

   ```ts
   // @/utils/BizError.ts
   export class BizError extends Error {
     constructor(public code: number, message: string) {
       super(message)
       this.name = 'BizError'
     }
   }
   ```

   ```ts
   // @/utils/handleErr.ts
   import { ElMessage, ElNotification } from 'element-plus'
   import { BizError } from './BizError'
   import axios, { AxiosError } from 'axios'

   const recent = new Map<string, number>()
   function dedup(msg: string): boolean {
     const t = Date.now()
     const last = recent.get(msg) || 0
     if (t - last < 3000) return true
     recent.set(msg, t)
     return false
   }

   export function toastErr(e: unknown, opts?: { title?: string; long?: boolean }) {
     let msg = '未知错误'
     let long = opts?.long ?? false
     if (e instanceof BizError) {
       msg = e.message
       if (e.code >= 500) long = true
     } else if (axios.isAxiosError(e)) {
       msg = e.message
       long = true
     } else if (e instanceof Error) {
       msg = e.message
     }
     if (dedup(msg)) return
     if (long) {
       ElNotification.error({ title: opts?.title ?? '出错了', message: msg, duration: 6000 })
     } else {
       ElMessage.error(msg)
     }
   }
   ```

   现场演示：调错误接口触发 500，Notification 弹右下停留 6 秒；调 400 触发 BizError，Message 弹顶部 3 秒。

2. **全局 `unhandledrejection`**（5 分钟）：

   ```ts
   // main.ts
   window.addEventListener('unhandledrejection', (e) => {
     console.error('Unhandled Promise Rejection:', e.reason)
     toastErr(e.reason, { title: '未捕获异常', long: true })
     e.preventDefault()
   })
   ```

   演示一个漏 catch 的 async 函数，兜底提示照样出现。

3. **blob 请求异常的特殊处理**（5 分钟）：CSV 导出时，如果后端返回 401，Axios 拿到的还是 blob。拦截器里需要判断：

   ```ts
   if (res.config.responseType === 'blob') {
     if (res.data.type === 'application/json') {
       // 后端把错误当 JSON 返回了，把 blob 转 text 再 parse
       const text = await res.data.text()
       const { code, msg } = JSON.parse(text)
       throw new BizError(code, msg)
     }
     return res.data
   }
   ```

#### 学生练习（8 分钟）

1. **P1（3 分钟）**：完善 `request.ts` 拦截器，覆盖 401 / 403 / 500 / 网络错误四种；
2. **P2（3 分钟）**：把 `toastErr` 落地，把项目里所有 `catch (e) { ElMessage.error(e.message) }` 替换成 `catch (e) { toastErr(e) }`；
3. **P3（2 分钟）**：`main.ts` 加全局 `unhandledrejection`。

#### 提问与巡视（3 分钟）
- 关注 `isRedirecting` 标志位是否正确设置——不加会因为并发请求都拿到 401 而弹 10 次登录过期；
- 常见错误：`ElMessage` 没做去重，同一错误连续点会弹 5 次；blob 拦截漏做，导出失败时用户看不到任何提示。

#### 小结（3 分钟）
- 四层异常：拦截器 → API try → 组件 toastErr → 全局 unhandledrejection
- BizError 承载业务码 + 消息
- Message 短反馈 / Notification 长内容
- 401 防重复：isRedirecting 标志位

### 6.4 板书设计
```
Day14-第6课时  异常处理体系
1. 四层：拦截器/API/组件/全局
2. BizError(code, message)
3. Message vs Notification 分工
4. 401 → isRedirecting 防重复
5. blob 异常特殊处理
```

---

## Day14 总结与作业

### 本日主线回顾

- **前 3 课时**：课程管理前端完整落地——列表页 5 项搜索 9 列表格，独立路由编辑页 15 字段，科目→教练级联下拉，冲突预检 300ms 防抖，发布/下架/单删/批删 4 种业务动作
- **第 4 课时**：Element Plus 校验体系六层分层图，`validator` 三种风格，跨字段 `validateField`，`validators.ts` 抽取
- **第 5 课时**：系统日志前端 4 项搜索 9 列表格，抽屉详情 + JsonBlock + CSV 导出
- **第 6 课时**：异常处理四层架构，BizError + toastErr，Message vs Notification 分工，全局 unhandledrejection 兜底

### 交付物

1. `src/api/course.ts` / `src/api/opLog.ts`
2. `src/views/course/CourseListView.vue` / `CourseEditView.vue`
3. `src/views/log/OpLogListView.vue` / `OpLogDetailDrawer.vue`
4. `src/components/JsonBlock.vue`
5. `src/utils/validators.ts` / `handleErr.ts` / `BizError.ts`
6. `src/api/request.ts` 拦截器升级
7. `main.ts` 全局 `unhandledrejection`

### 课后作业

1. 【必做】把 Day13 会员表单的 rules 全部改成 `validators.ts` 里的工具，代码行数至少减半；
2. 【必做】用 AI 生成「批量复制课程」功能：多选课程 → 弹窗选新的开课日期 → 保留其他字段一键复制；
3. 【选做】给 `JsonBlock` 增加**语法高亮**（`highlight.js` json 语法）；
4. 【选做】实现「操作日志实时推送」：后端 SSE 推送新日志，前端首页展示滚动 timeline，最多保留 20 条；
5. 【选做】增加「登录尝试记录」独立页面，超阈值高亮，可一键封禁 IP。

### 联调剧本回顾

**课程管理**：
1. `/courses` 空列表 → 点「新增课程」→ 跳 `/courses/edit`
2. 选科目「阴瑜伽」→ 教练下拉自动过滤 → 选「王芳」→ 教室「A302」→ 时段「明天 09:00 ~ 10:00」→ 冲突面板空
3. 改时段到「明天 10:00 ~ 11:00」→ 300ms 后 alert 冲突弹出
4. 容量填 200（超教室容量 30）→ 校验器红字
5. 保存 → 冲突二次确认；后端 `1010 时间冲突` → toastErr 弹通知
6. 列表刷新 → 新课「未发布」灰色 → 点「发布」→ 变「报名中」绿 → 「下架」出现
7. 状态过滤「报名中」→ 只显示 1 条

**系统日志**：
1. 完成会员/课程/教练的一系列操作留下日志
2. `/logs` 加载 10-20 条
3. 按操作人 `admin` 筛选 → 只剩 admin
4. 「模块=会员」+「状态=失败」→ 「手机号已注册」失败日志
5. 时间「最近 1 小时」→ 实时过滤
6. 详情 → 3 个 tab（参数 JSON / 返回结果 / 异常）
7. 复制按钮 → 剪贴板
8. 导出 CSV → Excel 打开正常
9. 勾选 → 「清理选中」→ 确认 → 刷新

**异常处理**：
1. 停掉后端 → 任一列表请求 → 右下 Notification「网络异常」6 秒
2. token 手工过期 → 任一请求 → 顶部 Message「登录过期」→ 跳登录页
3. 无权限接口 → 403 → Message「无权访问」
4. 触发 500 → Notification 长内容显示
5. 未 catch 的 async → unhandledrejection 兜底

---

## 教学反思要点

1. **课程页复杂度骤增**：字段数是会员页的 2 倍，学生容易在编辑页迷失——务必强调「按功能分组」而不是按顺序码；
2. **级联下拉的联动方向**：科目→教练 是**单向依赖**，学生常常把它写成双向 watch 导致死循环；
3. **`v-if` vs `:disabled`**：状态相关的按钮务必用 `v-if` 完全隐藏，不要留残影按钮误导；
4. **`ElMessageBox` reject 分支**：所有 confirm 后面**都要 try-catch 或 .catch**，否则控制台一片红警；
5. **`validators.ts` 抽取时机**：不要一上来就抽，等在项目里出现 3 次以上再抽——早抽反而是过度设计；
6. **异常处理的分层职责**：拦截器只做「翻译错误」，不做「用户提示」；组件层才决定「弹 Message 还是 Notification」——避免拦截器和组件互相踩脚；
7. **`unhandledrejection` 不是万能兜底**：它只兜住 Promise，同步抛错要用 `window.onerror`；本项目暂不涉及；
8. **CSV 中文乱码**是最容易被忽视的坑，建议一次课就让学生亲手复现一次并解决。

---

## 附：常见问题排查手册

| 现象 | 可能原因 | 解决 |
|------|--------|-----|
| 编辑页从 A 课跳到 B 课字段没变 | `<router-view>` 未加 `:key` | `<router-view :key="$route.fullPath">` |
| 教练下拉一直是空 | `subjectIds` 字段没返回 | 后端 `coachApi.simpleList()` 补字段 |
| 冲突预检没触发 | debounce 挂在错误 hook | 挂 `@change`，且要 return debounced 函数本身 |
| `datetimerange` 返回 null | `value-format` 没配置 | `value-format="YYYY-MM-DD HH:mm"` |
| CSV 打开中文乱码 | UTF-8 无 BOM | 后端写 `\uFEFF` 头 |
| `ElMessageBox` 控制台红字 | reject 没 catch | 加 `.catch(()=>{})` 或不 await |
| Message 连续弹 5 次 | 无去重 | 3s 内同消息合并 |
| 401 弹 10 次 | 并发请求都触发 | 加 `isRedirecting` 标志位 |
| `validator` 永远 pending | callback() 忘调 | 改 Promise 风格 |
| 修改前一字段，后一字段红字不消失 | 未 validateField | `watch` 里手动触发 |
| 抽屉里 `pre` 撑破抽屉 | 无 max-height | `max-height:400px; overflow:auto` |
| `navigator.clipboard` undefined | 非 https | 用 `document.execCommand('copy')` 兜底 |

---
