# 《AI 应用 Web 开发》 - 教师教案（Day11：预约管理 CRUD + 拦截器 + JWT + 图形验证码）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day10 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、Redis 8、事务、AOP 操作日志、DTO/VO、Result 统一响应、全局异常处理）**
**知识点覆盖：** 第 21 章 预约管理 CRUD（会员预约 / 退课 / 签到 / 缺席 / 日历视图 + Redis 并发扣减名额） + 第 22 章 拦截器 + JWT + 图形验证码（HandlerInterceptor + WebMvcConfigurer + JJWT 0.12.6 + Kaptcha + BCrypt + 后台登录 / 退出 / 刷新）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / Redis 8 / JJWT 0.12.6 / Kaptcha 2.3.2 / IDEA 2024.3+ / 通义灵码 + Trae。

**Day11 主线**：印想瑜伽会馆的「课程预约」是整个后端最复杂、最容易翻车的一块——**多约束业务 + 高并发扣减 + 状态机流转**三者叠加。**前 2 个课时**把预约模块从表结构到 REST 接口完整打穿：会员卡校验、时段冲突、Redis 名额扣减、DB 唯一键兜底、取消退卡、签到、缺席定时任务、日历视图；**中间 4 个课时**给整个后端加上「门神」——先讲 `HandlerInterceptor` 与 `WebMvcConfigurer` 的角色分工，再做后台登录、BCrypt 加盐、JWT 签发与校验、Kaptcha 图形验证码 + Redis 校验，最后加上黑名单强制下线与滑动式 refresh。打完这 6 课时，第二部分（后端）**正式收官**，Day12 开始切前端。

---

## 第 1 课时：预约业务建模 + 会员预约接口

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出印想瑜伽会馆「会员 / 会员卡 / 课程 / 教练 / 教室 / 预约单」六方之间的关系图，并说清「预约单」为什么是读写压力最大的表；
2. 能设计 `tb_booking` 表结构，理解 `uk_booking_no` 与 `uk_member_course(member_id, course_id, deleted)` 两个唯一键的业务含义；
3. 能画出「已预约 / 已取消 / 已签到 / 缺席」四态状态机，列出每个操作允许的起始状态；
4. 能实现 `BookingService.create(BookingCreateDTO)`：按「课程校验 → 会员卡校验 → 时段冲突 → Redis 扣名额 → 落库 → 卡扣课时 → 课程状态改已满」六步跑通；
5. 能解释「Redis `INCR` + DB UK 兜底」的双保险，说清 Redis 操作不参与 Spring 事务、异常必须手工 `DECR` 回滚。

#### 1.1.2 过程与方法目标
1. 通过「一张预约单牵动 4 张表」的实际案例，训练「先梳理约束、再画状态机、最后落代码」的建模顺序；
2. 通过对比「纯 DB 悲观锁」与「Redis 快通道 + UK 兜底」两种方案，理解「加速器」与「真相源」的分层思维。

### 1.2 教学重难点
- **重点**：`tb_booking` 表设计与两个 UK 的作用／预约创建六步链路／Redis `INCR` 首次自增时与 DB 已有数据的同步策略／`@Transactional(rollbackFor = Exception.class)` 与 Redis 补偿的关系
- **难点**：`uk_member_course` 为什么要带 `deleted`——不带 `deleted` 的坑（取消后无法再预约）；Redis 与 DB 双写不一致的窗口与兜底；`booking_no` 生成的碰撞概率与重试

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
口播切入：Day10 我们把 AOP 操作日志跑通了，会员、教练、课程三个模块的 CRUD 都能被切面记录。今天开始收官——**预约**这块业务是整个后端最扎心的一块：一次点击「立即预约」，后端要同时校验会员卡、课程状态、名额、时段冲突、是否重复预约五件事，任何一件不通过都得整体回滚。抛出灵魂问题：「10 个会员同时抢最后 1 个名额，你怎么保证只成功 1 个？」把学生的胃口吊起来。板书：**多约束业务 + 并发扣减 + 状态机流转 = 今天的三块硬骨头**。

#### 新知讲授（14 分钟）

1. **预约在业务里的位置**（4 分钟）：黑板上画六方关系——「会员 → 预约单 ← 课程」中间三条虚线连到「会员卡（扣课时）、教练时段、教室时段」。强调预约单是**唯一同时读写 4 张表**的接口，也是**读写压力最大**的表。任何一次预约都涉及：① 会员卡是否有效、课时是否够扣；② 课程是否处于「报名中/已满」状态；③ 名额是否已满；④ 该会员是否已重复预约；⑤ 是否与已预约的其他课程时间冲突。**任一条不通过必须整体回滚**——这就是事务与并发控制的最佳教材。

2. **`tb_booking` 表设计**（5 分钟）：投影 SQL，逐字段讲清用意——
   - `booking_no VARCHAR(32) NOT NULL` —— 业务单号 `YYYYMMDD+8 位随机`，面向用户展示，比自增 ID 更安全（不暴露业务量）；
   - `status TINYINT` —— 1 已预约 / 2 已取消 / 3 已签到 / 4 缺席，代码里定义枚举；
   - `deleted TINYINT DEFAULT 0` —— 软删；
   - `UNIQUE KEY uk_booking_no (booking_no)` —— 单号唯一；
   - `UNIQUE KEY uk_member_course (member_id, course_id, deleted)` —— **数据库层面保证同一会员不能对同一课程重复预约**，`deleted` 参与 UK 让软删记录不冲突（取消后可以重预）；
   - 索引 `(course_id, status)` 支撑「查某课程有多少人预约」，`(member_id, create_time)` 支撑「查某会员最近预约」。

3. **状态机四态**（5 分钟）：黑板画状态图——「已预约」是唯一入口，可以走向「已取消（会员/管理员触发）」、「已签到（到场刷卡）」、「缺席（课程结束仍未签到，定时任务触发）」。列一张操作允许表：`create` 无起始态、`cancel` 起始「已预约」、`checkIn` 起始「已预约」、`markAbsent` 起始「已预约（定时任务）」。**终态一律不可逆**——签到之后不能取消。

#### 示例演示（14 分钟）

1. **DTO / VO 定义**（3 分钟）：现场敲 `BookingCreateDTO`——`memberId / courseId / cardId` 都 `@NotNull`，`remark` `@Size(max=500)`；`BookingVO` 除了主键还带 `memberName / courseTitle / startTime / endTime / coachName / roomName`——**一次查询前端全用**，减少调用次数。

2. **`create` 核心六步**（8 分钟）：打开 `BookingService.create`，逐段讲——
   - **第 1 步 课程校验**：`courseMapper.getById + 状态判定 + 距开课 30 分钟锁死`；
   - **第 2 步 会员卡校验**：`cardService.getUsable(memberId, cardId)`——不属于此会员 / 已过期 / 已冻结 / 剩余课时 ≤0 都抛异常；
   - **第 3 步 时段冲突**：`bookingMapper.countMemberConflict(memberId, start, end)`——SQL 里用 `NOT (c.end_time <= start OR c.start_time >= end)` 做区间重叠判定；
   - **第 4 步 Redis 扣名额**：`redis.opsForValue().increment("course:booked:" + id)`，若 `booked == 1` 说明是首次自增，需要**同步 DB 已有数据**；若 `booked > capacity` 立即 `DECR` 回滚并抛异常；
   - **第 5 步 落库**：生成 `booking_no`，`insert`；
   - **第 6 步 卡扣课时 + 课程状态置已满**：`cardService.deduct(cardId, 1)`；若 `booked == capacity` 用 `UPDATE ... WHERE status = 2 AND id = ?` 把课程从「报名中」置为「已满」。
   - 演示 `catch (DuplicateKeyException dke)` 与 `catch (Exception e)` 两个补偿分支，**都要 Redis DECR**。

3. **AI 助手写一版对照**（3 分钟）：给通义灵码贴需求「Spring Boot 4 + MyBatis + Redis 8 生成预约创建接口」，观察 AI 是否会犯：① Redis 首次 `INCR` 不同步 DB；② 抛异常时忘记 `DECR` 回滚；③ 课程状态更新不带 `WHERE fromStatus` 条件；④ 事务里的 Redis 操作误以为参与回滚。**AI 常犯错清单**当堂列到黑板。

#### 课堂活动（10 分钟）
1. 每位学生新建 `tb_booking` 表、跑通「单人预约成功」闭环，交 3 张截图（Postman 200 / DB 一行数据 / Redis `course:booked:X = 1`）；
2. 追加要求：手工把课程 `capacity` 改成 1，用 Postman **连续两次**发预约（同一会员不同 courseId 也可以），观察第二次是否走到「名额已满」分支并 Redis `DECR` 回退；
3. 抽两位同学上台，说清「为什么 `uk_member_course` 要带 `deleted`」，并演示不带的时候取消后再预约会撞 UK；
4. 思考题：`Redis.increment` 到底原子吗？为什么它能挡并发？（提示：Redis 单线程执行命令）

#### 小结（3 分钟）
一句话回顾：**多约束业务 = 校验分层 + Redis 快通道 + DB UK 兜底 + 手工 Redis 补偿**。今天只跑通「预约创建」这一半，下节课把「取消 / 签到 / 缺席 / 日历视图」四个动作补齐，让预约模块真正上线可用。

### 1.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-01 预约业务建模 + 会员预约接口         │
├───────────────────────────────────────────────┤
│  多约束业务：                                 │
│   会员卡 / 课程 / 名额 / 时段 / 重复           │
│   任一失败 → 整体回滚                          │
│                                               │
│  表设计：tb_booking                           │
│   booking_no (UK)                             │
│   uk_member_course(member_id, course_id, deleted)│
│   status: 1 已预约 2 已取消 3 已签到 4 缺席    │
│                                               │
│  状态机：                                     │
│   [] → 已预约 → (已取消 / 已签到 / 缺席)      │
│                                               │
│  create 六步：                                │
│   ① 课程校验                                  │
│   ② 会员卡校验                                │
│   ③ 时段冲突                                  │
│   ④ Redis INCR + 首次同步 DB                  │
│   ⑤ 落库                                      │
│   ⑥ 卡扣课时 + 课程状态改已满                 │
│                                               │
│  双保险：                                     │
│   Redis 快通道 + DB UK 兜底                   │
│   异常必须 DECR                               │
└───────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `tb_booking` 建表 + `BookingService.create` 六步实现，跑通「单人预约成功 / 重复预约 / 名额已满」三种场景，各交一张 Postman 截图；
2. **必做**：写一段 JMeter 或 curl 循环脚本，对同一课程 `capacity=3` 用 10 个不同会员并发预约，验证「只有 3 个成功，其余全部『名额已满』」；
3. **挑战**：把 `booking_no` 生成器抽成独立的 `BookingNoGenerator` 组件，支持 `SNOWFLAKE / DATE_RANDOM / DATE_SEQUENCE` 三种策略，用 `@ConditionalOnProperty` 切换。

### 1.6 教学反思提示
- 学生最容易漏「Redis 首次 `INCR` 时同步 DB 数据」这一步，导致重启服务后已有的预约不计入 Redis，第一波并发会「多卖」；
- 演示时故意先漏掉 `catch (Exception e) { redis.decrement(...); throw e; }` 的补偿代码，让学生跑 JMeter 后发现 Redis 计数在异常场景下多减/少减，再补上；
- 讲师提问「你能只用 DB `SELECT ... FOR UPDATE` 实现吗」引出悲观锁 vs 乐观锁话题，作为课后思考铺垫。

---

## 第 2 课时：预约查询 + 退课 + 日历视图接口

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能实现 `BookingService.cancel(id, reason)`：完成「距开课 2 小时内不允许取消」的会馆制度、乐观 UPDATE 防并发、Redis 释放名额、课程状态从「已满」回落到「报名中」、会员卡课时退回五步；
2. 能实现 `checkIn(id)`：校验签到时间必须在「开课前 30 分钟到课程结束」窗口内，落 `check_in_time`；
3. 能写 `@Scheduled` 定时任务 `scanAbsent()`：每小时第 5 分钟扫描过期未签到的预约，批量置为「缺席」；
4. 能实现 `BookingService.page(BookingPageQuery)`：多表联查返回 `BookingVO`，处理 `memberName / phone / courseTitle / status / beginTime / endTime` 6 个查询字段；
5. 能实现 `BookingService.calendar(memberId, month)` 日历视图接口，返回该月每天的预约列表，前端直接渲染到日历组件。

#### 2.1.2 过程与方法目标
1. 通过「取消预约的 5 个连锁动作」，训练「主流程之外的补偿要写全」的编码习惯；
2. 通过对比「单条查询 + 前端拼装」与「联表查询一次返回 VO」，理解「用 SQL 一次查完」的性能收益。

### 2.2 教学重难点
- **重点**：乐观 UPDATE `UPDATE ... SET status=2 WHERE id=? AND status=1` 的行数判定／Redis `DECR` 与课程状态回落的顺序／定时任务批量 `markAbsent` 的 SQL／`BookingPageQuery` 的日期区间处理／日历视图的月粒度聚合
- **难点**：Redis 与 DB 状态回落的**顺序颠倒**引发的短暂不一致（先落库还是先 `DECR`）／`@Scheduled` 在多机部署下的重复执行（后续课引出 ShedLock，本课只提概念）／日历视图跨月边界的处理（用 `YearMonth.atDay(1)` 与 `YearMonth.atEndOfMonth()`）

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：「学员上课当天早上 6 点起床发现下雨了，想取消 7 点的瑜伽课，能不能取消？」引出**会馆制度**——距开课不足 2 小时不允许取消（防止老师白跑一趟）。再问：「如果学员 8 点才到场，签到还允许吗？」引出**签到时间窗口**。今天把上节课「只能预约不能反悔」的接口，补齐成完整生命周期。

#### 新知讲授（14 分钟）

1. **`cancel(id, reason)` 五步**（5 分钟）：
   - **第 1 步 前置校验**：`getById + status == 1` 判定；
   - **第 2 步 会馆制度**：`if (c.getStartTime().isBefore(now.plusHours(2))) throw ...`——**业务规则一定写在 Service，不写在 Controller 也不写在 SQL**；
   - **第 3 步 乐观 UPDATE**：`UPDATE tb_booking SET status=2, cancel_reason=? WHERE id=? AND status=1`，`rows == 0` 说明并发抢在前面（可能已被别处签到或取消），抛「并发操作，请重试」；
   - **第 4 步 Redis 释放名额**：`redis.decrement("course:booked:" + courseId)`；若课程状态是「已满」，用 `updateStatus(id, 3, 2)` 回落成「报名中」；
   - **第 5 步 卡课时退回**：`cardService.refund(cardId, 1)`。
   - 强调**顺序不能乱**：先 DB 后 Redis，DB 失败 Redis 不动；反之则 Redis 已减但 DB 没落，短暂不一致。

2. **`checkIn(id)` 签到窗口**（4 分钟）：
   - `now < startTime - 30min` → 「太早，还没到签到时间」；
   - `now > endTime` → 「课已结束，无法签到」；
   - 允许区间内 → `UPDATE ... SET status=3, check_in_time=NOW() WHERE id=? AND status=1`；
   - **全项目统一 `LocalDateTime`**——不要与 `System.currentTimeMillis()` / `Date` / `Timestamp` 混用，时区差异会让签到窗口飘。

3. **`@Scheduled scanAbsent` 定时任务**（3 分钟）：
   - `cron = "0 5 * * * *"` 每小时第 5 分钟；
   - SQL：`UPDATE tb_booking b JOIN tb_course c ON b.course_id = c.id SET b.status = 4 WHERE b.status = 1 AND b.deleted = 0 AND c.end_time <= NOW()`；
   - 打日志「[缺席扫描] 标记 X 条」——运维时能一眼看到；
   - 埋一颗雷：多机部署下这个 `@Scheduled` 会在每台机器都跑一次，重复更新虽不会错（SQL 里判 `status=1`），但日志会翻倍，Day13 引 ShedLock 解决。

4. **`page` 分页 + `calendar` 日历视图**（2 分钟）：
   - `BookingPageQuery` 支持 `memberName / phone / courseTitle / status / beginTime / endTime`，日期区间用 `>= beginTime AND < endTime + 1day`（避开「23:59:59 边界」的老坑）；
   - `calendar(memberId, YearMonth)` 返回 `Map<LocalDate, List<BookingBriefVO>>`——前端日历直接按 key 渲染。

#### 示例演示（16 分钟）

1. **`cancel` 完整代码**（5 分钟）：现场敲，特别强调 `int rows = bookingMapper.updateStatus(id, 1, 2, reason); if (rows == 0) throw ...` 的乐观并发写法。演示：手工把 DB 里预约 `status` 直接改成 2，再点前端「取消」按钮，观察抛「并发操作，请重试」。

2. **`checkIn` + `scanAbsent`**（5 分钟）：
   - `checkIn` 完整代码，Postman 三种场景（正常 / 太早 / 太晚）；
   - 手工把某条预约的 `tb_course.end_time` 改成 1 分钟前，等 1 分钟后（或手工触发 `scanAbsent`）观察 `status` 自动置 4。
   - 讲师抽一位同学到讲台，把 cron 改成 `*/10 * * * * *` 每 10 秒跑一次，观察日志滚动。

3. **联表分页 SQL**（4 分钟）：投影 `BookingMapper.xml` 的 `<select id="page">`——`LEFT JOIN tb_member LEFT JOIN tb_course LEFT JOIN tb_coach LEFT JOIN tb_room`，`resultMap` 嵌套映射到 `BookingVO`。**AI 生成 90% 可用**，只需人工核对：① 是否使用 `resultMap` 嵌套映射；② `b.deleted = 0` 是否遗漏；③ 日期区间是否 `>= beginTime AND < endTime + 1day`。

4. **`calendar` 视图**（2 分钟）：`SELECT DATE(c.start_time) day, b.id, c.title ...`，Service 层 `groupingBy(BookingBriefVO::getDay)` 聚合，返回 `Map<LocalDate, List<>>`。

#### 课堂活动（10 分钟）
1. 每位学生完成 `cancel / checkIn / page / calendar` 四个接口，Postman 每个至少一张截图；
2. 追加：故意把 `updateStatus` 里的 `AND status=1` 去掉，用两个客户端同时点「取消」，观察并发下会出现什么异常（提示：Redis 会 `DECR` 两次，课程状态可能被回落两次）；
3. 抽两位同学到讲台，说清「为什么先落库再 Redis DECR，反过来会出什么问题」；
4. 思考题：`@Scheduled` 多机部署下如何避免重复执行？（预告 Day13 的 ShedLock）

#### 小结（3 分钟）
一句话回顾：**取消五步、签到窗口、缺席扫描、分页联表、日历视图**——预约模块生命周期闭环。到此为止，Part 2 后端**业务模块全部结束**，但所有接口目前**任何人都能调**——下 4 个课时把「登录鉴权」补上，Part 2 才算正式收官。

### 1.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-02 取消 / 签到 / 缺席 / 日历            │
├───────────────────────────────────────────────┤
│  cancel 五步：                                │
│   ① 前置校验 status=1                          │
│   ② 会馆制度 距开课 >= 2h                      │
│   ③ 乐观 UPDATE WHERE status=1                │
│   ④ Redis DECR + 课程状态回落                  │
│   ⑤ 卡课时退回                                │
│                                               │
│  checkIn 时间窗口：                           │
│   [startTime - 30min, endTime]                │
│                                               │
│  scanAbsent 定时任务：                        │
│   cron "0 5 * * * *"                          │
│   UPDATE ... SET status=4                     │
│   WHERE status=1 AND end_time<=NOW()          │
│                                               │
│  分页联表：                                   │
│   LEFT JOIN member/course/coach/room          │
│   resultMap 嵌套映射                          │
│   日期 >= begin AND < end + 1day              │
│                                               │
│  日历视图：                                   │
│   Map<LocalDate, List<VO>>                    │
│   前端按 key 渲染日历                          │
└───────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `cancel / checkIn / page / calendar` 四个接口，加对应单元测试；
2. **必做**：整理「预约模块 8 个业务异常」速查表——重复预约 / 名额已满 / 距开课不足 30 分钟 / 距开课不足 2 小时取消 / 签到太早 / 签到太晚 / 并发操作 / 会员卡失效；
3. **挑战**：实现「候补预约」功能——满员时允许排队，取消时按 FIFO 自动上位（提示：Redis List 或 ZSet）。

### 1.6 教学反思提示
- 学生最容易把「先 DB 后 Redis」的顺序颠倒，讲师提问「颠倒会出什么问题」时要给足思考时间；
- `@Scheduled` 首次讲很多学生会误以为需要 `@EnableScheduling`——**主启动类上要加**，不然定时任务默默不执行；
- 日历视图的月边界处理，Java 25 用 `YearMonth.now()` + `atDay(1)` / `atEndOfMonth()` 最干净，避免自己 `if (month==12)` 手工判。

---

## 第 3 课时：Spring 拦截器（HandlerInterceptor + WebMvcConfigurer）

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能画出 Servlet Filter → DispatcherServlet → HandlerInterceptor → Controller 的请求生命周期图，说清 Filter 与 Interceptor 的三个差异（能否拿到 HandlerMethod / 依赖注入 / 生态整合）；
2. 能实现 `HandlerInterceptor.preHandle / postHandle / afterCompletion` 三个方法，说清各自触发时机与用途；
3. 能通过 `WebMvcConfigurer.addInterceptors + addPathPatterns + excludePathPatterns` 注册拦截器并配置白名单；
4. 能自定义 `@AuthIgnore` 注解，在拦截器里通过 `HandlerMethod.hasMethodAnnotation` 判断是否放行；
5. 能解释「`preHandle` 里 `return false` 与抛异常的差异」，选择更适合业务的写法。

#### 3.1.2 过程与方法目标
1. 通过「所有接口目前任何人都能调」的痛点切入，训练「先看清生命周期再选切入点」的架构思维；
2. 通过对比「配置里堆一堆白名单路径」与「注解贴接口方法」两种写法，理解「注解驱动」的可维护性收益。

### 3.2 教学重难点
- **重点**：`HandlerInterceptor` 三方法的触发时机／`WebMvcConfigurer.addInterceptors` 的注册顺序／`@AuthIgnore` 注解 + `HandlerMethod` 反射判定／`preHandle` 抛异常与 `return false` 的差异
- **难点**：`handler` 不一定是 `HandlerMethod`（可能是 `ResourceHttpRequestHandler` 静态资源）——不判类型会 `ClassCastException`／`return false` 时无法把 401 状态码带出去（响应体空），要么用 `response.setStatus(401) + writeBody`，要么统一改抛异常

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
口播抛问题：「Day01 到 Day11 前 2 课时，我们做了 40 多个接口，随便一个 URL 拿出来，未登录用户都能调——一个匿名请求就能删掉所有会员数据。今天开始给整个后端**装门神**。」板书三个候选：① Servlet Filter；② HandlerInterceptor；③ AOP。三选一的抉择要看**能不能拿到方法上的注解**——只有 Interceptor 可以，选它。

#### 新知讲授（14 分钟）

1. **请求生命周期图**（4 分钟）：黑板画链路——
   ```
   Client → Servlet Filter → DispatcherServlet
          → HandlerInterceptor.preHandle → @Controller 方法
          → HandlerInterceptor.postHandle → 视图/Response
          → HandlerInterceptor.afterCompletion → Filter → Client
   ```
   投影关键差异表：Filter 拿不到方法信息、依赖注入不便；Interceptor 拿到 `HandlerMethod`，能读取方法/类头注解，天然支持 Spring 依赖注入，执行链清晰。**「拿方法注解」是本课选 Interceptor 的决定性理由**。

2. **`HandlerInterceptor` 三方法**（5 分钟）：
   - `preHandle(req, res, handler) → boolean`：Controller 方法**执行前**，`return true` 放行，`return false` 拦下（**响应体空**是坑），也可以直接抛异常（走全局异常处理器）；
   - `postHandle(req, res, handler, ModelAndView)`：Controller 方法**执行后**、视图渲染**前**，前后端分离项目里几乎用不到；
   - `afterCompletion(req, res, handler, ex)`：整个请求结束**后**，无论成功或异常都执行，**适合做资源清理与访问日志**。
   - 强调常用只有 `preHandle`，另两个偶尔用于监控。

3. **`WebMvcConfigurer` 注册 + 白名单**（3 分钟）：
   - `@Configuration` + `implements WebMvcConfigurer`；
   - `addInterceptor(jwtInterceptor).addPathPatterns("/**").excludePathPatterns("/login", "/logout", "/captcha", "/files/**", "/error")`；
   - **`/error` 一定要放白名单**——不然拦截器抛异常后 Spring 内部 forward 到 `/error` 又被拦一次，死循环。

4. **`@AuthIgnore` 注解替代路径列表**（2 分钟）：
   - `@Target({METHOD, TYPE}) @Retention(RUNTIME) public @interface AuthIgnore {}`；
   - 拦截器里 `if (hm.hasMethodAnnotation(AuthIgnore.class) || hm.getBeanType().isAnnotationPresent(AuthIgnore.class)) return true`；
   - **好处**：路径变了不用改配置，接口作者一贴注解即可放行；坏处：静态资源、错误页仍要走 `excludePathPatterns`。

#### 示例演示（14 分钟）

1. **写一个极简 `LogInterceptor`**（5 分钟）：
   - `preHandle` 打「[LOG] preHandle {} {}」（method, uri）+ 存 `startTime` 到 `request.setAttribute`；
   - `afterCompletion` 计算耗时 `now - startTime` 打「[LOG] cost=Xms」；
   - `WebMvcConfig` 注册，浏览器随便点一个接口，观察日志顺序（先 preHandle，后 Controller，最后 afterCompletion）；
   - 演示 `handler instanceof HandlerMethod hm` 判空——不判会在访问 `/files/xxx.png` 静态资源时 `ClassCastException`。

2. **`@AuthIgnore` + `HandlerMethod` 反射**（5 分钟）：
   - 现场敲 `@AuthIgnore` 注解；
   - `LoginController.login` 方法头贴 `@AuthIgnore`；
   - 拦截器里加判断，投影 `hm.hasMethodAnnotation(AuthIgnore.class)`；
   - 演示：`GET /login` 打日志「AuthIgnore 放行」；`GET /members` 打日志「进入 preHandle 校验」。

3. **`return false` vs 抛异常**（4 分钟）：
   - 版本 A：`preHandle` `return false`，Postman 观察 —— 状态码 200、响应体空、前端不知道发生了什么；
   - 版本 B：`preHandle` `throw new AuthException("未登录")`，配合 `GlobalExceptionHandler` 里 `@ExceptionHandler(AuthException.class) → 401`，Postman 收到 `{"code":401,"msg":"未登录"}`；
   - **本项目统一用抛异常**——好处：状态码 + 错误消息一起交给全局异常处理，前端拦截器统一处理。

#### 课堂活动（10 分钟）
1. 每位学生完成 `LogInterceptor`——`preHandle` 记入口 + 时间戳，`afterCompletion` 打耗时，注册到 `/**` 全路径；
2. 追加：新建 `@AuthIgnore` 注解，给 `/captcha`、`/login`、`/refresh` 三个方法贴上，验证放行；
3. 讲师提问：「`preHandle` 返回 false 时，`postHandle` 与 `afterCompletion` 会不会执行？」（答：`postHandle` 不执行，`afterCompletion` 也不执行）；
4. 思考题：如果我想在**Controller 方法参数解析后**做校验，Interceptor 够不够？（提示：不够，得用 AOP 或 `HandlerMethodArgumentResolver`）

#### 小结（3 分钟）
一句话回顾：**Interceptor 是 Spring MVC 的门神——能拿方法注解、支持依赖注入、三方法覆盖生命周期**。下一课时把「后台登录 / 退出 / 密码加盐」补上，为 JWT 拦截器备好素材。

### 3.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-03 Spring 拦截器                       │
├───────────────────────────────────────────────┤
│  请求生命周期：                               │
│   Filter → DispatcherServlet                  │
│     → preHandle → Controller                  │
│     → postHandle → 视图                        │
│     → afterCompletion → Filter                │
│                                               │
│  三方法：                                     │
│   preHandle       方法前，boolean 或抛异常     │
│   postHandle      方法后视图前                │
│   afterCompletion 请求结束，资源清理           │
│                                               │
│  注册：                                       │
│   WebMvcConfigurer.addInterceptors            │
│   addPathPatterns("/**")                      │
│   excludePathPatterns(...) + /error 必须放行  │
│                                               │
│  @AuthIgnore：                                │
│   METHOD/TYPE 注解                            │
│   HandlerMethod.hasMethodAnnotation           │
│                                               │
│  return false vs 抛异常：                     │
│   false 响应体空 → 前端懵                     │
│   抛异常 → GlobalExceptionHandler → 401       │
│                                               │
│  handler 类型：                               │
│   HandlerMethod / ResourceHttpRequestHandler  │
│   必须 instanceof 判                          │
└───────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：写一个 `LogInterceptor` 记录访问日志（method / uri / cost / userAgent），注册到 `/**`；
2. **必做**：定义 `@AuthIgnore` 注解，理解它比在配置里堆路径的优势；
3. **挑战**：写一个 `RateLimitInterceptor`——每个 IP 每秒最多 10 次请求（Redis `INCR + EXPIRE 1s`），超过抛 429 Too Many Requests。

### 3.6 教学反思提示
- 学生最容易忘 `handler instanceof HandlerMethod hm` 的类型判断，静态资源访问一发就崩，可以让学生「先漏后补」加深印象；
- `WebMvcConfigurer` 里注册多个拦截器时执行顺序 = 注册顺序，可以让学生自己实验（先注册 A 再注册 B，`preHandle` A 先 B 后，`afterCompletion` B 先 A 后）；
- 讲师抽两位同学到讲台，一位说 Filter 与 Interceptor 三大差异，一位说 `return false` 与抛异常的适用场景，效果最佳。

---

## 第 4 课时：后台登录/退出 + 密码加盐

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能设计 `tb_admin_user` 表（`username / password / real_name / status / roles`），说清「roles 存 JSON 数组」与「独立 `tb_user_role` 关联表」两种模型的取舍；
2. 能用 `spring-security-crypto` 的 `BCrypt` 完成密码**加盐哈希 + 校验**，说清 BCrypt 每次加密结果都不同但校验能通过的原理；
3. 能实现 `AdminUserService.checkLogin(username, rawPwd)`：账号不存在 / 已禁用 / 密码错三种异常分支；
4. 能写 `POST /login` 与 `POST /logout` 骨架接口，`login` 返回 `LoginVO(username, realName, roles)`——此时**先不加 JWT**，专注密码校验；
5. 能解释「明文存密码 / MD5 存密码 / MD5 加盐存密码 / BCrypt 存密码」四种方案的安全性演进。

#### 4.1.2 过程与方法目标
1. 通过「你的用户名和密码明文存数据库」的真实事故案例（CSDN 6000 万密码泄露、多家公司连锁被撞库），训练**永不明文存密码**的意识；
2. 通过对比 MD5 / SHA-256 / BCrypt 的抗彩虹表能力，理解「计算成本 = 安全成本」。

### 4.2 教学重难点
- **重点**：BCrypt 的「自适应工作因子」＋每次加密带随机盐（写入结果本身）／`BCrypt.checkpw(raw, hash)` 的比较逻辑／`tb_admin_user` 的字段设计与 `status` 禁用位
- **难点**：BCrypt 加密结果格式 `$2a$10$xxxxxxxxx...`（版本 + cost + 盐 + hash 全在里面）／为什么不用 SHA-256——SHA 一秒能算几十亿次、GPU 撞库便宜；BCrypt cost=10 大约 60ms 一次，撞库慢 10 万倍／不要自己「MD5(密码+盐)」——**加密工程的第一定律：不要造轮子**

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：「Day02 建 `tb_admin_user` 时，密码字段是 `VARCHAR(64)`，你们的初始密码是怎么存的？」大部分学生答「明文 `123456`」——引出 CSDN 泄露事件（2011 年，600 万明文密码打包泄露到 GitHub），十几个大厂被撞库。今天把密码存储从「明文」升级到「BCrypt 加盐」，为下一课时的 JWT 登录接口备好用户表。

#### 新知讲授（14 分钟）

1. **`tb_admin_user` 表设计**（4 分钟）：
   ```sql
   CREATE TABLE tb_admin_user (
     id           BIGINT PRIMARY KEY AUTO_INCREMENT,
     username     VARCHAR(50)  NOT NULL,
     password     VARCHAR(100) NOT NULL COMMENT 'BCrypt 密文',
     real_name    VARCHAR(50),
     status       TINYINT DEFAULT 1 COMMENT '1 启用 0 禁用',
     roles        VARCHAR(500) COMMENT '角色列表，JSON 数组',
     last_login_time DATETIME,
     last_login_ip   VARCHAR(50),
     deleted      TINYINT DEFAULT 0,
     create_time  DATETIME DEFAULT CURRENT_TIMESTAMP,
     update_time  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     UNIQUE KEY uk_username (username, deleted)
   );
   ```
   - `password VARCHAR(100)` —— BCrypt 密文固定 60 字节，留 100 兼容未来算法；
   - `roles` 存 JSON 数组 `["ADMIN","OP"]`——小项目够用，大项目才拆 `tb_user_role`；
   - `status = 0` 禁用位——「离职员工」用软禁用，不删数据；
   - `uk_username(username, deleted)` —— 允许软删同名用户回归。

2. **密码存储演进史**（5 分钟）：
   - **明文** → CSDN 事件教科书级反例；
   - **MD5**（2000 年代常见） → 彩虹表秒解 `123456`；
   - **MD5 + 固定盐** → 盐固定 = 提前算好的彩虹表照旧；
   - **MD5 + 每人不同随机盐** → 撞库变慢，但 MD5 本身算力便宜（GPU 每秒 100 亿次）；
   - **BCrypt** → cost=10 大约 60ms 一次，撞库难度 = 100 亿 / 每秒 16 次 = **10 亿倍**。**加密工程唯一正确姿势**。
   - 讲清 BCrypt 加密结果 `$2a$10$xxxxxxxxx...`：`$2a$` 版本、`10` cost（对数，10 = 2^10 次迭代）、`xxxxxxxxx` 盐 + hash 拼接——**盐存在密文里**，校验时自动解析出来再哈希。

3. **`BCrypt` API**（3 分钟）：
   ```java
   import org.springframework.security.crypto.bcrypt.BCrypt;
   String hash = BCrypt.hashpw("123456", BCrypt.gensalt(10));
   //      → $2a$10$UnVeK4WqQg3zXfLpqE1BWuHVhBpTNqB.g0nLh9WvOfrWzL9Ug8P4a
   boolean ok = BCrypt.checkpw("123456", hash);   // true
   boolean ng = BCrypt.checkpw("wrong",  hash);   // false
   ```
   - 依赖：`spring-security-crypto`（不需要引入完整 Spring Security）；
   - 每次 `hashpw` 结果都不同——因为盐是随机生成的；
   - `checkpw` 内部会从密文提取盐再哈希对比。

2. **`checkLogin` 三个异常**（2 分钟）：
   - 账号不存在 → 「账号不存在或已禁用」（不告诉用户到底是不存在还是禁用，**降低撞库反馈**）；
   - `status == 0` → 同上；
   - `!BCrypt.checkpw(raw, u.password)` → 「用户名或密码错误」（同样模糊化）。

#### 示例演示（15 分钟）

1. **生成一个 BCrypt 密文**（3 分钟）：
   - IDEA `main` 方法跑 `BCrypt.hashpw("123456", BCrypt.gensalt(10))`；
   - 复制结果，`INSERT INTO tb_admin_user (username, password, real_name, status, roles) VALUES ('admin', '$2a$10$...', '超级管理员', 1, '["ADMIN"]')`；
   - 演示同一密码执行 3 次 `hashpw` 结果都不同，但都能 `checkpw` 通过。

2. **`AdminUserService.checkLogin`**（6 分钟）：
   - 现场敲：`mapper.getByUsername → null 或 status=0 抛异常 → BCrypt.checkpw → 不通过抛异常 → 返回 User`；
   - 顺手写 `LoginController.login`：接 `LoginDTO(username, password)`（**下节课再加 captcha 字段**），调 `checkLogin`，暂时返回 `LoginVO(username, realName, roles)`，**先不签发 JWT**；
   - Postman 三种场景：正确密码 200 / 错误密码 400 / 禁用账号 400。

3. **`logout` 骨架**（3 分钟）：
   - 现在没有 JWT，`logout` 逻辑很简单——返回成功；
   - 讲师提问：「无状态的 API 里 logout 到底要不要做点什么？」——引出下节课「JWT 黑名单强制下线」的话题。

4. **AI 生成 vs 人工核对**（3 分钟）：
   - 让 AI 生成 `AdminUserService`，观察典型问题：① 用 `MD5` 而不是 `BCrypt`；② 密码校验前忘记判 null；③ 密码错和账号不存在给不同错误消息（**帮撞库**）；
   - AI 常犯错清单板书。

#### 课堂活动（10 分钟）
1. 每位学生：① 建 `tb_admin_user` 表；② 用 IDEA main 方法生成 `admin/123456` 的 BCrypt 密文并 `INSERT`；③ 跑通 `POST /login` 三种场景（正确 / 错误 / 禁用），交 Postman 截图；
2. 抽一位同学到讲台，说清「为什么 `BCrypt.hashpw` 每次结果不同却能校验」——考察对「盐存在密文里」的理解；
3. 讲师提问：「MD5 + 固定盐 加密方案的漏洞是什么？」（提示：盐固定 = 彩虹表照旧成立）；
4. 思考题：如果 `admin` 的密码存到 GitHub 公开仓库了，我需要立即修复什么？（提示：不仅仅是改密码，是**换 cost、加 pepper、监控异常登录**）。

#### 小结（3 分钟）
一句话回顾：**BCrypt 加盐存密码 + 模糊化错误反馈 + 禁用位软控制**。下节课在这一切之上加 JWT——让登录成功后能签发一枚可验证、可携带业务字段的令牌。

### 4.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-04 后台登录 + BCrypt 加盐              │
├───────────────────────────────────────────────┤
│  密码存储演进：                               │
│   明文 → MD5 → MD5+固定盐 → BCrypt            │
│                                               │
│  BCrypt 关键：                                │
│   $2a$10$盐+hash                              │
│   cost=10 → 60ms 一次                         │
│   每次结果不同 → 但 checkpw 通过              │
│                                               │
│  tb_admin_user：                              │
│   password VARCHAR(100)                       │
│   status 0/1                                  │
│   roles JSON 数组                             │
│                                               │
│  checkLogin 三分支：                          │
│   账号不存在 / 禁用 / 密码错                   │
│   错误消息模糊化 → 抗撞库反馈                 │
│                                               │
│  API：                                        │
│   BCrypt.hashpw(raw, gensalt(10))             │
│   BCrypt.checkpw(raw, hash) → boolean         │
│                                               │
│  依赖：                                       │
│   spring-security-crypto（不要引全 Security） │
└───────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：跑通 `admin / 123456` 登录闭环——建表 + 生成密文 + INSERT + Postman 三种场景；
2. **必做**：把 BCrypt cost 从 10 改成 12，重新生成密文，用 stopwatch 打时间戳观察 hashpw / checkpw 耗时变化；
3. **挑战**：追加「登录失败次数」——同一 IP 或同一账号 5 分钟内错 5 次，锁 15 分钟（Redis 计数 + TTL），当次登录接口返回「账号已锁定，X 秒后重试」。

### 4.6 教学反思提示
- 学生最容易在生成 BCrypt 密文时**在 SQL 里手打**，`$2a` 里的 `$` 被 IDE / SQL 客户端当成占位符替换掉，导致存进去的密文残缺——一定要现场演示「用 IDEA 跑 main 方法拿到结果字符串再复制」的正确姿势；
- 讲师抽学生上台生成密文时，故意让他复制一个错的（少一位），然后 `checkpw` 返回 false，让全班找 bug；
- `BCrypt.hashpw` 是同步阻塞 60ms，登录接口 QPS 上不去时（一天几万次登录以内没问题）不用担心，讲清「cost 是权衡安全和性能的旋钮」。

---

## 第 5 课时：JWT 令牌签发与校验

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能画出 JWT 三段结构（Header / Payload / Signature）以及签发 → 保存 → 验签 → 上下文注入的完整链路；
2. 能引入 JJWT 0.12.6 的三个依赖（`jjwt-api` + `jjwt-impl` + `jjwt-jackson`）并解释为什么后两个是 `runtime` scope；
3. 能用 `Keys.hmacShaKeyFor(secretBytes)` + `Jwts.builder()...signWith(key, Jwts.SIG.HS256).compact()` 完成 JWT 签发，Payload 里带 `uid / roles / exp`；
4. 能实现 `JwtInterceptor.preHandle`：读 `Authorization: Bearer xxx` → 解析 → 塞进 `request.setAttribute` → Controller 里通过 `@RequestAttribute` 拿到当前用户；
5. 能实现「滑动式 refresh token」——`POST /refresh` 换新 access 时**同时换新 refresh**，旧的作废；
6. 能实现 Redis 黑名单强制下线——`POST /logout` 把当前 token 的 md5 写入 `bl:<md5>`，拦截器每次校验前查 Redis。

#### 5.1.2 过程与方法目标
1. 通过「Session vs JWT」的对比表格，训练「用架构决策矩阵选技术」的思维；
2. 通过实际动手把 JWT payload 复制到 [jwt.io](https://jwt.io) 解码，直观理解「JWT 只是签名不是加密——payload 是明文」。

### 5.2 教学重难点
- **重点**：`Jwts.builder().subject(sub).claims(map).issuedAt(now).expiration(exp).signWith(key, HS256).compact()` 五段式／`Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload()` 三段式／HS256 secret 至少 32 字节的硬约束／`Authorization: Bearer <token>` 请求头约定
- **难点**：JWT 是 Base64 明文可读——**不能放密码、身份证等敏感数据**／`ExpiredJwtException` 与 `JwtException` 的分层捕获（过期 → 提示重新登录、非法 → 直接 401）／Redis 黑名单让 JWT 恢复「有状态」的取舍——纯无状态无法强制下线／`request.setAttribute` 在异步线程为空——请求作用域

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上课时把上节课 `LoginVO` 里那三个字段（username / realName / roles）打印出来投影——「同学们看，前端拿到这些字段是能显示了，可**下一次请求怎么知道你是 admin 而不是 tom**？」引出「请求鉴权」——传统方案 Session（服务端存），现代方案 JWT（客户端存签名字符串）。板书 Session 与 JWT 对比表，说清**分布式项目 100% 选 JWT**。

#### 新知讲授（14 分钟）

1. **JWT 三段结构**（4 分钟）：
   ```
   eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInVpZCI6MSwicm9sZXMiOlsiQURNSU4iXSwiaWF0IjoxNy4uLiwiZXhwIjoxNy4uLn0.pxT8j9UP...
   └─ Header ─────────┘└─ Payload ────────────────────────────────────────────────────────┘└─ Signature ┘
   ```
   - **Header**：算法（`HS256`）+ 类型（`JWT`），Base64 编码；
   - **Payload**：业务字段 `sub / uid / roles / iat / exp`，Base64 编码——**明文**，任何人复制到 jwt.io 都能解出来；
   - **Signature**：`HMACSHA256( base64(header) + "." + base64(payload), secret )`，**只有握着 secret 的服务端能生成 / 验签**；
   - **重点澄清**：JWT 是**签名不是加密**，Payload 是明文——**不能放密码、身份证、卡号**；能放的是「无所谓被看到但改了不算数」的字段。

2. **JJWT 0.12.6 API**（5 分钟）：
   - 三依赖：`jjwt-api`（编译期用）+ `jjwt-impl`（`runtime`）+ `jjwt-jackson`（`runtime`）——工程里只 import `jjwt-api`，运行期自动加载 impl；
   - 签发五段：`Jwts.builder().subject(username).claims(Map.of("uid",uid,"roles",roles)).issuedAt(now).expiration(exp).signWith(key, Jwts.SIG.HS256).compact()`；
   - 验签三段：`Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload()`；
   - JJWT 0.12 API 与 0.11 差异大——旧版 `setSubject` / `parseClaimsJws` 已废弃，AI 生成时**指定版本**才不踩坑。

3. **HS256 secret 至少 32 字节**（2 分钟）：
   - `Keys.hmacShaKeyFor(secret.getBytes(UTF_8))` 生成 `SecretKey`；
   - 少于 32 字节抛 `WeakKeyException: The specified key byte array is X bits which is not secure enough for any JWT HMAC-SHA algorithm.`；
   - 生产用环境变量 `${JWT_SECRET:pleaseUseAtLeast32ByteSecretInProd_xxxxxxxxxxxx}`，不硬编码。

4. **拦截器 + 上下文注入**（3 分钟）：
   - `req.getHeader("Authorization")` → `startsWith("Bearer ")` → `.substring(7)` 拿 token；
   - `jwt.parse(token) → Claims` → `req.setAttribute("currentUser", c.getSubject())` / `"currentUid"` / `"currentRoles"`；
   - Controller 里 `@RequestAttribute("currentUid") Long uid` 拿到，**无需从 header 手工解析**。

#### 示例演示（14 分钟）

1. **`JwtUtils` 工具类**（5 分钟）：
   - 现场敲：`@Value` 注入 `secret / ttl`，`@PostConstruct` 里 `Keys.hmacShaKeyFor` 初始化；
   - `issue(subject, claims)` 与 `parse(token)` 两方法；
   - 单元测试：签发一枚 → 复制到 https://jwt.io → 解码 Payload 全班围观——**直观看到明文**。

2. **`AuthController.login` 加签 JWT**（3 分钟）：
   - 上节课的 `login` 方法末尾追加：`String access = jwt.issue(u.username, Map.of("uid",u.id,"roles",u.roles))`；
   - `LoginVO` 加 `accessToken` `refreshToken` 两字段；
   - Postman 登录，观察返回体多了两个 token。

3. **`JwtInterceptor` + `WebMvcConfig` 注册**（4 分钟）：
   - `preHandle`：`instanceof HandlerMethod` → `@AuthIgnore` 放行 → `Authorization` 校验 → `jwt.parse` → `setAttribute` → return true；
   - 三个异常分支：header 空 / `ExpiredJwtException` → 「登录已过期，请重新登录」/ `JwtException` → 「Token 非法」；
   - `WebMvcConfig` 加白名单 `/login /logout /captcha /files/** /error`；
   - `GlobalExceptionHandler` 加 `@ExceptionHandler(AuthException.class) → 401`；
   - Postman 演示：不带 header 401 / 带对的 200 / 手动截断 token 末位 401 / 手动改 payload 后 401。

4. **滑动式 refresh + Redis 黑名单**（2 分钟）：
   - `POST /refresh` → 用 refresh 换新 access **同时换新 refresh**，旧 refresh `redis.delete`——安全性优于固定 refresh；
   - `POST /logout` → 把当前 token 的 md5 存 `bl:<md5>`，TTL 与 access ttl 相同；拦截器每次 `preHandle` 先查 Redis，命中就 401「Token 已失效」；
   - 这一步让「无状态」JWT 恢复「可强制下线」能力，代价是**引入了状态**——工程上完全可接受。

#### 课堂活动（10 分钟）
1. 每位学生完成三件事：① `JwtUtils` 工具类；② 登录接口签发 access + refresh；③ `JwtInterceptor` 注册。用 Postman 跑完整链路，交 5 张截图（登录成功 / 无 header 401 / 有 header 200 / 手动截断 token 401 / 过期后 401）；
2. 抽两位同学到讲台，一位把自己的 access token 复制到 https://jwt.io 解码给全班看 Payload——**直观感受「明文」**；
3. 讲师提问：「JWT 的 secret 泄露了会怎样？」（答：任何人都能签出合法 token，等于系统裸奔——必须立即换密钥并把旧 token 全部作废）；
4. 思考题：`request.setAttribute("currentUser", ...)` 在 `@Async` 线程里为什么拿不到？（提示：请求作用域）

#### 小结（3 分钟）
一句话回顾：**JJWT 0.12.6 五段签发 + 三段解析 + Bearer 请求头 + `setAttribute` 上下文 + 黑名单强制下线**。到此已经能拦下所有未授权请求了，但**登录接口本身仍可被脚本无限刷**——下节课加上图形验证码把这最后一块补齐。

### 5.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-05 JWT 签发与校验                       │
├───────────────────────────────────────────────┤
│  JWT 三段：                                   │
│   Header.Payload.Signature                    │
│   Header/Payload 明文 Base64                  │
│   Signature = HMACSHA256(h.p, secret)         │
│                                               │
│  Session vs JWT：                             │
│   服务端存 vs 客户端存                        │
│   sticky/Redis vs 无状态                      │
│   删 Session vs 黑名单                        │
│                                               │
│  JJWT 0.12.6：                                │
│   jjwt-api (compile)                          │
│   jjwt-impl (runtime)                         │
│   jjwt-jackson (runtime)                      │
│                                               │
│  签发：                                       │
│   Jwts.builder()                              │
│     .subject(sub)                             │
│     .claims(map)                              │
│     .issuedAt(now)                            │
│     .expiration(exp)                          │
│     .signWith(key, Jwts.SIG.HS256)            │
│     .compact()                                │
│                                               │
│  验签：                                       │
│   Jwts.parser().verifyWith(key)               │
│     .build().parseSignedClaims(t).getPayload()│
│                                               │
│  拦截器：                                     │
│   Bearer → substring(7) → parse               │
│   → request.setAttribute currentUser          │
│   ExpiredJwtException → 过期                  │
│   JwtException → 非法                         │
│                                               │
│  强制下线：                                   │
│   Redis bl:<md5> 黑名单                       │
│   滑动式 refresh（旧作废）                    │
└───────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 `JwtUtils / JwtInterceptor / AuthController.login / logout / refresh` 五件套，跑通「登录 → 请求 → 过期 → 刷新 → 下线」五幕联调；
2. **必做**：把 JWT ttl 临时改成 30 秒，观察 access 过期后前端如何用 refresh 换新——加深「短命 access + 长命 refresh」的印象；
3. **挑战**：把 secret 改成「多密钥滚动」——`issue` 用 v2，`parse` 允许 v1/v2 都通过，用于生产环境无缝换密钥。

### 5.6 教学反思提示
- 学生最容易在 secret 上翻车——`yaml` 里写了短字符串就启动，`WeakKeyException` 一栈信息学生完全看不懂，提前告诉「至少 32 字节」并演示报错样例；
- 演示 `jwt.io` 解码 payload 时**一定要选一个不带敏感信息的 token**（示例里 payload 只放 uid/roles），让学生养成「不放隐私」的直觉；
- 讲师抽学生上台把 payload 里 `uid` 从 1 手工改成 2 再重放，观察拦截器抛 `SignatureException`——让「签名保护 payload 不被篡改」这个概念落地。

---

## 第 6 课时：图形验证码 + 登录防护

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能引入 `com.github.penggle:kaptcha:2.3.2`，写 `KaptchaConfig` 定制字符长度 / 字体 / 字符集 / 干扰线；
2. 能实现 `GET /captcha` 接口：生成 UUID 作 key，验证码文本存 Redis `cap:<key>` 有效期 3 分钟，图片转 Base64 塞进响应体 `data:image/jpeg;base64,...`；
3. 能改造 `LoginDTO` 加 `captchaKey / captchaCode` 两个字段，`AuthController.login` 首先校验验证码，**无论对错都 `redis.delete` 掉**（防复用）；
4. 能实现「登录失败次数」防护——同一账号 5 分钟内错 5 次锁定 15 分钟（Redis `INCR` + `EXPIRE`），错误消息模糊化；
5. 能画出 Day11 六课时的知识地图，说清「预约业务 + 拦截器 + JWT + 验证码 = 后端 Part 2 完整闭环」。

#### 6.1.2 过程与方法目标
1. 通过「验证码为什么用 base64 而不是流响应」这一细节，训练「减少来回请求」的接口设计意识；
2. 通过对 Part 2（Day09–Day11）三日知识做地图梳理，训练「模块化理解 + 承前启后」的能力。

### 6.2 教学重难点
- **重点**：`DefaultKaptcha` 配置项／`ImageIO.write(image, "jpg", bos)` + Base64 编码／Redis `cap:<key>` 3 分钟有效期／`redis.delete(capKey)` 不管对错都要删（防复用）／`LoginDTO` 加 captcha 字段后的联调
- **难点**：为什么用 base64 而不是流响应（**前端 `<img src="data:...">` 直接展示 + 不必设置 cookie**）／`AllowedHeaders: Authorization` 跨域配置容易漏／短信验证码同样要防刷（本课只提，不深入）／验证码只保护登录还不够——找回密码 / 短信发送 / 敏感操作都要挂

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：「上节课登录接口跑通了，我现在写一个 shell 循环 `while true; do curl -X POST http://localhost:8080/login -d '{"username":"admin","password":"123456"}'; done`，一秒能刷几百次——这就是**撞库**。你的 `admin/123456` 也许能扛住，但普通用户呢？」引出图形验证码——**给登录加一道人类才能过的关卡**，让脚本刷不动。

#### 新知讲授（14 分钟）

1. **Kaptcha 依赖与配置**（4 分钟）：
   - `com.github.penggle:kaptcha:2.3.2`；
   - `DefaultKaptcha` Bean，`Properties` 定制：
     - `kaptcha.textproducer.char.length = 4` —— 4 位；
     - `kaptcha.textproducer.font.size = 36`；
     - `kaptcha.textproducer.char.string = abcdefghjkmnpqrstuvwxyz23456789` —— **去掉容易混淆的 `i l 1 0 o`**；
     - `kaptcha.noise.impl = com.google.code.kaptcha.impl.NoNoise` —— 教学用，不加噪；
   - `kaptcha.createText()` 生成文本、`kaptcha.createImage(text)` 生成 `BufferedImage`。

2. **`GET /captcha` 接口**（5 分钟）：
   - UUID 作 key（不带 `-`）：`UUID.randomUUID().toString().replace("-", "")`；
   - `BufferedImage` → `ByteArrayOutputStream` → `Base64.getEncoder().encodeToString(bos.toByteArray())` → 前缀拼 `data:image/jpeg;base64,`；
   - Redis `cap:<key>` 存 `text.toLowerCase()`（**忽略大小写**），TTL 3 分钟；
   - 返回 `CaptchaVO(key, imageBase64)`；
   - 为什么 base64 不用流响应：① 前端 `<img src="{{ img }}">` 直接展示 ② 不必设置 cookie ③ **不用二次请求**。

3. **`LoginDTO` 加两字段 + `login` 校验**（3 分钟）：
   - `LoginDTO` 加 `@NotBlank captchaKey / captchaCode` 两字段；
   - `login` 方法体首先：`String expect = redis.opsForValue().get("cap:"+captchaKey); redis.delete("cap:"+captchaKey); if (expect == null || !expect.equalsIgnoreCase(captchaCode)) throw ...`；
   - **`redis.delete` 无论对错都执行**——**验证码一次性**，防复用 / 防脚本试错。

4. **登录失败次数防护**（2 分钟）：
   - Redis `login:fail:<username>` 计数 + `EXPIRE 300`；
   - `if (count >= 5) throw new BizException("账号已锁定 15 分钟")`；
   - 密码错时 `INCR`，密码对时 `DELETE`；
   - 讲师提问：「为什么按账号而不是按 IP？」（提示：IP 可能是 NAT 或代理，账号是攻击目标）

#### 示例演示（14 分钟）

1. **Kaptcha 配置 + `/captcha` 接口**（5 分钟）：
   - `KaptchaConfig` 现场敲；
   - `CaptchaController` 现场敲；
   - Postman `GET /captcha` 观察返回体：`{"code":0,"data":{"key":"xxx","image":"data:image/jpeg;base64,/9j/4AAQ..."}}`；
   - 把 base64 字符串复制到浏览器地址栏，直接看到图片——**base64 免二次请求的核心红利**。

2. **改造 `login` 加验证码校验**（4 分钟）：
   - `LoginDTO` 加两字段；
   - `AuthController.login` 首行加验证码校验；
   - Postman：① 先 `GET /captcha` 拿 key + image；② 人眼看图输入 code；③ `POST /login` 带 `{username, password, captchaKey, captchaCode}` → 200；
   - 演示三种错误：验证码错 / 验证码过期 / 已用过的验证码复用。

3. **登录失败次数防护**（3 分钟）：
   - `AdminUserService.checkLogin` 里加 Redis 计数逻辑；
   - Postman 连续错 5 次密码，第 6 次即使密码对也拒「账号已锁定 15 分钟」；
   - 手工 `DEL login:fail:admin` 解锁再试，恢复正常。

4. **Day09–Day11 知识地图 + 承前启后**（2 分钟）：
   - 投影 mindmap（同 22.13）——业务模块 / 公共能力 / 工程实践；
   - 强调：Day12 起切前端 Vue 3，第一件事就是**把今天的验证码 + 登录 + JWT 拦截**在前端跑通。

#### 课堂活动（10 分钟）
1. 每位学生：① Kaptcha 依赖 + `KaptchaConfig`；② `GET /captcha` 接口；③ 改造 `login` 校验验证码。Postman 全链路跑通交 4 张截图（拿验证码 / 输错 / 输对 / 复用被拒）；
2. 讲师抽两位同学到讲台，一位说清「为什么用 base64 不用流响应」，一位说清「为什么 `redis.delete` 不管对错都要执行」；
3. 追加：把「登录失败 5 次锁 15 分钟」实现出来；
4. 思考题：验证码只保护登录够不够？（提示：短信发送、找回密码、评论等任何可被刷的接口都要挂）

#### 小结（3 分钟）
Day11 六课时收官：**预约创建六步、生命周期五动作、拦截器门神、BCrypt 加盐、JWT 五段签发、图形验证码防刷**——后端 Part 2 完整闭环。**能力自检**：能独立完成一个「基本 CRUD + 多约束 + 并发扣减」业务模块、能说清「幂等 UK + Redis 扣减」并发方案、能写 Interceptor + JWT + 图形验证码构成的登录鉴权链。Day12 我们把这些接口搬到 Vue 3 前端，做出可交付的产品页面。

### 6.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-06 图形验证码 + 登录防护                │
├───────────────────────────────────────────────┤
│  Kaptcha 配置：                               │
│   char.length = 4                             │
│   char.string 去掉 i l 1 0 o                  │
│   NoNoise（教学用）                            │
│                                               │
│  /captcha 接口：                              │
│   UUID key                                    │
│   BufferedImage → base64                      │
│   Redis cap:<key> TTL 3min                    │
│   返回 CaptchaVO(key, image)                  │
│                                               │
│  base64 vs 流响应：                           │
│   前端 <img src="data:..."> 直接展示          │
│   免 cookie                                   │
│   免二次请求                                  │
│                                               │
│  login 校验：                                 │
│   ① 取 cap:<key>                              │
│   ② redis.delete 不管对错                     │
│   ③ equalsIgnoreCase                          │
│   ④ BCrypt.checkpw                            │
│   ⑤ 签发 access + refresh                     │
│                                               │
│  失败次数防护：                               │
│   Redis login:fail:<user> INCR                │
│   EXPIRE 300                                  │
│   >= 5 锁 15 分钟                             │
│                                               │
│  Day09-11 知识地图：                          │
│   业务：会员/教练/课程/预约                    │
│   公共：OSS/AOP/Redis/JWT/Captcha             │
│   工程：DTO-VO / 联表 / 并发扣减 / 令牌       │
└───────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成 `/captcha + 改造 login + 登录失败次数` 三件套，交 5 张 Postman 截图；
2. **必做**：把 6 课时代码合并成一个 PR，commit 信息按 conventional commits `feat(booking): ...` `feat(auth): ...` `feat(captcha): ...` 分三次；
3. **挑战**：用 AI 助手生成「短信验证码登录」接口——`POST /sms/send`（手机号 + 图形验证码前置校验）+ `POST /login/sms`（手机号 + 短信码），复用今天所有防护逻辑；
4. **挑战**：把验证码接口挂上限流——同一 IP 每分钟最多请求 20 次，用 Redis + 拦截器实现。

### 6.6 教学反思提示
- 学生最容易忘 `redis.delete(capKey)` 里的「不管对错都删」——密码错也删，学生会疑惑「密码错为什么把验证码删了」，讲师抽学生问一下「不删的话攻击者能反复试同一组吗」引出「一次性 nonce」的概念；
- 讲验证码字符集时**故意用带 `1 l 0 o i` 的默认字符集**演示一次，全班用眼睛读，感受易混淆字符对用户体验的伤害，再改成 `abcdefghjkmnpqrstuvwxyz23456789`；
- Day11 收官时把 Day09–Day11 mindmap 投影 3 分钟，让学生把「零散知识」压缩成一张知识地图——上课时讲授的东西太多，收官时必须做「解压→重新压缩」这一步；
- 提前预告 Day12：Vue 3 工程化 + Router + Axios + 登录页 + 拦截器——**今天的接口，明天就要在前端跑起来**。

---

## 附录 A：Day11 完整代码清单（供学员复现）

**新增文件**：
- `dto/BookingCreateDTO.java` / `dto/BookingPageQuery.java` / `vo/BookingVO.java` / `vo/BookingBriefVO.java`
- `entity/Booking.java` / `entity/AdminUser.java`
- `mapper/BookingMapper.java` / `mapper/AdminUserMapper.java`
- `mapper/BookingMapper.xml`（含 `page / countMemberConflict / countActive / updateStatus / checkIn / markAbsent / calendar`）
- `service/BookingService.java` / `service/AdminUserService.java`
- `controller/BookingController.java` / `controller/AuthController.java` / `controller/CaptchaController.java`
- `interceptor/JwtInterceptor.java` / `interceptor/LogInterceptor.java`
- `config/WebMvcConfig.java` / `config/KaptchaConfig.java`
- `util/JwtUtils.java`
- `annotation/AuthIgnore.java`
- `exception/AuthException.java` + `GlobalExceptionHandler` 新增 `@ExceptionHandler(AuthException.class)`

**数据库迁移**：
- `V11__create_tb_booking.sql`
- `V11__create_tb_admin_user.sql` + 初始 admin BCrypt 密文

**配置更新**：
- `application.yml` 增补 `yinxiang.jwt.secret / ttl / refresh-ttl / header / prefix`

---

## 附录 B：Day11 联调剧本汇总

| 步骤 | 请求 | 期望 |
|---|---|---|
| 1 | `GET /captcha` | 200 + `{key, image}` |
| 2 | `POST /login`（错误验证码） | 400「验证码错误或已过期」 |
| 3 | `POST /login`（正确） | 200 + `access / refresh / username / roles` |
| 4 | `GET /bookings`（不带 header） | 401「未登录」 |
| 5 | `GET /bookings`（带 Bearer） | 200 分页 |
| 6 | `POST /bookings` 预约课程 | 200 + `bookingId` + Redis `course:booked:X` +1 |
| 7 | 同会员同课再预约 | 400「请勿重复预约」（UK 命中） |
| 8 | 3 会员并发抢容量=2 的课 | 只 2 成功、1「名额已满」 |
| 9 | 距开课 <2h 取消 | 400「距开课不足 2 小时」 |
| 10 | 距开课前 30min 内签到 | 200 + `status=3` + `check_in_time` |
| 11 | 手工把课程 `end_time` 改成 1 分钟前 → 触发 `scanAbsent` | `status=4 缺席` |
| 12 | JWT ttl 到期 | 401「登录已过期」 |
| 13 | `POST /refresh` 换新 access | 200，旧 refresh 作废 |
| 14 | `POST /logout` → 再次用旧 access | 401「Token 已失效」 |
| 15 | 连续密码错 5 次 | 400「账号已锁定 15 分钟」 |

---

## 附录 C：Day11 AI 助手使用清单

**AI 常犯错清单**（六课时汇总）：

1. Redis 首次 `INCR` 不同步 DB 已有数据；
2. 抛异常时忘记 `DECR` 回滚 Redis；
3. 课程状态 UPDATE 不带 `WHERE fromStatus` 条件；
4. 事务内的 Redis 操作误以为参与回滚；
5. 拦截器忘记 `handler instanceof HandlerMethod` 判断；
6. 白名单里漏 `/error`，异常时死循环；
7. `preHandle` 用 `return false` 而不是抛异常，无法带出状态码；
8. 用 MD5 或明文存密码；
9. JWT secret 不足 32 字节；
10. 用 JJWT 0.11 老 API（`setSubject / parseClaimsJws`）；
11. Payload 里塞密码 / 身份证等敏感数据；
12. 验证码不管对错都要 `redis.delete`——AI 只在对时删；
13. 验证码字符集含 `i l 1 0 o` 易混淆字符；
14. 登录接口错误消息「账号不存在」「密码错」区分开——帮撞库；
15. `application.yml` 里 AK / secret 硬编码而非环境变量。

**提示词模板**（一次到位）：

> 请为 Spring Boot 4.0.x + MyBatis 3.5 + Redis 8 + JJWT 0.12.6 项目生成「预约模块 + JWT 登录鉴权」代码，需求：
> 1. `tb_booking` 建表：字段 `booking_no / member_id / course_id / card_id / status[1-4] / cancel_reason / check_in_time / remark / deleted / create_time / update_time`；UK: `booking_no`，`(member_id, course_id, deleted)`；索引 `(course_id, status)` `(member_id, create_time)`；
> 2. Service 方法：`create / cancel / checkIn / page / calendar`，字段校验用 Jakarta，业务校验按状态机；名额扣减用 Redis `INCR course:booked:<id>`，超出容量回滚 `DECR`；DB UK 兜底；事务 `@Transactional(rollbackFor = Exception.class)`；异常必手工 `DECR`；
> 3. `@Scheduled scanAbsent` 缺席扫描；
> 4. `HandlerInterceptor` + `WebMvcConfigurer`：Bearer 解析 JWT → `setAttribute currentUser / currentUid / currentRoles`；`@AuthIgnore` 注解白名单；`/login /logout /captcha /error /files/**` 排除；`AuthException` 抛出改为 401；
> 5. JJWT 0.12.6 API：`Keys.hmacShaKeyFor` + `Jwts.builder().subject().claims().issuedAt().expiration().signWith(key, SIG.HS256).compact()`；secret ≥ 32 字节；
> 6. Kaptcha 图形验证码：`GET /captcha` 返回 `{key, image(base64)}`，Redis `cap:<key>` TTL 3 分钟；`/login` 首校验并 `redis.delete` 一次性；
> 7. BCrypt 加盐密码，`spring-security-crypto`；
> 8. GlobalExceptionHandler 覆盖 `BizException / AuthException / MethodArgumentNotValidException / ExpiredJwtException`。

**AI 输出后必查清单**：见「AI 常犯错清单」15 条。

---

## 附录 D：Day11 常见坑与排查表

| 现象 | 原因 / 建议 |
|---|---|
| 并发预约「多卖」 | Redis 首次 `INCR` 未同步 DB 已有数据；捕获异常时忘 `DECR` |
| 取消后无法再预约 | `uk_member_course` 未包含 `deleted` |
| 定时任务重复执行 | 多机部署 `@Scheduled` 无锁，需 ShedLock 或 Redisson |
| `WeakKeyException` | JWT secret < 32 字节 |
| Postman 401 无响应体 | 拦截器 `return false` 而非抛异常 |
| 拦截器死循环 | 白名单漏 `/error` |
| 静态资源触发 `ClassCastException` | `handler` 未做 `instanceof HandlerMethod` 判断 |
| `request.getAttribute("currentUser")` 在 `@Async` 为空 | 请求作用域，用 ThreadLocal / TaskDecorator |
| CORS 401 「header 丢了」 | `Access-Control-Allow-Headers` 缺 `Authorization` |
| 验证码「已用一次的还能过」 | 忘记 `redis.delete(capKey)` |
| 登录报错「密码错」和「账号不存在」不同消息 | 帮撞库，务必模糊化 |
| JWT payload 被前端解出敏感字段 | payload 只放 `uid / roles / exp`，敏感数据留 DB |

---

（Day11 教案完，共 6 课时 × 45 分钟，配套讲义见 `讲义/day11.md`）
