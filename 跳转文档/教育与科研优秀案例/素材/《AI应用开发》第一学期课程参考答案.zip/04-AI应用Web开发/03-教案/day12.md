# 《AI 应用 Web 开发》 - 教师教案（Day12：Vue 3 工程化 + Router + Axios + Element Plus）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day11 的学生（掌握 Spring Boot 4.0.x 后端、JWT 登录、统一 Result、AOP 操作日志，且具备 HTML/CSS/JS 基础，能读懂 ES6 语法）**
**知识点覆盖：** 第 23 章 Vue 3 工程化 + Router + Axios（Vite + TS 脚手架、目录规约、Vue Router 4、Axios 二次封装） + 第 24 章 Element Plus 与前端项目准备（按需引入、通用布局、常用组件、Mock 联调）

**技术版本基线**：Node.js 20 LTS / pnpm 9.x / Vue 3.5.x / Vite 5.x / TypeScript 5.x / vue-router 4.x / pinia 3.x / axios 1.7+ / element-plus 3.x / IDEA 2024.3+（前端可用 VS Code 或 WebStorm）/ 通义灵码 + Trae。

**Day12 主线**：印想瑜伽会馆客户管理系统前端项目 `yoga-admin` 从零起手——**前 3 个课时**打通「Vite 建项目 → 组合式 API 写页面 → VueRouter 4 组织路由」这条主链，让学生第一次跑通「登录页 → dashboard」的完整跳转闭环；**后 3 个课时**把 Axios 二次封装、Element Plus 按需引入、目录规范与 Mock 数据一并落地，最终交付一个「会员列表页」小 Demo——它调用二次封装过的 axios、渲染 Element Plus 表格、支持分页与查询，是后续 Day13 会员管理页面的直接底座。

---

## 第 1 课时：Vue 3 概述 + Vite 创建 yoga-admin 项目

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出「浏览器 CDN 引入 Vue」与「Vite 工程化项目」在模块系统、构建、热更新、SFC 支持四个维度上的差异；
2. 能说清 Node.js / npm / pnpm / Vite / TypeScript 五个工具的分工，并类比后端 JDK / Maven / Java 建立心智模型；
3. 能用 `pnpm create vite@latest yoga-admin -- --template vue-ts` 生成基础项目，`pnpm install` + `pnpm dev` 跑通 5173 端口的欢迎页；
4. 能读懂脚手架生成的 `package.json / vite.config.ts / tsconfig.json / index.html / main.ts / App.vue` 六个关键文件的职责；
5. 能修改 `vite.config.ts`：配置 `@` 别名指向 `src`，配置 `/api` 代理指向 `http://localhost:8080`。

#### 1.1.2 过程与方法目标
1. 通过「先跑通再拆解」的顺序，训练「以运行结果为中心」的验收习惯，避免上来一头钻进 TS 语法；
2. 通过与后端工程（Maven/Spring Boot）对照，让已完成 Day01–Day11 的学生把工程化经验平移到前端。

### 1.2 教学重难点
- **重点**：Node.js 20 LTS 与 pnpm 9 的安装与版本校验／Vite 项目脚手架命令／`vite.config.ts` 的 `alias` 与 `proxy` 两处配置／脚手架六大关键文件的职责划分
- **难点**：pnpm 与 npm 的软链接机制导致的「node_modules 目录看起来空空的」错觉／Vite `proxy` 与浏览器 CORS 的对应关系（为什么本地开发不会出 CORS 报错）／`import.meta.env` 前缀 `VITE_` 的强约束

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
从 Day09 那句「后端接口跑通了，前端一直问图片 URL 从哪来」讲起：Day12 就把印想瑜伽会馆的**管理后台前端项目**从零建起来，项目名叫 `yoga-admin`，跑在 5173 端口，调用的正是 Day01–Day11 建好的 8080 后端。抛出目标：**这 6 个课时结束时，学生能进入登录页、跳转到 dashboard、看到一个可分页的会员列表表格**。

#### 新知讲授（14 分钟）

1. **为什么需要工程化**（4 分钟）：对照 Day10 之前的 `<script src="vue.global.js">` 简单页面——① 没有模块系统，代码全塞进一个 script；② 无法用 `.vue` 单文件组件；③ 无法使用 ES6+ / TypeScript；④ 没有构建时优化（tree-shaking / 压缩 / 懒加载）；⑤ 没有开发环境热更新。工程化 = 引入构建工具，Vue 官方钦定 **Vite**（冷启动秒级）。

2. **工具链心智模型**（5 分钟）：
   - **Node.js 20 LTS**：前端的 JDK，是 JS 的运行时；
   - **pnpm 9.x**：前端的 Maven，比 npm 更快 + 磁盘友好（软链复用）；
   - **Vite 5.x**：前端的构建工具，等价于 Maven package 的角色；
   - **TypeScript 5.x**：可选，本教程用 TS 模板但只用最基本子集（类型注解 + 接口）；
   - **Vue 3.5.x**：视图框架本身。
   - 一条命令验版本：`node -v && pnpm -v` 分别输出 `v20.x` 和 `9.x`；若无 pnpm，`npm i -g pnpm`。

3. **Vite 项目结构 6 件套**（5 分钟）：`package.json`（依赖清单 + scripts）／`vite.config.ts`（构建配置）／`tsconfig.json`（TS 编译配置）／`index.html`（唯一 HTML 入口，`<div id="app">` + `<script type="module" src="/src/main.ts">`）／`src/main.ts`（JS 入口，`createApp(App).mount('#app')`）／`src/App.vue`（根组件，用 SFC 语法）。SFC = `<template>` + `<script>` + `<style>` 三段式。

#### 示例演示（15 分钟）

1. **建项目**（5 分钟）：
   - 进入 `D:/workspace/yoga-admin-parent`（项目父目录），执行 `pnpm create vite@latest yoga-admin -- --template vue-ts`；
   - `cd yoga-admin`，`pnpm install`——现场观察 `node_modules` 与 `.pnpm/` 硬链接目录，讲一句「pnpm 通过全局仓库 + 软链复用，磁盘占用比 npm 小 60%」；
   - `pnpm dev` 启动，浏览器打开 `http://localhost:5173`，看到 Vue logo 页面。

2. **改造 `vite.config.ts`**（6 分钟）：

   ```ts
   import { defineConfig } from 'vite'
   import vue from '@vitejs/plugin-vue'
   import { fileURLToPath, URL } from 'node:url'

   export default defineConfig({
     plugins: [vue()],
     resolve: {
       alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) }
     },
     server: {
       port: 5173,
       proxy: {
         '/api': {
           target: 'http://localhost:8080',
           changeOrigin: true,
           rewrite: p => p.replace(/^\/api/, '')
         }
       }
     }
   })
   ```

   - `@` 指向 `src`，避免 `../../../` 相对地狱；
   - `proxy` 让开发环境所有 `/api/**` 走 Vite 中转到 8080，**浏览器看到的是同源请求**，绕开 CORS；
   - 记得同步改 `tsconfig.json` 的 `paths`，让 TS 也认识 `@/*`（否则 IDE 报红线，但构建能过——这是一个必栽的坑）。

3. **`.env.development` 与 `.env.production`**（4 分钟）：
   - 开发：`VITE_API_BASE = /api` + `VITE_APP_TITLE = 印想瑜伽-管理后台（DEV）`；
   - 生产：`VITE_API_BASE = /api` + `VITE_APP_TITLE = 印想瑜伽-管理后台`（生产由 nginx 反代做 /api → 8080）；
   - **重点强调**：**只有以 `VITE_` 开头的变量才会被打包进前端**。密钥永远**不能**放这里。

#### 课堂练习（9 分钟）
1. 每位学生完成 `pnpm create vite` → `pnpm install` → `pnpm dev` 三连，交一张截图（浏览器 5173 端口 Vue logo 页）；
2. 修改 `App.vue` 的模板文字为「印想瑜伽 · 管理后台」，验证热更新生效（保存文件后不刷新浏览器也变了）；
3. 追加需求：在 `App.vue` 里加一行 `<p>{{ title }}</p>`，其中 `title = import.meta.env.VITE_APP_TITLE`，页面上要能看到「印想瑜伽-管理后台（DEV）」。

#### 小结（3 分钟）
一句话回顾：**Node 20 + pnpm 9 + Vite 5 + Vue 3 + TS**——五件套齐全，`yoga-admin` 项目跑起来了。下一课时讲 Vue 3 的两种写法：选项式 vs 组合式，把 `App.vue` 从 hello 世界变成一个真会员登录页的雏形。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-01 Vue 3 概述 + Vite 建 yoga-admin     │
├──────────────────────────────────────────────┤
│  为什么工程化：                              │
│   模块系统 / SFC / TS / Tree-shaking / HMR   │
│                                              │
│  工具链五件套：                              │
│   Node 20   ↔ 后端 JDK                       │
│   pnpm 9    ↔ 后端 Maven                     │
│   Vite 5    ↔ 后端 Maven package             │
│   TS 5      ↔ 后端 Java                      │
│   Vue 3.5   视图框架                         │
│                                              │
│  一条命令建项目：                            │
│   pnpm create vite@latest yoga-admin \       │
│     -- --template vue-ts                     │
│                                              │
│  Vite 6 大关键文件：                         │
│   package.json / vite.config.ts /            │
│   tsconfig.json / index.html /               │
│   src/main.ts / src/App.vue                  │
│                                              │
│  vite.config.ts 两处配置：                   │
│   alias: '@' -> ./src                        │
│   proxy: /api -> localhost:8080              │
│                                              │
│  环境变量：                                  │
│   VITE_ 前缀才会被打包                       │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `yoga-admin` 项目脚手架，交 3 张截图（`node -v` + `pnpm -v` 输出 / `pnpm dev` 终端截图 / 浏览器 5173 页面）；
2. **必做**：修改 `vite.config.ts`，同时配置 `alias` 与 `proxy`，然后在 `App.vue` 里用 `fetch('/api/hello')` 触发一次请求（后端未跑通没关系，看 Network 面板里请求是否被代理到 8080）；
3. **挑战**：给 `.env.development` 加 `VITE_MODE_TAG = dev-local`，在 `App.vue` 里读出并显示；再定义一个 `NOT_VITE_SECRET = xxx`，观察它在 `import.meta.env` 里是否存在。

### 1.6 教学反思提示
- Windows 学生装 Node 时若走的是 Microsoft Store 版本，可能出现 pnpm 全局包权限报错，建议卸载后从 nodejs.org 下 LTS msi 安装；
- pnpm 首次启动可能触发 `corepack enable` 才能识别 `packageManager` 字段，若遇到「Unknown Command」提示，让学生执行 `corepack enable` 或直接 `npm i -g pnpm@9`；
- 有学生会把项目建在中文路径下，Vite 通常没问题但 Windows 下偶发路径解析怪异，示例演示时强调**用纯英文路径**；
- 若课堂时间紧，环境变量小节可以留到下一课时开场再讲。

---

## 第 2 课时：选项式 API vs 组合式 API（setup / ref / reactive / computed）

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能对比 Options API（Vue 2 风格：data/methods/computed 分块）与 Composition API（Vue 3 风格：`<script setup>` 平铺）在可维护性、逻辑复用、TS 友好度三个维度的差异；
2. 能正确使用 `ref` 与 `reactive` 声明响应式变量，并说清「基本类型必须用 ref、深层对象推荐 reactive」的选型依据；
3. 能用 `computed` 声明派生状态（如「密码是否合法」「表单是否可提交」），并解释为什么不用普通函数；
4. 能写一个「登录表单雏形」组件：`form.username / form.password` 双向绑定 + `canSubmit` 计算属性 + 点击按钮打印 form；
5. 能用 `watch` 与 `watchEffect` 监听响应式变化，理解「立即执行 vs 惰性执行」「浅监听 vs 深监听」的区别。

#### 2.1.2 过程与方法目标
1. 通过「同一段登录表单代码写两遍」（一遍 Options、一遍 Composition），让学生用眼睛感受两种风格的差别；
2. 通过 `.value` 出错的现场演示，训练「响应式变量必须解引用」的肌肉记忆。

### 2.2 教学重难点
- **重点**：`ref` 与 `reactive` 的使用与选型／`<script setup>` 语法糖／`computed` 的 getter 声明／`v-model` 双向绑定
- **难点**：`ref` 在 `<script>` 里必须 `.value` 但在 `<template>` 里自动解引用的「魔法」／`reactive` 解构会丢失响应性（必须 `toRefs`）／`computed` vs `methods` 的缓存差异

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
上一课时 `App.vue` 里的 `msg` 用了 `ref('Hello Vite + Vue')`，为什么要包一层 `ref()`？直接写 `let msg = 'Hello'` 会怎样？——引出**响应式**核心话题：**Vue 追踪的是「你告诉 Vue 我要追踪的变量」**，普通变量修改视图不会更新。

#### 新知讲授（15 分钟）

1. **两种 API 风格对比**（5 分钟）：现场敲两遍同一个「计数器 + 双倍值 + 增加按钮」组件：
   - **Options API**：`data() { return { count: 0 } }` + `computed: { double() { return this.count*2 } }` + `methods: { inc() { this.count++ } }`——**逻辑按种类分块**，一个业务点散在三处；
   - **Composition API**：`<script setup>` 里三行：`const count = ref(0)` + `const double = computed(() => count.value*2)` + `function inc() { count.value++ }`——**逻辑按业务聚合**，同一个业务的代码就在相邻几行；
   - 结论：**新项目一律用 `<script setup>`**，Options API 只在维护老代码时看得懂即可。

2. **`ref` 与 `reactive`**（5 分钟）：
   - `ref(value)`：适合基本类型（`number / string / boolean`），返回 `{ value: T }`——**`.value` 是访问约定**；
   - `reactive(obj)`：适合对象（`{}` 或 `[]`），返回 Proxy 代理——**属性访问不用 `.value`**；
   - **选型口诀**：**基本类型用 `ref`、表单/对象用 `reactive`**；
   - **陷阱**：`const { username } = reactive({ username: 'a' })` 解构后 `username` 是一个普通字符串，改它视图不更新——必须 `toRefs()` 或直接访问原对象。

3. **`computed`**（3 分钟）：
   - `computed(() => expr)` 声明**基于响应式变量的派生值**；
   - vs 普通函数：`computed` **有缓存**，依赖不变时不重复计算；`methods` 每次调用都跑一遍；
   - 典型用途：表单是否可提交、列表过滤、总价计算。

4. **`watch` 与 `watchEffect`**（2 分钟）：
   - `watch(source, cb, options)`：**惰性**，只在依赖变化时触发；
   - `watchEffect(fn)`：**立即执行一次**，自动收集依赖；
   - 选型：只关心「变化后干什么」用 `watch`；「有依赖就跑一次」用 `watchEffect`。

#### 示例演示（15 分钟）

1. **写「登录表单雏形」**（10 分钟）：

   `src/App.vue`：
   ```vue
   <template>
     <div style="max-width:360px;margin:80px auto;font-family:sans-serif">
       <h2>{{ title }}</h2>
       <input v-model="form.username" placeholder="用户名"><br><br>
       <input v-model="form.password" type="password" placeholder="密码"><br><br>
       <button :disabled="!canSubmit" @click="submit">
         {{ loading ? '登录中…' : '登录' }}
       </button>
       <p style="color:#999">canSubmit = {{ canSubmit }}</p>
     </div>
   </template>

   <script setup lang="ts">
   import { reactive, ref, computed, watch } from 'vue'

   const title = import.meta.env.VITE_APP_TITLE
   const form = reactive({ username: '', password: '' })
   const loading = ref(false)

   const canSubmit = computed(() =>
     form.username.trim().length >= 3 &&
     form.password.length >= 6 &&
     !loading.value
   )

   watch(() => form.username, v => console.log('用户名变化：', v))

   async function submit() {
     loading.value = true
     await new Promise(r => setTimeout(r, 800))     // 模拟接口
     console.log('提交：', form)
     loading.value = false
   }
   </script>
   ```

   - 现场按输入框，观察 `canSubmit` 从 `false` 变 `true`；
   - 点登录按钮 → 按钮变灰 → 800ms 后恢复；
   - 打开 DevTools 看 `console.log`。

2. **踩坑演示**（5 分钟）：
   - 把 `<script>` 里的 `form.username` 改成 `form.value.username` → 报错 `undefined`；
   - 把 `const canSubmit = computed(...)` 改成 `function canSubmit()`，然后模板里改成 `canSubmit()`——功能等价，但每次渲染都会重新计算（用 `console.log('computed')` 放函数体里对比调用次数）；
   - `const { username } = form` 之后修改 `username`——视图不更新，讲清「解构丢响应性」。

#### 课堂练习（9 分钟）
1. 每位学生完成登录表单雏形，提交 3 张截图（未填时按钮灰 / 填够长按钮亮 / 点击后 800ms loading）；
2. 追加需求：加一个 `rememberMe` 复选框（`ref<boolean>`），与 `form` 一起打印；
3. 思考题：若把 `form` 换成 `ref({ username: '', password: '' })`，模板与脚本要改几处？

#### 小结（3 分钟）
一句话回顾：**`<script setup>` + `ref/reactive/computed/watch` 四件套已经覆盖 90% 单文件组件场景**。下一课时把这些组件挂到 VueRouter 4 里，让 `/login` `/dashboard` `/members` 三条路径能互相跳转。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-02 组合式 API 四件套                   │
├──────────────────────────────────────────────┤
│  Options API   ↔   Composition API           │
│  ─────────────    ────────────────           │
│  按种类分块        按业务聚合                 │
│  data/methods…    <script setup> 平铺        │
│  this.xxx         直接引用变量               │
│                                              │
│  ref(v)      → 基本类型     .value           │
│  reactive(o) → 对象/数组    直接访问         │
│  computed()  → 派生 + 缓存                   │
│  watch/watchEffect → 副作用                  │
│                                              │
│  陷阱：                                      │
│   1. ref 在 <script> 必须 .value             │
│      在 <template> 自动解引用                │
│   2. 解构 reactive 丢响应性                  │
│      → toRefs() 或不解构                     │
│   3. computed vs methods：有无缓存差异       │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：把登录表单雏形改成「密码强度实时提示」——`computed` 计算强度（弱/中/强），模板显示彩色标签；
2. **必做**：用 `watchEffect` 打印 `form.username + '/' + form.password`，观察进入页面时是否立即输出一次；
3. **挑战**：把整个表单用 `reactive` 包住的同时，`loading` 用 `ref` 包，然后写一段 `toRefs(form)` 后解构使用的示例。

### 2.6 教学反思提示
- 学生最容易忘 `.value`——尤其是 `count++` 写成 `count.value++`，示例演示故意先写错再改；
- 有学生会问「为什么模板里不用 `.value`」——直接回答 Vue 编译时会自动解 ref，不必深挖 Proxy 原理；
- 若课堂时间紧，`watch` 小节可以只讲一句「后续用到再补」，把节奏留给主流程。

---

## 第 3 课时：Vue Router 4 路由配置 + 导航守卫

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能安装 `vue-router@4` 并在 `main.ts` 中挂载，明白挂载顺序对 Pinia / Router 的影响；
2. 能声明基本路由表：静态路径、动态参数、嵌套路由、`redirect`、通配符 404；
3. 能用 `component: () => import('...')` 声明**路由懒加载**，`pnpm build` 时观察到 chunk 拆分；
4. 能在 `<template>` 里用 `<RouterLink>` 与 `<RouterView>`，在 `<script>` 里用 `useRouter()` / `useRoute()`；
5. 能写 `router.beforeEach` 导航守卫，实现「未登录跳登录页」+ 「登录后按 `query.redirect` 返回原地」的登录闭环。

#### 3.1.2 过程与方法目标
1. 通过「先跑通再加守卫」的顺序，训练「先看到 URL 变化再考虑权限」的调试节奏；
2. 通过 `console.log(to, from)` 打印导航守卫参数，训练用日志追踪路由行为的排查方式。

### 3.2 教学重难点
- **重点**：`createRouter` + `createWebHistory` 基本用法／嵌套路由（父带 Layout，子填 `<RouterView>`）／`meta.public` 白名单机制／`next()` 三种调用方式
- **难点**：History 模式服务器需 fallback（第 29 章 nginx 讲，本课只提）／守卫内调用 `useAuthStore()` 的时机（Pinia 已 install 之后）／`next()` 忘调导致「路由卡死」

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：目前的 `App.vue` 只是一个孤立组件，我们要让 `/login` 显示登录页、`/dashboard` 显示仪表盘、`/members` 显示会员列表。**如何让「URL 路径 ↔ 组件」两者对上号？**——答案就是路由系统。Vue 官方推荐 `vue-router@4`（Vue 3 专属，Vue 2 用 3.x）。

#### 新知讲授（14 分钟）

1. **安装与目录**（3 分钟）：
   - `pnpm add vue-router@4 pinia`（pinia 下节课用，一次装齐）；
   - 建 `src/router/index.ts`、`src/views/`、`src/layouts/`、`src/stores/` 四个目录；
   - `views/` 只放页面组件（LoginView、DashboardView、MemberListView），`layouts/` 只放布局（DefaultLayout）——**目录职责铁律**。

2. **`createRouter` + 路由表**（5 分钟）：

   ```ts
   import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'

   const routes: RouteRecordRaw[] = [
     { path: '/login',
       component: () => import('@/views/login/LoginView.vue'),
       meta: { public: true, title: '登录' } },

     { path: '/',
       component: () => import('@/layouts/DefaultLayout.vue'),
       redirect: '/dashboard',
       children: [
         { path: 'dashboard', component: () => import('@/views/DashboardView.vue'),
           meta: { title: '首页' } },
         { path: 'members',   component: () => import('@/views/member/MemberListView.vue'),
           meta: { title: '会员管理' } },
       ]
     },
     { path: '/:pathMatch(.*)*', component: () => import('@/views/NotFoundView.vue') }
   ]

   export default createRouter({ history: createWebHistory(), routes })
   ```

   - `createWebHistory()` = HTML5 history 模式，URL 无 `#`（生产需 nginx `try_files`，第 29 章讲）；
   - **路由懒加载** `() => import(...)`：打包时拆 chunk、按需加载；
   - `meta.public` 是自定义标记（不是 Router 内置字段），配合守卫做白名单。

3. **`<RouterView>` 与嵌套**（3 分钟）：
   - 父级 `DefaultLayout.vue` 里放 `<RouterView>` 作为子路由**占位**；
   - `App.vue` 顶层也放一个 `<RouterView>`——**根级出口**；
   - 一个应用可以有**多个** `<RouterView>` 层级，这就是「嵌套路由」。

4. **导航守卫**（3 分钟）：
   - `router.beforeEach((to, from, next) => { ... })`：每次跳转都跑；
   - `next()` = 放行；`next('/login')` = 拦截跳登录；`next(false)` = 阻止跳转；
   - **重点**：**必须调 `next()`**，忘调 → 路由卡死；
   - 典型用法：查 `to.meta.public`，非公开且无 token → `next({ path: '/login', query: { redirect: to.fullPath } })`。

#### 示例演示（15 分钟）

1. **建三个页面 + 挂路由**（8 分钟）：
   - `views/login/LoginView.vue` 里放上节课那份表单（先不改逻辑）；
   - `views/DashboardView.vue`：`<h2>Dashboard</h2>` + `<button @click="goMembers">去会员</button>`；
   - `views/member/MemberListView.vue`：`<h2>会员列表</h2>`（占位）；
   - `layouts/DefaultLayout.vue`：顶部三个 `<RouterLink to="/dashboard">` + `<RouterLink to="/members">` + `<button @click="logout">` + 下面 `<RouterView>`；
   - `main.ts`：`app.use(createPinia()).use(router).mount('#app')`——**顺序：Pinia 先、Router 后**；
   - `App.vue`：`<template><RouterView /></template>`——瘦到只剩一行。

2. **加登录守卫**（4 分钟）：

   ```ts
   router.beforeEach((to, _from, next) => {
     document.title = `${to.meta.title || ''} · ${import.meta.env.VITE_APP_TITLE}`
     const token = localStorage.getItem('token')     // 下一课时会换成 auth store
     if (to.meta.public) return next()
     if (!token) return next({ path: '/login', query: { redirect: to.fullPath } })
     next()
   })
   ```

   - 现场演示：直接访问 `/dashboard` → 自动跳 `/login?redirect=/dashboard`；
   - `localStorage.setItem('token','fake')` → 再访问 `/dashboard` → 放行。

3. **观察懒加载**（3 分钟）：`pnpm build` → 打开 `dist/assets/`，看 `LoginView-xxx.js` / `MemberListView-xxx.js` / `DashboardView-xxx.js` 三个独立 chunk——**这就是懒加载的产物**。

#### 课堂练习（10 分钟）
1. 每位学生完成三条路由 + 守卫，交 3 张截图（未登录访问 `/dashboard` 自动跳 login / 手动 `localStorage.setItem` 后能进 / DevTools Network 看到懒加载 chunk）；
2. 追加：加一条 `/courses` 课程路由，占位页面显示「课程管理」；
3. 思考题：若把 `router.beforeEach` 里的 `next()` 写漏一处（例如 `if (to.meta.public) return`），会发生什么？

#### 小结（3 分钟）
一句话回顾：**路由表 + 懒加载 + `<RouterView>` + `beforeEach` 守卫**——四件东西齐全，前端从「一张页面」升级为「多页面 SPA」。下一课时把「假 token」换成真的 Axios 登录接口 + Pinia store。

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-03 VueRouter 4                        │
├──────────────────────────────────────────────┤
│  安装：                                      │
│   pnpm add vue-router@4 pinia                │
│                                              │
│  路由表：                                    │
│   /login          → LoginView   public       │
│   /               → DefaultLayout            │
│     /dashboard    → DashboardView            │
│     /members      → MemberListView           │
│   /:pathMatch(.*)*→ NotFoundView             │
│                                              │
│  三种懒加载：                                │
│   component: () => import(...)               │
│                                              │
│  导航守卫：                                  │
│   beforeEach(to, from, next)                 │
│    → next() 放行                             │
│    → next('/login') 拦截                     │
│    → next(false) 阻止                        │
│                                              │
│  挂载顺序：                                  │
│   app.use(createPinia())  // 先              │
│      .use(router)         // 后              │
│      .mount('#app')                          │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成三条路由 + 守卫 + 懒加载，交 3 张截图；
2. **必做**：给 DefaultLayout 顶部加菜单，`<RouterLink>` 三个：首页 / 会员 / 课程，点击能正确高亮当前项（`RouterLink` 自带 `router-link-active` 类）；
3. **挑战**：加一个 `/members/:id` 动态路由页 `MemberDetailView.vue`，用 `useRoute().params.id` 读参数，标题显示「会员详情：3」。

### 3.6 教学反思提示
- `next()` 忘调导致「路由卡死」是必栽的坑，示例故意漏一次让学生诊断；
- `createPinia()` 与 `router` 挂载顺序错，会在守卫里报「getActivePinia not set」，示例演示时可以现场颠倒一次；
- 有学生的浏览器地址栏输入 `/dashboard` 直接刷新会 404（Vite 有 fallback 不会，但 build 后 nginx 不配就会），本课只提一句「第 29 章 nginx 讲」；
- 若课堂时间紧，动态路由参数可以放到下一课时导入环节。

---

## 第 4 课时：Axios 二次封装 + 拦截器 + 环境变量

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能安装 `axios` 并在 `src/api/request.ts` 里创建独立实例，配置 `baseURL` 与 `timeout`；
2. 能写**请求拦截器**注入 JWT：`config.headers.set('Authorization', \`Bearer ${token}\`)`；
3. 能写**响应拦截器**解包 `{code, msg, data}`：`code === 200` 直接返回 `data`，否则抛 `BizError`；
4. 能处理三类错误：网络断连（`err.response` 为 `undefined`）、401（清 store + 跳登录 + 防抖）、其他 HTTP 错误码；
5. 能建 Pinia `useAuthStore`：`token / username / roles` state + `login / logout / reset` actions，配合 `localStorage` 持久化；
6. 能写 `src/api/auth.ts` 与 `src/api/member.ts` 两个业务 API 模块，返回强类型。

#### 4.1.2 过程与方法目标
1. 通过「拦截器 = AOP」类比，让学生把 Day10 学过的后端 AOP 思想平移到前端；
2. 通过「401 弹 10 次 alert」的反例现场演示，训练**防抖锁**这类工程细节的意识。

### 4.2 教学重难点
- **重点**：`axios.create` 独立实例／请求拦截注入 token／响应拦截解包 Result／`BizError` 自定义错误类／`useAuthStore` 三持久化 API
- **难点**：拦截器**函数体内**才能 `useAuthStore()`（top-level 调会因 Pinia 未 install 报错）／`err.response` 为 undefined 的网络异常分支／401 防抖锁的时序设计

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：如果前端 20 个页面每个都要发请求，每个都手写「Authorization 头 / 判断 code / 401 跳登录」——那 20 份重复代码。类比后端 Day10 的 AOP：**能不能一次封装、全项目共用？**——就是本课要做的**Axios 二次封装**。

#### 新知讲授（15 分钟）

1. **`axios.create` 独立实例**（3 分钟）：
   - 全局默认 axios 谁都能改，会互相污染；
   - `const request = axios.create({ baseURL, timeout })` 建立**独立配置**；
   - 项目所有请求都从 `request` 出，不从 `axios` 直接出。

2. **请求拦截：注入 token**（3 分钟）：

   ```ts
   request.interceptors.request.use((cfg) => {
     const auth = useAuthStore()          // ← 必须在函数内调
     if (auth.token) cfg.headers.set('Authorization', `Bearer ${auth.token}`)
     return cfg
   })
   ```

   - **函数内调 store** = 保证 Pinia 已 install；
   - `Authorization: Bearer <jwt>` 是与 Day11 后端约定好的格式。

3. **响应拦截：解包 Result + 统一错误**（6 分钟）：

   ```ts
   request.interceptors.response.use(
     (res) => {
       const body = res.data
       if (body && typeof body === 'object' && 'code' in body) {
         if (body.code === 200) return body.data
         throw new BizError(body.code, body.msg || '请求失败')
       }
       return body
     },
     async err => {
       if (!err.response) throw new BizError(-1, '网络异常，请稍后再试')
       const { status, data } = err.response
       if (status === 401) { /* 清 store + 跳 login + 防抖 */ }
       if (status === 403) throw new BizError(403, '无权限访问')
       if (status >= 500)  throw new BizError(status, '服务异常，请稍后再试')
       throw new BizError(status, data?.msg || '请求失败')
     }
   )

   export class BizError extends Error {
     constructor(public code: number, public msg: string) { super(msg) }
   }
   ```

   - **成功响应直接返回 `data`**——业务代码就写成 `const list = await memberApi.page(q)` 而不必再 `.data.data.list`；
   - **`code != 200` 直接 `throw BizError`**——上层用 `try/catch` 统一处理。

4. **`useAuthStore`（Pinia setup 风格）**（3 分钟）：

   ```ts
   export const useAuthStore = defineStore('auth', () => {
     const token    = ref(localStorage.getItem('token') || '')
     const username = ref(localStorage.getItem('u')     || '')
     const isLogin  = computed(() => !!token.value)

     async function login(p: { username: string; password: string }) {
       const data = await loginApi(p)
       token.value    = data.accessToken
       username.value = data.username
       persist()
     }
     function reset() { token.value = ''; username.value = ''; persist() }
     function persist() {
       localStorage.setItem('token', token.value)
       localStorage.setItem('u',     username.value)
     }
     return { token, username, isLogin, login, reset }
   })
   ```

#### 示例演示（15 分钟）

1. **建三个文件**（8 分钟）：
   - `src/api/request.ts`：完整拷贝上面的模板；
   - `src/api/auth.ts`：
     ```ts
     import request from './request'
     export interface LoginResult { accessToken: string; username: string; roles: string[] }
     export function loginApi(p: { username: string; password: string }) {
       return request.post<any, LoginResult>('/login', p)
     }
     ```
   - `src/api/member.ts`：
     ```ts
     import request from './request'
     export interface MemberVO { id: number; name: string; phone: string; status: number }
     export interface PageResult<T> { total: number; records: T[] }
     export const memberApi = {
       page: (q: any) => request.get<any, PageResult<MemberVO>>('/members', { params: q })
     }
     ```

2. **把守卫从假 token 换成真 store**（4 分钟）：
   ```ts
   router.beforeEach((to, _from, next) => {
     const auth = useAuthStore()
     if (to.meta.public) return next()
     if (!auth.token) return next({ path: '/login', query: { redirect: to.fullPath } })
     next()
   })
   ```

3. **登录联调**（3 分钟）：
   - LoginView 里 `await auth.login({ username, password })` → 成功后 `router.replace(route.query.redirect || '/dashboard')`；
   - 打开 DevTools Network 看请求，Payload 里 username/password 是否正确、Response 里 accessToken 是否解析；
   - 打开 Application → LocalStorage 看到 `token / u` 已持久化；
   - 手工把 `token` 改成乱码 → 刷新 → 弹「登录已过期」并跳 login。

#### 课堂练习（9 分钟）
1. 每位学生完成 request.ts + auth.ts + auth store 三件套，交一份能正常登录跳转的截图（登录成功进入 dashboard）；
2. 追加需求：把「登录已过期」的 alert 换成 `console.warn`，观察防抖锁是否阻止多次触发；
3. 思考题：如果响应体不是 `{code,msg,data}` 而是第三方接口（比如高德地图 API），本封装还能用吗？如何不改主 request 也接入？

#### 小结（3 分钟）
一句话回顾：**Axios 只封一次，全项目共用**——`baseURL / 拦截器 / BizError / Pinia store`，登录闭环就此打通。下一课时把丑陋的原型登录页升级成 Element Plus 版。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-04 Axios 二次封装                     │
├──────────────────────────────────────────────┤
│  axios.create({ baseURL, timeout })          │
│                                              │
│  请求拦截：                                  │
│   cfg.headers.set('Authorization',           │
│                    'Bearer '+token)          │
│                                              │
│  响应拦截：                                  │
│   ① code===200 → return body.data            │
│   ② code!==200 → throw BizError              │
│   ③ 401 → 清 store + 跳 login + 防抖         │
│   ④ 403 → 无权限                             │
│   ⑤ 5xx → 服务异常                           │
│   ⑥ 网络异常 → !err.response                 │
│                                              │
│  BizError extends Error {                    │
│    constructor(code: number, msg: string)    │
│  }                                           │
│                                              │
│  useAuthStore = defineStore('auth', () => {  │
│    token/username/roles + login/logout/reset │
│    localStorage 持久化                       │
│  })                                          │
│                                              │
│  必栽的坑：                                  │
│   * 拦截器内才能 useAuthStore()              │
│   * 401 不防抖 → 弹 10 次                    │
│   * err.response undefined = 网络断连        │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 Axios 封装 + auth store + 登录守卫真接入，交 3 张截图（登录成功 / localStorage 有 token / 手工改 token 后被强制跳回登录）；
2. **必做**：把 `LoginView` 里的 `alert` 全部替换成 `console.warn`，然后加一个 `error` 响应式变量在页面上显示错误消息；
3. **挑战**：给 `request` 增加**请求取消**：路由跳转时自动 `AbortController.abort()` 掉未完成请求（提示：`router.beforeEach` + Map 收集）。

### 4.6 教学反思提示
- 学生极易犯的错：在 `request.ts` **顶层** `const auth = useAuthStore()`——运行时报 「getActivePinia not set」，示例演示时故意先写在顶层让学生查错；
- 401 防抖锁不加，弹窗弹到用户想砸键盘，一定要现场跑一遍并发 5 个请求验证；
- Windows 网络切换（切 WiFi）时 `err.response` 为 undefined，可以让学生断开 WiFi 触发一次「网络异常」；
- 若课堂时间紧，Pinia 部分可以只讲 setup 风格，Options 风格提一句「兼容 Vue 2 用户习惯」即可。

---

## 第 5 课时：Element Plus 安装 + 常用组件（Menu / Table / Form / Message）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能用 `pnpm add element-plus @element-plus/icons-vue` 与两插件 `unplugin-vue-components` / `unplugin-auto-import` 完成**按需自动引入**，无需手写 `import ElButton`；
2. 能在 `vite.config.ts` 里配置 `ElementPlusResolver`，理解「组件用 Components、API 用 AutoImport」的分工；
3. 能用 CSS 变量 `--el-color-primary*` 覆盖主题色，把品牌色换成印想瑜伽绿 `#5AA372`；
4. 能用 `<el-menu>` 搭建左侧导航（首页 / 会员 / 课程），配合 `router` 属性实现点击跳转；
5. 能用 `<el-form>` + `<el-input>` + `rules` 做表单校验；用 `<el-table>` + `<el-pagination>` 做分页表格；用 `ElMessage` / `ElMessageBox` 做全局消息与确认框。

#### 5.1.2 过程与方法目标
1. 通过「原型丑丑 → Element 皮肤」的直观改造，让学生理解 UI 库的价值不在于「组件多」而在于「一致性和交付质量」；
2. 通过对照官方文档的 API 逐一使用，训练查文档写代码的能力。

### 5.2 教学重难点
- **重点**：按需自动引入的两插件配置／主题色 CSS 变量覆盖／`<el-menu router>`／`<el-form> rules`／`<el-table> + <el-pagination>` 组合／`ElMessage / ElMessageBox`
- **难点**：AutoImport 生成的 `auto-imports.d.ts` 与 `components.d.ts` TS 声明文件位置／`ElMessageBox.confirm` 的 promise reject 处理（必须 `.catch(()=>{})`）／`el-menu` 的 `default-active` 与当前路径同步

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：现在的登录页长这样（丑丑原型截图）——`<input>` 光秃秃、按钮扁扁的。用户看到能想登录吗？——引出 UI 库价值。业界候选：Element Plus / Ant Design Vue / Naive UI / PrimeVue，**教学首选 Element Plus**：中文文档、社区大、招聘岗位需求高。

#### 新知讲授（14 分钟）

1. **安装与按需引入**（5 分钟）：

   ```bash
   pnpm add element-plus @element-plus/icons-vue
   pnpm add -D unplugin-vue-components unplugin-auto-import
   ```

   ```ts
   // vite.config.ts
   import AutoImport from 'unplugin-auto-import/vite'
   import Components from 'unplugin-vue-components/vite'
   import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

   plugins: [
     vue(),
     AutoImport({ resolvers: [ElementPlusResolver()], dts: 'src/auto-imports.d.ts' }),
     Components({ resolvers: [ElementPlusResolver()], dts: 'src/components.d.ts' })
   ]
   ```

   - `unplugin-auto-import` 自动引入 `ElMessage / ElMessageBox / ElNotification` 等**逻辑 API**；
   - `unplugin-vue-components` 自动注册 `<el-button>` 等**模板组件**；
   - **不必 `import { ElButton } from 'element-plus'`**，Tree-shaking 也不会引入用不到的组件。

2. **主题色覆盖**（3 分钟）：

   `src/assets/main.css`：
   ```css
   :root {
     --el-color-primary:            #5AA372;
     --el-color-primary-light-3:    #7CB58E;
     --el-color-primary-light-5:    #A6CDB2;
     --el-color-primary-light-7:    #D0E2D6;
     --el-color-primary-light-8:    #E3EEE7;
     --el-color-primary-light-9:    #EEF7F1;
     --el-color-primary-dark-2:     #468B57;
   }
   ```

   - Element Plus 3.x 用 **CSS 变量**而非 SCSS 变量；
   - **必须成套覆盖** `-light-3/5/7/8/9`，否则按钮 hover/disabled 时颜色不对。

3. **图标全局注册**（2 分钟）：

   ```ts
   // main.ts
   import * as Icons from '@element-plus/icons-vue'
   for (const [name, comp] of Object.entries(Icons)) {
     app.component(name, comp as any)
   }
   ```

   - 之后模板直接 `<User />` `<Reading />` `<HomeFilled />`——无需再 import。

4. **四大常用组件用法速览**（4 分钟）：
   - `<el-menu>`：`router` 属性 + `default-active`；
   - `<el-form>`：`:model` + `:rules` + `<el-form-item prop="username">`，`ref.validate()` 返回 promise；
   - `<el-table>`：`:data` 数据源 + `<el-table-column prop="xxx" label="标签">`；
   - `<el-pagination>`：`v-model:current-page` + `v-model:page-size` + `:total` + `@current-change`；
   - `ElMessage.success('登录成功')` / `ElMessageBox.confirm('确认退出？', '提示')`——后者返回 promise，取消时 reject，**必须 `.catch(()=>{})`**。

#### 示例演示（16 分钟）

1. **升级 LoginView 为 Element Plus 版**（6 分钟）：
   ```vue
   <template>
     <div class="login-wrap">
       <el-card class="login-card">
         <div class="login-brand">
           <el-icon color="#5AA372" :size="24"><Sunny /></el-icon>
           <span>印想瑜伽会馆 · 管理后台</span>
         </div>
         <el-form ref="formRef" :model="form" :rules="rules" label-position="top"
                  @submit.prevent="submit">
           <el-form-item label="用户名" prop="username">
             <el-input v-model="form.username" prefix-icon="User" size="large"/>
           </el-form-item>
           <el-form-item label="密码" prop="password">
             <el-input v-model="form.password" type="password" show-password
                       prefix-icon="Lock" size="large" @keyup.enter="submit"/>
           </el-form-item>
           <el-button type="primary" size="large" class="submit-btn"
                      :loading="loading" @click="submit">登 录</el-button>
         </el-form>
       </el-card>
     </div>
   </template>

   <script setup lang="ts">
   import { reactive, ref } from 'vue'
   import type { FormInstance, FormRules } from 'element-plus'
   import { useAuthStore } from '@/stores/auth'
   import { useRouter, useRoute } from 'vue-router'

   const auth = useAuthStore()
   const router = useRouter(), route = useRoute()
   const formRef = ref<FormInstance>()
   const form = reactive({ username: '', password: '' })
   const loading = ref(false)

   const rules: FormRules = {
     username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
     password: [{ required: true, message: '请输入密码', trigger: 'blur' },
                { min: 6, message: '至少 6 位', trigger: 'blur' }]
   }

   async function submit() {
     const ok = await formRef.value?.validate().catch(() => false)
     if (!ok) return
     loading.value = true
     try {
       await auth.login(form)
       ElMessage.success('登录成功')
       router.replace((route.query.redirect as string) || '/dashboard')
     } catch (e: any) {
       ElMessage.error(e.msg || '登录失败')
     } finally { loading.value = false }
   }
   </script>
   ```

2. **升级 DefaultLayout 为侧栏 + 顶栏布局**（6 分钟）：
   - 左侧 `<el-aside>` + `<el-menu :default-active="route.path" router>` + 三个 `<el-menu-item>`；
   - 顶部 `<el-header>` + 用户名 + `<el-dropdown>` 退出登录；
   - `ElMessageBox.confirm('确认退出登录？', '提示', { type: 'warning' })`，**注意 `.catch(()=>{})`**。

3. **`<el-table>` + `<el-pagination>` 骨架**（4 分钟）：
   - MemberListView 里 mock 一份 10 条数据，`<el-table :data="list" border stripe>` + `<el-pagination>`；
   - 点分页，观察 `current-change` 事件触发。

#### 课堂练习（9 分钟）
1. 每位学生完成 Element Plus 版登录页 + Layout + 空 MemberListView，交 3 张截图（登录页样式 / 侧栏布局 / 会员列表 mock 表格）；
2. 追加：把「退出登录」的确认框改成 `ElMessageBox.confirm`，取消时不能报错（补上 `.catch`）；
3. 思考题：为什么 `<el-menu>` 要设 `default-active=route.path`？如果不设会怎样？（提示：刷新页面后菜单激活项丢失）

#### 小结（3 分钟）
一句话回顾：**按需自动引入 + CSS 变量覆盖 + 四大组件（Menu/Form/Table/Message）**——UI 层从原型皮升级为交付级。下一课时把这些组件整合成一份完整的会员列表 Demo，联上 Mock 数据。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-05 Element Plus                       │
├──────────────────────────────────────────────┤
│  安装：                                      │
│   pnpm add element-plus @element-plus/…      │
│   pnpm add -D unplugin-vue-components        │
│                unplugin-auto-import          │
│                                              │
│  按需引入两插件：                            │
│   AutoImport   → API   (ElMessage…)          │
│   Components   → 模板  (<el-button>…)        │
│                                              │
│  主题色 CSS 变量成套：                       │
│   --el-color-primary:         #5AA372        │
│   --el-color-primary-light-3~9               │
│   --el-color-primary-dark-2                  │
│                                              │
│  四大常用组件：                              │
│   <el-menu router> + default-active          │
│   <el-form :model :rules> + validate()       │
│   <el-table :data> + <el-table-column>       │
│   <el-pagination v-model:current-page>       │
│                                              │
│  两大 API：                                  │
│   ElMessage.success/error                    │
│   ElMessageBox.confirm  ← 必须 .catch(()=>{}) │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 Element Plus 登录页 + Layout + 空会员列表，交 3 张截图；
2. **必做**：给 Layout 顶部加面包屑，从 `route.matched` 过滤有 `meta.title` 的项，动态展示；
3. **挑战**：给项目加深色模式切换：右上角 `<el-switch>`，切换后给 `<html>` 加 `dark` 类，配合 `element-plus/theme-chalk/dark/css-vars.css` 生效。

### 5.6 教学反思提示
- 学生若没在 `main.ts` 里 `import 'element-plus/dist/index.css'`，组件会没样式，示例演示时可以故意漏一次；
- 主题色只覆盖 `--el-color-primary` 而漏 `-light-3` 的坑，让学生 hover 按钮看差别；
- Windows 学生偶尔遇到「装 pnpm 包时全局权限报错」，让他换用 `npx pnpm add ...` 或以管理员打开终端；
- 若课堂时间紧，深色模式课堂练习可以直接跳过，作为挑战题留。

---

## 第 6 课时：前端脚手架 + 目录规范 + 会员列表 Mock 联调

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能画出并解释 `yoga-admin/src/` 目录结构：`api / assets / components / layouts / router / stores / utils / views` 八个目录的职责边界；
2. 能用 `vite-plugin-mock` 或简易 `msw` 在**无后端**情况下 mock `/api/members` 与 `/api/login` 两个接口；
3. 能完成一个可运行的**会员列表页 Demo**：搜索栏 + 分页表格 + 编辑 / 删除按钮 + Loading 状态；
4. 能在 `pnpm build` 后打开 `dist/` 看输出产物：`index.html` + `assets/*.js` + `assets/*.css`，理解每个 chunk 的来源；
5. 能整理 `README.md` 的「快速开始 / 目录结构 / 联调说明」三段，提交到 git。

#### 6.1.2 过程与方法目标
1. 通过「有 mock 数据先跑起来」的顺序，摆脱「必须等后端」的依赖，训练前后端并行开发能力；
2. 通过 README + 目录规约撰写，训练文档意识——前端项目的可交付性 = 代码 + 文档。

### 6.2 教学重难点
- **重点**：`src/` 目录八件套的职责铁律／mock 数据的写法／完整会员列表页组合（SearchBar + ProTable + Pagination + Actions）／`pnpm build` 产物结构／README 三段结构
- **难点**：「目录职责」这种软规范如何让学生形成习惯（示例中每写一段都点名一次目录）／mock 数据切换到真接口时零改动的写法（`baseURL` 相同、路径相同）

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：现在 `yoga-admin` 的 src 目录只有 `api / stores / router / views / layouts / assets`——如果新同学来接手，他知道「工具函数放哪、通用组件放哪」吗？——引出**目录规约**的必要性。类比后端 `controller / service / mapper / entity` 分层——**前端也要分层**。

#### 新知讲授（13 分钟）

1. **`src/` 八目录职责铁律**（5 分钟）：

   ```text
   yoga-admin/
   ├── src/
   │   ├── api/            # 接口封装（一个业务一文件）
   │   │   ├── request.ts  # axios 实例
   │   │   ├── auth.ts
   │   │   └── member.ts
   │   ├── assets/         # 图片 / 全局样式 main.css
   │   ├── components/     # 通用组件（PageContainer/SearchBar/ProTable）
   │   ├── layouts/        # 布局组件（DefaultLayout）
   │   ├── router/         # 路由（index.ts + guards.ts）
   │   ├── stores/         # Pinia（auth.ts / app.ts）
   │   ├── utils/          # 纯函数（date / dict / handleErr）
   │   └── views/          # 页面级（login / member / course）
   ```

   - `api/` **只做接口**，不放业务；
   - `views/` **只写页面**，复用逻辑抽 `components/`；
   - `stores/` **管全局状态**，不写业务方法；
   - `utils/` **无副作用纯函数**，不能引用 store（避免循环依赖）。

2. **通用组件三件套**（3 分钟）：
   - `PageContainer.vue`：标题栏 + 操作区 + 内容区，统一每个业务页面外框；
   - `SearchBar.vue`：`inline` 表单 + 查询/重置按钮，emit `search` `reset` 事件；
   - `ProTable.vue`：`v-loading` + 分页 + `loader` 函数属性——一站式列表页组件。

3. **mock 数据方案对比**（3 分钟）：
   - 方案 A：`vite-plugin-mock`（快，写法像 express，dev 时生效）；
   - 方案 B：`msw`（Service Worker，dev/prod 都能拦，稍复杂）；
   - 方案 C：**本课选**——最简：在 `src/api/mock.ts` 里定义 `mockMembers()` 函数返回假数据，`member.ts` 里加环境判断 `if (import.meta.env.DEV) return mockMembers(q)`；
   - 后端就绪后**一行删除 mock 分支**，路径与结构不变。

4. **`pnpm build` 产物结构**（2 分钟）：
   - `dist/index.html`（体积小，只挂 script 标签）；
   - `dist/assets/index-xxxxxxxx.js`（主 chunk）；
   - `dist/assets/LoginView-xxxxxxxx.js`（懒加载 chunk，一路由一 chunk）；
   - `dist/assets/index-xxxxxxxx.css`（样式）；
   - 学一句：`pnpm preview` 本地起个 http server 验证 dist 是否可跑。

#### 示例演示（17 分钟）

1. **建 SearchBar + ProTable + PageContainer**（5 分钟）：从第 24 章模板拷入 `src/components/`，讲一句：**这三份代码是本教程赠送的基础件，未来所有列表页都直接组合它们**。

2. **写 mock 数据 + memberApi**（4 分钟）：

   ```ts
   // src/api/mock.ts
   import type { MemberVO, PageResult } from './member'
   const seed: MemberVO[] = Array.from({ length: 87 }, (_, i) => ({
     id: i + 1,
     name: `会员${i + 1}`,
     phone: `139${String(10000000 + i).padStart(8, '0')}`,
     status: (i % 3 === 0 ? 2 : 1)
   }))
   export function mockMembersPage(q: any): Promise<PageResult<MemberVO>> {
     let list = seed
     if (q.name)  list = list.filter(m => m.name.includes(q.name))
     if (q.phone) list = list.filter(m => m.phone.includes(q.phone))
     const pageNum = q.pageNum || 1, pageSize = q.pageSize || 10
     const start = (pageNum - 1) * pageSize
     return new Promise(r => setTimeout(
       () => r({ total: list.length, records: list.slice(start, start + pageSize) }),
       200
     ))
   }
   ```

   ```ts
   // src/api/member.ts
   import request from './request'
   import { mockMembersPage } from './mock'
   export interface MemberVO { id: number; name: string; phone: string; status: number }
   export interface PageResult<T> { total: number; records: T[] }
   export const memberApi = {
     page: (q: any): Promise<PageResult<MemberVO>> => {
       if (import.meta.env.VITE_USE_MOCK === 'true') return mockMembersPage(q)
       return request.get('/members', { params: q })
     }
   }
   ```

   `.env.development` 里加 `VITE_USE_MOCK = true`。

3. **写会员列表页**（6 分钟）：

   ```vue
   <!-- src/views/member/MemberListView.vue -->
   <template>
     <PageContainer title="会员管理">
       <template #actions>
         <el-button type="primary" @click="onCreate">新增会员</el-button>
       </template>

       <SearchBar :model="q" @search="onSearch" @reset="onSearch">
         <el-form-item label="姓名">
           <el-input v-model="q.name" placeholder="姓名模糊" clearable/>
         </el-form-item>
         <el-form-item label="手机号">
           <el-input v-model="q.phone" placeholder="手机号模糊" clearable/>
         </el-form-item>
       </SearchBar>

       <ProTable ref="tableRef" :loader="memberApi.page" :query="q">
         <el-table-column prop="id"    label="ID"   width="80"/>
         <el-table-column prop="name"  label="姓名"/>
         <el-table-column prop="phone" label="手机号"/>
         <el-table-column label="状态" width="90">
           <template #default="{ row }">
             <el-tag :type="row.status===1 ? 'success' : 'warning'">
               {{ row.status===1 ? '正常' : '冻结' }}
             </el-tag>
           </template>
         </el-table-column>
         <el-table-column label="操作" width="160">
           <template #default="{ row }">
             <el-button size="small" @click="onEdit(row)">编辑</el-button>
             <el-button size="small" type="danger" @click="onDel(row)">删除</el-button>
           </template>
         </el-table-column>
       </ProTable>
     </PageContainer>
   </template>

   <script setup lang="ts">
   import { reactive, ref } from 'vue'
   import PageContainer from '@/components/PageContainer.vue'
   import SearchBar from '@/components/SearchBar.vue'
   import ProTable from '@/components/ProTable.vue'
   import { memberApi, type MemberVO } from '@/api/member'

   const q = reactive({ name: '', phone: '' })
   const tableRef = ref()

   function onSearch() { tableRef.value?.resetToFirst() }
   function onCreate() { ElMessage.info('新增功能后续讲') }
   function onEdit(row: MemberVO)  { ElMessage.info('编辑：' + row.name) }
   async function onDel(row: MemberVO) {
     await ElMessageBox.confirm(`删除 ${row.name}？`, '提示', { type: 'warning' })
                       .catch(() => Promise.reject())
     ElMessage.success('已删除（mock）')
     tableRef.value?.refresh()
   }
   </script>
   ```

3. **打包 + 交付说明**（2 分钟）：
   - `pnpm build` → `dist/` 生成；
   - `pnpm preview` → 4173 端口验证；
   - README.md 三段：**快速开始**（node 20 / pnpm 9 / `pnpm i` / `pnpm dev`）+ **目录结构**（复制上面 8 目录说明）+ **联调说明**（mock 开关 / 真后端 URL / .env.\*）。

#### 课堂练习（9 分钟）
1. 每位学生跑通会员列表 mock：搜索 + 分页 + 编辑 / 删除，交 3 张截图（列表默认状态 / 搜索「会员 1」结果 / 点删除弹确认框）；
2. 追加：把 `.env.development` 的 `VITE_USE_MOCK` 改成 `false`，观察请求是否走 `/api/members`（应会 404 或跳登录，因为后端未接入，属正常）；
3. 思考题：如果新增一个「课程列表」页，能复用哪些通用组件？还需要新写什么？

#### 小结（3 分钟）
一句话回顾：**目录八件套 + 三件通用组件 + mock 开关**——`yoga-admin` 项目底座就位。至此 Day12 六课时全部完成：**Vite 建项目 → 组合式 API → Router → Axios → Element Plus → 完整业务页**，Day13 之后所有会员 / 课程 / 预约页面都能在这个底座上快速搭建。

### 6.4 板书设计
```
┌──────────────────────────────────────────────┐
│  Day12-06 脚手架 + 目录规范 + 会员列表 Demo  │
├──────────────────────────────────────────────┤
│  src/ 八目录：                               │
│   api/      接口封装（一业务一文件）         │
│   assets/   图片 + 全局样式                  │
│   components/ 通用组件                       │
│   layouts/  布局                             │
│   router/   路由                             │
│   stores/   Pinia                            │
│   utils/    纯函数                           │
│   views/    页面                             │
│                                              │
│  通用组件三件套：                            │
│   PageContainer / SearchBar / ProTable       │
│                                              │
│  Mock 方案：                                 │
│   VITE_USE_MOCK=true  → mockMembersPage()    │
│   VITE_USE_MOCK=false → request.get(...)     │
│   → 后端就绪一行删 mock 分支                 │
│                                              │
│  会员列表页组合：                            │
│   PageContainer                              │
│     ├─ SearchBar (name / phone)              │
│     └─ ProTable                              │
│         ├─ 表格列（ID/姓名/手机/状态）       │
│         ├─ 操作（编辑/删除）                 │
│         └─ 分页                              │
│                                              │
│  交付三件套：                                │
│   pnpm build → dist/                         │
│   pnpm preview → 4173                        │
│   README.md（快开始+目录+联调）              │
└──────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成 yoga-admin 会员列表页 Demo，交 5 张截图（默认列表 / 搜索 / 分页 / 编辑确认 / 删除确认）；
2. **必做**：写 README.md 三段（快速开始 / 目录结构 / 联调说明），提交到 git（本地初始化 repo 即可）；
3. **挑战**：给 Members 列表加一列「注册时间」和一列「性别」，同时让 `PATH: /members?name=x&pageNum=2` 这种带 query 直接进入时能自动填回搜索栏 + 停留在对应分页。

### 6.6 教学反思提示
- 学生极易把 `mock.ts` 写在 `views/` 或 `stores/` 里，示例演示时反复强调「mock 也是 api 层的一部分」；
- `ElMessageBox.confirm` 学生总忘记 `.catch(()=>{})`，让浏览器 Console 里堆一堆 unhandledRejection，示例演示时故意漏一次让全班找错；
- README 部分学生第一次写会长得不像样，示例给出一个模板骨架就够；
- 若课堂时间紧，最后的 `pnpm build / preview` 环节可以留作课后自行完成，本节保住「会员列表 Demo 能跑」是硬指标。

---

## Day12 结语

Day12 是**前端从零到一**的一天：Vite 建项目、组合式 API 上手、VueRouter 4 组织路由、Axios 二次封装、Element Plus 换皮、目录规范落地——最终交付一个可运行的 `yoga-admin` 会员列表页 Demo。学生此时应该已经能独立复现「登录 → dashboard → 会员管理」的完整闭环。Day13 起，我们将在此底座上把会员、教练、课程、预约四大业务前端全部铺开，与 Day01–Day11 建好的后端逐一联调。
