# 《AI 应用 Web 开发》 - 教师教案（Day06：课程科目管理 + 会员管理）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day05 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、Result 统一响应、参数校验基础）**
**知识点覆盖：** 第 11 章 课程科目管理（分页、批量删除、新增修改） + 第 12 章 会员管理（查询/删除/新增/修改）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / PageHelper 6.1+ / MySQL 8.0 / IDEA 2024.3+ / 通义灵码 + Trae。

**Day06 主线**：把印想瑜伽会馆的两张最重要的业务表 —— `tb_subject`（课程科目）与 `tb_member`（会员）—— 从零到接口全链路实现一遍。课程科目是「字典表」，字段少、规则简单；会员表是「主档表」，字段多、规则复杂（唯一手机号、软删除、日期区间、状态枚举）。前后呼应，梯度递进。

---

## 第 1 课时：课程科目列表与分页查询

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出 `tb_subject` 表结构，并解释每个字段的业务含义；
2. 能独立在 `pom.xml` 中集成 PageHelper，并在 `application.yml` 中完成关键参数配置；
3. 能写出「参数对象 + PageHelper.startPage + PageInfo + PageResult」的分页四件套；
4. 能在 XML 里用 `<where>` 与 `<if>` 组合出名称模糊 + 状态精确两类条件；
5. 能在 Postman 中用 `GET /api/category?page=&pageSize=&name=&status=` 联调成功。

#### 1.1.2 过程与方法目标
1. 通过「先看 SQL 再写 Java」的顺序，训练\"以数据为中心\"的接口设计思维；
2. 通过对比\"手写 limit\"与\"PageHelper\"两种分页方案，理解框架带来的抽象收益。

### 1.2 教学重难点
- **重点**：PageHelper 三件套用法（startPage → list → PageInfo）／`<where>` `<if>` 动态 SQL 写法／统一分页返回结构 `PageResult<T>{total, rows}`
- **难点**：PageHelper 的\"只对紧邻的第一条 select 生效\"这条隐性契约 / 模糊查询的 SQL 注入与中文乱码

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
以「印想瑜伽会馆」的实际业务场景切入：会馆开设了 15 个课程科目（哈他 / 阴 / 流 / 高温 / 孕妇 …），若前端一次拉回所有科目，做 3 个班的排课界面还可以，做 100 个班时页面就卡死。**分页是列表接口的\"缺省要求\"**，不是可选项。抛出今天要落地的接口列表：分页、模糊、按状态筛选，为后面 5 个课时的会员管理做技术铺垫。

#### 新知讲授（14 分钟）

1. **数据表设计**（4 分钟）：结合第 11 章 11.1.2 讲 `tb_subject`。重点强调三点：`name` 加 `UNIQUE`（业务上唯一）；`status` 用 `TINYINT` 而不是 `boolean`（后期可扩展 3、4 状态）；`create_time / update_time` 用 MySQL 自动填充（`DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`），Java 侧不再手动 set。

   预置数据 SQL 一次贴 4 条（哈他 / 阴 / 流 / 孕妇），课堂上让学生复制到 Navicat 跑一遍。

2. **PageHelper 快速上手**（5 分钟）：为什么选 PageHelper 而不是手写 limit？
   - 一行 `PageHelper.startPage()` 拦截下一条 select，自动补 `LIMIT ? OFFSET ?`，并且再跑一条 `SELECT COUNT(*)` 拿 `total`；
   - 支持多方言（本课只用 MySQL），支持排序注入检测；
   - 缺点：ThreadLocal 机制导致「紧邻规则」——**PageHelper.startPage 后紧跟的那一条 select 才被拦截，中间夹别的 select 会失效或误伤**。

   `pom.xml` 引 `pagehelper-spring-boot-starter:2.1.1`（Spring Boot 4.0 兼容版本，命名可能是 `6.1.x`，随讲随查最新版），`application.yml` 加 `helper-dialect: mysql`、`reasonable: true`、`support-methods-arguments: true` 三行。

3. **接口契约与参数对象**（5 分钟）：接口路径统一 `/api/category`（本课程从今天起接口前缀带 `/api`，与前端 axios baseURL 对齐）。参数对象 `SubjectPageQuery` 携带 `page / pageSize / name / status`，返回对象 `PageResult<T>{ long total; List<T> rows; }`，包装在 `Result<PageResult<Subject>>` 里。

#### 示例演示（14 分钟）

1. **在 IDEA 中现场敲代码**（8 分钟）：
   - 新建 `SubjectPageQuery`、`PageResult<T>`、`Subject`、`SubjectMapper` 四个类；
   - 补 `SubjectMapper.xml`：`<select id="list">` 用 `<where>` + 两条 `<if>`；
   - 写 `SubjectService.page()`，把 `PageHelper.startPage` → `mapper.list` → `new PageInfo` 三行敲进去；
   - 写 `SubjectController.page(@ModelAttribute SubjectPageQuery q)`。

2. **联调 Postman**（4 分钟）：
   - `GET http://localhost:8080/api/category?page=1&pageSize=3`，观察返回 `total=4, rows.length=3`；
   - 改 `page=2` → `rows.length=1`；
   - 加 `name=瑜伽` → 4 条；`name=哈他` → 1 条；
   - 加 `status=0` → 0 条（预置数据全是启用）。

3. **用 AI 助手一句话生成对照版**（2 分钟）：在通义灵码 / Trae 里投喂本课时的提示词模板（见第 11 章 11.7），让 AI 生成一版 Controller + Service + Mapper.xml，让学生对照\"人写\"和\"AI 写\"的差异——重点看 `<where>` 是否覆盖、`PageHelper.startPage` 是否紧邻 select、字段命名是否驼峰。

#### 课堂练习（10 分钟）
1. 每位学生独立完成 `GET /api/category?page=1&pageSize=5&name=瑜伽&status=1` 联调，截图返回 JSON；
2. 追加需求：把 `ORDER BY id DESC` 改为 `ORDER BY create_time DESC`，让 AI 帮你重写 XML，人工审查是否可能 SQL 注入；
3. 完成\"手写 limit 版\"作为对照——在 Mapper 里加 `list2(query, offset, size)`，感受手写方案\"每次都要算 offset\"的琐碎。

#### 小结（3 分钟）
一句话回顾：**PageHelper 三件套 + 参数对象 + PageResult**。下一课时把「删除」搞定 —— 单条与批量。

### 1.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-01 课程科目列表 + 分页                │
├───────────────────────────────────────────────┤
│  表：tb_subject                              │
│   id / name(unique) / intro / level          │
│   status(0停1启) / create_time / update_time │
│                                              │
│  PageHelper 三件套：                         │
│    PageHelper.startPage(page, size)          │
│    List<T> rows = mapper.list(query)         │
│    new PageInfo<>(rows).getTotal()           │
│                                              │
│  接口：GET /api/category                     │
│    参数: page pageSize name status           │
│    返回: Result<PageResult<Subject>>         │
│                                              │
│  三条铁律：                                  │
│   ① startPage 紧邻 select                    │
│   ② where + if 动态拼接                      │
│   ③ 返回统一 {total, rows}                   │
└───────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `/api/category` 分页接口，并附 3 张 Postman 截图（分页命中、模糊命中、状态筛选）；
2. **必做**：给 `SubjectPageQuery` 追加 `orderBy` 字段（白名单：`id / create_time / level`），实现动态排序，思考如何防 SQL 注入；
3. **挑战**：用 AI 助手写一版 `SubjectMapperTest`，覆盖\"空条件 / 单条件 / 三条件\"3 组测试。

### 1.6 教学反思提示
- 学生极易踩「PageHelper.startPage 与目标 select 之间夹了别的查询」的坑，示例演示时要故意演示一次错误现象；
- 若课堂已有前端联动经验，可提前告诉他们\"下节课批量删除的 ids 参数格式\"，避免下节课再从头讲 URL 编码；
- Spring Boot 4.0.x 的 PageHelper starter 版本号可能与教材不完全一致，讲课前 30 分钟到 Maven Central 核对最新兼容版本。

---

## 第 2 课时：批量删除（前后端约定 + MyBatis foreach）

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能说出\"单条删除\"与\"批量删除\"两个接口在 REST 语义上的差异，并选出前端最容易接的入参格式；
2. 能在 Controller 用 `@RequestParam List<Long> ids` 接收 `?ids=1,2,3` 与 `?ids=1&ids=2&ids=3` 两种写法；
3. 能在 Mapper.xml 用 `<foreach>` 正确写出 `DELETE FROM ... WHERE id IN (?, ?, ?)`；
4. 能在 Service 层做\"空校验 + 影响行数校验\"两道防线。

#### 2.1.2 过程与方法目标
1. 通过\"前端 URL 抓包 → 后端 Controller 打断点\"闭环，理解 Spring MVC 的参数绑定机制；
2. 通过对比 `IN (?, ?, ?)` 与 `IN (#{ids})` 两种错误写法，理解\"占位符和列表\"的边界。

### 2.2 教学重难点
- **重点**：`<foreach>` 五要素（collection / item / open / separator / close）／`@RequestParam List<Long>` 的两种前端提交格式
- **难点**：`DELETE` 语句缺少 `WHERE` 时是**全表删除**灾难场景的预防意识；空列表进 `IN ()` 的 SQL 报错

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问：\"前端列表页勾了 5 行，点\"批量删除\"，用一次请求还是 5 次请求？\"引出\"批量接口的必要性\"。再抛出\"如果 5 行里有 1 行已经被别人删了怎么办\"的容错话题，为后面的\"影响行数校验\"埋伏笔。

#### 新知讲授（14 分钟）

1. **前后端契约设计**（5 分钟）：三种常见入参格式对比：
   - `DELETE /api/category?ids=1,2,3`（Query，逗号分隔）—— **推荐**，URL 直观、Spring MVC 自动转 `List<Long>`；
   - `DELETE /api/category?ids=1&ids=2&ids=3`（Query，重复参数）—— 也能接，axios / URLSearchParams 默认这种；
   - `DELETE /api/category`，Body 传 `{"ids":[1,2,3]}` —— 语义上有争议（DELETE 带 Body 不被所有代理支持），本课程不用。

   最终约定：**Query + 逗号分隔**。前端 axios 用 `params: { ids: [1,2,3].join(',') }`。

2. **Mapper.xml 的 `<foreach>`**（5 分钟）：五个属性逐一讲：
   - `collection="ids"` —— 与 Mapper 接口 `@Param("ids")` 对应；
   - `item="id"` —— 循环变量名；
   - `open="("` `separator=","` `close=")"` —— 拼出 `(1,2,3)`；
   - 循环体里用 `#{id}`（**不要用 `${id}`**，会 SQL 注入）。

   常见反例：`WHERE id IN #{ids}` —— 把 List 当字符串塞进去，直接报错。

3. **Service 双层校验**（4 分钟）：
   - **入口空校验**：`if (ids == null || ids.isEmpty()) throw new BizException("请至少选择一条记录");` —— 拦截前端漏传；
   - **影响行数校验**：`int rows = mapper.deleteByIds(ids); if (rows == 0) throw new BizException("记录不存在或已被删除");` —— 拦截数据被别人先删/id 造假。

#### 示例演示（15 分钟）

1. **在 IDEA 里补齐 Mapper + Service + Controller**（7 分钟）：
   - `SubjectMapper.deleteByIds(@Param("ids") List<Long> ids)`；
   - XML `<delete>` + `<foreach>`；
   - `SubjectService.deleteBatch(List<Long> ids)` 加空校验与行数校验；
   - `SubjectController` 加两个方法：`@DeleteMapping("/{id}")` 单删（内部委托 batch）+ `@DeleteMapping` 批量。

2. **Postman 联调 + 断点观察**（5 分钟）：
   - `DELETE http://localhost:8080/api/category?ids=1,2`；
   - 在 Controller 参数 `ids` 上打断点，观察 IDEA 变量视图里已经是 `ArrayList[1, 2]`；
   - 再传 `DELETE /api/category`（不带 ids）→ 返回业务异常\"请至少选择一条记录\"；
   - 再传 `DELETE /api/category?ids=999` → 返回\"记录不存在或已被删除\"。

3. **让 AI 找 Bug**（3 分钟）：给 AI 一段\"故意写错\"的 XML（`<foreach>` 缺 `open="("`），让它指出问题。训练学生\"AI 是审查伙伴\"的意识。

#### 课堂练习（10 分钟）
1. 每位学生完成 `DELETE /api/category?ids=` 联调，包括三种情况：正常删除 / 空参数 / id 全部不存在；
2. 追加需求：给单条删除加二次确认——**前端弹框**（口头讲即可，不用真写前端），后端保持接口不变；
3. 思考题：如果一次删除 1 万个 id 会发生什么？IN 子句上限是多少？如何拆分？（引导用 `Lists.partition` 分批）

#### 小结（3 分钟）
一句话回顾：**`<foreach>` 拼 IN + Service 双校验**。批量接口的核心不是 SQL，而是\"入参格式约定 + 容错\"。

### 2.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-02 批量删除                           │
├───────────────────────────────────────────────┤
│  URL 契约（推荐）：                          │
│    DELETE /api/category?ids=1,2,3            │
│    → List<Long> 自动装配                     │
│                                              │
│  <foreach> 五要素：                          │
│    collection="ids" item="id"                │
│    open="(" separator="," close=")"          │
│    循环体用 #{id}（不是 ${id}）              │
│                                              │
│  Service 双校验：                            │
│    ① 入口: ids 空 → BizException             │
│    ② 出口: rows==0 → BizException            │
│                                              │
│  DELETE 语句：                               │
│    绝不能没有 WHERE                          │
│    P0 事故防线                               │
└───────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成 `/api/category` 批量删除接口，附 Postman 截图 + 一段自己写的 Mapper 单元测试；
2. **必做**：把\"批量删除\"接口的三种入参格式（逗号 / 重复 / body 数组）分别在 Postman 测一遍，观察哪一种能命中；
3. **挑战**：给 `deleteBatch` 加\"每批 500 条\"分批策略（`Lists.partition` 或手写 `subList`），思考事务边界。

### 2.6 教学反思提示
- \"DELETE 忘 WHERE\" 的段子要讲，学生对这类事故印象深刻；
- 强烈建议在演示环境准备一个 dev 数据库副本，若课堂上真删空表，直接 `mysql < seed.sql` 恢复；
- 部分学生会问\"为什么不直接用 `DELETE /api/category/1,2,3` 路径变量\"，可以讲 REST 语义与 Spring MVC 参数解析成本，30 秒带过。

---

## 第 3 课时：新增与修改科目（表单参数、参数校验、DTO/VO）

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能说出 DTO、VO、Entity 三层对象的分工，并在 Subject 场景下正确拆分；
2. 能在 DTO 上用 Bean Validation 注解（`@NotBlank / @Size / @Min / @Max`）表达业务规则；
3. 能在 Controller 用 `@Valid` 触发校验，理解校验失败时 Spring 抛的 `MethodArgumentNotValidException`；
4. 能实现「新增 + 修改」的**名称唯一性校验**：`existsByName(name, excludeId)` 模式。

#### 3.1.2 过程与方法目标
1. 通过\"实体层字段 vs DTO 层字段\"的差异梳理，建立\"外部输入永远不可信\"的意识；
2. 通过\"重复名称新增 → 抛业务异常\"的联调，感受统一异常处理的必要（为 Day07 埋伏笔）。

### 3.2 教学重难点
- **重点**：DTO 与 Entity 的字段差异／`@Valid` + `@RequestBody` 组合／`existsByName` + `excludeId` 通用唯一性校验模式
- **难点**：`BeanUtils.copyProperties` 的浅拷贝陷阱（`null` 字段也会覆盖）／DTO 校验失败时的错误响应体格式

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：\"如果前端把 `id=1` 塞进 POST 新增的 body，你信不信？\"引出 DTO 的存在意义：**不能把外部输入当作可信的 Entity 直接落库**。举一个反面例子：某电商在新增接口里让前端传 `deleted=0`，被人构造 `deleted=1` 直接把商品\"新增即删除\"。

#### 新知讲授（15 分钟）

1. **DTO / VO / Entity 三层职责**（5 分钟）：板书画三个方框：
   - **DTO（Data Transfer Object）** —— 前端 → 后端的入参对象，只含**用户可以填的字段**（`id / name / intro / level / status`），可加校验注解；
   - **Entity** —— 与数据库表 1:1 映射（含 `create_time / update_time`），不加校验注解；
   - **VO（View Object）** —— 后端 → 前端的出参对象，可以做字段裁剪、状态文本翻译（下 4-6 课时用到）。

   本课时先做\"DTO + Entity\"，VO 留到会员管理讲。

2. **Bean Validation 注解速览**（5 分钟）：`@NotBlank / @NotNull / @NotEmpty` 三兄弟差异（Blank 只能用于 String、null 与全空格都拦截；Null 用于对象；Empty 用于集合/字符串但**不拦截全空格**）。再讲 `@Size / @Min / @Max / @Pattern`。演示 IDEA 中 `Jakarta Validation` 的 import 路径（Spring Boot 3+ 已由 `javax.validation` 迁到 `jakarta.validation`）。

3. **唯一性校验通用模式**（5 分钟）：`int existsByName(String name, Long excludeId)` 的两种用法：
   - 新增时 `excludeId = null` —— 判断整表是否已有同名；
   - 修改时 `excludeId = dto.getId()` —— 排除自己以后判断。

   XML 用 `<if test="excludeId != null">AND id &lt;&gt; #{excludeId}</if>` 拼动态 SQL。这个模式后续在 Member 手机号、User 用户名场景里都会复用。

#### 示例演示（14 分钟）

1. **在 IDEA 里补齐代码**（8 分钟）：
   - 新建 `SubjectDTO`，加 5 个字段 + 校验注解；
   - `SubjectMapper` 加 `insert(Subject)`、`update(Subject)`、`existsByName(name, excludeId)`；
   - XML 补 `<insert>`（`useGeneratedKeys="true" keyProperty="id"`）、`<update>`（`<set>` 动态更新）、`<select>` existsByName；
   - `SubjectService.save(dto)`、`update(dto)`，各自先做唯一性校验再落库；
   - `SubjectController` 加 `@PostMapping` `@PutMapping`，都带 `@Valid @RequestBody`。

2. **联调 Postman**（4 分钟）：
   - `POST /api/category` body `{"name":"高温瑜伽","intro":"38°C","level":2}` → success；
   - 重复提交同 name → `{"code":500,"msg":"科目名称已存在"}`（Day07 会把 500 改成 400）；
   - `POST /api/category` body `{"name":""}` → `@NotBlank` 触发，Spring 返回 400 + 默认异常体；
   - `PUT /api/category` body 带 `id + 新 name`，验证 `excludeId` 生效。

3. **AI 生成 DTO 对照**（2 分钟）：给通义灵码贴表结构，让它一次性生成 DTO/VO/Entity 三件套，学生对照自己写的版本挑差异——**AI 常犯错**：把校验注解加到 Entity；忘记加 `@Data`；`@Size(max=50)` 少写；导包错成 `javax.validation`。

#### 课堂练习（10 分钟）
1. 每位学生完成 `POST` + `PUT` 两个接口的联调，各交 3 张截图（正常 / 名称重复 / 校验失败）；
2. 追加需求：给 `intro` 加 `@Size(max=255)`，前端传 300 字符时观察错误响应；
3. 思考题：`BeanUtils.copyProperties(dto, entity)` 如果 dto.status 为 null，会把 entity.status 也覆盖成 null 吗？（会，`copyProperties` 不区分 null）→ 引出\"部分更新时用 `<set>` 动态 SQL\"的必要性。

#### 小结（3 分钟）
一句话回顾：**DTO 校验，Entity 落库；新增/修改都要唯一性校验，用 `excludeId` 通用模式**。本章科目管理 CRUD 全部完成，下节课进入更复杂的会员管理。

### 3.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-03 科目新增与修改                     │
├───────────────────────────────────────────────┤
│  三层对象：                                  │
│    DTO  ← 前端入参（带校验）                 │
│    Entity ← 数据库映射（无校验）             │
│    VO   → 前端出参（可裁剪）                 │
│                                              │
│  校验注解：                                  │
│    @NotBlank / @Size / @Min / @Max           │
│    @Valid @RequestBody                       │
│                                              │
│  唯一性校验模板：                            │
│    existsByX(value, excludeId)               │
│    新增 → excludeId=null                     │
│    修改 → excludeId=dto.id                   │
│                                              │
│  <set> 动态更新：                            │
│    <if test="x != null"> x = #{x}, </if>     │
└───────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成 `POST/PUT /api/category`，并通过 Postman 交 6 张截图（3 正 3 反）；
2. **必做**：整理\"Bean Validation 常用注解速查表\"（≥ 10 个），存为个人笔记；
3. **挑战**：给 `Subject` 加 `sort` 排序字段，追加 `POST /api/category/{id}/move?direction=up|down` 接口。

### 3.6 教学反思提示
- 学生最常问的\"为什么校验注解要加到 DTO 不加到 Entity\"，一定要落到\"外部输入不可信\"这个大原则，不然他们记住了做法但不知道为什么；
- Bean Validation 校验失败默认响应体 `{"timestamp":...,"status":400,"errors":[...]}` 很丑，Day07 会有统一异常处理章节，本课时先忍一忍。

---

## 第 4 课时：会员列表与多条件查询（名字/手机/卡种/日期区间）

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能画出 `tb_member` 表结构，并解释 `deleted / uk_phone_deleted / card_expire / status` 四个关键字段；
2. 能设计一个含\"模糊 + 精确 + 区间\"三类条件的 `MemberPageQuery` 对象；
3. 能在 XML 里正确写\"日期区间左闭右开\"（`>= joinBegin AND < DATE_ADD(joinEnd, INTERVAL 1 DAY)`）；
4. 能用 `MemberVO` + `MemberConverter` 完成状态、性别、卡种三个字段的文本翻译。

#### 4.1.2 过程与方法目标
1. 通过\"复杂查询表单\"的字段拆解，训练\"接口先契约后实现\"的顺序；
2. 通过\"日期字符串 → LocalDate\" 的 `@DateTimeFormat` 用法，理解 Spring MVC 的类型转换机制。

### 4.2 教学重难点
- **重点**：`<where>` 里第一条 `deleted = 0` + 后续 `<if>`／日期区间\"左闭右开\"／VO 层文本翻译（状态/性别/卡种）
- **难点**：`LocalDate` 传参格式的严格化（必须 `yyyy-MM-dd`）／\"软删除必须让唯一索引带上 deleted\"的表结构陷阱

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
以真实会馆运营场景切入：前台每天要在会员列表里做\"找回失联老会员 / 筛选季卡即将到期 / 按渠道拉统计\"三类操作。列表页最少 5 个筛选条件（姓名、手机、卡种、状态、加入时间区间）。今天要一次性把这套\"复杂列表页\"的后端接口打通。

#### 新知讲授（14 分钟）

1. **`tb_member` 表结构**（5 分钟）：结合 12.1.2，逐字段讲清：
   - `name / phone / gender / id_card / avatar / card_type / card_expire / status / remark`：常规业务字段；
   - `deleted`：软删除标记，本课程从会员表开始引入软删除；
   - `UNIQUE KEY uk_phone_deleted (phone, deleted)`：**必须把 `deleted` 纳入唯一索引**，否则删掉之后同手机号无法重新注册。这是软删除的最经典陷阱，考试常考。

2. **多条件查询三分法**（4 分钟）：
   - **模糊查询**：`name / phone` → `LIKE CONCAT('%', #{x}, '%')`；
   - **精确匹配**：`card_type / status` → `= #{x}`；
   - **区间查询**：`join_begin / join_end` → 左闭右开 `>= begin AND < DATE_ADD(end, INTERVAL 1 DAY)`。

   板书画三类的对照表，学生记这三个\"字段类型 → SQL 模板\"的映射即可。

3. **VO 层文本翻译**（5 分钟）：为什么不能让前端自己 `switch (status)`？
   - 状态语义变化时，前后端要同步改；
   - 前端多个页面重复代码；
   - 后端可能给多个前端（Web / 小程序 / App）用，翻译在后端做一次最经济。

   `MemberVO` 在 `Member` 基础上加 `genderText / cardTypeText / statusText / cardExpire` 4 个前端展示用字段，通过 `MemberConverter.toVO` 静态方法转换。文本翻译用 Java 25 的 `switch expression` 简洁写法。

#### 示例演示（14 分钟）

1. **在 IDEA 里现场完成**（9 分钟）：
   - 建 `MemberPageQuery`，7 个字段（`page / pageSize / name / phone / cardType / status / joinBegin / joinEnd`），日期字段加 `@DateTimeFormat(pattern="yyyy-MM-dd")`；
   - `MemberMapper.list(query)`；
   - XML `<select>`：`<where>` 第一行 `deleted = 0`（必须，不然会拉出已删除会员），后续 5 个 `<if>` 拼条件；
   - `MemberVO` + `MemberConverter.toVO`，用 Java 25 `switch` 翻译三个字段；
   - `MemberService.page(query)`：先 `PageHelper.startPage` → `mapper.list` → `list.stream().map(MemberConverter::toVO).toList()` → 组装 `PageResult<MemberVO>`；
   - `MemberController.page(query)`。

2. **联调 Postman**（4 分钟）：
   - 提前用 `INSERT` 造 6 条测试数据；
   - `GET /api/member?page=1&pageSize=10&name=张` → 命中 2 条；
   - `GET /api/member?joinBegin=2026-07-01&joinEnd=2026-07-16` → 观察是否包含 07-16 全天；
   - `GET /api/member?cardType=3&status=1` → 精确匹配组合；
   - 故意传 `joinEnd=2026/07/16` → 400，展示 `@DateTimeFormat` 严格性。

3. **对照 AI 输出**（1 分钟）：让 AI 一次性生成 Mapper.xml，重点检查它有没有把 `deleted = 0` 放在 `<where>` 里、日期区间是不是左闭右开。**AI 高频翻车点**：`<= joinEnd`（漏掉当天最后一秒）、忘记 `deleted = 0`。

#### 课堂练习（10 分钟）
1. 每位学生完成 `/api/member` 分页接口，交 5 组测试用例的 Postman 截图；
2. 追加需求：给列表加\"卡片即将到期\"筛选 `cardExpireBefore`（30 天内到期），思考 SQL 怎么写；
3. 思考题：为什么 `MemberVO` 里返回了 `avatar` 却没返回 `id_card`？（隐私敏感字段脱敏思路，为业务安全埋点）

#### 小结（3 分钟）
一句话回顾：**软删除三件套：`deleted` 标记 + 唯一索引带 `deleted` + 每条 SELECT 加 `deleted=0`**。列表接口完成，下节课进入新增与删除。

### 4.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-04 会员多条件查询                     │
├───────────────────────────────────────────────┤
│  表：tb_member                               │
│    唯一索引: (phone, deleted)                │
│    软删除: deleted=1                         │
│                                              │
│  三类条件：                                  │
│   模糊 LIKE  → name / phone                  │
│   精确 =     → cardType / status             │
│   区间       → joinBegin/End                 │
│    左闭右开: >= begin                        │
│              < DATE_ADD(end, INTERVAL 1 DAY) │
│                                              │
│  <where> 首行永远：deleted = 0               │
│                                              │
│  VO 翻译：                                   │
│    genderText / cardTypeText / statusText    │
│    switch 表达式 (Java 25)                   │
└───────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 `/api/member` 分页 + 多条件接口，交 5 组 Postman 截图；
2. **必做**：整理\"三类条件 SQL 模板速查\"个人笔记；
3. **挑战**：让 AI 生成 50 条真实感的会员种子数据 SQL（真名 + 中国大陆手机号），并跑通。

### 4.6 教学反思提示
- 日期区间\"左闭右开\"是本课时最容易被忽视的知识点，可在下课前做一次\"课堂快问快答\"再强化一次；
- Java 25 switch expression 部分学生没接触过，若课堂时间紧张，可退回传统 `switch-case` 写法，讲清楚 `break` 别漏。

---

## 第 5 课时：会员删除（软删除）与新增（头像字段先预留）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能对比\"软删除\"与\"硬删除\"的适用场景，并说出各自的三条优缺点；
2. 能用 `<update>` + `<foreach>` 实现批量软删除，正确加 `deleted = 0` 前置过滤；
3. 能在 `MemberDTO` 上正确使用 `@Pattern` 校验手机号与身份证号；
4. 能实现\"手机号唯一性校验\"（含软删除维度：`WHERE phone = ? AND deleted = 0`）；
5. 明确\"头像字段先预留\"的开发节奏——`avatar` 字段先在 DTO 存 URL 字符串，文件上传接口留到 Day07 讲。

#### 5.1.2 过程与方法目标
1. 通过\"硬删除翻车 → 软删除方案\"的演化叙事，训练学生\"业务规则驱动技术方案\"的思考顺序；
2. 通过\"头像字段先预留\"的做法，理解\"最小可用版本 + 迭代交付\"的工程节奏。

### 5.2 教学重难点
- **重点**：软删除 SQL 模板（`UPDATE ... SET deleted=1 WHERE deleted=0 AND id IN (...)`）／手机号唯一性校验含 `deleted=0`／`@Pattern` 手机号正则 `^1[3-9]\\d{9}$`
- **难点**：软删除后，唯一索引冲突问题的根源理解／`avatar` 字段的\"占位\"策略（不做上传，先存 URL）

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
讲一个真实翻车事故：某健身房系统直接 `DELETE FROM tb_member`，会员卡历史查不到，第二年年报审计时缺了 800 张卡的进销存记录，罚款 20 万。抛出结论：**核心业务表禁用硬删除**。今天就把\"软删除\"这套设计固化下来。

#### 新知讲授（14 分钟）

1. **软删除 vs 硬删除**（5 分钟）：投影表格，逐维度对比：

   | 维度 | 软删除 | 硬删除 |
   |------|--------|--------|
   | 数据可恢复 | ✅（改 `deleted=0`） | ❌（除非查备份） |
   | 会计/合规 | ✅ 保留历史 | 需要额外审计日志 |
   | 查询语句 | 每条 select 都要加 `deleted=0` | 无额外条件 |
   | 唯一约束 | 需把 `deleted` 纳入唯一键 | 无需 |
   | 数据表体积 | 会持续膨胀，需定期归档 | 自然清理 |

   结论：**会员、订单、支付、合同必须软删除；日志、临时表、缓存表可硬删除**。

2. **软删除 SQL 模板**（4 分钟）：
   ```sql
   UPDATE tb_member
      SET deleted = 1, update_time = NOW()
    WHERE deleted = 0
      AND id IN (?, ?, ?)
   ```
   两点关键：
   - `WHERE deleted = 0`：防止把\"已删除\"再删一次（幂等）；
   - `update_time = NOW()`：借 SQL 侧刷时间戳，避免 Java 侧手动写 `LocalDateTime.now()`。

3. **DTO 与手机号校验**（5 分钟）：`MemberDTO` 全字段一次讲清：
   - `@NotBlank + @Pattern("^1[3-9]\\d{9}$")` 手机号；
   - `@Pattern("^$|(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)")` 身份证号（`^$` 允许空）；
   - `avatar` 字段先只做 URL 字符串校验，文件上传接口下节课讲；
   - `@Min(0) @Max(2)` gender、`@NotNull @Min(1) @Max(4)` cardType；
   - `@NotNull` cardExpire（`LocalDate`）。

   给学生一个提示：**校验注解不是越多越好，能落到\"业务规则\"的注解才有价值**。

#### 示例演示（16 分钟）

1. **在 IDEA 里补齐代码**（10 分钟）：
   - `MemberDTO`：按上面清单加校验注解；
   - `MemberMapper`：`insert(Member)` + `softDeleteByIds(ids)` + `existsByPhone(phone, excludeId)`；
   - XML：`<insert>` 用 `useGeneratedKeys="true" keyProperty="id"`；`<update id="softDeleteByIds">`；`<select id="existsByPhone">` 含 `deleted=0` 过滤；
   - `MemberService.save(dto)`：先 `existsByPhone(phone, null)` → 抛异常 or 落库；
   - `MemberService.delete(ids)`：空校验 + 影响行数校验，与第 2 课时同款模式；
   - `MemberController`：`@PostMapping`、`@DeleteMapping("/{id}")`、`@DeleteMapping`（批量）。

2. **联调 Postman**（5 分钟）：
   - `POST /api/member` body：`{"name":"张小雅","phone":"13800138001","gender":1,"cardType":3,"cardExpire":"2027-07-16"}` → success；
   - 再次 POST 同 phone → \"手机号已被注册\"；
   - `DELETE /api/member/1` → success；
   - `GET /api/member` → id=1 已消失（软删除生效）；
   - **反证软删除**：直接 SQL 查 `SELECT * FROM tb_member WHERE id=1` → 记录还在，`deleted=1`；
   - 再次 `POST` 同 phone `13800138001` → **依然报\"手机号已被注册\"？** 不，因为 `existsByPhone` 里加了 `AND deleted = 0`，此时 count 为 0，可以重新注册（唯一索引 `(phone, deleted)` 允许 `(13800138001, 0)` 与 `(13800138001, 1)` 共存）。

3. **AI 找 Bug**（1 分钟）：给 AI 一段\"故意漏掉 `deleted=0`\" 的 `existsByPhone`，让它指出问题。

#### 课堂练习（9 分钟）
1. 每位学生完成 `POST /api/member` + `DELETE /api/member/{id}` + `DELETE /api/member?ids=` 三个接口的联调；
2. 追加需求：给\"批量软删除\"加\"最多一次 100 条\"限制，超过报错；
3. 思考题：如果表里 `phone=13800138001` 已经有两条记录（`deleted=0` 和 `deleted=1`），此时删掉 `deleted=0` 的那条，新注册第三条会怎样？（唯一索引冲突！引出\"删除时把老的 deleted 值改成 id 而不是 1\"的进阶方案）

#### 小结（3 分钟）
一句话回顾：**软删除三件套 + 手机号 `existsByPhone(phone, excludeId)`**。至此会员的\"增\"与\"删\"完成，下节课把\"改\"和业务层重构做完。

### 5.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-05 会员软删除 + 新增                  │
├───────────────────────────────────────────────┤
│  软删除 SQL 模板：                           │
│    UPDATE tb_member                          │
│       SET deleted=1, update_time=NOW()       │
│     WHERE deleted=0                          │
│       AND id IN (...)                        │
│                                              │
│  手机号校验：                                │
│    @Pattern("^1[3-9]\\d{9}$")                │
│    existsByPhone(phone, excludeId)           │
│    WHERE phone=? AND deleted=0               │
│                                              │
│  唯一索引：                                  │
│    UNIQUE (phone, deleted)                   │
│                                              │
│  头像：先存 URL，上传接口 Day07              │
│                                              │
│  软删除 vs 硬删除：                          │
│    核心业务表 → 软删除                       │
│    日志/临时表 → 硬删除                      │
└───────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 `/api/member` 新增 + 删除接口，交 5 张 Postman 截图（含\"删除后再注册\"这一关键用例）；
2. **必做**：整理\"软删除 checklist\"个人笔记：唯一索引 / SELECT 过滤 / existsByX 过滤 / update_time 刷新 4 条；
3. **挑战**：为 `MemberService.delete` 加 Spring `@Transactional`，思考\"批量操作\"什么时候需要事务。

### 5.6 教学反思提示
- 学生对\"唯一索引带 deleted\"这个设计常常一遍讲不透，建议现场 `DROP INDEX + CREATE UNIQUE INDEX (phone)` 演示一次冲突现象，比讲十遍都管用；
- 手机号正则 `^1[3-9]\\d{9}$` 会漏掉运营商新号段，讲课时提一句\"生产项目建议加个白名单前缀表\"。

---

## 第 6 课时：会员修改 + 业务层重构与异常处理改造

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能实现\"详情回显 + 表单提交\"的修改完整闭环（`GET /api/member/{id}` + `PUT /api/member`）；
2. 能在修改场景下复用 `existsByPhone(phone, excludeId=dto.id)` 唯一性校验模式；
3. 能对已有 Service 做\"业务方法内联异常抛出\"的重构：`if (rows == 0) throw new BizException`；
4. 能规划下一天的\"全局异常处理器\"改造点（`@RestControllerAdvice` + `@ExceptionHandler`），为 Day07 铺路；
5. 能画出\"课程科目 + 会员\" 两模块的接口全景图，做当日复盘。

#### 6.1.2 过程与方法目标
1. 通过\"回显 → 修改 → 保存\"链路的完整走通，理解\"Last Write Wins\"问题与\"先拉最新数据\"的必要性；
2. 通过\"业务层重构\"练习，训练\"重构不改行为，只改结构\"的工程习惯。

### 6.2 教学重难点
- **重点**：`GET /api/member/{id}` 回显接口 + `PUT` 修改接口的组合／`existsByPhone(phone, dto.id)` 的 excludeId 用法／`if (rows==0) throw BizException` 通用容错
- **难点**：\"Last Write Wins\" 并发覆盖问题的直观理解／`BeanUtils.copyProperties` 在部分更新场景的陷阱

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
提问：\"A 前台正在改会员 5 号的手机号，同时 B 前台把 5 号的备注改了并保存了。A 一分钟后点保存，B 的改动会怎样？\"引出\"Last Write Wins\"的经典并发问题。今天的\"修改接口\"必须先做\"详情回显\"来最大程度缩短冲突窗口。

#### 新知讲授（14 分钟）

1. **修改场景为什么需要详情回显**（4 分钟）：
   - **表单初始值**：编辑弹框打开时，前端要拿到最新数据填充，否则表单是空的；
   - **缩短冲突窗口**：拉取最新数据 → 用户改动 → 保存，中间 30 秒的窗口比\"直接拿列表数据打开表单\"的 5 分钟窗口更安全；
   - **字段一致性**：详情返回的字段与修改提交的字段一一对应，前后端契约清晰。

   顺带引出后续\"乐观锁\"（`version` 字段）方案，本课程暂不实现，Day08 后再讲。

2. **修改接口的三个校验层**（5 分钟）：
   - **入口层**：`@Valid` 拦截字段格式问题；
   - **业务层 1**：`dto.getId() == null` 抛异常\"id 不能为空\"；
   - **业务层 2**：`existsByPhone(phone, dto.getId())` 校验\"改成新号后不与他人冲突\"；
   - **落库层**：`if (rows == 0) throw new BizException("会员不存在或已删除")` 兜底。

3. **业务层重构清单**（5 分钟）：本课程走到 Day06 已积累不少 Service 方法，是时候做一次\"内部质量整改\"：
   - 所有\"抛业务异常\"统一用 `BizException(String msg)`，不再抛 `RuntimeException`；
   - 所有\"批量操作\"检查空列表；
   - 所有\"落库操作\"检查影响行数；
   - `save/update` 里 `BeanUtils.copyProperties(dto, entity)` 之后手动补上默认值（如 `status == null → 1`），不要依赖数据库 default（Java 25 record 场景下 default 不总生效）；
   - Day07 会加 `@RestControllerAdvice` 统一转 500 → 400 的业务异常。

#### 示例演示（15 分钟）

1. **完成修改闭环**（8 分钟）：
   - `MemberMapper.getById(Long id)`：`SELECT ... FROM tb_member WHERE id=#{id} AND deleted=0`；
   - `MemberMapper.update(Member m)`：`<update>` + `<set>` 动态更新（12 章示例代码）；
   - `MemberService.getVO(id)`：查库 → 转 VO，若查不到抛异常；
   - `MemberService.update(dto)`：id 校验 → 手机号唯一性（`excludeId=dto.id`）→ update → 影响行数校验；
   - `MemberController`：`@GetMapping("/{id}")` + `@PutMapping`。

2. **联调完整流程**（5 分钟）：
   - `GET /api/member/2` → 返回详情 VO；
   - `PUT /api/member` body 里带 `id=2, phone=13900139000, remark="季卡续到 2027-12"` → success；
   - 再 `GET /api/member/2` → 观察 `phone` 已更新；
   - 再 `PUT /api/member` body `id=2, phone=13800138001`（别人的号）→ \"手机号已被其它会员占用\"；
   - `PUT /api/member` body 不传 id → \"id 不能为空\"；
   - `PUT /api/member` body `id=99999`（不存在）→ \"会员不存在或已删除\"。

3. **业务层重构演示**（2 分钟）：现场把 `SubjectService.save` 里的 `throw new RuntimeException` 全部改成 `throw new BizException`，让学生跟着改。演示 IDEA 的\"结构化查找替换\"技巧。

#### 课堂练习（10 分钟）
1. 每位学生完成 `GET /api/member/{id}` + `PUT /api/member` 联调，交 5 张截图；
2. 追加需求：为 `MemberService.update` 加 `@Transactional`，思考\"手机号校验查询 + update\" 是否真的需要事务；
3. 综合任务：把 Day06 涉及的 8 个接口全部整理到一张 Postman Collection 里，导出 JSON 提交（作业里必交）。

#### 小结（3 分钟）
一句话回顾：**修改闭环 = 详情回显 + 唯一性校验（excludeId）+ 影响行数兜底**。Day06 全部完成，两个模块 8 个接口一次落地。预告 Day07：**统一日志 + 全局异常处理 + 文件上传（会员头像）**。

### 6.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day06-06 会员修改 + 业务重构                │
├───────────────────────────────────────────────┤
│  修改闭环：                                  │
│   GET  /api/member/{id}  ← 回显              │
│   PUT  /api/member       ← 提交              │
│                                              │
│  三层校验：                                  │
│    @Valid       格式                         │
│    id==null?    空                           │
│    existsByPhone(phone, dto.id)  唯一        │
│    rows==0?     落库兜底                     │
│                                              │
│  业务层重构 4 条：                           │
│   ① throw BizException 而不是 RE             │
│   ② 空列表校验                               │
│   ③ 影响行数校验                             │
│   ④ 默认值 Java 侧兜底                       │
│                                              │
│  Day06 交付：                                │
│   /api/category × 4 + /api/member × 4        │
│                                              │
│  下集预告：Day07 全局异常 + 文件上传         │
└───────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成 `GET/PUT /api/member` 修改闭环，交 5 张 Postman 截图；
2. **必做**：把 Day06 所有 8 个接口整理成 Postman Collection，导出 JSON 附作业；
3. **必做**：Day06 复盘 500 字：踩过的坑（≥3 个）+ 收获（≥3 条）+ 明天想问老师的问题（≥1 个）；
4. **挑战**：为 `Member` 加 `join_channel`（1 老带新 / 2 地推 / 3 大众点评 / 4 抖音）字段，从 DDL 到接口全链路改造，交 diff 补丁。

### 6.6 教学反思提示
- 本课时是 Day06 收尾，节奏可以稍缓，多留 2 分钟做\"两个模块接口全景\"的板书回顾；
- 若学生已明显疲劳，可以把\"业务层重构\"讲成\"下节课再展开的伏笔\"，把注意力集中在\"修改闭环\"上；
- Day06 结束应确认每位学生都能完整跑通 8 个接口，不能跑通的必须现场帮忙定位——这两个模块是后续所有业务模块的模板。

---

## 附录 A：Day06 接口全景一览

| 序号 | 模块 | 方法 | 路径 | 说明 |
|------|------|------|------|------|
| 1 | 课程科目 | GET | `/api/category` | 分页 + 模糊 + 状态筛选 |
| 2 | 课程科目 | POST | `/api/category` | 新增（名称唯一） |
| 3 | 课程科目 | PUT | `/api/category` | 修改（excludeId 唯一） |
| 4 | 课程科目 | DELETE | `/api/category?ids=1,2,3` | 批量删除（硬删） |
| 5 | 会员 | GET | `/api/member` | 分页 + 多条件（含日期区间） |
| 6 | 会员 | GET | `/api/member/{id}` | 详情回显 |
| 7 | 会员 | POST | `/api/member` | 新增（手机号唯一） |
| 8 | 会员 | PUT | `/api/member` | 修改（手机号 excludeId 唯一） |
| 9 | 会员 | DELETE | `/api/member/{id}` | 单条软删除 |
| 10 | 会员 | DELETE | `/api/member?ids=1,2,3` | 批量软删除 |

## 附录 B：Day06 核心口诀

- **分页三件套**：`PageHelper.startPage → mapper.list → PageInfo`；
- **批量删除格式**：`?ids=1,2,3` → `@RequestParam List<Long>`；
- **动态 SQL 三剑客**：`<where> <set> <foreach>`；
- **唯一性校验**：`existsByX(value, excludeId)`；
- **软删除三件套**：唯一索引带 `deleted` + 每条 SELECT 加 `deleted=0` + `existsByX` 加 `deleted=0`；
- **日期区间**：左闭右开，`>= begin AND < DATE_ADD(end, INTERVAL 1 DAY)`；
- **修改闭环**：先 GET 回显、再 PUT 提交；
- **三层校验**：格式（`@Valid`）→ 业务（`BizException`）→ 落库（影响行数）。

## 附录 C：Day06 常见问题速答

| 问题 | 回答 |
|------|------|
| PageHelper 分页失效 | 检查 `PageHelper.startPage` 与目标 select 之间有没有夹别的 SQL |
| `?ids=` 收不到 | 前端 axios 用 `params.ids = [1,2,3].join(',')`，或改用 URLSearchParams 的多值格式 |
| 删除后再注册报冲突 | 唯一索引没带 `deleted`，改 `UNIQUE (phone, deleted)` |
| 日期区间漏最后一天 | 改成左闭右开 `< DATE_ADD(end, INTERVAL 1 DAY)` |
| `@Valid` 不生效 | Controller 参数漏了 `@RequestBody`，或依赖没引 `spring-boot-starter-validation` |
| 修改 status 传 null 被覆盖 | `BeanUtils.copyProperties` 是浅拷贝，null 也会覆盖；用 `<set>` + `<if>` 动态更新 |

---

**Day06 教师教案完**
