# 《AI 应用 Web 开发》 - 教师教案（Day15：JWT 登录前端 + Nginx 部署 + Linux 基础）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day14 的学生（掌握 Spring Boot 4.0.x 后端全链路、JWT 后端签发与拦截器、Vue 3 + TypeScript + Pinia + Vue Router + Element Plus 全部前端页面、Axios 封装、ECharts、表单校验、`vite dev` 联调、`pnpm build` 概念）**
**知识点覆盖：** 第 29 章 JWT 登录 / 退出前端 + Nginx 生产部署（Pinia AuthStore、Axios 请求 / 响应双拦截、路由守卫、SPA fallback、反向代理、Gzip、长缓存）+ 第 30 章 Linux 项目部署（SSH 密钥、目录结构、chmod / chown、systemd、ufw、rsync / scp、JDK / MySQL / Nginx 一键安装）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / Vue 3.5+ / Vite 5.4+ / Pinia 2.2+ / Vue Router 4.4+ / Axios 1.7+ / Element Plus 2.8+ / Ubuntu 22.04 LTS / Nginx 1.24 / OpenJDK 25 / MySQL 8.0 / IDEA 2024.3+ / 通义灵码 + Trae。

**Day15 主线**：Day13–Day14 我们把印想瑜伽后台管理系统的 8 大业务页面写完了——但从「本地能跑」到「学员打开浏览器就能用」还差最后一公里。今天前 3 个课时把「登录前端闭环」补齐：登录页 + 验证码 + Pinia AuthStore + Axios 双拦截 + 路由守卫 + 401 兜底跳转 + 不活跃自登出；中间 1 个课时把 `pnpm build` 打出的 `dist/` 目录逐字节讲透——`manualChunks` 拆包、`hash` 长缓存、`index.html` 不缓存的**版本切换三原则**；后 2 个课时把项目搬上 Ubuntu 22.04 服务器：SSH 密钥登录、`apt` 装 JDK / MySQL / Nginx、Nginx 反向代理 `/api/` + SPA fallback、`systemd` 托管 Jar、`ufw` 放通防火墙、`deploy.sh` 一键部署。Day15 结束后学生手里的作品链接可以直接投到简历。

---

## 第 1 课时：登录页开发（表单 + 验证码 + 提交）

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能写出 `LoginView.vue` 的三段式结构：`<template>` 表单 + `<script setup>` 响应式状态 + `<style scoped>` 局部样式；
2. 能用 `el-form` + `el-form-item` + `rules` 三件套完成账号、密码、验证码的三级校验，并解释 `blur` 与 `change` 触发时机的差异；
3. 能定义 `LoginDTO { username, password, captchaKey, captchaCode }` 与后端的字段严格对齐，并说清「验证码由前端主动拉取、后端签发一次性 key」的两次握手流程；
4. 能用 `authApi.captcha()` 拉 base64 图片直接塞进 `<img :src>`，避免二进制流传输；
5. 能实现「点图片刷新验证码」的用户体验，并解释为什么必须**同时**换 `captchaKey`——服务端一次性 key 用完即废。

#### 1.1.2 过程与方法目标
1. 通过「先画静态页 → 再挂 rules → 再打通后端」的三段推进节奏，让学生亲手体会「表单不是先绑 API 后调样式」；
2. 通过让学生故意先漏 `captchaKey` 提交一次的对照实验，训练「前后端字段契约必须先约定后写代码」的工程思维。

### 1.2 教学重难点
- **重点**：`el-form` 三件套的完整闭环（`ref` + `rules` + `validate()`）／验证码「拉取 - 展示 - 提交 - 刷新」四步握手／`Enter` 键在密码框回车自动登录的 `@keyup.enter`
- **难点**：为什么 `formRef.value?.validate()` 返回 Promise 而不是布尔值——异步校验（后端唯一性）需要等待／为什么点验证码图刷新时**旧的 captchaKey 必须立即丢弃**（否则用户看到新图但用旧 key 提交，服务端一定 400）／登录页禁止路由守卫触发（`meta.public: true`）——否则死循环

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
Day14 结尾学生已经把课程管理页做完，能用 Postman 拿 Token 手动放进 Header 联调。反问：「我把项目给同学演示，同学说『我在哪儿登录？』——你直接打开 `/courses`，浏览器一片空白，控制台一堆 401。今天要给项目**补一张脸**。」板书写下今天要交付的路由画像：

```
/login       — 未登录必到
POST /api/auth/captcha  → { key: "abc123", image: "data:image/png;base64,..." }
POST /api/auth/login    → { token: "eyJ...", user: { username, roles, perms } }
登录成功 → 跳 /dashboard 或 ?redirect=xxx
```

#### 目标（2 分钟）
一句话：**「把登录页从『一张 UI 稿』推进到『能真把 Token 拿回来的能用页面』」**。今天先把「表单 + 验证码 + 提交」这三步跑通，Pinia 存 Token 和 Axios 拦截放到第 2 课时。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 验证码 `key` 和 `image` 是一对孪生——**换图必须换 key**
- 🔴 `formRef.value?.validate()` 返回 Promise——`await` 后再判断

#### 新知讲授（14 分钟）

1. **页面骨架与 `el-form` 三件套**（4 分钟）：
   - 现场敲 `LoginView.vue`：`<el-form :model=\"form\" :rules=\"rules\" ref=\"formRef\">` 三个属性缺一不可；
   - `form` 是响应式对象，必须用 `reactive({ username: '', password: '', captchaCode: '' })`，不能用 `ref({...})`——`el-form` 内部会 `v-model` 到具体字段；
   - `rules` 用**普通对象**即可，不需要响应式——校验规则是静态的；
   - `formRef` 是 `ref<FormInstance>()`，模板上 `ref=\"formRef\"` 拿到组件实例，`formRef.value?.validate()` 才是校验入口。

2. **验证码「四步握手」**（4 分钟）：
   - 板书流程：`onMounted → captcha() → 拿到 key+image → 展示 → 提交带 key → 后端比对`；
   - 定义 `captchaKey = ref('')` 与 `captchaImg = ref('')`；`refreshCaptcha` 函数**同时**赋值这两个——学生最容易只更新 `captchaImg` 而漏 `captchaKey`；
   - 强调后端一次性 key：**同一个 key 提交两次会 400**——防重放攻击；
   - 图片用 base64 塞 `<img :src=\"captchaImg\">` 而不是 URL——避免第二次 GET 请求，也免去 CORS 问题。

3. **提交逻辑与 `Enter` 键**（6 分钟）：
   - `onSubmit` 骨架：`await formRef.value?.validate()` 校验 → `loading.value = true` → `await authApi.login(dto)` → 跳转；
   - `try / catch / finally` 三段——`catch` 里 `refreshCaptcha()` 一定要调，避免用户拿旧 key 反复试；
   - 密码框加 `@keyup.enter=\"onSubmit\"`——用户按回车不用鼠标点按钮；
   - `loading` 状态绑到 `el-button` 的 `:loading` 上——按钮 disable + spinner 一步到位；
   - 强调**登录接口错误不要弹 `BizError` 的原始 msg**——统一提示「账号或密码错误」防止用户名枚举。

#### 课堂活动（15 分钟）

1. **示例演示：跑通「打开 /login → 输账号密码 → 200 拿到 Token」**（8 分钟）：
   - 后端已在 Day07 完成 `/auth/captcha` 与 `/auth/login`，先用 Postman 验证接口存在；
   - 前端敲 `views/login/LoginView.vue`：40 行 `<template>` + 60 行 `<script setup>` + 20 行 `<style scoped>`；
   - 联调步骤：`pnpm dev` → 打开 `http://localhost:5173/login` → 看到验证码图 → 输 `admin / 123456 / 图上的字` → 点登录；
   - 断点在 Chrome DevTools 的 Network 面板：看到 `POST /api/auth/login 200`，Response 里有 `token` 字段——**「Token 拿到手了，就差存起来」**（为第 2 课时铺垫）。

2. **反面演示：漏 captchaKey 会发生什么**（5 分钟）：
   - 故意把 `refreshCaptcha` 里 `captchaKey.value = r.key` 这行注释掉；
   - 第一次登录成功、第二次失败——因为 key 被后端消费了；
   - 学生一定看到 400 但一头雾水；
   - 让学生自己把这行加回来，理解「一对孪生变量必须同步更新」；
   - 板书画一个红色警告框：**「验证码换图 = 换 key + 换 image，二者必须原子操作」**。

3. **AI 生成对照**（2 分钟）：
   - 把「Vue 3 + Element Plus 登录页」需求丢给通义灵码；
   - 常见 AI 错误：① `form` 用 `ref` 而不是 `reactive`——`el-form` 校验拿不到；② 验证码用 `<img :src=\"/api/auth/captcha\">` 直接拉——每次校验都换一张；③ 忘 `@keyup.enter`——用户体验掉一档；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「登录页 = 表单三件套 + 验证码四步握手 + Enter 键回车」**。今天把 Token 拿回手里，下节课把它存进 Pinia + 让 Axios 每次请求自动带上。

### 1.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-01 登录页开发                           │
├────────────────────────────────────────────────┤
│  el-form 三件套：                              │
│   :model + :rules + ref                        │
│   formRef.value?.validate() → Promise          │
│                                                │
│  验证码四步握手：                              │
│   onMounted → GET /auth/captcha                │
│   → { key, image(base64) }                     │
│   → 展示 <img :src=\"image\">                    │
│   → POST /auth/login { ..., captchaKey, code } │
│                                                │
│  🔴 key 与 image 必须原子替换                  │
│  🔴 一次性 key 提交后立即刷新                  │
│  🔴 catch 里 refreshCaptcha() 不能漏           │
│                                                │
│  Enter 键：@keyup.enter=\"onSubmit\"             │
│  loading：:loading=\"submitting\"                │
└────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `LoginView.vue` 的完整实现（表单 + 验证码 + 提交），联调三种场景（成功 / 密码错 / 验证码错），交 3 张浏览器截图 + Network 面板；
2. **必做**：给验证码图加一个「点击刷新」的鼠标手势 `style=\"cursor:pointer\"` + `@click=\"refreshCaptcha\"`，验证连续点 5 次每次都拿到新 key；
3. **挑战**：给用户名字段加**记住我**——用 `localStorage` 存最后一次登录的用户名（不存密码），下次打开自动填。

### 1.6 教学反思提示
- 学生最容易忘的是 `reactive` 与 `ref` 的选择——`el-form` 的 `:model` **只接受**响应式对象，学生用 `ref({...})` 时 `.value` 不解引用会报错；
- 演示时故意不写 `@keyup.enter`，让学生用回车提交发现不响应——引出这个易忽视点；
- 验证码图片如果后端返回的是二进制流而不是 base64，学生的 `<img :src>` 会显示破图——务必先用 Postman 确认 `image` 字段格式再敲代码。

---

## 第 2 课时：JWT 存储 + Axios 注入 + 401 拦截

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能定义 `useAuthStore` 的 `state / getters / actions` 三段结构，用 `localStorage` 做兜底持久化，解释「刷新页面 Pinia 状态会重置」的原因；
2. 能写出 `TOKEN_KEY = 'yx_token'` + `USER_KEY = 'yx_user'` 两个前缀化的 key 约定，避免与其他项目冲突；
3. 能实现 Axios 请求拦截器：**每次请求自动带 `Authorization: Bearer <token>`**，无 token 时不带 Header；
4. 能实现 Axios 响应拦截器：`code === 0` 直接返回 `data`；`code !== 0` 抛 `BizError`；HTTP 401 触发登录跳转；
5. 能理解 `redirecting` 全局标志位的作用——**防并发洪水**：多个页面接口同时 401 时只跳转一次。

#### 2.1.2 过程与方法目标
1. 通过「先刷新页面掉登录 → 再加 localStorage 兜底」的自然过程，让学生亲手体会「响应式状态是内存的、跨刷新要落盘」；
2. 通过手动改 Token 让它变成非法字符串，让学生看到「后端 401 + 前端跳登录 + 带 redirect 回原页」的完整闭环。

### 2.2 教学重难点
- **重点**：Pinia `defineStore` 三段式（`state / getters / actions`）／`localStorage` 兜底的初始化时机（`state` 工厂函数里读）／Axios 拦截器的**请求拦截**加 Header + **响应拦截**统一解包 `Result`／401 兜底跳登录带 `?redirect=`
- **难点**：为什么 `state` 里读 `localStorage` 时要用 `JSON.parse` 兜底 `'null'`——`getItem` 可能返回 `null` 字符串／为什么 `redirecting` 是模块级变量而不是 `authStore` 里的字段——跨多个请求共享一个开关／为什么响应拦截里 `blob` 类型要提前 return——不能试图解析 JSON

### 2.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
接着第 1 课时结尾——「Token 拿到手了但只在 `login()` 函数的局部变量里，用户跳到 `/dashboard` 前端就忘了」。板书画一根箭头：`浏览器 → 请求 /api/courses`——但请求头**没带 Token**，后端 401。反问：「我们要么每个 API 调用手动加 Header（300 个方法都改），要么让 Axios 自动加。选哪个？」引出**拦截器**这个「一次配置全局生效」的杠杆。

#### 目标（2 分钟）
一句话：**「让 Token 一次登录、全局自动带；一次过期、全局跳登录」**。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 Pinia state 只活在内存——**刷新页面即消失**，必须 localStorage 兜底
- 🔴 401 并发洪水——**redirecting 单一开关**只跳一次

#### 新知讲授（14 分钟）

1. **`useAuthStore` 骨架**（4 分钟）：
   - `defineStore('auth', { state, getters, actions })` 三段结构；
   - `state: () => ({ token: localStorage.getItem('yx_token') || '' })`——**工厂函数**才能在 store 创建时读一次 localStorage；
   - `getters.isLoggedIn: s => !!s.token`——布尔计算属性；
   - `actions.login / logout / clear`——**修改状态的唯一入口**，禁止组件直接 `authStore.token = ''`；
   - 每次 `login` 成功都 `localStorage.setItem(TOKEN_KEY, token)`——**修改 state 与落盘要成对出现**。

2. **Axios 请求拦截器**（4 分钟）：
   - `instance.interceptors.request.use(cfg => { ... return cfg })`——**必须返回 cfg**，不然请求发不出去；
   - `if (auth.token) cfg.headers.Authorization = 'Bearer ' + auth.token`——**空 token 时不加**，避免后端拿到 `Bearer ` 空串误判；
   - 常见坑：`useAuthStore()` 只能在**函数体内调**——放到模块顶层会在 Pinia 初始化前执行报错。

3. **Axios 响应拦截器 + 401 兜底**（6 分钟）：
   - 三段处理：`resp.config.responseType === 'blob'` 直接返回原始 `resp.data`（下载文件）／`body.code === 0` 返回 `body.data`／`body.code !== 0` 抛 `BizError`；
   - `err.response?.status === 401` 分支：`clear()` 清 Pinia + localStorage、`ElMessage.warning('登录已过期')`、`router.replace({ path: '/login', query: { redirect: 当前路径 } })`；
   - `redirecting` 模块级布尔：进入 401 分支前判断 + 设置为 `true`，跳转后再置回 `false`——**并发请求只走一次跳转**；
   - 强调 `redirect` 参数：登录成功后读 `route.query.redirect` 回到原页——用户体验提升一大截。

#### 课堂活动（15 分钟）

1. **示例演示：完整登录 - 请求 - 401 闭环**（8 分钟）：
   - 敲完 `stores/auth.ts` 与 `api/request.ts`；
   - `pnpm dev` → 打开 `/login` → 登录成功 → 手动导航到 `/courses`；
   - Chrome DevTools Network 面板：每个 `/api/*` 请求 Header 里都有 `Authorization: Bearer eyJ...`；
   - 打开 Console 手动 `localStorage.setItem('yx_token', 'aaa')` 篡改 Token → 刷新 → 直接跳登录 + URL 带 `?redirect=/courses`；
   - **「一次配置，全项目自动加 Token + 自动跳登录」**——学生第一次感受到 Axios 拦截器的杠杆。

2. **反面演示：redirecting 开关的作用**（5 分钟）：
   - 打开 Dashboard 页（同时并发 5 个接口拿数据）；
   - 手动改 Token 非法 → 刷新；
   - 未加 `redirecting` 版本：屏幕上 `ElMessage.warning` 弹了 5 次、路由 replace 也走了 5 次；
   - 加了 `redirecting` 版本：只弹 1 次、只跳 1 次；
   - 板书画红色警告框：**「网络洪水场景要有幂等开关」**。

3. **AI 生成对照**（2 分钟）：
   - 把「Axios 401 拦截跳登录」丢给通义灵码；
   - AI 常见错误：① 没考虑并发（每个请求都跳一次）；② 用 `window.location.href` 而不是 `router.replace`——页面全刷新，Pinia 丢；③ `err.response` 没做 `?.` 可选链，网络断线时 `err.response is undefined` 又崩一次；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「Pinia + Axios 双拦截 = 前端鉴权全自动」**。今天完成了「登录后所有请求自动带 Token」+「Token 过期自动跳登录」两条闭环，下节课把路由守卫补上。

### 2.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-02 JWT 存储 + Axios 注入 + 401 拦截     │
├────────────────────────────────────────────────┤
│  Pinia AuthStore 三段：                        │
│   state()  { token, user, permCache }          │
│   getters  { isLoggedIn, roles, perms }        │
│   actions  { login, logout, clear, hasPerm }   │
│   localStorage 兜底：yx_token / yx_user        │
│                                                │
│  Axios 请求拦截：                              │
│   auth.token → Authorization: Bearer xxx       │
│                                                │
│  Axios 响应拦截：                              │
│   blob      → 原样 return                      │
│   code=0    → 返回 data                        │
│   code≠0    → throw BizError                   │
│   401       → clear + 跳 /login?redirect=...   │
│                                                │
│  🔴 redirecting 模块级开关（防洪水）           │
│  🔴 state 工厂函数里读 localStorage            │
└────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成 `stores/auth.ts` + `api/request.ts` 两个文件，联调「登录 → 拿数据 → 手动改 token → 401 跳登录 + redirect」全流程，交 Network 面板截图 3 张；
2. **必做**：给 `BizError` 加上 `toString()`，让 `ElMessage.error(err)` 直接输出可读文案；
3. **挑战**：实现 Access Token / Refresh Token 双 Token 机制的**响应拦截**部分——401 时先用 refreshToken 换新 accessToken 成功则重放原请求，失败再跳登录。

### 2.6 教学反思提示
- 学生 90% 会把 `useAuthStore()` 写到模块顶层——一定在演示时提前打开 Vite 报错窗口截图给学生看；
- `redirecting` 是模块级布尔学生一开始理解不了「为什么不是 store 字段」——用「多个购物袋共用一个门口保安」的比喻；
- 学生可能会问「为什么不用 sessionStorage」——回答：sessionStorage 关闭标签页就没了，但用户可能只是刷新，体验差。

---

## 第 3 课时：路由守卫 + 退出 + 不活跃自登出

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能写出 `router.beforeEach((to, from) => ...)` 的三段判断：白名单直放 / 未登录跳登录 / 权限码校验；
2. 能定义 `meta: { public: true, title: '登录', perm: 'course:view' }` 的三层元信息，并解释 `meta` 的继承特性；
3. 能实现「登录后回原页」——`route.query.redirect` 优先跳，无则跳 `/dashboard`；
4. 能实现「退出登录」——调后端 `/auth/logout`（把 Token 加黑名单）+ 清本地 + 跳 `/login`；
5. 能实现「30 分钟不活跃自动登出」——监听 `mousemove / keydown` 重置计时器，超时 `auth.logout()`。

#### 3.1.2 过程与方法目标
1. 通过「先跑 dashboard 掉登录 → 再加白名单 → 再加权限码」的三级递进，让学生亲手体会「路由守卫是一次拦截、多重规则」；
2. 通过让学生打开 F12 手动删 Token 又刷新的对照实验，训练「前端权限只是体验、后端才是最后一道墙」的安全观。

### 3.2 教学重难点
- **重点**：`beforeEach` 的返回值三形态（`true` / `false` / `RouteLocationRaw`）／`meta.public` 白名单模式／`meta.perm` 权限码 + `authStore.hasPerm()` 的配合／`v-perm` 自定义指令控制按钮级权限
- **难点**：为什么 `beforeEach` 里不能用 `router.push`——应该直接 `return { path: '/login' }`（否则死循环）／`document.title = to.meta.title` 是**副作用**，放在 return 之前不会被后续 `return` 打断／不活跃自登出的**事件监听要在 App.vue 挂载**，路由守卫里加会重复注册

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
反问：「登录页做完了、Axios 拦截也搞定了。但如果用户直接在地址栏敲 `/courses`——没登录会怎样？」学生：「Axios 会 401 跳登录。」老师：「对，但这是**用户先看到一片空白再跳走**——闪一下，体验差。**在路由进入前**就判断有没有登录，才是真本事。」引出**路由守卫**——「浏览器换页面时的门卫」。

#### 目标（2 分钟）
一句话：**「让浏览器换 URL 时先过一道大脑再显示页面——未登录跳登录、无权限跳首页」**。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 守卫返回 `{ path: '/login' }` 而不是 `router.push('/login')`
- 🔴 白名单要覆盖 `/login` 和 `/404`——否则死循环

#### 新知讲授（14 分钟）

1. **`beforeEach` 三段判断**（4 分钟）：
   - 骨架：`router.beforeEach((to, from) => { ...return true 或 return { path } 或 return false... })`；
   - 第 1 段：`if (to.meta.public) return true`——登录页、404 页放行；
   - 第 2 段：`if (!auth.isLoggedIn) return { path: '/login', query: { redirect: to.fullPath } }`；
   - 第 3 段：`if (to.meta.perm && !auth.hasPerm(to.meta.perm)) return { path: '/dashboard' }`——无权限回首页并 `ElMessage.error('权限不足')`；
   - 强调**副作用要写在判断前**：`document.title = ...` 每次都要执行。

2. **权限码：路由 + 菜单 + 按钮**（4 分钟）：
   - 路由级：`meta.perm: 'course:view'`——守卫兜底；
   - 菜单级：侧边栏 `v-if=\"auth.hasPerm('course:view')\"`——没权限的菜单不显示；
   - 按钮级：`<el-button v-perm=\"'course:delete'\">删除</el-button>`——用自定义指令 `mounted` 时 `el.remove()`；
   - 板书画「三层过滤网」，强调**前端过滤只是体验优化，后端拦截器才是最终防线**。

3. **退出登录 + 不活跃自登出**（6 分钟）：
   - `authStore.logout()`：调 `authApi.logout()`（后端加黑名单）→ `try/catch` 吞掉网络错误 → `clear()` 清本地 → `router.push('/login')`；
   - **不活跃自登出**：在 `App.vue` 里挂一个 30 分钟计时器；
   - `window.addEventListener('mousemove' / 'keydown' / 'click', resetTimer)`——三种交互事件重置；
   - `setTimeout(() => { ElMessageBox.confirm('长时间未操作，请重新登录') ; auth.logout() }, 30 * 60 * 1000)`；
   - `onBeforeUnmount` 记得 `removeEventListener + clearTimeout`——防内存泄漏。

#### 课堂活动（15 分钟）

1. **示例演示：跑通「未登录直接访问 /courses」**（8 分钟）：
   - 学生按 F12 → Application → Local Storage → 删掉 `yx_token`；
   - 地址栏敲 `http://localhost:5173/courses`；
   - **未加守卫**版：先看到 layout 骨架 → 接口 401 弹 → 才跳登录（闪屏 2 秒）；
   - **加了守卫**版：直接跳 `/login?redirect=/courses`，不闪屏；
   - 登录后自动回到 `/courses`——「回原页」体验闭环。

2. **权限体验测试**（5 分钟）：
   - 后端给一个 `readonly` 角色（只有 `course:view` 没有 `course:edit`）；
   - 登录 readonly 账号 → 侧边栏没「操作日志」菜单（`log:view` 权限被过滤）；
   - 「课程管理」列表里没「删除」按钮（`v-perm` 生效）；
   - 手动地址栏敲 `/courses/edit/1` → 守卫跳 `/dashboard` + 弹「权限不足」；
   - **三层防护齐上阵**。

3. **AI 生成对照**（2 分钟）：
   - 把「vue-router 路由守卫」丢给通义灵码；
   - 常见 AI 错误：① 用 `next()` 老风格 API（Vue Router 4 已过时，直接 return 更清晰）；② 白名单漏 `/404` 造成 404 页自己进不去；③ 不用 `redirect` 参数——登录后一律跳首页体验差；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「路由守卫 = 白名单 + 未登录跳登录 + 权限码校验 + 副作用（标题）」**。至此登录闭环 100% 打通，下节课开始把项目「打包上线」。

### 3.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-03 路由守卫 + 退出 + 不活跃自登出       │
├────────────────────────────────────────────────┤
│  beforeEach((to, from) => ...)                 │
│   ① document.title = to.meta.title             │
│   ② to.meta.public          → return true      │
│   ③ !auth.isLoggedIn        → { path:'/login', │
│                     query:{ redirect:fullPath }│
│   ④ to.meta.perm 无权限     → { path:'/dashb' }│
│   ⑤ return true                                │
│                                                │
│  三层权限过滤：                                │
│   路由级 meta.perm                             │
│   菜单级 v-if=\"auth.hasPerm(x)\"                │
│   按钮级 v-perm=\"'x'\"                          │
│                                                │
│  不活跃自登出：                                │
│   App.vue onMounted 挂计时器                   │
│   mousemove/keydown/click → resetTimer         │
│   30 分钟 → auth.logout()                      │
│                                                │
│  🔴 守卫内 return 而不是 router.push           │
│  🔴 后端才是最后一道墙                         │
└────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：给 8 个路由都补上 `meta.perm` + `meta.title`，登录 readonly 账号验证「菜单缺、按钮无、地址栏访问被拦」三层过滤；
2. **必做**：实现 30 分钟不活跃自动登出，倒计时最后 60 秒弹 `ElMessageBox.confirm` 让用户「续期 / 立刻登出」二选一；
3. **挑战**：把 `meta.perm` 从单值升级为**数组或表达式**——支持 `perm: ['course:view', 'course:edit']`（任一即可）或 `perm: 'course:view && course:edit'`（都要）。

### 3.6 教学反思提示
- 学生最容易忘的是**白名单也要覆盖 404 页**——否则未登录用户访问不存在路径会跳登录，登录后又跳去 404，用户体验拧巴；
- 「不活跃自登出」学生第一版几乎都会漏掉 `onBeforeUnmount` 里清理事件监听——路由切换时旧计时器还在跑，30 分钟后突然弹登出，学生一脸懵；
- 演示时故意登录 readonly 账号让学生看「没权限的菜单直接不显示」的效果——比后端返回 403 弹窗好得多。

---

## 第 4 课时：Vue 项目打包（vite build）+ dist 分析

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能配置 `.env.development` / `.env.production` 两份环境变量，理解 `VITE_` 前缀是**必须的**（否则运行时读不到）；
2. 能执行 `pnpm build` 并解读产物结构：`index.html` + `assets/*.js` + `assets/*.css`；
3. 能配置 `manualChunks` 把 `vue-vendor` / `element-plus` / `echarts` 三大依赖拆成独立包，理解「浏览器并发加载 + 二次命中缓存」的收益；
4. 能解释 `hash` 文件名与 `Cache-Control: immutable` 的配合：**静态资源长缓存 30 天**、`index.html` 不缓存的原因；
5. 能用 `pnpm preview` 在本地起 4173 端口验证生产包能跑，`vite preview` 只做静态服务不做 HMR。

#### 4.1.2 过程与方法目标
1. 通过「先无脑 build → 再看 chunk 大小 → 再拆包」的三段推进，让学生亲手体会「打包不是一键操作，是可调优的工程活」；
2. 通过对比首次访问与刷新访问的 Network 面板 200 vs 304 vs disk cache，训练「性能优化要基于事实数据」的思维。

### 4.2 教学重难点
- **重点**：`import.meta.env.VITE_API_BASE_URL` 与 `VITE_APP_TITLE` 的用法／`base: '/'` 与子路径 `/admin/` 的区别／`manualChunks` 对象形式的分包／`chunkSizeWarningLimit` 抑制警告的**正当理由**
- **难点**：为什么 `sourcemap` 生产环境要关——**防源码泄漏**，且开了产物翻倍／`vite preview` 与 `pnpm dev` 的区别（HMR 关、Proxy 关，与 Nginx 环境更接近）／`base` 配错时静态资源 404 的排查思路（Chrome Network 看 URL）

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「昨天代码全在本地跑，`vite dev` 的 Proxy 帮我们把 `/api` 转到 8080。但**明天要给同学演示**——他没有 5173 端口，你只能把 `dist/` 交给 Nginx。今天我们把 `pnpm build` 打出来的 `dist/` 逐字节讲透。」板书写下今天要看的三个数字：

```
dist/  ~1.5MB
gzip   ~450KB
首屏 chunk < 200KB
```

#### 目标（2 分钟）
一句话：**「把 `pnpm dev` 环境的产物打包成 Nginx 能直接托管的 `dist/`，并把首屏包压到 500KB gzip 以下」**。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 `VITE_` 前缀——不加运行时读不到
- 🔴 `base` 与部署路径必须一致——子路径部署时改 `base: '/admin/'`

#### 新知讲授（14 分钟）

1. **环境变量三件套**（4 分钟）：
   - 板书三个文件：`.env`（公共）、`.env.development`（`pnpm dev` 读）、`.env.production`（`pnpm build` 读）；
   - 变量必须 `VITE_` 前缀——防止把敏感变量（数据库密码）误暴露到前端；
   - 使用 `import.meta.env.VITE_API_BASE_URL || '/api'` 读取，兜底值防止空指针；
   - 强调 `.env.local` 加入 `.gitignore`——本地调试才用的临时值。

2. **`pnpm build` 全流程**（4 分钟）：
   - 现场执行 `pnpm build`——学生看到 Rollup 打包日志滚动；
   - 打完后 `ls -alh dist/assets/`——看到 20~40 个带 hash 的文件；
   - `index.html` 引用 `<script src=\"/assets/index-a1b2c3.js\">`——**hash 是打包时算出的内容指纹**，内容变了 hash 就变；
   - 强调「文件内容变了 → 文件名变了 → 浏览器不会命中旧缓存」——**版本切换即时生效的物理基础**。

3. **`manualChunks` 分包 + 长缓存策略**（6 分钟）：
   - 无分包时 `index-xxx.js` 可能 800KB——首屏一次性下载太慢；
   - 加 `manualChunks: { 'vue-vendor': ['vue','vue-router','pinia'], 'ele': ['element-plus'], 'echarts-vendor': ['echarts'] }`；
   - 再 build → 得到 4 个 chunk，浏览器可并发下载；
   - **二次访问收益**：`vue-vendor` 内容极少变——用户改一次业务代码只有 `index-xxx.js` 变，其他 3 个 chunk 命中缓存；
   - Nginx 配长缓存 `expires 30d; add_header Cache-Control immutable`——因为 hash 变名，`immutable` 是安全的；
   - `index.html` 反之必须 `no-cache`——每次访问都要拿新版才能看到新 hash。

#### 课堂活动（15 分钟）

1. **示例演示：完整 build + preview + 分析**（8 分钟）：
   - 修改 `vite.config.ts` 加 `manualChunks`；
   - `pnpm build` → 看到 chunk 拆开的日志（`vue-vendor.xxx.js 89KB`、`ele.xxx.js 620KB`、`index.xxx.js 210KB`）；
   - `pnpm preview` 起 4173 端口 → 打开浏览器 → F12 Network 看 4 个 chunk 并发下载；
   - 二次刷新 → 3 个 vendor chunk 命中 disk cache（灰色）、只有 index 是 200；
   - **「首屏还是全下、二次刷新只下 20KB」**——性能优化立竿见影。

2. **反面演示：base 配错的排查**（5 分钟）：
   - 故意把 `base` 改成 `/admin/`，`pnpm build` 后 `pnpm preview`；
   - 打开 `http://localhost:4173/`——一片白；
   - F12 Network 看到 `/admin/assets/xxx.js` 全 404；
   - 让学生自己想「为什么会去请求 /admin」——因为 `index.html` 里 `<script src=\"/admin/assets/...\">` 是编译期硬编码的；
   - 改回 `base: '/'` 或访问 `http://localhost:4173/admin/`——两种解法。

3. **AI 生成对照**（2 分钟）：
   - 把「Vite 分包配置」丢给通义灵码；
   - AI 常见错误：① 把每个 `node_modules` 依赖单独一 chunk（HTTP 请求爆炸）；② 忘了 `chunkSizeWarningLimit` 造成控制台警告刷屏；③ 没开 `sourcemap: false`——生产泄漏源码；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「build = 环境变量 + 分包 + 长缓存 hash 名。dist/ 就是 Nginx 明天要托管的一堆静态文件」**。下节课把 Ubuntu 服务器装起来，把 dist/ 传上去。

### 4.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-04 vite build + dist 分析               │
├────────────────────────────────────────────────┤
│  环境变量：                                    │
│   .env.development / .env.production           │
│   VITE_API_BASE_URL=/api                       │
│   VITE_APP_TITLE=印想瑜伽后台                  │
│   VITE_ 前缀是必须的                           │
│                                                │
│  vite.config.ts：                              │
│   base: '/'                                    │
│   build.sourcemap: false                       │
│   build.chunkSizeWarningLimit: 800             │
│   manualChunks:                                │
│     'vue-vendor':      ['vue','vue-router',    │
│                         'pinia']               │
│     'ele':             ['element-plus']        │
│     'echarts-vendor':  ['echarts']             │
│                                                │
│  dist/                                         │
│   ├─ index.html    Cache-Control: no-cache     │
│   └─ assets/                                   │
│      *-<hash>.js   Cache-Control: immutable    │
│      *-<hash>.css  同上                        │
│                                                │
│  🔴 index.html 不缓存 → 版本切换即时           │
│  🔴 assets 长缓存 → 二次访问秒开               │
└────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：把印想瑜伽项目 `pnpm build` + `pnpm preview`，交 Network 面板的**首次访问**与**二次刷新**两张截图对比 chunk 命中情况；
2. **必做**：写一份 `docs/build.md`——列出 chunk 大小、gzip 大小、首屏加载时间三项指标；
3. **挑战**：把 `element-plus` 的 icon 按需引入（`unplugin-icons` 或按需 import），让 `ele` chunk 从 620KB 降到 300KB 以内。

### 4.6 教学反思提示
- 学生看到 `pnpm build` 打包卡住 30 秒时会以为坏了——提前说明「Rollup 单线程，比 Vite dev 慢很多」；
- `sourcemap` 学生可能会主动想开着好调试——务必说明**生产不开的三个理由**：产物翻倍、暴露源码、上传 CDN 也没人真用；
- `base: '/'` 与子路径 `/admin/` 的区别是**部署时**才决定的——现在统一用 `/`，如果真需要子路径部署再改。

---

## 第 5 课时：Linux 基础 + SSH + JDK / MySQL / Nginx 安装

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能用 `ssh-keygen -t ed25519` 生成密钥对，用 `ssh-copy-id` 上传公钥实现免密登录；
2. 能配置 `~/.ssh/config` 定义 `Host yoga` 别名，一键 `ssh yoga` 连接；
3. 能用 `apt update && apt install` 装 OpenJDK 25、MySQL 8.0、Nginx 1.24；
4. 能用 `systemctl` 启停查状态：`sudo systemctl start / status / enable / restart nginx`；
5. 能用 `ufw` 放通 22 / 80 / 443 端口，并解释「云厂商安全组是第一道墙、ufw 是第二道墙」的分层设计。

#### 5.1.2 过程与方法目标
1. 通过「先密码登录一次 → 再密钥登录 → 再一键别名」的三级递进，让学生亲手体会「Linux 是可配置化生产力工具」；
2. 通过让学生**故意不开安全组**观察连接失败，训练「网络不通先看外层再看内层」的排查思维。

### 5.2 教学重难点
- **重点**：SSH 密钥对生成与上传（`ssh-keygen` / `ssh-copy-id` / `authorized_keys`）／`apt update` 与 `apt install` 的区别／`systemctl` 五件套（`start / stop / status / enable / restart`）／`ufw` 防火墙操作
- **难点**：为什么 `Port 22` 生产环境要改（防扫描）／SSH 私钥 `~/.ssh/id_ed25519` 权限必须 `600`——权限太开 SSH 客户端会拒绝使用／MySQL 8.0 装完 root 密码在 `/var/log/mysql/error.log` 里而不是随机弹出（Ubuntu 22.04 不同发行版行为不一）

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「昨天 `dist/` 打好了。今天要把它传到一台 Ubuntu 22.04 云服务器——先要能**登进去**、再要能**开 web 端口**、还要装 JDK 跑后端。」板书画**四层网络示意**：

```
自己电脑 ── ssh ──▶ 云服务商公网 IP:22
                        │
                        ▼
                云安全组（80/443/22）
                        │
                        ▼
                主机 ufw（80/443/22）
                        │
                        ▼
                Nginx :80 → 上游 Java :8080
```

#### 目标（2 分钟）
一句话：**「一台裸的 Ubuntu 22.04 变成能跑印想瑜伽项目的生产服务器」**。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 SSH 私钥权限必须 `600`
- 🔴 云安全组 ≠ ufw，两道都要开

#### 新知讲授（14 分钟）

1. **SSH 密钥登录**（4 分钟）：
   - 本地敲 `ssh-keygen -t ed25519 -C \"you@example.com\"`——生成 `~/.ssh/id_ed25519` 与 `id_ed25519.pub`；
   - `ssh-copy-id root@1.2.3.4`——把公钥追加到远端 `~/.ssh/authorized_keys`；
   - 关键点：远端 `~/.ssh` 目录权限 `700`、`authorized_keys` 权限 `600`——SSH 服务端权限检查很严，稍微开阔一点就拒绝登录；
   - 配 `~/.ssh/config`：`Host yoga / HostName 1.2.3.4 / User root / Port 22 / IdentityFile ~/.ssh/id_ed25519`，之后 `ssh yoga` 一键连。

2. **`apt` 装三大件**（4 分钟）：
   - `sudo apt update` 更新软件源索引（**不装任何东西**）；
   - `sudo apt install -y openjdk-25-jdk mysql-server nginx` 一行装齐；
   - 装完验证：`java -version`（应输出 openjdk 25）、`mysql --version`、`nginx -v`；
   - MySQL 8.0 首次装完可能没有 root 密码——`sudo mysql` 免密进；改密码 `ALTER USER 'root'@'localhost' IDENTIFIED BY 'yourpwd'`；
   - `sudo mysql_secure_installation` 走一遍安全加固（禁远程 root、删匿名用户、删 test 库）。

3. **`systemctl` + `ufw`**（6 分钟）：
   - `sudo systemctl start nginx`——启动；
   - `sudo systemctl enable nginx`——开机自启（一次即可）；
   - `sudo systemctl status nginx`——看运行状态、最近几行日志、PID；
   - `sudo journalctl -u nginx -f`——实时看 systemd 日志（等价于 `tail -f`）；
   - `sudo ufw allow 22/tcp && ufw allow 80/tcp && ufw allow 443/tcp && ufw enable`——放通三个必须端口再开防火墙；
   - **顺序很重要**：**必须先放 22 再 enable**，否则你会把自己踢出登录（板书画大红警告框）。

#### 课堂活动（15 分钟）

1. **示例演示：0 到能 `curl` 到 Nginx 欢迎页**（8 分钟）：
   - 讲师现场用一台阿里云试用 ECS（Ubuntu 22.04）；
   - `ssh-copy-id root@1.2.3.4` → 免密登录成功；
   - `sudo apt update && sudo apt install -y nginx openjdk-25-jdk mysql-server`；
   - `sudo systemctl start nginx && sudo ufw allow 22,80,443/tcp && sudo ufw enable`；
   - 本地浏览器打开 `http://1.2.3.4`——看到 Nginx 欢迎页；
   - **「10 条命令，一台裸机变 Web 服务器」**。

2. **反面演示：ufw 顺序错的惨案**（5 分钟）：
   - 讲师故意先 `ufw enable`（默认拒绝所有入站）再 `ufw allow 22`——SSH 会话已经断掉；
   - 只能通过云厂商控制台的**Web VNC** 进；
   - 讲师复现给学生看后**手工修复**：VNC 里 `sudo ufw allow 22/tcp` → 重连 SSH；
   - 板书写下永久规则：**「ufw enable 之前必须先放 22！」**。

3. **AI 生成对照**（2 分钟）：
   - 把「Ubuntu 22.04 一键装 JDK MySQL Nginx」丢给通义灵码；
   - AI 常见错误：① 用 `apt-get` 老命令（`apt` 更现代）；② 装 `default-jdk` 而不指定 25 版本；③ 忘 `apt update` 直接 install 会用旧索引；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「SSH 密钥进服务器 → apt 装三件套 → systemctl 起服务 → ufw 放端口」**。下节课把 Nginx 配置写完 + Jar 用 systemd 托管，项目正式上线。

### 5.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-05 Linux 基础 + SSH + 装机              │
├────────────────────────────────────────────────┤
│  SSH 密钥登录：                                │
│   ssh-keygen -t ed25519                        │
│   ssh-copy-id root@1.2.3.4                     │
│   ~/.ssh/config → Host yoga                    │
│                                                │
│  权限约定：                                    │
│   ~/.ssh              700                      │
│   ~/.ssh/id_ed25519   600                      │
│   ~/.ssh/authorized_  600                      │
│                                                │
│  apt 三件套：                                  │
│   sudo apt update                              │
│   sudo apt install -y openjdk-25-jdk           │
│                       mysql-server             │
│                       nginx                    │
│                                                │
│  systemctl 五件套：                            │
│   start / stop / status / restart / enable     │
│                                                │
│  ufw 顺序：                                    │
│   allow 22 → allow 80/443 → enable             │
│   🔴 先放 22 再 enable！                       │
│                                                │
│  两道墙：云安全组 + ufw                        │
└────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：申请一台阿里云 / 腾讯云试用服务器（Ubuntu 22.04），完成 SSH 密钥免密登录 + 三件套安装 + `curl http://<公网 IP>` 看到 Nginx 欢迎页，交 4 张截图；
2. **必做**：在服务器上创建 `deploy` 用户 + 加 sudo 组，禁用 root 密码登录（`PermitRootLogin prohibit-password`），交 `sshd_config` 差异；
3. **挑战**：写一份 `init-server.sh` 一键脚本——换 Ubuntu 阿里镜像源、装三件套、创建 deploy 用户、配置 ufw、设置时区 `Asia/Shanghai`。

### 5.6 教学反思提示
- 学生第一次登录云服务器几乎必踩「密码错误」——多半是安全组没开 22 端口，不是密码错；用 `ping` 与 `telnet 1.2.3.4 22` 先诊断连通性；
- MySQL 8.0 在不同 Ubuntu 版本里首次密码策略不一样（有的免密、有的随机密码在日志里）——务必现场看一次日志养成习惯；
- `apt install openjdk-25-jdk` 可能因为源不同版本号不同，学生可以用 `apt search openjdk` 找可用版本。

---

## 第 6 课时：Nginx 反向代理 + 静态部署 + Jar 后台 + systemd

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能写出 `/etc/nginx/conf.d/yoga.conf` 完整配置：`server` 段、`root` 静态资源、`try_files` SPA fallback、`location /api/` 反向代理、Gzip、长缓存；
2. 能理解 `proxy_pass http://backend/` 末尾斜杠对 `/api/` 前缀的影响——**带斜杠会剥除前缀**；
3. 能写出 `/etc/systemd/system/yoga.service` 单元文件，管理 Spring Boot Jar 的启停、开机自启、故障重启；
4. 能用 `rsync -avz --delete` 把本地 `dist/` 同步到服务器 `/opt/yoga/web/`，并解释 `--delete` 让**目标端与源端严格一致**；
5. 能写出 `deploy.sh` 一键脚本：`build → scp/rsync → systemctl restart → curl health check`。

#### 6.1.2 过程与方法目标
1. 通过「配置 Nginx → reload → curl 验证」的即时反馈循环，让学生亲手体会「Nginx 配置文件是活的、改完必测」；
2. 通过让 systemd 自动重启一次故意 `kill -9` 掉的 Jar 进程，训练「生产环境要有自愈能力」的可靠性观。

### 6.2 教学重难点
- **重点**：Nginx `server` 完整段（`listen 80` / `server_name` / `root` / `location`）／`try_files $uri $uri/ /index.html` 的 SPA 兜底／`proxy_pass` + `X-Forwarded-*` 头传递／`systemd` 服务单元四要素（`ExecStart / Restart / User / WorkingDirectory`）
- **难点**：为什么 `proxy_pass http://backend/` 与不带斜杠行为不同（**带斜杠 = 前缀替换**、不带 = 前缀保留）／`nginx -t` 语法检查通过 ≠ 运行正常（还要看 error.log）／systemd `Restart=on-failure` 与 `always` 的区别（前者只在退出码非 0 时重启，后者无条件）

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
「昨天 Nginx 欢迎页出来了。但**印想瑜伽后台**要的是：`https://yoga.example.com/` 看到我们的 Vue 页面、`/api/*` 转到后端 8080。今天把这两块拼起来。」板书画请求流：

```
浏览器 GET /              → Nginx → 返 index.html + dist/*
浏览器 GET /courses       → Nginx → try_files → 返 index.html（SPA fallback）
浏览器 GET /api/courses   → Nginx → proxy_pass → Java :8080
```

#### 目标（2 分钟）
一句话：**「Nginx 一份配置把静态与后端两条路径同时接管，systemd 让 Jar 挂了自己爬起来」**。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 `proxy_pass` 末尾**带不带斜杠**结果不同
- 🔴 `try_files` 顺序：文件 → 目录 → index.html

#### 新知讲授（14 分钟）

1. **Nginx `server` 完整段**（4 分钟）：
   - `/etc/nginx/conf.d/yoga.conf` 新建（**不改 `nginx.conf` 主文件**）；
   - `server { listen 80; server_name yoga.example.com; root /opt/yoga/web; index index.html; ... }`；
   - `location /` 用 `try_files $uri $uri/ /index.html`——**vue-router history 模式必备**：`/courses` 硬刷新会去请求文件 `/courses` 不存在，回落到 `index.html`；
   - `location ~* ^/assets/.+\.(js|css|png|jpg|svg|woff2?)$` 加 `expires 30d; add_header Cache-Control immutable`——**hash 文件名 + immutable = 缓存直接命中不校验**；
   - `location = /index.html` 强制 `no-cache`——**版本切换即时生效**。

2. **`location /api/` 反向代理**（4 分钟）：
   - `upstream yoga_backend { server 127.0.0.1:8080; keepalive 32; }`——上游池 + 长连接复用；
   - `location /api/ { proxy_pass http://yoga_backend/; ... }`——**末尾斜杠**！让 Nginx 把 `/api/courses` 剥前缀变 `/courses` 转给后端；
   - `proxy_set_header X-Real-IP $remote_addr`、`X-Forwarded-For $proxy_add_x_forwarded_for`、`X-Forwarded-Proto $scheme`——让后端能拿到**真实用户 IP** 与 HTTPS 状态；
   - 后端 `application-prod.yml` 配 `server.forward-headers-strategy: framed`——信任这些头。

3. **systemd 单元 + Gzip**（6 分钟）：
   - `/etc/systemd/system/yoga.service`：`[Unit] After=network.target` + `[Service] User=deploy WorkingDirectory=/opt/yoga/app ExecStart=/usr/bin/java -jar -Dspring.profiles.active=prod yoga-boot.jar Restart=on-failure RestartSec=5` + `[Install] WantedBy=multi-user.target`；
   - `sudo systemctl daemon-reload && sudo systemctl enable --now yoga`——重载配置 + 开机自启 + 立即启动；
   - `sudo journalctl -u yoga -f`——实时看后端日志；
   - Gzip：`gzip on; gzip_types text/plain text/css application/json application/javascript image/svg+xml; gzip_min_length 1k;`——JSON 与静态资源都压缩，节省 70% 带宽；
   - **Gzip 别忘加 `application/json`**——90% 的 AI 生成配置漏掉这行，API 响应不压缩。

#### 课堂活动（15 分钟）

1. **示例演示：完整部署闭环**（8 分钟）：
   - 本地：`pnpm build` → `dist/` 就绪；
   - `rsync -avz --delete dist/ yoga:/opt/yoga/web/`——上传前端；
   - `scp target/yoga-boot.jar yoga:/opt/yoga/app/`——上传后端 Jar；
   - 服务器：`sudo systemctl restart yoga`；
   - 本地：`curl -I http://<IP>/`——200 拿到 `index.html`；
   - 本地：`curl http://<IP>/api/courses` → 后端 JSON；
   - 浏览器：打开域名 → 登录 → 拿数据——**全流程通！**

2. **反面演示：`proxy_pass` 斜杠陷阱**（5 分钟）：
   - 故意把 `proxy_pass http://yoga_backend/;` 改成 `proxy_pass http://yoga_backend;`（去掉末尾斜杠）；
   - `sudo nginx -t && sudo systemctl reload nginx`；
   - `curl http://<IP>/api/courses`——后端 404（因为它收到的路径是 `/api/courses` 而不是 `/courses`）；
   - 后端日志 `journalctl -u yoga -f` 里能看到 404 记录；
   - 加回斜杠 → 正常。板书写下：**「proxy_pass 有无斜杠 = 前缀剥或不剥」**。

3. **systemd 自愈演示**（2 分钟）：
   - `ps aux | grep yoga-boot` 找到 PID；
   - `sudo kill -9 <pid>` 强杀；
   - 5 秒后 `sudo systemctl status yoga` 看到状态又是 `active (running)`——`Restart=on-failure` + `RestartSec=5` 自愈；
   - 学生鼓掌——**生产系统的可靠性起点**。

#### 小结（3 分钟）
一句话回顾：**「Nginx 一份配置接管静态与 /api → systemd 托管 Jar → deploy.sh 一键上线」**。至此从 Day01 到今天的项目**从零到线上**全流程走通。

### 6.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day15-06 Nginx + systemd + deploy.sh          │
├────────────────────────────────────────────────┤
│  server {                                      │
│    listen 80;                                  │
│    server_name yoga.example.com;               │
│    root  /opt/yoga/web;                        │
│    index index.html;                           │
│                                                │
│    location ~* ^/assets/.+ {                   │
│      expires 30d;                              │
│      Cache-Control immutable;                  │
│    }                                           │
│    location = /index.html { no-cache }         │
│    location /  { try_files $uri /index.html; } │
│    location /api/ {                            │
│      proxy_pass http://yoga_backend/;          │
│      X-Real-IP $remote_addr;                   │
│      X-Forwarded-For $proxy_add_x_forwarded_for│
│    }                                           │
│  }                                             │
│                                                │
│  systemd:                                      │
│    ExecStart=java -jar yoga-boot.jar           │
│    Restart=on-failure RestartSec=5             │
│                                                │
│  deploy.sh: build → rsync → restart → curl     │
│                                                │
│  🔴 proxy_pass 带斜杠 = 前缀剥                 │
│  🔴 Gzip 别忘 application/json                 │
└────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成印想瑜伽项目的**完整生产部署**，域名 / IP 交作业时一并提交，讲师课后随机抽查在线服务；
2. **必做**：写一份 `deploy.sh` 一键脚本（build → rsync → ssh restart → curl health check）交到 GitHub 项目 `scripts/` 目录；
3. **挑战**：给项目加 HTTPS——用 `certbot` 申请 Let's Encrypt 免费证书 + 强制 HTTP → HTTPS 跳转 + 加 HSTS 头 `Strict-Transport-Security`。

### 6.6 教学反思提示
- 学生 `nginx -t` 通过就直接 `systemctl reload nginx` 上线——务必强调**先 curl 验证再改 DNS**；
- `proxy_pass` 斜杠陷阱学生 90% 首次出错——一定要现场演示两种行为的差异；
- systemd `User=deploy` 会造成 Jar 无权读 `/opt/yoga/app/`——必须先 `chown -R deploy:deploy /opt/yoga` 再启动，学生第一次几乎必踩。

---

## Day15 总结

| 课时 | 主题 | 核心产出 |
|---|---|---|
| 第 1 课时 | 登录页开发（表单 + 验证码） | `LoginView.vue` + `authApi.captcha/login` 打通「拿 Token」 |
| 第 2 课时 | JWT 存储 + Axios 注入 + 401 拦截 | `stores/auth.ts` + `api/request.ts` 请求响应双拦截 |
| 第 3 课时 | 路由守卫 + 退出 + 不活跃自登出 | `router.beforeEach` 三段判断 + `v-perm` 按钮级权限 |
| 第 4 课时 | Vite build + dist 分析 | `manualChunks` 分包 + hash 长缓存 + `index.html` 不缓存 |
| 第 5 课时 | Linux 基础 + SSH + 装机 | 密钥登录 + `apt` 装 JDK/MySQL/Nginx + `ufw` 放通 |
| 第 6 课时 | Nginx 反代 + 静态 + systemd | 一份 Nginx 配置 + `yoga.service` + `deploy.sh` 一键上线 |

**Day15 之后**：印想瑜伽后台管理系统**从零到线上**全流程走通。学生手里有一个可以直接投简历的作品链接。后续 Day16 之后进入进阶（Docker 化、CI/CD、监控、灰度）。
