# 《AI 应用 Web 开发》 - 教师教案（Day03：Maven 依赖管理 + Spring Boot 入门）

**总课时：6 课时 × 45 分钟**
**授课对象：具备 Java 基础语法能力的大二/大三本科生（已完成 Day01/Day02，能熟练使用 IDEA 2024.3+ 与 JDK 25）**
**知识点覆盖：** 第 5 章 Maven 依赖管理 + 第 6 章 Spring Boot 入门与分层架构

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 全部案例围绕主线项目展开，Maven 坐标统一使用 `com.yinxiang:yoga-member`，Spring Boot 演示以 `/api/course/list` 返回瑜伽课程列表为主。

---

## 第 1 课时：Maven 介绍 + 安装配置 + 阿里云镜像

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能用自己的话说出 Maven 是什么、解决了什么问题（依赖下载、统一构建、分模块管理）；
2. 能说出 Maven 三大核心概念：POM / 坐标（GAV）/ 仓库；
3. 能在 Windows 环境下完成 Maven 3.9.x 的下载、解压、`MAVEN_HOME` 与 `Path` 环境变量配置；
4. 能修改 `settings.xml` 完成本地仓库路径和阿里云镜像配置，并用 `mvn -v` 验证安装成功。

#### 1.1.2 过程与方法目标
1. 通过"没有 Maven vs 有 Maven"的场景对比，让学生理解构建工具的必要性；
2. 通过命令行 `mvn -v` 与 `mvn help:effective-settings` 演示，学会自查配置。

### 1.2 教学重难点
- **重点**：Maven 三大核心概念（POM / GAV / 仓库）／`MAVEN_HOME` 环境变量配置／`settings.xml` 阿里云镜像
- **难点**：Windows 环境变量修改后不生效（未重启终端）／`localRepository` 路径包含中文或空格导致下载失败

### 1.3 教学过程设计（45 分钟）
#### 导入（5 分钟）
向学生提问：**"如果没有 Maven，你要在项目里用 MySQL 驱动、JSON 处理库、日志框架 3 个第三方库，你会怎么做？"** 随机抽 2 位同学回答，把答案写在板书左侧。若学生答"上官网下载 jar 放 lib"，正好引出 Maven 的价值。接着讲一个真实场景：一个中型项目有 40+ 个依赖，jar 包之间还会互相依赖，手动管理是灾难。

#### 新知讲授（18 分钟）
按三小节推进：

1. **Maven 是什么 + 解决什么问题**（6 分钟）：Maven 是 Apache 出品的 Java 项目**构建 + 依赖管理**工具。板书对比"没有 Maven 的日子（下载 jar、放 lib、比版本）"和"有 Maven 的日子（一行 `<dependency>` 搞定）"。强调 Maven 的三大定位：**依赖管理 + 构建自动化 + 项目标准化**。

2. **三大核心概念**（8 分钟）：板书画 POM/GAV/仓库的关系图。
   - **POM**（Project Object Model）：一个 `pom.xml` 文件描述整个项目——项目名、版本、依赖、构建方式；
   - **坐标（GAV）**：`groupId + artifactId + version`，三元组唯一定位一个库，是 Maven 世界的"身份证"；举例 `com.mysql:mysql-connector-j:8.3.0`；
   - **仓库**：本地仓库（默认 `~/.m2/repository/`）+ 远程仓库（中央仓库 / 阿里云镜像 / 私服 Nexus）。第一次构建时依赖从远程下载到本地，之后直接读本地。

3. **为什么要配阿里云镜像**（4 分钟）：中央仓库在国外，下载慢且经常超时。阿里云提供了国内镜像 `https://maven.aliyun.com/repository/public`，速度快，是国内开发必备。

#### 示例演示（12 分钟）
现场演示 Windows 下 Maven 安装全流程，学生同步操作：

1. **下载解压**：从 `https://maven.apache.org/download.cgi` 下载 `apache-maven-3.9.9-bin.zip`，解压到 `D:\dev\apache-maven-3.9.9`（**强调路径不能有中文、空格**）。

2. **配置环境变量**：右键"此电脑"→"属性"→"高级系统设置"→"环境变量"：
   - 新增 `MAVEN_HOME` = `D:\dev\apache-maven-3.9.9`
   - 编辑 `Path` → 追加 `%MAVEN_HOME%\bin`

3. **验证**：**关闭并重新打开** cmd/PowerShell，执行 `mvn -v`：
   ```bash
   mvn -v
   ```
   看到 `Apache Maven 3.9.9` 与 JDK 25 信息即成功。

4. **修改 `settings.xml`**：打开 `%MAVEN_HOME%\conf\settings.xml`：
   ```xml
   <localRepository>D:/mvn-repo</localRepository>

   <mirrors>
       <mirror>
           <id>aliyun-public</id>
           <mirrorOf>central</mirrorOf>
           <name>阿里云公共仓库</name>
           <url>https://maven.aliyun.com/repository/public</url>
       </mirror>
   </mirrors>
   ```
   现场提问学生："`<mirrorOf>central</mirrorOf>` 是什么意思？" 引导回答"替代中央仓库"。

5. **验证配置生效**：`mvn help:effective-settings`，在输出里找 `<localRepository>` 与 `<mirrors>` 段落，能看到阿里云地址即成功。

#### 课堂练习（7 分钟）
1. 学生独立完成 Maven 安装 + 阿里云镜像配置；
2. 执行 `mvn help:evaluate -Dexpression=settings.localRepository -q -DforceStdout`，把输出的路径截图上传；
3. 教师巡视，特别关注环境变量未重启终端就报"mvn 不是内部或外部命令"的学生。

#### 小结（3 分钟）
一句话总结：**Maven = POM + 坐标 + 仓库 + 阿里云镜像**。下一课时把 Maven 接入 IDEA，一起看第一个 Maven 项目长什么样。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  1. Maven 介绍 + 安装 + 阿里云镜像           │
├──────────────────────────────────────────────┤
│  Maven = 构建工具 + 依赖管理                 │
│                                              │
│  三大核心概念：                              │
│   POM  → pom.xml 描述项目                    │
│   GAV  → groupId:artifactId:version          │
│   仓库 → 本地 ~/.m2 + 远程（中央/阿里云）    │
│                                              │
│  安装 4 步：                                 │
│   ① 解压到无中文路径                         │
│   ② MAVEN_HOME + Path                        │
│   ③ mvn -v 验证                              │
│   ④ 改 settings.xml → 阿里云镜像             │
│                                              │
│  ⚠ 环境变量改完必须重启终端                  │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：截图 `mvn -v` 输出和 `settings.xml` 的 mirrors 段，命名 `day03-01-mvn.png`。
2. **必做**：在 `D:/mvn-repo` 下截图当前目录（此时应为空），第 2 课时新建项目后再截一张对比。
3. **挑战题**：查阅资料，在 `settings.xml` 里同时配置**阿里云 public 仓库**与**阿里云 spring 仓库**，思考 `<mirrorOf>` 的写法（提示：`central,spring`）。

### 1.6 教学反思提示
- 环境变量踩坑高发：Windows 家庭版部分学生找不到"高级系统设置"，可让他们用 `Win + R` → 输入 `sysdm.cpl` → "高级" → "环境变量"。
- 有学生的 `Path` 已经被拉得很长（超过 2048 字符），Windows 会截断——遇到必须帮学生把 `Path` 拆到"系统变量"和"用户变量"分开保存。
- 部分学生解压路径带了中文（例如 `D:\软件\maven`）会导致后续依赖下载失败，第 3 课时排错时如果出现 `NullPointerException` 类错误，先怀疑路径。

---

## 第 2 课时：Maven 与 IDEA 集成 + 坐标 GAV + 项目结构

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 能在 IDEA 2024.3 中把 Maven Home、User settings file、Local repository 三处指向自己安装的 Maven；
2. 能通过 IDEA 内置向导新建一个 Maven 项目，指定 groupId/artifactId/version；
3. 能识别 Maven 项目的**标准目录结构**（`src/main/java`、`src/main/resources`、`src/test/java`、`pom.xml`、`target/`）；
4. 能读懂并手写一个最小可用的 `pom.xml` 骨架。

#### 2.1.2 过程与方法目标
1. 通过"IDEA 全局设置 vs 项目级设置"的对比，理解 IDEA 每次新建项目都会用全局 Maven 配置；
2. 通过"新建 → 目录展开 → pom.xml 解读"的三步骤，建立完整的 Maven 项目心智模型。

### 2.2 教学重难点
- **重点**：IDEA 里 Maven 三处路径的配置／Maven 标准目录结构／`pom.xml` 骨架（GAV + properties + dependencies）
- **难点**：IDEA 默认会覆盖用 IDEA 自带的 Maven（Bundled）而不是学生装的那个——必须**勾选 Override** 手动指定；`packaging` 选 `jar` 还是 `war` 的区别

### 2.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
承接上节课："**上节课我们让 Maven 能在命令行跑起来，可实际开发我们并不常用命令行，而是用 IDEA。今天要让 IDEA 认识你自己装的 Maven。**"

#### 新知讲授（15 分钟）
1. **IDEA 中的 Maven 三处路径**（5 分钟）：板书画出 IDEA 配置面板结构，讲清三处的作用：
   - **Maven home path**：告诉 IDEA 用哪个 Maven 版本（默认 Bundled 3.x，我们要改到自己装的 3.9.9）；
   - **User settings file**：`settings.xml` 位置（决定用哪个镜像、本地仓库路径）；
   - **Local repository**：本地仓库路径（会自动从 `settings.xml` 读，也可 Override）。

2. **Maven 标准目录结构**（5 分钟）：板书画目录树，讲清每个目录的用途。特别强调"约定优于配置"——只要按标准放代码，Maven 就自动认识。

3. **`pom.xml` 骨架剖析**（5 分钟）：投影下面骨架，逐段讲：
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <project xmlns="http://maven.apache.org/POM/4.0.0">
       <modelVersion>4.0.0</modelVersion>

       <groupId>com.yinxiang</groupId>
       <artifactId>yoga-member</artifactId>
       <version>1.0-SNAPSHOT</version>
       <packaging>jar</packaging>

       <properties>
           <maven.compiler.source>25</maven.compiler.source>
           <maven.compiler.target>25</maven.compiler.target>
           <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
       </properties>

       <dependencies>
           <!-- 依赖在这里 -->
       </dependencies>
   </project>
   ```
   讲师提问："`<packaging>` 除了 `jar` 还能填什么？" 引出 `war`（Web 打包）、`pom`（父项目聚合）。

#### 示例演示（17 分钟）
现场做一遍，学生同步：

1. **IDEA 配置 Maven**（5 分钟）：`File → Settings → Build, Execution, Deployment → Build Tools → Maven`：
   - Maven home path：`D:/dev/apache-maven-3.9.9`
   - User settings file：`D:/dev/apache-maven-3.9.9/conf/settings.xml`，**勾选 Override**
   - Local repository：会自动读取变为 `D:/mvn-repo`

   点击 Apply。

2. **新建 Maven 项目**（5 分钟）：`File → New → Project → Maven Archetype`：
   - Name：`yoga-member`
   - Location：`D:/workspace/yoga-member`
   - JDK：25
   - Archetype：**留空**（不选任何 archetype，直接空模板最干净）
   - GroupId：`com.yinxiang`
   - ArtifactId：`yoga-member`
   - Version：`1.0-SNAPSHOT`

   点击 Create。IDEA 会自动创建目录 + `pom.xml`，同时触发下载。

3. **观察生成的项目结构**（4 分钟）：让学生打开左侧 Project 面板，展开：
   ```text
   yoga-member/
   ├── pom.xml
   ├── src/
   │   ├── main/
   │   │   ├── java/
   │   │   └── resources/
   │   └── test/
   │       ├── java/
   │       └── resources/
   └── target/         ← 第一次 build 后才有
   ```
   讲师提问："`src/main/resources` 和 `src/main/java` 有什么区别？" 引导：一个放 Java 源码，一个放配置文件（yml/properties/xml）。

4. **打开 `pom.xml` 边讲边看**（3 分钟）：让学生手动加一段 `<properties>` 配置 JDK 25 和 UTF-8，右键 → Maven → Reload Project，观察右下角进度条。

#### 课堂练习（7 分钟）
1. 学生独立完成 IDEA Maven 配置 + 新建 `yoga-member` 项目；
2. 手写一个 `App.java` 放到 `src/main/java/com/yinxiang/`，输出"Hello, yoga-member!"；
3. 右键 `App.java` → Run，验证能跑通。

#### 小结（3 分钟）
今天完成了两件事：**IDEA 认识了 Maven + 会新建标准 Maven 项目**。下一课时讲**依赖管理与冲突排查**——这是 Maven 真正的核心竞争力。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  2. IDEA 集成 Maven + GAV + 项目结构         │
├──────────────────────────────────────────────┤
│  IDEA 三处路径（勾 Override）：              │
│   ① Maven home path                          │
│   ② User settings file                       │
│   ③ Local repository（自动读）               │
│                                              │
│  新建项目 GAV：                              │
│   groupId: com.yinxiang                      │
│   artifactId: yoga-member                    │
│   version: 1.0-SNAPSHOT                      │
│   packaging: jar / war / pom                 │
│                                              │
│  标准目录：                                  │
│   src/main/java     ← Java 源码              │
│   src/main/resources ← 配置文件              │
│   src/test/java     ← 单元测试               │
│   target/           ← 编译产物               │
│                                              │
│  ⚠ IDEA Bundled Maven ≠ 你装的 3.9.9         │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：截图 IDEA Maven 三处路径配置，命名 `day03-02-idea-maven.png`。
2. **必做**：在 `yoga-member` 项目里手写 `App.java` 输出"Hello, 印想瑜伽!"，跑通并截图。
3. **挑战题**：让通义灵码生成一份最小 `pom.xml` 骨架（groupId=`com.yinxiang`、artifactId=`yoga-member`、JDK 25），对比自己手写的差异。

### 2.6 教学反思提示
- IDEA 首次 Reload Project 会下载 Maven 元数据到本地仓库，若网速慢容易被误认为"卡死"——提前提醒学生观察右下角进度条，不要中断。
- 部分学生新建项目时选了 `maven-archetype-quickstart` 会生成多余的 `App.java` 与 `AppTest.java`——本节讲义已明确选"空模板"，若已生成，让学生删掉重来或手动删除 archetype 生成物。

---

## 第 3 课时：Maven 依赖管理 + scope + 冲突 + 生命周期

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 能在 `mvnrepository.com` 查询坐标并粘贴到 `pom.xml`；
2. 掌握四种依赖 scope：`compile / test / provided / runtime` 及各自的典型代表；
3. 能识别**传递性依赖**，会用 `mvn dependency:tree` 查看依赖树；
4. 能用 `<exclusions>` 排除依赖，并解释 Maven 版本冲突的"短路径优先"原则；
5. 记住 Maven 生命周期 7 个阶段，能说出 `clean / compile / test / package / install` 各自的产物。

#### 3.1.2 过程与方法目标
1. 通过引入 `spring-boot-starter-web` 演示"1 个依赖带来 30+ 个 jar"的传递效应；
2. 通过故意制造版本冲突，让学生亲眼看到 `dependency:tree` 的输出与"短路径优先"。

### 3.2 教学重难点
- **重点**：4 种 scope 差异／`mvn dependency:tree`／`<exclusions>` 排除／生命周期 7 阶段
- **难点**：`provided` 和 `runtime` 的区别；版本冲突时如何决定用 `<exclusion>` 还是显式声明版本

### 3.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
展示一个真实场景截图："某项目引入了 A 库和 B 库，A 依赖 `guava:31.0`，B 依赖 `guava:20.0`，运行时抛 `NoSuchMethodError`。"提问：**"如果你遇到这种错，会怎么办？"** 引出本节课要教的排查方法。

#### 新知讲授（20 分钟）
1. **依赖坐标从哪里来**（3 分钟）：现场打开 `https://mvnrepository.com`，搜 `mysql-connector-j`，点第一个结果 → 复制 `<dependency>` 片段。演示"Usages 高的是常用版本"的挑选思路。

2. **4 种 scope**（6 分钟）：板书 4 行表格：

   | scope | 编译 | 测试 | 运行 | 打包 | 典型代表 |
   |-------|:---:|:---:|:---:|:---:|---------|
   | `compile`（默认） | ✅ | ✅ | ✅ | ✅ | 业务库、Spring |
   | `test` | ✕ | ✅ | ✕ | ✕ | JUnit、Mockito |
   | `provided` | ✅ | ✅ | ✕ | ✕ | servlet-api、Lombok（部分场景） |
   | `runtime` | ✕ | ✅ | ✅ | ✅ | JDBC 驱动 |

   讲师提问："JDBC 驱动为什么是 runtime？" 引导：编译期只需要 JDBC 接口（java.sql），运行时才需要具体驱动实现。

3. **传递性依赖 + 依赖树**（5 分钟）：在 `yoga-member/pom.xml` 添加：
   ```xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-web</artifactId>
       <version>4.0.0</version>
   </dependency>
   ```
   Reload 后执行：
   ```bash
   mvn dependency:tree
   ```
   投影 30+ 行依赖树，讲：**你没直接引入的 tomcat、jackson、spring-web 全都来了，这就是传递**。

4. **排除依赖 + 版本冲突**（6 分钟）：
   ```xml
   <dependency>
       <groupId>org.springframework.boot</groupId>
       <artifactId>spring-boot-starter-web</artifactId>
       <exclusions>
           <exclusion>
               <groupId>org.springframework.boot</groupId>
               <artifactId>spring-boot-starter-logging</artifactId>
           </exclusion>
       </exclusions>
   </dependency>
   ```
   **短路径原则**：同一个库出现多个版本时，Maven 采用①路径短的胜；②路径相同则声明顺序先者胜。可以在当前 `pom.xml` 显式声明版本进行"强制"。

#### 示例演示（15 分钟）
1. **生命周期演示**（5 分钟）：板书画阶段图，然后依次运行：
   ```bash
   mvn clean          # 删 target/
   mvn compile        # target/classes/
   mvn test           # 跑测试
   mvn package        # 生成 jar
   mvn install        # 安装到本地仓库
   ```
   讲："**后一个阶段会自动执行前面所有阶段**——所以你直接 `mvn install` 相当于跑了前面 5 步。"

2. **IDEA Maven 面板演示**（5 分钟）：右侧栏点开 Maven 图标 → Lifecycle → 双击 `clean` 和 `install`，展示等价于命令行。

3. **常用命令投影 5 分钟**：
   ```bash
   mvn dependency:tree            # 依赖树
   mvn dependency:analyze         # 冗余/未用依赖
   mvn -DskipTests package        # 跳过测试打包
   mvn -U clean package           # 强制刷新 SNAPSHOT
   ```

#### 课堂练习（5 分钟）
1. 学生在 `yoga-member` 里引入 `commons-lang3:3.14.0` 与 `mysql-connector-j:8.3.0`（`runtime`），Reload；
2. 执行 `mvn dependency:tree`，把输出粘到讲义课后作业区；
3. 故意再加一行 `<dependency>` 声明 `commons-lang3:3.12.0`，重新看依赖树，观察 Maven 选择哪个版本。

#### 小结（2 分钟）
Maven 三件套：**依赖 + 生命周期 + 命令**。掌握 6 条命令即可应付日常：`clean / compile / test / package / install / dependency:tree`。下一课时正式进入 **Spring Boot**。

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  3. 依赖管理 + 冲突 + 生命周期               │
├──────────────────────────────────────────────┤
│  scope 4 种：                                │
│   compile  ← 默认，全阶段可用                │
│   test     ← 只测试用（JUnit）               │
│   provided ← 编译测试用，运行由容器提供      │
│   runtime  ← 运行时用（JDBC 驱动）           │
│                                              │
│  依赖树：mvn dependency:tree                 │
│  排除：<exclusions><exclusion>...            │
│  冲突：短路径优先 → 声明顺序 → 显式版本      │
│                                              │
│  生命周期 7 阶段：                           │
│  validate → compile → test → package         │
│    → verify → install → deploy               │
│                                              │
│  6 条日常命令：                              │
│   clean / compile / test / package           │
│   install / dependency:tree                  │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：把 `mvn dependency:tree` 输出保存为 `day03-03-tree.txt` 并统计一共传递引入了多少个 jar。
2. **必做**：故意引入 `guava:31.0` 和 `guava:20.0`（一个直接、一个通过其他库间接），用依赖树观察 Maven 选了哪个版本，写 100 字说明。
3. **挑战题**：让通义灵码生成一段解释"为什么 `spring-boot-starter-web` 会带 Tomcat"的答案，与教材对照，指出 AI 有没有幻觉。

### 3.6 教学反思提示
- `mvn dependency:tree` 输出较长，投影字太小学生看不清——建议现场把字体调大或换成 IDEA 的 `Show Diagram` 图形化视图。
- `provided` 的应用场景在纯 Spring Boot 项目里学生短期用不到，可以只讲原理不深入，让学生记住"servlet-api 是 provided"这个典型例子即可。
- 部分学生问"`compile` 和 `runtime` 都会打包进 jar 有啥区别？"——答：`runtime` 编译时不放到 classpath，防止代码错误使用具体驱动 API。

---

## 第 4 课时：Spring Boot 介绍 + Web 入门（HelloController）

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能说出 Spring Boot 相对 Spring 的三大优势：约定优于配置 / 起步依赖 / 内嵌服务器；
2. 会用 IDEA 内置向导（Spring Initializr）创建 Spring Boot 4.0.0 项目；
3. 能读懂 `@SpringBootApplication` 启动类的作用；
4. 会写一个最简 `@RestController` + `@GetMapping`，跑通 `http://localhost:8080/hello`。

#### 4.1.2 过程与方法目标
1. 通过"传统 Spring 30 行 XML vs Spring Boot 3 行注解"的对比，直观感受生产力提升；
2. 通过"点击运行 → 浏览器访问"的 5 秒闭环，建立"Web 开发原来这么快"的正向反馈。

### 4.2 教学重难点
- **重点**：Spring Initializr 生成项目／`@SpringBootApplication` + `main` 方法／`@RestController` + `@GetMapping`
- **难点**：包结构必须让启动类在最外层（否则 `@ComponentScan` 扫不到子包的 Bean）；端口冲突时的处理

### 4.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
向学生展示两段代码截图对比：
- **左边**：传统 Spring MVC，`web.xml + spring-servlet.xml + spring-context.xml` 三个 XML，一屏都装不下；
- **右边**：Spring Boot，一个 `main()` 方法 + `@SpringBootApplication` + `@RestController` 就跑起来了。

讲师提问："**同样写一个 `/hello` 接口，你更愿意用哪种？**" 学生 100% 选右边——引出 Spring Boot 的价值。

#### 新知讲授（12 分钟）
1. **从 Spring 到 Spring Boot**（4 分钟）：
   - **Spring**：Java 企业开发的事实标准框架，但配置繁琐（XML 一大堆）；
   - **Spring Boot**：**约定优于配置**，帮你自动装配大量默认配置，`main` 方法即可启动 Web 服务。

2. **Spring Boot 四大特性**（4 分钟）：
   - **自动配置**：`@EnableAutoConfiguration`（隐藏在 `@SpringBootApplication` 里）；
   - **起步依赖**：`spring-boot-starter-*` 一键引入功能族（web/data-jpa/security/…）；
   - **内嵌服务器**：Tomcat/Jetty/Undertow，无需外部部署 war；
   - **生产就绪**：`Actuator` 提供指标、健康检查、监控端点。

3. **本课程版本基线**（4 分钟）：**Spring Boot 4.0.x + Java 25 + Maven 3.9+**。为什么选 4.0？—— 支持 JVM 25 新特性、JDK 17+ 强制、Jakarta EE 命名空间统一。

#### 示例演示（20 分钟）
现场做一遍完整入门，学生同步：

1. **用 IDEA 内置 Spring Initializr 生成项目**（5 分钟）：
   `File → New → Project → Spring Initializr`：
   - Name：`yoga-member`
   - Location：`D:/workspace/yoga-member`
   - Language：Java
   - Type：Maven
   - Group：`com.yinxiang`
   - Artifact：`yoga-member`
   - JDK：25
   - Java：25
   - Packaging：Jar
   - Spring Boot：4.0.0
   - Dependencies：**Spring Web、Lombok**

   点击 Create。IDEA 会调用 `start.spring.io` 生成骨架并自动 Reload。

2. **看生成的启动类**（3 分钟）：
   ```java
   package com.yinxiang.yogamember;

   import org.springframework.boot.SpringApplication;
   import org.springframework.boot.autoconfigure.SpringBootApplication;

   @SpringBootApplication
   public class YogaMemberApplication {
       public static void main(String[] args) {
           SpringApplication.run(YogaMemberApplication.class, args);
       }
   }
   ```
   讲师提问："`@SpringBootApplication` 里包含了哪三个注解？" 引导：`@Configuration + @EnableAutoConfiguration + @ComponentScan`（第 6 课时深挖）。

3. **写第一个 Controller**（5 分钟）：
   在 `com.yinxiang.yogamember.controller` 包下创建 `HelloController.java`：
   ```java
   package com.yinxiang.yogamember.controller;

   import org.springframework.web.bind.annotation.GetMapping;
   import org.springframework.web.bind.annotation.RestController;

   @RestController
   public class HelloController {

       @GetMapping("/hello")
       public String hello() {
           return "Hello, 印想瑜伽!";
       }
   }
   ```
   **注意**：`controller` 包必须是启动类所在包 `com.yinxiang.yogamember` 的**子包**，否则 `@ComponentScan` 扫不到。

4. **运行并访问**（3 分钟）：
   - 点击 `YogaMemberApplication` 类左侧绿色三角 → Run；
   - 控制台看到 `Started YogaMemberApplication in 1.234 seconds`；
   - 浏览器访问 `http://localhost:8080/hello` → 应看到 `Hello, 印想瑜伽!`。

5. **端口冲突处理演示**（4 分钟）：如果 8080 被占用会报 `Port 8080 was already in use`。解决办法：在 `src/main/resources/application.yml` 中改端口：
   ```yaml
   server:
     port: 9090
   ```
   重启，访问 `http://localhost:9090/hello`。

#### 课堂练习（7 分钟）
1. 学生独立完成 Spring Initializr 生成 + `HelloController` + 浏览器访问；
2. 再写一个 `/api/course/list` 接口，返回硬编码的瑜伽课程字符串："哈他瑜伽,阴瑜伽,阿斯汤加,流瑜伽"；
3. 教师巡视，确认每人浏览器都看到返回结果。

#### 小结（2 分钟）
今天完成 Spring Boot 第一个 Web 程序——**5 分钟从零到能用**，这就是它的魅力。下一课时讲**分层架构**，把这一坨代码拆到 Controller / Service / DAO 三层。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  4. Spring Boot 入门 + HelloController       │
├──────────────────────────────────────────────┤
│  Spring Boot 四大特性：                      │
│   ① 自动配置（@EnableAutoConfiguration）     │
│   ② 起步依赖（starter-*）                    │
│   ③ 内嵌 Tomcat                              │
│   ④ 生产就绪（Actuator）                     │
│                                              │
│  最小启动模板：                              │
│                                              │
│   @SpringBootApplication                     │
│   public class App {                         │
│     public static void main(String[] a) {    │
│       SpringApplication.run(App.class, a);   │
│     }                                        │
│   }                                          │
│                                              │
│   @RestController                            │
│   class HelloController {                    │
│     @GetMapping("/hello")                    │
│     String hello() { return "Hi"; }          │
│   }                                          │
│                                              │
│  ⚠ Controller 必须在启动类子包               │
│  ⚠ 8080 冲突改 server.port                   │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：跑通 `/hello` 和 `/api/course/list`，截图浏览器结果，命名 `day03-04-web.png`。
2. **必做**：把端口改成 8888，上下文路径改成 `/yoga`，访问 `http://localhost:8888/yoga/hello`。
3. **挑战题**：不使用 Spring Initializr，手写一个纯 `pom.xml` 引入 `spring-boot-starter-web:4.0.0`，看能否跑通同样效果。

### 4.6 教学反思提示
- Spring Initializr 若网速慢/走代理有异常，可让学生改用 `https://start.aliyun.com/`（阿里云镜像的 Initializr）。
- 学生把 `HelloController` 放到 `com.yinxiang.other` 包里，会遇到"404 Not Found"——排查思路：先看包名是否是启动类的子包。
- 部分学生 IDEA 版本 <2024.3 不支持 Spring Boot 4，可以让学生临时把 Spring Boot 版本降到 3.4.x 继续听课，课后再升级 IDEA。

---

## 第 5 课时：分层解耦 + Controller/Service/DAO + IOC/DI

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 能画出经典三层架构图：Controller（表现层）→ Service（业务层）→ Mapper/DAO（持久层）；
2. 能对应写出 `@RestController` / `@Service` / `@Mapper`（或 `@Repository`）三个层的最小代码；
3. 理解 **IOC**（控制反转）与 **DI**（依赖注入）的定义；
4. 会用**构造器注入**（推荐）、**字段注入**、**Setter 注入**三种方式，能说出为什么推荐构造器注入。

#### 5.1.2 过程与方法目标
1. 通过"全部塞 Controller"vs"分层"的对比，让学生感受"关注点分离"的价值；
2. 通过 Lombok 的 `@RequiredArgsConstructor` 演示，让代码从 8 行降到 3 行，感受实际项目的写法。

### 5.2 教学重难点
- **重点**：三层分工／`@Service` `@Mapper` `@RestController` 三个注解／构造器注入模式
- **难点**：为什么要"面向接口编程"（`UserService` 接口 + `UserServiceImpl`）；`@Autowired` 与 `@Resource` 的区别

### 5.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
展示反例：一段 200 行的 Controller，里面同时写了参数校验、SQL 拼接、业务判断、返回 JSON。提问：**"这段代码有什么问题？测试怎么测？改需求怎么改？"** 引导出"关注点分离"的必要性。

#### 新知讲授（20 分钟）
1. **为什么要分层**（4 分钟）：4 个痛点：
   - 一个改动波及全局（改 SQL 要碰 Controller）；
   - 测试无从下手（业务逻辑和 HTTP 混在一起）；
   - 无法复用（Service 逻辑要在 Controller 和定时任务里各写一遍）；
   - 团队协作困难（前端等接口、DBA 等 SQL、大家改同一个类）。

2. **经典三层**（8 分钟）：板书画三层图 + Spring 注解对应：
   ```
   ┌────────────────────┐
   │  Controller 表现层  │  ← @RestController / @Controller
   │  接收请求、返回响应  │
   └─────────┬──────────┘
             ↓
   ┌────────────────────┐
   │  Service 业务层     │  ← @Service
   │  业务规则、事务边界  │
   └─────────┬──────────┘
             ↓
   ┌────────────────────┐
   │  Mapper/DAO 持久层  │  ← @Mapper（MyBatis） / @Repository
   │  数据库访问         │
   └────────────────────┘
   ```
   **面向接口编程**：Service 层通常写成"接口 + 实现类"（`UserService` + `UserServiceImpl`），方便替换实现、方便单元测试用 Mock。

3. **IOC 与 DI**（8 分钟）：
   - **IOC**（Inversion of Control）：对象的**创建**交给 Spring 容器；
   - **DI**（Dependency Injection）：容器把依赖**送到**对象里。

   类比：从前你自己去菜市场买菜（`new`）；现在你告诉厨师你要吃什么，食材他会送到你面前。

   **三种注入方式**：
   ```java
   // ① 字段注入（简洁但难测试）
   @Autowired
   private UserMapper userMapper;

   // ② 构造器注入（✅ 推荐，Lombok 简化）
   @Service
   @RequiredArgsConstructor
   public class UserServiceImpl implements UserService {
       private final UserMapper userMapper;
   }

   // ③ Setter 注入
   @Autowired
   public void setUserMapper(UserMapper m) { this.userMapper = m; }
   ```
   讲师提问："`@Autowired` 与 `@Resource` 有什么区别？" 引导：`@Autowired` 按类型（Spring 注解）、`@Resource` 按名字（JSR-250 标准注解）。

#### 示例演示（15 分钟）
围绕主线项目做一个最小的三层示范——"查询瑜伽课程列表"：

1. **持久层**（3 分钟）：
   ```java
   package com.yinxiang.yogamember.mapper;

   import org.apache.ibatis.annotations.Mapper;
   import java.util.List;

   @Mapper
   public interface CourseMapper {
       List<String> findAll();
   }
   ```
   *（先用返回 `List<String>` 简化，第 4 天再讲实体类。真实项目会用 `List<Course>`。）*

2. **业务层接口 + 实现**（4 分钟）：
   ```java
   // 接口
   public interface CourseService {
       List<String> list();
   }

   // 实现
   @Service
   @RequiredArgsConstructor
   public class CourseServiceImpl implements CourseService {
       private final CourseMapper courseMapper;

       @Override
       public List<String> list() {
           // 暂时不连数据库，返回硬编码演示
           return List.of("哈他瑜伽", "阴瑜伽", "阿斯汤加", "流瑜伽");
       }
   }
   ```

3. **表现层**（3 分钟）：
   ```java
   @RestController
   @RequestMapping("/api/course")
   @RequiredArgsConstructor
   public class CourseController {
       private final CourseService courseService;

       @GetMapping("/list")
       public List<String> list() {
           return courseService.list();
       }
   }
   ```

4. **运行验证**（5 分钟）：重启 `YogaMemberApplication`，访问 `http://localhost:8080/api/course/list`，浏览器应返回 JSON 数组 `["哈他瑜伽","阴瑜伽","阿斯汤加","流瑜伽"]`。

   讲师追问："为什么返回的是 JSON 而不是字符串？" 引导：`@RestController = @Controller + @ResponseBody`，Jackson 自动把 `List` 序列化为 JSON。

#### 课堂练习（5 分钟）
1. 学生按三层结构完成 `/api/course/list` 接口；
2. 再补一个 `/api/course/count` 返回课程数量（int），要求走完整三层；
3. 教师巡视，特别关注学生是否漏了 `@Service` 或用了错误的 `new` 而不是注入。

#### 小结（2 分钟）
一句话：**Controller 只管接请求、Service 只管业务规则、Mapper 只管拿数据**。构造器注入 + Lombok 是行业标配。下一课时深挖 `@SpringBootApplication` 的启动原理。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  5. 分层解耦 + IOC/DI                        │
├──────────────────────────────────────────────┤
│  三层架构：                                  │
│   Controller (@RestController) 表现层        │
│           ↓                                  │
│   Service   (@Service)         业务层        │
│           ↓                                  │
│   Mapper    (@Mapper)          持久层        │
│                                              │
│  IOC = 容器创建对象                          │
│  DI  = 容器注入依赖                          │
│                                              │
│  三种注入：                                  │
│   ① 字段注入   @Autowired                    │
│   ② 构造器注入 @RequiredArgsConstructor ✅   │
│   ③ Setter 注入                              │
│                                              │
│  @Autowired 按类型 | @Resource 按名字        │
│                                              │
│  主线示例：/api/course/list                  │
│  Controller → Service → Mapper               │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 `/api/course/list` 三层结构，截图接口返回结果，命名 `day03-05-course.png`。
2. **必做**：再写一个 `/api/member/count` 接口（返回会员数量硬编码 128），走完整三层。
3. **挑战题**：让通义灵码生成 `Category`（id / name / code / createTime）的三层 CRUD 骨架（Controller + Service 接口 + Impl + Mapper 接口 + Entity），运行并访问 `/api/category` 的 GET 接口。

### 5.6 教学反思提示
- 学生最容易漏 `@Service` 或 `@Mapper` 注解 → 启动时报 `NoSuchBeanDefinitionException`。教他们先看错误日志"Consider defining a bean..."，就能定位到哪个类没加注解。
- 部分学生对"接口 + 实现类"抵触（觉得多余）——用一个例子说服：如果 Service 实现要改成"读缓存"版本，接口不变，替换实现类即可。
- 若时间紧，Mapper 可先用 `@Component` 实现类顶替（不连数据库），避免绕进 MyBatis 细节。

---

## 第 6 课时：Spring Boot 启动原理剖析（@SpringBootApplication + 自动装配）

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 能拆解 `@SpringBootApplication` 是三个注解的组合：`@SpringBootConfiguration + @EnableAutoConfiguration + @ComponentScan`；
2. 能画出 Spring Boot 启动流程 5 步：`main → SpringApplication.run → 创建上下文 → 加载自动配置 → 启动 Tomcat`；
3. 理解**自动装配**的核心机制：`META-INF/spring/*.imports` + `@ConditionalOnXxx`；
4. 能说出 `application.yml` 配置文件加载顺序和多环境（profile）切换方式。

#### 6.1.2 过程与方法目标
1. 通过 IDEA 里 Ctrl 点进 `@SpringBootApplication` 源码，让学生看到"注解叠注解"的组合真相；
2. 通过打开一个 `AutoConfiguration` 类看 `@ConditionalOnClass` 演示，理解"按需装配"。

### 6.2 教学重难点
- **重点**：`@SpringBootApplication` 三大注解拆解／启动 5 步流程／`application.yml` 与 profile
- **难点**：`@EnableAutoConfiguration` 背后的 `AutoConfiguration.imports` 加载机制；`@ConditionalOnXxx` 条件装配

### 6.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
提问：**"Spring Boot 为什么加个 `@SpringBootApplication` 就能自动跑起来？内嵌 Tomcat 谁启动的？我明明只写了一个 `main()`。"** 学生大多好奇但答不上来——今天揭开这层"魔法"。

#### 新知讲授（22 分钟）
1. **`@SpringBootApplication` 三大注解拆解**（8 分钟）：
   ```java
   @Target({ElementType.TYPE})
   @Retention(RetentionPolicy.RUNTIME)
   @Documented
   @Inherited
   @SpringBootConfiguration       // = @Configuration，声明这是配置类
   @EnableAutoConfiguration       // 打开自动装配开关
   @ComponentScan(...)            // 扫描当前包及子包的 @Component/@Service/...
   public @interface SpringBootApplication { ... }
   ```
   讲师提问："为什么 `@ComponentScan` 不需要写扫描路径？" 引导：默认从"启动类所在包"开始扫描——这就是为什么 Controller 要放启动类的子包。

2. **自动装配原理**（8 分钟）：投影 `@EnableAutoConfiguration` 源码，关注 `@Import(AutoConfigurationImportSelector.class)`。核心机制三步：
   - 启动时读取 `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports` 文件（Spring Boot 4 起，2.7 之前叫 `spring.factories`）；
   - 该文件里列出成百上千的 `xxxAutoConfiguration` 类；
   - 每个 `AutoConfiguration` 类头上有 `@ConditionalOnClass` / `@ConditionalOnProperty` / `@ConditionalOnMissingBean` 等条件——**只有类路径存在时才生效**。

   演示例子：`spring-boot-starter-web` 里有 `WebMvcAutoConfiguration`，头部有 `@ConditionalOnClass(Servlet.class)`——所以你引入 `starter-web` → 有 Servlet 类 → 条件成立 → 自动装配 Spring MVC + Tomcat。

3. **启动流程 5 步**（6 分钟）：板书画顺序图：
   ```
   ① main()
        ↓
   ② SpringApplication.run(App.class, args)
        ↓
   ③ 创建 ApplicationContext（IOC 容器）
        ↓
   ④ 加载自动配置类（AutoConfiguration.imports）
        ↓
   ⑤ 扫描 @Component 注册 Bean
        ↓
   ⑥ Web 项目 → 启动内嵌 Tomcat（默认 8080）
        ↓
   ⑦ 打印 "Started XXX in x.xxx seconds"
   ```

#### 示例演示（15 分钟）
1. **IDEA 内 Ctrl 点进源码**（5 分钟）：
   - Ctrl + 点 `@SpringBootApplication` → 展开看到 `@SpringBootConfiguration`、`@EnableAutoConfiguration`、`@ComponentScan`；
   - Ctrl + 点 `@EnableAutoConfiguration` → 看到 `@Import(AutoConfigurationImportSelector.class)`；
   - 打开 `spring-boot-autoconfigure-4.0.0.jar` → 在 `META-INF/spring/` 下找到 `AutoConfiguration.imports` 文件，滚动看几百行自动配置类清单。

2. **`application.yml` 完整配置**（5 分钟）：把 `application.properties` 删掉，新建 `application.yml`：
   ```yaml
   server:
     port: 8080
     servlet:
       context-path: /api

   spring:
     application:
       name: yoga-member
     profiles:
       active: dev

   logging:
     level:
       com.yinxiang: debug
   ```
   讲：**层级用缩进（2 空格）表示，比 properties 直观**。

3. **多环境 profile 演示**（5 分钟）：新建 `application-dev.yml` 和 `application-prod.yml`：
   ```yaml
   # application-dev.yml
   server:
     port: 8080

   # application-prod.yml
   server:
     port: 80
   ```
   在主 `application.yml` 中用 `spring.profiles.active: dev` 切换环境。启动时日志里会看到 `The following 1 profile is active: "dev"`。

#### 课堂练习（3 分钟）
1. 学生用 IDEA Ctrl 点进 `@SpringBootApplication`，找到三大注解并截图；
2. 在 `application.yml` 里改 `server.port=7777`，重启验证；
3. 添加 `application-dev.yml`、`application-prod.yml`，切换 `spring.profiles.active` 并观察日志。

#### 小结（2 分钟）
**`@SpringBootApplication` = 配置类 + 自动装配 + 组件扫描**。自动装配的秘密就在 `AutoConfiguration.imports` 加进类路径的一堆 `@ConditionalOnXxx` 配置类。至此 Day03 结束，你已经能：**从零建 Maven 项目 → 引入 Spring Boot → 分三层写业务 → 理解启动原理**。明天进入 MySQL + JDBC。

### 6.4 板书设计
```
┌──────────────────────────────────────────────┐
│  6. Spring Boot 启动原理                     │
├──────────────────────────────────────────────┤
│  @SpringBootApplication =                    │
│   ① @SpringBootConfiguration (=@Configuration)│
│   ② @EnableAutoConfiguration                 │
│   ③ @ComponentScan                           │
│                                              │
│  自动装配秘密：                              │
│  META-INF/spring/                            │
│    AutoConfiguration.imports                 │
│    ↓                                         │
│  xxxAutoConfiguration                        │
│    + @ConditionalOnClass                     │
│    + @ConditionalOnMissingBean               │
│                                              │
│  启动 5 步：                                 │
│   main → run → 创建 Context                  │
│   → 加载 AutoConfig → 扫 @Component          │
│   → 启动 Tomcat                              │
│                                              │
│  application.yml + profile：                 │
│   dev/prod 用 spring.profiles.active 切换    │
└──────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：Ctrl 点进 `@SpringBootApplication` 直到看到 `AutoConfigurationImportSelector`，截图并写 100 字理解。
2. **必做**：为 `yoga-member` 建立 dev/prod 两套配置，dev 端口 8080、prod 端口 80，切换验证。
3. **挑战题**：让通义灵码解释"Spring Boot 4.0 相对 3.x 在自动装配机制上有什么变化"，与官方 Release Notes 对照，指出 AI 是否有幻觉。

### 6.6 教学反思提示
- 讲原理时切忌全程读源码——只挑关键位置 Ctrl 点一层就退回来，避免学生迷失。
- `@ConditionalOnXxx` 家族有 10 多个，本节只展开 3 个：`@ConditionalOnClass`、`@ConditionalOnMissingBean`、`@ConditionalOnProperty` 即可，其余下学期讲。
- 部分学生会问"AutoConfiguration.imports 里有 200+ 类，全部装配不慢吗？"——答：**装配是懒加载 + 条件裁剪**，实际生效的只有几十个，不会有性能问题。
- 半天课结束时留 1—2 分钟做课程反馈：让学生说本 Day 最难的一个点，作为下次课的补充材料。

---

## 附录：Day03 主线项目 pom.xml 参考

供学生做完 Day03 后对照检查，位于 `yoga-member/pom.xml`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>4.0.0</version>
    </parent>

    <groupId>com.yinxiang</groupId>
    <artifactId>yoga-member</artifactId>
    <version>1.0-SNAPSHOT</version>
    <packaging>jar</packaging>

    <properties>
        <java.version>25</java.version>
        <maven.compiler.source>25</maven.compiler.source>
        <maven.compiler.target>25</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```

---

## 附录：Day03 整体教学时间轴

| 课时 | 主题 | 关键产出 |
|:---:|---|---|
| 1 | Maven 介绍 + 安装 + 阿里云镜像 | `mvn -v` 输出成功 + `settings.xml` 配好镜像 |
| 2 | IDEA 集成 Maven + GAV + 项目结构 | 新建 `yoga-member` 项目 + 手写 `pom.xml` |
| 3 | 依赖管理 + scope + 冲突 + 生命周期 | 会用 `mvn dependency:tree` |
| 4 | Spring Boot 介绍 + HelloController | 跑通 `/hello` |
| 5 | 分层解耦 + Controller/Service/Mapper + IOC/DI | 跑通 `/api/course/list` 三层 |
| 6 | Spring Boot 启动原理 | 拆解 `@SpringBootApplication` + profile 切换 |

**推荐练习平台**：本地 IDEA + 阿里云 Initializr（`https://start.aliyun.com/`）。
**AI 辅助**：全程可用通义灵码 / Trae 生成骨架代码，但**每段 AI 输出必须自己看懂后再粘贴**——本 Day 反复强调这一点。
