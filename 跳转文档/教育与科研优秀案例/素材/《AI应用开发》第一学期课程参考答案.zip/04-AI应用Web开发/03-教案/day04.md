# 《AI 应用 Web 开发》 - 教师教案（Day04：MySQL + MyBatis 首个 CRUD）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01—Day03 的大二/大三本科生（掌握 Java 基础语法、能熟练使用 IDEA 2024.3+、JDK 25，已跑通 Spring Boot 4.0 三层结构的 `/api/course/list`）**
**知识点覆盖：** 第 7 章 MySQL 数据库与 SQL 语言 + 第 8 章 MyBatis 持久层与首个 CRUD 接口

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 全部案例围绕主线项目展开，数据库统一使用 `yoga_member`，主线表为 `course`（瑜伽课程）、`member`（会员）、`coach`（教练）、`classroom`（教室）。MyBatis 首个 CRUD 案例以最简单的 `category`（课程科目：哈他 / 阿斯汤加 / 阴瑜伽 / 流瑜伽）表切入，第 5 课时升级到 `course` 全流程 CRUD。

---

## 第 1 课时：MySQL 安装与连接 + SQL 分类 + 数据库与表基本概念

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能用自己的话说出关系型数据库解决了什么问题（持久化、结构化、事务、索引、权限）；
2. 说出 MySQL 8.0 在 Java Web 开发中的地位与本课程版本基线（MySQL 8.0.x）；
3. 完成 MySQL 8.0 服务的验证（Windows 服务列表能看到 `MySQL80` 处于"正在运行"状态）；
4. 使用命令行 `mysql -uroot -p` 和图形化客户端（Navicat / DBeaver / DataGrip / IDEA Database 任选其一）成功连接到本地 3306；
5. 说出 SQL 四大分类 DDL / DML / DQL / DCL 各自的关键字和作用；
6. 会用 `show databases; create database ... default charset utf8mb4; use ...; show tables;` 完成"看库—建库—切库—看表"流程。

#### 1.1.2 过程与方法目标
1. 通过"没有数据库怎么活"的类比场景，让学生理解 RDBMS 的价值；
2. 通过命令行 → 图形化的双通道演示，让学生理解"图形化客户端只是给 MySQL 发 SQL 的壳子"，避免把 Navicat 当成数据库本身。

### 1.2 教学重难点
- **重点**：MySQL 服务的启动/连接／SQL 四大分类／`create database ... default charset utf8mb4;` 建库标准写法
- **难点**：字符集为什么必须 `utf8mb4` 而不是 `utf8`（`utf8` 是历史遗留的"伪三字节"）／端口 3306 被占用时如何排查（`netstat -ano | findstr 3306`）

### 1.3 教学过程设计（45 分钟）
#### 导入（5 分钟）
抽 1 位同学到黑板前提问：**"如果让你用 Excel 存 10 万条瑜伽会员数据，会遇到哪些痛点？"** 板书学生回答（预期：打开卡、多人不能同时改、并发覆盖、查找慢、崩溃即丢），教师随即在右侧写"数据库要解决的 5 件事：**持久化 / 结构化 / 事务 / 索引 / 权限**"，形成对照。口播："今天我们要认识的 MySQL，就是给这 5 个问题的一整套答案。"

#### 新知讲授（15 分钟）
按三小节推进：

1. **关系型数据库与 MySQL**（5 分钟）：板书画一张"三层结构图" —— 应用层（Java 程序）→ 数据库服务（MySQL Server，监听 3306）→ 数据文件（`.ibd`）。强调**MySQL 8.0 是本课程基线**（相对 5.7 支持更好的 JSON、CTE、窗口函数、`check` 约束真正生效）。投影演示"任务管理器 → 服务 → `MySQL80` 正在运行"。

2. **图形化客户端 4 选 1**（3 分钟）：投影对比表格，简述 Navicat（收费但界面友好）、DBeaver（免费全能）、DataGrip（JetBrains 家族、和 IDEA 一致）、IDEA 内置 Database（Ultimate）。**给学生的建议**：DBeaver 或 IDEA 内置 Database——免费、不需要额外账号。

3. **SQL 四大分类**（7 分钟）：板书画一张四象限表，讲师提问："`create table` 是哪一类？`select * from ...` 是哪一类？`update` 呢？`grant` 呢？" 抽 4 位同学各答一题。板书补齐：

   | 分类 | 全称 | 关键字 | 典型场景 |
   |------|------|--------|----------|
   | DDL | Data Definition Language | `create / drop / alter` | 建库、建表、改表 |
   | DML | Data Manipulation Language | `insert / update / delete` | 增改删数据 |
   | DQL | Data Query Language | `select` | 查询数据 |
   | DCL | Data Control Language | `grant / revoke` | 用户与权限 |

#### 示例演示（15 分钟）
投影演示"零到有"的连接全流程，学生同步操作：

1. **命令行登录**（3 分钟）：
   ```bash
   mysql -uroot -p
   ```
   回车输入密码 `123456`（练习环境）。看到 `mysql>` 提示符即成功。若报"不是内部或外部命令"，说明 MySQL bin 目录未加入 `Path`，现场演示补齐环境变量。

2. **命令行建库**（3 分钟）：
   ```sql
   show databases;
   create database yoga_member default charset utf8mb4;
   use yoga_member;
   show tables;
   ```
   讲师提问："`default charset utf8mb4` 里的 `mb4` 是什么意思？为什么不能只写 `utf8`？" 引导得到答案："MySQL 早期的 `utf8` 是伪三字节，`utf8mb4` 才是真正的 4 字节 UTF-8，能存 emoji 和生僻汉字。"

3. **DBeaver 连接演示**（5 分钟）：投影演示"新建连接 → MySQL → Host `localhost` / Port `3306` / User `root` / Password `123456` → Test Connection → 提示下载驱动 → 点 Download → 绿勾 → Finish"。左侧数据库树展开，找到刚才建的 `yoga_member` 库。

4. **命令行 vs 图形化写同一条 SQL**（4 分钟）：在图形化客户端里执行 `show databases;` 与命令行结果对比，强调**"图形化客户端 = 一个方便的 SQL 发射器 + 结果格式化器"**，本质仍是把 SQL 发给 3306。

#### 课堂练习（7 分钟）
1. 学生独立完成 MySQL 命令行登录 + `create database yoga_member default charset utf8mb4;`；
2. 在自选的图形化客户端里连接同一个数据库，看到 `yoga_member` 库；
3. 讲师提问："命令行建的库，为什么图形化客户端也能看到？" 引导回答"它们操作的是同一个 MySQL 服务，数据在服务端，客户端只是显示"。教师巡视，特别关注端口冲突、密码忘记、字符集写错的学生。

#### 小结（3 分钟）
一句话总结：**MySQL 服务在后台，客户端（命令行 or 图形化）发 SQL；四大分类 DDL/DML/DQL/DCL 是我们今后 3 课时的骨架**。下一课时正式进入 DDL，把瑜伽会馆的表建起来。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  1. MySQL 安装 + 连接 + SQL 四分类           │
├──────────────────────────────────────────────┤
│  RDBMS 5 件事：                              │
│   持久化 / 结构化 / 事务 / 索引 / 权限       │
│                                              │
│  三层结构：                                  │
│   Java 程序 → MySQL Server(3306) → .ibd 文件 │
│                                              │
│  图形化 4 选 1：                             │
│   Navicat / DBeaver / DataGrip / IDEA DB     │
│                                              │
│  SQL 四大分类：                              │
│   DDL create/drop/alter    改结构            │
│   DML insert/update/delete 改数据            │
│   DQL select               看数据            │
│   DCL grant/revoke         管权限            │
│                                              │
│  第一句 SQL：                                │
│   create database yoga_member                │
│   default charset utf8mb4;                   │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 MySQL 8.0 的连接（命令行 + 一款图形化客户端），在图形化客户端里截图"左侧数据库列表能看到 `yoga_member`"。
2. **必做**：把 `create database yoga_member default charset utf8mb4;` 这句 SQL 抄写 3 遍，能默写。
3. **挑战题**：查一查 MySQL 的 `utf8mb4_0900_ai_ci` 排序规则是什么意思，用 200 字总结 `ai` / `ci` / `bin` 三种后缀的区别。

### 1.6 教学反思提示
- Day04 是全课程数据库能力的起点，节奏别太快——只要"能连上"就已经达标；SQL 语法后 2 课时慢慢补。
- 有的学生装的是 MySQL 5.7 或 MySQL Community 8.4 preview 版本，出错风险高，建议课前统一发放 8.0.36 或 8.0.40 稳定版安装包。
- 出现连不上的常见原因排序：① 服务没启动 ② 密码错 ③ 端口 3306 被占用 ④ 防火墙。逐一排查即可。
- `utf8mb4` 的坑要反复强调，否则后面存中文瑜伽课程名会乱码，是最耗时的坑之一。

---

## 第 2 课时：DDL 建库建表 + 主线表设计（course / member）

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 掌握 `create table` 的完整语法：字段名 + 数据类型 + 约束 + 注释；
2. 说出 MySQL 常用数据类型 8 大类：`tinyint/int/bigint`、`float/double/decimal`、`varchar/char`、`text`、`date/datetime/timestamp`、`enum`；
3. 说出 5 大约束：`primary key / not null / unique / default / check`；理解外键在实际工程中"业务层保证 > 数据库层保证"的取舍；
4. 完成主线项目 4 张表的建表：`course`（课程）、`member`（会员）、`coach`（教练）、`classroom`（教室），全部字段带注释、字符集 `utf8mb4`；
5. 熟练使用 `alter table` 增/改/删字段和重命名表。

#### 2.1.2 过程与方法目标
1. 通过 AI 辅助生成建表 SQL → 自己审读修改 → 执行验证，训练"AI 出草稿、人做主"的工程习惯；
2. 通过 `desc course;` 反查表结构，验证 DDL 执行结果与设计的对应关系。

### 2.2 教学重难点
- **重点**：`create table` 语法四段式（字段 / 类型 / 约束 / 注释）／`decimal(10,2)` 用于金额场景／`datetime default current_timestamp on update current_timestamp` 自动维护时间
- **难点**：`char` vs `varchar` 的取舍（定长 vs 变长）／`decimal` vs `double`（金额场景必须 `decimal`）／`enum` 类型的坑（后续增值不便，工程实践中改用 `tinyint` + 注释）

### 2.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
投影展示 4 张纸质表格（会员登记表、课程价目表、教练花名册、教室排布图），提问："如果要把这 4 张纸变成数据库，你觉得每张表应该有哪些字段？" 讲师做小组随机抽签，让 4 组学生**每组只讲一张表的 3 个必备字段**（学生答会员必有姓名/电话/等级，课程必有名称/时长/价格……），把答案写在板书右侧作为伏笔。

#### 新知讲授（18 分钟）
1. **`create table` 语法**（6 分钟）：板书 4 段式模板：
   ```
   create table 表名 (
       字段名  数据类型  约束  comment '注释',
       ...
   ) comment '表注释';
   ```
   逐段解释。投影演示官方 `t_user` 建表模板（来自教材第 7 章）：
   ```sql
   create table t_user (
       id          bigint primary key auto_increment comment '主键',
       username    varchar(32)  not null unique       comment '用户名',
       password    varchar(64)  not null              comment '密码（加密）',
       gender      tinyint      default 0             comment '0男 1女',
       age         int          default 0,
       create_time datetime     default current_timestamp,
       update_time datetime     default current_timestamp on update current_timestamp
   ) comment '用户表';
   ```

2. **数据类型 8 大类**（6 分钟）：板书如下：

   | 类型族 | 常用成员 | 场景 |
   |---|---|---|
   | 整型 | `tinyint / int / bigint` | 状态位、年龄、主键 |
   | 浮点/精确 | `float / double / decimal(m,d)` | **金额必须 `decimal`** |
   | 字符串 | `varchar(n) / char(n) / text` | 名称/密码 hash/长文本 |
   | 日期时间 | `date / datetime / timestamp` | 生日/记录时间 |
   | 枚举 | `enum('a','b')` | 工程实践建议改用 `tinyint` |

3. **5 大约束**（4 分钟）：`primary key / not null / unique / default / check`。讲师口播："外键在教科书里必学，但工程里我们常常不加，而是在 Service 层保证——理由是删除、迁移、分库分表时外键会带来一堆麻烦。"

4. **`alter table` 三兄弟**（2 分钟）：
   ```sql
   alter table course add column tags varchar(200);
   alter table course modify column price decimal(10,2) not null;
   alter table course drop column tags;
   alter table course rename to yoga_course;
   ```

#### 示例演示（15 分钟）
现场演示主线 4 张表建表全过程，学生同步操作。**先在 DBeaver / IDEA Database 里 `use yoga_member;`**，然后依次执行：

1. **`course` 瑜伽课程表**（4 分钟）：
   ```sql
   create table course (
       id           int          primary key auto_increment comment '主键',
       name         varchar(50)  not null                 comment '课程名，如"哈他初级"',
       category_id  int                                   comment '课程科目 id',
       coach_id     int                                   comment '主教练 id',
       duration     int          default 60               comment '时长（分钟）',
       price        decimal(10,2) not null                comment '课程单价',
       image        varchar(300)                          comment '封面图 url',
       description  text                                  comment '课程简介',
       status       tinyint      default 1                comment '1上架 0下架',
       create_time  datetime     default current_timestamp,
       update_time  datetime     default current_timestamp on update current_timestamp
   ) comment '瑜伽课程表';
   ```

2. **`member` 会员表**（3 分钟）：
   ```sql
   create table member (
       id           int          primary key auto_increment,
       name         varchar(32)  not null                 comment '会员姓名',
       phone        varchar(11)  unique                   comment '手机号，登录用',
       gender       tinyint                               comment '1男 2女',
       birthday     date                                  comment '生日',
       level        tinyint      default 1                comment '1普通 2黄金 3钻石',
       balance      decimal(10,2) default 0.00            comment '会员卡余额',
       create_time  datetime     default current_timestamp,
       update_time  datetime     default current_timestamp on update current_timestamp
   ) comment '会员表';
   ```

3. **`coach` 教练表 + `classroom` 教室表**（4 分钟）：类似写法，快速带过（详见讲义完整代码）。讲师提问："`coach` 表和 `member` 表结构很像，能不能合成一张？" 引导讨论"合了看似省事，但业务上教练要发工资、会员要充值，未来字段分歧越来越大，不建议合"。

4. **`desc course;` 反查**（2 分钟）：在图形化客户端里执行 `desc course;`，看到字段列表、类型、约束、默认值，验证 DDL 执行成功。

5. **`alter table` 演示**（2 分钟）：现场给 `course` 加一个 `tags` 字段，再删掉——训练学生"表结构不是一次性写死"的思维。

#### 课堂练习（6 分钟）
1. 学生独立完成 4 张表建表；
2. 用 `show create table course;` 反查建表 SQL，与自己写的对比，教师巡视；
3. 抽 1 位同学到讲台上讲"为什么 `price` 用 `decimal(10,2)` 而不是 `double`"，其他人补充。

#### 小结（3 分钟）
一句话总结：**建表 = 字段 + 类型 + 约束 + 注释；金额用 `decimal`；时间自动维护用 `current_timestamp on update current_timestamp`**。下一课时把这 4 张空表填上数据、并学会怎么查。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  2. DDL 建表 + 主线 4 张表                    │
├──────────────────────────────────────────────┤
│  建表 4 段式：                               │
│   字段  类型  约束  comment                  │
│                                              │
│  数据类型 8 大类：                           │
│   整型：tinyint/int/bigint                   │
│   精确：decimal(m,d)  ← 金额必用             │
│   字符：varchar/char/text                    │
│   时间：date/datetime/timestamp              │
│                                              │
│  5 大约束：                                  │
│   PK / NOT NULL / UNIQUE / DEFAULT / CHECK   │
│                                              │
│  主线 4 表：                                 │
│   course    - 瑜伽课程                       │
│   member    - 会员                           │
│   coach     - 教练                           │
│   classroom - 教室                           │
│                                              │
│  alter 三兄弟：                              │
│   add / modify / drop  column                │
│                                              │
│  auto 时间：                                 │
│   datetime default current_timestamp         │
│           on update current_timestamp        │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成主线 4 张表（`course / member / coach / classroom`）建表，字段注释齐全，字符集 `utf8mb4`，截图 `desc course;` 结果。
2. **必做**：用 `alter table` 给 `course` 加一个 `tags varchar(200)` 字段，再删掉；截屏两次 `desc course;` 前后对比。
3. **挑战题**：让通义灵码/Trae 给你生成第 5 张表 `booking`（预约表：`id / member_id / course_id / classroom_id / book_time / status / create_time / update_time`），要求给出 3 个方案对比（外键 vs 无外键 vs 组合唯一索引），并解释你的选型理由，写 200 字。

### 2.6 教学反思提示
- 学生最爱犯的错：把 `varchar` 长度写得过大（如 `varchar(2000)` 存手机号），要现场纠正——数据类型是设计的一部分，不是"越大越好"。
- `decimal(10,2)` 的含义（总位 10、小数位 2）也是常错点：现场演示插入 `999999999.99` 成功、`9999999999.99` 报错的对比。
- 时间到位管理很关键：4 张表建表 15 分钟必须打住，超过就把 `classroom` 留到讲义自学，不影响主线。
- 有学生会问"为什么用 `int` 而不是 `bigint`"——回答：**主线练手够用；工业级 UGC 项目常用 `bigint`，本课程不纠结**。

---

## 第 3 课时：DML 与 DQL（插入/更新/删除 + 查询 + 条件 + 排序 + 分页 + 分组）

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 熟练使用 `insert / update / delete` 三条 DML，能写"指定列、全部列、批量插入"三种 insert；
2. 熟练使用 `select` 的六件套：**投影 / where / order by / limit / 聚合 / group by**；
3. 会用 `count / avg / max / min / sum` 5 大聚合函数；
4. 记住并会用**查询顺序口诀 S-F-W-G-H-O-L**（select → from → where → group by → having → order by → limit）；
5. 会用 `limit (page-1)*size, size` 公式实现分页。

#### 3.1.2 过程与方法目标
1. 通过"忘写 `where` 的血泪案例"，让学生形成"生产上写 update/delete 先套 begin/rollback 演练一遍"的习惯；
2. 通过让 AI 生成 100 条 mock 数据，训练"用 AI 造数据"的能力，避免"没数据没法练习"。

### 3.2 教学重难点
- **重点**：`update / delete` 必带 `where`（否则全表更新/删除）／`select` 六件套的书写顺序与执行顺序不同／分页公式
- **难点**：`where` 与 `having` 的区别（`where` 在分组前过滤行、`having` 在分组后过滤组）／`limit` 的参数顺序（起始偏移在前、数量在后）

### 3.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
讲师口播一段"运维事故"：**"某年某月某日，工程师执行 `update user set password = '123' where id = 1;` 时不小心多按了一次回车，`where` 没输入就 Enter，全站 300 万用户密码变成 `123`。第二天早晨老板亲自去机房拔电源。"** 引发笑声，随即引出："本节课学 DML 与 DQL，写完必看 `where`——这是本课时唯一必带回家的东西。"

#### 新知讲授（15 分钟）
1. **DML 三兄弟**（5 分钟）：投影三段代码，逐条讲解。

   ```sql
   -- 插入（指定列）
   insert into course(name, category_id, price)
   values('哈他初级', 1, 199.00);

   -- 批量
   insert into course(name, price) values
   ('阿斯汤加基础', 249.00),
   ('阴瑜伽入门',   199.00),
   ('流瑜伽进阶',   299.00);

   -- 更新
   update course set price = 259.00 where id = 1;

   -- 删除
   delete from course where id = 5;
   truncate table course;  -- 清空+重置自增，无法回滚
   ```

   讲师用红笔在板书上圈出所有 `where`，反复强调"没有 `where` 就是全表操作"。

2. **DQL 六件套**（8 分钟）：板书写下 6 步：
   ```
   select  <字段列表>       -- 投影
   from    <表>
   where   <行过滤>
   group by <分组>
   having  <组过滤>
   order by <排序>
   limit   <偏移, 数量>
   ```
   讲师提问抽 3 位学生依次答："查所有课程用哪一句？"、"查 200 元以上的课程用哪几句？"、"按价格降序查前 10 条用哪几句？"

3. **聚合函数 5 个**（2 分钟）：
   ```sql
   select
       count(*)   as total,
       avg(price) as avg_price,
       max(price) as max_price,
       min(price) as min_price,
       sum(price) as sum_price
   from course;
   ```

#### 示例演示（15 分钟）
围绕主线 `course / member` 表演示 6 类查询，学生同步执行：

1. **投影与条件**（3 分钟）：
   ```sql
   select id, name, price from course where price >= 200;
   select * from course where name like '哈他%';
   select * from member where phone is not null and gender = 2;
   ```

2. **排序与分页**（3 分钟）：
   ```sql
   select * from course order by price desc, create_time asc;
   select * from course order by price desc limit 0, 5;   -- 第 1 页 5 条
   select * from course order by price desc limit 5, 5;   -- 第 2 页 5 条
   ```
   讲师板书公式：`limit (page-1)*size, size`。

3. **聚合与分组**（4 分钟）：
   ```sql
   select category_id, count(*) as cnt, avg(price) as avg_price
   from course
   group by category_id
   having count(*) > 2
   order by cnt desc;
   ```
   投影演示后，讲师提问："这里 `where` 换成 `having` 有区别吗？为什么把 `count(*) > 2` 放 `having` 里而不是 `where`？" 引导学生答："`where` 在分组前执行，那时还没有 `count(*)` 这个东西。"

4. **AI 造 mock 数据**（3 分钟）：现场用通义灵码/Trae 生成 100 条 `insert into member ...` mock 数据（提示词见讲义），复制到 DBeaver 执行，然后学生就有真数据可查了。

5. **书写顺序 vs 执行顺序**（2 分钟）：板书两栏：
   ```
   书写顺序：S F W G H O L
   执行顺序：F W G H S O L
   ```
   讲师口播："**FROM 先来找到表，WHERE 立刻过滤行，GROUP BY 分组、HAVING 挑组、SELECT 投影字段、ORDER BY 排序、LIMIT 分页**。"

#### 课堂练习（9 分钟）
1. 学生在 `course` 表和 `member` 表上完成 5 条查询：
   - 查所有课程；
   - 查 200 元以上的课程，按价格降序；
   - 查会员总人数、平均余额、最大余额；
   - 按 `level` 分组统计会员数（`group by level`）；
   - 分页查第 2 页课程列表（每页 3 条）。
2. 讲师巡视，特别关注忘写 `where`、`limit` 参数顺序写反、`group by` 后 `select` 非分组字段的错误。
3. 抽 1 位同学讲第 4 题，其他人对答案。

#### 小结（3 分钟）
一句话总结：**DML 三兄弟必带 `where`；DQL 六件套书写顺序 S-F-W-G-H-O-L、执行顺序 F-W-G-H-S-O-L**。下一课时把这些 SQL 交给 Java 程序去执行——欢迎来到 MyBatis。

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  3. DML + DQL                                │
├──────────────────────────────────────────────┤
│  DML 三兄弟（必带 WHERE!）：                 │
│   insert into 表(列..) values(值..)          │
│   update  表 set 列=值 where ...             │
│   delete  from 表 where ...                  │
│                                              │
│  DQL 六件套（书写顺序 S-F-W-G-H-O-L）：      │
│   SELECT  字段                               │
│   FROM    表                                 │
│   WHERE   行过滤                             │
│   GROUP BY 分组                              │
│   HAVING  组过滤                             │
│   ORDER BY 排序                              │
│   LIMIT   偏移, 数量                         │
│                                              │
│  执行顺序 F-W-G-H-S-O-L                       │
│                                              │
│  聚合 5 兄弟：                               │
│   count / avg / max / min / sum              │
│                                              │
│  分页公式：                                  │
│   limit (page-1)*size, size                  │
│                                              │
│  警语：忘写 WHERE = 全表事故                 │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：在 `course` 表上完成 8 条查询：全查 / 单条件 / 多条件 / 模糊 / 分页 / 分组 / 聚合 / 排序，每条附截图。
2. **必做**：让通义灵码/Trae 生成 100 条 `member` 表 mock `insert` 数据（要求手机号唯一），执行后跑 `select count(*) from member;` 验证。
3. **挑战题**：写一条"每个会员等级的平均余额，按等级排序"的查询，然后思考"如果我想只显示平均余额 > 1000 的等级，应该用 `where` 还是 `having`？"，写 100 字解释。

### 3.6 教学反思提示
- 学生最容易混淆的是**书写顺序 vs 执行顺序**——出错时会觉得"SELECT 的别名怎么在 WHERE 里用不了"，正是因为 SELECT 在 WHERE 之后执行。可以现场演示这个报错，让学生记忆更深。
- `limit 5, 10` 的 5 是偏移不是页码，是新手第一个坑；建议现场写错一次让学生纠正。
- AI 造 mock 数据这一小节，若课堂网络不好，教师可提前把 100 条 SQL 备好；避免课堂卡在 AI 生成。
- 半天课结束前留 1—2 分钟做本课时反馈，问学生"关于 `where` / `having` 还想学什么"。

---

## 第 4 课时：MyBatis 介绍 + 入门程序（第一个 Mapper 接口）

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能说出 MyBatis 的定位——**半自动化 ORM 框架**（程序员写 SQL、框架做参数映射与结果封装）；
2. 说出 MyBatis vs Hibernate 的核心差异："半自动"的价值是 SQL 可控、性能可控；
3. 完成 Spring Boot 4 + MyBatis 3.5+ Starter 集成三件套：**pom 起步依赖 + application.yml + `@Mapper`**；
4. 写出第一个 Mapper 接口（`CategoryMapper#selectAll`），跑通"从 `category` 表查出全部记录"；
5. 会读 IDEA 控制台的 MyBatis SQL 日志（`log-impl: StdOutImpl`）。

#### 4.1.2 过程与方法目标
1. 通过对比"手写 JDBC 30 行 vs MyBatis 3 行"的代码量，让学生直观感受框架的价值；
2. 通过看日志中的 `Preparing / Parameters / Total`，理解 MyBatis "写 SQL + 参数占位 + 结果封装" 的三段式工作流。

### 4.2 教学重难点
- **重点**：MyBatis Starter 依赖坐标／`application.yml` 数据源与 MyBatis 三段配置／`@Mapper` 与 `map-underscore-to-camel-case` 的组合
- **难点**：`type-aliases-package` 的作用（让 XML 里的 `resultType` 可以直接写类名不用写全限定）／`mapper-locations` 的路径规则（`classpath:mapper/*.xml`）

### 4.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
讲师投影一段裸 JDBC 代码：`Class.forName → getConnection → prepareStatement → executeQuery → while(rs.next()){ … rs.getString("name") …} → close`，问学生："这段代码有 3 个痛点是什么？" 抽 2 位同学回答（预期：**代码冗长、结果封装麻烦、连接容易忘关**）。板书写："**MyBatis 就是替你解决这 3 件事的框架**"。

#### 新知讲授（15 分钟）
1. **MyBatis 是什么**（4 分钟）：定义 = **半自动化 ORM 框架**。板书对比：
   ```
   全自动 ORM（Hibernate）: 你写实体、框架帮你生成 SQL   —— SQL 不可控，复杂查询痛苦
   半自动 ORM（MyBatis）  : 你写 SQL、框架帮你映射参数和结果 —— SQL 全权在你手里
   ```
   国内 Java Web 主流选 MyBatis 是有原因的：SQL 可读可调优、DBA 也看得懂。

2. **集成三件套**（5 分钟）：板书画一张表：

   | 步骤 | 内容 |
   |---|---|
   | ① pom.xml | `mybatis-spring-boot-starter` + `mysql-connector-j` + `lombok` |
   | ② application.yml | `spring.datasource` + `mybatis.configuration/mapper-locations/type-aliases-package` |
   | ③ Mapper 接口 | 加 `@Mapper`，用 `@Select("...")` 写 SQL |

3. **MyBatis 3.5+ 与 Spring Boot 4 兼容**（3 分钟）：**关键版本**：`mybatis-spring-boot-starter:3.0.5+`（这是唯一兼容 Spring Boot 4 的版本线）。若沿用老坐标 `2.x`，Spring Boot 4 启动会报 `NoSuchMethodError`。讲师提问："为什么 MyBatis Spring Boot Starter 的版本是 3.x，但主体框架仍叫 MyBatis 3.5？" 引导得出：**Starter 版本号是 Spring Boot 集成层的版本，和 MyBatis 主体版本不一致，这在 Spring 生态很常见**。

4. **`map-underscore-to-camel-case` 与日志**（3 分钟）：投影演示这个配置项开启后，`create_time` 数据库字段自动映射到 `createTime` 实体属性；关闭则要写 `@Alias` 或 `resultMap`。日志用 `log-impl: StdOutImpl` 打印到控制台，方便调试。

#### 示例演示（20 分钟）
现场演示"第一个 MyBatis 程序"全流程，学生同步操作：

1. **前置：建 `category` 表 + 插 4 条数据**（3 分钟）：
   ```sql
   create table category (
       id          int primary key auto_increment,
       name        varchar(32) not null unique comment '科目名',
       code        varchar(32)                 comment '科目编码',
       create_time datetime default current_timestamp,
       update_time datetime default current_timestamp on update current_timestamp
   ) comment '课程科目表';

   insert into category(name, code) values
   ('哈他',   'HATHA'),
   ('阿斯汤加','ASHTANGA'),
   ('阴瑜伽',  'YIN'),
   ('流瑜伽',  'VINYASA');
   ```

2. **pom.xml 加依赖**（3 分钟）：
   ```xml
   <dependency>
       <groupId>org.mybatis.spring.boot</groupId>
       <artifactId>mybatis-spring-boot-starter</artifactId>
       <version>3.0.5</version>
   </dependency>
   <dependency>
       <groupId>com.mysql</groupId>
       <artifactId>mysql-connector-j</artifactId>
   </dependency>
   ```
   Reload Maven，等待下载。

3. **application.yml 配置**（3 分钟）：
   ```yaml
   spring:
     datasource:
       url: jdbc:mysql://localhost:3306/yoga_member?serverTimezone=Asia/Shanghai&useSSL=false
       username: root
       password: '123456'
       driver-class-name: com.mysql.cj.jdbc.Driver

   mybatis:
     configuration:
       map-underscore-to-camel-case: true
       log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
     mapper-locations: classpath:mapper/*.xml
     type-aliases-package: com.yinxiang.yogamember.pojo
   ```

4. **实体类 `Category`**（2 分钟）：
   ```java
   package com.yinxiang.yogamember.pojo;

   import lombok.Data;
   import java.time.LocalDateTime;

   @Data
   public class Category {
       private Integer id;
       private String name;
       private String code;
       private LocalDateTime createTime;
       private LocalDateTime updateTime;
   }
   ```

5. **第一个 Mapper 接口**（3 分钟）：
   ```java
   package com.yinxiang.yogamember.mapper;

   import com.yinxiang.yogamember.pojo.Category;
   import org.apache.ibatis.annotations.Mapper;
   import org.apache.ibatis.annotations.Select;
   import java.util.List;

   @Mapper
   public interface CategoryMapper {
       @Select("select * from category order by id")
       List<Category> selectAll();
   }
   ```

6. **写单元测试跑起来**（4 分钟）：
   ```java
   @SpringBootTest
   class CategoryMapperTest {
       @Autowired CategoryMapper categoryMapper;

       @Test
       void selectAll() {
           List<Category> list = categoryMapper.selectAll();
           list.forEach(System.out::println);
       }
   }
   ```
   跑测试，控制台看到 4 条数据 + SQL 日志（`Preparing / Parameters / Total: 4`），教师投影讲解每段日志的含义。

7. **常见问题现场排查**（2 分钟）：**故意漏 `@Mapper`** → 报 `NoSuchBeanDefinitionException`；**故意关掉驼峰映射** → 字段 `createTime` 变 `null`。让学生看错误 → 恢复配置 → 再跑，强化理解。

#### 课堂练习（5 分钟）
1. 学生独立完成 `Category` 实体 + `CategoryMapper#selectAll` + 单元测试全流程；
2. 抽 1 位同学讲"若日志里字段值全是 `null`，可能的原因是什么？" 期望答"驼峰映射没开"。

#### 小结（2 分钟）
一句话总结：**MyBatis 三件套（Starter + yml + `@Mapper`）已经打通，从这一课时起，Java 世界和 MySQL 世界正式握手**。下一课时把完整 CRUD 五件事（list / getById / insert / update / deleteById）都实现，并接到 Controller 上，跑通 REST 接口。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  4. MyBatis 介绍 + 入门程序                  │
├──────────────────────────────────────────────┤
│  定位：半自动化 ORM                          │
│   你写 SQL、框架映射参数与结果               │
│                                              │
│  Hibernate (全自动) vs MyBatis (半自动)      │
│                                              │
│  集成三件套：                                │
│   ① pom  mybatis-spring-boot-starter:3.0.5   │
│   ② yml  datasource + mybatis 3 段配置        │
│   ③ Mapper 接口 @Mapper + @Select            │
│                                              │
│  关键配置：                                  │
│   map-underscore-to-camel-case: true         │
│   log-impl: StdOutImpl                       │
│   mapper-locations: classpath:mapper/*.xml   │
│   type-aliases-package: ...pojo              │
│                                              │
│  第一 Mapper：                               │
│   @Select("select * from category")          │
│   List<Category> selectAll();                │
│                                              │
│  日志三段式：                                │
│   Preparing / Parameters / Total             │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 `category` 表 + `Category` 实体 + `CategoryMapper#selectAll` 全流程，控制台看到 SQL 日志 + 4 条数据。
2. **必做**：为 `CategoryMapper` 再加两个方法：`getById(Integer id)` 和 `getByCode(String code)`，用 `@Select` 注解写 SQL，写测试跑通。
3. **挑战题**：故意把 `map-underscore-to-camel-case` 改成 `false`，重新跑测试，观察日志字段值，思考并写 100 字解释为什么 `createTime` 变成了 `null`。

### 4.6 教学反思提示
- MyBatis 是本课程"从前端跳到后端持久层"的重要拐点，节奏要慢。**先跑通再讲原理**——第一课时先见到 4 条数据，再谈"怎么实现的"。
- Starter 版本坑：一定要用 `3.0.5+`，否则 Spring Boot 4 启动会报错。有的学生复制别人 Day03 项目的 pom 时会带来老版本，要提醒。
- 日志开着 `StdOutImpl` 会刷屏，如果学生嫌吵可以现场演示切换为 `log4j2` 或关掉，教一个"生产上一般用 Slf4j 加分级"。
- 学生问"Mapper 接口没有实现类，谁给它 new 出来的？"——回答：**MyBatis Starter 帮它做了动态代理，我们下一课时会展开**。

---

## 第 5 课时：MyBatis CRUD 完整实现（穿通 Controller / Service / Mapper / DB）

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 会用 MyBatis 注解方式实现 5 大方法：`list / getById / insert / update / deleteById`；
2. 掌握主键回填 `@Options(useGeneratedKeys=true, keyProperty="id")`；
3. 会用 `@Param` 处理多参方法；
4. 把 `CourseMapper` 接到 Service + Controller，跑通 `/api/course` 完整 REST 接口（GET/POST/PUT/DELETE）；
5. 会用 Apifox / Postman / IDEA HTTP Client 测试全套 CRUD 接口。

#### 5.1.2 过程与方法目标
1. 通过"从 Mapper 长到 Controller"的四层穿通演示，让学生把 Day03 学的三层结构和 Day04 的持久层对齐；
2. 通过 AI 一次性生成完整 CRUD 三层代码，训练"AI 出草稿、人做主"的工程习惯。

### 5.2 教学重难点
- **重点**：`@Insert / @Update / @Delete` 注解写法／主键回填 `@Options`／`@RequestBody` 收 JSON 体
- **难点**：`Invalid bound statement` 报错的定位（Mapper 接口方法名 vs XML/注解 SQL 不一致）／字段全是 `null`（驼峰未开）／JDBC url 中文乱码（`useUnicode=true&characterEncoding=utf8`）

### 5.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
抽 1 位同学到讲台，让他画 Day03 的三层结构图 —— Controller / Service / Mapper。**讲师在 Mapper 下面加一层"MySQL 数据库"**，口播："今天这堂课的目标就是把这四层完整穿透——你在 Postman 里点一次 POST，数据落到 MySQL 里；点一次 GET，数据从 MySQL 一路吐回浏览器。"

#### 新知讲授（12 分钟）
1. **注解 CRUD 5 兄弟**（6 分钟）：投影 `CourseMapper` 完整代码，逐条讲解：
   ```java
   @Mapper
   public interface CourseMapper {

       @Select("select * from course order by update_time desc")
       List<Course> list();

       @Select("select * from course where id = #{id}")
       Course getById(Integer id);

       @Insert("insert into course(name, category_id, coach_id, duration, price, image, description, status, create_time, update_time) " +
               "values(#{name}, #{categoryId}, #{coachId}, #{duration}, #{price}, #{image}, #{description}, #{status}, now(), now())")
       @Options(useGeneratedKeys = true, keyProperty = "id")
       void insert(Course course);

       @Update("update course set name=#{name}, category_id=#{categoryId}, coach_id=#{coachId}, " +
               "duration=#{duration}, price=#{price}, image=#{image}, description=#{description}, " +
               "status=#{status}, update_time=now() where id=#{id}")
       void update(Course course);

       @Delete("delete from course where id = #{id}")
       void deleteById(Integer id);
   }
   ```
   讲师重点解释 `#{name}` 是 MyBatis 的**参数占位符**，最终会生成 `?` 让 JDBC 预编译，防注入。

2. **主键回填**（3 分钟）：`@Options(useGeneratedKeys=true, keyProperty="id")` 让 `insert` 后 `course.getId()` 能拿到 MySQL 自增出来的主键。讲师提问："什么场景下需要主键回填？" 抽 1 位同学答（预期：**插入后立刻返回给前端**、**再关联插入子表**）。

3. **`@Param` 多参**（3 分钟）：
   ```java
   @Select("select * from course where category_id = #{cid} and status = #{status}")
   List<Course> listByCategoryAndStatus(@Param("cid") Integer categoryId,
                                        @Param("status") Integer status);
   ```
   讲师口播："**多个参数必须加 `@Param`，否则 MyBatis 只知道 `arg0/arg1`，SQL 里 `#{name}` 会找不到**。"

#### 示例演示（20 分钟）
现场演示 `/api/course` 完整穿通，学生同步操作：

1. **Mapper 层**（5 分钟）：把 `CourseMapper` 5 个方法完整写好（详见讲义）。

2. **Service 层**（4 分钟）：接口 + Impl，构造器注入（`@RequiredArgsConstructor`）：
   ```java
   public interface CourseService {
       List<Course> list();
       Course getById(Integer id);
       void save(Course course);
       void update(Course course);
       void deleteById(Integer id);
   }

   @Service
   @RequiredArgsConstructor
   public class CourseServiceImpl implements CourseService {
       private final CourseMapper courseMapper;

       public List<Course> list()              { return courseMapper.list(); }
       public Course getById(Integer id)       { return courseMapper.getById(id); }
       public void save(Course course)         { courseMapper.insert(course); }
       public void update(Course course)       { courseMapper.update(course); }
       public void deleteById(Integer id)      { courseMapper.deleteById(id); }
   }
   ```

3. **Controller 层**（5 分钟）：
   ```java
   @RestController
   @RequestMapping("/api/course")
   @RequiredArgsConstructor
   public class CourseController {
       private final CourseService courseService;

       @GetMapping           public List<Course> list()                       { return courseService.list(); }
       @GetMapping("/{id}")  public Course       get(@PathVariable Integer id){ return courseService.getById(id); }
       @PostMapping          public void         save(@RequestBody Course c)  { courseService.save(c); }
       @PutMapping           public void         update(@RequestBody Course c){ courseService.update(c); }
       @DeleteMapping("/{id}") public void       delete(@PathVariable Integer id){ courseService.deleteById(id); }
   }
   ```

4. **Postman / Apifox 全流程测试**（6 分钟）：
   ```
   GET    http://localhost:8080/api/course
   GET    http://localhost:8080/api/course/1
   POST   http://localhost:8080/api/course
     body: {"name":"高温 26 式","categoryId":1,"coachId":2,"duration":90,"price":399.00,"status":1}
   PUT    http://localhost:8080/api/course
     body: {"id":5,"name":"高温 26 式 · 改版","categoryId":1,"coachId":2,"duration":90,"price":459.00,"status":1}
   DELETE http://localhost:8080/api/course/5
   ```
   讲师投影每一步的请求/响应，特别演示 POST 后 `id` 主键回填、DELETE 后 GET list 少了一条。

#### 课堂练习（8 分钟）
1. 学生独立完成 `CourseMapper` 5 方法 + Service + Controller 全套，用 Postman 或 IDEA HTTP Client 完整测试；
2. 抽 1 位同学讲"POST 一次成功后，为什么响应里能看到 `id` 变化"，验证主键回填理解；
3. 教师巡视，特别关注 `Invalid bound statement` 报错（方法名不一致）、`Content-Type` 不是 `application/json`（POST 请求失败）。

#### 小结（2 分钟）
一句话总结：**MyBatis 注解 CRUD 5 兄弟（list/getById/insert/update/deleteById） + `@Options` 主键回填 = 完整 REST 接口 60 分线**。下一课时进入 XML 映射与动态 SQL，把"条件查询/批量删除"这些复杂需求解决。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  5. MyBatis CRUD 完整实现                    │
├──────────────────────────────────────────────┤
│  四层穿通：                                  │
│   Postman → Controller → Service             │
│           → Mapper → MySQL                   │
│                                              │
│  注解 CRUD 5 兄弟：                          │
│   @Select "select ..."                       │
│   @Insert "insert ..."                       │
│   @Update "update ..."                       │
│   @Delete "delete ..."                       │
│   + @Options(useGeneratedKeys, keyProperty)  │
│                                              │
│  参数占位：                                  │
│   单参 #{id}                                 │
│   多参 @Param("cid") + #{cid}                │
│                                              │
│  Controller 5 端点：                         │
│   GET  /api/course                           │
│   GET  /api/course/{id}                      │
│   POST /api/course (@RequestBody)            │
│   PUT  /api/course (@RequestBody)            │
│   DEL  /api/course/{id}                      │
│                                              │
│  常见报错：                                  │
│   Invalid bound statement                    │
│   字段全 null → 驼峰未开                     │
│   POST 400   → Content-Type 不对             │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 `CourseMapper` 5 方法 + Service + Controller，用 Postman 完整测试 5 个端点，每个端点截图。
2. **必做**：仿照 `Course` 的写法，为 `Coach` 表（`id, name, phone, level, intro, image, create_time, update_time`）实现完整 CRUD，暴露 `/api/coach` REST 接口。
3. **挑战题**：让通义灵码/Trae 一次性生成 `Member` 表的完整三层代码（4 个文件：`Member.java / MemberMapper.java / MemberService+Impl.java / MemberController.java`），你负责审读并修正 3 个不合理点（如：主键回填缺失、`@Mapper` 遗漏、`@RequestBody` 没写等），写 200 字复盘。

### 5.6 教学反思提示
- 这是 Day04 的**核心课时**，要保证学生课堂上就跑通至少 3 个端点（list / getById / insert），未跑通的下次一定要课后单独辅导。
- `@Insert` 里 SQL 太长时字符串拼接容易漏空格 —— 提醒学生每一段字符串结尾要留空格，或者干脆用文本块 `"""..."""`（Java 21+）。
- `@RequestBody` 和 Postman 的 `Content-Type: application/json` 是重灾区，讲师要主动示范一次错误：不加 `application/json` 会报 415，让学生印象深刻。
- 有学生问"为什么不用 @Autowired 而用 `@RequiredArgsConstructor`？"——回答：**构造器注入是 Spring 官方推荐，不可变、易测、无循环依赖风险**，这在 Day03 已讲过，此处只需巩固。

---

## 第 6 课时：XML 映射进阶（resultMap + `#{}` vs `${}` + 动态 SQL 初识）

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 会写标准 XML 映射文件（`<mapper namespace>` + `<select id resultType>`）；
2. 说清 Mapper 接口方法名与 XML `<select id>` 必须**同名**的原理；
3. 说清 `#{}` 与 `${}` 的差异：**`#{}` 预编译占位符（防注入）、`${}` 字符串拼接（不防注入）**；
4. 会用 `<resultMap>` 处理数据库字段与实体属性不一致的场景（不用驼峰映射也能应对特殊字段）；
5. 初识动态 SQL 三大标签：`<if>` / `<where>` / `<foreach>`，能写"条件查询"和"批量删除"两个典型场景。

#### 6.1.2 过程与方法目标
1. 通过 SQL 注入的现场演示（`or 1=1`），让学生"痛"一次，永远记住 `${}` 的风险；
2. 通过 `<where>` 智能剔除 `and/or` 的对比演示，理解框架为写 SQL 提供的"糖"。

### 6.2 教学重难点
- **重点**：XML 映射结构／`#{}` vs `${}`／`<if>` + `<where>` 组合／`<foreach>` 批量
- **难点**：`Invalid bound statement (not found)`（namespace 或 id 写错）／`<if test="name != null and name != ''">` 里的 `and` 是 OGNL 关键字而不是 SQL 的 `and`／`&gt;` `&lt;` XML 转义

### 6.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
讲师抛出一段"看起来正常"的 SQL："`select * from user where name = '${name}'`" —— 然后当学生把 `name` 传成 `' or '1'='1`，SQL 变成 `select * from user where name = '' or '1'='1'` 全表泄漏。板书写下"**`${}` = SQL 注入直通车**"，作为本课时最刺眼的教训。

#### 新知讲授（15 分钟）
1. **XML 映射结构**（4 分钟）：投影标准骨架：
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
       "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
   <mapper namespace="com.yinxiang.yogamember.mapper.CourseMapper">
       <select id="list" resultType="Course">
           select * from course order by update_time desc
       </select>
   </mapper>
   ```
   讲师提问："`namespace` 为什么必须是 Mapper 接口的**全限定类名**？" 引导答"这是 MyBatis 找到接口 → SQL 映射的桥梁"。

2. **`#{}` vs `${}`**（4 分钟）：板书画对比：
   ```
   #{} → 预编译占位符 = JDBC ? → 防 SQL 注入（99% 场景用这个）
   ${} → 字符串拼接    → 有注入风险，仅用于"表名/字段名/order by 方向"这种不能预编译的位置
   ```
   现场演示：用 `${}` 写 `where name = '${name}'`，传 `' or '1'='1` 全表返回；改成 `#{name}`，同样输入被安全转义。

3. **`<resultMap>`**（3 分钟）：当数据库字段和实体属性不能靠驼峰对应时（如 `nick_name_v2 → nickname`），用 `<resultMap>` 显式声明。投影一段小例子：
   ```xml
   <resultMap id="CourseMap" type="Course">
       <id     property="id"   column="id"/>
       <result property="name" column="course_name"/>
       <result property="price" column="course_price"/>
   </resultMap>
   ```

4. **动态 SQL 三大标签**（4 分钟）：
   - `<if>` 条件片段；
   - `<where>` 智能剔除首尾多余 `and/or`；
   - `<foreach>` 遍历集合，做 `in` 或批量插入；

   板书表格：

   | 标签 | 作用 | 场景 |
   |---|---|---|
   | `<if>` | 拼片段 | 有条件才拼 |
   | `<where>` | 智能 where | 去掉多余 `and/or` |
   | `<set>` | 智能 set | 去掉多余逗号（update） |
   | `<foreach>` | 遍历集合 | `in` / 批量 insert |
   | `<sql>/<include>` | 片段复用 | 通用字段列表 |

#### 示例演示（18 分钟）
围绕主线 `course` 表演示"条件查询 + 批量删除"两个典型场景，学生同步操作：

1. **建立 XML 映射文件**（3 分钟）：`src/main/resources/mapper/CourseMapper.xml`，写 `<mapper namespace>` 骨架 + `list` 兜底：
   ```xml
   <mapper namespace="com.yinxiang.yogamember.mapper.CourseMapper">
       <select id="list" resultType="Course">
           select * from course order by update_time desc
       </select>
   </mapper>
   ```
   在 `CourseMapper` 接口里删掉 `@Select("list")` 注解（**注解与 XML 同名会冲突，XML 优先，教材写"以 XML 为准"，工程实践建议二选一**）。

2. **`listByCondition` 条件查询**（6 分钟）：
   Mapper 接口：
   ```java
   List<Course> listByCondition(@Param("name") String name,
                                @Param("status") Integer status,
                                @Param("begin") LocalDate begin,
                                @Param("end") LocalDate end);
   ```
   XML：
   ```xml
   <select id="listByCondition" resultType="Course">
       select * from course
       <where>
           <if test="name != null and name != ''">
               and name like concat('%', #{name}, '%')
           </if>
           <if test="status != null">
               and status = #{status}
           </if>
           <if test="begin != null">
               and create_time &gt;= #{begin}
           </if>
           <if test="end != null">
               and create_time &lt;= #{end}
           </if>
       </where>
       order by update_time desc
   </select>
   ```
   讲师投影演示三次调用：全 null（返回全部）、只传 name（返回匹配）、传 name+status（组合）。看日志里 SQL 每次都不一样，理解"动态"二字。

3. **`deleteBatch` 批量删除**（4 分钟）：
   Mapper 接口：
   ```java
   void deleteBatch(@Param("ids") List<Integer> ids);
   ```
   XML：
   ```xml
   <delete id="deleteBatch">
       delete from course where id in
       <foreach collection="ids" item="id" open="(" close=")" separator=",">
           #{id}
       </foreach>
   </delete>
   ```
   讲师投影调用：`courseMapper.deleteBatch(List.of(3, 4, 5))`，日志里看到最终 SQL `delete from course where id in (3,4,5)`。

4. **注入现场演示**（3 分钟）：写一版故意用 `${}` 的错误代码：
   ```xml
   <select id="listByNameBad" resultType="Course">
       select * from course where name = '${name}'
   </select>
   ```
   传入 `' or '1'='1`，看到日志里最终 SQL 是 `where name = '' or '1'='1'`，全表返回。改成 `#{name}`，再传同样字符串，日志变成 `where name = ?` + 参数 `' or '1'='1`，安全。**这一步一定要让学生亲眼看到**。

5. **`&gt;` `&lt;` 转义**（2 分钟）：讲师板书："XML 里 `<` `>` 是标签边界符号，SQL 里的大于小于必须用 `&gt;` `&lt;` 转义，或者裹在 `<![CDATA[ ... ]]>` 里。"

#### 课堂练习（7 分钟）
1. 学生独立完成 `listByCondition` XML 与 `deleteBatch` XML，跑测试；
2. 抽 1 位同学讲"`${}` 与 `#{}` 的区别是什么？何时必须用 `${}`？" 期望答"`${}` 仅用于表名/字段名/order by 方向这种不能预编译的位置"；
3. 教师巡视，特别关注：namespace 写错（`Invalid bound statement`）、`&gt;` 写成 `>` 报 XML 解析错误。

#### 小结（2 分钟）
一句话总结：**XML 映射 = `<mapper namespace>` + `<select id resultType>`；`#{}` 防注入、`${}` 谨慎用；动态 SQL 三大件 `<if>/<where>/<foreach>` 覆盖 80% 场景**。整个 Day04 到此结束，你已经能独立写出一个"能连数据库、能 CRUD、能条件查询"的后端服务。

### 6.4 板书设计
```
┌──────────────────────────────────────────────┐
│  6. XML 映射进阶 + 动态 SQL 初识             │
├──────────────────────────────────────────────┤
│  XML 骨架：                                  │
│   <mapper namespace="接口全限定名">          │
│     <select id="方法名" resultType="Xxx">    │
│       ... SQL ...                            │
│     </select>                                │
│   </mapper>                                  │
│                                              │
│  #{} vs ${}：                                │
│   #{}  预编译 ? 防注入 → 值                  │
│   ${}  字符串拼接 有风险 → 仅表名/排序方向   │
│                                              │
│  动态 SQL 三大件：                           │
│   <if>     条件片段                          │
│   <where>  智能剔除首个 and/or               │
│   <foreach> 遍历集合 → in / 批量 insert       │
│                                              │
│  XML 转义：                                  │
│   >  →  &gt;                                 │
│   <  →  &lt;                                 │
│   或 <![CDATA[ ... ]]>                       │
│                                              │
│  警语：${} = SQL 注入直通车                  │
└──────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：为 `member` 表写 XML 版本的 `listByCondition`，支持"姓名模糊 + 等级 + 生日区间"三个可选条件，加上分页参数 `page/size`（用 `limit`）。
2. **必做**：写 `deleteBatch(List<Integer> ids)`，用 `<foreach>` 实现，在 Controller 暴露 `DELETE /api/course/batch?ids=1,2,3`。
3. **挑战题**：让通义灵码/Trae 给你解释"MyBatis 是怎么把 Mapper 接口和 XML 映射对应起来的"，然后自己在 IDEA 里 Ctrl 点进 `SqlSessionFactoryBean`，找到扫描 XML 的入口，截图并写 200 字复盘。

### 6.6 教学反思提示
- SQL 注入的现场演示效果非常好，学生会有明显情绪反应；一定要留 3 分钟做这个演示，比讲十遍原理都管用。
- 有的学生把 XML 和注解 SQL 同时写在一个方法上（既有 `@Select` 又有 XML `<select id>` 同名），会互相冲突。工程建议："**同一个 Mapper 里，简单 SQL 用注解，复杂 SQL 用 XML；不要一个方法两个地方都写**"。
- `<if test="...">` 里的 `and` `or` 是 OGNL 表达式关键字，不是 SQL 的 `and/or`——这个坑写第一次动态 SQL 一定会踩，讲师要预判并主动提。
- 半天课结束时留 2 分钟做 Day04 总反馈，问学生"接下来最想学什么"，收集反馈作为 Day05 起点。

---

## 附录：Day04 主线数据库 SQL 初始化脚本参考

供教师课前准备与学生对照。文件放在 `yoga-member/sql/init.sql`：

```sql
-- ===== 建库 =====
drop database if exists yoga_member;
create database yoga_member default charset utf8mb4;
use yoga_member;

-- ===== 课程科目 =====
create table category (
    id          int primary key auto_increment,
    name        varchar(32) not null unique,
    code        varchar(32),
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '课程科目';

insert into category(name, code) values
('哈他', 'HATHA'), ('阿斯汤加', 'ASHTANGA'),
('阴瑜伽', 'YIN'), ('流瑜伽', 'VINYASA');

-- ===== 教练 =====
create table coach (
    id          int primary key auto_increment,
    name        varchar(32) not null,
    phone       varchar(11) unique,
    level       tinyint default 1 comment '1初级 2中级 3高级',
    intro       text,
    image       varchar(300),
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '教练表';

-- ===== 教室 =====
create table classroom (
    id          int primary key auto_increment,
    name        varchar(32) not null unique,
    capacity    int default 20,
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '教室表';

-- ===== 课程 =====
create table course (
    id           int primary key auto_increment,
    name         varchar(50) not null,
    category_id  int,
    coach_id     int,
    duration     int default 60,
    price        decimal(10,2) not null,
    image        varchar(300),
    description  text,
    status       tinyint default 1,
    create_time  datetime default current_timestamp,
    update_time  datetime default current_timestamp on update current_timestamp
) comment '瑜伽课程表';

-- ===== 会员 =====
create table member (
    id          int primary key auto_increment,
    name        varchar(32) not null,
    phone       varchar(11) unique,
    gender      tinyint,
    birthday    date,
    level       tinyint default 1 comment '1普通 2黄金 3钻石',
    balance     decimal(10,2) default 0.00,
    create_time datetime default current_timestamp,
    update_time datetime default current_timestamp on update current_timestamp
) comment '会员表';
```

---

## 附录：Day04 整体教学时间轴

| 课时 | 主题 | 关键产出 |
|:---:|---|---|
| 1 | MySQL 安装 + 连接 + SQL 分类 | `create database yoga_member default charset utf8mb4;` 成功 |
| 2 | DDL 建表 + 主线 4 张表 | `course / member / coach / classroom` 4 张表全部建成 |
| 3 | DML + DQL 六件套 | 8 条查询全部写出、`limit` 分页公式熟练 |
| 4 | MyBatis 介绍 + 入门程序 | `CategoryMapper#selectAll` 跑通、看到 SQL 日志 |
| 5 | MyBatis CRUD 完整实现 | `/api/course` 5 个端点 Postman 全过 |
| 6 | XML 映射 + 动态 SQL 初识 | `listByCondition` + `deleteBatch` XML 全部跑通 |

---

## 附录：Day04 常见问题速查（教师备课用）

| 现象 | 定位与解决 |
|---|---|
| `Access denied for user 'root'@'localhost'` | 密码错，或大小写敏感；先命令行验证 |
| `Communications link failure` | MySQL 服务未启动 / 端口被占用 |
| 中文乱码 | 建库时缺 `utf8mb4`；JDBC url 加 `useUnicode=true&characterEncoding=utf8` |
| `Invalid bound statement (not found)` | Mapper 接口方法名与 XML `<select id>` 不同名 / namespace 写错 |
| 字段全 `null` | 忘开 `map-underscore-to-camel-case: true` |
| `BindingException: Parameter 'xxx' not found` | 多参未加 `@Param` |
| POST 415 Unsupported Media Type | Postman 未设置 `Content-Type: application/json` |
| SQL 注入 | 把 `${}` 改成 `#{}`；只在表名/排序方向这种不能预编译的位置用 `${}` |

---

## 附录：AI 辅助建库 + 三层代码提示词模板

**建库提示词（DDL）**：
```text
请为"印想瑜伽会馆客户管理系统"生成 MySQL 8.0 建库脚本，字符集 utf8mb4：
1. category（id, name unique, code, create_time, update_time）
2. coach（id, name, phone unique, level 1-3, intro, image, ...时间戳）
3. classroom（id, name unique, capacity, ...时间戳）
4. course（id, name, category_id, coach_id, duration, price decimal(10,2), image, description, status, ...时间戳）
5. member（id, name, phone unique, gender, birthday, level 1-3, balance, ...时间戳）
要求：主键自增、字段注释齐全、创建/更新时间自动维护。
```

**MyBatis 三层代码提示词**：
```text
使用 Spring Boot 4.0 + MyBatis 3.5+，为 yoga-member 项目的 course 表生成完整三层代码：
1. Entity 类 Course（Lombok @Data、LocalDateTime）
2. Mapper 接口（@Mapper，注解方式：list/getById/insert/update/deleteById，
   主键回填 @Options(useGeneratedKeys=true, keyProperty="id")）
3. Service 接口 + Impl（构造器注入，Lombok @RequiredArgsConstructor）
4. Controller（RESTful：/api/course，5 个标准端点 + @RequestBody）
```

拿到 AI 输出后必须自己审读 5 个点：`@Mapper` 是否加、`@Options` 是否加、`@RequestBody` 是否加、下划线转驼峰是否开、`Content-Type` 测试是否想清楚。
