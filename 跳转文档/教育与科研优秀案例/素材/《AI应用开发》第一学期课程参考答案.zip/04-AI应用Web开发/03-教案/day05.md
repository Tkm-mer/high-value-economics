# 《AI 应用 Web 开发》 - 教师教案（Day05：项目启动 + Git + Maven 分模块）

**总课时：6 课时 × 45 分钟**
**授课对象：具备 Java 基础语法能力的大二/大三本科生（已完成 Day01~Day04，能熟练使用 IDEA 2024.3+、JDK 25、Maven 3.9+、Spring Boot 4.0.x、MyBatis 基础）**
**知识点覆盖：** 第 9 章 项目启动与 Git 版本管理 + 第 10 章 Maven 分模块开发与项目基础搭建

**课程主线项目：印想瑜伽会馆客户管理系统（`yoga-member`）**
本 Day 是整个后端项目的**正式开跑日**：将前 4 天学到的 Java + Maven + Spring Boot + MyBatis 全部集成到一个真实工程里，用 Git 做版本管理，用 Maven 分模块做分层解耦，用 Knife4j 做接口文档。Maven 坐标统一使用 `com.yinxiang:yoga-member`，Gitee 仓库示例地址 `git@gitee.com:xxx/yoga-member.git`。

---

## 第 1 课时：项目需求分析 + 技术选型回顾 + 代码仓库规划

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 能用一句话说清《印想瑜伽会馆客户管理系统》的业务定位（会员/课程/预约/教练四大核心域）；
2. 能画出项目的整体技术栈图，包含 JDK 25、Spring Boot 4.0.x、MyBatis 3.0.x、MySQL 8.0、Maven 3.9+、Git 2.45+、通义灵码 + Trae；
3. 能说清"代码仓库 = 项目本体 + 版本历史 + 团队协作媒介"三重角色；
4. 能给出一份合理的代码仓库命名与目录规划：仓库名 `yoga-member`、Maven 坐标 `com.yinxiang:yoga-member`、Gitee 分组示例。

#### 1.1.2 过程与方法目标
1. 通过"需求 → 技术选型 → 仓库规划"三段式引导，让学生建立自顶向下的工程思维；
2. 通过与 Day03 单模块 Demo 的对比，感受"真项目"与"练习项目"的差别。

#### 1.1.3 情感态度价值观
- 建立"工程即产品"的意识：写代码不是自娱自乐，是要交付给用户的商品；
- 培养对**版本管理**的敬畏心：代码丢失、误删、误覆盖，都是职场血案。

### 1.2 教学重难点
- **重点**：主线项目业务域拆分（会员/课程/预约/教练）／技术栈版本基线／仓库命名与 GAV 约定
- **难点**：让学生真正理解"为什么要单独规划仓库"——不是随手 `git init` 就行，而是要考虑分组、命名、可见性、协作模式

### 1.3 教学过程设计（45 分钟）
#### 导入（5 分钟）
在黑板画一张\"从今天起，我们开始写一个真项目\"的口号板，提问学生：**\"过去 4 天你写的代码，明天还能找到吗？\"** 大多数学生会回答\"能，在 D 盘\"或\"不确定\"。接着追问：**\"如果 D 盘挂了呢？如果你和同桌一起改同一个文件呢？如果三个月后要回滚到上周版本呢？\"** 引出 Git 与规范化项目管理的必要性。

紧接着展示印想瑜伽会馆的一张假想业务图（用板书画会员到店、教练排课、前台预约的三个人形卡通），过渡到\"我们要为这家瑜伽馆做一个后台系统\"。

#### 新知讲授（20 分钟）

1. **项目定位与业务域**（7 分钟）
   板书写出四大核心业务域：
   - **会员管理**（Member）：手机号 + 会员卡类型 + 剩余次数 + 到期日
   - **课程管理**（Course）：课程分类 + 上课时间 + 教练 + 容量
   - **预约管理**（Reservation）：会员预约课程、签到、取消
   - **教练管理**（Coach）：教练基本信息 + 授课资质 + 排班

   强调本课程 Day05~Day10 以\"会员 + 课程分类 + 教练\"为主线，其他模块作为拓展作业。让学生看到\"业务边界决定了模块边界\"。

2. **技术栈回顾与选型说明**（8 分钟）
   板书写出完整技术栈表：

   | 层次 | 技术 | 版本 | 用途 |
   |---|---|---|---|
   | 语言 | Java | 25 | 主体开发语言 |
   | 构建 | Maven | 3.9+ | 依赖管理 + 分模块 |
   | 框架 | Spring Boot | 4.0.x | Web + IOC + 自动装配 |
   | 持久层 | MyBatis | 3.0.x | ORM |
   | 数据库 | MySQL | 8.0 | 数据存储 |
   | 版本控制 | Git | 2.45+ | 代码版本 |
   | IDE | IDEA | 2024.3+ | 开发环境 |
   | AI 辅助 | 通义灵码 + Trae | 最新 | 编码助手 |
   | 接口文档 | Knife4j | 4.5+ | Swagger 增强 |

   讲师提问：\"如果面试官问'你这个项目为什么用 Spring Boot 4 而不是 3.2？'你怎么答？\" 引导学生回答\"版本基线 + 团队规范 + 生态支持\"。

3. **代码仓库规划**（5 分钟）
   板书写出仓库命名规约：
   - 仓库名：`yoga-member`（**小写 + 连字符**，不要 `YogaMember` 或 `yoga_member`）
   - 平台：Gitee（国内速度快，也可选 GitHub）
   - 可见性：本课程用 **Private**，防止代码被抄袭；工作后按公司要求
   - 分组示例：`git@gitee.com:xxx/yoga-member.git`（`xxx` 为学生自己的 Gitee 用户名）
   - Maven 坐标：`com.yinxiang:yoga-member:1.0-SNAPSHOT`

#### 示例演示（12 分钟）
现场登录 Gitee 演示仓库创建全流程，学生同步操作：

1. **注册 / 登录 Gitee**（3 分钟）：<https://gitee.com>，若已有账号直接登录。
2. **新建仓库**（5 分钟）：右上角 `+` → \"新建仓库\"：
   - 仓库名：`yoga-member`
   - 归属：个人
   - 仓库介绍：\"印想瑜伽会馆客户管理系统 · AI 应用 Web 开发课程主线项目\"
   - 是否开源：**私有**
   - 分支模型：默认（master + 后期改造为 main）
   - **不要**勾选 \"使用 Readme 文件初始化仓库\"、\".gitignore\"、\"开源许可证\" —— 保持仓库为空，本地推送时更少冲突
   - 点击创建

3. **获取仓库 SSH 地址**（2 分钟）：仓库主页顶部切到 \"SSH\" 标签，复制形如 `git@gitee.com:xxx/yoga-member.git` 的地址。**强调不要复制 HTTPS 地址**——本课程统一走 SSH 免密。

4. **让 AI 生成仓库 README 初稿**（2 分钟）：打开通义灵码，输入提示词：
   ```text
   请为一个名为 yoga-member 的 Spring Boot 4.0 + MyBatis + MySQL 8.0 项目
   生成一份中文 README.md 骨架，包含：项目简介、技术栈、目录结构、启动方式、贡献指南 5 节。
   ```
   把 AI 输出粘到本地新建的 `README.md`，第 2 课时首次提交时一并入库。

#### 课堂练习（5 分钟）
1. 学生独立创建 Gitee 账号并新建 `yoga-member` 私有仓库；
2. 复制 SSH 地址到自己的记事本备用；
3. 让 AI 生成 README 初稿并保存到本地 `D:/workspace/yoga-member/README.md`（此时项目目录尚未初始化）。

#### 小结（3 分钟）
一句话总结：**Day05 目标 = 把 yoga-member 项目从零跑起来 + 用 Git 管起来 + 用 Maven 拆分成模块**。本节课定下了业务范围、技术栈、仓库地址，接下来 5 节课把它们逐个落地。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  1. 项目启动 + 需求分析 + 仓库规划           │
├──────────────────────────────────────────────┤
│  主线：印想瑜伽会馆客户管理系统              │
│  四大业务域：                                │
│   ① 会员 Member    ② 课程 Course             │
│   ③ 预约 Reserve   ④ 教练 Coach              │
│                                              │
│  技术栈基线：                                │
│   Java 25 + Spring Boot 4.0.x                │
│   Maven 3.9+ + MyBatis 3.0.x                 │
│   MySQL 8.0 + Git 2.45+                      │
│   IDEA 2024.3 + 通义灵码 + Trae              │
│                                              │
│  仓库规划：                                  │
│   名称：yoga-member（小写 + 连字符）         │
│   平台：Gitee 私有仓库                       │
│   地址：git@gitee.com:xxx/yoga-member.git    │
│   坐标：com.yinxiang:yoga-member:1.0-SNAPSHOT│
│                                              │
│  ⚠ 空仓创建：不要勾选 Readme/.gitignore      │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：在 Gitee 创建 `yoga-member` 私有仓库，截图仓库主页命名为 `day05-01-repo.png`；
2. **必做**：让通义灵码生成 `README.md` 初稿并保存到本地 `D:/workspace/yoga-member/`（此时目录先手动建）；
3. **挑战题**：查阅 GitHub 与 Gitee 的差异，用一张表列出：延迟、CI/CD 生态、可见性策略、私有仓限制。

### 1.6 教学反思提示
- 部分学生首次注册 Gitee 时会遇到手机号验证收不到短信——可提前告知备用邮箱验证途径；
- \"仓库归属\"下拉里如果学生加入过组织，会误选到组织下——一定要强调选择\"个人\"；
- \"不勾选 Readme 初始化\"是关键，否则第 3 课时 push 时会冲突，学生易慌张——本节要**反复强调 3 次**；
- 少数学生想用自己已有的仓库名（如 `yoga2024`）——允许，但后续教案里所有示例仍按 `yoga-member` 展示，让他们自行做名称替换。

---

## 第 2 课时：Git 介绍 + 本地仓库 + 基本工作流

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 能说清版本控制的三种形态：本地版本、集中式（SVN）、分布式（Git）；
2. 能画出并解释 Git 的三区模型：工作区 → 暂存区 → 本地仓库；
3. 熟练使用 `git init / status / add / commit / log / diff / restore / reset` 8 条本地命令；
4. 能在 Git Bash 完成 `user.name / user.email / init.defaultBranch` 全局配置，并用 `git config --list` 验证；
5. 能对 `yoga-member` 目录完成 `git init` 与首次 commit，并写出符合 Conventional Commits 的 message。

#### 2.1.2 过程与方法目标
1. 通过\"文件命名地狱\"（`代码_final_v2_老板要的版本.zip`）的段子引入版本控制的必要性；
2. 通过在同一个文件上做\"改 → status → add → status → commit → log\"的循环演示，让学生看清每一步区之间的状态迁移。

### 2.2 教学重难点
- **重点**：三区模型／`add / commit / log / diff` 四大基础命令／Conventional Commits 提交规范
- **难点**：`git restore` 与 `git reset` 的区别——一个撤销未提交的改动、一个回滚已提交的历史；`--staged` 参数的作用范围

### 2.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
展示一张截图：某电脑桌面有 `毕业设计.zip`、`毕业设计_修改版.zip`、`毕业设计_final.zip`、`毕业设计_final_真_final.zip`、`毕业设计_老师要的版本.zip` 五个文件。全班笑完之后，讲师提问：\"这是每一个没学过 Git 的大学生的宿命，你想以后也这样吗？\" 顺势引出 Git 是所有职业开发者的必备武器。

补充点一个反例：\"我在阿里做过一次故障复盘，某工程师本地改了 3 天的代码没提交，硬盘坏了——全没了。而他同桌只写了 30 分钟但每 5 分钟 commit 一次，硬盘坏了从远程 clone 回来还能继续。\"

#### 新知讲授（16 分钟）

1. **三种版本控制形态**（4 分钟）
   板书三张小图：
   - **本地版本**：`copy 项目 项目_v1`——最原始，缺点是无法多人协作、无法回溯细节；
   - **集中式（SVN）**：只有一个中央服务器有完整历史，客户端只有当前工作副本；断网不能提交；
   - **分布式（Git）**：**每个人本地都有完整历史**——即使中央仓挂了、断网了，本地仍可 commit、log、diff、branch，网络恢复后一次 push 即可同步。

   强调：**Git 的核心优势 = 分布式 + 快照 + 分支廉价**。

2. **三区模型**（6 分钟）
   板书画三个方框 + 三根箭头：
   ```
   工作区 --git add--> 暂存区 --git commit--> 本地仓库(HEAD)
                                              --git push--> 远程仓库
   ```
   - **工作区**：你 IDE 里打开、能看能改的文件；
   - **暂存区**（Index）：`git add` 之后候选提交的文件快照（一个中间篮子）；
   - **本地仓库**：`.git/` 目录里所有历史 commit 组成的时间线；
   - **远程仓库**（下节课再讲）：Gitee / GitHub 上的备份。

   讲师提问：\"为什么中间要一个暂存区？直接 add + commit 一步不好吗？\" 引导：因为你可能有 10 个改动，但只想把其中 6 个作为一次逻辑完整的提交——**暂存区就是让你精挑细选**的地方。

3. **8 条本地基础命令**（6 分钟）
   板书写命令清单：
   ```bash
   git init                              # 初始化仓库
   git config --global user.name  "Zhang San"
   git config --global user.email "zs@example.com"
   git config --global init.defaultBranch main

   git status                            # 看当前状态
   git add .                             # 全部暂存
   git add src/main/java/                # 部分暂存
   git commit -m "feat: xxx"             # 提交
   git log --oneline --graph             # 看历史
   git diff                              # 看工作区改动
   git diff --staged                     # 看暂存区改动
   git restore <file>                    # 撤销工作区改动
   git restore --staged <file>           # 撤销暂存
   git reset --hard HEAD^                # 回退到上一次提交
   ```

#### 示例演示（18 分钟）
以 `yoga-member` 目录为例，现场完整走一遍首次提交：

1. **全局配置**（2 分钟）：打开 Git Bash：
   ```bash
   git --version
   git config --global user.name  "Zhang San"
   git config --global user.email "zs@example.com"
   git config --global init.defaultBranch main
   git config --list | grep user
   ```

2. **初始化本地仓库**（3 分钟）：
   ```bash
   cd D:/workspace/yoga-member
   git init
   ls -a               # 看到隐藏的 .git 目录
   ```
   讲：**`.git/` 就是仓库本体，删除它 = 删除所有版本历史。永远不要手动改 `.git/`**。

3. **首次提交实况**（8 分钟）：手把手完成：
   ```bash
   git status                       # 看到 README.md untracked
   git add README.md
   git status                       # 看到 README.md 变绿（staged）
   git commit -m "chore: 项目初始化 README"
   git log --oneline
   ```
   接着改一下 README，再演示：
   ```bash
   # 改文件后
   git status                       # modified
   git diff                         # 看具体差异
   git add README.md
   git diff --staged                # 看暂存区差异
   git commit -m "docs: 完善技术栈说明"
   git log --oneline --graph
   ```

4. **撤销演示**（5 分钟）：故意再改一次 README（写一行乱码），然后：
   ```bash
   git status
   git restore README.md            # 撤销工作区改动
   cat README.md                    # 看到回到干净状态
   ```
   再演示 `--staged` 场景：
   ```bash
   echo "bad line" >> README.md
   git add README.md
   git restore --staged README.md   # 从暂存区撤出
   git restore README.md
   ```
   最后简单提及 `git reset --hard HEAD^`，**强调这是"删除历史"的命令，团队协作时慎用，个人练习可用**。

#### 课堂练习（5 分钟）
1. 学生完成 `git config --global` 三项配置，截图 `git config --list | grep user`；
2. 在 `yoga-member/` 下完成 `git init` + 首次 commit（README）；
3. 再改一次 README，做 `restore` 撤销练习并观察 `git status` 输出。

#### 小结（2 分钟）
一句话总结：**Git 三区模型是本节精华，`add / commit / log / diff / restore` 是每天要用 20 次的高频命令**。下一节课把本地仓库推到 Gitee 远程仓库，实现\"云端备份\"。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  2. Git 本地仓库 + 基本工作流                │
├──────────────────────────────────────────────┤
│  三种版本控制：                              │
│   本地拷贝（stone age）                      │
│   集中式 SVN（一个中央服务器）               │
│   分布式 Git（每人本地都是完整仓库）✅       │
│                                              │
│  三区模型：                                  │
│   工作区 --add--> 暂存区 --commit--> 本地库  │
│    ↑           ↑                    ↑        │
│    restore     restore --staged     reset    │
│                                              │
│  8 条本地命令：                              │
│   init / status / add / commit               │
│   log / diff / restore / reset               │
│                                              │
│  首次配置 3 件：                             │
│   user.name / user.email                     │
│   init.defaultBranch = main                  │
│                                              │
│  ⚠ .git/ 不能手动改；reset --hard 慎用       │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：截图 `git config --list | grep user`，命名 `day05-02-config.png`；
2. **必做**：在 `yoga-member/` 完成首次 commit，`git log --oneline` 输出至少 2 条记录，截图命名 `day05-02-log.png`；
3. **挑战题**：查阅 `git reflog`，理解为什么 `git reset --hard` 后 30 天内还能\"救回\"删除的提交。

### 2.6 教学反思提示
- 学生首次 `git init` 后如果没配 `init.defaultBranch main`，默认分支叫 `master`，第 3 课时 push 时会与远程 `main` 冲突——本节必须让学生**先配置再 init**；
- 部分学生用中文用户名的 Windows 账号，`~/.gitconfig` 路径含中文，可能触发编码问题——遇到再引导改用户名或改 `HOME` 环境变量；
- `git restore` 是 Git 2.23+ 引入的新命令，替代老的 `git checkout -- file`——课上强调只教 `restore`，别提 `checkout` 撤销，避免混淆；
- 有学生会问\"Windows 上是不是要装 TortoiseGit？\"——回答：**用 IDEA 内置 Git 已够，Git Bash 用于命令行学习，不推荐图形化 GUI 让基础更扎实**。

---

## 第 3 课时：远程仓库 + SSH 密钥 + push/pull/clone + .gitignore

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 能生成 ed25519 SSH 密钥对，并把公钥正确添加到 Gitee 的 SSH 公钥管理；
2. 能用 `ssh -T git@gitee.com` 验证 SSH 连接成功；
3. 熟练使用 `git remote add / push / pull / fetch / clone` 5 条远程命令；
4. 能编写覆盖 Java + Maven + IDEA + 敏感文件的 `.gitignore`，并理解已被追踪的文件不受 `.gitignore` 影响。

#### 3.1.2 过程与方法目标
1. 通过\"密码 vs 密钥\"的类比（进门刷卡 vs 报门牌号）让学生理解 SSH 免密的原理；
2. 通过故意先 commit 一个 `target/` 目录再补 `.gitignore` 的踩坑演示，让学生亲手体验\"已追踪文件不忽略\"的坑。

### 3.2 教学重难点
- **重点**：SSH 密钥生成与配置／`git remote add + push -u origin main` 首次推送三连／`.gitignore` 语法
- **难点**：Windows 上 `~/.ssh/` 目录的定位（`C:\\Users\\<用户名>\\.ssh\\`）；`.gitignore` 只对**未追踪**文件生效，已入库的要 `git rm --cached`

### 3.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
承接上节课：\"上节课我们让代码 commit 到本地——但只是在你自己的硬盘上，硬盘挂了照样丢。今天要把代码推到 Gitee 云端，实现真正的备份 + 让同学能 clone 下来做代码 review。\"

顺带发问：\"为什么要用 SSH 而不是 HTTPS？\" 简短回答：**SSH = 一次配置终身免密**，HTTPS 每次都要输账号密码（或 Token），非常烦。

#### 新知讲授（15 分钟）

1. **SSH 密钥原理**（4 分钟）
   板书画一张示意图：
   ```
   本机                             Gitee 服务器
   ┌──────┐                        ┌──────────┐
   │ 私钥 │  ─── 签名 ──────────►  │  用你上传的公钥  │
   │ pri  │                        │  验证签名 → 放行 │
   └──────┘                        └──────────┘
   ```
   - **私钥**：留在本地 `~/.ssh/id_ed25519`，**永不外传**；
   - **公钥**：`~/.ssh/id_ed25519.pub`，可以放到任何服务器上；
   - 服务器用公钥验证你提交的签名——**签名对得上 = 你就是你**，无需密码。

2. **`ssh-keygen` 生成密钥**（3 分钟）
   板书命令：
   ```bash
   ssh-keygen -t ed25519 -C "zs@example.com"
   # 一路回车（默认路径 + 空密码）
   cat ~/.ssh/id_ed25519.pub
   ```
   讲：**-t ed25519 是现代推荐算法**，比老的 RSA 更短更安全；**-C** 是注释（一般写邮箱，便于识别）。

3. **5 条远程命令**（5 分钟）
   板书写命令表：
   ```bash
   git remote add origin git@gitee.com:xxx/yoga-member.git
   git remote -v                    # 查看当前远程

   git push -u origin main          # 首次推送：-u 建立跟踪关系
   git push                         # 之后简化为一句 push

   git pull                         # 拉取并合并
   git fetch                        # 只拉取不合并（更安全）

   git clone git@gitee.com:xxx/yoga-member.git
   ```
   讲师提问：\"`push` 和 `pull` 谁先谁后？\" 引导：**协作时永远先 pull 再 push**，避免直接 push 被拒。

4. **`.gitignore`**（3 分钟）
   板书写常见忽略项：
   ```gitignore
   # Maven
   target/
   *.class

   # IDEA
   .idea/
   *.iml

   # Logs
   *.log
   logs/

   # OS
   .DS_Store
   Thumbs.db

   # Secrets
   application-local.yml
   ```
   讲师**重点提问**：\"如果我先 commit 了 `target/`，然后再加 `.gitignore`，还能忽略吗？\" 引导学生思考——答案是**不能**，因为已经被追踪。要用 `git rm --cached -r target/` 从索引移除。

#### 示例演示（20 分钟）

1. **生成 SSH 密钥并上传 Gitee**（6 分钟）：
   ```bash
   ssh-keygen -t ed25519 -C "zs@example.com"
   # 回车三次
   cat ~/.ssh/id_ed25519.pub
   ```
   把输出的整行 `ssh-ed25519 AAAA...` 复制。打开 Gitee → 右上角头像 → \"设置\" → \"SSH 公钥\" → 粘贴 → 标题填 \"yoga-dev-pc\" → 添加。

   验证：
   ```bash
   ssh -T git@gitee.com
   ```
   看到 `Hi 用户名! You've successfully authenticated...` 即成功。

2. **关联远程并首次推送**（6 分钟）：回到 `yoga-member/`：
   ```bash
   cd D:/workspace/yoga-member
   git remote -v                          # 空
   git remote add origin git@gitee.com:xxx/yoga-member.git
   git remote -v                          # 看到 origin
   git branch                             # 看到 main
   git push -u origin main
   ```
   刷新 Gitee 网页，能看到 README.md 出现。

3. **`.gitignore` 实操 + 踩坑还原**（5 分钟）：
   ```bash
   # 故意先编译一下产生 target 目录
   mvn compile                            # 假设第 5 课时后才做，这里可用 mkdir 模拟
   # 或
   mkdir target && echo "class content" > target/Foo.class

   git status                             # 看到 target/ 未追踪
   ```
   **故意错误示范**：先 add 再补 gitignore：
   ```bash
   git add .
   git commit -m "wip: 演示错误示范"
   # 现在补 .gitignore
   echo "target/" > .gitignore
   git status                             # 会发现 target/ 仍在追踪
   git rm --cached -r target/             # 从索引移除，磁盘保留
   git add .gitignore
   git commit -m "chore: 补 .gitignore 忽略 target 目录"
   ```

4. **`clone` 验证**（3 分钟）：在另一个目录：
   ```bash
   cd D:/tmp
   git clone git@gitee.com:xxx/yoga-member.git yoga-clone
   cd yoga-clone && ls
   ```
   看到 README.md、`.gitignore` 已经在远程仓库里。**强调 clone 会自动完成 remote 关联和分支跟踪**。

#### 课堂练习（5 分钟）
1. 完成 SSH 密钥生成 + 上传 Gitee + `ssh -T` 验证；
2. 完成 `remote add + push -u origin main` 首次推送；
3. 补齐 `.gitignore` 并再推一次，Gitee 网页刷新验证。

#### 小结（2 分钟）
一句话总结：**SSH 免密 + push/pull 五连击 + .gitignore 是团队开发的三张通行证**。下一节课讲**分支**——真正的团队协作从分支开始。

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  3. 远程仓库 + SSH + push/pull + .gitignore  │
├──────────────────────────────────────────────┤
│  SSH 密钥原理：                              │
│   本地私钥（不外传）+ 服务器公钥             │
│   ssh-keygen -t ed25519 -C "邮箱"            │
│   cat ~/.ssh/id_ed25519.pub → Gitee 粘贴     │
│   ssh -T git@gitee.com 验证                  │
│                                              │
│  5 条远程命令：                              │
│   remote add origin <ssh>                    │
│   push -u origin main（首次带 -u）           │
│   push / pull / fetch / clone                │
│                                              │
│  .gitignore 常客：                           │
│   target/  .idea/  *.iml  *.log              │
│   .DS_Store  application-local.yml           │
│                                              │
│  ⚠ 已 commit 的文件加 .gitignore 无效        │
│     → git rm --cached -r <path>              │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：截图 `ssh -T git@gitee.com` 成功输出，命名 `day05-03-ssh.png`；
2. **必做**：完成首次 push，Gitee 网页截图命名 `day05-03-remote.png`；
3. **挑战题**：查阅 SSH `~/.ssh/config` 用法，为 Gitee 和 GitHub 配置两套密钥（对应不同 Host），并写 200 字说明。

### 3.6 教学反思提示
- Windows 上 `~/.ssh/` 路径实际是 `C:\\Users\\<用户名>\\.ssh\\`，部分学生 Windows 用户名是中文——遇到再引导用 Git Bash 而非 PowerShell（Bash 里 `~` 是明确的 `/c/Users/xxx`）；
- `ssh-keygen` 期间会提示 \"Enter passphrase\" —— 让学生**回车留空**，本课程不用密码保护私钥；
- 少数学生的公司/学校防火墙会封 22 端口，导致 SSH 连不上——可让他们改用 443 端口（Gitee 支持 `ssh.gitee.com:443`）或临时换 HTTPS；
- 演示 `.gitignore` 踩坑时，一定要**先 add 错误 → 再补救**，让学生真切感受到，不要提前提示他们\"其实先加 gitignore 就好\"——踩过一次的坑记一辈子。

---

## 第 4 课时：分支开发实践 + 冲突解决 + 团队协作流

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 能说出 Git 分支的本质（指向某个 commit 的可移动指针）；
2. 熟练使用 `git branch / switch / merge / branch -d` 4 条分支命令；
3. 能主动制造并解决一次真实的合并冲突，理解冲突标记 `<<<<<<< / ======= / >>>>>>>` 的含义；
4. 能画出主干开发流：`main / dev / feat/xxx / fix/xxx` 四类分支的角色。

#### 4.1.2 过程与方法目标
1. 通过\"你和同桌各自改同一行代码\"的现场演练，让学生真实经历冲突场景；
2. 通过 IDEA 内置 Git 工具做冲突解决，让学生看到 GUI 和命令行的映射关系。

### 4.2 教学重难点
- **重点**：`switch -c` 新建切换／`merge` 合并／冲突手工解决三步（编辑 → add → commit）／IDEA 冲突面板
- **难点**：分支的\"指针\"本质（不是文件夹拷贝，是引用）；理解\"快进合并 fast-forward\"和\"三方合并 3-way\"的区别

### 4.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
先讲一个真实故事：\"某创业公司 4 个后端全在 main 分支上直接改代码，某周五下午张三改了登录模块，李四改了支付模块，同时 push——第二天上线全线崩溃，因为他们相互覆盖了对方的改动。\" 引出分支的必要性：**分支 = 平行宇宙 = 每个功能独立开发不打架**。

#### 新知讲授（15 分钟）

1. **分支的本质**（4 分钟）
   板书画一条时间线：
   ```
   c1 ── c2 ── c3 ── c4 ── c5
                          ↑
                       main / HEAD
   ```
   讲：**分支就是一个指针，指向某个 commit**。新建分支只是复制一份指针，切换分支只是把 HEAD 移到不同指针上。Git 分支为什么便宜？因为**不复制文件，只复制指针**。

2. **4 条分支命令**（4 分钟）
   板书写命令表：
   ```bash
   git branch                              # 看当前所有分支
   git branch feat/member                  # 新建，但不切换
   git switch feat/member                  # 切换
   git switch -c feat/member               # 新建 + 切换（推荐）
   git merge feat/member                   # 把 feat/member 合并到当前分支
   git branch -d feat/member               # 已合并的分支删除
   git branch -D feat/member               # 强制删除未合并的分支
   ```
   讲师提问：\"如果我在 feat/member 分支上还没 commit 就 switch 到 main 会怎样？\" 引导：**Git 会阻止你切换**（未 commit 改动会跨分支冲突），必须先 commit 或 stash。

3. **快进合并 vs 三方合并**（3 分钟）
   板书画两张图：
   ```
   # 快进 fast-forward（main 没动，feat 领先）
   main         feat
    ↓            ↓
   c1 ── c2 ── c3
              ↓ merge
   c1 ── c2 ── c3
                ↑
             main / feat

   # 三方合并 3-way（main 也进了）
   main            merge commit
    ↓              ↓
   c1 ── c2 ── c4 ─── c5
         └── c3 ──────┘
                ↑
              feat
   ```
   讲：**只有主干在你分出去以后没动过时才会 fast-forward**，否则会产生一个"合并 commit"。团队协作里几乎全是三方合并。

4. **主干开发流四分支**（4 分钟）
   板书写清单：
   - **main**：稳定发布分支，只接受 PR / Merge Request，不允许直接 push；
   - **dev**：日常集成分支，各 feat 合并到这里做联调；
   - **feat/xxx**：功能开发分支，如 `feat/member`、`feat/course`；
   - **fix/xxx**：Bug 修复分支，如 `fix/login-npe`。

#### 示例演示（20 分钟）

1. **正常分支合并（快进）**（5 分钟）：
   ```bash
   git switch -c feat/hello
   echo "hello from feat" >> README.md
   git add README.md
   git commit -m "feat: 演示分支合并"
   git switch main
   git merge feat/hello                  # 快进
   git log --oneline --graph
   git branch -d feat/hello
   ```

2. **制造冲突并解决**（10 分钟）：
   ```bash
   # 第 1 步：main 上改第一行
   git switch main
   # 编辑 README.md 第 1 行：\"# 印想瑜伽会馆客户管理系统 v1\"
   git add README.md && git commit -m "docs: main 改标题为 v1"

   # 第 2 步：分出 feat 也改第一行
   git switch -c feat/title
   # 编辑 README.md 第 1 行：\"# 印想瑜伽 · 会馆管理平台\"
   git add README.md && git commit -m "docs: feat 改标题为会馆管理平台"

   # 第 3 步：切回 main 又改一次
   git switch main
   # 编辑 README.md 第 1 行：\"# 印想瑜伽会馆客户管理系统 v2\"
   git add README.md && git commit -m "docs: main 改标题为 v2"

   # 第 4 步：合并 feat 到 main —— 冲突！
   git merge feat/title
   ```
   看到冲突输出，`git status` 显示 `both modified: README.md`。打开文件看到：
   ```
   <<<<<<< HEAD
   # 印想瑜伽会馆客户管理系统 v2
   =======
   # 印想瑜伽 · 会馆管理平台
   >>>>>>> feat/title
   ```
   讲：**`<<<<<<< HEAD` 到 `=======` 是当前分支内容**，**`=======` 到 `>>>>>>> feat/title` 是合并进来的分支内容**。手动编辑成最终想要的版本，然后：
   ```bash
   git add README.md
   git commit                            # 直接 commit（不用 -m，Git 已备好 merge message）
   ```
   或 IDEA 里右键 → Git → Resolve Conflicts，用三栏 Merge Tool 可视化合并。

3. **IDEA 冲突面板演示**（5 分钟）：现场用 IDEA 打开另一个演示项目，右键冲突文件 → Git → Resolve Conflicts → 左中右三栏（Their / Result / Yours），点击箭头逐段合并。**强调 IDEA 面板对新手最友好**。

#### 课堂练习（5 分钟）
1. 学生完成一次\"正常合并\"练习（feat 分支加一行，合回 main）；
2. 故意制造冲突并用命令行手工解决；
3. 用 IDEA 内置工具重做一次冲突解决，对比两种方式。

#### 小结（2 分钟）
一句话总结：**分支是 Git 的灵魂，冲突是团队协作的常态**。今天你已经具备一个人做团队协作演练的能力。下一课时进入 Maven 分模块——真项目的骨架。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  4. 分支开发 + 冲突解决 + 团队协作流         │
├──────────────────────────────────────────────┤
│  分支本质：指向某个 commit 的指针            │
│   → 新建分支不复制文件，只复制指针           │
│                                              │
│  4 条分支命令：                              │
│   branch / switch -c / merge / branch -d     │
│                                              │
│  两种合并：                                  │
│   fast-forward：主干没动，指针前移           │
│   3-way merge：主干也动了，产生 merge commit │
│                                              │
│  冲突标记：                                  │
│   <<<<<<< HEAD                               │
│    当前分支                                  │
│   =======                                    │
│    合并进来的                                │
│   >>>>>>> other-branch                       │
│                                              │
│  解决 = 编辑 → add → commit                  │
│                                              │
│  主干流四分支：                              │
│   main（稳）/ dev（集成）                    │
│   feat/xxx / fix/xxx                         │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成一次快进合并并 push 到 Gitee，命名 `day05-04-ff.png`；
2. **必做**：故意制造并解决一次冲突，截图 `git log --oneline --graph` 命名 `day05-04-conflict.png`；
3. **挑战题**：查阅 `git rebase`，用一句话说清它和 `merge` 的差异；说明为什么公司里\"主干合并用 merge、本地整理用 rebase\"。

### 4.6 教学反思提示
- 部分学生会问\"分支之间的文件是共享的还是独立的？\"——回答：**独立视图但共享底层对象**。Git 存的是快照，一个 blob 只存一份，多个分支共享；
- 冲突解决时如果学生把 `<<<<<<< / ======= / >>>>>>>` 也当代码 commit 了，程序会崩——课上必须**反复强调这三行必须删除**；
- 有学生分支合并后忘记删旧分支，导致 `git branch` 列表越来越长——课上要提醒\"合并即删除\"的卫生习惯；
- IDEA 的 Resolve Conflicts 三栏顺序不同版本可能有差异（有的左是 Yours，有的左是 Theirs）——课前预演一次确认版本，防止讲反。

---

## 第 5 课时：Maven 分模块开发 + 父 POM + 子模块拆分

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 能说出分模块的三大动机：**关注点分离 + 代码复用 + 独立部署**；
2. 能对比\"按层拆\"和\"按业务拆\"两种主流风格，理解本课程采用的折中方案；
3. 能编写父 POM（`<packaging>pom</packaging>` + `<modules>` + `<dependencyManagement>`）；
4. 能编写子模块 POM（引用父模块 + 只写 artifactId）；
5. 能把单模块 `yoga-member` 拆成 `yoga-common / yoga-pojo / yoga-mapper / yoga-service / yoga-web` 五个模块，并跑通 `mvn clean install`。

#### 5.1.2 过程与方法目标
1. 通过\"单模块痛点回忆\"引出分模块动机；
2. 通过\"父 POM → 子模块 → 模块间依赖\"三步阶梯，逐层建构分模块心智模型。

### 5.2 教学重难点
- **重点**：父 POM 的 `<packaging>pom</packaging>` / `<modules>` / `<dependencyManagement>` 三大要素；子模块间依赖关系（上层依赖下层，不可反向）
- **难点**：`<dependencyManagement>` 与 `<dependencies>` 的差异——前者**只声明版本不引入**，后者**才真正引入**；父子 POM 的位置约定（父在根、子在子目录）

### 5.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
承接 Day03 的 `yoga-member` 单模块项目：\"上周我们的项目一个 `pom.xml` 打天下，代码全在 `com.yinxiang` 下。今天要把它拆成 5 个模块，为什么？\" 板书写单模块痛点：
- 编译越来越慢（改 1 个类要编译全部）；
- Controller / Mapper / Service / Entity 混一起，找类靠 IDEA 全文搜索；
- 想让别的项目复用 Result 工具类？只能复制粘贴；
- 分不同环境部署？打包全塞一个 jar，太重。

**分模块 = 关注点分离 + 复用 + 独立部署**。

#### 新知讲授（18 分钟）

1. **两种拆分风格**（4 分钟）
   板书画两张目录树：
   ```
   # 按层拆
   yoga-parent/
   ├── yoga-common
   ├── yoga-pojo
   ├── yoga-mapper
   ├── yoga-service
   └── yoga-web

   # 按业务拆
   yoga-parent/
   ├── yoga-common
   ├── yoga-member
   ├── yoga-course
   └── yoga-web
   ```
   讲师提问：\"哪种更容易理解？哪种更利于长期演化？\" 引导：**初学期按层拆更直观；大型系统会按业务拆（微服务前身）**。本课程作为教学案例，选\"按层拆\"，保持简单。

2. **父 POM 完整骨架**（8 分钟）
   投影父 POM 完整源码，逐行讲：
   ```xml
   <?xml version=\"1.0\" encoding=\"UTF-8\"?>
   <project xmlns=\"http://maven.apache.org/POM/4.0.0\">
       <modelVersion>4.0.0</modelVersion>

       <groupId>com.yinxiang</groupId>
       <artifactId>yoga-member</artifactId>
       <version>1.0.0</version>
       <packaging>pom</packaging>            <!-- 父工程必须 pom -->

       <parent>
           <groupId>org.springframework.boot</groupId>
           <artifactId>spring-boot-starter-parent</artifactId>
           <version>4.0.0</version>
       </parent>

       <modules>
           <module>yoga-common</module>
           <module>yoga-pojo</module>
           <module>yoga-mapper</module>
           <module>yoga-service</module>
           <module>yoga-web</module>
       </modules>

       <properties>
           <java.version>25</java.version>
           <mybatis.version>3.0.5</mybatis.version>
           <hutool.version>5.8.32</hutool.version>
       </properties>

       <dependencyManagement>
           <dependencies>
               <dependency>
                   <groupId>org.mybatis.spring.boot</groupId>
                   <artifactId>mybatis-spring-boot-starter</artifactId>
                   <version>${mybatis.version}</version>
               </dependency>
               <dependency>
                   <groupId>cn.hutool</groupId>
                   <artifactId>hutool-all</artifactId>
                   <version>${hutool.version}</version>
               </dependency>
           </dependencies>
       </dependencyManagement>

       <dependencies>
           <dependency>
               <groupId>org.projectlombok</groupId>
               <artifactId>lombok</artifactId>
               <optional>true</optional>
           </dependency>
       </dependencies>
   </project>
   ```
   讲师**重点提问**：\"`<dependencyManagement>` 里的依赖会自动引入子模块吗？\" 引导：**不会**，只是"备案"，子模块要用还得自己声明——但可以省略 version（走父的统一版本）。

3. **子模块 POM**（3 分钟）
   投影最小子模块骨架：
   ```xml
   <project>
       <modelVersion>4.0.0</modelVersion>

       <parent>
           <groupId>com.yinxiang</groupId>
           <artifactId>yoga-member</artifactId>
           <version>1.0.0</version>
       </parent>

       <artifactId>yoga-common</artifactId>

       <dependencies>
           <dependency>
               <groupId>cn.hutool</groupId>
               <artifactId>hutool-all</artifactId>
           </dependency>
       </dependencies>
   </project>
   ```
   讲：**子模块的 `groupId` 与 `version` 从父继承，可省**；`<parent>` 是必须的。

4. **模块间依赖关系图**（3 分钟）
   板书画依赖箭头图：
   ```
   yoga-web ──► yoga-service ──► yoga-mapper ──► yoga-pojo ──► yoga-common
              │                                                     ▲
              └───────────────────────────────────────────────────┘
   ```
   讲：**上层可以依赖下层，下层绝不能依赖上层**（否则循环依赖）。`yoga-common` 是最底层的通用工具，人人都能依赖它。

#### 示例演示（19 分钟）

1. **在 IDEA 里把单模块拆成父 + 5 子模块**（12 分钟）：现场演示，学生同步：

   - 先在 Day05 分支上 `git switch -c refactor/multi-module`（**任何重构都开分支！**）；
   - 备份原 `pom.xml` 内容；
   - 修改根 `pom.xml`：把 `<packaging>` 从 `jar` 改成 `pom`，删除 `<dependencies>` 里的具体业务依赖，添加 `<modules>` 与 `<dependencyManagement>`；
   - IDEA 右键项目 → New → Module → Maven → Name 依次填 `yoga-common`、`yoga-pojo`、`yoga-mapper`、`yoga-service`、`yoga-web`；
   - 检查每个子模块 `pom.xml` 已经有 `<parent>` 指回 `yoga-member`；
   - 把原来 `src/main/java/com/yinxiang/` 下的代码搬迁：`controller/` → `yoga-web/src/main/java/com/yinxiang/controller/`；`service/` → `yoga-service`；`mapper/` → `yoga-mapper`；`entity/dto/vo/` → `yoga-pojo`；工具类 → `yoga-common`；
   - 修改各子模块 pom 加对应依赖，例如 `yoga-web/pom.xml`：
     ```xml
     <dependencies>
         <dependency>
             <groupId>org.springframework.boot</groupId>
             <artifactId>spring-boot-starter-web</artifactId>
         </dependency>
         <dependency>
             <groupId>com.yinxiang</groupId>
             <artifactId>yoga-service</artifactId>
             <version>1.0.0</version>
         </dependency>
     </dependencies>

     <build>
         <plugins>
             <plugin>
                 <groupId>org.springframework.boot</groupId>
                 <artifactId>spring-boot-maven-plugin</artifactId>
             </plugin>
         </plugins>
     </build>
     ```

2. **启动类的关键调整**（4 分钟）：把 `YogaMemberApplication.java` 放到 `yoga-web/src/main/java/com/yinxiang/`：
   ```java
   package com.yinxiang;

   import org.mybatis.spring.annotation.MapperScan;
   import org.springframework.boot.SpringApplication;
   import org.springframework.boot.autoconfigure.SpringBootApplication;

   @SpringBootApplication(scanBasePackages = \"com.yinxiang\")
   @MapperScan(\"com.yinxiang.mapper\")
   public class YogaMemberApplication {
       public static void main(String[] args) {
           SpringApplication.run(YogaMemberApplication.class, args);
       }
   }
   ```
   **重点强调**：分模块后代码分散在多个 jar 里，`@SpringBootApplication` 默认扫\"启动类所在包及其子包\"——因为各模块都以 `com.yinxiang` 为根，写 `scanBasePackages = \"com.yinxiang\"` 即可扫全；Mapper 也要 `@MapperScan`。

3. **父工程整体构建**（3 分钟）：
   ```bash
   cd D:/workspace/yoga-member
   mvn clean install
   ```
   看到 5 个 `BUILD SUCCESS` 分别对应 5 个模块，最后一个大 `BUILD SUCCESS`。
   ```bash
   mvn -pl yoga-web spring-boot:run    # 只跑 web 模块
   ```

#### 课堂练习（3 分钟）
1. 学生完成父 POM 与 5 个子模块的目录建立；
2. 执行 `mvn clean install` 通过 5 次 BUILD SUCCESS；
3. `git add . && git commit -m \"refactor: 单模块拆分为 5 模块分层结构\"`。

#### 小结（2 分钟）
一句话总结：**分模块 = 父 POM 管版本 + 子模块管边界 + 上层依赖下层**。分模块之后，代码分层更清晰，Result、PageResult 这些通用工具可以让所有模块共用。下一节课就来给 `yoga-common` 加通用返回和接口文档。

### 5.4 板书设计
```
┌──────────────────────────────────────────────┐
│  5. Maven 分模块 + 父 POM + 子模块           │
├──────────────────────────────────────────────┤
│  分模块 3 大动机：                           │
│   关注点分离 + 代码复用 + 独立部署           │
│                                              │
│  两种拆分风格：                              │
│   按层拆 ← 本课程采用（学习期首选）          │
│   按业务拆（大型系统 / 微服务前身）          │
│                                              │
│  父 POM 三要素：                             │
│   <packaging>pom</packaging>                 │
│   <modules>...</modules>                     │
│   <dependencyManagement>...</...>            │
│                                              │
│  yoga-member/                                │
│   ├── yoga-common                            │
│   ├── yoga-pojo                              │
│   ├── yoga-mapper                            │
│   ├── yoga-service                           │
│   └── yoga-web  ← 启动类 + @MapperScan       │
│                                              │
│  依赖箭头：上层 ─► 下层（永不反向）          │
│                                              │
│  ⚠ scanBasePackages = \"com.yinxiang\"         │
└──────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 5 模块拆分，`mvn clean install` 5 个 SUCCESS 截图，命名 `day05-05-build.png`；
2. **必做**：把重构分支合并回 main 并 push 到 Gitee；
3. **挑战题**：让通义灵码为 `yoga-common` 生成一个 `DateTimeUtils.java`（含 `LocalDateTime ↔ String` 互转），并写 3 个单元测试。

### 5.6 教学反思提示
- 学生最容易踩的坑：新建子模块时 IDEA 默认会自动填 `<groupId>` 和 `<version>`——如果与父模块不一致会构建失败——课上要提示学生**统一为 `com.yinxiang` + `1.0.0`**；
- 部分学生的 `yoga-web/pom.xml` 忘了加 `spring-boot-maven-plugin`，导致 `mvn package` 不生成可执行 jar——本节要强调这一插件只加在 `yoga-web` 里；
- `@MapperScan(\"com.yinxiang.mapper\")` 的包名必须与 `yoga-mapper` 里的实际包名一致，否则 Bean 无法注册——课后要求学生自查；
- 重构过程学生易把代码搬错模块（如把 Service 放到 mapper 模块），可让学生做完后互查一次；
- 分模块后 IDEA 索引会重建，短时间内爆红——安抚学生等 IDEA 完成 Reindex 再判断。

---

## 第 6 课时：项目基础环境搭建（建库 + Result + Knife4j + 开发规范）

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 能创建 MySQL 8.0 数据库 `yoga_member`，并在 `application-dev.yml` 中配置正确的连接串；
2. 能在 `yoga-common` 定义泛型 `Result<T>` 与 `PageResult<T>`，并在 Controller 中使用；
3. 能在 `yoga-web` 集成 Knife4j 4.5+ 接口文档，成功访问 `http://localhost:8080/doc.html`；
4. 能背下项目开发规范：包命名 / 类命名 / 常量命名 / Git commit 规范。

#### 6.1.2 过程与方法目标
1. 通过\"接口调试的痛点\"（Postman 手输 URL、参数）引出接口文档的价值；
2. 通过\"AI 生成 Result 类 + 自己审查\"的方式，训练\"AI 是同事而不是替身\"的协作意识。

### 6.2 教学重难点
- **重点**：`yoga_member` 库 + `application-dev.yml` 配置／`Result<T>` 泛型统一返回／Knife4j 集成／开发规范
- **难点**：Knife4j 4.x 与 Spring Boot 4 的适配版本；`OpenAPI 3` 与旧 `Swagger 2` 注解的差异

### 6.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
展示一个开发场景：\"你写了一个 `/api/course/list` 接口，前端同学 QQ 上问：'路径是啥？参数怎么传？返回什么结构？'——你手动打字回答。三天后又问同一个问题。\" 引出接口文档：**Knife4j 让接口自己描述自己，前端一看即懂**。

#### 新知讲授（12 分钟）

1. **数据库准备**（3 分钟）
   板书 SQL：
   ```sql
   CREATE DATABASE yoga_member
     DEFAULT CHARACTER SET utf8mb4
     DEFAULT COLLATE utf8mb4_unicode_ci;

   USE yoga_member;

   CREATE TABLE t_category (
     id           BIGINT       PRIMARY KEY AUTO_INCREMENT,
     name         VARCHAR(64)  NOT NULL COMMENT '课程分类名',
     code         VARCHAR(32)  NOT NULL COMMENT '编码',
     sort         INT          DEFAULT 0,
     create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
     update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   ) COMMENT='课程分类';
   ```

2. **`yoga-web/src/main/resources/application-dev.yml`**（3 分钟）：
   ```yaml
   server:
     port: 8080

   spring:
     datasource:
       url: jdbc:mysql://localhost:3306/yoga_member?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai
       username: root
       password: 123456
       driver-class-name: com.mysql.cj.jdbc.Driver

   mybatis:
     mapper-locations: classpath*:mapper/*.xml
     configuration:
       map-underscore-to-camel-case: true

   logging:
     level:
       com.yinxiang: debug
   ```

3. **`Result<T>` 与 `PageResult<T>`**（3 分钟）
   板书写核心结构：
   ```java
   @Data
   public class Result<T> implements Serializable {
       private Integer code;   // 1 成功 0 失败
       private String  msg;
       private T       data;

       public static <T> Result<T> success()          { return build(1, \"success\", null); }
       public static <T> Result<T> success(T data)    { return build(1, \"success\", data); }
       public static <T> Result<T> error(String msg)  { return build(0, msg, null); }
       // build 略
   }
   ```
   **强调**：所有 Controller 返回都要包一层 `Result`——统一响应结构是前后端约定的基本礼仪。

4. **Knife4j 集成核心配置**（3 分钟）
   板书写 `yoga-web/pom.xml` 依赖：
   ```xml
   <dependency>
       <groupId>com.github.xiaoymin</groupId>
       <artifactId>knife4j-openapi3-jakarta-spring-boot-starter</artifactId>
       <version>4.5.0</version>
   </dependency>
   ```
   `application.yml` 追加：
   ```yaml
   springdoc:
     swagger-ui:
       enabled: true
     api-docs:
       enabled: true

   knife4j:
     enable: true
     setting:
       language: zh_cn
   ```

#### 示例演示（22 分钟）

1. **建库建表 + JDBC 连通性验证**（5 分钟）：现场用 MySQL Workbench / IDEA Database 面板执行 SQL，插入 3 条种子数据；启动 `yoga-web` 模块，日志里看到 HikariCP 成功初始化即通。

2. **`yoga-common` 完善 Result + PageResult**（5 分钟）：把上面的 Java 代码写到 `yoga-common/src/main/java/com/yinxiang/common/Result.java`，同时写：
   ```java
   package com.yinxiang.common;

   import lombok.AllArgsConstructor;
   import lombok.Data;
   import java.util.List;

   @Data
   @AllArgsConstructor
   public class PageResult<T> {
       private long total;
       private List<T> rows;
   }
   ```
   在 `yoga-web` 的 `HelloController` 里改造：
   ```java
   @GetMapping(\"/hello\")
   public Result<String> hello() {
       return Result.success(\"Hello, 印想瑜伽!\");
   }
   ```
   浏览器访问，看到 `{\"code\":1,\"msg\":\"success\",\"data\":\"Hello, 印想瑜伽!\"}`。

3. **Knife4j 集成 + 注解**（7 分钟）：加依赖 + 配置后，写一个 `CategoryController`：
   ```java
   package com.yinxiang.controller;

   import com.yinxiang.common.Result;
   import io.swagger.v3.oas.annotations.Operation;
   import io.swagger.v3.oas.annotations.tags.Tag;
   import org.springframework.web.bind.annotation.*;

   @Tag(name = \"课程分类\", description = \"课程分类管理接口\")
   @RestController
   @RequestMapping(\"/api/category\")
   public class CategoryController {

       @Operation(summary = \"分类列表\")
       @GetMapping(\"/list\")
       public Result<String> list() {
           return Result.success(\"分类列表 - 空实现\");
       }
   }
   ```
   重启 `yoga-web`，浏览器访问 `http://localhost:8080/doc.html`——**看到 Knife4j 华丽首页 + 左侧分组 + 右侧接口详情即成功**。

4. **开发规范速览**（5 分钟）：板书清单：
   - 包命名：`com.yinxiang.<模块>.<层>`，全小写，反向域名开头；
   - 类命名：Pascal，`XxxController` / `XxxService` / `XxxServiceImpl` / `XxxMapper` / `XxxEntity` / `XxxDTO` / `XxxVO`；
   - 常量命名：`static final` + 全大写 + 下划线：`DEFAULT_PASSWORD`；
   - Git commit：Conventional Commits，`feat/fix/docs/style/refactor/test/chore`；
   - 每个功能开 `feat/xxx` 分支，合并到 `dev`，`dev` 再 PR 到 `main`。

#### 课堂练习（5 分钟）
1. 完成建库 + `application-dev.yml` 连接；
2. 完成 `Result` + `PageResult` 定义 + `Hello` 接口改造；
3. 完成 Knife4j 集成 + `CategoryController` + `/doc.html` 打开成功截图。

#### 小结（3 分钟）
一句话总结：**Day05 结束 = 有仓库、有分支、有分模块、有 Result、有接口文档**。你的项目已经具备一个真实工程的所有骨架。接下来 Day06~Day10 全是往这个骨架里填肉：登录、员工、会员、课程、预约……。今天最后 3 分钟做课程反馈：让学生说本 Day 最难的一个点，作为下次课的补充材料。

### 6.4 板书设计
```
┌──────────────────────────────────────────────┐
│  6. 项目基础环境（库 + Result + Knife4j）    │
├──────────────────────────────────────────────┤
│  数据库：                                    │
│   CREATE DATABASE yoga_member                │
│     DEFAULT CHARACTER SET utf8mb4;           │
│                                              │
│  application-dev.yml：                       │
│   spring.datasource.url                      │
│   mybatis.mapper-locations                   │
│                                              │
│  yoga-common：                               │
│   Result<T> { code, msg, data }              │
│   PageResult<T> { total, rows }              │
│                                              │
│  Knife4j 集成 3 步：                         │
│   ① 加依赖 knife4j-openapi3-jakarta          │
│   ② application.yml 开启                     │
│   ③ Controller 加 @Tag / @Operation          │
│   ④ 访问 /doc.html                           │
│                                              │
│  开发规范：                                  │
│   包/类/常量命名 + Conventional Commits      │
│                                              │
│  ⚠ Knife4j 4.5+ 匹配 Spring Boot 3.x/4.x     │
└──────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：建库 + 建 `t_category` 表 + 插 3 条种子数据，命名截图 `day05-06-db.png`；
2. **必做**：`http://localhost:8080/doc.html` 打开成功截图，命名 `day05-06-knife4j.png`；
3. **必做**：把今天所有改动按 `feat: 集成 Knife4j 与 Result` 一次 commit 并 push 到 Gitee；
4. **挑战题**：让 Trae 生成 `yoga-common` 里的 `BizException` 自定义异常类 + `ErrorCode` 枚举，与 `Result` 联动一个 `Result.error(ErrorCode)` 重载。

### 6.6 教学反思提示
- Knife4j 版本坑：4.4+ 才完整支持 Jakarta EE 9+ / Spring Boot 3.x/4.x——若学生用 4.3 及以下，会报 `javax.servlet` 找不到——课上要**明确指定 4.5.0**；
- MySQL 8.0 默认要 `serverTimezone`，学生易忘——JDBC URL 里必须加 `serverTimezone=Asia/Shanghai`；
- 部分学生用 MySQL 5.7 或 Docker MySQL，密码策略不同——课前调研学生环境，及时提供备用密码方案；
- Knife4j 页面若加载不出来，多半是 `springdoc` 与 `knife4j` 版本冲突——课上要提前预留 3 分钟做兜底演示；
- 半天课结束建议留 2 分钟做本 Day 反馈：让学生说本 Day 最难的一个点，作为下次课的补充材料；
- Day05 是分水岭——过了今天，全部项目基础到位。若学生跟不上，务必用课间和课后单独辅导，否则 Day06 后完全脱节。

---

## 附录：Day05 主线项目最终目录结构

供学生做完 Day05 后对照检查：

```text
yoga-member/                     ← 父工程 + Git 仓库根
├── .gitignore
├── README.md
├── pom.xml                      ← 父 POM，packaging=pom
├── yoga-common/
│   └── src/main/java/com/yinxiang/common/
│       ├── Result.java
│       └── PageResult.java
├── yoga-pojo/
│   └── src/main/java/com/yinxiang/pojo/
│       ├── entity/
│       ├── dto/
│       └── vo/
├── yoga-mapper/
│   ├── src/main/java/com/yinxiang/mapper/
│   └── src/main/resources/mapper/
├── yoga-service/
│   └── src/main/java/com/yinxiang/service/
│       ├── CategoryService.java
│       └── impl/
└── yoga-web/
    ├── src/main/java/com/yinxiang/
    │   ├── YogaMemberApplication.java
    │   ├── controller/
    │   │   ├── HelloController.java
    │   │   └── CategoryController.java
    │   └── config/
    │       └── Knife4jConfig.java
    └── src/main/resources/
        ├── application.yml
        ├── application-dev.yml
        └── application-prod.yml
```

## 附录：Day05 整体教学时间轴

| 课时 | 主题 | 关键产出 |
|:---:|---|---|
| 1 | 项目需求分析 + 技术选型 + 仓库规划 | Gitee `yoga-member` 私有仓库创建 |
| 2 | Git 本地仓库 + 基本工作流 | 本地 `git init` + 首次 commit |
| 3 | 远程仓库 + SSH + push/pull + .gitignore | SSH 免密 + 首次 push 成功 |
| 4 | 分支开发 + 冲突解决 + 团队协作流 | 完成一次冲突解决实战 |
| 5 | Maven 分模块 + 父 POM + 子模块 | 拆分 5 模块 `mvn clean install` |
| 6 | 项目基础（库/Result/Knife4j/规范） | Knife4j `/doc.html` 打开成功 |
