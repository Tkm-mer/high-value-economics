# 《AI 应用 Web 开发》 - 教师教案（Day07：统一日志处理与全局异常 + 教练管理与教室管理）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day06 的学生（掌握 Spring Boot 4.0 项目结构、MyBatis 3.5+、DTO/VO 分层、参数校验、会员模块 CRUD 与分页查询）**
**知识点覆盖：** 第 13 章 统一日志处理与全局异常（Result、BizException、@RestControllerAdvice、Logback 生产配置、404 统一） + 第 14 章 教练管理与教室管理（tb_coach + tb_room 双模块、双重唯一性校验、AI 一次生成两模块）

**技术版本基线**：Spring Boot 4.0 / Java 25 / Vue 3.5+ / pnpm 9 / MySQL 8.0 / Redis 8.x / Docker 24+ / MyBatis 3.5+ / IDEA 2024.3+ / 通义灵码 + Trae。

**Day07 主线**：前 3 个课时把「后端接口的两个底裤」——统一响应结构 + 全局异常处理 + 生产级日志——一次性打死，这是印想瑜伽会馆项目从「能跑」到「能上线」的分水岭；后 3 个课时用「教练 + 教室」这一对结构对称的资源模块，把前面所有铺垫（DTO 分层、双重唯一性校验、软删除、分页搜索、AI 批量生成）一次性巩固，为 Day08 的课程排课多表关联打好牌。

---

## 第 1 课时：统一响应结构 Result 与业务异常 BizException

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能说出「前端厌恶有时 200 有时 500」的根本原因，并画出统一 Result 结构下的前后端契约图；
2. 能用 Java 25 语法写出 `Result<T>` 三字段（code、message、data）以及静态工厂 `ok / ok(data) / fail(code, msg) / fail(msg)`；
3. 能区分「该抛 BizException 的业务预期内错误」与「该让全局异常兜底的系统级异常」两类场景，各举 3 例；
4. 能定义 `BizException extends RuntimeException`，包含 `int code` 字段，提供双构造器；
5. 能在会员 Service 里用 `throw new BizException("手机号已被注册")` 替换 `return Result.fail(...)`，理解「Service 只关心业务、Controller 只关心返回」的分层原则。

#### 1.1.2 过程与方法目标
1. 通过「让 5 位学生念一遍老代码里 `Result.fail / throw / return null` 混杂的 Service 片段」，引导学生自己发现「返回结构不一致」的痛点；
2. 通过「先画类图再敲键盘」的顺序，训练「用图表达契约」的接口设计习惯。

### 1.2 教学重难点
- **重点**：Result<T> 三字段契约／`code=0` 表示成功的约定／`BizException` 的抛出时机／Service 抛异常 vs Controller 返回 Result 的分层原则
- **难点**：什么错误该抛 `BizException`（业务预期内），什么错误该让全局兜底（系统级）／`BizException` 的 code 与 HTTP 状态码要不要一致（本课先约定「一律 HTTP 200，业务错在 body 的 code 字段里」）

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
以真实痛点切入。讲师投影 Day06 学生提交的 `MemberController` 代码片段：手机号已存在返回 `Result.fail(500, "已存在")`、参数缺失让 Spring 直接抛 400、Service 里空指针原样冒泡到 500 白页。**抽 3 位学生朗读**这段代码，让每一位学生说一句「如果你是前端，看到这三种响应，你会怎么写 axios 拦截器」。板书写下学生原话，多半是「我根本没法统一处理」。

讲师接话：「今天我们花一节课把这个乱象**一次性摁死**——所有接口，无论成功失败，HTTP 一律 200，body 一律 Result 结构，前端只看 `res.data.code == 0` 判断成败。」

#### 新知讲授（15 分钟）

1. **为什么必须统一**（5 分钟）：投影三张对比图，一张「乱象前」的响应组合表（200 + 数据 / 200 + Result.fail / 400 空 body / 500 Whitelabel），另一张「统一后」的响应组合表（HTTP 全部 200，Result 的 code 表示成败）。讲师口播：**统一带来 3 个价值**——① 前端 axios 拦截器一处判断即可；② 后端日志只在最外层打一次栈；③ 业务错误与系统错误分级监控。

2. **Result<T> 三字段契约**（5 分钟）：黑板画出类结构。字段一一说明：
   - `Integer code`：0 表示成功，非 0 表示失败，值域约定 `4xxxx` 会员业务、`5xxxx` 教练业务、`6xxxx` 教室业务、`400 / 404 / 405 / 409 / 500` 系统级；
   - `String message`：给人看的中文错误提示，前端可直接 toast；
   - `T data`：泛型载荷，成功时挂返回数据，失败时置 null；
   - 静态工厂四方法：`ok() / ok(T data) / fail(String msg) / fail(int code, String msg)`，注解 `@AllArgsConstructor` `@NoArgsConstructor` `@Data`。

3. **BizException 的抛出时机**（5 分钟）：讲师**抽学生**回答「以下场景哪些应该抛 BizException」，逐一举手统计：
   - 手机号已存在（**抛 BizException**：业务预期内）；
   - 余额不足（**抛 BizException**：业务预期内）；
   - 参数手机号格式错（**不抛**：交给 Bean Validation）；
   - MySQL 连不上（**不抛**：交给 Throwable 兜底）；
   - `getById(id)` 找不到（**抛 BizException**：业务语义）；
   - 数据库唯一键冲突（**不抛**：`DuplicateKeyException` 单独处理）。

   板书总结口诀：**「业务规则不通过 → BizException；框架能识别的 → 交给框架；系统级问题 → 兜底」。**

#### 示例演示（13 分钟）

1. **写 Result.java**（5 分钟）：讲师在 IDEA 里现场敲代码，边敲边口播。投影全屏放大。放到模块 `yoga-common` 下：

   ```java
   package com.yinxiang.common;

   import lombok.AllArgsConstructor;
   import lombok.Data;
   import lombok.NoArgsConstructor;

   @Data
   @AllArgsConstructor
   @NoArgsConstructor
   public class Result<T> {
       private Integer code;
       private String  message;
       private T       data;

       public static <T> Result<T> ok()               { return new Result<>(0, "OK", null); }
       public static <T> Result<T> ok(T data)         { return new Result<>(0, "OK", data); }
       public static <T> Result<T> fail(String msg)   { return new Result<>(500, msg, null); }
       public static <T> Result<T> fail(int code, String msg) { return new Result<>(code, msg, null); }
   }
   ```

   现场纠错——故意先写成 `int code`（不是 `Integer`），让学生发现「基本类型无法序列化为 null，Jackson 默认 0，代码看起来永远成功」，改为包装类型。

2. **写 BizException.java**（4 分钟）：

   ```java
   package com.yinxiang.common;

   public class BizException extends RuntimeException {
       private final int code;

       public BizException(String message) {
           super(message);
           this.code = 500;
       }

       public BizException(int code, String message) {
           super(message);
           this.code = code;
       }

       public int getCode() { return code; }
   }
   ```

   讲师口播：「继承 `RuntimeException` 不是 `Exception`，为什么？因为**受检异常会污染 Service 方法签名**，团队协作里没人愿意到处写 `throws BizException`。」

3. **重构 MemberService**（4 分钟）：把 Day06 的 `Result.fail("手机号已被注册")` 替换成 `throw new BizException("手机号已被注册")`。讲师现场演示——Postman 打一次已存在手机号，此时**故意不加全局异常处理器**，让学生看到 Spring 抛出的 Whitelabel Error Page，制造悬念：「下一课时我们把这坨白页治了。」

#### 课堂练习（8 分钟）
1. 每位学生在自己项目里新建 `Result.java` 和 `BizException.java`，把 Day06 的 `MemberService` 中所有 `Result.fail(...)` 改为 `throw new BizException(...)`（提示：Service 方法签名的返回值也要跟着改，从 `Result<Void>` 改为 `void`）；
2. 追加要求：用通义灵码提示词「帮我给 Result 加一个 `fail(BizException e)` 静态方法」，观察 AI 是否会正确识别 `e.getCode()` 与 `e.getMessage()` 两个字段；
3. 思考题：如果一个接口既可能业务失败（返回 code 42001），又可能返回数据（返回 code 0），前端 axios 拦截器该怎么写？（提示：以 `code == 0` 为唯一判据，data 只在成功时使用）。

#### 小结（3 分钟）
一句话回顾：**Result 三字段 + 两组静态工厂 + BizException 一个 code 字段——契约就这么简单。** 现在业务侧的「预期错误」有了统一出口，但**框架抛出的异常**（校验失败、404、方法不允许、唯一键冲突、空指针）还在到处乱跑。下一课时用 `@RestControllerAdvice` 把它们全部收编。

### 1.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day07-01  Result 与 BizException 类图               │
├──────────────────────────────────────────────────────┤
│                                                      │
│        ┌───────────────────────┐                     │
│        │  Result<T>            │                     │
│        ├───────────────────────┤                     │
│        │ - code   : Integer    │  0 = 成功           │
│        │ - message: String     │  给人看的提示       │
│        │ - data   : T          │  载荷               │
│        ├───────────────────────┤                     │
│        │ + ok()                │                     │
│        │ + ok(T)               │                     │
│        │ + fail(String)        │                     │
│        │ + fail(int,String)    │                     │
│        └───────────────────────┘                     │
│                                                      │
│        ┌───────────────────────────────┐             │
│        │  BizException                 │             │
│        │  extends RuntimeException     │             │
│        ├───────────────────────────────┤             │
│        │ - code : int                  │             │
│        ├───────────────────────────────┤             │
│        │ + BizException(msg)           │             │
│        │ + BizException(code,msg)      │             │
│        │ + getCode()                   │             │
│        └───────────────────────────────┘             │
│                                                      │
│  抛 / 不抛 判据：                                    │
│    业务预期错误  → 抛 BizException                   │
│    参数格式错    → 让 Bean Validation 抛             │
│    数据库唯一键  → 让 DuplicateKeyException 抛       │
│    系统级空指针  → 让 Throwable 兜底                 │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：把 Day06 的会员模块 Service 全部改为「抛 BizException 而非 return Result.fail」，Controller 里 Service 方法签名也要跟着改成 `void` / 直接返回数据，交 GitHub commit 链接；
2. **必做**：整理一份「什么该抛 BizException 什么不该」的私人清单，至少列 8 条业务场景 + 4 条非业务场景，作为后续写代码时的自查表；
3. **挑战**：把 `Result` 的 `code` 字段抽成枚举 `ResultCode`，包含 `SUCCESS(0)`、`BAD_REQUEST(400)`、`NOT_FOUND(404)`、`CONFLICT(409)`、`SERVER_ERROR(500)`，`BizException` 构造器改为 `BizException(ResultCode, String)`，Service 层不再直接写数字。

### 1.6 教学反思提示
- 学生最容易在**返回值改造**这一步卡壳——Service 方法从 `Result<Void>` 改为 `void` 后，Controller 里 `return Result.ok(service.xxx())` 会编译报错。示例演示时讲师**故意先漏一处**让学生找编译错误，训练「跟着编译器修 bug」的习惯；
- 有学生会问「HTTP 状态码不用 400 / 500 吗」，讲师回答：「团队约定统一 HTTP 200，把业务错误放 body 里。这不是对错问题，是**契约选择**——RESTful 风格用 HTTP 状态码，一站式后台管理系统用 body 错误码，两派都有大厂在用，我们选后者是为了前端 axios 拦截器简单」；
- 若课堂时间紧，`ResultCode` 枚举挑战题可以留到 Day08 补齐。

---

## 第 2 课时：全局异常处理器 @RestControllerAdvice 与 404 统一

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能用 `@RestControllerAdvice` + `@ExceptionHandler` 编写全局异常处理器，覆盖 7 类常见异常；
2. 能画出「异常处理器分派矩阵」——异常类型 → 处理方法 → HTTP 状态 → 业务 code → 日志级别；
3. 能配置 `spring.web.resources.add-mappings: false` 和 `throw-exception-if-no-handler-found: true`，让 404 也能被处理器捕获；
4. 能区分 `log.warn`（业务/客户端错误，可预期）与 `log.error`（系统错误，需要报警）两级别的日志纪律；
5. 能写出 `handle404` `handleBiz` `handleValid` `handleDup` `handleAll` 五个核心分支的完整代码。

#### 2.1.2 过程与方法目标
1. 通过「先列所有可能的异常，再画分派矩阵，最后填代码」的三步流程，训练系统性编程思维；
2. 通过「故意让每个异常都触发一次，观察响应变化」的对照实验，让学生眼见为实。

### 2.2 教学重难点
- **重点**：`@RestControllerAdvice` 的作用域（全应用 vs `basePackages`）／`@ExceptionHandler` 就近匹配原则（具体到抽象、业务到系统）／404 统一的两个必要配置项／日志级别 warn vs error
- **难点**：`Throwable` 兜底必须**放在最后**且**必须打完整栈**——如果放最前面所有具体异常都不会被匹配到／`@ControllerAdvice` 和 `@RestControllerAdvice` 的差异（后者自带 `@ResponseBody`）／异常处理器里**绝不能再抛异常**

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接上课时的悬念。讲师打开 Postman，故意传一个不存在的手机号做 POST，屏幕上出现「Whitelabel Error Page」白花花一片。抛问：**「假设你是印想瑜伽会馆的产品经理，看到这个白页你的第一反应是什么？」** 抽一位学生回答，大概率是「这系统坏了」。讲师接话：「今天我们让 Spring **永远不再返回白页**——所有异常都变成 Result 结构。」

#### 新知讲授（15 分钟）

1. **@RestControllerAdvice 工作原理**（3 分钟）：讲师板书 `@RestControllerAdvice = @ControllerAdvice + @ResponseBody`。它是一个「全局切面」，扫描所有 Controller 抛出的异常，用 `@ExceptionHandler(XxxException.class)` 标记的方法接管返回。**匹配规则**：Spring 优先匹配最具体的异常类型，找不到才向父类匹配，最后落到 `Throwable`。

2. **异常清单与分派矩阵**（7 分钟）：讲师投影一张表，逐行讲解。让学生**举手**回答每一行的处理策略：

   | 异常类型 | 场景 | HTTP | 业务 code | 日志级别 |
   |----------|------|------|-----------|----------|
   | `BizException` | 手机号已存在、余额不足 | 200 | 用异常自带 code | `warn` |
   | `MethodArgumentNotValidException` | @RequestBody + @Valid 校验失败 | 200 | 400 | `warn` |
   | `ConstraintViolationException` | Query 参数 @Validated 失败 | 200 | 400 | `warn` |
   | `MissingServletRequestParameterException` | 必填 Query 参数缺失 | 200 | 400 | `warn` |
   | `HttpRequestMethodNotSupportedException` | GET/POST 用错 | 200 | 405 | `warn` |
   | `DuplicateKeyException` | 数据库唯一键冲突 | 200 | 409 | `warn` |
   | `NoHandlerFoundException` | URL 不存在 | 200 | 404 | `warn` |
   | `Throwable` | 空指针、SQL 报错、Redis 挂 | 200 | 500 | `error` + 完整栈 |

   讲师口播总结口诀：「**具体到抽象、业务到系统、warn 到 error。**」

3. **404 统一的两个必要配置**（3 分钟）：Spring Boot 默认对未映射 URL 走 `BasicErrorController` 返回白页。要让 `NoHandlerFoundException` **真的能抛出来**，必须在 `application.yml` 加两行：

   ```yaml
   spring:
     web:
       resources:
         add-mappings: false
     mvc:
       throw-exception-if-no-handler-found: true
   ```

   讲师强调：**这两个配置任缺其一 404 都无法被捕获**。第一行关掉默认静态资源映射（否则 Spring 认为「你可能在找 static 目录下的文件」），第二行让 Spring 遇到未映射 URL 时抛异常而非渲染错误页。

4. **异常处理器里的三大禁忌**（2 分钟）：
   - **禁忌一**：处理器里再抛异常——会导致 500 空响应，所有代码用 try-catch 包住；
   - **禁忌二**：`Throwable` 分支放最前面——具体异常永远匹配不到，整个矩阵形同虚设；
   - **禁忌三**：正常路径写 `log.error`——错误监控告警会天天误报，只有真的系统级错误才用 `error`。

#### 示例演示（14 分钟）

1. **写 GlobalExceptionHandler**（10 分钟）：讲师现场敲完整代码，投影全屏，边敲边讲：

   ```java
   package com.yinxiang.common;

   import lombok.extern.slf4j.Slf4j;
   import org.springframework.dao.DuplicateKeyException;
   import org.springframework.web.bind.MethodArgumentNotValidException;
   import org.springframework.web.bind.MissingServletRequestParameterException;
   import org.springframework.web.bind.annotation.ExceptionHandler;
   import org.springframework.web.bind.annotation.RestControllerAdvice;
   import org.springframework.web.HttpRequestMethodNotSupportedException;
   import org.springframework.web.servlet.NoHandlerFoundException;
   import jakarta.validation.ConstraintViolationException;
   import java.util.stream.Collectors;

   @Slf4j
   @RestControllerAdvice
   public class GlobalExceptionHandler {

       @ExceptionHandler(BizException.class)
       public Result<Void> handleBiz(BizException e) {
           log.warn("[业务异常] code={} msg={}", e.getCode(), e.getMessage());
           return Result.fail(e.getCode(), e.getMessage());
       }

       @ExceptionHandler(MethodArgumentNotValidException.class)
       public Result<Void> handleValid(MethodArgumentNotValidException e) {
           String msg = e.getBindingResult().getFieldErrors().stream()
                   .map(f -> f.getField() + ": " + f.getDefaultMessage())
                   .collect(Collectors.joining("; "));
           log.warn("[参数校验失败] {}", msg);
           return Result.fail(400, msg);
       }

       @ExceptionHandler(ConstraintViolationException.class)
       public Result<Void> handleConstraint(ConstraintViolationException e) {
           String msg = e.getConstraintViolations().stream()
                   .map(v -> v.getPropertyPath() + " " + v.getMessage())
                   .collect(Collectors.joining("; "));
           return Result.fail(400, msg);
       }

       @ExceptionHandler(MissingServletRequestParameterException.class)
       public Result<Void> handleMissingParam(MissingServletRequestParameterException e) {
           return Result.fail(400, "缺少必需参数：" + e.getParameterName());
       }

       @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
       public Result<Void> handleMethod(HttpRequestMethodNotSupportedException e) {
           return Result.fail(405, "不支持的请求方法：" + e.getMethod());
       }

       @ExceptionHandler(DuplicateKeyException.class)
       public Result<Void> handleDup(DuplicateKeyException e) {
           log.warn("[唯一键冲突] {}", e.getMessage());
           return Result.fail(409, "数据已存在，请检查唯一字段");
       }

       @ExceptionHandler(NoHandlerFoundException.class)
       public Result<Void> handle404(NoHandlerFoundException e) {
           return Result.fail(404, "接口不存在：" + e.getRequestURL());
       }

       @ExceptionHandler(Throwable.class)
       public Result<Void> handleAll(Throwable e) {
           log.error("[系统异常]", e);
           return Result.fail(500, "系统繁忙，请稍后再试");
       }
   }
   ```

   讲师**故意先把 `Throwable` 分支写到最前面**，然后触发一次 `BizException`，让学生看到「所有业务异常都被 Throwable 兜住了、日志级别错乱」——再把 `Throwable` 移到最后，重跑一次演示对比。这一步的教学价值：让学生亲眼看到「顺序错了矩阵就没用」。

2. **application.yml 配置 404**（2 分钟）：现场加两行 `add-mappings: false` 和 `throw-exception-if-no-handler-found: true`，Postman 请求 `/xxxNotExist`，返回 `{"code":404,"message":"接口不存在：/xxxNotExist","data":null}`。

3. **触发全部 7 类异常做对照**（2 分钟）：讲师快速跑一遍——已注册手机号触发 BizException、少填 phone 触发 MethodArgumentNotValidException、GET 用成 POST 触发 405、故意在 SQL 里改字段名触发 Throwable 兜底。每次都观察 Postman 响应 + IDEA 控制台日志级别，让学生数出「warn 出现几次、error 出现几次」。

#### 课堂练习（10 分钟）
1. 每位学生完成 `GlobalExceptionHandler` 落地，交 Postman 截图 5 张，分别覆盖 BizException / 参数校验失败 / 405 方法不允许 / 404 接口不存在 / 500 兜底；
2. 追加要求：把 `handleBiz` 里的 `log.warn` 改成 `log.error`，观察项目日志文件里的**错误级别统计**，理解「错级别导致误报警」的成本；
3. 思考题：如果一个接口内部调用了另一个接口，被调用方抛了 `BizException`，会不会被本处理器捕获？（提示：`@RestControllerAdvice` 只切 Controller 层，Service 层向上冒泡到 Controller 时才会被捕获）。

#### 小结（3 分钟）
一句话回顾：**8 个分支、warn/error 两级别、Throwable 放最后、404 需两行配置。** 但这些还不够——生产环境的日志不能只打控制台，要按天滚动、要压缩、要脱敏、要区分 CONSOLE/FILE/ASYNC 三个通道。下一课时用 `logback-spring.xml` 把日志侧的生产级配置一次性打死。

### 2.4 板书设计
```
┌────────────────────────────────────────────────────────────────┐
│  Day07-02  异常处理器分派矩阵                                  │
├─────────────────────────────┬──────────┬───────┬───────────────┤
│  异常类型                   │  code    │ 级别  │  说明         │
├─────────────────────────────┼──────────┼───────┼───────────────┤
│  BizException               │ 自带     │ warn  │ 业务预期错误  │
│  MethodArgumentNotValid     │ 400      │ warn  │ @RequestBody  │
│  ConstraintViolation        │ 400      │ warn  │ Query 校验    │
│  MissingServletRequestParam │ 400      │ warn  │ 缺必填参数    │
│  HttpRequestMethodNotSupp   │ 405      │ warn  │ GET/POST 错   │
│  DuplicateKeyException      │ 409      │ warn  │ 唯一键冲突    │
│  NoHandlerFoundException    │ 404      │ warn  │ URL 不存在    │
│  Throwable  ← 放最后        │ 500      │ error │ 兜底 + 完整栈 │
└─────────────────────────────┴──────────┴───────┴───────────────┘

  匹配顺序口诀：具体 → 抽象、业务 → 系统、warn → error

  404 两行必配：
    spring.web.resources.add-mappings: false
    spring.mvc.throw-exception-if-no-handler-found: true

  三大禁忌：
    ① 处理器里再抛异常
    ② Throwable 放最前
    ③ 正常路径 log.error
```

### 2.5 课后作业
1. **必做**：完成 8 分支全局异常处理器，覆盖上述矩阵，提交 5 张 Postman 截图 + IDEA 控制台日志片段；
2. **必做**：新增一条 `@ExceptionHandler(MethodArgumentTypeMismatchException.class)`（前端把字符串传给 Long 类型 PathVariable 会触发），返回 code 400 提示「参数类型错误」；
3. **挑战**：给 `GlobalExceptionHandler` 加 `basePackages = "com.yinxiang.controller.open"` 属性，仅切公开接口。再写一个 `AdminGlobalExceptionHandler` 切 `admin` 包，两处返回不同 message 前缀（如「[对外接口]」「[管理后台]」），观察两个处理器互不干扰。

### 2.6 教学反思提示
- 8 个分支现场敲代码时间紧，讲师可**提前把 import 复制到剪贴板**，节省 IDE 自动导包的时间；
- 学生最容易漏 `spring.mvc.throw-exception-if-no-handler-found: true`，导致 404 依旧返回白页——示例演示时讲师**故意只加第一行**，触发一次让学生找 bug；
- 若课堂时间紧，`ConstraintViolationException` 和 `MissingServletRequestParameterException` 两个分支可以合并到「兜底 400」一起讲，重点保住 `handleBiz / handleValid / handle404 / handleAll` 四个核心。

---

## 第 3 课时：Logback 生产配置 + 打印规范 + AI 生成异常处理骨架

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能对比 `application.yml` 快速调优 vs `logback-spring.xml` 精细控制的差异，并说出两者的选择场景；
2. 能编写 `logback-spring.xml`，包含 CONSOLE / FILE / ASYNC 三个 appender，实现按天滚动 + 单文件 50MB 切分 + 保留 30 天 + `.gz` 压缩；
3. 能背出「打印规范三条纪律」——参数化日志、最外层打栈、敏感字段脱敏；
4. 能列出「必须打的字段」（traceId、userId、耗时、入参摘要）和「绝对不能打的字段」（密码、身份证、Token、完整手机号）；
5. 能预告请求日志切面（`@Around` 打入参出参耗时）的目标形态，理解「AOP 在 Day09 才实现，本课时只画图」；
6. 能用给定的 AI 提示词模板，让通义灵码一次性生成 8 分支异常处理器骨架，并识别 AI 输出的 3 个常见遗漏。

#### 3.1.2 过程与方法目标
1. 通过「先画三个 appender 的日志流向图，再逐个 XML 元素对应到图上」，训练「图 → 配置」的双向映射能力；
2. 通过「让 AI 生成后手工审查」的流程，训练「不迷信 AI 输出」的工程判断力。

### 3.2 教学重难点
- **重点**：三个 appender 的角色分工（CONSOLE 开发调试 / FILE 生产落盘 / ASYNC 异步不阻塞业务线程）／`<springProperty>` 从 `spring.application.name` 取变量／`SizeAndTimeBasedRollingPolicy` 双维度滚动／`<springProfile>` 区分 dev/prod
- **难点**：为什么文件名必须叫 `logback-spring.xml` 而不是 `logback.xml`（前者才能识别 `<springProfile>`）／ASYNC appender 的 `queueSize` 与 `discardingThreshold` 配置意义／敏感字段脱敏为什么不能只在日志层做（应该在业务层就脱敏后传入）

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
讲师投影生产事故新闻标题：「某公司日志里明文存了 xxx 万用户手机号，被安全部门通报」。抛问：**「你的代码里 `log.info("会员登录：{}", user)` 会不会把整个 user 对象序列化后打出来？会不会有身份证、手机号、Token？」** 抽 2 位学生上台，投影他们 Day06 的 Service 代码，全班一起找「敏感字段泄露」——多半能找出至少 1 处。讲师接话：「今天我们把日志侧的生产规范一次性打死。」

#### 新知讲授（16 分钟）

1. **application.yml 快速调优 vs logback-spring.xml 精细控制**（4 分钟）：投影对比表。
   - `application.yml` 适用场景：小项目、只需控制台 + 单文件、不需要按环境切换配置；
   - `logback-spring.xml` 适用场景：需要多 appender、需要按 profile 区分 dev/prod、需要 ASYNC 异步、需要单独把 ERROR 输出到独立文件、需要复杂过滤器。
   - **本项目选后者**——印想瑜伽会馆要上生产，日志规范就是运维底裤。

2. **三个 appender 的日志流向**（6 分钟）：讲师板书画流向图。
   - **CONSOLE**：开发环境用，控制台带颜色，输出到 stdout，Docker 场景直接被 `docker logs` 抓走；
   - **FILE**：生产环境主战场，落盘到 `logs/yinxiang.log`，用 `SizeAndTimeBasedRollingPolicy` 按天 + 按大小双维度切分，`.gz` 压缩，保留 30 天；
   - **ASYNC**：包装 FILE，把「写磁盘」这个 I/O 操作从业务线程移到独立日志线程，`queueSize=512`，`discardingThreshold=0`（队列满时不丢弃，宁可阻塞也要保住日志）；
   - **`<root>` 层级**：`level=INFO`，同时挂 CONSOLE 与 ASYNC（不直接挂 FILE，因为 FILE 已经被 ASYNC 包住）。

3. **打印规范三条纪律**（4 分钟）：
   - **纪律一 参数化日志**：`log.info("会员新增 name={} phone={}", name, phone)`，禁用 `+` 字符串拼接，理由是级别不够时不做参数解析、性能与安全双赢；
   - **纪律二 最外层打栈**：只有 `GlobalExceptionHandler.handleAll` 用 `log.error("[系统异常]", e)` 打完整栈，Service / Mapper / Controller 全部禁止 `log.error(e)`，避免同一异常打 5 遍栈；
   - **纪律三 敏感字段脱敏**：手机号 `138****0001`、身份证 `110***********1234`、密码/Token/AK/SK 一律不落盘。**脱敏工具类放 `yoga-common`**，Service 调 `SensitiveUtil.maskPhone(phone)` 后再传入日志。

4. **请求日志切面预告**（2 分钟）：讲师画目标日志片段——

   ```text
   2026-07-18 14:22:31.412 INFO  c.y.log.LogAspect - [进入] POST /members ip=127.0.0.1 body={"name":"张小雅","phone":"138****0001"}
   2026-07-18 14:22:31.548 INFO  c.y.log.LogAspect - [响应] POST /members cost=136ms {"code":0,"message":"OK","data":null}
   ```

   **只画目标形态，不写代码**。`@Around` 切面实现在 Day09 讲，本课时只是「画个饼」，让学生知道「重复的日志代码不用写在每个 Controller 里」。

#### 示例演示（13 分钟）

1. **写 logback-spring.xml**（8 分钟）：讲师在 `src/main/resources/logback-spring.xml` 现场敲。投影：

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <configuration>
     <springProperty name="APP" source="spring.application.name" defaultValue="yinxiang"/>
     <property name="LOG_DIR" value="logs"/>
     <property name="PATTERN"
               value="%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n"/>

     <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
       <encoder><pattern>${PATTERN}</pattern></encoder>
     </appender>

     <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
       <file>${LOG_DIR}/${APP}.log</file>
       <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
         <fileNamePattern>${LOG_DIR}/${APP}.%d{yyyy-MM-dd}.%i.log.gz</fileNamePattern>
         <maxFileSize>50MB</maxFileSize>
         <maxHistory>30</maxHistory>
         <totalSizeCap>5GB</totalSizeCap>
       </rollingPolicy>
       <encoder><pattern>${PATTERN}</pattern></encoder>
     </appender>

     <appender name="ASYNC" class="ch.qos.logback.classic.AsyncAppender">
       <queueSize>512</queueSize>
       <discardingThreshold>0</discardingThreshold>
       <neverBlock>false</neverBlock>
       <appender-ref ref="FILE"/>
     </appender>

     <root level="INFO">
       <appender-ref ref="CONSOLE"/>
       <appender-ref ref="ASYNC"/>
     </root>

     <logger name="com.yinxiang" level="DEBUG"/>
     <logger name="org.mybatis" level="DEBUG"/>

     <springProfile name="prod">
       <logger name="com.yinxiang" level="INFO"/>
       <logger name="org.mybatis" level="INFO"/>
     </springProfile>
   </configuration>
   ```

   讲师现场演示——启动项目、`logs/` 目录出现 `yinxiang.log`、故意打 100 条 `log.info` 观察文件是否有内容、把系统时间改成明天再启动一次看看是否生成 `.log.gz` 压缩包。

2. **敏感字段脱敏工具类**（3 分钟）：现场写 `SensitiveUtil`：

   ```java
   package com.yinxiang.common;

   public class SensitiveUtil {

       public static String maskPhone(String phone) {
           if (phone == null || phone.length() < 11) return phone;
           return phone.substring(0, 3) + "****" + phone.substring(7);
       }

       public static String maskIdCard(String idCard) {
           if (idCard == null || idCard.length() < 15) return idCard;
           return idCard.substring(0, 3) + "***********" + idCard.substring(idCard.length() - 4);
       }
   }
   ```

   把 `MemberService` 里的 `log.info("[会员新增] phone={}", phone)` 改为 `log.info("[会员新增] phone={}", SensitiveUtil.maskPhone(phone))`，观察日志文件里的手机号变成 `138****0001`。

3. **AI 一次生成异常处理骨架**（2 分钟）：投影 AI 提示词模板：

   ```
   我需要一个 Spring Boot 4.0.x 项目的 @RestControllerAdvice，捕获以下异常并统一返回 Result<Void>：
   1. 自定义 BizException(int code, String message)——用其 code 与 message
   2. MethodArgumentNotValidException——拼接字段级错误，code 400
   3. ConstraintViolationException——同上
   4. MissingServletRequestParameterException——code 400
   5. HttpRequestMethodNotSupportedException——code 405
   6. DuplicateKeyException——code 409
   7. NoHandlerFoundException——code 404
   8. Throwable 兜底——code 500，log.error 打完整栈
   要求：类名 GlobalExceptionHandler，包 com.yinxiang.common，日志用 @Slf4j。
   业务/客户端错误用 log.warn，系统错误用 log.error。
   ```

   把提示词贴给通义灵码，收到输出后**当堂检查 3 个常见遗漏**：
   - ① 有没有把 `Throwable` 放最后？
   - ② 有没有把日志级别搞混（比如 handleBiz 用了 `log.error`）？
   - ③ 有没有漏 `NoHandlerFoundException` 处理，或漏了 `application.yml` 里的两行 404 配置说明？

#### 课堂练习（10 分钟）
1. 每位学生完成 `logback-spring.xml` 落地 + `SensitiveUtil` 工具类，确保 `logs/yinxiang.log` 里手机号全部脱敏；
2. 追加要求：在 `logback-spring.xml` 里再加一个 `ERROR_FILE` appender，只落 ERROR 级别日志到 `logs/error.log`，供运维单独告警订阅；
3. 思考题：ASYNC appender 的 `queueSize=512` 满了怎么办？`discardingThreshold=0` 和 `neverBlock=false` 联合起来意味着什么？（提示：队列满时业务线程会阻塞在打日志这一步，宁可业务慢一点也不丢日志——这是金融/支付类系统的通用取舍）。

#### 小结（3 分钟）
一句话回顾：**三个 appender 分工、三条打印纪律、一份 AI 提示词模板。** 至此 ch13 的四大件（Result / BizException / 全局异常处理器 / Logback）全部落地，后端接口的「底裤」齐了。下一课时进入 ch14——用「教练模块」把前面所有铺垫（DTO 分层、双重唯一性校验、Result、BizException、软删除）巩固一遍。

### 3.4 板书设计
```
┌──────────────────────────────────────────────────────────────┐
│  Day07-03  三个 Appender 的日志流向                          │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│    log.info("[会员新增] phone={}",                           │
│              SensitiveUtil.maskPhone(phone))                 │
│                     │                                        │
│                     ▼                                        │
│              ┌────────────┐                                  │
│              │ Logger 分发 │                                  │
│              └─────┬──────┘                                  │
│                    │                                         │
│         ┌──────────┼───────────┐                             │
│         ▼                      ▼                             │
│  ┌──────────────┐       ┌──────────────┐                     │
│  │  CONSOLE     │       │  ASYNC       │                     │
│  │  开发环境    │       │  queueSize   │                     │
│  │  stdout      │       │  =512        │                     │
│  │  彩色输出    │       └──────┬───────┘                     │
│  └──────────────┘              │                             │
│                                ▼                             │
│                         ┌──────────────┐                     │
│                         │  FILE        │                     │
│                         │  按天滚动    │                     │
│                         │  50MB 切分   │                     │
│                         │  保留 30 天  │                     │
│                         │  .gz 压缩    │                     │
│                         └──────────────┘                     │
│                                                              │
│  打印三纪律：                                                │
│    ① 参数化 log.info("{} {}", a, b)                          │
│    ② 只在最外层 handleAll 打完整栈                           │
│    ③ 敏感字段脱敏（phone / idCard / token / password）       │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成 `logback-spring.xml` 三 appender 配置 + `SensitiveUtil` 工具类，提交 `logs/` 目录截图 + 一段脱敏后的日志文本；
2. **必做**：把 Day06 会员 Service 里所有 `log.info` / `log.warn` 一次性走查，任何含 `phone` / `idCard` 的字段全部换成脱敏调用；
3. **挑战**：给 `logback-spring.xml` 增加一个「按业务模块拆分日志」的思路——`com.yinxiang.member` 落到 `member.log`、`com.yinxiang.coach` 落到 `coach.log`。用 `<logger>` + `additivity="false"` 组合实现，并在博客里写一篇复盘。

### 3.6 教学反思提示
- 学生最容易踩「文件名写成 logback.xml」的坑，导致 `<springProfile>` 不生效——讲师**故意先起错名字**让学生自己发现；
- ASYNC 的三个参数（`queueSize` / `discardingThreshold` / `neverBlock`）如果时间紧可以只讲 `queueSize=512`，另外两个说「保持默认，参考文档」即可；
- AI 生成骨架后的 3 个常见遗漏，讲师最好**当堂让学生也跑一遍**同样的提示词，对比不同学生的通义灵码给出的差异——这本身就是「AI 输出不稳定」的活教材。

---

## 第 4 课时：教练模块——tb_coach 表设计 + DTO 分层 + 双重唯一性校验

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能说出「为什么教练模块和教室模块要放在同一天讲」——都是资源型主数据，结构对称，训练模板化思维；
2. 能设计 tb_coach 表（13 个字段），并说明 `phone` `id_card` 为什么要建 UNIQUE 且必须带 `deleted` 字段联合唯一；
3. 能编写 `CoachAddDTO` `CoachUpdateDTO` `CoachQueryDTO` 三分层 DTO，理解「新增不带 id、修改必须带 id、查询字段全可选」的分层原则；
4. 能实现「先 SQL 查一次 → 再靠数据库 UNIQUE 兜底」的双重唯一性校验，理解为什么要两道防线；
5. 能画出「双重唯一性校验的执行流程图」，标注 3 个可能的分岔点（SQL 命中抛 BizException、SQL 未命中 + insert 冲突走 DuplicateKeyException、并发插入两条同 phone 的时序）。

#### 4.1.2 过程与方法目标
1. 通过「先画表 ER 图再敲 DDL、先画 DTO 分层图再敲代码」的顺序，训练「模型先行」的开发习惯；
2. 通过「并发插入两条同手机号」的时序推演，训练「先设想并发场景再写校验」的服务端思维。

### 4.2 教学重难点
- **重点**：tb_coach 字段（尤其是 phone / id_card 两个唯一键 + deleted 联合唯一）／DTO 三分层的字段差异（AddDTO 不带 id、UpdateDTO 必带 id、QueryDTO 全可选 + 分页参数）／双重唯一性校验的两道防线
- **难点**：为什么 UNIQUE 必须带 `deleted`（软删除后同手机号可以再注册）／SQL 层查一次的意义（不加也能靠数据库兜住，但给用户的错误提示不友好）／并发场景下双重校验依然可能失败，最终必须靠数据库

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
讲师投影两张 GitHub 仓库截图——一张来自去年学生做的项目，教练模块 500 行代码；另一张来自今年优秀学生的项目，教练模块 200 行代码，教室模块 180 行代码，两者结构几乎一样。抛问：**「同样的功能，为什么代码量差 2 倍？」** 抽学生回答，引导到「教练和教室结构对称，可以用同一份模板批量生成」。

讲师接话：「今天我们花一节课把教练模块的表 + DTO + 双重校验打死，下一节课把 Mapper + Controller 也打死，然后第 6 节课**用同一份 AI 提示词一次性把教室模块也生出来**——你会发现，你的代码量真的能减半。」

#### 新知讲授（15 分钟）

1. **为什么把两个模块放一起**（3 分钟）：讲师板书两张表结构对比：
   - **相同点**：都是资源型主数据、都有名称/状态/软删除/时间戳、都被后续课程模块引用、都需要分页搜索；
   - **不同点**：教练涉及个人身份（phone + id_card 双唯一），教室涉及物理属性（capacity 有上限、hourly_rate 是金额）。
   - **结论**：**结构对称的模块用同一份模板批量生成，是训练模板化思维的最佳时机**。

2. **tb_coach 表设计**（6 分钟）：讲师投影 DDL 并逐字段解读：

   ```sql
   CREATE TABLE tb_coach (
     id           BIGINT       PRIMARY KEY AUTO_INCREMENT,
     name         VARCHAR(50)  NOT NULL COMMENT '姓名',
     phone        VARCHAR(20)  NOT NULL COMMENT '手机号',
     id_card      VARCHAR(20)  NOT NULL COMMENT '身份证号',
     gender       TINYINT      DEFAULT 0 COMMENT '性别 0 未知 1 女 2 男',
     birthday     DATE                  COMMENT '出生日期',
     level        TINYINT      DEFAULT 1 COMMENT '教练等级 1 初级 2 中级 3 高级 4 首席',
     hire_date    DATE                  COMMENT '入职日期',
     intro        TEXT                  COMMENT '简介',
     avatar_url   VARCHAR(255)          COMMENT '头像 URL',
     status       TINYINT      DEFAULT 1 COMMENT '状态 1 在职 2 休假 3 离职',
     deleted      TINYINT      DEFAULT 0 COMMENT '软删除 0 未删 1 已删',
     create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
     update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     UNIQUE KEY uk_phone_deleted   (phone,   deleted),
     UNIQUE KEY uk_id_card_deleted (id_card, deleted)
   ) COMMENT '教练';
   ```

   讲师**抽学生**回答：「为什么 UNIQUE 要带 `deleted`？」引导出答案——软删除后 `deleted=1`，同一手机号新加一条 `deleted=0` 的记录也不冲突，业务上「离职再入职」的场景就能成立。**再抽一位**回答：「gender 用 TINYINT 而不是 CHAR('M'/'F')，为什么？」引导到「存储省 3 字节 + 数据库索引效率高，前端展示时用字典转文字」。

3. **DTO 三分层设计**（4 分钟）：讲师板书三个类的字段差异对比表：

   | 字段 | CoachAddDTO | CoachUpdateDTO | CoachQueryDTO |
   |------|-------------|----------------|---------------|
   | id | 不带 | @NotNull 必带 | 不带 |
   | name | @NotBlank | @NotBlank | 可选（模糊） |
   | phone | @NotBlank + @Pattern | @NotBlank + @Pattern | 可选（模糊） |
   | id_card | @NotBlank + @Pattern | @NotBlank + @Pattern | 不带 |
   | status | 可选（默认 1） | 可选 | 可选（精确匹配） |
   | pageNum / pageSize | 无 | 无 | 必带（默认 1 / 10） |

   讲师口播口诀：**「新增不带 id、修改必带 id、查询全可选加分页。」**

4. **双重唯一性校验的两道防线**（2 分钟）：
   - **第一道 SQL 查一次**：`existsByPhone(phone, excludeId)` `existsByIdCard(idCard, excludeId)`，命中就抛 `BizException("手机号已被占用")`——**用户友好**；
   - **第二道 数据库 UNIQUE**：即使 SQL 查完的瞬间另一个线程刚好插了同手机号，数据库还是会挡下，抛 `DuplicateKeyException`，被全局异常处理器捕获转成 `Result.fail(409, "数据已存在")`——**并发兜底**；
   - **两道防线缺一不可**：只有第一道，并发一来就崩；只有第二道，用户体验差（只知道「已存在」不知道是手机号还是身份证）。

#### 示例演示（14 分钟）

1. **执行 DDL 建表**（3 分钟）：讲师在 Navicat / DBeaver 里执行上面的 CREATE TABLE，插入 3 条种子数据：

   ```sql
   INSERT INTO tb_coach (name, phone, id_card, gender, birthday, level, hire_date, status) VALUES
    ('李教练','13800138010','110101199001011234',1,'1990-01-01',2,'2022-03-15',1),
    ('王教练','13800138011','110101198805052345',2,'1988-05-05',3,'2020-06-01',1),
    ('张教练','13800138012','110101199512124567',1,'1995-12-12',1,'2024-01-10',1);
   ```

   顺便演示：`SELECT * FROM tb_coach` 观察 create_time / update_time 自动填充。

2. **写三个 DTO**（8 分钟）：讲师现场敲 `CoachAddDTO`：

   ```java
   package com.yinxiang.coach.dto;

   import jakarta.validation.constraints.*;
   import lombok.Data;
   import java.time.LocalDate;

   @Data
   public class CoachAddDTO {

       @NotBlank @Size(max = 50)
       private String name;

       @NotBlank
       @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
       private String phone;

       @NotBlank
       @Pattern(regexp = "^\\d{17}[\\dXx]$", message = "身份证号格式不正确")
       private String idCard;

       @Min(0) @Max(2)
       private Integer gender;

       private LocalDate birthday;

       @Min(1) @Max(4)
       private Integer level;

       private LocalDate hireDate;

       @Size(max = 2000)
       private String intro;

       @Size(max = 255)
       private String avatarUrl;

       @Min(1) @Max(3)
       private Integer status;
   }
   ```

   然后**只讲差异**，快速敲 `CoachUpdateDTO`（多一个 `@NotNull Long id`）和 `CoachQueryDTO`（字段全去掉 `@NotBlank`，加 `Integer pageNum = 1; Integer pageSize = 10;`）。

3. **Service 双重校验骨架**（3 分钟）：讲师现场敲 `CoachService.add` 方法：

   ```java
   @Service
   @RequiredArgsConstructor
   @Slf4j
   public class CoachService {
       private final CoachMapper mapper;

       public void add(CoachAddDTO dto) {
           if (mapper.existsByPhone(dto.getPhone(), null) > 0) {
               throw new BizException("手机号已被占用");
           }
           if (mapper.existsByIdCard(dto.getIdCard(), null) > 0) {
               throw new BizException("身份证号已被占用");
           }
           Coach c = new Coach();
           BeanUtils.copyProperties(dto, c);
           if (c.getStatus() == null) c.setStatus(1);
           mapper.insert(c);
           log.info("[教练新增] name={} phone={}", c.getName(),
                   SensitiveUtil.maskPhone(c.getPhone()));
       }
   }
   ```

   讲师**故意在双重校验后并不等待**，直接演示：先在 IDEA 里打断点在 `mapper.insert(c)` 前一行，Postman 触发一次请求让线程停住，再从 Navicat 里手动 `INSERT` 同一手机号 → 松开断点让 `mapper.insert` 继续 → 观察 `DuplicateKeyException` 被全局处理器接住转成 409。**这是本节课的高光时刻**，让学生亲眼看到「第二道防线怎么救回并发」。

#### 课堂练习（8 分钟）
1. 每位学生完成 tb_coach 建表 + 三个 DTO 落地 + Service.add 骨架，Postman 触发一次「手机号重复」和一次「身份证重复」的 BizException；
2. 追加要求：把 tb_coach 里的 `deleted=1` 改成 `deleted=0` 手工制造脏数据（同一手机号两条 `deleted=0` 的记录）后，`existsByPhone` 会返回什么值？如果不带 `deleted` 条件的 UNIQUE 又会怎样？
3. 思考题：如果我把 `existsByPhone` 的 SQL 写成 `SELECT id FROM tb_coach WHERE phone=#{phone}`，忘记加 `AND deleted=0`，会有什么后果？

#### 小结（3 分钟）
一句话回顾：**tb_coach 双唯一键 + DTO 三分层 + 双重唯一性校验两道防线。** 表和 DTO 齐了，但 Mapper 的分页 SQL、Controller 的 6 个 REST 端点还没落地——下一课时把剩下的骨架一次性打完。

### 4.4 板书设计
```
┌──────────────────────────────────────────────────────────────┐
│  Day07-04  tb_coach 表结构 + DTO 三分层                      │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────── tb_coach ────────────┐                        │
│  │ id            BIGINT  PK         │                        │
│  │ name          VARCHAR(50)  NN    │                        │
│  │ phone         VARCHAR(20)  NN ★  │  UNIQUE(phone,deleted) │
│  │ id_card       VARCHAR(20)  NN ★  │  UNIQUE(id_card,       │
│  │                                  │         deleted)       │
│  │ gender        TINYINT            │                        │
│  │ birthday      DATE               │                        │
│  │ level         TINYINT  1-4       │                        │
│  │ hire_date     DATE               │                        │
│  │ intro         TEXT               │                        │
│  │ avatar_url    VARCHAR(255)       │                        │
│  │ status        TINYINT  1-3       │                        │
│  │ deleted       TINYINT  0/1       │                        │
│  │ create_time   DATETIME           │                        │
│  │ update_time   DATETIME           │                        │
│  └──────────────────────────────────┘                        │
│                                                              │
│  DTO 分层：                                                  │
│    CoachAddDTO      不带 id，字段全 @NotBlank/@NotNull       │
│    CoachUpdateDTO   带 id (@NotNull)，其余同 Add             │
│    CoachQueryDTO    全字段可选，加 pageNum/pageSize          │
│                                                              │
│  双重唯一性校验：                                            │
│    第一道 SQL       existsByPhone/IdCard → BizException      │
│    第二道 数据库    UNIQUE → DuplicateKeyException → 409     │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 tb_coach 建表 + 3 个 DTO + `CoachService.add` 骨架，Postman 触发一次 BizException 一次 DuplicateKeyException，交 3 张截图；
2. **必做**：用通义灵码提示词「帮我给 CoachAddDTO 生成 30 条边界值测试数据（10 条合法、10 条 phone 非法、10 条 id_card 非法）」，观察 AI 生成的 JSON 数组是否可以直接粘到 Postman；
3. **挑战**：读文档，把 `id_card` 的 `@Pattern` 换成能校验校验码位（第 18 位）的完整正则，或者用 Bean Validation 的 `@Constraint` 自定义注解 `@IdCard`。

### 4.6 教学反思提示
- 学生最容易漏 UNIQUE 的 `deleted` 字段——**讲师故意先建表不带 deleted**，然后软删一条数据、再次插入同手机号，让学生亲眼看到「唯一键冲突」，再重建表加上 `deleted`；
- 演示并发场景的断点技巧需要课前彩排 1 次，否则容易翻车（断点位置错、线程挂死）；
- DTO 三分层如果学生质疑「为什么不用一个 DTO 全部字段可选」，讲师回答：**「一个 DTO 意味着 Add 场景可以传 id、Update 场景可以不传 id——校验直接失效。」**

---

## 第 5 课时：教练 Mapper 关键 SQL + Controller 完整实现

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能编写 `CoachMapper.xml` 的 5 个关键 SQL：`selectPage`（带 keyword 模糊 + status 精确 + 分页 + 排序）、`existsByPhone` `existsByIdCard`（带 excludeId 排除自身）、`softDeleteById`（逻辑删除 update deleted=1）、`selectById`；
2. 能实现 `CoachService` 的 5 个方法：`add / update / deleteById / page / getById`，全部走 BizException 而非返回 Result；
3. 能设计 `CoachController` 的 6 个 REST 端点：`POST /coaches`、`PUT /coaches/{id}`、`DELETE /coaches/{id}`、`GET /coaches/{id}`、`GET /coaches`（分页）、`GET /coaches/available`（供 Day08 排课用）；
4. 能画出 6 个端点的「URL + HTTP 方法 + 请求参数 + 返回类型」四列表格，作为 Day08 前端联调的接口契约；
5. 能理解并解释「逻辑删除后 `selectPage` 必须加 `deleted=0` 过滤」的原因。

#### 5.1.2 过程与方法目标
1. 通过「一次性画完 6 端点表格再动手写代码」的顺序，训练「先契约后实现」的接口设计习惯；
2. 通过「让学生上台改一个 SQL 参数并预测结果」的互动，训练边写边验证的动态思维。

### 5.2 教学重难点
- **重点**：`<where>` 标签自动去掉前导 AND / `<if>` 条件模糊查询 / `existsByX(value, excludeId)` 的 `excludeId != null` 分支 / 6 端点契约 / 逻辑删除的 SQL 写法
- **难点**：`selectPage` 的排序字段防注入（不能直接拼 `#{orderBy}` 到 ORDER BY，要 whitelist）／`available` 端点为什么单独一个（Day08 排课时只需要 in 职教练精简字段，不需要分页）／PageHelper 的 `PageHelper.startPage(pageNum, pageSize)` 必须紧贴 Mapper 调用之前

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
讲师投影上节课学生的作业——多半只写了 `add` 方法，`page` `update` `delete` 全没写。抛问：**「一个模块从『Service 有 add』到『Controller 6 端点齐全』还差多远？」** 抽学生估算行数，引导到「Mapper.xml 大概 50 行、Service 剩余方法 30 行、Controller 6 端点 40 行，合计 120 行——一节课刚好写完」。

#### 新知讲授（14 分钟）

1. **6 端点契约表**（4 分钟）：讲师板书 6 行契约，让学生**先看再写**：

   | # | HTTP | URL | 请求参数 | 返回 | 备注 |
   |---|------|-----|----------|------|------|
   | 1 | POST | /coaches | CoachAddDTO (body) | Result<Void> | 新增，双重唯一校验 |
   | 2 | PUT | /coaches/{id} | CoachUpdateDTO (body) | Result<Void> | 修改，唯一校验带 excludeId |
   | 3 | DELETE | /coaches/{id} | id (path) | Result<Void> | 软删除 |
   | 4 | GET | /coaches/{id} | id (path) | Result<CoachVO> | 详情 |
   | 5 | GET | /coaches | CoachQueryDTO (query) | Result<PageResult<CoachVO>> | 分页 + 搜索 |
   | 6 | GET | /coaches/available | 无 | Result<List<CoachSimpleVO>> | 供排课用，精简字段 |

   讲师口播：**「6 个端点是资源型模块的标准公式，后面教室 6 个、Day08 课程 6 个、Day09 订单 6 个，全都是这个套路。」**

2. **Mapper.xml 关键 SQL 解构**（6 分钟）：讲师现场敲：

   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
           "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
   <mapper namespace="com.yinxiang.coach.mapper.CoachMapper">

     <select id="selectPage" resultType="com.yinxiang.coach.vo.CoachVO">
       SELECT id, name, phone, id_card AS idCard, gender, birthday,
              level, hire_date AS hireDate, intro, avatar_url AS avatarUrl,
              status, create_time AS createTime
       FROM tb_coach
       <where>
         deleted = 0
         <if test="keyword != null and keyword != ''">
           AND (name  LIKE CONCAT('%', #{keyword}, '%')
             OR phone LIKE CONCAT('%', #{keyword}, '%'))
         </if>
         <if test="status != null">AND status = #{status}</if>
         <if test="level  != null">AND level  = #{level}</if>
       </where>
       ORDER BY id DESC
     </select>

     <select id="existsByPhone" resultType="int">
       SELECT COUNT(*) FROM tb_coach
       WHERE phone = #{phone} AND deleted = 0
       <if test="excludeId != null">AND id != #{excludeId}</if>
     </select>

     <select id="existsByIdCard" resultType="int">
       SELECT COUNT(*) FROM tb_coach
       WHERE id_card = #{idCard} AND deleted = 0
       <if test="excludeId != null">AND id != #{excludeId}</if>
     </select>

     <update id="softDeleteById">
       UPDATE tb_coach SET deleted = 1 WHERE id = #{id} AND deleted = 0
     </update>

     <select id="selectAvailable" resultType="com.yinxiang.coach.vo.CoachSimpleVO">
       SELECT id, name, level FROM tb_coach WHERE deleted = 0 AND status = 1
     </select>
   </mapper>
   ```

   讲师**抽学生**回答：「`<where>` 标签的作用是什么？」引导到「自动去掉第一个 `<if>` 前的 AND、自动去掉整个块前的 WHERE 关键字（如果所有 `<if>` 都不命中）」。

3. **Controller 6 端点写法**（4 分钟）：讲师投影骨架代码，逐行讲：

   ```java
   @Slf4j
   @RestController
   @RequestMapping("/coaches")
   @RequiredArgsConstructor
   public class CoachController {

       private final CoachService service;

       @PostMapping
       public Result<Void> add(@RequestBody @Valid CoachAddDTO dto) {
           service.add(dto);
           return Result.ok();
       }

       @PutMapping("/{id}")
       public Result<Void> update(@PathVariable Long id,
                                   @RequestBody @Valid CoachUpdateDTO dto) {
           dto.setId(id);
           service.update(dto);
           return Result.ok();
       }

       @DeleteMapping("/{id}")
       public Result<Void> delete(@PathVariable Long id) {
           service.deleteById(id);
           return Result.ok();
       }

       @GetMapping("/{id}")
       public Result<CoachVO> getById(@PathVariable Long id) {
           return Result.ok(service.getById(id));
       }

       @GetMapping
       public Result<PageResult<CoachVO>> page(CoachQueryDTO query) {
           return Result.ok(service.page(query));
       }

       @GetMapping("/available")
       public Result<List<CoachSimpleVO>> available() {
           return Result.ok(service.listAvailable());
       }
   }
   ```

   讲师**故意**在 `update` 端点上把 `dto.setId(id)` 写漏，Postman 触发一次 PUT，让学生看到「Service 里 dto.getId() == null 抛 BizException」，再补上这行。

#### 示例演示（14 分钟）

1. **Service 剩余方法完整实现**（6 分钟）：

   ```java
   @Service
   @RequiredArgsConstructor
   @Slf4j
   public class CoachService {
       private final CoachMapper mapper;

       public void update(CoachUpdateDTO dto) {
           if (dto.getId() == null) throw new BizException("id 不能为空");
           if (mapper.existsByPhone(dto.getPhone(), dto.getId()) > 0)
               throw new BizException("手机号已被其它教练占用");
           if (mapper.existsByIdCard(dto.getIdCard(), dto.getId()) > 0)
               throw new BizException("身份证号已被其它教练占用");
           Coach c = new Coach();
           BeanUtils.copyProperties(dto, c);
           int rows = mapper.updateById(c);
           if (rows == 0) throw new BizException("教练不存在或已离职");
           log.info("[教练修改] id={}", dto.getId());
       }

       public void deleteById(Long id) {
           int rows = mapper.softDeleteById(id);
           if (rows == 0) throw new BizException("教练不存在或已删除");
           log.info("[教练软删] id={}", id);
       }

       public CoachVO getById(Long id) {
           CoachVO vo = mapper.selectById(id);
           if (vo == null) throw new BizException(404, "教练不存在");
           return vo;
       }

       public PageResult<CoachVO> page(CoachQueryDTO query) {
           PageHelper.startPage(query.getPageNum(), query.getPageSize());
           List<CoachVO> list = mapper.selectPage(query);
           PageInfo<CoachVO> pi = new PageInfo<>(list);
           return new PageResult<>(pi.getTotal(), pi.getList());
       }

       public List<CoachSimpleVO> listAvailable() {
           return mapper.selectAvailable();
       }
   }
   ```

   讲师口播强调：**「`PageHelper.startPage` 必须紧贴下一行的 Mapper 调用——中间隔一行代码它可能就不生效。」**

2. **Postman 联调走一遍**（6 分钟）：讲师依次演示 6 个端点：
   - `POST /coaches` 传新教练数据 → 返回 `{"code":0,"message":"OK","data":null}`；
   - 再 POST 一次同手机号 → 返回 `{"code":500,"message":"手机号已被占用","data":null}`；
   - `GET /coaches?keyword=李&pageNum=1&pageSize=10` → 返回分页数据；
   - `PUT /coaches/1` 改名字 → 200 ok；
   - `DELETE /coaches/2` → 200 ok，再 GET 该 id → 返回 404 「教练不存在」；
   - `GET /coaches/available` → 返回精简字段列表。

   每次联调**抽学生上讲台**改一个参数（比如把 `pageSize` 改成 50、把 `keyword` 改成中文）预测结果，全班举手投票，再看实际返回。

3. **AI 生成 CoachController 对照**（2 分钟）：讲师投影提示词：

   ```
   基于 Spring Boot 4.0 + MyBatis + PageHelper 生成 CoachController，
   路径 /coaches，包含 POST 新增、PUT /{id} 修改、DELETE /{id} 软删、
   GET /{id} 详情、GET 分页搜索、GET /available 精简列表 六个端点。
   DTO 分层：CoachAddDTO / CoachUpdateDTO / CoachQueryDTO。
   Service 抛 BizException，Controller 统一返回 Result。
   ```

   把 AI 输出和手写版对照，**当堂圈出 AI 的 3 个常见问题**：① 把 update 方法的 id 参数漏在 PathVariable 里；② PageHelper.startPage 位置放错；③ available 端点写成分页版返回。

#### 课堂练习（11 分钟）
1. 每位学生完成 `CoachMapper.xml` + `CoachService` 剩余方法 + `CoachController` 6 端点，Postman 联调 6 个接口全绿；
2. 追加要求：给 `selectPage` 增加一个 `orderBy` 参数，允许前端传 `id_desc / hire_date_desc / level_desc` 三选一，用 `<choose>` 白名单方式实现（**禁止直接拼 `#{orderBy}` 到 ORDER BY，会 SQL 注入**）；
3. 思考题：`available` 端点为什么单独一个 URL？合并到 `GET /coaches?status=1&pageSize=999` 行不行？（提示：字段精简 + 语义明确 + 前端下拉框专用 + 无需分页）。

#### 小结（3 分钟）
一句话回顾：**Mapper 5 个 SQL、Service 5 个方法、Controller 6 个端点，配合上节课的 DTO 三分层，教练模块彻底完工。** 下一课时用**同一份 AI 提示词**把结构对称的教室模块也一次性生出来，然后做双模块联调剧本。

### 5.4 板书设计
```
┌────────────────────────────────────────────────────────────────────┐
│  Day07-05  Coach 6 端点 URL 表                                     │
├─────┬─────────┬───────────────────┬──────────────────┬─────────────┤
│  #  │ HTTP    │ URL               │ 参数             │ 返回        │
├─────┼─────────┼───────────────────┼──────────────────┼─────────────┤
│  1  │ POST    │ /coaches          │ AddDTO(body)     │ Result<V>   │
│  2  │ PUT     │ /coaches/{id}     │ UpdateDTO(body)  │ Result<V>   │
│  3  │ DELETE  │ /coaches/{id}     │ id(path)         │ Result<V>   │
│  4  │ GET     │ /coaches/{id}     │ id(path)         │ Result<VO>  │
│  5  │ GET     │ /coaches          │ QueryDTO(query)  │ Result<Page>│
│  6  │ GET     │ /coaches/available│ 无               │ Result<List>│
└─────┴─────────┴───────────────────┴──────────────────┴─────────────┘

  Mapper.xml 5 个 SQL：
    ① selectPage       <where>+<if> 分页搜索
    ② existsByPhone    带 excludeId 排除自身
    ③ existsByIdCard   同上
    ④ softDeleteById   UPDATE ... SET deleted=1
    ⑤ selectAvailable  status=1 精简字段

  Service 层约定：
    - 抛 BizException 而非 return Result.fail
    - PageHelper.startPage 紧贴 Mapper 调用
    - update 前双重校验带 excludeId=dto.getId()
```

### 5.5 课后作业
1. **必做**：完成 Coach Mapper/Service/Controller 全部代码，Postman 6 端点联调截图；
2. **必做**：给 `selectPage` 加白名单排序，允许 `id_desc / id_asc / hire_date_desc / level_desc` 四选一，其余值一律用默认 `id DESC`；
3. **挑战**：把 `PageResult<T>` 通用化——不用 PageHelper 的 `PageInfo`，改用手写 SQL `SELECT COUNT(*)` + `SELECT ... LIMIT`，思考两者的性能与可读性差异。

### 5.6 教学反思提示
- 学生最容易犯的错：`PageHelper.startPage` 和 `mapper.selectPage(query)` 中间隔了一行 `log.info` 导致分页失效——讲师现场演示这个坑；
- `existsByX` 的 `excludeId` 分支如果学生质疑「为什么 add 时传 null」，讲师回答：**「add 场景没有『排除自己』的需求，传 null 后 `<if excludeId != null>` 不命中，等于普通查询」**；
- 如果时间紧，`available` 端点可以留到 Day08 讲课程排课时再实现，本课时保住其余 5 端点是硬指标。

---

## 第 6 课时：教室模块 tb_room + AI 一次生成两模块 + 联调剧本

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能设计 tb_room 表（10 个字段），说明 `name` 唯一 + `capacity` 有物理上限 + `hourly_rate` 是 DECIMAL(10,2) 的原因；
2. 能编写 `RoomAddDTO` `RoomUpdateDTO` `RoomQueryDTO` 三分层 DTO，特别是 `capacity` 的 `@Min(1) @Max(100)` 与 `hourly_rate` 的 `@DecimalMin("0.00")`；
3. 能对比教练与教室两模块的 Service 差异——教室只需 `existsByName` 一个唯一校验，没有身份证；
4. 能写出 `RoomController` 6 个端点，端点命名与教练完全对称，只把 `/coaches` 换成 `/rooms`、返回类型换成 `RoomVO`；
5. 能使用「一次生成两模块」的 AI 提示词模板，让通义灵码同时输出 tb_coach 与 tb_room 全套代码，并识别 AI 的 5 个常见字段串味错误；
6. 能执行完整的双模块联调剧本（教练 3 步 + 教室 3 步 + 双模块交叉 2 步），并现场解释每一步的期望响应。

#### 6.1.2 过程与方法目标
1. 通过「让 AI 一次生成两模块，再和手写版对比」的实验，训练「AI 提效 + 人工审查」的协作模式；
2. 通过完整联调剧本演练，训练「按脚本走完流程 + 每步验证响应」的测试习惯。

### 6.2 教学重难点
- **重点**：tb_room 表结构（10 字段）／教室 DTO 特有校验（capacity 区间 + hourly_rate 精度）／Service 只需 name 唯一校验／RoomController 6 端点／AI 一次生成两模块的提示词模板
- **难点**：AI 生成时字段容易串味（tb_coach 的 phone 跑到 tb_room SQL 里）／`gender` `status` 用 TINYINT 存储 + 前端需要转文字（1→在职 2→休假 3→离职）／DuplicateKeyException 没 catch 会返回 500 而非 409（其实上节课已配全局，本课时再验证一遍）／逻辑删除后 SQL 忘加 `deleted=0` 会查到已删数据

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
讲师投影 4 张截图并排：
- 图 1：手写 CoachController（Day07-05 成果，200 行）
- 图 2：手写 RoomController（还没写，问号）
- 图 3：AI 一次生成两模块的提示词（一段文字）
- 图 4：AI 输出结果（教练 + 教室代码全套约 400 行）

抛问：**「如果 AI 30 秒能生成 400 行代码，其中 380 行和你手写一样，剩下 20 行有细节坑——你应该怎么用 AI？」** 抽学生回答，引导到「让 AI 干 380 行的活，人干 20 行的差异审查」。

讲师接话：「今天最后一节课，我们用一份提示词把教室模块 + 教练模块**一起**让 AI 生成，然后用一份联调剧本把两模块交叉验证。」

#### 新知讲授（14 分钟）

1. **tb_room 表设计**（4 分钟）：投影 DDL 并逐字段讲：

   ```sql
   CREATE TABLE tb_room (
     id           BIGINT       PRIMARY KEY AUTO_INCREMENT,
     name         VARCHAR(50)  NOT NULL COMMENT '教室名称，如 阳光厅',
     capacity     INT          NOT NULL COMMENT '容量（人）',
     location     VARCHAR(100)          COMMENT '位置，如 3 楼东侧',
     equipment    VARCHAR(255)          COMMENT '设施（音响、地暖、镜面）',
     status       TINYINT      DEFAULT 1 COMMENT '状态 1 可用 2 维护中 3 停用',
     hourly_rate  DECIMAL(10,2) DEFAULT 0.00 COMMENT '每小时费率',
     deleted      TINYINT      DEFAULT 0,
     create_time  DATETIME     DEFAULT CURRENT_TIMESTAMP,
     update_time  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
     UNIQUE KEY uk_name_deleted (name, deleted)
   ) COMMENT '教室';
   ```

   讲师**抽学生**回答：「教室为什么只有 name 一个唯一键，教练却有两个？」引导到「资源属性差异——教室没有身份证/工号这种个人标识」。**再抽一位**：「`hourly_rate` 为什么用 DECIMAL(10,2) 不用 FLOAT？」引导到「金融字段禁用浮点数，DECIMAL 精度可控」。

2. **RoomDTO 特有校验**（4 分钟）：投影 `RoomAddDTO` 关键字段：

   ```java
   @Data
   public class RoomAddDTO {

       @NotBlank @Size(max = 50)
       private String name;

       @NotNull
       @Min(value = 1,   message = "容量至少 1 人")
       @Max(value = 100, message = "容量最多 100 人")
       private Integer capacity;

       @Size(max = 100)
       private String location;

       @Size(max = 255)
       private String equipment;

       @Min(1) @Max(3)
       private Integer status;

       @NotNull
       @DecimalMin(value = "0.00", message = "费率不能为负")
       @DecimalMax(value = "9999.99", message = "费率过高，请检查")
       @Digits(integer = 8, fraction = 2)
       private BigDecimal hourlyRate;
   }
   ```

   讲师强调：`@Digits(integer=8, fraction=2)` 前端传 `100.123`（3 位小数）会被挡下，前端会看到 400 提示；`@DecimalMin` 用字符串而非 double，避免精度丢失。

3. **AI 一次生成两模块的提示词模板**（4 分钟）：讲师投影提示词全文：

   ```
   我在做印想瑜伽会馆后台，技术栈 Spring Boot 4.0 + Java 25 + MyBatis 3.5 +
   PageHelper + Bean Validation。已经完成了会员模块（Result / BizException /
   GlobalExceptionHandler / 软删除唯一键约定），现在请用相同风格一次性生成以下
   两个资源模块的完整代码：

   模块 A：教练管理 /coaches
     表 tb_coach(id, name, phone [唯一,手机号正则], id_card [唯一,身份证正则],
                gender[0-2], birthday, level[1-4], hire_date, intro, avatar_url,
                status[1-3], deleted, create_time, update_time)

   模块 B：教室管理 /rooms
     表 tb_room(id, name [唯一], capacity[1-100], location, equipment,
               status[1-3], hourly_rate[DECIMAL(10,2)>=0], deleted, create_time,
               update_time)

   每个模块交付：Controller / Service / Mapper.java / Mapper.xml /
     AddDTO / UpdateDTO / QueryDTO / VO / 实体。
   Controller 提供 6 端点：POST 新增 / PUT/{id} 修改 / DELETE/{id} 软删 /
     GET/{id} 详情 / GET 分页搜索(keyword+status) / GET/available 精简列表。
   包 com.yinxiang.{coach,room}.{controller,service,mapper,entity,dto,vo}。
   返回 Result<T>，异常抛 BizException。
   双重唯一性校验：Service 先查一次抛 BizException，数据库 UNIQUE 兜底。
   PageHelper.startPage 紧贴 Mapper 调用。
   ```

   讲师**讲收到 AI 输出后必做的 5 步**：
   - ① **对比对称部分**：两模块的 `<where>` `<if>` 结构是不是几乎一样？
   - ② **只关心差异**：教练双唯一 vs 教室单唯一、hourly_rate 特有校验；
   - ③ **补齐团队约定**：唯一键必带 `deleted`、日期区间左闭右开、手机号脱敏（AI 常忘）；
   - ④ **人工加 TODO**：教室删除前应检查是否被 tb_course 引用（Day08 补齐）；
   - ⑤ **警惕字段串味**：教练的 `phone` 跑到 tb_room 的 SQL 里，或 tb_room 的 `hourly_rate` 校验注解写到 CoachDTO 里。

2. **AI 常见字段串味 5 例（讲师板书）**：
   - 例 1：Room 的 selectPage 里 `AND phone LIKE ...`（把教练字段抄来了）；
   - 例 2：Coach 的 DTO 加了 `hourly_rate` 字段；
   - 例 3：Room 的 Service 检查了 `existsByIdCard`（教室根本没这字段）；
   - 例 4：两模块 mapper 命名空间写重复了 `com.yinxiang.coach.mapper.CoachMapper`；
   - 例 5：Room 的 status 注释还写着「1 在职 2 休假」（教练的语义）。

#### 示例演示（14 分钟）

1. **讲师现场用通义灵码跑一次**（5 分钟）：投影 IDE，把提示词粘到通义灵码，30 秒后拿到 AI 输出。全班一起当侦探，用板书上的 5 例字段串味清单**逐条检查**——大概率能找到 2 到 3 处。找到一处讲师就在投影上圈红。

2. **修正 AI 输出并本地跑通**（4 分钟）：把 AI 输出的教室模块代码整合进项目，改掉字段串味，执行 `CREATE TABLE tb_room`，插入 3 条种子：

   ```sql
   INSERT INTO tb_room (name, capacity, location, equipment, status, hourly_rate) VALUES
    ('阳光厅', 20, '3 楼东侧', '镜面,音响,地暖', 1, 120.00),
    ('月光厅', 12, '3 楼西侧', '镜面,音响',      1,  80.00),
    ('星辰厅', 30, '4 楼中央', '镜面,音响,地暖,加湿', 1, 180.00);
   ```

   Postman 跑一遍 `POST /rooms`、`GET /rooms?keyword=阳`、`PUT /rooms/1`、`DELETE /rooms/2`、`GET /rooms/available`，5 步全绿。

3. **双模块联调剧本**（5 分钟）：讲师投影 8 步剧本，抽 4 位学生上台，每人执行 2 步：

   | 步 | 动作 | 期望响应 |
   |----|------|----------|
   | 1 | POST /coaches 新建李教练 | code=0 |
   | 2 | POST /coaches 用同手机号 | code=500 「手机号已被占用」 |
   | 3 | POST /rooms 新建阳光厅 | code=0 |
   | 4 | POST /rooms 用同 name | code=500 「教室名称已存在」（第一道 SQL 挡下） |
   | 5 | GET /coaches?keyword=李 | 返回 1 条 |
   | 6 | GET /rooms?keyword=阳 | 返回 1 条 |
   | 7 | DELETE /rooms/1 → GET /rooms/1 | 500「教室不存在」 |
   | 8 | POST /rooms 用 capacity=200 | 400「容量最多 100 人」 |

   每一步执行完，讲师**抽第 5 位学生**朗读实际响应 JSON，对照期望响应，全班举手投票是否通过。

#### 课堂练习（10 分钟）
1. 每位学生用 AI 提示词一次生成两模块 → 修正字段串味 → 本地跑通 → 交联调剧本 8 张 Postman 截图；
2. 追加要求：给 `GET /rooms` 加一个 `minCapacity` 查询条件（>= minCapacity 的教室），SQL 加 `<if minCapacity != null>AND capacity >= #{minCapacity}</if>`；
3. 思考题：教室的 `status` 从「1 可用」改成「2 维护中」这个操作是「修改」还是「删除」？如果频繁切换 status，PUT /rooms/{id} 是否需要拆一个 PATCH /rooms/{id}/status 出来？

#### 小结（3 分钟）
一句话回顾：**tb_room 单唯一键 + hourly_rate 金融精度 + AI 一次生成双模块 + 5 步审查 + 8 步联调剧本**。

Day07 全景总结（讲师快速过一遍 6 张板书）：Result/BizException（1-01） → 8 分支异常矩阵（1-02） → 三 appender 日志流向（1-03） → tb_coach 表 + DTO 三分层（1-04） → Coach 6 端点 URL 表（1-05） → tb_room + AI 双模块生成（1-06）。**至此后端「资源型模块」的标准公式打死**，Day08 用这套公式做课程模块 + 多表关联查询。

### 6.4 板书设计
```
┌────────────────────────────────────────────────────────────────────┐
│  Day07-06  Coach + Room 双模块 12 端点表                           │
├─────┬─────────┬───────────────────────────┬───────────────────────┤
│  #  │ HTTP    │ URL                       │ 返回                  │
├─────┼─────────┼───────────────────────────┼───────────────────────┤
│  1  │ POST    │ /coaches                  │ Result<Void>          │
│  2  │ PUT     │ /coaches/{id}             │ Result<Void>          │
│  3  │ DELETE  │ /coaches/{id}             │ Result<Void>          │
│  4  │ GET     │ /coaches/{id}             │ Result<CoachVO>       │
│  5  │ GET     │ /coaches                  │ Result<Page<CoachVO>> │
│  6  │ GET     │ /coaches/available        │ Result<List<Simple>>  │
├─────┼─────────┼───────────────────────────┼───────────────────────┤
│  7  │ POST    │ /rooms                    │ Result<Void>          │
│  8  │ PUT     │ /rooms/{id}               │ Result<Void>          │
│  9  │ DELETE  │ /rooms/{id}               │ Result<Void>          │
│ 10  │ GET     │ /rooms/{id}               │ Result<RoomVO>        │
│ 11  │ GET     │ /rooms                    │ Result<Page<RoomVO>>  │
│ 12  │ GET     │ /rooms/available          │ Result<List<Simple>>  │
└─────┴─────────┴───────────────────────────┴───────────────────────┘

  AI 一次生成 5 步审查：
    ① 对比对称结构    ② 只关心差异    ③ 补团队约定
    ④ 人工加 TODO      ⑤ 警惕字段串味

  常见坑：
    - DuplicateKeyException 没 catch 会 500 → 上节课全局处理器已挡
    - 逻辑删除 SQL 漏 deleted=0 → 查到已删数据
    - gender/status TINYINT 存储 → 前端用字典转文字
```

### 6.5 课后作业
1. **必做**：用 AI 一次生成两模块 → 修正字段串味 → 本地跑通 → 提交联调剧本 8 张 Postman 截图 + AI 生成原文对比 diff；
2. **必做**：整理一份「Day07 12 端点」的接口契约文档，Markdown 格式，含 URL / 方法 / 请求参数 / 响应示例，供 Day08 前端联调用；
3. **挑战**：把「gender / status / level」三个 TINYINT 字段做成 Java 25 sealed enum，Service 层直接返回枚举，Jackson 序列化成 `{code:1, label:"在职"}` 结构，前端不用再查字典。

### 6.6 教学反思提示
- 本节是 Day07 收尾，节奏适中，多留 5 分钟做「Day07 全景板书」——把 6 节课的 6 张核心板书快速过一遍，加深整体印象；
- AI 生成两模块的字段串味问题**不一定每次都出现**，讲师课前应先自己跑 3 次通义灵码，记录常见错误清单，课堂上引导学生找；
- 若学生反馈「AI 输出比我手写快得多，那我为什么还要手写一遍」，讲师回答：**「你手写过教练模块，才有能力审查 AI 的教室模块。没有手写基础，AI 的错误你根本看不出来——这就是为什么第 5 节课让你手写，第 6 节课才让你用 AI。」**

---

## 附录 A：Day07 交付物一览

| 序号 | 分类 | 交付 | 关键点 |
|------|------|------|--------|
| 1 | 统一响应 | `Result<T>` | code / message / data + 4 静态工厂 |
| 2 | 业务异常 | `BizException` | 继承 RuntimeException + int code |
| 3 | 全局异常 | `GlobalExceptionHandler` | 8 分支矩阵，warn/error 分级 |
| 4 | 404 统一 | application.yml 两行配置 | add-mappings=false + throw-exception=true |
| 5 | 日志配置 | `logback-spring.xml` | CONSOLE + FILE + ASYNC 三 appender |
| 6 | 日志脱敏 | `SensitiveUtil` | maskPhone / maskIdCard |
| 7 | 教练表 | tb_coach | 13 字段 + 两个 UNIQUE(x, deleted) |
| 8 | 教练 DTO | Add/Update/QueryDTO 三分层 | 新增无 id、修改必 id、查询全可选 |
| 9 | 教练 Mapper | 5 个关键 SQL | selectPage / existsByX / softDelete |
| 10 | 教练 Controller | 6 个 REST 端点 | POST/PUT/DELETE/GET × 6 |
| 11 | 教室表 | tb_room | 10 字段 + UNIQUE(name, deleted) |
| 12 | 教室 DTO | 三分层 + 特有校验 | capacity 1-100 / hourly_rate DECIMAL |
| 13 | 教室 Controller | 6 个 REST 端点 | 与 Coach 完全对称 |
| 14 | AI 提示词 | 一次生成两模块模板 | 5 步审查清单 |
| 15 | 联调剧本 | 双模块 8 步 Postman | 唯一冲突 / 校验失败 / 软删除 |

## 附录 B：Day07 核心口诀

- **Result 三字段**：code / message / data，成功 0；
- **BizException 时机**：业务预期错误抛，参数格式错不抛，系统错误不抛；
- **异常矩阵口诀**：具体到抽象、业务到系统、warn 到 error；
- **404 两行配**：`add-mappings=false` + `throw-exception-if-no-handler-found=true`；
- **打印三纪律**：参数化、最外层打栈、敏感字段脱敏；
- **三 appender 分工**：CONSOLE 开发 / FILE 生产 / ASYNC 异步不阻塞；
- **DTO 三分层**：Add 无 id / Update 必 id / Query 全可选加分页；
- **双重唯一性**：SQL 先查一次 → 数据库 UNIQUE 兜底；
- **UNIQUE 必带 deleted**：软删后同值能复用；
- **6 端点标准公式**：POST / PUT/{id} / DELETE/{id} / GET/{id} / GET / GET/available；
- **AI 5 步审查**：对称 → 差异 → 团队约定 → TODO → 字段串味。

## 附录 C：Day07 常见问题速答

| 问题 | 回答 |
|------|------|
| Postman 请求 404 依旧返回白页 | `spring.mvc.throw-exception-if-no-handler-found: true` 漏配 |
| Throwable 兜底 log.error 打了 3 次 | Service / Controller 里也 catch 了并 log，删掉中间的 |
| `<if test="keyword != null and keyword != ''">` 空字符串没被拦 | MyBatis OGNL 判断，`''` 和 `null` 要一起判 |
| `PageHelper.startPage` 分页失效 | 中间隔了别的代码，必须紧贴 Mapper 调用 |
| DuplicateKeyException 没被 409 处理 | 全局处理器漏了这一分支，或异常继承链被 Spring 包装 |
| AI 生成的 Room SQL 里出现 phone 字段 | 字段串味，5 例常见坑之一，人工修正 |
| logback-spring.xml 里 `<springProfile>` 不生效 | 文件名写成 logback.xml 了，改成 logback-spring.xml |
| 手机号打印到日志里没脱敏 | Service 层 log.info 忘了调 `SensitiveUtil.maskPhone` |
| BizException 抛出后 Controller 编译报错 | Service 返回值从 `Result<Void>` 改成了 `void`，Controller 里去掉 `return service.xxx()` 的赋值 |
| tb_coach 唯一键冲突 500 而非 409 | 全局处理器没配 DuplicateKeyException 分支，加上即可 |
| gender / status 前端显示成 1、2、3 | 前端没做字典映射，或后端 VO 序列化未转文字 |
| `available` 端点该不该分页 | 不该，供下拉框用，数据量有限 |

---
