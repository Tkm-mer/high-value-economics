# 《AI 应用 Web 开发》 - 教师教案（Day17：Docker 网络 + 全栈部署 + CI/CD + 课程回顾）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day16 的学生（掌握 Spring Boot 4.0.x 全链路后端、Vue 3 + TypeScript 全部业务页面、Linux 基础、Nginx 反代、Docker 单容器打包、Dockerfile 分层构建、镜像推送 ACR 全部前置能力）**
**知识点覆盖：** 第 33 章 Docker 容器网络互连与项目部署（自定义 bridge / host 网络、容器互联、docker compose v2 多服务编排、depends_on + healthcheck、命名卷、Nginx 容器化反代、HTTPS 证书）+ 第 34 章 CI/CD 与课程回顾（GitHub Actions 自动构建 + push registry、Docker Layer Cache、一键拉取重启 deploy.sh、版本回滚、mysqldump 备份、监控 & 安全清单、34 章 107 技术点知识地图、后续学习路径）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / Vue 3.5+ / Vite 5.4+ / Ubuntu 22.04 LTS / Docker Engine 27.x / Docker Compose v2.29+ / Nginx 1.24（容器）/ MySQL 8.0（容器）/ Redis 8-alpine（容器）/ GitHub Actions（actions/checkout@v4、setup-java@v4、docker/build-push-action@v6、docker/setup-buildx-action@v3、docker/login-action@v3、appleboy/ssh-action@v1）/ 阿里云 ACR / IDEA 2024.3+ / 通义灵码 + Trae。

**Day17 主线**：Day16 我们把印想瑜伽后端与前端**分别**塞进了 Docker 镜像，能用 `docker run` 起一个孤立容器——但真实生产是 **MySQL + Redis + Backend + Nginx** 四个容器**协同**工作，`docker run` 一堆参数写到手抽筋、启动顺序管不住、卷和网络没版本。Day17 就是把「零散容器」拧成「一台机器」的收官日：前 1 个课时讲 Docker 自定义 `bridge` 网络与 `host` 网络的区别 + 容器互联的服务名 DNS；第 2 课时用一份 `docker-compose.yml` 把 4 个服务一键编排，把 `.env`、`depends_on` + `healthcheck`、命名卷、`restart: always` 逐字讲透；第 3 课时把 Nginx **容器化**成反向代理，前后端**同源**部署到服务器，浏览器打开 `https://yoga.example.com` 拿到真实数据；第 4 课时把「本地 build + push + ssh + up」串成 **GitHub Actions** 自动流水线，`git push` 一次 CI 全绿；第 5 课时写 `deploy.sh` 让服务器接受 tag 参数一键拉取、健康检查、失败回滚，再补 `mysqldump` 备份与监控告警；第 6 课时用一张 mindmap 把 17 天 34 章 107 技术点串成知识地图，给出 3-5 个拓展项目建议，让学生带着「能独立上线一个中小型 Web 系统」的能力离开课堂。**Day17 = 课程闭环 + 简历级作品链接**。

---

## 第 1 课时：Docker 自定义网络（bridge / host）+ 容器互联

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出 Docker 默认三种网络（`bridge` / `host` / `none`）的拓扑图，并说清「默认 bridge 网络的容器**不能**用容器名互相访问」这一关键限制；
2. 能用 `docker network create yoga-net` 创建自定义 bridge 网络，把两个容器 `--network yoga-net` 加进去，验证 `ping` 容器名可通；
3. 能解释 Docker 内置 DNS 的工作原理：**自定义 bridge 网络**里，容器名 = 服务名 = 可解析主机名；
4. 能对比 `bridge` 与 `host` 模式的两大差别：端口发布方式（`-p` vs 直用宿主端口）、网络隔离强度（NAT vs 无隔离）；
5. 能用 `docker network inspect` 查看子网 CIDR、网关 IP、已连接容器的内部 IP，为排障建立"眼睛"。

#### 1.1.2 过程与方法目标
1. 通过「先用默认 bridge 起两容器互 ping 容器名失败 → 再切自定义网络成功」的对照实验，让学生亲手体会「自定义 bridge = 免费送内置 DNS」这一关键收益；
2. 通过在自定义网络里用「服务名」而不是「IP」联调 MySQL + Backend，训练「配置文件写服务名、Docker 帮你解析 IP」的容器化思维，为下一课时 compose 一键编排铺垫。

### 1.2 教学重难点
- **重点**：默认 bridge vs 自定义 bridge 的 DNS 差异 / `docker network create` + `--network` 双步操作 / 服务名 = 内部主机名的连接串写法（`jdbc:mysql://mysql:3306/yoga`）/ `docker network inspect` 查子网与网关
- **难点**：为什么默认 bridge 网络**故意不支持**容器名 DNS——历史兼容性问题，官方推荐所有生产项目都用自定义网络 / `host` 网络在 Linux 上生效但在 Docker Desktop for Mac / Windows 上**行为不同**（Docker Desktop 会用 VM 隔离）/ 端口冲突与 `-p host:container` 的映射方向：**冒号左边**是宿主机端口，学生极易记反

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
Day16 我们把 backend 打成镜像 `yoga/backend:1.0.0`，`docker run -p 8080:8080` 单独跑起来了——但连数据库的 `SPRING_DATASOURCE_URL` 写的是 `jdbc:mysql://localhost:3306/yoga`，而 MySQL 也在另一个容器里，`localhost` 指向的是 **backend 容器自己的回环地址**，根本连不上 MySQL。反问：「容器 A 想连容器 B，A 该填 B 的什么？IP？端口？还是容器名？」板书画一张双容器拓扑：

```
┌──────────────┐        ┌──────────────┐
│ backend      │  ???  │ mysql        │
│ 172.18.0.3   │◄──────►│ 172.18.0.2  │
└──────────────┘        └──────────────┘
       └──────── docker network ─────────┘
```

引出今天的核心问题：**「让容器之间用名字互相找到」**。

#### 目标（2 分钟）
一句话：**「用自定义 bridge 网络让 backend 用 `mysql` 这个服务名连到 MySQL 容器」**。今天先把「网络 + DNS」的基础打牢，下节课直接进 compose 一键编排。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **默认 bridge 网络无容器名 DNS**——必须建自定义网络
- 🔴 **`-p 8080:8080` 冒号左边是宿主**——写反后从浏览器打不开

#### 新知讲授（14 分钟）

1. **Docker 网络驱动的三大类别**（4 分钟）：
   - `bridge`（默认）：Docker 装完后自带一个 `bridge` 名字的默认网桥，`docker run` 不带 `--network` 都进它；子网通常是 `172.17.0.0/16`；**关键限制：容器名不解析**，容器互相只能用 IP（IP 又是每次启动动态分配的）；
   - `host`：容器**直接使用宿主机网络栈**，没有网络隔离，`-p` 参数会被忽略，容器内 `bind 0.0.0.0:8080` 就是宿主的 8080；性能最好、隔离最差，Linux 原生 Docker 生效，Docker Desktop（Mac/Win）由于 VM 层原因**行为不完全一致**，本课以 Linux 部署为目标；
   - `none`：无网络，容器只有回环 lo，用来跑纯计算任务或做安全隔离；
   - **自定义 bridge**：`docker network create yoga-net`，与默认 bridge 唯一区别但极其关键——**自带内置 DNS**，容器名可当主机名互相解析。生产项目**无一例外**都用自定义网络。

2. **自定义网络实操**（4 分钟）：
   - 现场敲三条命令：
     ```bash
     docker network create yoga-net
     docker run -d --name mysql --network yoga-net \
       -e MYSQL_ROOT_PASSWORD=Root@123 -e MYSQL_DATABASE=yoga mysql:8.0
     docker run -d --name backend --network yoga-net \
       -e SPRING_DATASOURCE_URL='jdbc:mysql://mysql:3306/yoga' \
       -e SPRING_DATASOURCE_USERNAME=root -e SPRING_DATASOURCE_PASSWORD=Root@123 \
       -p 8080:8080 yoga/backend:1.0.0
     ```
   - 强调 `SPRING_DATASOURCE_URL` 里主机部分**写 `mysql`**（就是上一条命令的 `--name mysql`），不写 IP、不写 `localhost`；
   - `docker exec backend ping -c 1 mysql`——学生亲手看到"用名字 ping 通"这一刻的震撼。

3. **端口发布与 network inspect**（6 分钟）：
   - `-p 8080:8080` 语义：**宿主机 8080** 映射到**容器 8080**；写成 `-p 80:8080` 是宿主 80 → 容器 8080，浏览器 `http://host/` 直接访问；反过来 `-p 8080:80` 就打不开——学生最容易记反；
   - `docker network inspect yoga-net`：JSON 输出里 `Subnet`、`Gateway`、`Containers` 三段最有价值，能看到每个容器的内部 IP、Mac 地址——**排障必查**；
   - 演示故意把 backend `-e SPRING_DATASOURCE_URL='jdbc:mysql://localhost:3306/yoga'` 写错，启动 30 秒后必然 `ConnectException`——引出「容器里的 `localhost` 是容器自己」这一致命误解；
   - 板书画一张对照表：
     ```
     写法                          结果
     jdbc:mysql://localhost/yoga  连自己容器 → 失败
     jdbc:mysql://mysql/yoga      连服务名 → 成功（自定义网络）
     jdbc:mysql://172.18.0.2/yoga 连硬编码 IP → 重启后 IP 变，失败
     ```

#### 课堂活动（15 分钟）

1. **示例演示：默认 vs 自定义 bridge 对照实验**（8 分钟）：
   - 先用**默认 bridge** 起两个 `alpine`：`docker run -dit --name a alpine sh` / `docker run -dit --name b alpine sh`；
   - `docker exec a ping -c 1 b` → **失败**：`bad address 'b'`；
   - `docker rm -f a b` 清掉，重来：
     ```bash
     docker network create demo-net
     docker run -dit --name a --network demo-net alpine sh
     docker run -dit --name b --network demo-net alpine sh
     docker exec a ping -c 1 b
     ```
   - 这次 ping 通，`64 bytes from b`——学生震撼；
   - 板书写下：**「自定义网络 = 免费送 DNS」**。

2. **反面演示：`-p` 方向写反**（5 分钟）：
   - 故意把 backend 启动改成 `-p 8080:9090`（backend 容器里监听的其实是 8080）；
   - 浏览器 `http://localhost:8080` → 拒绝连接；`http://localhost:9090` → 也拒绝；
   - `docker logs backend` 里看得到 `Tomcat started on port 8080`，说明容器**内**是 8080；
   - 修正为 `-p 8080:8080`——浏览器立刻通；
   - 板书画红色警告框：**「-p 宿主:容器，冒号左边永远是外部世界的端口」**。

3. **AI 生成对照**（2 分钟）：
   - 把「用 Docker 起 MySQL + Spring Boot 后端，让后端能连到 MySQL」需求丢给通义灵码；
   - 常见 AI 错误：① 让 backend 写 `jdbc:mysql://localhost:3306/...`——容器隔离下必然失败；② 忘 `--network`——两容器不在同一网络无法互访；③ 直接告诉学生用 `--link`——**已废弃**语法，Docker 20 之后不推荐；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「自定义 bridge 网络 + `--network` 加入 + 服务名当主机名 = 容器互联三件套」**。今天用 `docker run` 手工连了两容器，下节课我们用一份 `docker-compose.yml` 把 4 个服务一键拉起。

### 1.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-01 Docker 自定义网络 + 容器互联                │
├──────────────────────────────────────────────────────┤
│  三种网络驱动：                                       │
│    bridge  默认，容器名不解析 ✗                       │
│    host    共享宿主栈，无隔离                         │
│    none    纯计算，无网络                             │
│                                                       │
│  🔴 自定义 bridge：docker network create yoga-net    │
│      自带 DNS：容器名 = 主机名                        │
│                                                       │
│  docker run --network yoga-net \                     │
│    --name mysql ...                                  │
│  backend 连接串：jdbc:mysql://mysql:3306/yoga        │
│                                                       │
│  🔴 -p 8080:8080                                     │
│      冒号左：宿主端口（外部世界）                     │
│      冒号右：容器端口（应用监听）                     │
│                                                       │
│  排障：docker network inspect yoga-net               │
│         看 Subnet / Gateway / Containers             │
└──────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：把 Day16 打好的 `yoga/backend:1.0.0` 与 `mysql:8.0` 用**自定义网络** `yoga-net` 起起来，`docker exec backend ping mysql` 通，`curl http://localhost:8080/actuator/health` 返回 `UP`，交 3 条命令 + 输出截图；
2. **必做**：故意把 `docker run` 换成默认 bridge（去掉 `--network yoga-net`），backend 启动后 30 秒内必然报 `Communications link failure`，交错误日志截图 + 简述"为什么默认 bridge 不通"的一段话；
3. **挑战**：用 `docker network inspect yoga-net` 查到 mysql 容器的内部 IP，重启 mysql 容器再查一次——观察 IP 是否变化，写一段结论解释"为什么 mysql 容器 IP 会变，而服务名不会失效"。

### 1.6 教学反思提示
- 学生最容易问的是「为什么默认 bridge 有 DNS 更好，Docker 却默认不开」——正确答案是**历史兼容**：早期版本用 `/etc/hosts` 静态方案，后来引入 embedded DNS 但为了不破坏遗留脚本，只在自定义网络上开启；官方文档明确写明「生产使用请建自定义网络」；
- 演示 `-p` 方向时故意写反是最深刻的教训——学生下次自己写就不会错；
- `host` 网络在 Docker Desktop for Mac / Windows 上因为 VM 层介入行为不同，本课统一以 Linux 服务器为部署目标，Mac 学生本地演示时提醒切换心智。

---

## 第 2 课时：docker compose 一键编排（MySQL + Redis + Backend + Nginx）

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能解释 docker compose v2 的定位——**一份 YAML 描述多服务**、`docker compose up -d` 一条命令拉起，取代 `docker run` 手工堆参数；
2. 能写出 `docker-compose.yml` 的顶层三段结构：`services / networks / volumes`，并说清「同一 compose 项目里的服务默认在同一自定义网络」这一隐式规则；
3. 能给每个服务配 `image` / `container_name` / `environment` / `env_file` / `volumes` / `networks` / `ports` / `expose` / `restart` / `depends_on` / `healthcheck` 十项常用字段；
4. 能理解 `depends_on.condition: service_healthy` 与 `healthcheck` 的**配合关系**——`depends_on` 只等启动、`healthcheck` 才等就绪，两者缺一不可；
5. 能用 `.env` 文件把敏感值（数据库密码、JWT Secret、镜像 tag）从 `docker-compose.yml` 里剥离，`${VAR}` 占位符注入。

#### 2.1.2 过程与方法目标
1. 通过「先 `docker run` 起 4 个容器（30 条命令）→ 再 compose 一键 up（1 条命令）」的对照，让学生亲手体会声明式编排的杠杆效应；
2. 通过「先不加 healthcheck backend 起不来 → 再加 healthcheck 起得来」的失败复盘，训练"启动顺序 = 就绪顺序"的分布式思维。

### 2.2 教学重难点
- **重点**：`services` 段的十项常用字段完整覆盖 / `depends_on + healthcheck` 双保险 / `.env` + `${VAR}` 敏感值剥离 / `docker compose up -d` / `logs -f` / `ps` / `down` 五条日常命令
- **难点**：为什么 `depends_on` **单独用**几乎没意义——它只保证启动**顺序**不保证服务**就绪**，MySQL 初始化 30 秒时 backend 就已经 `Connection refused` 了 / `volumes` 段命名卷 vs `bind mount` 的选择：数据库用命名卷（Docker 管理）、配置文件用 bind（宿主可编辑）/ `expose` vs `ports` 的差别——`expose` 只在内网可见（backend 走 Nginx 代理），`ports` 才对宿主发布

### 2.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
接着第 1 课时结尾——「4 个服务、每个 `docker run` 起码 8-12 个参数、还要记启动顺序、还要考虑失败重启」。板书随手写一堆 `docker run -d --name mysql -e ... -v ... --network ... --restart always mysql:8.0 && docker run -d --name redis ...` 拉到白板尽头。反问：「同学接手项目第一件事，是不是要理清楚这 30 条命令？我们能不能把它变成一份"配置文件"，一键执行？」引出 **docker compose** 的核心价值：**声明式**多服务编排。

#### 目标（2 分钟）
一句话：**「写一份 `docker-compose.yml` + 一份 `.env`，`docker compose up -d` 一条命令拉起 mysql / redis / backend / web 四服务」**。今天不引入 Nginx 反代配置（下节课专讲），先把编排骨架跑通。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **`depends_on` 只等启动、`healthcheck` 才等就绪**——两者必须配合
- 🔴 **`expose` 内网可见 / `ports` 对宿主发布**——backend 只 expose、web 才 ports

#### 新知讲授（14 分钟）

1. **compose 文件顶层结构与目录约定**（4 分钟）：
   - 顶层三段 `services / networks / volumes`，无 `version:` 字段（v2 已废弃版本号）；
   - 项目目录约定：
     ```
     /opt/yoga/
     ├── docker-compose.yml
     ├── .env                          # 敏感值
     ├── nginx/conf.d/yoga.conf        # Nginx 站点配置
     ├── data/mysql/init/              # 初始化 SQL
     ├── data/certs/                   # HTTPS 证书
     └── logs/                         # 日志目录
     ```
   - `.env` 与 `docker-compose.yml` **同目录**才自动加载，文件名必须精确是 `.env`；
   - `.gitignore` 必加 `.env` —— 敏感值绝不入库。

2. **四服务骨架**（4 分钟）：
   - `mysql`：`image: mysql:8.0`、环境变量、`command` 加 utf8mb4、命名卷 `mysql-data`、healthcheck 用 `mysqladmin ping`；
   - `redis`：`image: redis:8-alpine`、`command` 加密码 + AOF、命名卷 `redis-data`、healthcheck 用 `redis-cli PING`；
   - `backend`：`image: ${BACKEND_IMAGE}`（从 .env 读）、连接串写服务名、`depends_on: mysql: {condition: service_healthy}`、`expose: [8080]`（**只**内网可见）；
   - `web`：`image: ${WEB_IMAGE}`、挂 `nginx/conf.d`、`ports: [80:80, 443:443]`、`depends_on: [backend]`。

3. **`.env` 与 `${VAR}` 占位符**（6 分钟）：
   - `.env` 文件示例：
     ```
     MYSQL_ROOT_PASSWORD=StrongRootPwd!
     MYSQL_DATABASE=yoga
     MYSQL_USER=yoga
     MYSQL_PASSWORD=StrongUserPwd!
     REDIS_PASSWORD=Yoga@Redis
     JWT_SECRET=change-me-in-prod
     BACKEND_IMAGE=registry.cn-hangzhou.aliyuncs.com/yoga/backend:1.0.0
     WEB_IMAGE=registry.cn-hangzhou.aliyuncs.com/yoga/web:1.0.0
     ```
   - `docker-compose.yml` 里所有敏感值全部走 `${VAR}` 占位符——本地开发、测试、生产切 `.env` 就切环境；
   - `docker compose config` 命令**渲染** YAML（把 `${VAR}` 全部替换成实际值），学生第一次会惊呼"原来 `.env` 是这样注入的"；
   - 强调**双下划线小心**：`${MYSQL_PASSWORD}` 与 `$${LITERAL}` 前者被替换、后者保留字面 `$` ——如果密码里含 `$` 要转义。

#### 课堂活动（15 分钟）

1. **示例演示：一份完整的 `docker-compose.yml`**（8 分钟）：
   - 现场敲完 130 行 YAML（前面结构讲过、这里合成整体）：
     ```yaml
     services:
       mysql:
         image: mysql:8.0
         container_name: yoga-mysql
         restart: always
         environment:
           MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
           MYSQL_DATABASE:     ${MYSQL_DATABASE}
           MYSQL_USER:         ${MYSQL_USER}
           MYSQL_PASSWORD:     ${MYSQL_PASSWORD}
           TZ: Asia/Shanghai
         command:
           - --character-set-server=utf8mb4
           - --collation-server=utf8mb4_unicode_ci
         volumes:
           - mysql-data:/var/lib/mysql
           - ./data/mysql/init:/docker-entrypoint-initdb.d:ro
         networks: [yoga-net]
         healthcheck:
           test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-p${MYSQL_ROOT_PASSWORD}"]
           interval: 10s
           timeout:  5s
           retries:  10

       redis:
         image: redis:8-alpine
         restart: always
         command: ["redis-server", "--requirepass", "${REDIS_PASSWORD}", "--appendonly", "yes"]
         volumes:
           - redis-data:/data
         networks: [yoga-net]
         healthcheck:
           test: ["CMD", "redis-cli", "-a", "${REDIS_PASSWORD}", "PING"]
           interval: 10s
           timeout:  3s
           retries:  5

       backend:
         image: ${BACKEND_IMAGE}
         restart: always
         environment:
           SPRING_PROFILES_ACTIVE: prod
           SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/${MYSQL_DATABASE}?useUnicode=true&characterEncoding=UTF-8&serverTimezone=Asia/Shanghai
           SPRING_DATASOURCE_USERNAME: ${MYSQL_USER}
           SPRING_DATASOURCE_PASSWORD: ${MYSQL_PASSWORD}
           SPRING_DATA_REDIS_HOST: redis
           SPRING_DATA_REDIS_PASSWORD: ${REDIS_PASSWORD}
           JWT_SECRET: ${JWT_SECRET}
         depends_on:
           mysql: { condition: service_healthy }
           redis: { condition: service_healthy }
         networks: [yoga-net]
         expose: ["8080"]

       web:
         image: ${WEB_IMAGE}
         restart: always
         depends_on: [backend]
         volumes:
           - ./nginx/conf.d:/etc/nginx/conf.d:ro
           - ./logs/nginx:/var/log/nginx
         ports:
           - "80:80"
           - "443:443"
         networks: [yoga-net]

     networks:
       yoga-net:
         driver: bridge

     volumes:
       mysql-data:
       redis-data:
     ```
   - `docker compose config` → 校验语法 + 渲染值；
   - `docker compose up -d` → 学生看着终端逐个 `Creating yoga-mysql ... done`；
   - `docker compose ps` → 4 个服务全部 `Up (healthy)`；
   - 学生第一次感受到"一条命令 = 30 条命令"的杠杆。

2. **反面演示：漏 healthcheck 会怎样**（5 分钟）：
   - 把 mysql 的 `healthcheck` 段整块注释掉，backend 的 `depends_on.mysql.condition` 改回 `service_started`；
   - `docker compose down && docker compose up -d`；
   - `docker compose logs -f backend` → 前 30 秒疯狂 `Communications link failure to mysql:3306`——因为 MySQL 容器已启动但**没就绪**；
   - Spring Boot 默认没配重试就直接崩溃退出，然后 `restart: always` 又拉起、又崩溃……**启动死循环**；
   - 恢复 healthcheck 段——一次性起来；
   - 板书画红色警告框：**「启动 ≠ 就绪，depends_on 必须配 healthcheck」**。

3. **AI 生成对照**（2 分钟）：
   - 把「用 docker compose 起 MySQL + Redis + Spring Boot + Nginx 四服务」需求丢给通义灵码；
   - 常见 AI 错误：① 顶层加 `version: '3.8'`——compose v2 已废弃、警告刷屏；② `depends_on` 不带 condition——回到启动死循环；③ 密码写死在 YAML 里——上 Git 就完蛋；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「compose = 4 个服务的一键脚本 + 声明式配置 + `.env` 敏感值剥离 + healthcheck 就绪保证」**。今天把编排骨架跑通、能看到 4 个容器 healthy，下节课把 Nginx 反代配上让浏览器打开就能用。

### 1.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-02 docker compose 一键编排                     │
├──────────────────────────────────────────────────────┤
│  services:                                           │
│    mysql:   image + env + volume + healthcheck       │
│    redis:   image + command --requirepass + hc       │
│    backend: image + expose 8080 + depends_on healthy │
│    web:     image + ports 80/443 + volumes conf.d    │
│                                                       │
│  networks: yoga-net (bridge)                         │
│  volumes:  mysql-data, redis-data                    │
│                                                       │
│  🔴 depends_on + condition: service_healthy           │
│       启动 ≠ 就绪，healthcheck 才等就绪               │
│                                                       │
│  🔴 expose vs ports                                   │
│       expose 只内网；ports 对宿主发布                 │
│                                                       │
│  .env → ${VAR} 占位符                                 │
│  docker compose config     校验 + 渲染                │
│  docker compose up -d      一键启动                   │
│  docker compose logs -f    调试日志                   │
│  docker compose down       停止（保留卷）             │
│  docker compose down -v    连数据一起删               │
└──────────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：把课堂上的 `docker-compose.yml` + `.env` 拷贝到本地或云主机 `/opt/yoga/`（backend / web 镜像可先用 `nginx:1.24` 占位），`docker compose up -d` 起 4 个容器全部 `Up (healthy)`，交 `docker compose ps` 截图；
2. **必做**：把 `depends_on` 里的 `condition: service_healthy` 改回 `service_started` 再复现一次启动失败，看 `docker compose logs backend` 里 `Communications link failure` 的日志，交错误截图 + 一句话解释"为什么会失败"；
3. **挑战**：给 compose 增加一个 `adminer`（MySQL 图形化管理）服务，`image: adminer:latest`，`ports: 8081:8080`，`depends_on: mysql`，浏览器打开 `http://localhost:8081` 用服务名 `mysql` 登录数据库。

### 2.6 教学反思提示
- 学生最容易问的是"为什么不给 backend 配 `ports` 直接 8080 对外"——正确答案是**安全**：backend 只面向 Nginx 反代、直接暴露 8080 是"两扇门"，攻击面翻倍；
- `healthcheck.test` 用 `CMD` 数组格式而不是字符串——数组不走 shell 解析、更安全；
- 演示时故意用 `docker compose down` 后学生问"数据丢了吗"——展示 `docker volume ls` 命名卷还在，`up -d` 再来数据回来；再演示 `docker compose down -v` 数据彻底没了——留下深刻印象。

---

## 第 3 课时：Nginx 容器内反向代理 + 前后端全栈上线

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能写出 Nginx 容器的 `nginx/conf.d/yoga.conf` 完整配置：HTTP 80 → HTTPS 301 跳转 / HTTPS 443 SSL 段 / `location /` SPA fallback / `location /api/` 反向代理到 `http://backend:8080/`；
2. 能解释 `proxy_pass http://backend:8080/` 末尾斜杠的作用：带斜杠 = **重写路径**（`/api/emp` → `/emp`），不带斜杠 = 保留前缀；
3. 能配 `proxy_set_header` 四件套：`Host` / `X-Real-IP` / `X-Forwarded-For` / `X-Forwarded-Proto`，让后端拿到真实客户端 IP；
4. 能配 Gzip、静态资源长缓存 `Cache-Control: public, immutable`、`client_max_body_size 20m`（上传大文件）；
5. 能理解 HTTPS 证书两种来源：Let's Encrypt certbot（免费 90 天）+ 云厂商托管证书（阿里云 / 腾讯云 / Cloudflare），并知道 `snap install certbot` + `certonly --standalone` 的申请流程。

#### 3.1.2 过程与方法目标
1. 通过「先跑 HTTP 版让全栈打通 → 再补 HTTPS 段升级安全」的两阶段推进，让学生先见「能用」再见「能上生产」；
2. 通过「用 curl 直接打 backend expose 端口失败 → 用 curl 打 web:80/api 成功」的对照，训练"反向代理才是唯一入口"的架构思维。

### 3.2 教学重难点
- **重点**：`proxy_pass http://backend:8080/` 里 `backend` 是 compose 服务名 / 末尾斜杠语义 / `try_files $uri $uri/ /index.html` SPA fallback / `proxy_set_header` 四件套 / `client_max_body_size` 别忘配
- **难点**：为什么静态资源要挂 hash 长缓存 + `index.html` 不缓存——**版本切换三原则**（Day15 讲过，今天在容器里落地）/ HTTPS 证书的 90 天自动续期怎么做（certbot renew + 定时重载 nginx）/ 反代 502 时到底是哪一环坏了（Nginx 起来了但 backend 没起 / 端口写错 / 网络不通）

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
第 2 课时结尾我们看到 4 个容器 `Up (healthy)`，但浏览器打开 `http://localhost/` 显示 Nginx 默认欢迎页——因为**没配站点**。反问：「浏览器请求 `/api/emp/list` 该到哪去？请求 `/dashboard` 又该返回什么？」板书画出前后端同域架构：

```
浏览器 https://yoga.example.com
         │
    ┌────┴────┐
    │ Nginx   │ 80/443 对外
    │ (web)   │
    └────┬────┘
    /api/*    /
    │         │
    ▼         ▼
 backend:8080  dist/index.html (SPA)
 (内网 expose)
```

引出今天核心：**「Nginx 一份 conf.d 配置文件承担 3 件事：SPA 静态托管 / API 反代 / HTTPS」**。

#### 目标（2 分钟）
一句话：**「让浏览器 `http://yoga.local/` 打开是登录页、点登录后 `/api/auth/login` 走到 backend、拿 Token 后 `/api/emp/list` 拉到数据」**。今天先跑 HTTP 版，HTTPS 段作为增量配置讲。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **`proxy_pass` 末尾斜杠**——重写 vs 保留前缀
- 🔴 **`try_files ... /index.html`**——SPA 刷新 404 兜底

#### 新知讲授（14 分钟）

1. **`web` 镜像与 `conf.d` 挂载**（4 分钟）：
   - Day16 已经把前端打成 `yoga/web:1.0.0` 镜像（Dockerfile 用 `nginx:1.24-alpine` 作 base、把 `dist/` COPY 到 `/usr/share/nginx/html`）；
   - compose 里 `web` 服务把宿主 `./nginx/conf.d` 挂载到容器 `/etc/nginx/conf.d:ro` —— 只读挂载，配置放宿主、改完 `docker compose exec web nginx -s reload` 生效；
   - 强调**不要重新构建镜像来改配置**——配置应该是"运行时可注入"的资源。

2. **完整 nginx 配置解剖**（4 分钟）：
   - 现场敲 `nginx/conf.d/yoga.conf`（HTTP 版）：
     ```nginx
     server {
         listen      80;
         server_name yoga.local;
         root  /usr/share/nginx/html;
         index index.html;

         location / {
             try_files $uri $uri/ /index.html;
         }

         location /assets/ {
             expires 1y;
             add_header Cache-Control "public, immutable";
         }

         location /api/ {
             proxy_pass         http://backend:8080/;
             proxy_http_version 1.1;
             proxy_set_header   Host              $host;
             proxy_set_header   X-Real-IP         $remote_addr;
             proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
             proxy_set_header   X-Forwarded-Proto $scheme;
             proxy_connect_timeout 5s;
             proxy_read_timeout    60s;
         }

         client_max_body_size 20m;

         gzip on;
         gzip_types text/plain text/css application/json application/javascript;
         gzip_min_length 1024;

         access_log /var/log/nginx/yoga.access.log;
         error_log  /var/log/nginx/yoga.error.log warn;
     }
     ```
   - 逐段解释：`server_name` 匹配 Host 头；`root` 挂 SPA 目录；`try_files` SPA fallback；`/assets/` hash 文件强缓存 1 年；`/api/` 反代 backend；`client_max_body_size` 允许 20MB 上传。

3. **HTTPS 增量配置**（6 分钟）：
   - 有证书时增加 `listen 443 ssl http2;` + `ssl_certificate/key` + `ssl_protocols TLSv1.2 TLSv1.3;`；
   - 80 端口改成 `return 301 https://$host$request_uri;` 全站跳 HTTPS；
   - 证书来源：Let's Encrypt `certbot certonly --standalone -d yoga.example.com` → 证书路径 `/etc/letsencrypt/live/yoga.example.com/fullchain.pem` + `privkey.pem`；
   - 拷到 `./data/certs/yoga.pem` + `yoga.key`，compose 挂 `./data/certs:/etc/nginx/certs:ro`；
   - 90 天到期问题：certbot renew + cron / systemd timer 每日凌晨检查 + `docker compose exec web nginx -s reload`。

#### 课堂活动（15 分钟）

1. **示例演示：全栈全链路一次跑通**（10 分钟）：
   - 先 `docker compose up -d`（4 服务 healthy）；
   - `curl http://localhost/` → 拿到 `index.html`；
   - `curl -X POST http://localhost/api/auth/captcha` → 后端返回 `{key, image}` —— **API 反代通了**；
   - 浏览器打开 `http://localhost/login` → 登录页 → 输 `admin / 123456 / 验证码` → 跳 `/dashboard` → 员工列表出现 —— **全栈闭环**；
   - Chrome DevTools Network 看：所有请求 `/api/*` 都从 `http://localhost/` 发出，**同源**、无 CORS 问题；
   - **「今天，你的项目真的能打开了」**。

2. **反面演示：`proxy_pass` 末尾斜杠**（3 分钟）：
   - 把 `proxy_pass http://backend:8080/;` 的末尾斜杠去掉；
   - `docker compose exec web nginx -s reload`；
   - 浏览器请求 `/api/auth/login` → 后端收到的是 `/api/auth/login` 而不是 `/auth/login` —— Spring Boot 找不到 handler、404；
   - 加回斜杠 → 后端收到 `/auth/login`（前缀 `/api` 被剥掉）—— 通；
   - 板书画红色警告框：**「proxy_pass 末尾斜杠 = 剥掉 location 前缀」**。

3. **AI 生成对照**（2 分钟）：
   - 把「Nginx 反代 Spring Boot 后端 + SPA 前端」需求丢给通义灵码；
   - 常见 AI 错误：① 忘 `try_files` —— SPA 刷新 404；② `proxy_pass` 写 `localhost:8080` —— 容器里连不到；③ 忘 `client_max_body_size` —— 上传大文件 413；④ `proxy_set_header` 只配 `Host` —— 后端拿不到真实 IP；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「Nginx 反代三件事：SPA 托管 + API 转发 + HTTPS 卸载」**。今天你的项目真的**上线**了，下节课我们把「本地 build + push + ssh + up」这条链自动化成 GitHub Actions。

### 3.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-03 Nginx 反代 + 全栈上线                       │
├──────────────────────────────────────────────────────┤
│  location / {                                         │
│    try_files $uri $uri/ /index.html;   ← SPA fallback │
│  }                                                    │
│                                                       │
│  location /assets/ {                                  │
│    expires 1y;                                        │
│    add_header Cache-Control "public, immutable";      │
│  }                                                    │
│                                                       │
│  location /api/ {                                     │
│    proxy_pass http://backend:8080/;   ← 服务名        │
│    proxy_set_header Host $host;                       │
│    proxy_set_header X-Real-IP $remote_addr;           │
│    proxy_set_header X-Forwarded-For $proxy_add_x...;  │
│    proxy_set_header X-Forwarded-Proto $scheme;        │
│  }                                                    │
│                                                       │
│  🔴 proxy_pass 末尾 / 语义                            │
│       http://backend:8080/  → 剥前缀（推荐）           │
│       http://backend:8080   → 保留前缀                │
│                                                       │
│  client_max_body_size 20m;   上传大文件               │
│  gzip on;                    文本压缩                 │
│                                                       │
│  HTTPS：listen 443 ssl http2 + ssl_certificate/key    │
│  证书：certbot / 云厂商 → ./data/certs/               │
└──────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：在本地或云主机上把 4 服务 compose 起来 + `nginx/conf.d/yoga.conf` 配好，浏览器打开 `http://localhost/` 完成登录 + 员工列表加载，交 2 张浏览器截图 + Chrome Network 的 `/api/auth/login` 200 截图；
2. **必做**：故意把 `proxy_pass` 末尾斜杠去掉，观察 backend 收到的 URL（可以在 `EmpController` 加一个 `@GetMapping("/*")` 打印 `HttpServletRequest.getRequestURI()`），交对照截图 + 一句话解释末尾斜杠的作用；
3. **挑战**：申请一个免费域名（freenom / 阿里云个人域名）+ Let's Encrypt 证书，把 nginx 配置改成 HTTPS，浏览器打开 `https://<your-domain>/` 拿到绿色小锁 —— 这就是你的第一个"可放简历的作品链接"。

### 3.6 教学反思提示
- 学生最容易忘 `client_max_body_size` —— 上传头像时报 413 一头雾水；
- `try_files` 里最后一段必须是 `/index.html` 前导斜杠 —— 相对路径会失败；
- HTTPS 证书路径挂载**必须只读** `:ro` —— 防止容器进程被入侵后写坏证书；
- 演示时可以让学生刻意刷新 `/dashboard` 看到 404 —— 引出为什么必须 `try_files`。

---

## 第 4 课时：GitHub Actions CI/CD（自动构建镜像 + push registry）

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能解释 CI（持续集成）与 CD（持续交付 / 持续部署）的边界：CI 到"构建 + 测试 + push 镜像"、CD 到"服务器拉取 + 重启 + 健康检查"；
2. 能写出 `.github/workflows/backend-ci.yml` 完整流水线：`actions/checkout@v4` → `setup-java@v4`（temurin JDK 25）→ `./mvnw test` → `docker/setup-buildx-action@v3` → `docker/login-action@v3`（ACR）→ `docker/build-push-action@v6`（双 tag + gha cache）；
3. 能配 GitHub 仓库 Secrets：`ACR_USER` / `ACR_TOKEN` / `SSH_HOST` / `SSH_USER` / `SSH_KEY`，并解释「Secret 只能写、不能读，一次泄露立即失效」的安全模型；
4. 能实现 tag 策略：`refs/heads/main` → `sha-<8位>` / `refs/tags/v*` → 同名 tag，让"提交 = 版本"天然对齐；
5. 能配 `cache-from: type=gha` + `cache-to: type=gha,mode=max` 让 Docker 层缓存跨构建复用，构建时间从 5 分钟压到 30 秒。

#### 4.1.2 过程与方法目标
1. 通过「先手工 build + push + ssh 走完一遍上线（10 分钟）→ 再让 Actions 自动做（`git push` 一次）」的对照，让学生亲手体会 CI/CD 的杠杆；
2. 通过让 Actions 故意跑一次失败（测试断言错），让学生看到 GitHub Actions 页面里红 ✗ + 邮件通知，训练"CI 兜底"的安全网思维。

### 4.2 教学重难点
- **重点**：`.github/workflows/` 目录约定 / `on: push / tags / workflow_dispatch` 三种触发 / `secrets.XXX` 语法 / `docker/build-push-action@v6` 常用参数（context / push / tags / cache-from / cache-to）/ tag 计算脚本 `TAG=${GITHUB_REF##*/}` + `[[ "$GITHUB_REF" == refs/heads/* ]] && TAG=sha-${GITHUB_SHA:0:8}`
- **难点**：为什么 `secrets.ACR_TOKEN` 只在 workflow 运行时可见、连 fork 的 PR 都拿不到 —— GitHub 安全隔离设计 / `type=gha` 层缓存的原理（GitHub Cache API，10GB 上限，每仓库独立）/ 为什么 monorepo 里 `paths: 'backend/**'` 过滤器很重要 —— 前端改动不该触发后端流水线

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
第 3 课时结尾学生手工做了一次上线：本地 `docker build` → `docker push` → `ssh` → `docker compose pull` → `up -d` —— 5 步、每步都要人肉、忘一步就出错。反问：「我今天改一行代码要重复这 5 步，一周上线 20 次是不是要疯？还有谁能确定'v1.0.1 到底包含了哪些提交'？」引出 CI/CD 的两大价值：**免人肉**、**可追溯**。

#### 目标（2 分钟）
一句话：**「让 `git push origin main` 一次触发 GitHub Actions 自动构建两个镜像并推到 ACR」**。今天先做 CI，明天做服务端一键部署（CD）。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **Secrets 只写不读**——泄露就换、别放代码里
- 🔴 **`cache-from/to: type=gha`**——省时间的关键杠杆

#### 新知讲授（14 分钟）

1. **workflow 目录与触发规则**（4 分钟）：
   - `.github/workflows/backend-ci.yml` 与 `.github/workflows/web-ci.yml` 分离——一个仓库两个流水线；
   - `on:` 三种触发：
     ```yaml
     on:
       push:
         branches: [main]
         tags:     ['v*']
         paths:
           - 'backend/**'
           - '.github/workflows/backend-ci.yml'
       workflow_dispatch:   # 页面上手动点
     ```
   - `paths` 过滤器在 monorepo 里**至关重要**：只有 backend 目录或本 workflow 文件变了才触发；
   - `workflow_dispatch` 让你能在 Actions 页面手动"点一下"重跑——不用改代码。

2. **完整 `backend-ci.yml`**（4 分钟）：
   - 现场敲：
     ```yaml
     name: backend-ci

     on:
       push:
         branches: [main]
         tags:     ['v*']
         paths:
           - 'backend/**'
           - '.github/workflows/backend-ci.yml'
       workflow_dispatch:

     env:
       IMAGE_NAME: yoga/backend
       REGISTRY:   registry.cn-hangzhou.aliyuncs.com

     jobs:
       build-and-push:
         runs-on: ubuntu-latest
         permissions:
           contents: read

         steps:
           - name: Checkout
             uses: actions/checkout@v4

           - name: Set up JDK 25
             uses: actions/setup-java@v4
             with:
               distribution: temurin
               java-version: '25'
               cache: maven

           - name: Unit test
             working-directory: backend
             run: ./mvnw -B -DskipTests=false test

           - name: Compute tag
             id: tag
             run: |
               TAG=${GITHUB_REF##*/}
               [[ "$GITHUB_REF" == refs/heads/* ]] && TAG=sha-${GITHUB_SHA:0:8}
               echo "tag=$TAG" >> $GITHUB_OUTPUT

           - name: Set up Docker Buildx
             uses: docker/setup-buildx-action@v3

           - name: Login to ACR
             uses: docker/login-action@v3
             with:
               registry: ${{ env.REGISTRY }}
               username: ${{ secrets.ACR_USER }}
               password: ${{ secrets.ACR_TOKEN }}

           - name: Build & Push
             uses: docker/build-push-action@v6
             with:
               context: backend
               push:    true
               tags: |
                 ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ steps.tag.outputs.tag }}
                 ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest
               cache-from: type=gha
               cache-to:   type=gha,mode=max
     ```
   - 逐段讲：checkout → JDK → mvn test → tag 计算 → buildx → 登录 ACR → build + push；
   - `distribution: temurin` 是 setup-java 支持的 OpenJDK 发行版（免登录免协议），本地仍以 Oracle JDK 25 为准。

3. **Secrets 配置 + tag 策略**（6 分钟）：
   - 仓库 Settings → Secrets and variables → Actions → New repository secret；
   - 需要配 `ACR_USER` + `ACR_TOKEN`（阿里云 ACR 控制台 → 访问凭证 → 生成 Token）；
   - **强调**：Secret 一旦创建**不可读**——只能覆盖或删除；连仓库 admin 也读不到；
   - tag 策略计算逻辑：
     - `main` 分支推送 → `GITHUB_REF=refs/heads/main` → TAG 先赋 `main`，再进 `if` 覆盖为 `sha-<8位>`；
     - 打 `v1.0.1` tag 推送 → `GITHUB_REF=refs/tags/v1.0.1` → TAG 就是 `v1.0.1`，不进 `if`；
   - 结果：**分支提交每次都有唯一 tag 可追溯、正式版本走 `vX.Y.Z` 语义化**；
   - 前端 CI（`web-ci.yml`）几乎一样，只把 `setup-java` 换 `setup-node@v4`、`./mvnw test` 换 `pnpm -C web build`、context 换 `web`。

#### 课堂活动（15 分钟）

1. **示例演示：从 push 到 CI 全绿**（10 分钟）：
   - 学生克隆自己的仓库、创建 `.github/workflows/backend-ci.yml` + `web-ci.yml`；
   - 配 Secrets `ACR_USER` + `ACR_TOKEN`（用讲师提供的测试账号）；
   - 改一行代码 → `git add .github/workflows/backend-ci.yml backend/pom.xml` → `git commit -m "ci: bootstrap"` → `git push`；
   - 打开 GitHub 仓库 → Actions Tab → 看到 `backend-ci #1` 在跑；
   - 逐步展开 5 个 step：checkout / setup-java（缓存命中 8 秒）/ mvn test（1 分 20 秒）/ buildx / build+push（首次 3 分 30 秒）；
   - 打开阿里云 ACR 控制台 → 看到镜像 `yoga/backend:sha-a1b2c3d4` + `latest` 两个 tag —— **CI 成功**；
   - 再改一行代码、`git push` 一次 → 这次 build+push **只花 25 秒**（层缓存命中）—— **`type=gha` 立竿见影**；
   - 学生第一次感受到 CI 的杠杆：**「从此，push 一次 = 一版镜像自动可用」**。

2. **反面演示：让 CI 挂一次**（3 分钟）：
   - 故意在 `EmpServiceTest.java` 加一个 `assertEquals(1, 2)`；
   - `git push` → Actions 页面 `mvn test` step 红 ✗ → 邮件通知；
   - **这就是 CI 的"安全网"作用**：坏代码根本走不到 build，更不会污染 registry；
   - 修回来 → 再推 → 全绿；
   - 板书画红色警告框：**「CI = 每次 push 都自动跑测试，测试挂了根本推不出镜像」**。

3. **AI 生成对照**（2 分钟）：
   - 把「GitHub Actions 自动构建 Spring Boot Docker 镜像并推 ACR」需求丢给通义灵码；
   - 常见 AI 错误：① 用 `actions/checkout@v2` —— 早已过时，应 `v4`；② 直接把密码写 workflow —— 上 Git 立刻泄露；③ 忘 `docker/setup-buildx-action` —— `build-push-action` 依赖 buildx 后端；④ 用 Dockerfile ARG 传敏感值 —— 会写入镜像层，`docker history` 可读；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「.github/workflows + Secrets + buildx + gha cache = 自动化上线的引擎」**。今天让 push 触发构建 push 镜像，明天让 push 一路推到"服务器重启 + 健康检查"完成 CD 闭环。

### 4.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-04 GitHub Actions CI/CD                        │
├──────────────────────────────────────────────────────┤
│  .github/workflows/backend-ci.yml                    │
│                                                       │
│  on:                                                  │
│    push:                                              │
│      branches: [main]                                 │
│      tags:     ['v*']                                 │
│      paths: ['backend/**']    ← monorepo 过滤         │
│    workflow_dispatch:          ← 手动触发             │
│                                                       │
│  steps:                                               │
│    1. actions/checkout@v4                             │
│    2. actions/setup-java@v4 (temurin 25)              │
│    3. ./mvnw test                                     │
│    4. compute tag (main→sha-8 / tag→v*)               │
│    5. docker/setup-buildx-action@v3                   │
│    6. docker/login-action@v3 (ACR)                    │
│    7. docker/build-push-action@v6                     │
│         cache-from/to: type=gha ← 层缓存              │
│                                                       │
│  🔴 Secrets：ACR_USER / ACR_TOKEN                     │
│      只写不读、泄露即换                               │
│                                                       │
│  🔴 首次构建 3.5 分钟，二次 25 秒 —— gha cache 杠杆    │
└──────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：在自己的 GitHub 私仓写 `.github/workflows/backend-ci.yml` + `web-ci.yml`，配好 Secrets，push 一次后打开 Actions 页面看两个 workflow 全绿，交 workflow 列表截图 + ACR 镜像列表截图；
2. **必做**：故意让一个单元测试断言错，看 Actions 红 ✗ + 邮件通知，再修好 → 全绿，交对照截图 + 一句话总结"CI 的安全网价值"；
3. **挑战**：为 `backend-ci.yml` 增加 `on: pull_request` 触发（只测试、不 push 镜像），本地开一个 PR 分支验证：PR 打开时自动跑测试，合并到 main 才 push 镜像 —— 这就是"分支保护 + CI 强制"的行业标准。

### 4.6 教学反思提示
- 学生最容易犯的错是把 Secret 名字写错（大小写敏感）—— `secrets.acr_token` 会返回空串，login 静默失败；
- `paths` 过滤器要**同时**包含 `.github/workflows/xxx.yml` 自己 —— 否则改 workflow 文件本身不触发；
- 演示层缓存时，第二次构建**必须**不改 Dockerfile 的**前几层**，否则缓存全失效——把 `COPY . .` 放到 `RUN mvn install` 后面是经典做法；
- 提醒学生：**Secrets 在 fork 的 PR 里拿不到** —— 这是 GitHub 的安全设计，不是 bug。

---

## 第 5 课时：一键拉取重启 + 版本回滚 + 备份监控

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能写出 `/opt/yoga/deploy.sh` 完整脚本：`set -euo pipefail` 严格模式 → 参数校验 → `sed` 更新 `.env` 镜像 tag → `docker compose pull` → `up -d --remove-orphans` → 10 次 curl 健康检查 → 失败 exit 1；
2. 能用 `appleboy/ssh-action@v1` 把 CI 与 CD 打通：Actions 构建完镜像后 SSH 到服务器执行 `deploy.sh $tag $tag`；
3. 能理解版本回滚的极简策略：`./deploy.sh v1.0.0 v1.0.0` 一键回到上个版本；语义化版本（`vMAJOR.MINOR.PATCH`）与 Git tag、Docker tag 三者对齐；
4. 能写 `mysqldump --single-transaction --routines --triggers` 备份脚本 + `gzip` + `find -mtime +14 -delete` 保留 14 天，放 `/etc/cron.daily/`；
5. 能列出监控告警的入门方案：Actuator + Prometheus + Grafana / node-exporter / 云厂商监控 / 企业微信 & 钉钉 webhook。

#### 5.1.2 过程与方法目标
1. 通过「先手动敲一次 5 步上线 → 再让 `deploy.sh` 一条命令做完 → 再让 CI 自动 SSH 触发」的三级递进，让学生看到"每一层自动化都是上一层的组合"；
2. 通过「上线 v1.0.1 发现文案有 bug → `deploy.sh v1.0.0 v1.0.0` 60 秒回滚 → 修复后再上 v1.0.2」的完整演练，训练"版本管理 = 灾难演练"的运维思维。

### 5.2 教学重难点
- **重点**：`set -euo pipefail` 四件套（错就退出、变量必声明、管道错传播）/ `sed -i.bak` 备份原文件的原子替换 / `docker compose pull` 只拉指定服务 / 10 次 curl 健康检查循环 / `appleboy/ssh-action` 的 5 个 Secret（HOST/USER/KEY/PORT/SCRIPT）
- **难点**：为什么 `docker compose up -d` 会重启**有变化的**服务而不是全部——compose 的"diff-then-apply"设计 / 数据库回滚为什么危险——迁移脚本可能是**单向的**（DROP COLUMN 无法回退）/ 备份定时任务里 `docker exec` + 密码传递的安全写法

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
第 4 课时把镜像 push 到了 ACR，但**没人 pull**——服务器上还是老版本。反问：「难道每次上线都要 SSH 手工 `docker compose pull && up -d`？测试环境、灰度环境、生产环境三套怎么办？出 bug 了怎么回滚？」引出今天核心：**「脚本化 + 自动化 + 可回滚 = 生产级部署」**。

#### 目标（2 分钟）
一句话：**「写 `deploy.sh`，让服务器接受 tag 参数一键拉取、健康检查、失败退出；再让 GitHub Actions 自动 SSH 触发」**。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **`set -euo pipefail`** —— 错误传播四件套
- 🔴 **健康检查循环** —— 不确认 healthy 就不算部署成功

#### 新知讲授（14 分钟）

1. **`deploy.sh` 脚本结构**（4 分钟）：
   - `/opt/yoga/deploy.sh`：
     ```bash
     #!/usr/bin/env bash
     set -euo pipefail

     cd "$(dirname "$0")"

     usage() {
       echo "Usage: $0 <backend-tag> <web-tag>"; exit 1
     }
     [[ $# -lt 2 ]] && usage

     BACKEND_TAG=$1
     WEB_TAG=$2
     REGISTRY=registry.cn-hangzhou.aliyuncs.com

     echo "==> update .env"
     sed -i.bak \
       -e "s#^BACKEND_IMAGE=.*#BACKEND_IMAGE=${REGISTRY}/yoga/backend:${BACKEND_TAG}#" \
       -e "s#^WEB_IMAGE=.*#WEB_IMAGE=${REGISTRY}/yoga/web:${WEB_TAG}#" \
       .env

     echo "==> docker compose pull"
     docker compose pull backend web

     echo "==> docker compose up -d"
     docker compose up -d --remove-orphans

     echo "==> health check"
     sleep 5
     for i in 1 2 3 4 5 6 7 8 9 10; do
       if curl -fsS http://localhost/api/actuator/health >/dev/null; then
         echo "OK"; exit 0
       fi
       echo "waiting... ($i)"; sleep 3
     done
     echo "backend not healthy, please check logs"; exit 1
     ```
   - 逐段讲：严格模式 → 参数校验 → sed 替换 → pull → up → health check；
   - `sed -i.bak` 会保留原文件为 `.env.bak`，回滚变量方便；
   - `--remove-orphans` 会清理已从 compose 里删掉的旧服务容器。

2. **CI 触发 CD（appleboy/ssh-action）**（4 分钟）：
   - 在 `backend-ci.yml` 末尾追加 Deploy step：
     ```yaml
     - name: Deploy
       if: startsWith(github.ref, 'refs/tags/v')
       uses: appleboy/ssh-action@v1
       with:
         host:     ${{ secrets.SSH_HOST }}
         username: ${{ secrets.SSH_USER }}
         key:      ${{ secrets.SSH_KEY }}
         script: |
           /opt/yoga/deploy.sh ${{ steps.tag.outputs.tag }} ${{ steps.tag.outputs.tag }}
     ```
   - `if: startsWith(github.ref, 'refs/tags/v')` —— 只有打 `vX.Y.Z` tag 才自动部署，普通分支 push 不触发；
   - Secrets 新增 `SSH_HOST` / `SSH_USER` / `SSH_KEY`（私钥），并在服务器 `~/.ssh/authorized_keys` 加对应公钥。

3. **版本回滚 + 备份 + 监控**（6 分钟）：
   - **回滚**：`./deploy.sh v1.0.0 v1.0.0` 秒回上个稳定版；语义化版本让"我要回到 3 天前"变成一条命令；
   - **数据库回滚警告**：如果 v1.0.1 加了 `ADD COLUMN` 或 `DROP COLUMN`，镜像回滚≠数据回滚。Flyway `undo` 有限，务必**上线前 shadow 库先跑一遍迁移**；
   - **mysqldump 备份**：
     ```bash
     # /etc/cron.daily/yoga-mysql-backup.sh
     #!/bin/bash
     set -e
     DATE=$(date +%F)
     docker exec yoga-mysql \
       mysqldump -uroot -p"$MYSQL_ROOT_PASSWORD" --single-transaction \
       --routines --triggers --databases yoga \
       | gzip > /opt/yoga/backup/yoga-$DATE.sql.gz
     find /opt/yoga/backup -mtime +14 -delete
     ```
   - `--single-transaction` 让 InnoDB 表在**一致性快照**上导出，业务无阻塞；
   - **监控**（了解）：应用侧 Actuator + Prometheus + Grafana / 主机侧 node-exporter / 云厂商监控 / 告警走企业微信 / 钉钉 / 飞书 webhook；
   - **安全清单**（快速过一遍）：SSH 密钥登录 + fail2ban / 只开 22 / 80 / 443 / DB & Redis 只内网 / HTTPS + HSTS / 验证码防刷 / `.env` 出 Git / 定期 `docker compose pull` 补 CVE。

#### 课堂活动（15 分钟）

1. **示例演示：完整发布 + 回滚**（10 分钟）：
   - 讲师现场提交一行代码改错误提示 → `git tag v1.0.1 && git push --tags`；
   - Actions 页面：backend-ci / web-ci 依次跑绿 → SSH Deploy step 开始跑；
   - 服务器 `journalctl -u ssh` 看到登录记录、`/opt/yoga/deploy.sh v1.0.1 v1.0.1` 输出；
   - 30 秒后 `OK` —— 浏览器刷新看到新文案；
   - **演练回滚**：讲师故意在 v1.0.2 埋一个前端 bug 上线 → 学生发现 → 讲师 SSH 到服务器 `./deploy.sh v1.0.1 v1.0.1` → 60 秒回滚成功；
   - `ls /opt/yoga/backup/` → 看到今日的 `yoga-2026-07-17.sql.gz`；
   - **「一次完整的发布 → 回滚 → 备份链路，都在你眼皮底下发生了」**。

2. **反面演示：`set -euo pipefail` 缺失的后果**（3 分钟）：
   - 把 `deploy.sh` 开头 `set -euo pipefail` 注释掉；
   - 故意让 `docker compose pull` 失败（网络断开）；
   - 脚本继续走到 `up -d`（拿到的是旧镜像）+ 健康检查（healthy 因为旧版本本来就 healthy）→ **exit 0**；
   - 学生以为部署成功，其实还是老版本 —— **静默失败**；
   - 加回 `set -euo pipefail` → pull 失败立刻 exit 1 → CI 红灯 → 邮件通知；
   - 板书画红色警告框：**「脚本第一行永远是 set -euo pipefail」**。

3. **AI 生成对照**（2 分钟）：
   - 把「写一个 deploy.sh 拉取镜像 + 重启 + 健康检查」需求丢给通义灵码；
   - 常见 AI 错误：① 没 `set -e` —— 静默失败；② 健康检查写 `sleep 30 && curl` 一次就完 —— 慢启动挂 CI；③ `sed` 直接 `-i` 无 `.bak` —— 出错无法恢复；④ 密码 `-p$MYSQL_ROOT_PASSWORD` 走 argv 会在 `ps` 里泄露；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「deploy.sh 让上线可复用、Actions SSH 让上线自动化、语义化版本让回滚变一条命令、mysqldump 让数据永远有备份」**。到这里，你已经掌握了**中小型团队上线一个新功能**的完整闭环。

### 5.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-05 一键部署 + 回滚 + 备份                      │
├──────────────────────────────────────────────────────┤
│  /opt/yoga/deploy.sh                                 │
│                                                       │
│  🔴 set -euo pipefail        错就退                    │
│                                                       │
│  ./deploy.sh v1.0.1 v1.0.1                           │
│  ├─ sed -i.bak .env → 新 tag                          │
│  ├─ docker compose pull backend web                  │
│  ├─ docker compose up -d --remove-orphans            │
│  └─ curl /api/actuator/health × 10 次                │
│                                                       │
│  🔴 版本回滚：./deploy.sh v1.0.0 v1.0.0                │
│      语义化 vX.Y.Z = Git tag = Docker tag             │
│                                                       │
│  CI 触发 CD：                                         │
│    appleboy/ssh-action@v1                            │
│    if: startsWith(github.ref, 'refs/tags/v')         │
│                                                       │
│  备份：/etc/cron.daily/yoga-mysql-backup.sh          │
│    mysqldump --single-transaction                    │
│    gzip → /opt/yoga/backup/yoga-YYYY-MM-DD.sql.gz    │
│    find -mtime +14 -delete                           │
│                                                       │
│  监控：Actuator + Prometheus + Grafana               │
│         node-exporter / 云厂商 / 企微 webhook          │
└──────────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：把 `deploy.sh` 放到自己服务器 `/opt/yoga/`，`chmod +x`，跑一次 `./deploy.sh v1.0.0 v1.0.0` 观察输出全部 OK；再改一行文案 `git tag v1.0.1 && git push --tags` 触发 CI 自动 CD，60 秒内看到线上更新；交 Actions 页面截图 + 浏览器截图；
2. **必做**：把 `yoga-mysql-backup.sh` 放到 `/etc/cron.daily/`，`chmod +x`，等次日凌晨 3 点看 `/opt/yoga/backup/` 出现 `yoga-YYYY-MM-DD.sql.gz`；交 `ls -la` 截图 + `zcat yoga-*.sql.gz | head -20` 截图确认数据完整；
3. **挑战**：给 `deploy.sh` 增加"部署前打日志到企业微信 / 钉钉群机器人 webhook"的功能——用 `curl -X POST` 发一条 `发布 vX.Y.Z 开始 / 完成` 消息，让整个团队都能感知上线动作。

### 5.6 教学反思提示
- 学生最容易忽视 `set -euo pipefail` —— 一定要演示一次静默失败让他们记住；
- `docker exec yoga-mysql mysqldump -p"$MYSQL_ROOT_PASSWORD"` 的密码走 argv 会在其他用户 `ps` 里泄露 —— 生产上应改 `--defaults-extra-file=/etc/yoga/mysql.cnf`；
- `appleboy/ssh-action` 的 SSH_KEY 必须是**私钥内容**（不是路径），且格式是 OpenSSH 或 PEM——学生常拷贝错内容；
- 备份文件应**异地存储**（对象存储 OSS / S3）—— 服务器炸了本地备份也没了，务必强调。

---

## 第 6 课时：全栈回顾 + 项目拓展建议

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能画出**课程完整知识地图**：4 大部分 34 章 107 技术点覆盖的全栈栈层（HTML/CSS/JS → Java/Spring Boot/MyBatis → MySQL/Redis → Vue 3/TS/Pinia → Nginx/Docker/CI-CD）；
2. 能用 5 分钟口头讲清印想瑜伽项目的**技术选型理由**：为什么选 Spring Boot 4 而不是 Node.js、为什么选 Vue 3 而不是 React、为什么选 MySQL 而不是 PostgreSQL；
3. 能列出个人技能进阶的 6 大方向：深入 Spring / 深入前端 / 数据库调优 / 架构 (DDD / CQRS / MQ) / 云原生 (K8s / Helm / Istio) / AI 融合 (RAG / Agent / Function Calling)；
4. 能自己规划 3-5 个"能放简历"的拓展项目题材，说清每个题材的**业务价值 + 技术栈 + 关键难点**；
5. 能建立"AI 辅助编码"的正确心智：AI 是放大器——放大效率也放大品位与判断，人类的**问题拆解 + 代码 review + 生产灾难处置**才是核心竞争力。

#### 6.1.2 过程与方法目标
1. 通过让学生现场把 17 天写过的所有 tech point 拉一张表，让学生亲眼看到自己"从零到全栈"走过的路，建立技术自信；
2. 通过 3-5 个拓展项目的题材头脑风暴，训练"业务发现 → 技术选型 → 里程碑拆分"这一独立项目开发的核心能力。

### 6.2 教学重难点
- **重点**：34 章 mindmap 一张纸盖全 / 拓展项目 3-5 个题材（读书笔记 / 健身打卡 / 二手书城 / AI 智能日记 / 团队协作 Kanban）/ 每个项目的关键技术难点 / "用 AI 干活"的正确姿势
- **难点**：学生最容易问的"接下来学什么" —— 没有唯一答案，只有"找一个自己**用得上**的方向"这一原则 / 如何判断一个新技术值不值得学 —— 看它能不能解决你**真实项目**里遇到的痛点 / 面试与作品：面试考的是问题拆解，作品是最好的名片

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
学生已经站在课程终点线上——项目上线、CI 通了、备份在跑。反问：「17 天前你只会写 `<h1>Hello</h1>`，今天你已经上线了一个能被真实用户使用的 Web 系统。回头看看，你到底学了些什么？下一步该往哪走？」板书大字写下今天两个议题：**「① 回望走过的路 / ② 展望前面的山」**。

#### 目标（2 分钟）
一句话：**「用一张 mindmap 把 17 天 34 章 107 技术点串起来，再给出 3-5 个可以立刻上手的拓展项目建议」**。今天没有新代码，是"整理知识"和"规划下一步"的一天——但可能是全课程**最值钱**的一天。

#### 重难点（2 分钟）
黑板标记两个红色难点符号：
- 🔴 **"学什么"无标准答案** —— 找**用得上**的方向
- 🔴 **AI 是放大器** —— 品位与判断才是护城河

#### 新知讲授（14 分钟）

1. **课程全景 mindmap**（5 分钟）：
   - 现场画：
     ```
     AI 应用 Web 开发
     ├── 第一部分 基础（Day01-Day04）
     │   ├── HTML / CSS / JS / jQuery
     │   ├── Java 语法 + Maven
     │   ├── Spring Boot + MyBatis + MySQL
     │   └── IDEA / Postman / AI 辅助编码
     ├── 第二部分 后端实战（Day05-Day09）
     │   ├── 印想瑜伽会馆项目
     │   ├── Git + 分模块 + CRUD + 分页 + 上传
     │   ├── 日志 + AOP + 全局异常
     │   ├── Redis + Spring Cache + JWT + 拦截器
     │   ├── 图形验证码
     │   └── 多环境配置 (dev/test/prod)
     ├── 第三部分 前端实战（Day10-Day14）
     │   ├── Vue 3 + Vite + TypeScript
     │   ├── Vue Router + Axios 封装 + Pinia
     │   ├── Element Plus + ECharts
     │   ├── 登录 + 全部 CRUD 页面
     │   └── 表单校验 + 权限按钮
     └── 第四部分 部署（Day15-Day17）
         ├── Linux + SSH + systemd + Nginx
         ├── Docker + Dockerfile + Compose
         ├── Nginx 反代 + HTTPS
         └── CI / CD + 版本回滚 + 备份
     ```
   - **34 章 / 107 技术点 / 一个真实项目**——学生一眼看到自己走过的地图。

2. **3-5 个拓展项目建议**（6 分钟）：
   - **① 读书笔记 AI 助手**：
     - 业务：录入读书笔记 → RAG 检索 → 用 AI 生成"这本书讲了什么"的摘要
     - 栈：Spring Boot + Vue + PostgreSQL + pgvector + OpenAI Embedding / 通义千问
     - 难点：Embedding 存储与相似度查询 / Prompt 工程 / 长文本切片
   - **② 健身打卡社区**：
     - 业务：用户打卡 + 好友互赞 + 排行榜 + AI 生成动作分析
     - 栈：Spring Boot + Vue + MySQL + Redis Sorted Set 排行 + WebSocket 实时通知
     - 难点：好友关系图 / 排行榜性能 / 实时推送
   - **③ 二手书城**：
     - 业务：卖家发布 → 买家搜索 → 站内消息 → 微信支付
     - 栈：Spring Boot + Vue + MySQL + Elasticsearch 全文检索 + 微信支付 API
     - 难点：ES 搜索 / 支付回调幂等 / 交易状态机
   - **④ AI 智能日记**：
     - 业务：写日记 → AI 情感分析 + 关键词提取 + 长期回顾（"今年你最开心的一天"）
     - 栈：Spring Boot + Vue + MySQL + OpenAI / 本地开源 LLM (Ollama)
     - 难点：LLM 调用编排 / 隐私加密 / Function Calling
   - **⑤ 团队协作 Kanban（Trello Lite）**：
     - 业务：多人协作看板 + 拖拽卡片 + 实时同步 + 权限
     - 栈：Spring Boot + Vue + MySQL + Redis + Socket.IO / STOMP + JWT
     - 难点：CRDT / OT 并发编辑 / 多人实时 / RBAC 权限模型

3. **"用 AI 干活"的正确姿势 + 后续学习方向**（3 分钟）：
   - AI 是放大器 —— 快速产出代码骨架、但**品位与判断**在你；
   - 三个 AI 反模式：① 复制不 review —— 埋雷；② 让 AI 做架构决策 —— AI 不懂你的业务约束；③ 让 AI 直接接触生产密钥 —— 一次泄露永久风险；
   - 后续 6 大方向（Spring 深入 / 前端 TS + Nuxt + Playwright / SQL 调优 + MySQL 主从 / DDD + CQRS + MQ / K8s + Helm + Istio / RAG + Agent + Function Calling）；
   - 学习方法：**找一个真实业务，从零上线**，比刷 100 个视频有用。

#### 课堂活动（15 分钟）

1. **学生现场输出：我的下一个项目**（10 分钟）：
   - 每个学生 5 分钟写一段：
     - 项目名 + 一句话业务描述
     - 主要用户是谁、要解决什么问题
     - 打算用什么栈（越具体越好）
     - 3 个里程碑（V0.1 能跑通 / V0.5 能给别人用 / V1.0 上线）
   - 讲师随机抽 2-3 个方案点评：业务是否清晰、栈是否合理、里程碑是否可交付。

2. **课程闭幕：3 分钟自由发言**（4 分钟）：
   - 学生任意分享："这 17 天最有收获的一刻" —— 通常是"第一次 Docker up -d 全绿"、"第一次登录页拿到 Token"、"第一次线上被朋友访问"；
   - 讲师留一句结语：**「AI 时代的开发者，最稀缺的不是写代码的手，而是提出好问题的脑」**。

3. **合影 + 项目地址上墙**（1 分钟）：
   - 让每个学生把自己项目的 GitHub 地址 + 上线域名写在教室后墙的看板上——**"这就是你的第一份 AI 时代作品简历"**。

#### 小结（3 分钟）
17 天的课程走到这里正式收官。一句话回顾：**「你从一个 HTML 页面出发，用 17 天搭起一整套"前端 + 后端 + 数据库 + 部署 + CI/CD"的现代 Web 应用，更学会了如何与 AI 协作」**。保持好奇，动手写、动手改、动手上线——你会走得比想象中更远。

### 6.4 板书设计
```
┌──────────────────────────────────────────────────────┐
│  Day17-06 全栈回顾 + 项目拓展建议                     │
├──────────────────────────────────────────────────────┤
│  17 天走过的路：                                      │
│    Day01-04  HTML/CSS/JS + Java + Spring Boot         │
│    Day05-09  瑜伽后端全链路（Redis/JWT/AOP/多环境）    │
│    Day10-14  Vue 3 + Element Plus 全部页面            │
│    Day15-17  Linux/Docker/Compose/CI-CD               │
│    → 34 章 / 107 技术点 / 1 个真实项目                │
│                                                       │
│  🔴 5 个拓展项目建议：                                 │
│    ① 读书笔记 AI 助手（RAG + Embedding）              │
│    ② 健身打卡社区（Sorted Set + WebSocket）           │
│    ③ 二手书城（ES 搜索 + 支付回调）                    │
│    ④ AI 智能日记（LLM + Function Calling）            │
│    ⑤ 团队协作 Kanban（实时协作 + RBAC）               │
│                                                       │
│  🔴 后续学习方向：                                    │
│    Spring 深入 / TS + Nuxt / SQL 调优 /               │
│    DDD + MQ / K8s + Istio / RAG + Agent               │
│                                                       │
│  一句话结语：                                         │
│    AI 是放大器，品位与判断是护城河                     │
│    找一个真实业务，从零上线                            │
└──────────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：在自己的 GitHub 建一个新仓库，写 `README.md` 起草下一个个人项目：题材 + 用户画像 + 技术栈 + 3 个里程碑；提交后把仓库地址交给讲师；
2. **必做**：把印想瑜伽项目部署到自己的**真实域名**上（可以是免费的 vercel / netlify 前端 + 阿里云轻量 backend），拿到一个公开可访问的 URL，作为**第一版简历作品**；
3. **挑战**：从 5 个拓展项目里选一个，用 AI 辅助（通义灵码 / Cursor / Claude Code）花一个周末做出 V0.1 —— 至少能登录 + 完成一个核心业务操作。

### 6.6 教学反思提示
- 学生最容易问的是「学不完怎么办」—— 正确答案是「本来就学不完，只学**用得上**的」；
- 拓展项目里可以让学生**互相 pitch** —— 两两配对讲对方的项目，锻炼"业务讲清楚"的能力；
- 课程收官不要拖泥带水 —— 用一句有力量的结语把课堂拉到高点：**"保持好奇，动手上线，未来是你的"**；
- 记得把课程反馈问卷发给学生，回收后作为下一期课程的迭代输入。

---

## Day17 结课语

> 你从一个 HTML 页面出发，用 17 天搭起一整套"前端 + 后端 + 数据库 + 部署 + CI/CD"的现代 Web 应用。
> 更重要的是，你在整个过程中学会了**如何与 AI 协作**：让它写代码、写文档、写脚本、排查错误。
> AI 是放大器——它放大你的效率，也放大你的品位与判断。
> 保持好奇，动手写、动手改、动手上线，你会走得比想象中更远。
>
> 加油，未来的 AI 时代开发者。

---
