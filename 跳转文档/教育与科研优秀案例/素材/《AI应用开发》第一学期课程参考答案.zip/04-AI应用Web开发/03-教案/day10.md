# 《AI 应用 Web 开发》 - 教师教案（Day10：Spring AOP 实战 + Redis 缓存 + Spring 事务）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day09 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、DTO/VO、Result 统一响应、全局异常处理、参数校验、文件上传 OSS、代理模式与 AOP 五要素概念、`this` 调用不走代理的经典坑）**
**知识点覆盖：** 第 19 章 Spring AOP 实战：操作日志（`@Around` 切面 + `JoinPoint` + SpEL + 异步落库） + 第 20 章 Redis 缓存与 Spring 事务（Redis 8 入门 + `RedisTemplate` + `Spring Cache` 声明式缓存 + `@Transactional` 传播行为 + 缓存与事务共存陷阱）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / Redis 8.0 / Lettuce（Spring Data Redis 默认）/ Spring Cache（`spring-boot-starter-cache`）/ IDEA 2024.3+ / 通义灵码 + Trae。

**Day10 主线**：Day09 我们已经理解了「代理模式 + AOP 五要素 + `this` 调用陷阱」这些**概念**，但真正把 AOP 用在业务上还差临门一脚。今天前 2 个课时把「操作日志」这个团队规约级切面**从注解定义到异步落库**完整落地——`@Around` + `JoinPoint` + SpEL + 独立线程池 + 失败留痕；中间 2 个课时把 Redis 8 请进后端，先讲清 `RedisTemplate` 的序列化、再用声明式 `@Cacheable` / `@CacheEvict` 把「热门课程」「科目详情」的读接口从 30ms 打到 3ms；最后 2 个课时把 `@Transactional` 讲透——传播行为、回滚规则、四大失效场景，并特别拉出「缓存 + 事务共存陷阱」这一节，让学生明白**先写库后删缓存**、**双删补偿**、**事务内不宜清缓存**这些工程折衷。Day10 结束后，会员/课程/科目三条业务线拥有了「审计 + 加速 + 一致」三大能力。

---

## 第 1 课时：`@Around` 统一记录会员操作日志（AOP 实战开篇）

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出「Controller → Service → `@Around` 切面 → 异步线程池 → `tb_op_log` 表」的完整链路图；
2. 能写出 `tb_op_log` 建表 SQL，说清「大字段用 `MEDIUMTEXT`、时间列建组合索引」两个工程约定；
3. 能定义 `@OperationLog(value, module, targetIdEl, logArgs, logResult)` 注解，理解为什么把日志描述写成 SpEL 模板；
4. 能写出 `@Around("@annotation(op)")` 骨架，通过参数 `op` 直接拿到方法上的注解实例；
5. 能使用 `ProceedingJoinPoint.getSignature() / getArgs() / proceed()` 三个 API，并解释「成功 + 异常」两个分支都要留痕的原因。

#### 1.1.2 过程与方法目标
1. 通过「不改 Service 代码，只在方法上加一个注解就能审计」的强对比，让学生亲手体会 AOP 相比传统 try-catch 埋点的**代码密度**优势；
2. 通过手动抛异常的联调剧本，训练「异常路径也要有可观测性」的工程思维。

### 1.2 教学重难点
- **重点**：`@Around` 切面骨架／`@annotation(op)` 直接把方法上的注解注入切面参数／`try-finally` 收敛正常与异常两条路径／`OpLog` DO 里 `operator / ip / cost_ms / success / errMsg` 五个通用字段
- **难点**：为什么 `@Around` 要用 `Object` 作返回值而不是 `void`（要把 `proceed()` 的结果原样返回业务）／`throw ex` 之前必须先在 `finally` 里塞完 `errMsg`（否则异常一走信息就丢了）／`HttpServletRequest` 只能在**切面主线程**里取，不能在异步线程里拿

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
接着 Day09 结尾的「AOP 五要素」板书回顾：切点、通知、连接点、织入、代理。反问：「Day09 我们只是让 `TimingAspect` 在控制台 print 了一行耗时，那要是**每一次会员新增 / 修改 / 删除**都留一条可查询的记录呢？总不能在 300 个 Service 方法里各写一段 `insert into op_log` 吧？」引出**操作日志**这个团队规约级需求。板书写下今天要交付的接口画像：

```
只在 Service 方法上加一个注解 → 后台 tb_op_log 自动落一行
POST /members  @OperationLog(...) →  operator=admin, action=新增会员：张三, cost=42ms
```

#### 目标（2 分钟）
一句话：**「不改 Service 一行代码，靠一个注解 + 一个切面把审计闭环建起来」**。今天先把切面骨架 + 建表 + 最小闭环打通，SpEL 表达式抽参数放到第 2 课时。

#### 重难点（2 分钟）
黑板标记两个难点符号：
- 🔴 `try-finally` 两分支——「日志要成功也记、失败也记」
- 🔴 异步落库时**主线程的信息要先取好**——`HttpServletRequest` 不能带进异步线程

#### 新知讲授（14 分钟）

1. **需求画像与 `tb_op_log` 表结构**（4 分钟）：
   - 板书 11 个字段：`operator / action / module / target_id / method / args / result / success / err_msg / ip / cost_ms / create_time`；
   - 强调**大字段 `args / result` 用 `MEDIUMTEXT`**（16MB 上限，足够 JSON 序列化后的入参 / 返回值）；
   - `KEY idx_module / idx_operator / idx_create_time` 三个索引——时间范围过滤是最常见的运营场景；
   - 口播：**「日志表几乎不做更新，只做插入 + 时间范围查询」**——设计索引就按这两个动作来。

2. **`@OperationLog` 注解设计**（4 分钟）：
   - 五个成员：`value`（动作描述，支持 SpEL）、`module`（模块名）、`targetIdEl`（目标 ID SpEL）、`logArgs`（是否记入参）、`logResult`（是否记返回值）；
   - 讲清**为什么 `value` 要用 SpEL** 而不是纯字符串——同一个 `@OperationLog(value="#{'新增会员：'+#dto.name}", ...)` 可以贴到 20 个不同方法上，动态取入参；
   - `@Target(METHOD) @Retention(RUNTIME) @Documented` 三件套解释一遍，`RetentionPolicy.RUNTIME` 是**必须**的——不然运行时 AOP 拿不到注解。

3. **`@Around` + `@annotation(op)` 切面骨架**（6 分钟）：
   - 现场敲 `@Aspect @Component @RequiredArgsConstructor` 三件套；
   - `@Around("@annotation(op)")` 的**参数注入魔法**：Spring 会把方法上那个注解实例直接塞进切面方法的 `op` 参数——不需要再自己 `method.getAnnotation(OperationLog.class)`；
   - 骨架 `Object around(ProceedingJoinPoint pjp, OperationLog op)`——注意**返回值必须是 `Object`**，否则业务方法的返回值就丢了；
   - `long start = System.currentTimeMillis()` → `try { ret = pjp.proceed(); ... } catch(Throwable ex) { ... throw ex; } finally { record.setCostMs(...); opLogService.saveAsync(record); }`；
   - 强调：**`throw ex` 一定要在 `catch` 里显式写出来**——不 rethrow 事务不知道该回滚，全局异常处理也拿不到异常。

#### 课堂活动（15 分钟）

1. **示例演示：跑通「新增会员 → tb_op_log 落一行」**（8 分钟）：
   - 打开已有的 `MemberController.save`，在 `Service.save(MemberDTO)` 方法上贴 `@OperationLog(value="新增会员", module="member")`（此时 SpEL 还没讲，先用纯字符串占位）；
   - 现场敲 `OperationLogAspect` 骨架：切点、`@Around`、`try-finally`、`opLogService.saveAsync(record)`；
   - Postman `POST /members` 传 `{"name":"张三"}`，返回 200；
   - 用 IDEA 数据库工具连 MySQL 8，`SELECT * FROM tb_op_log ORDER BY id DESC LIMIT 1`，学生应看到一行 `action=新增会员 module=member method=MemberService.save cost_ms=约 40ms success=1`；
   - 投影展示这一行——**「一行注解 = 一行审计记录」**，学生第一次亲眼看到 AOP 的杠杆效应。

2. **抽 2 位同学复现异常路径**（5 分钟）：
   - 让学生传 `{"name":"张三"}` 两次——第二次触发 `BizException("姓名已存在")`；
   - 检查 `tb_op_log`：应有一行 `success=0 err_msg=姓名已存在`，且 `cost_ms` 仍有值；
   - 提问：「如果我在 `catch` 里忘写 `throw ex`，前端会看到什么？」（预期回答：前端拿到 200 但业务其实失败了——**灾难级 Bug**）；
   - 板书画一个红色警告框：**「AOP 里 catch 之后必须 rethrow」**。

3. **AI 生成对照**（2 分钟）：
   - 把「Spring Boot 4 操作日志切面」需求丢给通义灵码；
   - 观察 AI 常见错误：① 忘 `@EnableAspectJAutoProxy`（Spring Boot 3+ 一般自动开，但值得提）；② `catch` 后没 rethrow；③ 直接用 `record.getArgs().toString()` 而不 JSON 序列化，list/map 参数会打印一坨 `[Ljava.lang.Object;@xxx`；
   - **AI 常犯错清单**记到黑板。

#### 小结（3 分钟）
一句话回顾：**「`@Around` + `@annotation(op)` + `try-finally` = 团队级审计切面的三件套」**。今天只做了「静态描述」，下节课把 `value` 与 `targetIdEl` 换成 SpEL，让一个切面适配所有业务方法。

### 1.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-01 @Around 统一操作日志                 │
├────────────────────────────────────────────────┤
│  链路四段：                                    │
│   Controller → Service.@OperationLog           │
│   → @Around 切面 → OpLogService.saveAsync      │
│                                                │
│  tb_op_log 关键字段：                          │
│   operator / action / module / target_id       │
│   method / args / result / success / err_msg   │
│   ip / cost_ms / create_time                   │
│   大字段 MEDIUMTEXT，时间列组合索引            │
│                                                │
│  切面骨架：                                    │
│   @Aspect @Component                           │
│   @Around("@annotation(op)")                   │
│   Object around(ProceedingJoinPoint, op)       │
│   try{ ret=proceed() }                         │
│   catch(ex){ 记 errMsg ; throw ex }            │
│   finally{ 记 cost ; saveAsync }               │
│                                                │
│  🔴 catch 必须 rethrow                         │
│  🔴 HttpServletRequest 只能主线程取            │
└────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：把 `@OperationLog(value="新增会员", module="member")` 贴到 `MemberService.save / update / delete` 三个方法上，联调三种场景（成功 / 姓名重复 / 主键不存在），交 3 张 `tb_op_log` 截图；
2. **必做**：整理「Spring AOP 常用切点表达式」速查表，至少覆盖 `@annotation()`、`execution(* com.yinxiang..service..*(..))`、`within()`、`args()` 四种；
3. **挑战**：改造 `record.setMethod(...)`，把签名从 `MemberService.save` 升级成 `MemberService.save(MemberDTO)`，思考参数类型全限定名会不会太长（提示：考虑 `Class.getSimpleName()`）。

### 1.6 教学反思提示
- 学生最容易在 `catch` 里忘 `throw ex`——示例演示时故意先漏一次让学生找 Bug；
- `@Around` 的返回值类型如果写成 `void`，业务方法有返回值时会直接返回 `null`，前端 `data` 变空——建议第一遍演示时保留这个坑；
- `tb_op_log` 表如果学生连的是共享数据库，务必提前建好；否则切面里 SQL 抛异常又被 `saveAsync` 里的 `catch (Exception e)` 吞掉，学生会误以为「切面没执行」。

---

## 第 2 课时：自定义 `@Log` 注解 + SpEL 取参数

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能用 `DefaultParameterNameDiscoverer` + `SpelExpressionParser` + `TemplateParserContext("#{", "}")` 三件套把 SpEL 表达式在切面里跑起来；
2. 能理解 `#dto`（按参数名）与 `#arg0`（按索引）两种引用方式的差异，并解释为什么推荐前者；
3. 能通过 `-parameters` 编译参数让 SpEL 拿到真实参数名（Maven 项目 `spring-boot-maven-plugin` 默认加，纯手写 pom 要自己配）；
4. 能使用 `#_ret` 内置变量在切面里引用返回值，实现「新增接口返回值就是 target_id」的场景；
5. 能给 `@OperationLog` 加上 `logResult=true`、`logArgs=false` 两个开关，学会给上传接口关掉 args JSON 打印以防 `MultipartFile` 序列化炸栈。

#### 2.1.2 过程与方法目标
1. 通过「一份切面适配 5 个业务方法」的重构，让学生亲身感受**声明式编程**的复用价值；
2. 通过打开 IDEA 反编译窗口观察 `.class` 里的 `LocalVariableTable`，让学生知道「参数名并非天然存在，是编译期塞进去的」。

### 2.2 教学重难点
- **重点**：`ParameterNameDiscoverer` 解析参数名／`SpelExpressionParser + TemplateParserContext("#{", "}")` 双件套解析 `#{...}` 模板／`ctx.setVariable("_ret", ret)` 把返回值注入 SpEL 上下文
- **难点**：**参数名丢失**问题——没加 `-parameters` 编译时 SpEL 里 `#dto` 会解析成 `null`，只有 `#arg0` 才能取到值／`MultipartFile` 参数不能进 args JSON

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接上节课的板书：现在 `@OperationLog(value="新增会员", module="member")` 里的 `value` 是**死字符串**——**每一个不同业务都得写一个专属 value**。但项目里有 20 个 Service 方法，都想在 `action` 里带上业务实体的名字（如「新增会员：张三」「删除课程：id=42」）——难道要在切面里 `switch(method.getName()) { case "save": ... }`？—— **SpEL** 就是为这个场景准备的。

#### 目标（2 分钟）
一句话：**「让 `@OperationLog` 的每一个字段都能从入参 / 返回值动态取值，让一份切面适配全项目」**。

#### 重难点（3 分钟）
- 🔴 参数名解析——**Maven pom 一定要打开 `-parameters` 编译**
- 🔴 SpEL 里想用 `#{...}` 模板必须显式给 `TemplateParserContext`，否则只能写裸表达式 `#dto.name`

#### 新知讲授（16 分钟）

1. **SpEL 三件套**（6 分钟）：
   - `DefaultParameterNameDiscoverer` —— 解析方法参数名（依赖编译期 `-parameters`）；
   - `SpelExpressionParser` —— 解析 SpEL 表达式；
   - `TemplateParserContext("#{", "}")` —— 声明「`#{...}` 是模板占位符」，普通字符串按字面处理；
   - 现场画切面里的调用图：`method + args → PND 取参数名 → EvaluationContext.setVariable → PARSER.parseExpression(tpl, ctx) → getValue(ctx)`。

2. **`EvaluationContext` 装填**（4 分钟）：
   - `String[] names = PND.getParameterNames(method)`；
   - `for (int i=0; i<names.length; i++) ctx.setVariable(names[i], args[i])`；
   - **额外塞一个内置变量**：`ctx.setVariable("_ret", ret)` —— 让注解里能写 `#{#_ret.id}` 引用返回值；
   - 抽学生问：**「为什么参数名可能是 null？」**（答：pom 没打开 `-parameters`）——引出下一段。

3. **`-parameters` 编译参数**（3 分钟）：
   - Spring Boot 官方 starter 从 3.2 起，`spring-boot-maven-plugin` 默认加了 `-parameters`——绝大多数学生开箱即用；
   - **但**：手写 pom、切换到 Gradle、老项目升级——都可能漏；
   - 现场演示：把 pom 里的 `<parameters>true</parameters>` 注释掉，重新 build，切面里 `PND.getParameterNames(method)` 返回 `[arg0]`，注解里 `#dto.name` 直接抛 `SpelEvaluationException`；
   - 板书救急口诀：`SpelEvaluationException: EL1008E → 立刻检查 -parameters`。

4. **`logArgs / logResult` 开关**（3 分钟）：
   - 反问：「文件上传接口 `upload(MultipartFile file)` 也想加 `@OperationLog`，你会踩什么坑？」（预期：Jackson 序列化 `MultipartFile` 触发 `StackOverflowError`）；
   - 解决：`@OperationLog(logArgs=false)` 关闭 args 序列化；
   - 反过来：`@OperationLog(logResult=true)` 打开返回值序列化——常用在「新增接口，返回新记录 id」的审计。

#### 课堂活动（15 分钟）

1. **示例演示：一份切面适配 5 个方法**（8 分钟）：
   - 现场把上节课 5 个业务方法上的 `@OperationLog` 全部改成 SpEL 版本：
     - `MemberService.save(MemberDTO dto)` → `@OperationLog(value="#{'新增会员：'+#dto.name}", module="member", targetIdEl="#{#_ret}")`
     - `MemberService.update(MemberDTO dto)` → `@OperationLog(value="#{'修改会员：'+#dto.name}", module="member", targetIdEl="#{#dto.id}")`
     - `MemberService.delete(List<Long> ids)` → `@OperationLog(value="#{'删除会员：ids='+#ids}", module="member", targetIdEl="#{#ids[0]}")`
     - `CourseService.publish(Long id)` → `@OperationLog(value="#{'发布课程：'+#id}", module="course", targetIdEl="#{#id}")`
     - `CourseService.save(CourseDTO dto)` → `@OperationLog(value="#{'新增课程：'+#dto.title}", module="course", targetIdEl="#{#_ret}", logResult=true)`；
   - Postman 分别调这 5 个接口，投影展示 `tb_op_log` 的 5 行——学生能直观看到「一份切面适配所有业务」。

2. **抽学生现场制造 `SpEL` 报错**（4 分钟）：
   - 让学生把 `#dto.name` 故意写成 `#dot.name`（笔误）；
   - 观察异常栈：`SpelEvaluationException` + `Property or field 'name' cannot be found on null`；
   - 讨论：切面里的 SpEL 报错该不该影响业务？—— **绝对不能**——`evalSpEL` 外面必须再包一层 `try-catch`，SpEL 报错时降级为 `""` 空字符串 + `log.warn` 一次。

3. **AI 助手对照**（3 分钟）：
   - 让 AI 生成「SpEL 表达式解析器」，观察是否会：① 漏掉 `TemplateParserContext`；② 忘掉 `_ret` 内置变量；③ 用 `#p0 #p1` 而不是 `#dto` 语法（前者不依赖 `-parameters` 但可读性差）；
   - 补充规约：**注解里的 SpEL 必须用参数名**（`#dto`），不许用 `#p0 #arg0`。

#### 小结（3 分钟）
一句话回顾：**「SpEL 让注解从『标签』升级成『微型 DSL』」**。今天所有会员 / 课程 / 教练 CRUD 都获得了免费的审计，Day10 的 AOP 部分收官。接下来 4 个课时换赛道——把 Redis 请进后端。

### 2.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-02 @Log 注解 + SpEL                     │
├────────────────────────────────────────────────┤
│  SpEL 三件套：                                 │
│   PND       —— 解析参数名                      │
│   SpelParser —— 解析表达式                     │
│   TemplateParserContext("#{","}")              │
│                                                │
│  上下文变量：                                  │
│   ctx.setVariable("dto",  args[0])             │
│   ctx.setVariable("_ret", ret)  ← 返回值       │
│                                                │
│  注解写法：                                    │
│   value="#{'新增会员：'+#dto.name}"            │
│   targetIdEl="#{#_ret}"                        │
│   logArgs=false  ← MultipartFile 关掉          │
│                                                │
│  🔴 pom -parameters 必须开                     │
│  🔴 SpEL 报错不能反噬业务：外层再包 try        │
└────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：把 Day07 的 `CourseService` 全部 CRUD 方法加上 SpEL 版 `@OperationLog`，5 个接口联调后交 `tb_op_log` 截图；
2. **必做**：给 `@OperationLog` 加一个新字段 `sensitive: String[]` 表示「入参哪些字段要脱敏」（如 `password / idCard`），落库前用 Jackson `ObjectMapper` 覆盖为 `***`；
3. **挑战**：把 `@Log` 注解 + 切面抽成 `yinxiang-common` 模块，让整个团队直接 import 使用；思考如何在 starter 里暴露一个 `@ConditionalOnMissingBean` 的 `OperationLogAspect`，业务方可以覆盖默认实现。

### 2.6 教学反思提示
- SpEL 是本节最容易翻车的地方——学生手滑打错单引号、多打空格、`#{}` 与 `${}` 混用都常见；示例演示时投影窗口调大字号；
- 若课堂时间紧，可把「AI 助手对照」环节压缩成课后任务；核心是**每个学生亲手让 SpEL 的 `#_ret` 生效**——这个 API 后面第 5、第 6 课时的事务与缓存不会再讲，跳车太早以后会补不上；
- `-parameters` 这一段建议**故意演示崩一次**——不然学生看不到 SpEL 参数名解析失败的真实报错，以后遇到会花一整天排查。

---

## 第 3 课时：Redis 入门 + Spring Data Redis + StringRedisTemplate

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能用 Docker 起 Redis 8（`docker run -d --name redis8 -p 6379:6379 redis:8.0`），并通过 `redis-cli PING → PONG` 验证；
2. 能说清 Redis 8 六种常用数据结构（String / Hash / List / Set / ZSet / Stream）各自的典型业务场景；
3. 能在 Spring Boot 4 引入 `spring-boot-starter-data-redis` + `commons-pool2`，配置 `spring.data.redis.host / port / password / lettuce.pool`；
4. 能写 `RedisConfig` 类，用 `StringRedisSerializer` + `GenericJackson2JsonRedisSerializer` 替换默认 JDK 序列化，避免 Redis 里存二进制乱码；
5. 能使用 `StringRedisTemplate` / `RedisTemplate<String,Object>` 实现「手机号 60 秒发送限流」「课程报名人数原子自增」两个印想瑜伽会馆真实场景。

#### 3.1.2 过程与方法目标
1. 通过 `redis-cli` 直接敲命令，让学生形成「Redis = 一个可编程的内存 KV」的直观印象，而不是先跳到 Spring 抽象；
2. 通过「JDK 序列化 vs JSON 序列化」在 `redis-cli GET` 里的对比，让学生亲眼看到「乱码 vs 可读」的差异——理解为什么必须自定义序列化器。

### 3.2 教学重难点
- **重点**：Docker 起 Redis 8 与 `redis-cli` 手感／六大数据结构和场景匹配／Spring Data Redis 依赖与 Lettuce 连接池配置／`RedisConfig` 里 `StringRedisSerializer` + `GenericJackson2JsonRedisSerializer` 的组合
- **难点**：**必须自定义 `RedisTemplate` Bean** 覆盖默认——不覆盖会拿到 JDK 序列化的乱码；`opsForValue().setIfAbsent(key, val, ttl)` 是**原子** SET NX EX 命令而不是 SET + EXPIRE 两步

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
从性能问题切入：Day08 的课程列表接口需要 3 张表 LEFT JOIN + 分页，SQL 平均耗时 30ms。前端首页每分钟刷新几十次，一天下来这条 SQL 被执行几十万次。**MySQL 磁盘 + 索引扫描的极限就在这里**——再优化 SQL 也逃不出 10ms 量级。而 Redis 内存访问只要 0.1ms——**300 倍**性能差距。板书：`MySQL 30ms  vs  Redis 0.1ms  →  300×`。

#### 目标（2 分钟）
一句话：**「今天先让 Redis 8 在 Docker 里跑起来，再让 Spring Boot 能用 `RedisTemplate` 读写 Redis，最后完成两个真实业务：短信限流 + 报名人数」**。

#### 重难点（2 分钟）
- 🔴 **`RedisTemplate` 序列化必须自定义**——默认 JDK 序列化会写入 `\xac\xed\x00\x05...` 乱码
- 🔴 `setIfAbsent(key, val, ttl)` **必须一次调用**——绝不允许 `set` 完再 `expire`（中间宕机会造成 key 永不过期）

#### 新知讲授（15 分钟）

1. **Docker 起 Redis 8 + `redis-cli` 手感**（4 分钟）：
   - 现场敲 `docker run -d --name redis8 -p 6379:6379 redis:8.0`；
   - `docker exec -it redis8 redis-cli`；
   - `PING → PONG`；`SET hello world EX 60 → GET hello → "world"`；`TTL hello → 60`；
   - 提问：「`EX 60` 是干嘛的？」（预期：60 秒过期）——引出 TTL 概念。

2. **六大数据结构 & 场景表**（5 分钟）：
   - 表格列出：
     | 结构 | 命令 | 印想瑜伽会馆场景 |
     |---|---|---|
     | String | `GET/SET/INCR` | 会员登录 Token、课程报名计数 |
     | Hash | `HSET/HGET` | 会员资料局部更新 |
     | List | `LPUSH/RPOP` | 待推送短信队列、消息时间线 |
     | Set | `SADD/SISMEMBER` | 会员标签去重、教练特长集合 |
     | ZSet | `ZADD/ZRANGE` | 教练热度排行榜、课程报名榜 |
     | Stream | `XADD/XREAD` | 轻量级操作日志消息总线 |
   - 每种结构只讲一个印想业务案例，不深入。

3. **Spring Data Redis 依赖 + `application.yml`**（3 分钟）：
   - `spring-boot-starter-data-redis` + `commons-pool2`；
   - `spring.data.redis.host / port / password / timeout: 3s / lettuce.pool.{max-active,max-idle,min-idle}`；
   - 强调 Spring Boot 4 用 **Lettuce** 而不是 Jedis——Lettuce 基于 Netty，天生支持异步与响应式，Jedis 是老古董。

4. **`RedisConfig` 自定义序列化**（3 分钟）：
   - 板书：
     ```
     Key       →  StringRedisSerializer
     Value     →  GenericJackson2JsonRedisSerializer(objectMapper)
     HashKey   →  String
     HashValue →  JSON
     ```
   - 附加要点：`ObjectMapper` 里 `registerModule(JavaTimeModule)` + `disable(WRITE_DATES_AS_TIMESTAMPS)`——不注册 `JavaTimeModule` 反序列化 `LocalDateTime` 会直接抛异常；
   - `activateDefaultTyping(...)` 让 JSON 里带上 `@class` 元信息，反序列化能还原成原类而不是 `LinkedHashMap`。

#### 课堂活动（14 分钟）

1. **示例演示：手机号 60 秒发送限流**（6 分钟）：
   - 场景：会员注册页要发短信验证码，防止一个手机号 60 秒内被反复请求；
   - 现场写：
     ```java
     String key = "sms:limit:" + phone;
     Boolean ok = redisTemplate.opsForValue()
         .setIfAbsent(key, "1", Duration.ofSeconds(60));
     if (!Boolean.TRUE.equals(ok)) throw new BizException("发送过于频繁，请稍后再试");
     ```
   - Postman 联调：第一次 200，第二次 200 但抛 `BizException`；60 秒后再试 → 恢复；
   - `redis-cli GET sms:limit:13800138000` 应能看到 `"1"`；`TTL` 剩下几十秒。

2. **抽 3 位同学：课程报名人数原子自增**（5 分钟）：
   - 场景：印想瑜伽某网红课程报名超库存要拒；
   - 现场写：
     ```java
     Long v = redisTemplate.opsForValue().increment("course:booked:" + courseId);
     if (v > capacity) {
         redisTemplate.opsForValue().decrement("course:booked:" + courseId);
         throw new BizException("已满员");
     }
     ```
   - 让学生开 2 个 Postman 标签并发 POST，观察 Redis 里的计数值；
   - 提问：**为什么不能先 `GET` 再判断再 `INCR`？** —— 因为 `GET + 判断 + INCR` 不是原子操作，两个线程都会通过判断。

3. **乱码演示**（3 分钟）：
   - **临时把 `RedisConfig` 注释掉**，重启项目，再打一次报名接口；
   - 到 `redis-cli` 执行 `GET course:booked:1` → 显示 `"\xac\xed\x00\x05sr\x00\x11java.lang.Long..."`；
   - 学生第一次亲眼看到 JDK 序列化的乱码——**「这就是不配 `RedisConfig` 的下场」**；
   - 恢复配置，`GET` 应得到干净的 `1`。

#### 小结（3 分钟）
一句话回顾：**「Redis 8 + Docker + Lettuce + JSON 序列化 = Spring Boot 4 使用 Redis 的最佳姿势」**。今天写的都是**编程式**（`redisTemplate.opsForValue()...`）——下节课换成**声明式**（`@Cacheable`），让 Spring 帮你自动读写缓存。

### 3.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-03 Redis 入门 + RedisTemplate           │
├────────────────────────────────────────────────┤
│  基础：                                        │
│   docker run -d -p 6379:6379 redis:8.0         │
│   PING → PONG                                  │
│   SET k v EX 60 / GET k / TTL k                │
│                                                │
│  依赖 & 配置：                                 │
│   spring-boot-starter-data-redis (Lettuce)     │
│   commons-pool2                                │
│   spring.data.redis.host/port/password/pool    │
│                                                │
│  序列化组合（RedisConfig）：                   │
│   Key   → StringRedisSerializer                │
│   Value → GenericJackson2JsonRedisSerializer   │
│   ObjectMapper 注册 JavaTimeModule             │
│                                                │
│  常见用法：                                    │
│   setIfAbsent(k, v, TTL) → 分布式锁 / 限流     │
│   increment(k)            → 计数 / 库存        │
│                                                │
│  🔴 不自定义 RedisConfig → 乱码                │
│  🔴 setIfAbsent + TTL 必须一次调用             │
└────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：本机装好 Docker 与 Redis 8，`PING → PONG` 截图；
2. **必做**：把「手机号 60 秒限流」和「课程报名人数原子自增」两个业务都跑通，各交 2 张截图（Postman + `redis-cli`）；
3. **挑战**：用 ZSet 实现「教练热度排行榜」——`ZADD coach:rank 42 张老师`，前端读取 `ZREVRANGE coach:rank 0 9 WITHSCORES`；如何设计 TTL？（提示：如果排行榜要按「每周」滚动，Key 里带上周数）。

### 3.6 教学反思提示
- 学生第一次接触 Docker 常见问题：Windows 学生没启动 Docker Desktop、Linux 学生要 `sudo`——课前群里发一份「Docker 环境自检脚本」；
- `RedisConfig` 的 `ObjectMapper` 里如果没开 `defaultTyping`，反序列化会得到 `LinkedHashMap`——学生业务里想 `.getName()` 就抛 `ClassCastException`——这个坑今天不深入，下节课再补；
- 若课时紧张，`Stream` 数据结构可以只提一嘴不演示，重点保 String / Hash / ZSet 三个印想业务用得最多的。

---

## 第 4 课时：Spring Cache `@Cacheable / @CacheEvict` + Redis 作缓存

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能通过 `@EnableCaching` + `RedisCacheManager` Bean 让 Spring Cache 用 Redis 作缓存后端；
2. 能画出 `RedisCacheManager` 的分层配置：`cacheDefaults` 定义**基线**（默认 10 分钟 TTL、禁用 null 缓存），`withInitialCacheConfigurations` 为 `course / subject` 等**具名缓存**指定差异化 TTL；
3. 能在 `SubjectService` 上写 `@Cacheable(cacheNames="subject", key="#id", unless="#result==null")`、`@CachePut`、`@CacheEvict(allEntries=true)` 三个注解，理解三者语义差异；
4. 能通过 `redis-cli KEYS subject::*` 观察 Spring Cache 的 Key 结构（`cacheName::key`），并解释 `::` 是默认分隔符；
5. 能读懂 IDEA 控制台 SQL 日志——首次进 DB / 二次命中缓存 / `@CacheEvict` 后再次进 DB——三段闭环。

#### 4.1.2 过程与方法目标
1. 通过「先看到 SQL 二次执行 → 加注解 → SQL 消失」的对比演示，训练学生用**日志作为验证工具**；
2. 通过对比「编程式 `redisTemplate` vs 声明式 `@Cacheable`」的代码密度，理解声明式编程的**约束换效率**。

### 4.2 教学重难点
- **重点**：`@EnableCaching` + `RedisCacheManager`／`@Cacheable / @CachePut / @CacheEvict` 三注解语义／`cacheNames + key` 组合决定 Redis Key 格式／`unless` 与 `condition` 的差异
- **难点**：**`@Cacheable` 也会经过 AOP 代理**——`this.detail(id)` 内部调用不走缓存（和 `@Transactional` 一模一样的坑）／`allEntries=true` 会遍历整个 cacheName 目录，海量 key 时性能陡降

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接上节课的 `redisTemplate.opsForValue().set(...)` 编程式风格——反问：「如果我把它包成一个模板方法：先 `get`，命中返回；不命中回源 DB，再 `set` 回缓存——是不是每一个读接口都要抄一遍？」引出**声明式**：`@Cacheable` 让 Spring 帮你把「查缓存 → 回源 → 写缓存」这三步吞进注解里。

#### 目标（2 分钟）
一句话：**「让科目详情、课程详情两个读接口通过一个注解获得 300× 性能提升，且业务方法本身零改动」**。

#### 重难点（2 分钟）
- 🔴 `@Cacheable` 走 AOP，**同类 `this` 调用不生效**——和 `@Transactional` 是同一个坑
- 🔴 `@CacheEvict(allEntries=true)` 慎用，海量 key 场景会拖垮 Redis

#### 新知讲授（15 分钟）

1. **`RedisCacheManager` 分层配置**（5 分钟）：
   - `@EnableCaching` 打开开关；
   - `RedisCacheConfiguration.defaultCacheConfig()` 拿到默认配置；
   - `.entryTtl(Duration.ofMinutes(10))` 设默认 TTL；
   - `.serializeKeysWith(String)` + `.serializeValuesWith(JSON)` 与上节课呼应；
   - `.disableCachingNullValues()` —— **默认不缓存 null**（后面「缓存穿透」章节会打脸这一句）；
   - `withInitialCacheConfigurations(Map)` 为具名 cache 覆盖 TTL：`subject` → 1 小时（变更少）、`course` → 5 分钟（变更中等）。

2. **三大注解语义**（5 分钟）：
   - 板书三行表：
     | 注解 | 时机 | 语义 |
     |---|---|---|
     | `@Cacheable` | 方法前 | 查缓存，命中返回；未命中执行方法后写缓存 |
     | `@CachePut` | 方法后 | **一定执行方法**，把返回值写缓存（用于**更新**） |
     | `@CacheEvict` | 方法后 | 执行方法后删缓存（`beforeInvocation=true` 改为方法前） |
   - `key = "#id"` —— SpEL 表达式（和第 2 课时的 SpEL 是**同一套**）；
   - `unless = "#result == null"` —— 「除非返回值为 null，否则缓存」——**注意 `unless` 是取反语义**，学生特别容易记反。

3. **`condition` vs `unless`**（3 分钟）：
   - `condition="#id > 0"` —— 满足条件才「介入」（写 / 读缓存）；
   - `unless="#result == null"` —— 「除非满足否则」写缓存——两者时机不同：`condition` 方法前后都判，`unless` 只能拿到 `#result` 所以只能方法后判；
   - **口诀**：读用 `condition` 拦非法参数，写用 `unless` 拦坏结果。

4. **Redis Key 命名格式**（2 分钟）：
   - 默认 `cacheName::key` —— 如 `subject::1`，两个冒号是**分隔符**；
   - Spring Boot 4 默认没加 `key-prefix`，如果多个服务共用一个 Redis 建议在 `RedisCacheConfiguration.computePrefixWith` 里加上 `service-name:` 前缀。

#### 课堂活动（15 分钟）

1. **示例演示：`SubjectService.detail` 从 30ms 打到 3ms**（8 分钟）：
   - 打开 IDEA 控制台，`show sql=true`；
   - Postman `GET /subjects/1` —— 控制台看到 `SELECT * FROM tb_subject WHERE id=1`，返回 30ms；
   - 加注解：`@Cacheable(cacheNames="subject", key="#id", unless="#result==null")`；
   - 再打 `GET /subjects/1` —— 控制台 SQL **不再出现**，接口返回 3ms；
   - `redis-cli KEYS subject::* → 1) "subject::1"`；`GET subject::1` 看到 JSON；
   - **首次进库 → 二次命中缓存**闭环打通。

2. **抽 2 位学生现场加 `@CacheEvict`**（4 分钟）：
   - `@CacheEvict(cacheNames="subject", key="#id")` 加到 `delete(Long id)` 方法上；
   - Postman `DELETE /subjects/1` → `KEYS subject::*` 应返回空；
   - 再 `GET /subjects/1` → 控制台重新出现 SQL（缓存被清）；
   - 提问：「`@CachePut` 和 `@Cacheable` 都能实现『更新 + 回写』，你更选哪个？」（预期答：`@Cacheable` 会跳过方法体，`@CachePut` 一定执行；**更新**永远选 `@CachePut`）。

3. **`this` 调用坑复现**（3 分钟）：
   - 在 `SubjectService` 里加一个方法 `pageWithDetail()`，内部循环 `this.detail(id)`；
   - 打开 SQL 日志，跑一次 100 条数据的分页；
   - 观察到 100 条 SQL 全部执行——**缓存完全失效**；
   - 揭示：`@Cacheable` 走 AOP，同类 `this` 调用不走代理——与 Day09 的 `@Async / this` 坑是**同源**问题；
   - 解法预告：注入自己 (`@Autowired private SubjectService self`) 或者拆到不同类，第 6 课时再展开。

#### 小结（3 分钟）
一句话回顾：**「Spring Cache = 声明式 Redis 缓存，`@Cacheable / @CachePut / @CacheEvict` 三注解就够 90% 场景」**。今天读接口获得了 300× 提升，但也埋下三个坑：缓存穿透、击穿、雪崩，以及缓存 + 事务共存陷阱——第 6 课时统一处理。

### 4.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-04 Spring Cache + Redis                 │
├────────────────────────────────────────────────┤
│  开关：                                        │
│   @EnableCaching                               │
│   RedisCacheManager Bean                       │
│                                                │
│  分层 TTL：                                    │
│   cacheDefaults(TTL=10m,null=false)            │
│   withInitialCacheConfigurations(Map)          │
│     subject → 1h                               │
│     course  → 5m                               │
│                                                │
│  三注解：                                      │
│   @Cacheable  先查缓存                         │
│   @CachePut   一定执行 + 回写                  │
│   @CacheEvict 执行完后删                       │
│                                                │
│  Key 结构：cacheName::key   (subject::1)       │
│                                                │
│  🔴 this.method 不走缓存（同 @Transactional）  │
│  🔴 allEntries=true 慎用                       │
│  💡 缓存穿透 / 击穿 / 雪崩 → 第 6 讲           │
└────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：给 `SubjectService.detail / update / delete` 加齐 `@Cacheable / @CachePut / @CacheEvict` 三件套，联调「首次进库 → 命中 → 更新回写 → 命中新值 → 删除穿透」五步剧本；
2. **必做**：给 `CourseService.hotTop10()` 加 `@Cacheable(cacheNames="course", key="'hot-top10'")`——注意 SpEL 里的**字符串常量要加单引号**，很多学生第一次栽在这里；
3. **挑战**：`@CacheEvict(cacheNames="course", allEntries=true)` 会不会**清掉**同一个 Redis 里其他业务的 key？（提示：Spring Cache 只按 `cacheName::` 前缀扫描，不会误伤）。

### 4.6 教学反思提示
- `unless` 与 `condition` 学生极易混淆——建议在黑板画一个「方法前 / 方法后」时间轴强化记忆；
- IDEA 控制台的 SQL 日志一定要**提前打开**（`logging.level.org.mybatis: DEBUG` 或 `mybatis-plus.configuration.log-impl: StdOutImpl`），否则学生看不到「命中缓存 → SQL 消失」这个关键现象，本节课的效果打折扣；
- 若课堂剩余 5 分钟，可现场演示 `@CacheEvict(beforeInvocation=true)` 的差异，帮学生记住「方法失败也删缓存」的边界场景。

---

## 第 5 课时：Spring 声明式事务 `@Transactional`（传播行为 + 回滚规则）

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能画出 Spring 声明式事务的执行链路：AOP 代理 → `TransactionInterceptor` → `PlatformTransactionManager.getTransaction` → 方法体 → `commit / rollback`；
2. 能背诵 5 种主要传播行为（`REQUIRED / REQUIRES_NEW / NESTED / SUPPORTS / NEVER`）的语义与典型场景；
3. 能理解 `@Transactional` 默认只对 `RuntimeException / Error` 回滚，配置 `rollbackFor = Exception.class` 让受检异常也触发回滚；
4. 能列出 `@Transactional` 四大失效场景：`this` 调用 / catch 未 rethrow / 默认不回滚受检异常 / 非 public 方法；
5. 能写出 `REQUIRES_NEW` 的典型用例——「记录预约失败日志」在外层事务回滚时仍能提交。

#### 5.1.2 过程与方法目标
1. 通过「先跑通一个失败案例再修好」的顺序，让学生对每个失效场景形成肌肉记忆；
2. 通过对比「Day09 `this` 调用 AOP 陷阱」与「今天 `this` 调用事务陷阱」，让学生理解**同一个根因**（都是 AOP 代理）驱动多个业务问题。

### 5.2 教学重难点
- **重点**：`@Transactional` 五种传播行为／`rollbackFor` 与受检异常／四大失效场景／`REQUIRES_NEW` 的正确用途
- **难点**：**「事务是绑定线程的」**——`@Async` 方法开新线程，事务不传播过去；**「事务只在方法退出时才决定 commit/rollback」**——方法内部 catch 掉异常 = 事务照常提交

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
从一个「祖传 Bug」切入：Day07 会员注册接口里 `memberMapper.insert(member); pointsMapper.insertInitialPoints(member.getId());` 两句写在一起，但没有加事务。反问：「如果 `pointsMapper.insertInitialPoints` 抛异常，`tb_member` 的记录会不会回滚？」预期回答：不会——学生就理解「事务不是自动的，必须声明」。板书：**「`@Transactional`：三个字符换来一致性」**。

#### 目标（2 分钟）
一句话：**「今天把 `@Transactional` 讲透——传播行为背 5 个，失效场景背 4 个，能在 30 秒内定位任何『事务没生效』的报警」**。

#### 重难点（2 分钟）
- 🔴 `this.method()` 内部调用**不走代理**——事务、缓存、AOP、`@Async` 四个都栽在这里
- 🔴 默认**只回滚 `RuntimeException`**——受检异常必须写 `rollbackFor = Exception.class`

#### 新知讲授（14 分钟）

1. **执行链路**（3 分钟）：
   - 板书：`调用 → Spring AOP 代理 → TransactionInterceptor.invoke → getTransaction → 方法体 → commit or rollback`；
   - 强调**代理**——和 `@Cacheable / @Async / @OperationLog` 一样都是 AOP，理解一个就理解全部；
   - 提问：「代理对象和 `this` 是不是同一个对象？」（预期：不是——`this` 是原始实例，代理是 CGLIB 生成的子类实例）。

2. **五种传播行为**（5 分钟）：
   - 板书表：
     | 值 | 语义 | 场景 |
     |---|---|---|
     | `REQUIRED`（默认） | 有事务加入，没有则新建 | 90% 场景 |
     | `REQUIRES_NEW` | 挂起外层事务，新开一个 | 记日志、发短信——**不希望被外层回滚** |
     | `NESTED` | 嵌套 SAVEPOINT，可独立回滚 | 复杂业务分块 |
     | `SUPPORTS` | 有则加入，没有以非事务运行 | 只读方法 |
     | `NEVER / MANDATORY / NOT_SUPPORTED` | 罕用 | 特殊校验 |
   - 隔离级别一笔带过：**保留数据库默认（MySQL 是 `REPEATABLE_READ`）**——绝大多数业务不用改。

3. **四大失效场景**（4 分钟）：
   - `this.method()` 内部调用不走代理——**必背**；
   - catch 掉异常没 rethrow 或没 `TransactionAspectSupport.currentTransactionStatus().setRollbackOnly()`；
   - 受检异常（`IOException` 等）默认不回滚——必须 `rollbackFor = Exception.class`；
   - 方法非 public——Spring AOP 只切 public；
   - **每个场景现场写一段错代码放在讲义**，本课时课堂活动会跑通。

4. **`REQUIRES_NEW` 的正确姿势**（2 分钟）：
   - 印想瑜伽场景：会员预约课程失败要记 `tb_audit_log`；
   - 外层 `bookingService.book(...)` 是 `REQUIRED`，中间 `auditService.write(log)` 是 `REQUIRES_NEW`；
   - 即使外层回滚，`write(log)` 那一句已在**独立事务**里提交——审计不丢；
   - 前提：**必须通过 Spring 代理调用** `auditService`，不能 `this.write(...)`。

#### 课堂活动（15 分钟）

1. **示例演示：4 个失效场景逐个跑通**（10 分钟）：
   - **场景 A：`this.method` 坑**——`MemberService.register` 里 `this.savePoints(...)`，故意抛 `RuntimeException` → `tb_member` 未回滚；
     - 修法：注入 `@Autowired private MemberService self; self.savePoints(...)` → 回滚生效；
   - **场景 B：catch 未 rethrow**——`register` 里包 `try{ savePoints() } catch(Exception e){ log.warn... }` → 不回滚；
     - 修法：要么 rethrow，要么 `TransactionAspectSupport.currentTransactionStatus().setRollbackOnly()`；
   - **场景 C：受检异常不回滚**——`register throws IOException` 抛出 → 不回滚；
     - 修法：`@Transactional(rollbackFor = Exception.class)`；
   - **场景 D：private 方法**——把 `register` 改成 `private` → 事务完全不生效（`@Transactional` 是「声明但没人切」的死代码）；
     - 修法：改回 public。
   - 每个场景**先看错误现象**（`tb_member` 里有脏数据）**再改正**，让学生亲眼验证。

2. **抽 2 位同学演示 `REQUIRES_NEW`**（4 分钟）：
   - `bookingService.book(...)` 里在最后手动 `throw new BizException("已满员")`；
   - `auditService.write(log)` 用 `@Transactional(propagation = REQUIRES_NEW)` 提前记一行；
   - 联调后：`tb_booking` 无数据（外层回滚），`tb_audit_log` 有数据（内层已提交）；
   - 学生第一次亲眼看到「独立事务」的价值。

3. **AI 陷阱题**（1 分钟）：
   - 把这段代码丢给 AI：
     ```java
     @Transactional public void a() { b(); c(); }
     @Transactional(propagation = REQUIRES_NEW) public void b() { insert(); }
     @Transactional public void c() { throw new RuntimeException(); }
     ```
   - 问：**「b 和 c 分别是否回滚？」**——期望 AI 答：`c` 与 `a` 同一事务一起回滚；`b` 已在独立事务提交，**不受影响**。前提：`b` `c` 是**代理调用**。

#### 小结（3 分钟）
一句话回顾：**「`@Transactional` = AOP + `TransactionInterceptor`，5 种传播行为 + 4 大失效场景背熟就够 95% 场景」**。下节课把今天的事务与前 3 节课的缓存拼一起——**「事务里能不能删缓存？双写怎么保证一致？」**——最后一道坎。

### 5.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-05 @Transactional 传播行为 + 失效       │
├────────────────────────────────────────────────┤
│  执行链路：                                    │
│   Proxy → TransactionInterceptor               │
│   → getTransaction → body → commit/rollback    │
│                                                │
│  五种传播：                                    │
│   REQUIRED (默认)      有事务加入              │
│   REQUIRES_NEW         挂起外层，新开          │
│   NESTED               SAVEPOINT               │
│   SUPPORTS             读方法                  │
│   NEVER/MANDATORY      罕用                    │
│                                                │
│  🔴 四大失效：                                 │
│   ① this 内部调用不走代理                      │
│   ② catch 未 rethrow                           │
│   ③ 默认不回滚受检异常                         │
│      → rollbackFor = Exception.class           │
│   ④ 非 public 方法                             │
│                                                │
│  典型：审计日志用 REQUIRES_NEW                 │
└────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：把四大失效场景各写一个 Demo，交 8 张截图（每场景 = 错前 + 修后 两张）；
2. **必做**：给 `BookingService.book` 加 `@Transactional(rollbackFor = Exception.class)`，`AuditService.write` 加 `REQUIRES_NEW`，联调「预约失败但审计留痕」剧本；
3. **挑战**：查 Spring 源码 `TransactionAspectSupport.invokeWithinTransaction`，画出「事务开始 → 执行 → commit / rollback」的详细流程图，交手绘或 draw.io。

### 5.6 教学反思提示
- 四大失效场景一定要**现场跑一遍**——只讲理论学生 3 天忘光；
- `this` 陷阱与 Day09 的 `@Async / this` 陷阱是同一个根因——建议现场翻回 Day09 板书对照，形成「一个坑，四个副本（`@Transactional / @Async / @Cacheable / 自定义 AOP`）」的记忆锚点；
- 如果时间紧张，`NESTED` 传播可以只提一嘴不演示——`REQUIRED / REQUIRES_NEW` 才是主战场。

---

## 第 6 课时：事务 + 缓存共存陷阱（双写一致性 + 方法内自调失效）

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能画出 Cache Aside Pattern（旁路缓存）的读 / 写两条路径，并解释「先写库后删缓存」优于「先写库后更新缓存」的两个原因；
2. 能实现「双删补偿」——写库后立即删缓存，异步 500ms 后再删一次，应对并发脏读；
3. 能识别「缓存穿透 / 击穿 / 雪崩」三种问题的成因，说出至少两种解决方案（空值缓存 / 布隆过滤器 / 互斥锁 / TTL 抖动 / 多级缓存）；
4. 能理解「事务方法内不宜清缓存」的原因——事务未提交时缓存已删，其他线程读回旧数据回填新缓存，一致性反而破坏；
5. 能应用 `@TransactionalEventListener(phase=AFTER_COMMIT)` 或 `TransactionSynchronizationManager.registerSynchronization` 把「删缓存」推迟到事务提交后。

#### 6.1.2 过程与方法目标
1. 通过并发场景模拟（两个 Postman 并发），让学生亲手复现「双写不一致」的脏读；
2. 通过对比「事务内清缓存 vs 事务后清缓存」的时序图，训练**画时序图定位并发 Bug**的能力。

### 6.2 教学重难点
- **重点**：Cache Aside 模式／双删补偿／缓存三大问题（穿透 / 击穿 / 雪崩）与对应解法／`@TransactionalEventListener(AFTER_COMMIT)`
- **难点**：**事务未提交时删缓存 = 灾难**——并发读线程会用**旧数据**回填缓存；**方法内自调**（同一 `SubjectService` 里 `@CacheEvict` 方法调用另一个 `@Cacheable` 方法）**同样不走代理**——缓存清理与回填全部失效

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
接第 4 课时和第 5 课时的埋点：读接口有了 `@Cacheable`，写接口有了 `@Transactional`——现在把两者**拼一起**：`SubjectService.update` 既要 `@Transactional` 又要 `@CacheEvict`——**先执行哪个？如果之间有并发读会不会脏读？** 学生一般会答「先删缓存再写库」——今天要打破这个直觉。板书两问：**「先写库还是先删缓存？」「事务提交前删还是提交后删？」**

#### 目标（2 分钟）
一句话：**「今天把缓存 + 事务这最后一道坎打过——一句话原则是『先写库、事务提交后再删缓存，且必要时补一次双删』」**。

#### 重难点（3 分钟）
- 🔴 **事务里 `@CacheEvict` 不安全**——`AFTER_COMMIT` 才是正确时机
- 🔴 **方法内自调**再一次栽在这里（`@Cacheable` 也是 AOP）
- 💡 缓存三大问题（穿透 / 击穿 / 雪崩）——三招解

#### 新知讲授（15 分钟）

1. **Cache Aside Pattern**（4 分钟）：
   - **读**：先读缓存，未命中读库，回写缓存；
   - **写**：**先写库，成功后删缓存**（不是**更新**缓存）；
   - 为什么是**删而不改**：改缓存时算错、字段漏改、并发覆盖都比「下一次读时回源」更危险；
   - 反问：「先删缓存再写库不好吗？」——不好，因为写库失败 = 缓存已丢 + 数据未变，下一次读会**重新写入旧数据**，缓存永远比数据库旧。

2. **双删补偿**（3 分钟）：
   - 场景：线程 A 写库中 → 线程 B 读缓存未命中 → B 回源 DB 读到**旧数据** → B 写回缓存 → A 删缓存（此时 A 已删）→ 线程 C 读到**旧数据**；
   - 解法：**写完后立即删 + 异步 500ms 后再删一次**：
     ```java
     subjectMapper.update(...);
     redis.delete("subject::" + id);
     executor.schedule(() -> redis.delete("subject::" + id), 500, TimeUnit.MILLISECONDS);
     ```
   - 500ms 是经验值——只要**大于**并发读的回源时间即可。

3. **三大缓存问题**（5 分钟）：
   - **穿透**：查询必然不存在的 key（如 id=-1），缓存永远不命中；
     - 解：**空值也缓存**（去掉 `disableCachingNullValues`）+ 短 TTL；或 **布隆过滤器**；
   - **击穿**：热点 key 过期瞬间大量并发穿到 DB；
     - 解：**互斥锁**（`setIfAbsent` 抢锁）+ 递归重试；或**物理不过期 + 逻辑过期**；
   - **雪崩**：大量 key 同时过期或 Redis 挂了；
     - 解：**TTL 加随机抖动**（`5 分钟 + Random(0, 60秒)`）+ Caffeine 本地缓存兜底 + Redis 哨兵 / 集群。

4. **`@TransactionalEventListener(AFTER_COMMIT)`**（3 分钟）：
   - 事务内清缓存的问题：事务未提交 → 缓存已删 → 并发读回填**旧数据** → 事务回滚 → **缓存和数据库都是旧数据**——最坏结果；
   - 解法：让「删缓存」等事务真正提交后再执行：
     ```java
     @Transactional public void update(SubjectDTO dto) {
         subjectMapper.update(convert(dto));
         eventPublisher.publishEvent(new SubjectUpdatedEvent(dto.getId()));
     }
     @Component
     class SubjectCacheListener {
         @TransactionalEventListener(phase = AFTER_COMMIT)
         public void onUpdated(SubjectUpdatedEvent e) {
             redis.delete("subject::" + e.getId());
         }
     }
     ```
   - 也可以用 `TransactionSynchronizationManager.registerSynchronization(...)` 直接注册 hook——效果一样，推荐前者可读性更好。

#### 课堂活动（14 分钟）

1. **示例演示：并发脏读复现**（6 分钟）：
   - 打开 2 个 Postman 标签：A `PUT /subjects/1` 改标题，B `GET /subjects/1` 反复读；
   - 在 `update` 方法里故意加 `Thread.sleep(1000)` 模拟慢事务；
   - 学生观察：A 慢事务期间 B 反复读到**旧值**并回填缓存 → A 事务提交 + `@CacheEvict` 生效 → **但**缓存里已经是 B 刚回填的旧值 + `@CacheEvict` 又清了一次 → 下一次 B 读会真正命中新库；
   - 讨论：**如果 `@CacheEvict` 写在方法体开头**（`beforeInvocation=true` 或**先删缓存再写库**）会怎样？—— **更差**——脏读窗口拉长到整个方法执行期。

2. **抽学生现场改造为 `AFTER_COMMIT` 事件**（5 分钟）：
   - 把 `@CacheEvict` 从 `SubjectService.update` 上删掉；
   - 在方法内 `eventPublisher.publishEvent(...)`；
   - 新增 `SubjectCacheListener` 类，`@TransactionalEventListener(phase = AFTER_COMMIT)` 处理事件；
   - 再跑并发复现 → 脏读窗口收敛到「事务提交后 500ms 之内」——需要 → 双删补偿收尾。

3. **方法内自调坑**（3 分钟）：
   - 在 `SubjectService.batchImport` 里 `this.save(dto)` 循环调用；
   - `save` 上有 `@CachePut(cacheNames="subject", key="#dto.id")`；
   - 观察：`batchImport` 完成后 `KEYS subject::*` **为空**——因为 `this.save` 没走代理，`@CachePut` 完全失效；
   - 修法与 Day10-05 一模一样：注入 `self`，或改用 `applicationContext.getBean(SubjectService.class).save(...)`。

#### 小结（3 分钟）
一句话回顾：**「Cache Aside + 双删 + `AFTER_COMMIT` = 缓存与事务共存的工程折衷」**。至此 Day10 六节课把「审计（AOP）+ 加速（缓存）+ 一致（事务）」三个能力全部装进印想瑜伽会馆系统。Day11 开始进入预约管理 CRUD 与状态机——本日为下周的高并发业务打好了底座。

### 6.4 板书设计
```
┌────────────────────────────────────────────────┐
│  Day10-06 事务 + 缓存共存陷阱                  │
├────────────────────────────────────────────────┤
│  Cache Aside：                                 │
│   读：cache → miss → DB → 回写                 │
│   写：DB → 删缓存（不是更新）                  │
│                                                │
│  双删补偿：                                    │
│   DB + delete + schedule(500ms, delete)        │
│                                                │
│  三大问题：                                    │
│   穿透 → 空值缓存 / 布隆过滤器                 │
│   击穿 → 互斥锁 / 逻辑过期                     │
│   雪崩 → TTL 抖动 / 多级缓存                   │
│                                                │
│  🔴 事务里删缓存 = 脏读                        │
│      → @TransactionalEventListener             │
│           (phase = AFTER_COMMIT)               │
│                                                │
│  🔴 方法内 this.save 不触发 @CachePut          │
│      → self.save / getBean                     │
└────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：把 `SubjectService.update` 改造为 `@TransactionalEventListener(AFTER_COMMIT)` 清缓存 + 双删补偿，交 Postman 并发脏读复现前后对比截图；
2. **必做**：给 `CourseService.detail` 加「TTL 5 分钟 + `Random(0, 60秒)` 抖动」的雪崩防护——提示：`RedisCacheConfiguration` 的 `entryTtl` 只支持固定值，需要自定义 `RedisCacheWriter` 或者用 `redisTemplate` 编程式实现；
3. **挑战**：用 Guava `BloomFilter` 给 `SubjectService.detail` 加上布隆过滤器兜底——启动时把 `SELECT id FROM tb_subject` 全灌进过滤器，非法 id 直接短路。

### 6.6 教学反思提示
- 并发脏读复现现场如果没跑出来，别慌——检查是否在 `update` 里加了 `Thread.sleep(1000)`；这个演示的**时序**比代码更重要，学生必须亲眼看到「B 用旧值回填缓存」这一步；
- `@TransactionalEventListener(AFTER_COMMIT)` 有个前提——**事务必须存在**——如果 `update` 忘加 `@Transactional`，事件根本不会派发（Spring 4.2+ 默认 `fallbackExecution=false`），学生排查半天；建议**先让他们踩一次坑**再讲这个开关；
- 本日六课时信息密度大，最后 3 分钟建议留给「Day10 全景回顾」——回到 Day10 开头板书的「审计 + 加速 + 一致」，学生画一张自己的知识图。

---

## Day10 全日回顾与 Day11 预告

**Day10 交付物盘点**：
- `@OperationLog` 注解 + `OperationLogAspect` 切面（`@Around` + SpEL + 异步落库）+ `tb_op_log` 表 → 全项目审计能力
- Redis 8 + Docker + `RedisConfig`（JSON 序列化）+ `StringRedisTemplate` → 编程式缓存打底
- `@EnableCaching` + `RedisCacheManager` + `@Cacheable / @CachePut / @CacheEvict` → 声明式缓存
- `@Transactional`（`REQUIRED / REQUIRES_NEW` + `rollbackFor + AFTER_COMMIT`）→ 一致性保底

**Day11 预告**：预约管理 CRUD + 状态机——学生会用到今天所有工具：审计留痕、Redis 计数（报名人数）、事务保证「扣减库存 + 生成预约」原子性。今天所有的工程折衷都会在明天的高并发场景里被再次验证。
