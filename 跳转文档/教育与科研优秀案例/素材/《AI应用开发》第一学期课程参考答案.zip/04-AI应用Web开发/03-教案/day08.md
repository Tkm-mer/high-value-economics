# 《AI 应用 Web 开发》 - 教师教案（Day08：多表关联设计与课程管理·查询 + 课程管理·新增/修改/删除）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day07 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、DTO/VO、Result 统一响应、全局异常、Bean Validation、日志基础，且已经把「教练」「教室」「会员」三张单表 CRUD 全部走通）**
**知识点覆盖：** 第 15 章 多表关联设计与课程管理·查询（tb_course 表设计 + resultMap 一对一映射 + 分页多表联查）+ 第 16 章 课程管理·新增/修改/删除（DTO 与业务校验 + 时间冲突检测 + 状态流转 + 删除策略 + Controller 汇总）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / Vue 3.5+ / pnpm 9 / MySQL 8.0 / Redis 8.x / Docker 24+ / IDEA 2024.3+ / 通义灵码 + Trae。

**Day08 主线**：印想瑜伽会馆前 7 天已经把教练、教室、会员三张「资源型」主数据全部落地，从今天开始把它们**串起来**——「课程 = 教练 + 教室 + 时间段 + 容量 + 报名人数」。**前 3 个课时**打通「查」的链路：`tb_course` 表 DDL → `resultMap` 一对一嵌套映射 → 分页多表联查 SQL；**后 3 个课时**打通「写」的链路：DTO 分层与外键存在性校验 → 时间冲突检测的四情形推导 → 状态机流转与删除策略。整整一天下来，学生应能独立交付课程模块的六个接口（POST / PUT / PATCH / DELETE / GET/{id} / GET 分页），并且**用 AI 生成冲突检测**时能把 AI 常犯的错误一眼揪出来。

---

## 第 1 课时：课程模块承上启下 + tb_course 表设计

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能说出「课程」在整个印想瑜伽会馆系统中的位置——为什么要放到项目后半段，它依赖前面哪些模块；
2. 能画出「教练 ↔ 课程 ↔ 教室」三张表的关联图，并说出每个外键字段是谁指向谁；
3. 能独立设计 `tb_course` 表 DDL，覆盖 13 个业务字段（含 `enrolled_count`、`status`、`deleted` 等）；
4. 能给 `tb_course` 表加出合理的索引（外键单列索引 + 冲突检测复合索引 + 状态过滤索引），并解释为什么；
5. 能说清「物理外键 vs 应用层校验」两种方案的取舍，且知道生产环境为什么普遍**不用**物理外键。

#### 1.1.2 过程与方法目标
1. 通过「先画业务图再画表结构」的顺序，训练「以业务实体为中心」的数据建模思维；
2. 通过对比「教练表 / 教室表」（单表）与「课程表」（关联表）的字段差异，理解「资源型主数据 vs 关联型业务数据」的区别。

### 1.2 教学重难点
- **重点**：课程模块的定位（关联型业务数据）／`tb_course` 表的 13 个业务字段的取值语义／外键索引与冲突检测复合索引的建法
- **难点**：为什么生产环境不用物理外键约束（分库分表 / 数据订正 / 性能三重代价）／`(coach_id, room_id, start_time)` 复合索引对冲突检测 SQL 的加速原理

### 1.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
以印想瑜伽会馆的实际场景切入：**投影**打开前面 7 天的接口清单——教练 CRUD、教室 CRUD、会员 CRUD 都完成了，但学生做完这三个模块会发现「系统还是空壳」，因为**没有一节真正的课**。抛出问题：**「同学们想一想，会馆真正每天在卖什么？」**——不是教练档案，也不是教室档案，而是**一节一节的课**。今天开始的两天，就是把课程模块从零到一做出来。**板书顶行**：`Day08 课程 = 教练 + 教室 + 时间段 + 容量 + 报名人数`。

#### 新知讲授（16 分钟）

1. **课程模块承上启下**（4 分钟）：**投影**画 ER 图——`tb_coach` 一条线连到 `tb_course`（`coach_id`），`tb_room` 另一条线连到 `tb_course`（`room_id`），未来还会有 `tb_booking` 连到 `tb_course`（Day10 讲）。**口播**：为什么课程放在项目后半段？因为它**依赖前面所有模块**——教练还没建你怎么选教练？教室还没建你怎么选教室？会员还没建谁来上课？这是「资源型主数据 → 关联型业务数据 → 交易型流水数据」的经典分层。**抽学生**：请第 3 排同学复述「资源型」和「关联型」的区别。

2. **`tb_course` 表 13 个字段逐一讲**（7 分钟）：**投影** DDL 边讲边指——

```sql
CREATE TABLE tb_course (
  id              BIGINT       PRIMARY KEY AUTO_INCREMENT,
  title           VARCHAR(100) NOT NULL             COMMENT '课程标题',
  coach_id        BIGINT       NOT NULL             COMMENT '授课教练 id（应用层校验，非物理外键）',
  room_id         BIGINT       NOT NULL             COMMENT '上课教室 id',
  start_time      DATETIME     NOT NULL             COMMENT '开始时间',
  end_time        DATETIME     NOT NULL             COMMENT '结束时间',
  capacity        INT          NOT NULL             COMMENT '容量上限',
  enrolled_count  INT          NOT NULL DEFAULT 0   COMMENT '已报名人数',
  status          TINYINT      NOT NULL DEFAULT 0   COMMENT '0 待开始 1 报名中 2 进行中 3 已结束 4 已取消',
  fee             DECIMAL(10,2) NOT NULL            COMMENT '课程费用',
  intro           TEXT                              COMMENT '课程介绍',
  cover_url       VARCHAR(255)                      COMMENT '课程封面 URL',
  create_time     DATETIME     DEFAULT CURRENT_TIMESTAMP,
  update_time     DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  deleted         TINYINT      DEFAULT 0            COMMENT '0 未删 1 已删（逻辑删除）'
) COMMENT='课程';
```

   逐个讲三个坑点：① `capacity` 与 `enrolled_count` 分开存——为什么不即时 `SELECT COUNT(*)`？答：高并发抢报名时聚合太慢；② `status` 用 `TINYINT` 而不是枚举字符串——省空间且便于加索引；③ `fee` 用 `DECIMAL(10,2)`，**永远不要用 `FLOAT`/`DOUBLE` 存金额**——`0.1 + 0.2 ≠ 0.3` 的经典坑。

3. **索引设计**（3 分钟）：**板书**四条索引——

```sql
KEY idx_coach   (coach_id),                       -- 教练维度查询
KEY idx_room    (room_id),                        -- 教室维度查询
KEY idx_status  (status),                         -- 状态过滤（报名中的课程列表）
KEY idx_conflict(coach_id, start_time, end_time)  -- 冲突检测复合索引
```

   **口播**为什么复合索引前缀是 `coach_id`：MySQL B+Tree 的最左前缀原则，冲突检测 SQL 里 `coach_id = ? AND start_time ... AND end_time ...` 会走这条索引，命中率极高。

4. **物理外键的取舍**（2 分钟）：**投影**一张对比表——

| 维度 | 物理外键（`FOREIGN KEY`） | 应用层校验（Service 里 `assertXxx`） |
|------|---------------------------|--------------------------------------|
| 数据一致性 | DB 强保证 | 靠代码保证，需覆盖测试 |
| 分库分表 | ❌ 完全不支持 | ✅ 天然支持 |
| 性能 | 每次写都触发校验 | Service 层可选做批量校验 |
| 数据订正 | 极难（要先禁用约束） | 直接 SQL 就能补 |

   **结论**：本项目**不用**物理外键，把它写在建表脚本注释里——`应用层校验，非物理外键`。抽学生问：如果就是想用物理外键教学，会怎么写？答：`FOREIGN KEY (coach_id) REFERENCES tb_coach(id)`——课后可以试，但项目代码里去掉。

#### 示例演示（13 分钟）

1. **现场建表**（5 分钟）：打开 IDEA 的 Database 工具窗，连到本地 MySQL 8.0，执行上面的 DDL。**投影**成功截图：`Table tb_course created, 0 rows affected`。然后 `SHOW CREATE TABLE tb_course` 反向拿出 DDL，重点让学生看**索引部分**。

2. **测试数据准备**（5 分钟）：现场敲三条 `INSERT`——

```sql
INSERT INTO tb_course (title, coach_id, room_id, start_time, end_time, capacity, fee, intro)
VALUES ('周一晨间哈他', 1, 1, '2026-07-20 08:00:00', '2026-07-20 09:00:00', 20, 88.00, '基础哈他，适合初学者'),
       ('周二夜阴瑜伽', 1, 2, '2026-07-21 20:00:00', '2026-07-21 21:00:00', 12, 128.00, '深度放松'),
       ('周三流瑜伽',   2, 1, '2026-07-22 19:30:00', '2026-07-22 20:30:00', 20, 128.00, '高强度');
```

   然后 `SELECT * FROM tb_course` 看结果。**故意**问学生：为什么 `enrolled_count` 显示是 0？答：DEFAULT 0。

3. **AI 生成 DDL 对照**（3 分钟）：给通义灵码贴需求「MySQL 8 建表：课程表 tb_course，含教练/教室外键、时间段、容量、状态、逻辑删除」。**观察 AI 常犯错**：① 直接加 `FOREIGN KEY`（要手动去掉）；② `fee` 用 `FLOAT`；③ `status` 忘了给 `NOT NULL DEFAULT`；④ 忘了冲突检测的复合索引。**AI 常犯错清单**当堂列到黑板。

#### 课堂练习（10 分钟）
1. 每位学生在本地 MySQL 8.0 建 `tb_course` 表，交 `SHOW CREATE TABLE` 截图；
2. 插入 5 条测试课程（教练/教室 id 用前几天已建好的真实数据），交 `SELECT COUNT(*)` 结果；
3. 思考题：如果 `capacity` 允许改小（如从 20 改到 10），但当前 `enrolled_count = 15`，DB 层怎么处理？答：**DB 不管**，业务层要在 UPDATE 前校验。

#### 小结（3 分钟）
一句话回顾：**课程是关联型业务数据，13 个字段，4 条索引，不用物理外键**。下一课时把这张表的字段映射到 Java 侧的实体和 VO，并用 MyBatis `resultMap` 把 JOIN 结果拼成嵌套对象。

### 1.4 板书设计
```
┌────────────────────────────────────────────────────┐
│  Day08-01  tb_course 表设计                        │
├────────────────────────────────────────────────────┤
│  课程 = 教练 + 教室 + 时间段 + 容量 + 报名人数    │
│                                                    │
│  三层结构：                                        │
│   资源主数据 → 关联业务数据 → 交易流水数据       │
│   (coach/room)  (course)      (booking, Day10)   │
│                                                    │
│  关键字段（13 个）：                              │
│   id  title  coach_id  room_id                    │
│   start_time  end_time                             │
│   capacity  enrolled_count                         │
│   status(0-4)  fee(DECIMAL!)                       │
│   intro  cover_url                                 │
│   create/update_time  deleted                      │
│                                                    │
│  索引 4 条：                                       │
│   idx_coach     单列，教练维度查询                │
│   idx_room      单列，教室维度查询                │
│   idx_status    单列，状态过滤                    │
│   idx_conflict  (coach_id, start_time, end_time)   │
│                                                    │
│  外键：不加物理约束，Service 层 assertXxx          │
│                                                    │
│  AI 常犯错：                                       │
│   ① 直接 FOREIGN KEY  ② fee 用 FLOAT              │
│   ③ status 忘 NOT NULL ④ 漏冲突复合索引            │
└────────────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：在本地 MySQL 8.0 中建好 `tb_course` 表，插入至少 5 条测试数据，交 DDL 截图 + `SELECT * FROM tb_course` 结果；
2. **必做**：给出一个「查询报名中且教练 id = 1 的所有课程」的 SQL，并用 `EXPLAIN` 看看走了哪条索引；
3. **选做**：把 `capacity` 与 `enrolled_count` 的关系抽象成一个「余量视图」——`CREATE VIEW v_course_seat AS SELECT id, title, capacity - enrolled_count AS remain FROM tb_course WHERE deleted = 0`，思考什么场景可以直接查视图。

### 1.6 教学反思提示
- 学生若卡在「为什么不用物理外键」，可用「删除教练时，数据库不让删有关联课程的教练」的场景反问，让他们体会一下强约束的痛点；
- 若时间超出，把 AI 对照演示压缩到 1 分钟，只列 AI 常犯错清单即可，DDL 详解不能压。

---

## 第 2 课时：实体/VO 分层 + MyBatis resultMap 一对一映射

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能说清 `Course` 实体（贴数据库）与 `CourseVO`（贴前端）分层的动机，并列出 VO 比实体多出的字段类型（教练名、教练头像、教室名、教室位置）；
2. 能独立编写 `CourseVO` Java 类，含扁平字段（`coachName / coachAvatar / roomName / roomLocation`）版本；
3. 能独立编写 `<resultMap>` + `<association>` 嵌套版本，把 JOIN 结果拼成 `CourseVO.coach` / `CourseVO.room` 子对象；
4. 能对比「嵌套 VO」 vs 「扁平 VO」两种写法的适用场景（前端表格 vs 前端详情页）；
5. 能给同名字段列（如三张表都有 `id`、`name`）加**列别名前缀**（`coach_` / `room_`），避免映射串行。

#### 2.1.2 过程与方法目标
1. 通过「实体 vs VO」两个类的对比，训练「后端分层职责单一」的思维；
2. 通过「扁平 vs 嵌套」两种 VO 写法的取舍，训练「以前端使用场景为导向」的接口设计。

### 2.2 教学重难点
- **重点**：实体 vs VO 分层职责／`<resultMap>` + `<association>` 一对一嵌套映射写法／同名字段列别名前缀
- **难点**：`<id>` 与 `<result>` 的语义区别（主键必须用 `<id>`，否则去重错乱）／`columnPrefix` 属性简化写法

### 2.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课已建好 `tb_course` 表并插入了 5 条数据。**投影**在 MySQL 里手工执行一句 JOIN：

```sql
SELECT c.id, c.title, c.start_time, coach.name AS coach_name, room.name AS room_name
  FROM tb_course c
  LEFT JOIN tb_coach coach ON c.coach_id = coach.id
  LEFT JOIN tb_room  room  ON c.room_id  = room.id;
```

**口播**：SQL 层面能拿到扁平结果集，但前端要的可能是嵌套对象——`{ id, title, coach: { name, avatar }, room: { name, location } }`。这中间的转换谁负责？**Java 侧的 VO + MyBatis 的 resultMap**。今天就学这两件事。

#### 新知讲授（14 分钟）

1. **实体 vs VO 的分层动机**（4 分钟）：**板书**两张表——

   | 层次 | 类名 | 字段来源 | 用途 |
   |------|------|----------|------|
   | 实体 | `Course` | `tb_course` 一列一字段 | Mapper 参数 / 单表 CRUD |
   | VO   | `CourseVO` | 前端要显示的字段 | 返回给前端 |

   **口播**：为什么不能一个类走天下？① 前端要 `coachName`，实体里只有 `coachId`——放实体里就是脏字段；② 未来某天前端要额外加 `enrolledPercent`（`enrolled_count / capacity`），实体里加一个「假字段」也是脏字段；③ 分层清晰能让 Mapper 只关心表，Service 只关心业务，Controller 只关心 HTTP。

2. **两种 VO 写法：扁平 vs 嵌套**（5 分钟）：

   **扁平版**（更常用，前端表格场景）：

```java
@Data
public class CourseVO {
    private Long id;
    private String title;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer capacity;
    private Integer enrolledCount;
    private Integer status;
    private String statusText;
    private BigDecimal fee;
    private String coverUrl;

    // 扁平：教练/教室字段直接拉平
    private Long coachId;
    private String coachName;
    private String coachAvatar;
    private Long roomId;
    private String roomName;
    private String roomLocation;
}
```

   **嵌套版**（详情页场景，字段多时更清晰）：

```java
@Data
public class CourseDetailVO {
    private Long id;
    private String title;
    // ... 课程主字段
    private CoachBriefVO coach;   // 子对象
    private RoomBriefVO  room;
}
@Data public class CoachBriefVO { private Long id; private String name; private String avatar; }
@Data public class RoomBriefVO  { private Long id; private String name; private String location; }
```

   **抽学生**：哪种写法更适合列表页？答：扁平版，前端 `v-for` 一行取一个字段更顺；嵌套版适合详情页，字段一多能分组。

3. **`<resultMap>` 嵌套映射语法**（5 分钟）：**投影** Mapper XML 逐段讲——

```xml
<resultMap id="courseDetailVO" type="com.yinxiang.vo.CourseDetailVO">
  <id     column="id"          property="id"/>
  <result column="title"       property="title"/>
  <result column="start_time"  property="startTime"/>
  <result column="end_time"    property="endTime"/>
  <result column="capacity"    property="capacity"/>
  <result column="enrolled_count" property="enrolledCount"/>
  <result column="status"      property="status"/>
  <result column="fee"         property="fee"/>
  <result column="cover_url"   property="coverUrl"/>

  <!-- 子对象一：教练 -->
  <association property="coach" javaType="com.yinxiang.vo.CoachBriefVO"
               columnPrefix="coach_">
    <id     column="id"     property="id"/>
    <result column="name"   property="name"/>
    <result column="avatar" property="avatar"/>
  </association>

  <!-- 子对象二：教室 -->
  <association property="room"  javaType="com.yinxiang.vo.RoomBriefVO"
               columnPrefix="room_">
    <id     column="id"       property="id"/>
    <result column="name"     property="name"/>
    <result column="location" property="location"/>
  </association>
</resultMap>
```

   **重点讲两点**：① `<id>` vs `<result>`——主键必须用 `<id>`，MyBatis 才知道去重键是谁；② `columnPrefix="coach_"`——SQL 里所有 `coach_xxx` 列自动去掉前缀映射，比一列一列写 `column="coach_name"` 优雅得多。

#### 示例演示（12 分钟）

1. **写 VO 与实体**（4 分钟）：现场在 IDEA 里新建 `Course.java`（实体）与 `CourseVO.java`（扁平版），Lombok `@Data` 注解全套。**投影**编译通过。

2. **写扁平版 resultMap**（4 分钟）：现场敲 `CourseMapper.xml`——

```xml
<resultMap id="courseVO" type="com.yinxiang.vo.CourseVO">
  <id     column="id"              property="id"/>
  <result column="title"           property="title"/>
  <result column="start_time"      property="startTime"/>
  <result column="end_time"        property="endTime"/>
  <result column="capacity"        property="capacity"/>
  <result column="enrolled_count"  property="enrolledCount"/>
  <result column="status"          property="status"/>
  <result column="fee"             property="fee"/>
  <result column="cover_url"       property="coverUrl"/>
  <result column="coach_id"        property="coachId"/>
  <result column="coach_name"      property="coachName"/>
  <result column="coach_avatar"    property="coachAvatar"/>
  <result column="room_id"         property="roomId"/>
  <result column="room_name"       property="roomName"/>
  <result column="room_location"   property="roomLocation"/>
</resultMap>
```

   **抽学生**：`camelCase` 与 `snake_case` 的转换是自动的吗？答：不是；`mybatis.configuration.map-underscore-to-camel-case: true` 开启后**才**自动。这行配置 Day04 就设过，可以省掉大部分 `column/property` 显式声明——但列有别名（如 `coach_name`）时还是显式写更保险。

3. **AI 生成 resultMap 对照**（4 分钟）：给通义灵码贴需求「MyBatis resultMap，把 tb_course + tb_coach + tb_room 的 JOIN 结果映射为 CourseVO（嵌套版）」。**观察 AI 常犯错**：① 主键漏用 `<id>` 全写成 `<result>`；② `columnPrefix` 没用，一堆 `column="coach_name"` 硬写；③ 忘了子对象自己的 `<id>`（导致嵌套对象总是新建）。**当堂列到黑板**。

#### 课堂练习（10 分钟）
1. 每位学生写完 `CourseVO`（扁平版）+ `CourseMapper.xml` 中的 `courseVO` resultMap；
2. 追加一个嵌套版 `CourseDetailVO` + 对应 resultMap，用 `columnPrefix`；
3. 思考题：如果 `<id>` 用了 `<result>` 会怎样？提示：在 3 条课程都是同一个教练的场景下，MyBatis 可能把三条结果**合并**为一条。

#### 小结（3 分钟）
一句话回顾：**实体贴数据库、VO 贴前端；扁平 VO 用于列表、嵌套 VO 用于详情；resultMap 主键 `<id>` 不能少，`columnPrefix` 省一半代码**。下节课把 SQL 补上——真正把 JOIN + 分页 + 动态条件跑起来。

### 2.4 板书设计
```
┌───────────────────────────────────────────────────┐
│  Day08-02  实体 / VO 分层 + resultMap             │
├───────────────────────────────────────────────────┤
│  三层类：                                         │
│   Course      实体   贴表                         │
│   CourseVO    扁平   列表页                       │
│   CourseDetailVO  嵌套   详情页                   │
│                                                   │
│  VO 比实体多的字段：                              │
│   coachName / coachAvatar                         │
│   roomName / roomLocation                         │
│   statusText / enrolledPercent(可选)              │
│                                                   │
│  resultMap 语法：                                 │
│   <id>      主键（不能省！）                     │
│   <result>  普通字段                              │
│   <association property="coach"                   │
│                javaType="CoachBriefVO"            │
│                columnPrefix="coach_">             │
│     <id> <result> ...                             │
│   </association>                                  │
│                                                   │
│  列别名约定：                                     │
│   主表原名     c.title → title                    │
│   子表加前缀   coach.name → coach_name             │
│                                                   │
│  AI 常犯错：                                      │
│   ① 主键写成 <result>                             │
│   ② 不用 columnPrefix                             │
│   ③ 子对象漏 <id>                                 │
└───────────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成 `Course` + `CourseVO`（扁平）+ `CourseDetailVO`（嵌套）+ `resultMap`（两个）；
2. **必做**：手工在 MySQL 里写一句 JOIN SQL，字段用 `coach_name` `room_name` 等别名，能被 resultMap 顺利映射；
3. **选做**：调研 MyBatis 的 `<collection>` 元素（一对多），比如「一个教练教的所有课程」，为 Day10 的一对多做准备。

### 2.6 教学反思提示
- 学生若觉得两个 VO 类多余，可反问：如果前端将来要在列表页增加「已报名进度条」字段，你怎么加？让他们体会分层带来的稳定性。
- 若时间富余，可现场删掉子对象的 `<id>`，跑一下测试看看结果集是否被合并——非常直观。

---

## 第 3 课时：分页多表联查 SQL + Service 层查询

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能独立写出完整的 `selectPage` SQL：三张表 LEFT JOIN + 动态 `<if>` 条件 + `ORDER BY start_time DESC` + `LIMIT #{offset}, #{size}`；
2. 能单独写 `selectPageCount` SQL（不含 JOIN，直接 `count(*)`），并解释为什么两条 SQL 不能合并；
3. 能列出至少 4 个动态 `<if>` 条件（`title` 模糊、`status`、`coachId`、日期区间）并解释每个走不走索引；
4. 能独立写 `CourseService.pageQuery` 完整代码，返回 `PageResult<CourseVO>`；
5. 能用 `EXPLAIN` 观察上一课时建的 `idx_conflict` 复合索引在哪些查询条件下被命中。

#### 3.1.2 过程与方法目标
1. 通过「count SQL 与 list SQL 分开写」的对比，训练「同一业务多条 SQL 各司其职」的意识；
2. 通过 `EXPLAIN` 观察，训练「SQL 走不走索引要靠证据」的严谨态度。

### 3.2 教学重难点
- **重点**：三表 LEFT JOIN SQL 的写法／动态 `<if>` 条件的组合／count 与 list 两条 SQL 分开的必要性
- **难点**：`LIMIT offset, size` 大 offset 场景的性能问题（`LIMIT 100000, 10` 的深分页坑）／为什么模糊查询 `title LIKE '%xx%'` 不走索引

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课已经把 `resultMap` 建好了。**投影**打开前端 UI 原型：一个课程管理页面，有搜索框（课程标题）、下拉框（状态、教练）、日期范围选择器（开课时间从-到）、翻页控件。**口播**：前端一个「搜索」按钮点下去，后端要在**一次 SQL 中**支持所有这些条件——今天就学这条 SQL。

#### 新知讲授（14 分钟）

1. **分页联查 SQL 主体**（5 分钟）：**投影**逐段讲——

```xml
<select id="selectPage" resultMap="courseVO">
  SELECT
    c.id, c.title, c.start_time, c.end_time,
    c.capacity, c.enrolled_count, c.status, c.fee, c.cover_url,
    c.coach_id,
    coach.name   AS coach_name,
    coach.avatar AS coach_avatar,
    c.room_id,
    room.name     AS room_name,
    room.location AS room_location
  FROM tb_course c
  LEFT JOIN tb_coach coach ON coach.id = c.coach_id AND coach.deleted = 0
  LEFT JOIN tb_room  room  ON room.id  = c.room_id  AND room.deleted  = 0
  <where>
    c.deleted = 0
    <if test="title != null and title != ''">
      AND c.title LIKE CONCAT('%', #{title}, '%')
    </if>
    <if test="status != null">
      AND c.status = #{status}
    </if>
    <if test="coachId != null">
      AND c.coach_id = #{coachId}
    </if>
    <if test="startFrom != null">
      AND c.start_time &gt;= #{startFrom}
    </if>
    <if test="startTo != null">
      AND c.start_time &lt; #{startTo}
    </if>
  </where>
  ORDER BY c.start_time DESC, c.id DESC
  LIMIT #{offset}, #{size}
</select>
```

   **口播**四个坑点：① 为什么用 `LEFT JOIN` 而不是 `INNER JOIN`——教练/教室被软删后，课程本身仍然存在，前端应能看到「教练已离职」；② `AND coach.deleted = 0` 必须写在 `ON` 里而不是 `WHERE` 里——写在 `WHERE` 里会退化成 `INNER JOIN`；③ 日期区间用**左闭右开**（`>= startFrom AND < startTo`），避免时间边界重复；④ `ORDER BY` 加 `c.id DESC` 作为**平局裁决**——同一秒开始的课能稳定排序。

2. **count SQL 单独写**（3 分钟）：**投影**——

```xml
<select id="selectPageCount" resultType="long">
  SELECT COUNT(*)
  FROM tb_course c
  <where>
    c.deleted = 0
    <if test="title != null and title != ''">
      AND c.title LIKE CONCAT('%', #{title}, '%')
    </if>
    <if test="status != null">AND c.status = #{status}</if>
    <if test="coachId != null">AND c.coach_id = #{coachId}</if>
    <if test="startFrom != null">AND c.start_time &gt;= #{startFrom}</if>
    <if test="startTo != null">AND c.start_time &lt; #{startTo}</if>
  </where>
</select>
```

   **重点讲**：为什么 count 里**没有 JOIN**？因为 count 只关心「有多少行」，不需要教练/教室信息。JOIN 掉两张表能让 count 快一个数量级。**抽学生**：那 PageHelper 会不会自动做这个优化？答：PageHelper 只会 wrap 出一个 count SQL 但**不会自动删掉不必要的 JOIN**，深分页场景手写 count 更快。

3. **动态 `<if>` 与索引利用**（3 分钟）：**投影**一张对照表——

   | 条件 | SQL 片段 | 走索引？ | 原因 |
   |------|----------|---------|------|
   | `title` 模糊 | `title LIKE '%xx%'` | ❌ 全表扫描 | 前导 `%` 无法用 B+Tree |
   | `status` 精确 | `status = 2` | ✅ `idx_status` | 单列等值 |
   | `coachId` 精确 | `coach_id = 1` | ✅ `idx_coach` | 单列等值 |
   | `startFrom + startTo` | `start_time >= ? AND start_time < ?` | ✅ `idx_conflict` 部分命中 | 范围扫描 |
   | `coachId + startFrom` | `coach_id = 1 AND start_time >= ?` | ✅ `idx_conflict` 全命中 | 最左前缀完整 |

   **口播**：所以「教练维度 + 时间区间」的组合查询最快，因为 `idx_conflict(coach_id, start_time, end_time)` 两个字段都用上。**抽学生**：如果学生问 title 怎么加索引？答：全文索引（`FULLTEXT`）或引入 Elasticsearch，本项目数据量小暂不做。

4. **分页返回体 `PageResult<T>`**（3 分钟）：**板书**——

```java
@Data
@AllArgsConstructor
public class PageResult<T> {
    private long total;    // 总记录数（来自 count SQL）
    private List<T> list;  // 当前页数据（来自 list SQL）
}
```

   **口播**：前端翻页控件只需要这两个字段。有些团队会再加 `pageNum`、`pageSize`、`totalPages`——回声值，价值不大，本项目省了。

#### 示例演示（12 分钟）

1. **写 Query DTO**（3 分钟）：现场新建 `CoursePageQuery.java`——

```java
@Data
public class CoursePageQuery {
    private String title;
    private Integer status;
    private Long coachId;
    private LocalDateTime startFrom;
    private LocalDateTime startTo;

    private Integer pageNum  = 1;
    private Integer pageSize = 10;

    public Integer getOffset() { return (pageNum - 1) * pageSize; }
    public Integer getSize()   { return pageSize; }
}
```

2. **写 Service**（4 分钟）：现场敲 `CourseService.pageQuery`——

```java
@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseMapper courseMapper;

    public PageResult<CourseVO> pageQuery(CoursePageQuery q) {
        long total = courseMapper.selectPageCount(q);
        if (total == 0) {
            return new PageResult<>(0, Collections.emptyList());
        }
        List<CourseVO> list = courseMapper.selectPage(q);
        // 补 statusText 展示字段
        list.forEach(vo -> vo.setStatusText(courseStatusText(vo.getStatus())));
        return new PageResult<>(total, list);
    }

    private String courseStatusText(Integer s) {
        return switch (s == null ? -1 : s) {
            case 0 -> "待开始"; case 1 -> "报名中";
            case 2 -> "进行中"; case 3 -> "已结束";
            case 4 -> "已取消"; default -> "未知";
        };
    }
}
```

   **重点讲**：先 count，等于 0 直接返回空列表，能省一次 list SQL 的 IO——**早失败早返回**。

3. **Controller + Postman 联调**（5 分钟）：现场敲 `CourseController.page`——

```java
@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public Result<PageResult<CourseVO>> page(CoursePageQuery q) {
        return Result.success(courseService.pageQuery(q));
    }
}
```

   Postman 依次测试：① `GET /courses?pageNum=1&pageSize=10` → 3 条；② `GET /courses?coachId=1` → 2 条；③ `GET /courses?startFrom=2026-07-21T00:00:00&startTo=2026-07-22T00:00:00` → 1 条（左闭右开验证）；④ `GET /courses?title=瑜伽&status=0` → 2 条。**投影** MySQL 5 秒钟内 `EXPLAIN` 一下条件 ③ 的 SQL，看它是否走了 `idx_conflict`。

#### 课堂练习（10 分钟）
1. 每位学生完成 `CoursePageQuery` + `pageQuery` Service + `page` Controller 三层；
2. 用 Postman 至少测 4 组不同的查询条件组合，交结果截图；
3. 挑战：把 `title LIKE '%xx%'` 改成 `title LIKE 'xx%'`（右模糊），观察是否命中索引；
4. 思考题：如果 `pageNum = 10000, pageSize = 10`（深分页），SQL 会怎样？答：`LIMIT 99990, 10`——MySQL 要**读 100000 行**再丢掉前 99990 行，非常慢。下节课不讲，Day13-14 优化时再讲游标分页。

#### 小结（3 分钟）
一句话回顾：**list 与 count 两条 SQL 各写各的，LEFT JOIN 保数据、动态 `<if>` 保灵活、`idx_conflict` 保性能**。下节课进入「写」——但写之前先补足外键存在性校验和 DTO 校验。

### 3.4 板书设计
```
┌────────────────────────────────────────────────────┐
│  Day08-03  分页多表联查                            │
├────────────────────────────────────────────────────┤
│  两条 SQL：                                        │
│   selectPage        LEFT JOIN + 分页 + 排序        │
│   selectPageCount   COUNT(*), 无 JOIN, 更快        │
│                                                    │
│  LEFT JOIN 关键点：                                │
│   子表 deleted=0 写在 ON, 不能写 WHERE            │
│   否则退化为 INNER JOIN                            │
│                                                    │
│  动态条件 <if>：                                   │
│   title  模糊  ❌ 不走索引                         │
│   status 精确  ✅ idx_status                       │
│   coachId精确  ✅ idx_coach                        │
│   time 区间    ✅ idx_conflict 部分                │
│   coach+time   ✅ idx_conflict 全命中              │
│                                                    │
│  日期用左闭右开：                                  │
│   >= startFrom AND < startTo                       │
│                                                    │
│  ORDER BY start_time DESC, id DESC                 │
│   （id 作平局裁决）                                │
│                                                    │
│  PageResult<T> = { total, list }                   │
│                                                    │
│  深分页坑：LIMIT 99990,10 → 读 10w 丢 9w9         │
│   （Day13 优化再讲）                               │
└────────────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成课程分页查询完整链路（Query DTO + Mapper XML + Service + Controller），交 Postman 4 组测试截图；
2. **必做**：在 `EXPLAIN` 中观察至少 3 组查询条件的 `type` `key` `rows`，把结果贴到作业里；
3. **选做**：给 title 加一个 `FULLTEXT` 全文索引，试试 `MATCH ... AGAINST` 语法能不能加速。

### 3.6 教学反思提示
- 学生若把 `AND coach.deleted = 0` 写到 `WHERE` 里，可以让他们造一条被软删的教练数据，观察对应的课程是否消失，非常直观地体会 LEFT JOIN 的退化坑；
- 深分页问题只做预告，不做展开——它需要游标分页 + 索引覆盖，是 Day13-14 的话题。

---

## 第 4 课时：外键存在性校验 + 课程 DTO 与基础校验

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能说清「不用物理外键」时，外键存在性校验为什么必不可少，以及不做会引发什么业务事故；
2. 能独立写通用方法 `assertCoachExists(id)` / `assertRoomExists(id)`，抛 `BizException(4041, "教练不存在")` 类的错误码；
3. 能独立编写 `CourseAddDTO`，覆盖 9 个字段并加 Bean Validation 注解（`@NotBlank` / `@NotNull` / `@Future` / `@Positive` / `@DecimalMin` 等）；
4. 能编写自定义校验器 `@ValidTimeRange`，用于「结束时间必须晚于开始时间」这类跨字段校验；
5. 能独立编写 `CourseUpdateDTO`，理解「新增用 `@NotNull`、修改用可选」的差异。

#### 4.1.2 过程与方法目标
1. 通过「注解校验 vs Service 校验」两层的对比，训练「分层职责」的思维；
2. 通过「跨字段校验必须自定义注解」这一动手过程，理解 JSR-380 的扩展点。

### 4.2 教学重难点
- **重点**：外键存在性校验的通用方法／DTO 的字段级注解校验／新增 DTO 与修改 DTO 的差异
- **难点**：`@ValidTimeRange` 自定义校验器的 `ConstraintValidator` 实现／Bean Validation 只能做**字段自己**的校验，跨字段/跨记录必须在 Service 层做

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课已把「查」跑通了，本节课开始「写」。**投影**一个反例：如果前端手误传了 `coachId = 999`（不存在的教练），当前的 DDL 因为**没加物理外键**，DB 会直接 `INSERT` 成功——但等前端查列表时，`LEFT JOIN` 出来的 `coachName` 是 `null`，页面会显示「教练：null」。**口播**：这就是数据脏了，得从源头堵住。堵在哪里？**Service 层**。

#### 新知讲授（14 分钟）

1. **外键存在性校验的通用方法**（4 分钟）：**投影** `ExistenceChecker` 组件——

```java
@Component
@RequiredArgsConstructor
public class ExistenceChecker {

    private final CoachMapper coachMapper;
    private final RoomMapper  roomMapper;

    public Coach assertCoachExists(Long id) {
        Coach c = coachMapper.selectById(id);
        if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
            throw new BizException(4041, "教练不存在：id=" + id);
        }
        return c;
    }

    public Room assertRoomExists(Long id) {
        Room r = roomMapper.selectById(id);
        if (r == null || Integer.valueOf(1).equals(r.getDeleted())) {
            throw new BizException(4042, "教室不存在：id=" + id);
        }
        return r;
    }
}
```

   **口播**两个设计考虑：① **返回**校验到的对象——上层调用往往还需要它（例如新增课程时要拿教室 `capacity` 与课程 `capacity` 做比较）；② 错误码分段（`4041 教练不存在 / 4042 教室不存在`）——便于前端根据不同错误码高亮不同下拉框。

2. **`CourseAddDTO` 字段与注解**（6 分钟）：**投影**——

```java
@Data
@ValidTimeRange   // 类级注解：跨字段
public class CourseAddDTO {

    @NotBlank(message = "课程标题不能为空")
    @Size(max = 100, message = "课程标题最多 100 字")
    private String title;

    @NotNull(message = "教练不能为空")
    private Long coachId;

    @NotNull(message = "教室不能为空")
    private Long roomId;

    @NotNull(message = "开始时间不能为空")
    @Future(message = "开始时间必须晚于当前时间")
    private LocalDateTime startTime;

    @NotNull(message = "结束时间不能为空")
    private LocalDateTime endTime;

    @NotNull @Positive(message = "容量必须大于 0")
    @Max(value = 200, message = "容量最多 200 人")
    private Integer capacity;

    @NotNull
    @DecimalMin(value = "0.00", message = "费用不能为负")
    @DecimalMax(value = "99999.99", message = "费用过大")
    @Digits(integer = 6, fraction = 2)
    private BigDecimal fee;

    @Size(max = 5000, message = "介绍最多 5000 字")
    private String intro;

    @Size(max = 255, message = "封面 URL 过长")
    private String coverUrl;
}
```

   **口播**逐个注解讲：① `@Future` 只允许**未来时间**——排课不能排到过去；② `@Positive` 不含 0，`@Min(1)` 等价；③ `@Digits(integer=6, fraction=2)` 限制整数最多 6 位、小数 2 位；④ 关键——`@ValidTimeRange` 是**类级**注解，处理「结束时间 > 开始时间」这类跨字段校验，字段级注解做不到。

3. **自定义校验器 `@ValidTimeRange`**（4 分钟）：**投影**两段代码——

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = TimeRangeValidator.class)
public @interface ValidTimeRange {
    String message() default "结束时间必须晚于开始时间，且至少 15 分钟";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
```

```java
public class TimeRangeValidator implements ConstraintValidator<ValidTimeRange, Object> {
    @Override
    public boolean isValid(Object value, ConstraintValidatorContext ctx) {
        if (value == null) return true;
        LocalDateTime start, end;
        try {
            // 用反射拿字段，简化起见这里只演示 CourseAddDTO/UpdateDTO 两种
            start = (LocalDateTime) value.getClass().getMethod("getStartTime").invoke(value);
            end   = (LocalDateTime) value.getClass().getMethod("getEndTime")  .invoke(value);
        } catch (Exception e) {
            return true;   // 找不到字段，交给字段级注解处理
        }
        if (start == null || end == null) return true;
        return end.isAfter(start) && Duration.between(start, end).toMinutes() >= 15;
    }
}
```

   **重点讲**：跨字段校验一定要在**类级**上加注解，`ConstraintValidator` 的第二个泛型是 `Object`（因为 DTO 类型不定）——用反射拿两个字段。**抽学生**：`@Future` 能不能改成 `@FutureOrPresent`？答：可以，看业务——排课要留提前量，`@Future` 更严格。

#### 示例演示（13 分钟）

1. **`CourseUpdateDTO`**（4 分钟）：**投影**——

```java
@Data
@ValidTimeRange
public class CourseUpdateDTO {

    @NotNull(message = "id 不能为空")
    private Long id;

    // 修改时字段大多可选：不传就不改（Service 层做 selective 更新）
    @Size(max = 100) private String title;
    private Long coachId;
    private Long roomId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @Positive @Max(200)
    private Integer capacity;

    @DecimalMin("0.00") @DecimalMax("99999.99") @Digits(integer=6, fraction=2)
    private BigDecimal fee;

    @Size(max = 5000) private String intro;
    @Size(max = 255)  private String coverUrl;
}
```

   **口播**：新增 DTO 里的 `@NotBlank`/`@NotNull` 在修改 DTO 里都去掉——修改时用户只传要改的字段，没传的就不动。但 `id` 必须传。

2. **DTO 校验触发**（3 分钟）：在 Controller 里演示 `@Valid`：

```java
@PostMapping
public Result<Long> add(@RequestBody @Valid CourseAddDTO dto) { ... }

@PutMapping("/{id}")
public Result<Void> update(@PathVariable Long id,
                            @RequestBody @Valid CourseUpdateDTO dto) {
    dto.setId(id);   // path 与 body 都传 id 时，以 path 为准
    ...
}
```

   **口播**：`@Valid` 触发校验，失败会抛 `MethodArgumentNotValidException`——Day05 已经在全局异常里接过它，前端拿到 `Result{ code:4001, msg:"课程标题不能为空" }` 直接展示。

3. **AI 生成 DTO 对照**（6 分钟）：给通义灵码贴需求「生成 CourseAddDTO，含标题、教练/教室 id、开课/结课时间、容量、费用、介绍、封面 URL 字段，用 Bean Validation 注解」。**观察 AI 常犯错**：① 忘写 `@Future`（时间字段没做未来限制）；② `capacity` 只写 `@NotNull` 没有 `@Positive`；③ `fee` 用 `Double` 而非 `BigDecimal`（丢精度）；④ 跨字段的「结束时间 > 开始时间」用 `@NotNull` 强行凑活。**AI 常犯错清单**当堂列到黑板。

#### 课堂练习（10 分钟）
1. 每位学生完成 `ExistenceChecker` + `CourseAddDTO` + `CourseUpdateDTO` + `@ValidTimeRange`；
2. Postman 至少测 4 组反例（空标题 / 过去时间 / 结束早于开始 / 容量负数），交返回体截图；
3. 思考题：如果学生忘了在 Controller 加 `@Valid`，注解校验会生效吗？答：不会。可以现场演示。

#### 小结（3 分钟）
一句话回顾：**DTO 字段级注解 + 跨字段自定义校验 + Service 层外键校验，三层配合缺一不可**。下一课时是本节的高潮——**时间区间冲突检测**，先讲区间重叠的四种情形，再落到 SQL。

### 4.4 板书设计
```
┌────────────────────────────────────────────────────┐
│  Day08-04  DTO 与外键存在性校验                    │
├────────────────────────────────────────────────────┤
│  三层校验（缺一不可）：                            │
│   Controller  @Valid + Bean Validation             │
│              ↓ 只做单字段合法性                    │
│   跨字段     @ValidTimeRange（类级注解）           │
│              ↓ end > start, 最少 15 分钟           │
│   Service    assertCoachExists / assertRoomExists  │
│              ↓ 数据库反查存在且未删                │
│                                                    │
│  CourseAddDTO 9 字段：                             │
│   title    @NotBlank @Size(max=100)                │
│   coachId  @NotNull                                │
│   roomId   @NotNull                                │
│   start    @NotNull @Future                        │
│   end      @NotNull                                │
│   capacity @NotNull @Positive @Max(200)            │
│   fee      @NotNull @DecimalMin @Digits(6,2)       │
│   intro    @Size(max=5000)                         │
│   coverUrl @Size(max=255)                          │
│                                                    │
│  CourseUpdateDTO：id @NotNull, 其它可选           │
│                                                    │
│  错误码分段：4041 教练  4042 教室                  │
│                                                    │
│  AI 常犯错：                                       │
│   ① 忘 @Future  ② fee 用 Double                    │
│   ③ 跨字段没用自定义注解                           │
└────────────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：完成 `ExistenceChecker` + 两个 DTO + `@ValidTimeRange` 自定义校验器；
2. **必做**：Postman 至少测 6 组反例（每个字段级注解都要至少覆盖 1 条），交 `Result` 返回体截图；
3. **选做**：为 `@ValidTimeRange` 增加 `minMinutes` 属性，默认 15，允许业务方自定义最小时长。

### 4.6 教学反思提示
- 若学生对反射拿字段的写法不适应，可以在讲义里简化为强制转型 `if (value instanceof CourseAddDTO dto) { ... }`——**不推荐**通用性差，但初学者更好懂；
- 若时间紧张，AI 对照可以只讲 2 分钟，把重心放在 `@ValidTimeRange` 上——这是本节的技术点。

---

## 第 5 课时：冲突检测 SQL + 新增/修改 Service

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能画出「两个时间区间重叠」的四种情形图，并推导「不冲突」的两个条件；
2. 能独立写出 `countCoachConflict` / `countRoomConflict` 的 SQL，含 `excludeId` 参数供修改场景使用；
3. 能独立编写 `CourseService.add`：外键校验 → 冲突检测 → 落库，顺序不乱；
4. 能独立编写 `CourseService.update`：多传 `excludeId = 自己`，避免误判自己冲突；
5. 能解释「左闭右开」时间区间语义，以及 `@Transactional` 应该加在 Service 层而不是 Controller。

#### 5.1.2 过程与方法目标
1. 通过「画四情形图 → 推导条件 → 反演成 SQL」的过程，训练「用几何直觉推 SQL 谓词」的思维；
2. 通过「新增 vs 修改的 excludeId 差异」，训练「同一算法在不同场景微调」的复用意识。

### 5.2 教学重难点
- **重点**：区间重叠的四情形与「不冲突」谓词的取反／`countConflict` SQL 的完整写法／新增和修改的 excludeId 差异
- **难点**：`NOT (end <= start OR start >= end)` 的语义（左闭右开语义下等号的处理）／`@Transactional` 的传播行为（本节只讲 REQUIRED 即可）

### 5.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
**投影**一个真实场景：教练 A 已经排了「周一 8:00-9:00 哈他」，现在助教又想给她排「周一 8:30-9:30 阴瑜伽」——一个人不能同时在两个课上。**口播**：这是本节要解决的问题——**排课冲突检测**。抛出难点：光靠 DB 唯一索引解决不了（因为不是简单的字段相等，而是**区间相交**）。今天用「画图 + 推谓词 + 写 SQL」三步搞定。

#### 新知讲授（16 分钟）

1. **时间区间重叠的四情形**（6 分钟）：**板书**四张图（用 ASCII 时间轴表示）——

```
情形 A：新区间完全在旧区间前
   旧：       [------------------]
   新：  [--]
   → 不冲突：new.end <= old.start

情形 B：新区间完全在旧区间后
   旧：  [------------------]
   新：                       [--]
   → 不冲突：new.start >= old.end

情形 C：部分重叠
   旧：  [------------------]
   新：            [------------]
   → 冲突

情形 D：完全包含
   旧：       [--]
   新：  [------------------]
   → 冲突
```

   **口播**推导：所以「不冲突」= 情形 A 或情形 B = `new.end <= old.start OR new.start >= old.end`。取反得「冲突」= `NOT (new.end <= old.start OR new.start >= old.end)`。**抽学生**：把这句话读出来。**这个模板要背下来，排课、会议室、酒店房间通用**。

2. **`countCoachConflict` SQL**（4 分钟）：**投影**——

```xml
<select id="countCoachConflict" resultType="int">
  SELECT COUNT(*) FROM tb_course
   WHERE deleted = 0
     AND status &lt;&gt; 4                <!-- 已取消不算冲突 -->
     AND coach_id = #{coachId}
    <if test="excludeId != null">
     AND id &lt;&gt; #{excludeId}
    </if>
     AND NOT (end_time  &lt;= #{startTime}
           OR start_time &gt;= #{endTime})
</select>
```

   **重点讲**三个坑：① `status <> 4`——已取消的课不占用时间段，可以在同一时段排新课；② `excludeId`——修改自己时把自己排除，否则永远和自己冲突；③ `end_time <=` 与 `start_time >=` 的等号——**左闭右开**语义下，「上一节 9:00 结束、下一节 9:00 开始」是允许的（不算重叠），所以带等号。

3. **`countRoomConflict` SQL**（2 分钟）：与教练冲突同构，只把 `coach_id` 换成 `room_id` 即可——**投影**：

```xml
<select id="countRoomConflict" resultType="int">
  SELECT COUNT(*) FROM tb_course
   WHERE deleted = 0
     AND status &lt;&gt; 4
     AND room_id = #{roomId}
    <if test="excludeId != null">AND id &lt;&gt; #{excludeId}</if>
     AND NOT (end_time  &lt;= #{startTime} OR start_time &gt;= #{endTime})
</select>
```

   **口播**：两条 SQL 结构一模一样，为什么不合并成一个 `OR`？答：合并了走不同索引会退化到全表扫描——分开写，教练冲突走 `idx_coach` + 二级过滤，教室冲突走 `idx_room` + 二级过滤，都非常快。

4. **`@Transactional` 的位置**（4 分钟）：**板书**——

```
Controller       ← 不加事务：HTTP 层不关心事务
    ↓
Service          ← 加 @Transactional：业务边界在这里
    ↓
Mapper           ← 不加事务：ORM 层不做决策
```

   **口播**：本节只讲 `@Transactional` 默认的 `REQUIRED` 传播行为——「有事务就加入，没有就新建」。事务传播的其它级别（`REQUIRES_NEW` / `NESTED`）是 Day11-12 的话题，先埋个种子。**抽学生**：`@Transactional` 加到 `private` 方法上会生效吗？答：不会，因为 Spring 用代理拦截，`private` 方法不走代理——这个坑课后自己试。

#### 示例演示（13 分钟）

1. **`CourseService.add` 完整代码**（5 分钟）：**投影**——

```java
@Service
@RequiredArgsConstructor
public class CourseService {

    private final CourseMapper courseMapper;
    private final ExistenceChecker existenceChecker;

    @Transactional(rollbackFor = Exception.class)
    public Long add(CourseAddDTO dto) {
        // 1. 外键校验（顺便拿教室信息）
        existenceChecker.assertCoachExists(dto.getCoachId());
        Room room = existenceChecker.assertRoomExists(dto.getRoomId());

        // 2. 容量不得超过教室容量
        if (dto.getCapacity() > room.getCapacity()) {
            throw new BizException(4001,
                "课程容量（" + dto.getCapacity()
              + "）超过教室容量（" + room.getCapacity() + "）");
        }

        // 3. 冲突检测（新增时 excludeId = null）
        int coachConflict = courseMapper.countCoachConflict(
                dto.getCoachId(), dto.getStartTime(), dto.getEndTime(), null);
        if (coachConflict > 0) {
            throw new BizException(4091, "该教练在此时间段已有课程");
        }
        int roomConflict = courseMapper.countRoomConflict(
                dto.getRoomId(),  dto.getStartTime(), dto.getEndTime(), null);
        if (roomConflict > 0) {
            throw new BizException(4092, "该教室在此时间段已被占用");
        }

        // 4. 落库
        Course c = new Course();
        BeanUtils.copyProperties(dto, c);
        c.setStatus(0);           // 默认待开始
        c.setEnrolledCount(0);
        courseMapper.insert(c);
        return c.getId();
    }
}
```

   **重点讲**校验顺序：先便宜后昂贵——先做本地对象比较（`capacity` 越界），再做 DB 查询（存在性、冲突），最后 `INSERT`。**早失败早返回**是这层的最大守则。

2. **`CourseService.update` 完整代码**（5 分钟）：**投影**——

```java
@Transactional(rollbackFor = Exception.class)
public void update(CourseUpdateDTO dto) {
    Course old = courseMapper.selectById(dto.getId());
    if (old == null || Integer.valueOf(1).equals(old.getDeleted())) {
        throw new BizException(4041, "课程不存在：id=" + dto.getId());
    }
    if (old.getStatus() == 3 || old.getStatus() == 4) {
        throw new BizException(4093, "已结束或已取消的课程不允许修改");
    }

    // 拼合并对象：null 字段用旧值
    Long coachId = dto.getCoachId() != null ? dto.getCoachId() : old.getCoachId();
    Long roomId  = dto.getRoomId()  != null ? dto.getRoomId()  : old.getRoomId();
    LocalDateTime start = dto.getStartTime() != null ? dto.getStartTime() : old.getStartTime();
    LocalDateTime end   = dto.getEndTime()   != null ? dto.getEndTime()   : old.getEndTime();

    existenceChecker.assertCoachExists(coachId);
    Room room = existenceChecker.assertRoomExists(roomId);

    Integer capacity = dto.getCapacity() != null ? dto.getCapacity() : old.getCapacity();
    if (capacity > room.getCapacity()) {
        throw new BizException(4001, "课程容量超过教室容量");
    }
    if (capacity < old.getEnrolledCount()) {
        throw new BizException(4002, "已报名人数超过新容量，不能改小");
    }

    // 冲突检测：excludeId = 自己
    if (courseMapper.countCoachConflict(coachId, start, end, dto.getId()) > 0) {
        throw new BizException(4091, "该教练在此时间段已有课程");
    }
    if (courseMapper.countRoomConflict(roomId, start, end, dto.getId()) > 0) {
        throw new BizException(4092, "该教室在此时间段已被占用");
    }

    Course c = new Course();
    BeanUtils.copyProperties(dto, c);
    int rows = courseMapper.updateSelective(c);
    if (rows == 0) throw new BizException(4094, "并发修改，请刷新重试");
}
```

   **重点讲**三处差异：① `excludeId = dto.getId()`——不然自己和自己冲突；② `capacity < enrolledCount` 的额外校验——已经有人报名后不能把容量改小；③ `rows == 0` 视为并发修改——防止两个后台同时改一条数据只有一个生效但都返回成功。

3. **Postman 联调**（3 分钟）：现场演示——① 正常新增：返回 `data: <id>`；② 同教练同时段：返回 `4091 该教练在此时间段已有课程`；③ 修改同一课程的标题（不改时间）：应通过；④ 修改课程时间到冲突段：返回 `4091` 或 `4092`。

#### 课堂练习（10 分钟）
1. 每位学生完成 `add` + `update` 两个方法 + 两条冲突检测 SQL；
2. Postman 至少测 8 组用例（新增正常/教练冲突/教室冲突/容量越界；修改正常/教练冲突/教室冲突/终态锁定）；
3. 思考题：如果同一秒两个前端同时提交新增同教练同时段的课，冲突检测会不会双双通过？答：会，这是**竞态**——Day13-14 会用「乐观锁 / 数据库唯一索引 / 分布式锁」补齐。

#### 小结（3 分钟）
一句话回顾：**四情形推谓词 → SQL 模板背下来 → 校验顺序：本地→外键→冲突→写库**。下一课时把状态流转、删除策略和 Controller 汇总一起做完，本模块收工。

### 5.4 板书设计
```
┌────────────────────────────────────────────────────┐
│  Day08-05  冲突检测                                │
├────────────────────────────────────────────────────┤
│  区间重叠四情形：                                  │
│                                                    │
│   A 完全前： 旧 [====]                             │
│              新 []                                 │
│              new.end <= old.start   不冲突         │
│                                                    │
│   B 完全后： 旧 [====]                             │
│              新       []                           │
│              new.start >= old.end   不冲突         │
│                                                    │
│   C 部分重叠：旧 [====]                            │
│              新    [====]           冲突           │
│                                                    │
│   D 完全包含：旧    []                             │
│              新 [========]           冲突          │
│                                                    │
│  谓词模板（背下来！）：                            │
│   NOT (end_time <= startTime                       │
│     OR start_time >= endTime)                      │
│                                                    │
│  SQL 三条件：                                      │
│   deleted=0                                        │
│   status <> 4  （已取消不占位）                    │
│   coach_id / room_id 等值                          │
│   excludeId  修改场景排除自己                      │
│                                                    │
│  Service 校验顺序（早失败早返回）：                │
│   ① 本地对象比较（capacity > 教室 capacity）      │
│   ② 外键存在（assertCoachExists）                 │
│   ③ 冲突检测 SQL                                  │
│   ④ INSERT/UPDATE                                  │
│                                                    │
│  @Transactional 加在 Service 层                    │
│                                                    │
│  update 三处差异：                                 │
│   excludeId=自己  |  capacity ≥ enrolled          │
│   rows==0 判并发                                   │
└────────────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 `countCoachConflict` `countRoomConflict` 两条 SQL + `CourseService.add` + `CourseService.update` 完整代码；
2. **必做**：Postman 至少交 8 组用例的截图（正/反各半）；
3. **选做**：为 `insert` SQL 补一条 MySQL 唯一索引 `UNIQUE KEY uk_conflict(coach_id, start_time, end_time)`，试试是否能作为「兜底」的最后一道防线（提示：唯一索引不能表达区间重叠，所以只能兜住「同教练同时刻」的完全相同排课）。

### 5.6 教学反思提示
- 学生若卡在四情形推导，可现场用 A4 纸画两个色块滑动演示，视觉冲击最强；
- 若时间富余，可让学生自行推导「三个课程两两不冲突」的条件——这是一道很好的思考题，答案就是两两之间都满足 `end <= start OR start >= end`。

---

## 第 6 课时：状态流转 + 删除策略 + Controller 汇总 + AI 生成冲突检测

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能画出课程状态机（`0 待开始 → 1 报名中 → 2 进行中 → 3 已结束`；`0/1 → 4 已取消`），并说出每一步的触发者；
2. 能实现 `updateStatus(id, fromStatus, toStatus)` 的乐观并发 SQL（`WHERE status = fromStatus`），并解释为什么它就是最朴素的并发控制；
3. 能对比「物理删除 / 逻辑删除 / 归档」三种策略，说清本项目为什么用**逻辑删除**；
4. 能独立编写 `CourseController` 的 6 个接口：POST / PUT / PATCH `/status` / DELETE / GET `/{id}` / GET 分页；
5. 能设计一段完整的**AI 提示词模板**，把区间重叠四情形 + 表结构一起喂给 AI，生成冲突检测代码；
6. 能列出至少 5 个本模块常见坑（时间用 `LocalDateTime` 别用 `Date` / 时区 / 事务传播 / BigDecimal 相等 / 状态终态回流）。

#### 6.1.2 过程与方法目标
1. 通过「状态机图 → 转移表 → 代码」的顺序，训练「先建模再编码」的思维；
2. 通过「让 AI 写冲突检测 + 逐行审查」的过程，训练「AI 是助手不是老板」的协作态度。

### 6.2 教学重难点
- **重点**：课程状态机与转移表／乐观并发 SQL 的 `WHERE status = fromStatus`／逻辑删除三段策略／6 个接口的 HTTP 语义（POST/PUT/PATCH/DELETE 各干嘛的）
- **难点**：「状态转移合法性」代码的表驱动写法（`Map<Integer, Set<Integer>>`）／`PATCH /courses/{id}/status` 与 `POST /courses/{id}/publish` 的选择

### 6.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
上节课把「新增」和「修改」跑通了，还差**状态变更**（发布 / 取消 / 结课）和**删除**两条链路。**投影**打开前端 UI：一个课程详情页，右上角有「发布」「取消」「删除」三个按钮——今天把这三个按钮的后端接口全部实现。**口播**：状态和删除看起来简单，但**坑最多**——终态回流、并发点击、有引用还能不能删——都会在这一节讲清楚。

#### 新知讲授（15 分钟）

1. **课程状态机与转移表**（5 分钟）：**板书** ASCII 状态图——

```
           ┌──────────┐
           │ 0 待开始 │
           └────┬─────┘
                │ 手工发布
                ▼
           ┌──────────┐        取消
           │ 1 报名中 │ ──────────────┐
           └────┬─────┘               │
     定时任务   │ start_time 到       │
                ▼                     ▼
           ┌──────────┐         ┌──────────┐
           │ 2 进行中 │         │ 4 已取消 │◄─── 从 0/1 可来
           └────┬─────┘         └──────────┘
                │ end_time 到          ▲
                ▼                       │ 手工取消
           ┌──────────┐                 │
           │ 3 已结束 │─────────────────┘（终态：不再变化）
           └──────────┘
```

   **口播**：`3 已结束` 和 `4 已取消` 是**终态**，不能再回流；从 `0 / 1` 都能到 `4`；`2 进行中` 不允许取消（课已经在上了，取消损失更大，业务上要走「退款」流程）。**抽学生**：`2 进行中` 到 `3 已结束` 谁触发？答：**定时任务**（Day13-14 讲 `@Scheduled`）。

2. **表驱动的合法性校验**（3 分钟）：**投影**——

```java
private static final Map<Integer, Set<Integer>> TRANSITIONS = Map.of(
    0, Set.of(1, 4),   // 待开始 → 报名中 / 已取消
    1, Set.of(2, 4),   // 报名中 → 进行中 / 已取消
    2, Set.of(3)       // 进行中 → 已结束
    // 3、4 为终态，不出现在 key 里
);

private void assertTransitionAllowed(int from, int to) {
    Set<Integer> allowed = TRANSITIONS.getOrDefault(from, Set.of());
    if (!allowed.contains(to)) {
        throw new BizException(4095,
            "状态不允许从 " + from + " 变更为 " + to);
    }
}
```

   **口播**：**表驱动**——把规则从代码抽到数据（一个 `Map`）里，未来加状态只改 `Map`，不改 `if-else`。这是把「配置」与「逻辑」分开的经典做法。

3. **乐观并发 SQL**（3 分钟）：**投影**——

```xml
<update id="updateStatus">
  UPDATE tb_course
     SET status = #{toStatus}, update_time = NOW()
   WHERE id = #{id}
     AND status = #{fromStatus}
     AND deleted = 0
</update>
```

   **口播**：`AND status = #{fromStatus}` 就是**最朴素的乐观锁**——两个人同时点「发布」，第一个把 status 从 0 改到 1，第二个 SQL 的 `WHERE status = 0` 匹配失败，`rows = 0`，返回错误。**抽学生**：为什么不用 `SELECT FOR UPDATE`？答：会锁行，并发下性能差；`WHERE` 匹配 + 检查 `rows` 是零成本方案。

4. **删除策略三选一**（4 分钟）：**投影**一张表——

   | 策略 | 说明 | 优点 | 缺点 |
   |------|------|------|------|
   | 物理删除 | `DELETE FROM tb_course` | 数据干净 | 有外键引用（订单）会失败 / 无法追溯 |
   | 逻辑删除 | `UPDATE ... SET deleted = 1` | 保留数据 / 可恢复 | 所有查询要 `AND deleted = 0` |
   | 归档 | 移到 `tb_course_archive` | 主表干净 + 保留历史 | 维护成本高（要建镜像表） |

   **口播**：本项目课程用**逻辑删除**——理由是「订单要能查到已删除的课名」。删除时同步校验：如果已有报名（`enrolled_count > 0`），提示「请改为取消课程」，禁止删除。**板书**规则：`enrolled_count > 0 时禁止逻辑删除`。

#### 示例演示（14 分钟）

1. **状态与删除的 Service 代码**（5 分钟）：**投影**——

```java
@Transactional(rollbackFor = Exception.class)
public void updateStatus(Long id, Integer toStatus) {
    Course c = courseMapper.selectById(id);
    if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
        throw new BizException(4041, "课程不存在");
    }
    assertTransitionAllowed(c.getStatus(), toStatus);
    int rows = courseMapper.updateStatus(id, c.getStatus(), toStatus);
    if (rows == 0) throw new BizException(4094, "并发修改，请刷新重试");
}

@Transactional(rollbackFor = Exception.class)
public void logicalDelete(Long id) {
    Course c = courseMapper.selectById(id);
    if (c == null || Integer.valueOf(1).equals(c.getDeleted())) {
        throw new BizException(4041, "课程不存在");
    }
    if (c.getEnrolledCount() != null && c.getEnrolledCount() > 0) {
        throw new BizException(4096, "该课程已有报名，请改为取消课程");
    }
    courseMapper.logicalDeleteById(id);
}
```

2. **`CourseController` 汇总 6 接口**（5 分钟）：**投影**——

```java
@RestController
@RequestMapping("/courses")
@RequiredArgsConstructor
public class CourseController {

    private final CourseService courseService;

    // 1. 分页查询
    @GetMapping
    public Result<PageResult<CourseVO>> page(CoursePageQuery q) {
        return Result.success(courseService.pageQuery(q));
    }

    // 2. 详情
    @GetMapping("/{id}")
    public Result<CourseVO> detail(@PathVariable Long id) {
        return Result.success(courseService.detail(id));
    }

    // 3. 新增
    @PostMapping
    public Result<Long> add(@RequestBody @Valid CourseAddDTO dto) {
        return Result.success(courseService.add(dto));
    }

    // 4. 全量修改
    @PutMapping("/{id}")
    public Result<Void> update(@PathVariable Long id,
                                @RequestBody @Valid CourseUpdateDTO dto) {
        dto.setId(id);
        courseService.update(dto);
        return Result.success();
    }

    // 5. 状态变更
    @PatchMapping("/{id}/status")
    public Result<Void> updateStatus(@PathVariable Long id,
                                      @RequestParam Integer toStatus) {
        courseService.updateStatus(id, toStatus);
        return Result.success();
    }

    // 6. 逻辑删除
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        courseService.logicalDelete(id);
        return Result.success();
    }
}
```

   **重点讲** HTTP 语义：① `POST` 新增，返回新 id；② `PUT` **整体**修改，body 传完整对象；③ `PATCH` **局部**修改（状态一个字段），走 query 更符合语义；④ `DELETE` 幂等——同一 id 删两次结果一致。**抽学生**：为什么不用 `POST /courses/{id}/publish` 而用 `PATCH /courses/{id}/status`？答：后者更通用——所有状态变更走同一个接口，参数区分。RESTful 语义更纯。

3. **AI 生成冲突检测代码提示词模板**（4 分钟）：**投影**给通义灵码/Trae 的完整提示——

```
请为 Spring Boot 4.0 + MyBatis + MySQL 8.0 项目实现「排课冲突检测」。

表结构（关键字段）：
tb_course(id, coach_id, room_id, start_time, end_time,
          status[0-4], deleted[0/1])

冲突定义（背景）：
两个课程时间区间有重叠 → 冲突。
区间重叠的四种情形：
  A 完全前：new.end <= old.start（不冲突）
  B 完全后：new.start >= old.end（不冲突）
  C 部分重叠：冲突
  D 完全包含：冲突
不冲突 = A 或 B → 冲突 = NOT(A OR B)

要求：
1. Mapper 提供两个方法：
   countCoachConflict(coachId, startTime, endTime, excludeId)
   countRoomConflict (roomId,  startTime, endTime, excludeId)
2. SQL 使用 NOT (end_time <= startTime OR start_time >= endTime)
3. 过滤条件：deleted=0 AND status <> 4
4. excludeId 用 <if> 包裹，修改场景传自己 id，新增场景传 null
5. Service 层顺序调用两个方法，抛 BizException(4091/4092)
6. 时间字段用 LocalDateTime，不用 Date
```

   **口播**观察 AI 输出，重点看四点：① 谓词是否写反（新手容易把 OR 写成 AND）；② `status <> 4` 有没有漏；③ `excludeId` 有没有用 `<if>`；④ 时间字段类型是不是 `LocalDateTime`。**抽学生**：读一遍 AI 的输出，指出至少一个可以更好的点。

#### 课堂练习（8 分钟）
1. 每位学生完成 `updateStatus` + `logicalDelete` + `CourseController` 6 接口；
2. Postman 至少测 5 组用例：① 发布（0→1）成功；② 从 3 强行到 1（终态回流）失败；③ 无报名删除成功；④ 有报名删除失败；⑤ 分页 + 状态过滤组合。

#### 小结（3 分钟）
一句话回顾：**状态机用 Map 表驱动、乐观锁靠 WHERE 匹配、逻辑删除防误删、6 个接口按 HTTP 语义各归其位**。整个课程模块的 CRUD 收工。**预告** Day09 讲文件上传（把 `cover_url` 真正对接起来），Day10 讲代理模式与 AOP（把日志、事务等横切关注点抽出来）。

### 6.4 板书设计
```
┌────────────────────────────────────────────────────┐
│  Day08-06  状态流转 + Controller 汇总              │
├────────────────────────────────────────────────────┤
│  状态机：                                          │
│   0 待开始 ──┬──> 1 报名中 ──> 2 进行中 ──> 3 已结束 (终态) │
│              │                                     │
│              └──> 4 已取消 (终态)                  │
│              ↑                                     │
│              └── 1 报名中也能到 4                  │
│                                                    │
│  表驱动转移表：                                    │
│   Map<from, Set<to>>                               │
│   0 → {1, 4}                                       │
│   1 → {2, 4}                                       │
│   2 → {3}                                          │
│                                                    │
│  乐观锁 SQL：                                      │
│   UPDATE ... SET status=to                         │
│    WHERE id=? AND status=from                      │
│   rows==0 → 并发冲突                               │
│                                                    │
│  删除三选一：                                      │
│   物理 vs 逻辑 vs 归档                             │
│   → 本项目：逻辑删除                              │
│   → enrolled_count > 0 禁止删                     │
│                                                    │
│  Controller 6 接口：                               │
│   GET    /courses          分页                    │
│   GET    /courses/{id}     详情                    │
│   POST   /courses          新增                    │
│   PUT    /courses/{id}     全量改                  │
│   PATCH  /courses/{id}/status 状态改               │
│   DELETE /courses/{id}     逻辑删                  │
│                                                    │
│  AI 提示词四要素：                                 │
│   ① 表结构  ② 谓词模板  ③ excludeId  ④ 时间类型   │
│                                                    │
│  本模块常见坑：                                    │
│   ① Date vs LocalDateTime                          │
│   ② 时区                                           │
│   ③ 事务传播（Day11 讲）                           │
│   ④ BigDecimal.equals 用 compareTo                 │
│   ⑤ 终态回流没挡住                                 │
└────────────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成状态流转 + 逻辑删除 + Controller 6 接口的完整代码，交 Postman 5 组用例截图；
2. **必做**：写一段完整的 AI 提示词（参照本节的模板），让 AI 生成一版冲突检测代码，把 AI 的输出贴到作业中，并**用红笔**圈出至少 3 处可改进的地方；
3. **选做**：为课程模块补一个「批量取消」接口 `POST /courses/batch-cancel`，一次传多个 id，任何一个失败整体回滚（提示：`@Transactional` 的 `rollbackFor`，但**批量场景**要考虑「部分成功」是否可接受——Day11-12 讲事务时会展开）；
4. **选做**：给 Day10 预习：什么是「代理模式」？为什么要把「记录状态变更日志」这类横切关注点抽出来？

### 6.6 教学反思提示
- 若学生对「终态」概念模糊，可以引用现实场景类比：一节课已经上完（`3 已结束`）就不能再回到「报名中」；一个订单已经退款（`4 已取消`）就不能再变回「未支付」——现实世界中的「不可逆」；
- 若学生问「为什么不用状态机框架（Spring StateMachine）」，答：小状态机手写更清晰、依赖更少；如果状态爆炸（20+ 状态）再上框架不迟——**过早优化是万恶之源**；
- 若最后 AI 提示词环节时间紧，可让学生课后完成，把「用红笔圈错」当成必做作业交上来——比听老师讲收获更大。

---

**Day08 结课语（1 分钟）**：整整一天，我们把印想瑜伽会馆最关键的关联型业务数据——「课程」——从表结构到 Controller 全部走完。你们手上应该有：一张 `tb_course` 表、两个 VO 类、两条 SQL（list + count）、两个 DTO、一个 `ExistenceChecker`、两个冲突检测 SQL、一个 Service（5 个方法）、一个 Controller（6 个接口）——**加起来大约 800 行代码，覆盖 6 个接口，处理 15+ 种业务异常**。这是你们从事 Web 开发以来单日产出最大的一天，值得一张合影。明天 Day09 我们把课程封面图（`cover_url`）真正接通——**文件上传与阿里云 OSS**。
