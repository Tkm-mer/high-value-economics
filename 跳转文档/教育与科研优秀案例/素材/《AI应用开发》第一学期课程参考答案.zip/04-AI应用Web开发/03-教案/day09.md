# 《AI 应用 Web 开发》 - 教师教案（Day09：文件上传与阿里云 OSS + 代理模式与 AOP 概念）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day08 的学生（掌握 Spring Boot 4.0.x、MyBatis 3.5+、DTO/VO、Result 统一响应、全局异常处理、参数校验、日志与配置基础）**
**知识点覆盖：** 第 17 章 文件上传与阿里云 OSS（本地磁盘 + OSS 双方案 + 安全校验） + 第 18 章 代理模式与 AOP 概念（静态代理 → JDK 动态代理 → CGLIB → AOP 五要素 + this 调用坑）

**技术版本基线**：Spring Boot 4.0.x / Java 25 / MyBatis 3.5+ / MySQL 8.0 / aliyun-sdk-oss 3.17.4 / IDEA 2024.3+ / 通义灵码 + Trae。

**Day09 主线**：把印想瑜伽会馆之前预留的 `avatar / cover / id_card` 三个「URL 字段」真正接通——**前 3 个课时**把「文件从哪里来、存到哪里、URL 从哪里回」这条链路打穿；**后 3 个课时**把每一个方法都要重复的横切关注点（日志、耗时、事务、权限）抽出去，先讲代理模式的三种形态（静态 → JDK 动态 → CGLIB），再引出 Spring AOP 的五要素与切点表达式，最后落到「this 调用不走代理」这个必栽的经典坑，为 Day10 的 AOP 实战（操作日志 / 全局耗时监控）做概念铺垫。

---

## 第 1 课时：文件上传总览与本地磁盘方案（一）

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出「前端 multipart → Spring Boot → 存储介质 → URL 回落数据库」的完整链路图；
2. 能说出「本地磁盘」与「对象存储」两种方案在 5 个维度（多机部署 / 备份 / CDN / 大文件 / 成本）上的差异；
3. 能配置 `spring.servlet.multipart.max-file-size / max-request-size` 两个关键参数，并解释为什么 request-size 通常大于 file-size；
4. 能新建 `WebConfig implements WebMvcConfigurer`，用 `addResourceHandlers` 把本地磁盘目录映射到 URL 前缀；
5. 能写出最简版 `POST /files/upload` 接口，成功把一张图片写到 `D:/yinxiang/uploads` 并通过浏览器访问。

#### 1.1.2 过程与方法目标
1. 通过「先画链路图再敲代码」的顺序，训练「以数据流为中心」的接口设计思维；
2. 通过对比「Nginx 静态映射」与「Spring ResourceHandler」两种方案，理解「谁负责扛静态流量」这一架构取舍。

### 1.2 教学重难点
- **重点**：文件上传总体链路（multipart → Controller → Storage → URL）／`multipart.max-file-size` 与 `max-request-size` 的差异／`ResourceHandler` 把本地目录暴露成 HTTP 静态资源
- **难点**：`file:` 协议前缀与操作系统绝对路径的写法（Windows `D:/…`、Linux `/opt/…`）／`MultipartFile.transferTo` 相对路径的坑（默认落到临时目录，不是 `base-dir`）

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
以印想瑜伽会馆的实际场景切入：前面 Day03–Day08 已经把会员、教练、课程三张表落地，`tb_member.avatar / tb_coach.avatar / tb_course.cover` 三个字段都在 DDL 里，但联调时前端一直在问「图片到底传到哪儿去，URL 从哪里拿？」——今天就把这条链路打通。抛出目标：**一个通用的 `POST /files/upload`，同一份接口既能存到本地磁盘（开发环境），也能存到阿里云 OSS（生产环境），前端不用改一行代码**。

#### 新知讲授（14 分钟）

1. **文件上传总体链路**（4 分钟）：黑板上画四个方框——「前端 FormData」→「Spring MVC 解析 multipart」→「Storage 组件写入介质」→「数据库存 URL 字符串」。强调关键约定：**数据库里存的永远是 URL 字符串，不是二进制**；文件本身只在文件系统 / OSS 中。

2. **本地磁盘 vs 对象存储 五维对比**（5 分钟）：一张表逐行讲——多机部署（本地写 A 机，读到 B 机就 404）、备份容灾、CDN、大文件、成本。**结论**：生产 100% 用 OSS，本地磁盘只在开发环境用，理由是「便宜、不占学生的阿里云余额」。

3. **`multipart` 两个关键配置**（5 分钟）：
   - `spring.servlet.multipart.max-file-size: 10MB` —— 单个文件上限；
   - `spring.servlet.multipart.max-request-size: 30MB` —— 整个请求体上限（一次可能传 3 张图）；
   - **两个值必须同时调**，前端一次传 3 张 8MB 图，即使单张不超 10MB，也会因为 request 总和 24MB > 默认 10MB 被拒；
   - 再讲 `file-size-threshold`（超过阈值才写临时文件，否则直接内存），课堂上不深究，只提「一般不调」。

#### 示例演示（14 分钟）

1. **配置文件与静态映射**（6 分钟）：
   - `application.yml` 加 `spring.servlet.multipart` 三行 + 自定义 `yinxiang.upload.local.base-dir` `base-url`；
   - 现场敲 `WebConfig` + `addResourceHandlers`：`reg.addResourceHandler(baseUrl+"/**").addResourceLocations("file:"+baseDir+"/")`；
   - 特别强调结尾必须带 `/`，否则被 Spring 当成一个「文件」而非目录。

2. **最简上传接口**（6 分钟）：
   - 新建 `FileController`：`@PostMapping("/upload")`，参数 `@RequestPart("file") MultipartFile file`；
   - 现场演示——如果用 `@RequestParam` 也能收到，但语义上 `@RequestPart` 更明确；
   - 直接 `file.transferTo(new File("D:/yinxiang/uploads/"+file.getOriginalFilename()))` 落盘（这里故意用原始文件名，下一课时打脸）；
   - Postman：Body → form-data → key=`file` type=File，上传一张 png，返回 200；
   - 浏览器打开 `http://localhost:8080/files/xxx.png` 应能预览。

3. **AI 助手写一版对照**（2 分钟）：给通义灵码贴需求「Spring Boot 4 文件上传 + 本地磁盘 + 静态映射」，观察 AI 是否会：① 忘记 `spring.servlet.multipart` 配置；② 用相对路径调 `transferTo`；③ 忘记结尾的 `/`。**AI 常犯错清单**当堂列到黑板。

#### 课堂练习（10 分钟）
1. 每位学生完成「上传 test.png → 浏览器可预览」闭环，交两张截图（Postman 200 + 浏览器可看图）；
2. 追加要求：把 `max-file-size` 改成 `1MB`，上传 5MB 图片，观察 Spring 抛什么异常（`MaxUploadSizeExceededException`，包 `org.springframework.web.multipart`）；
3. 思考题：为什么 `ResourceHandler` 的第二个参数一定要 `file:` 前缀？（提示：`Resource` 的 URL 协议解析）

#### 小结（3 分钟）
一句话回顾：**multipart 双阈值 + ResourceHandler 静态映射 + Controller 三行**。链路能跑通了，但**安全**还没做——下一课时补上安全命名、大小与类型校验，把这张接口变成生产可用。

### 1.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-01 文件上传总览 + 本地磁盘（一）      │
├───────────────────────────────────────────────┤
│  链路四段：                                   │
│   FormData → multipart 解析                   │
│   → Storage 落盘/OSS → 数据库存 URL           │
│                                               │
│  两大方案：                                   │
│   本地磁盘：开发环境                          │
│   对象存储：生产环境                          │
│                                               │
│  multipart 两阈值：                           │
│   max-file-size    单文件上限                 │
│   max-request-size 请求体总上限               │
│                                               │
│  ResourceHandler：                            │
│   /files/** → file:D:/yinxiang/uploads/       │
│   末尾 / 不能少                               │
│                                               │
│  接口最小闭环：                               │
│   POST /files/upload  @RequestPart file       │
└───────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `POST /files/upload` 本地磁盘最小版，交 3 张截图（Postman 成功 / 浏览器预览 / 磁盘目录快照）；
2. **必做**：整理「Spring 上传相关常见异常」速查表，至少覆盖 `MaxUploadSizeExceededException`、`MultipartException`、`FileNotFoundException` 三种；
3. **挑战**：改造 `ResourceHandler`，同时映射两个目录（`/files/**` → 本地 uploads，`/static/**` → classpath 静态资源），观察路径冲突时哪一个优先。

### 1.6 教学反思提示
- 学生最容易忘 `base-dir` 结尾的 `/`，导致 URL 404，示例演示时故意先漏一次让学生找 bug；
- Windows 学生的 `D:/yinxiang/uploads` 需要**手工提前建好**，否则 `transferTo` 报「路径不存在」；Linux/Mac 学生要注意目录写入权限；
- 若课堂时间紧，AI 对照环节可以并到下一课时讲，本课时保住「链路跑通」是硬指标。

---

## 第 2 课时：本地磁盘上传实战——三层安全校验 + 日期分桶 + UUID 命名

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能实现「非空 + 大小 + 扩展名」三层安全校验，任何一层失败都抛 `BizException`；
2. 能用 `Set.of("jpg","jpeg","png","gif","webp")` 组织**白名单**扩展名校验，理解为什么用白名单而不是黑名单；
3. 能按 `yyyy/MM/dd/<UUID>.<ext>` 组装存储路径，理解「日期分桶」的目录压平作用；
4. 能封装 `LocalFileStorage` 组件，把「校验 + 命名 + 落盘 + 拼 URL」四步收敛在一个 `save(MultipartFile)` 方法里；
5. 能返回 `UploadVO(url, size, ext)` 结构，前端拿到后即可直接写回业务字段（如 `memberDTO.avatar`）。

#### 2.1.2 过程与方法目标
1. 通过「用户传 `../../etc/passwd` 会怎样」的攻击面反推，训练「永远不信任外部输入」的安全意识；
2. 通过对比「原始文件名 vs UUID 命名」的目录快照，理解「服务端自主命名」的工程价值。

### 2.2 教学重难点
- **重点**：三层校验（非空 / 大小 / 白名单扩展名）／`yyyy/MM/dd/<UUID>.<ext>` 命名规则／`try-with-resources` 处理输入流（本地场景可省，但要养成习惯）
- **难点**：白名单 vs 黑名单的安全差异（`.png.exe` 双扩展名黑名单绕过）／`file.transferTo` 必须传绝对路径否则落到 servlet 临时目录

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：「上节课直接用 `file.getOriginalFilename()` 落盘。如果我把文件名改成 `../../../../etc/passwd`，会发生什么？」引出**目录穿越攻击**。再问：「如果我把 `virus.exe` 改名成 `cute.png`，你的校验挡得住吗？」引出**扩展名白名单 + 后续 magic number** 的话题（magic number 本课不深入，只提概念）。

#### 新知讲授（15 分钟）

1. **三层安全校验**（6 分钟）：
   - **第 1 层 非空**：`if (file == null || file.isEmpty()) throw new BizException("请选择文件")`——前端可能表单没勾就点提交；
   - **第 2 层 大小**：`if (file.getSize() > 5*1024*1024) throw new BizException("单文件不得超过 5MB")`——**Java 层再挡一次**，即使 `application.yml` 的 `max-file-size` 被误改，业务上限仍在；
   - **第 3 层 白名单扩展名**：`Set.of("jpg","jpeg","png","gif","webp")` 常量集合 + `file.getOriginalFilename()` 取扩展名，`toLowerCase(Locale.ROOT)` 归一化；
   - **为什么用白名单**：黑名单永远漏，`.php` `.jsp` `.exe` `.sh` `.html`…你永远补不全；白名单只写「明确允许的」，其余一律拒。

2. **文件命名策略**（5 分钟）：
   - 反例 1：用原始文件名 → 中文乱码 / 特殊字符 / 目录穿越 / 同名覆盖，四个坑一起踩；
   - 反例 2：只用 UUID 不分目录 → 一个目录堆到几十万个文件，`ls` 直接卡死；
   - **推荐**：`yyyy/MM/dd/<32位 UUID>.<ext>` —— 日期分桶天然限制每目录规模到「一天几千个」，UUID 保证唯一，扩展名保留业务语义；
   - `DateTimeFormatter.ofPattern("yyyy/MM/dd")` + `UUID.randomUUID().toString().replace("-","")` 是标准写法。

3. **返回结构 `UploadVO`**（4 分钟）：
   - Java 25 用 `record` 一行搞定：`public record UploadVO(String url, long size, String ext) {}`；
   - 为什么带 `size` `ext`：前端上传封面时可以立即显示「已上传 3.2MB，PNG 格式」，不用再发一次请求；
   - **返回结构一稳定，前端就能写死渲染逻辑**——所有存储方案（本地 / OSS / COS）都得返回这个格式。

#### 示例演示（14 分钟）

1. **重构 `LocalFileStorage`**（8 分钟）：
   - 抽出 `LocalFileStorage` 组件（`@Component + @RequiredArgsConstructor + @Slf4j`）；
   - 私有常量 `IMAGE_EXTS` `MAX_SIZE`；
   - `save(MultipartFile)` 方法体：三层校验 → 组装 `rel` 相对路径 → `FileUtils.forceMkdirParent(target)` 建目录 → `file.transferTo(target)` → 拼 `url` 返回；
   - `Controller` 精简为一行：`return Result.success(localStorage.save(file))`。

2. **联调三种场景**（4 分钟）：
   - **正常**：上传 3MB PNG → 成功，`url = /files/2026/07/17/xxxxxxxx.png`；
   - **超大**：上传 8MB JPG → 「单文件不得超过 5MB」；
   - **非图片**：改扩展名为 `.exe` 上传 → 「仅支持 jpg/png/gif/webp」；
   - 顺手在磁盘上打开 `D:/yinxiang/uploads/2026/07/17/`，看目录结构确实是日期分桶。

3. **让 AI 找漏洞**（2 分钟）：把「只做扩展名校验」的这版代码丢给 AI，让它列出**潜在攻击面**。AI 通常会给出：magic number 校验、文件名清洗、单 IP 上传频率限制、病毒扫描等。**AI 是安全审查伙伴**，但输出要人工挑主要矛盾——本课程只落到「白名单扩展名 + UUID 命名」，其余方向作为拓展题。

#### 课堂练习（10 分钟）
1. 每位学生完成三种校验闭环，交 3 张截图（正常 / 超大 / 非图片）；
2. 追加需求：把 `MAX_SIZE` 抽到 `application.yml`（`yinxiang.upload.max-size: 5MB`），用 `@Value` + `DataSize` 类型注入；
3. 思考题：把 `IMAGE_EXTS` 换成读配置（`yinxiang.upload.allowed-exts: jpg,png,webp`），要动几个类？（提示：`@Value("${...}") private Set<String> allowedExts` 是否可行？）

#### 小结（3 分钟）
一句话回顾：**三层校验挡住脏输入，UUID + 日期分桶让文件系统长得像仓库而不是垃圾场**。下节课把这一切搬到阿里云 OSS 上，配一个 `enabled` 开关做优雅切换。

### 2.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-02 本地上传实战                        │
├───────────────────────────────────────────────┤
│  三层安全校验：                               │
│   ① 非空       file.isEmpty()                 │
│   ② 大小       size > MAX_SIZE                │
│   ③ 白名单扩展名  IMAGE_EXTS.contains(ext)    │
│                                               │
│  命名策略：                                   │
│   yyyy/MM/dd/<UUID>.<ext>                     │
│   → 目录分桶 + 唯一 + 保留业务语义            │
│                                               │
│  返回结构（record）：                         │
│   UploadVO(url, size, ext)                    │
│                                               │
│  为什么白名单：                               │
│   黑名单永远补不全                            │
│   .php .jsp .sh .exe .html .htaccess …        │
│                                               │
│  攻击面：                                     │
│   目录穿越、双扩展名、magic 伪装、恶意脚本    │
└───────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成三层校验版 `LocalFileStorage`，交联调截图 + 磁盘目录截图；
2. **必做**：把 `MAX_SIZE` 与 `IMAGE_EXTS` 抽到配置文件，用 `@ConfigurationProperties` 收拢到 `LocalUploadProperties`；
3. **必做**：把 Day09-01 生成的直接用原始文件名的旧版代码删掉，git commit 一次「重构：文件上传引入安全校验与 UUID 命名」；
4. **挑战**：追加 magic number 校验——读取文件头 8 个字节，判断是否与扩展名声明的图片类型一致（提示：PNG=`89 50 4E 47`，JPG=`FF D8 FF`）。

### 2.6 教学反思提示
- 三层校验的顺序**不能乱**——「非空 → 大小 → 类型」代价递增，先便宜的校验先拦；把 magic number 校验放最后，因为要读文件；
- 演示「上传 `.exe` 改名 `.png`」时，一定要**实际做一次**——学生看到「校验通过但文件其实是 exe」的瞬间，magic number 的必要性就自动种进他们脑子里；
- Java 25 `record` 的 `getUrl()` 写法不再是 `getXxx()` 而是 `xxx()`，前端 JSON 序列化时字段名仍是 `url`，可以放心用。

---

## 第 3 课时：阿里云 OSS 集成 + `@ConditionalOnProperty` 优雅切换

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能在阿里云控制台完成「开通 OSS → 建 Bucket → RAM 子用户 → AccessKey」四步准备，并解释每一步的安全含义；
2. 能引入 `aliyun-sdk-oss:3.17.4` 依赖，写一个 `OssProperties` + `OssConfig`，用 `@Bean(destroyMethod="shutdown")` 声明 `OSS` 客户端；
3. 能实现 `OssFileStorage` 组件，复用「三层校验 + UUID + 日期分桶」逻辑，只把落盘部分换成 `ossClient.putObject`；
4. 能用 `@ConditionalOnProperty(prefix="...", name="enabled", havingValue="true")` 让 OSS Bean 在未启用时不加载；
5. 能在 `FileController` 中用 `ObjectProvider<OssFileStorage>` + 一个布尔开关做「本地 / OSS」的运行时切换，前端接口不变。

#### 3.1.2 过程与方法目标
1. 通过「AK/SK 泄露」的真实事故案例（GitHub 扫库、几小时被盗刷十几万），训练**永不硬编码密钥**的意识；
2. 通过对比「if-else 硬切换 vs `@ConditionalOnProperty`」两种写法，理解 Spring 条件装配的工程收益。

### 3.2 教学重难点
- **重点**：Bucket / RAM 子用户 / AK / Endpoint / Domain 五个概念的角色分工／`@ConditionalOnProperty` 让 OSS 组件按需加载／`ObjectProvider` 优雅处理「可能存在也可能不存在的 Bean」
- **难点**：`Endpoint`（`https://oss-cn-hangzhou.aliyuncs.com`）与 `Domain`（`https://<bucket>.oss-cn-hangzhou.aliyuncs.com`）的差异——前者是**上传时**用的 API 域名，后者是**读取时**用的 CDN 域名／`putObject` 的 `InputStream` 必须用 try-with-resources

### 3.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
真实故事：某创业公司把主账号 AK/SK 提交到 GitHub 公开仓库，凌晨 4 点被脚本扫库拿走，几小时内被开了 200 台按量付费 GPU 挖矿实例，一觉起来欠费 3 万块。**主账号 AK 一次都不能出现在业务代码里**——今天从「怎么建子用户」开始讲，把安全线拉在最前面。

#### 新知讲授（15 分钟）

1. **阿里云控制台四步准备**（5 分钟）：
   - **步骤 1**：开通「对象存储 OSS」（免费开通，按量付费）；
   - **步骤 2**：建 Bucket，起名 `yinxiang-yoga`，区域「华东 1（杭州）」，读写权限**「公共读」**（头像、封面场景），存储类型「标准」；
   - **步骤 3**：到「访问控制 RAM」建**子用户**，勾选 `AliyunOSSFullAccess` 策略（生产可进一步收敛到 `AliyunOSSPutObjectAccess`），记下 `AccessKeyId` `AccessKeySecret`；
   - **步骤 4**：记 Endpoint `https://oss-cn-hangzhou.aliyuncs.com` 和访问域名 `https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com`——**两个不同的东西**。

2. **依赖 + 配置类**（5 分钟）：
   - `pom.xml` 引 `aliyun-sdk-oss:3.17.4`；
   - `application.yml` 加 `yinxiang.upload.oss` 段，AK/SK 用 `${OSS_AK:xxx}` **环境变量优先**；
   - IDEA Run Configuration → Environment Variables 里配 `OSS_AK` `OSS_SK`，**不提交到 Git**；
   - `@ConfigurationProperties(prefix="yinxiang.upload.oss")` 收拢到 `OssProperties`；
   - `OssConfig` 加 `@ConditionalOnProperty(prefix="yinxiang.upload.oss", name="enabled", havingValue="true")`——**不填 `enabled=true` 时 OSS Bean 根本不加载**，本地开发不用申请 OSS 也能启动。

3. **`OssFileStorage` 组件**（5 分钟）：
   - 复用三层校验逻辑，抽 `FileNameUtil.ext(name)` 静态方法；
   - key 命名：`"images/" + yyyy/MM/dd + "/" + UUID + "." + ext`——**OSS 里的 `/` 只是文件名的一部分**，OSS 本身没有目录概念，但控制台会按 `/` 拆分展示为目录；
   - `try (InputStream in = file.getInputStream()) { ... }` **必须 try-with-resources**——OSS SDK 不负责关；
   - `ObjectMetadata` 设 `ContentLength`、`ContentType`（关键，缺少会被浏览器当成下载）、`CacheControl` 一年（图片是不可变资源，随便缓存）；
   - 双异常捕获：`IOException`（本地读文件失败）与 `OSSException | ClientException`（OSS 端失败），**都要打日志**，日志里带 `code` `message` 但**别把 AK 打出来**。

#### 示例演示（14 分钟）

1. **代码演进对照**（6 分钟）：
   - 打开上一课时的 `LocalFileStorage`，把「校验 + 命名」两部分抽成 `AbstractFileStorage` 的模板方法（或用 `FileNameUtil` 静态类共用），**避免复制粘贴**；
   - 现场新建 `OssFileStorage`，仅实现「落盘 → OSS put」这一步；
   - 演示 IDEA 里两个类并排的字段完全一致，`save` 方法差异只有落盘那 5 行。

2. **`FileController` 加开关**（4 分钟）：
   - 注入 `LocalFileStorage localStorage` + `ObjectProvider<OssFileStorage> ossStorageProvider`；
   - `@Value("${yinxiang.upload.oss.enabled:false}") boolean ossEnabled`；
   - `upload` 方法体：`var storage = ossEnabled ? ossStorageProvider.getIfAvailable() : localStorage`，null 兜底抛 `BizException("上传存储未配置")`；
   - **前端接口一字不改**，就在配置里一行切换。

3. **联调切换**（4 分钟）：
   - 先跑本地版：`yinxiang.upload.oss.enabled=false`，Postman 上传，URL 是 `/files/...`；
   - 停服务，改成 `true` 并配好 AK/SK 环境变量，重启；
   - Postman 上传同一张图，URL 变成 `https://yinxiang-yoga.oss-cn-hangzhou.aliyuncs.com/images/...`，浏览器直接可访问；
   - 到阿里云控制台 OSS Bucket，能看到 `images/2026/07/17/xxx.png`——**证据链完整**。

#### 课堂练习（10 分钟）
1. 每位学生按发的 AK/SK（教师课前建好的教学 Bucket，会后销毁）完成 OSS 切换闭环，交 3 张截图（本地版 URL / OSS 版 URL / OSS 控制台目录）；
2. 追加需求：给 `OssFileStorage.save` 加**上传结果校验**——`putObjectResult.getResponse().getStatusCode() == 200` 才认为成功，否则抛 `BizException`；
3. 思考题：Bucket 权限改为「私有」后，之前的 URL 会怎样？（403）如何做？（下一章讲，先记住关键词「签名 URL」）。

#### 小结（3 分钟）
一句话回顾：**RAM 子用户 + 环境变量 AK/SK + `@ConditionalOnProperty` 让 OSS 组件按需加载**。前 3 课时把「文件从哪里来、URL 从哪里回」这条链路彻底打穿，下一课时开始换主题——把每个方法都要打的日志、耗时、事务抽出去，先讲代理模式。

### 3.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-03 阿里云 OSS 集成                     │
├───────────────────────────────────────────────┤
│  控制台四步：                                 │
│   ① 开通 OSS                                  │
│   ② 建 Bucket（公共读）                       │
│   ③ RAM 子用户 + AK/SK                        │
│   ④ 记 Endpoint & Domain                      │
│                                               │
│  三个绝不：                                   │
│   ✘ 主账号 AK 用在业务                        │
│   ✘ AK/SK 硬编码进代码                        │
│   ✘ AK/SK 提交进 Git                          │
│                                               │
│  条件装配：                                   │
│   @ConditionalOnProperty                      │
│     name="enabled" havingValue="true"         │
│                                               │
│  Controller 切换：                            │
│   ObjectProvider<OssFileStorage> + 布尔开关   │
│                                               │
│  key 命名：images/yyyy/MM/dd/UUID.ext         │
│  URL：<domain>/<key>                          │
└───────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成 OSS 版接口，交 4 张截图（本地 / OSS URL / OSS 控制台 / 环境变量配置界面）；
2. **必做**：写一段 300 字反思：如果 AK/SK 泄露了，你应该在 15 分钟内完成的三件事（提示：禁用密钥 → 建新密钥 → 检查账单）；
3. **必做**：把 `POST /files/upload` 拿到的 URL，回填到 `POST /api/member` 的 `avatar` 字段，验证 Day05 会员新增接口能正确保存；
4. **挑战**：给 `OssFileStorage` 加**进度回调**（`ProgressListener`），上传 20MB 大文件时能在日志里看到 `[OSS 上传] 30%、60%、90%`。

### 3.6 教学反思提示
- 演示 AK/SK 配置时，**遮盖真实 secret 的后 16 位**，示范正确的分享姿势；
- 部分学生首次进阿里云控制台会花不少时间做实名认证，可以让他们先本地跑通（`enabled=false`），阿里云配置作为课后练习延后；
- 若课堂时间紧，`ObjectProvider` 的差异只讲一句「它比 `@Autowired` 允许 Bean 不存在」，具体源码留到 Day10 或课后拓展。

---

## 第 4 课时：代理模式三形态——静态 → JDK 动态 → CGLIB

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能写出「静态代理」的最小可运行示例，并解释「为什么代理类要实现同一个接口」；
2. 能用 `java.lang.reflect.Proxy.newProxyInstance` 写出 JDK 动态代理，解释三个入参（`ClassLoader` / `Class[] interfaces` / `InvocationHandler`）的作用；
3. 能用 CGLIB `Enhancer.setSuperclass + setCallback(MethodInterceptor)` 写出无接口场景下的动态代理；
4. 能说出「JDK 动态代理只支持接口，CGLIB 支持类」的核心原因（**JDK 生成的是接口实现类，CGLIB 生成的是子类**）；
5. 能说明 Spring Boot 2.x 起 AOP 默认走 CGLIB 的原因（避免注入类型不一致）。

#### 4.1.2 过程与方法目标
1. 通过「静态 → JDK → CGLIB」的演进梯度，训练「从复制粘贴到运行时生成」的抽象思维；
2. 通过「同一个 `MemberService` 分别用三种代理增强」的实验，理解代理模式的核心不变量：**替身 + 委托**。

### 4.2 教学重难点
- **重点**：静态代理的样板代码痛点／`InvocationHandler.invoke` 的三个参数（`proxy / method / args`）／CGLIB 通过继承实现代理
- **难点**：JDK 动态代理为什么必须要接口（生成类是 `Proxy` 的子类 + 实现指定接口，若无接口拿不到「等价替身」）／CGLIB 对 `final` 方法/类的限制

### 4.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
回顾一句话痛点：Day08 我们已经写了 20 多个 Service 方法，几乎每个方法开头都在打 `log.info("[XX 新增] ...")`、结尾都在算耗时。**这些代码不是业务，是「横切关注点」**。我们希望：**业务代码只写业务，横切逻辑另开一个「小接一脚，走完就退」的地方**——这就是 AOP。要吃透 AOP，先要把它的地基**代理模式**弄明白。

#### 新知讲授（16 分钟）

1. **代理模式定义**（3 分钟）：
   - **代理 = 替身**。客户端只认代理，代理内部握着 target，调 target 前后加自己的逻辑；
   - 现实类比：明星（target）+ 经纪人（proxy）。粉丝找经纪人签合同，经纪人先审合约再交给明星，明星只管演戏；
   - 类图：`Subject`（接口）← `RealSubject`（target）/ `Proxy`（代理，也实现 Subject，持有 RealSubject 引用）。

2. **静态代理**（5 分钟）：
   - 现场敲 `MemberService` 接口 + `MemberServiceImpl` 目标 + `LoggingMemberServiceProxy` 代理三个类；
   - 代理的 `save` 方法体：`before log → target.save(dto) → finally after log`；
   - 优点：一目了然；
   - **痛点**：每加一个业务接口就要新写一个代理类；每加一个方法就要在**所有代理类**里加同一份模板——面向对象的复制粘贴。设想 100 个 Service，就是 100 份代理，一处 log 格式改动要改 100 次。

3. **JDK 动态代理**（4 分钟）：
   - `Proxy.newProxyInstance(loader, interfaces, handler)` 运行时**动态生成一个实现指定接口的类**；
   - `InvocationHandler.invoke(proxy, method, args)`：所有被代理的方法调用都会走到这里，`method.invoke(target, args)` 完成委托；
   - **关键限制**：`target.getClass().getInterfaces()` 必须非空——没有接口就没法生成「等价替身」。

4. **CGLIB 代理**（4 分钟）：
   - `Enhancer.setSuperclass(TargetClass) + setCallback(MethodInterceptor)` 通过**继承目标类**生成代理子类；
   - `MethodInterceptor.intercept(obj, method, params, methodProxy)`：注意用 `methodProxy.invokeSuper(obj, params)` 调父类实现，**不要**用 `method.invoke(target, ...)`（后者会走反射，性能差且需要 target 引用）；
   - 限制：目标类不能 `final`，被增强方法不能 `final / private / static`；
   - Spring Boot 2.x 起 `@EnableAspectJAutoProxy(proxyTargetClass = true)` **默认**——不管有没有接口都走 CGLIB，避免「注入类型是接口还是实现类」的困惑。

#### 示例演示（14 分钟）

1. **静态代理**（3 分钟）：
   - 敲 `LoggingMemberServiceProxy`，`main` 方法里 `new LoggingMemberServiceProxy(new MemberServiceImpl()).save(...)`；
   - 控制台看到 `[LOG] before save / [LOG] after save cost=1ms`。

2. **JDK 动态代理**（5 分钟）：
   - 敲 `LoggingHandler implements InvocationHandler`；
   - `Proxy.newProxyInstance(target.getClass().getClassLoader(), target.getClass().getInterfaces(), new LoggingHandler(target))` 拿到 proxy；
   - 强转成 `MemberService` 调 `save`，同样输出 log；
   - **实验**：故意把 `MemberServiceImpl` 上的 `implements MemberService` 删掉重跑——`getInterfaces()` 返回空数组，运行时抛错，学生印象深刻。

3. **CGLIB 代理**（4 分钟）：
   - 引入 `cglib` 依赖（或使用 Spring 自带的 `org.springframework.cglib.proxy.Enhancer`）；
   - 现场敲 `Enhancer` 三行；
   - **实验**：把 `MemberServiceImpl` 加上 `final` 关键字，`Enhancer.create()` 直接抛异常——CGLIB 靠继承，父类 final 就没戏。

4. **观察 Spring 用的哪种代理**（2 分钟）：
   - 打开印想瑜伽项目，`@Autowired ApplicationContext ctx`，`ctx.getBean("memberService").getClass().getName()`；
   - 由于 Spring Boot 默认 `proxyTargetClass=true`，看到 `com.yinxiang.service.MemberService$$SpringCGLIB$$0`——**Spring 悄悄用 CGLIB 把你的 Bean 换了替身**。

#### 课堂练习（8 分钟）
1. 每位学生完成静态代理 + JDK 动态代理两个版本的「方法耗时打印」，交代码 diff；
2. 追加实验：给 `MemberServiceImpl` 加 `final`，观察 CGLIB 报错信息，把异常堆栈贴到笔记；
3. 思考题：如果同一个类既有 `save(MemberDTO)`，又有 `save(CoachDTO)`（重载），`InvocationHandler.invoke` 里如何区分？（`method.getParameterTypes()`）

#### 小结（3 分钟）
一句话回顾：**静态代理 = 复制粘贴、JDK 动态代理 = 接口反射生成、CGLIB = 继承生成**。三种形态从「手工」到「运行时」逐级抽象。下一课时把 Spring AOP 的五要素铺开，把「代理」这个底层能力包装成开箱即用的注解式声明。

### 4.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-04 代理模式三形态                      │
├───────────────────────────────────────────────┤
│  静态代理：                                   │
│   Proxy implements Subject                    │
│   痛：一接口一代理类，方法级复制粘贴          │
│                                               │
│  JDK 动态代理：                               │
│   Proxy.newProxyInstance(loader,ifs,handler)  │
│   InvocationHandler.invoke(proxy,method,args) │
│   限制：目标必须实现接口                      │
│                                               │
│  CGLIB 代理：                                 │
│   Enhancer.setSuperclass + Callback           │
│   MethodInterceptor.intercept                 │
│   限制：类/方法不能 final                     │
│                                               │
│  Spring 选择：                                │
│   Boot 2.x+ 默认 proxyTargetClass=true → CGLIB│
│   getBean 后 .getClass() 有 $$SpringCGLIB$$   │
│                                               │
│  核心不变量：替身 + 委托                      │
└───────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：交静态代理 + JDK 动态代理 + CGLIB 三个版本的最小 Demo，附控制台输出截图；
2. **必做**：在印想瑜伽项目里加一句 `ctx.getBean(...).getClass().getName()` 到 `@PostConstruct`，观察 Service Bean 是不是 `$$SpringCGLIB$$`，截图；
3. **挑战**：读一下 `java.lang.reflect.Proxy.getProxyClass` 生成的字节码（用 `Files.write` 把 `sun.misc.ProxyGenerator.generateProxyClass` 结果写到磁盘 → `javap -c` 反编译），观察 JDK 到底生成了什么。

### 4.6 教学反思提示
- 「JDK 必须要接口，CGLIB 不要求」这句话是**面试题模板**，一定要让学生自己动手实验一次才有记忆；
- 部分学生会问「Spring 的选择规则我到底记 JDK 还是 CGLIB」，一句话结论：**Spring Boot 2.x 起默认 CGLIB，别的场景问 JDK/CGLIB 差异**；
- CGLIB 演示时如果引入 `cglib` 依赖太麻烦，可以直接用 Spring 自带的 `org.springframework.cglib.proxy.Enhancer`，效果一致。

---

## 第 5 课时：Spring AOP 五要素 + 切点表达式 + 最小可运行切面

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能说出 AOP 五要素（Aspect / Pointcut / Advice / JoinPoint / Weaving）+ Target / Proxy 共 7 个术语的一句话定义；
2. 能识别并写出五种 Advice（`@Before / @After / @AfterReturning / @AfterThrowing / @Around`）的正确签名，并解释 90% 场景为什么用 `@Around`；
3. 能写出 4 种常用切点表达式：包路径（`execution(* ..controller..*.*(..))`）、类注解（`@within`）、方法注解（`@annotation`）、组合（`&&`）；
4. 能写出一个「拦截所有 Controller、打印方法耗时」的最小可运行切面，并在不改 Controller 一行代码的前提下让全局生效；
5. 能通过 `ProceedingJoinPoint.getSignature().toShortString()` 获取被切方法的签名，`pjp.getArgs()` 获取入参。

#### 5.1.2 过程与方法目标
1. 通过「代理三形态」→「Spring AOP 声明式抽象」的对照，理解框架把「工程复用」推到什么程度；
2. 通过「一份 `@Around` = Before + After + AfterReturning + AfterThrowing 四合一」的展示，训练**用最少代码覆盖最多需求**的取舍。

### 5.2 教学重难点
- **重点**：五要素术语字典／`@Around` 的标准骨架（`try { proceed(); ... } catch { ...; throw; } finally { ... }`）／`execution / @annotation / @within` 三大切点表达式
- **难点**：切点表达式的 `..`（任意层子包）与 `*`（一个通配）区别／`@Around` 里忘 `throw e` 会**吞异常**导致业务异常悄悄消失

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
上节课我们用 CGLIB 手写代理增强了一个 `MemberService`，本质是「拦所有方法、加日志」。**Spring AOP 就是把这件事变成注解**——你只需要写 `@Aspect + @Around("execution(...)")`，Spring 帮你把代理装配好、把切点表达式解析成拦截规则、把 `Advice` 方法织入进去。今天我们把 AOP 的「说明书」啃完，然后写一个能立即上线的切面。

#### 新知讲授（17 分钟）

1. **五要素术语字典**（6 分钟）：黑板画一张图，边讲边标：
   - **Aspect（切面）**：一份横切逻辑的打包，例如 `LoggingAspect` 类，头顶 `@Aspect`；
   - **Pointcut（切点）**：「拦哪些方法」的规则，用 AspectJ 表达式描述；
   - **Advice（通知）**：「拦到之后做什么」，是切面里的方法；
   - **JoinPoint（连接点）**：被拦截的那个方法调用瞬间，从中可拿到方法名、参数、目标类；
   - **Weaving（织入）**：把 Advice 塞进 Target 的动作，Spring AOP 是**运行时**织入；
   - 顺带：**Target**（原始对象）与 **Proxy**（Spring 给你的替身，Bean 里注入的其实是它）。

2. **五种 Advice**（4 分钟）：一张表，顺口溜「前后成异环」：
   - `@Before` 方法前；
   - `@After (finally)` 方法后（无论正常/异常，等价 Java 的 finally）；
   - `@AfterReturning` 正常返回后（可拿返回值）；
   - `@AfterThrowing` 抛异常后（可拿异常）；
   - `@Around` **环绕**——能覆盖上面四种全部能力，还能决定「要不要真的调 target」，日常 90% 只用它。

3. **切点表达式速查**（4 分钟）：
   - `execution(* com.yinxiang.controller..*.*(..))` —— 拦 controller 包下**所有子包所有类所有方法**；
   - `execution(public * com.yinxiang.service..*.*(..))` —— 只拦 public；
   - `@annotation(com.yinxiang.annotation.OperationLog)` —— 拦所有标了自定义注解的方法；
   - `@within(org.springframework.web.bind.annotation.RestController)` —— 拦类头带 `@RestController` 的所有方法；
   - 组合：`execution(...) && @annotation(...)` —— 交集；
   - **口诀**：`..` 任意层子包、`*` 一个通配、`(..)` 任意个参数。

4. **`@Around` 标准骨架**（3 分钟）：
   ```java
   @Around("controllerLayer()")
   public Object around(ProceedingJoinPoint pjp) throws Throwable {
       long t = System.currentTimeMillis();
       try {
           Object ret = pjp.proceed();
           // 正常返回后
           return ret;
       } catch (Throwable e) {
           // 抛异常后
           throw e;                    // ← 一定要重新抛，否则吞异常
       } finally {
           // 无论成败
       }
   }
   ```
   - `throw e` 不能省，否则业务异常被 AOP 吃掉、前端拿不到错误响应，事故等级 P1；
   - 返回类型 `Object`、必抛 `Throwable`——这是 `@Around` 的固定签名，别自作聪明改成 `void` 或 `RuntimeException`。

#### 示例演示（14 分钟）

1. **最小可运行切面**（6 分钟）：
   - 新建 `TimingAspect` 类（`@Aspect + @Component + @Slf4j`）；
   - `@Pointcut("execution(* com.yinxiang.controller..*.*(..))")` 命名 `controllerLayer()`；
   - `@Around("controllerLayer()")` 方法体：耗时统计 + 签名日志 + 异常处理；
   - **重启项目、随便调一个 GET 接口**，控制台立刻出现 `[耗时] MemberController.page cost=42ms`——**没动 Controller 一行代码就给全局加了统计**。

2. **切点表达式扩展**（4 分钟）：
   - 加一版 `@Pointcut("@annotation(com.yinxiang.annotation.OperationLog)")` `operationLog()`；
   - 定义 `OperationLog` 自定义注解（`@Target(METHOD) @Retention(RUNTIME)`，只留一个 `value()`）；
   - `@Around("operationLog()")` 里 `pjp.getSignature()` 拿方法名，再用 `MethodSignature.getMethod().getAnnotation(OperationLog.class).value()` 拿业务描述；
   - 在 `MemberController.save` 上加 `@OperationLog("新增会员")`，Postman 调一次，日志出现 `[操作日志] 新增会员 args=[MemberDTO(...)]`。

3. **AI 帮忙生成一版 IP + UA 记录切面**（4 分钟）：
   - 给通义灵码贴需求「基于 Spring AOP + `@RestController` @within 切点，记录每次请求的 IP / UA / 耗时 / 状态」；
   - 观察 AI 通常犯的错：① `@Around` 忘 `throw e`；② 用 `RequestContextHolder` 却没判空（非 web 线程会 NPE）；③ 把切面自己所在包也切进去导致栈溢出；
   - 现场把这三处修正，形成对照。

#### 课堂练习（8 分钟）
1. 每位学生完成「Controller 全局耗时切面」，跑通 3 个不同接口，交日志截图；
2. 追加需求：耗时超过 500ms 时把日志级别升到 `WARN`，正常时 `INFO`；
3. 思考题：如果两个切面都命中同一个方法，执行顺序由什么决定？（`@Order` / `Ordered` 接口，值越小越早执行）

#### 小结（3 分钟）
一句话回顾：**`@Aspect + @Pointcut + @Around` 三件套，切点表达式 = execution / @annotation / @within**。今天写的耗时切面已经能上线，但**还有一个坑必栽**——在自己的 Service 里 `this.methodB()` 会绕过代理，AOP 直接失效。下节课把这个坑讲透，Day09 收官。

### 5.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-05 Spring AOP 五要素                   │
├───────────────────────────────────────────────┤
│  五要素（+ 2 支撑角色）：                    │
│   Aspect     一份横切逻辑                     │
│   Pointcut   拦哪些方法                       │
│   Advice     拦到做什么                       │
│   JoinPoint  拦截时刻的上下文                 │
│   Weaving    织入动作（运行时）               │
│   Target / Proxy   原对象 / 替身              │
│                                               │
│  五种 Advice（顺口溜 前后成异环）：          │
│   @Before / @After / @AfterReturning /        │
│   @AfterThrowing / @Around（90% 只用它）      │
│                                               │
│  @Around 骨架：                               │
│   try { proceed(); }                          │
│   catch (Throwable e) { throw e; }            │
│   finally { 耗时 }                            │
│                                               │
│  切点四剑客：                                 │
│   execution(* pkg..*.*(..))                   │
│   @annotation(自定义注解)                     │
│   @within(类注解)                             │
│   A && B / A || B                             │
└───────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 Controller 全局耗时切面 + `@OperationLog` 注解切面，两份日志截图；
2. **必做**：在 IDE 里断点看 `pjp.getSignature()` 到底是什么类型（`MethodSignature`），学着从中拿 `Method` 对象；
3. **必做**：把 Day09 前 3 课时的 `POST /files/upload` 加 `@OperationLog("上传文件")`，联调看日志；
4. **挑战**：写一版 `@Around` 版的**幂等切面**——注解 `@Idempotent(key="#dto.phone", expire=5)`，5 秒内重复调抛业务异常（先 mock 一个内存 Map，Redis 版留到高阶课）。

### 5.6 教学反思提示
- 学生最常忘 `throw e`，做示范时**故意漏一次**并演示「Postman 拿到 200 但业务其实抛了异常」的诡异现象；
- 切点表达式建议先只讲 `execution` + `@annotation` + `@within` 三种，`this / target / args` 等 5 种参数绑定放到高阶课；
- 若课堂时间紧，AI 对照环节可以延到课后作业；本课时保住「学生能独立写出一版能跑的切面」是硬指标。

---

## 第 6 课时：`this.method` 陷阱 + 三种解法 + 观察代理对象 + Day09 收官

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能复现并解释「同一个 Service 里 `this.methodB()` 让 `@Transactional / @Around` 失效」的经典陷阱；
2. 能画出「外部 → Proxy → Target」的调用序列图，说明 `this` 为什么绕过了代理；
3. 能给出三种解法：`@Autowired @Lazy self`（自注入）、`AopContext.currentProxy()`（要开 `exposeProxy=true`）、**方法拆到另一个 Service**（推荐）；
4. 能通过 `applicationContext.getBean(...).getClass().getName()` 看到 `$$SpringCGLIB$$` 后缀，验证 Bean 被 AOP 增强；
5. 能列出「切面加了没生效」的 5 大排查点：注解齐全 / 切了 private / this 调用 / `@PostConstruct` 时机 / 切自己所在包栈溢出。

#### 6.1.2 过程与方法目标
1. 通过「亲手复现 bug 再亲手修」的闭环，训练**面对失效 AOP 时的排查路径**；
2. 通过 Day09 全局回顾，把「文件上传三课时」与「代理 / AOP 三课时」串成一条完整认知链，为 Day10 AOP 实战铺垫。

### 6.2 教学重难点
- **重点**：`this` 调用绕过代理的原理／三种解法优劣对比／`getBean().getClass().getName()` 验证代理对象
- **难点**：`@EnableAspectJAutoProxy(exposeProxy = true)` 与 `AopContext.currentProxy()` 的联动／`@PostConstruct` 阶段 AOP 尚未织入完成，切不到

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
反问：「如果我在 `OrderService.create()` 里加 `@Transactional`，同一类的 `updateStock()` 加 `@Transactional(propagation=REQUIRES_NEW)`，`create` 里通过 `this.updateStock()` 调用，事务传播真的会切成 REQUIRES_NEW 吗？」直接给答案：**不会**。然后现场跑代码打脸——事务确实是同一个。**这是面试高频、新手必栽**的坑，今天把它彻底讲透。

#### 新知讲授（15 分钟）

1. **复现 bug**（5 分钟）：
   - 新建 `OrderService`（在印想瑜伽项目里贴到 sandbox 包，别污染业务代码）；
   - `create()` 方法 + `@Transactional`，内部 `this.updateStock()`；`updateStock()` + `@Transactional(propagation=REQUIRES_NEW)`；
   - 在两个方法体里 `TransactionSynchronizationManager.getCurrentTransactionName()` 打日志；
   - 从 Controller 调 `create`，观察日志——两个方法的事务名**一模一样**，证明 `REQUIRES_NEW` 没触发。

2. **原理讲解**（5 分钟）：
   - Spring 容器里注入的是 `orderService$Proxy`——**外部调用**先进代理，代理执行 AOP（事务、日志、耗时）后再委托给真实对象；
   - 但一旦**进入了 `create` 方法体**，`this` 就是**真实对象**而非代理；
   - `this.updateStock()` 直接调真实对象的方法，**没经过代理**，AOP 全部落空；
   - 画序列图：外部 → Proxy → Target.create → **Target.updateStock（直连）** → return。

3. **三种解法**（5 分钟）：
   - **解法 1**：**自注入**——`@Autowired @Lazy private OrderService self`，`self.updateStock()` 走代理。`@Lazy` 是关键（避免循环依赖）。缺点：把「代理」这个实现细节暴露到业务代码；
   - **解法 2**：`AopContext.currentProxy()` 拿当前代理——**必须**在 `@EnableAspectJAutoProxy(exposeProxy = true)` 前提下。缺点：耦合 Spring AOP 内部 API；
   - **解法 3**：**方法拆到另一个 Service**——`OrderService` 依赖 `StockService`，跨类调用天然走代理。**推荐**，最干净，符合单一职责。

#### 示例演示（14 分钟）

1. **完成三种解法各一次**（8 分钟）：
   - 解法 1 现场敲，联调再跑一次 `create`，看日志——两个方法事务名不同了，`REQUIRES_NEW` 生效；
   - 解法 2 现场加 `exposeProxy=true`，再跑；顺带演示忘开 `exposeProxy` 时 `AopContext.currentProxy()` 抛 `IllegalStateException`；
   - 解法 3 现场把 `updateStock` 抽到 `StockService`，删掉 self，代码最清爽。

2. **观察代理对象**（3 分钟）：
   - `@Autowired ApplicationContext ctx`，`@PostConstruct` 打印 `ctx.getBean("orderService").getClass().getName()`；
   - 看到 `com.yinxiang.sandbox.OrderService$$SpringCGLIB$$0`；
   - 演示：给 `OrderService` **加上 `final`** → 项目启动直接抛错 `Cannot subclass final class`，因为 CGLIB 靠继承。

3. **「切面加了没生效」5 大排查点**（3 分钟）：黑板列一张速查表——
   - ① `@Aspect + @Component` 是否同时存在？
   - ② 目标方法是不是 `private / static / final`？
   - ③ 是不是 `this.method` 内部调用？（今日主课）
   - ④ 是不是 `@PostConstruct` 阶段？（代理装配未完成）
   - ⑤ 切点表达式是不是把自己所在包也切了？（栈溢出，Spring 有告警）。

#### 课堂练习（7 分钟）
1. 每位学生复现 `this` 陷阱一次，交两张日志截图（bug 现场 + 修复后）；
2. 追加实验：用三种解法各解决一次，各交一张日志截图；
3. 思考题：`self` 自注入用 `@Autowired @Lazy` 的原因是什么？直接 `@Autowired` 不加 `@Lazy` 会怎样？（`@Lazy` 避免 Bean 初始化阶段的**循环依赖**——自己引用自己）。

#### 小结（3 分钟）
一句话回顾：**外部 → Proxy → Target；`this` 绕过 Proxy 就绕过 AOP；三种解法首推「拆方法到另一个 Service」**。Day09 六课时打完收工——文件上传三课时接通了 URL 字段的最后一公里，代理与 AOP 三课时为 Day10 的操作日志 / 全局异常增强铺好了地基。

**Day09 交付验收**：
- `POST /files/upload` 本地版 + OSS 版 双通道；
- `TimingAspect` Controller 全局耗时切面；
- `OperationLogAspect` 注解式操作日志切面；
- `this` 陷阱三种解法各跑通一次。

**下集预告 Day10**：AOP 实战——把所有 Service 的**操作日志**统一落库（`tb_operation_log`），把**全局异常处理**增强成**「异常也走操作日志」**，把今天的两个切面从「日志打印」升级到「审计追踪」。

### 6.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day09-06 this 陷阱 + Day09 收官              │
├───────────────────────────────────────────────┤
│  外部 → Proxy → Target                        │
│  Target.this.method → 绕过 Proxy → AOP 失效   │
│                                               │
│  三种解法：                                   │
│   ① self 自注入 @Autowired @Lazy              │
│   ② AopContext.currentProxy()                 │
│       + @EnableAspectJAutoProxy(exposeProxy=  │
│         true)                                 │
│   ③ 拆到另一个 Service（推荐）                │
│                                               │
│  验证代理对象：                               │
│   ctx.getBean(name).getClass().getName()      │
│   → $$SpringCGLIB$$ 说明有代理                │
│                                               │
│  切面没生效 5 大排查：                        │
│   注解齐 / private / this / @PostConstruct /  │
│   自切自包                                    │
│                                               │
│  Day09 交付 4 件套：                          │
│   上传接口双通道 / 耗时切面 / 操作日志切面 /  │
│   this 陷阱三解法                             │
│                                               │
│  预告 Day10：AOP 实战 · 操作日志入库          │
└───────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：完成 `this` 陷阱复现 + 三种解法，共交 4 份 5 张日志截图；
2. **必做**：把 Day09 六课时的 4 件交付物整理到一张脑图（用 XMind / draw.io / 甚至手写），交图；
3. **必做**：Day09 复盘 500 字：踩过的坑（≥ 3 个）+ 收获（≥ 3 条）+ 明天想问老师的问题（≥ 1 个）；
4. **挑战**：给 `OrderService` 加乐观锁——`create` 里 `this.updateStock` 用 `where version=?`，`rows == 0` 时把 `this.retry()` 也走一遍（先复现失败，再用解法 3 修复）。

### 6.6 教学反思提示
- 本课时是 Day09 收尾，节奏适中，多留 5 分钟做「Day09 全景板书」——把 6 节课的关键 8 张板书快速过一遍；
- 学生若已疲劳，可以把「AopContext.currentProxy()」这条解法讲成「知道有这么个东西即可」，重点押在解法 1 和解法 3；
- 若时间还有余，可以拉一小段 Spring 事务传播行为的实际验证（`REQUIRES_NEW` 会不会真的开新事务），把「事务失效 = AOP 失效 = this 调用」这个链条打死。

---

## 附录 A：Day09 交付物一览

| 序号 | 分类 | 交付 | 关键点 |
|------|------|------|--------|
| 1 | 文件上传 | `POST /files/upload` 本地版 | 三层校验 + UUID + 日期分桶 |
| 2 | 文件上传 | `POST /files/upload` OSS 版 | RAM 子用户 + AK 环境变量 + `@ConditionalOnProperty` |
| 3 | 文件上传 | `WebConfig.addResourceHandlers` | `file:` 协议 + 末尾 `/` |
| 4 | 文件上传 | `UploadVO(url,size,ext)` | Java 25 record，前端契约稳定 |
| 5 | 代理 | 静态代理 Demo | `Proxy implements Subject` |
| 6 | 代理 | JDK 动态代理 Demo | `Proxy.newProxyInstance` + `InvocationHandler` |
| 7 | 代理 | CGLIB 代理 Demo | `Enhancer.setSuperclass` + `MethodInterceptor` |
| 8 | AOP | `TimingAspect` | `@Around` + `execution(..controller..)` |
| 9 | AOP | `OperationLogAspect` | `@Around` + `@annotation(OperationLog)` |
| 10 | AOP | `this` 陷阱三种解法 | 自注入 / AopContext / 拆 Service |

## 附录 B：Day09 核心口诀

- **上传三层校验**：非空 → 大小 → 白名单扩展名；
- **上传命名策略**：`yyyy/MM/dd/<UUID>.<ext>`，服务端自主命名；
- **OSS 三个绝不**：主账号 AK 不用、AK/SK 不硬编码、AK/SK 不进 Git；
- **代理三形态**：静态代理复制粘贴 → JDK 动态代理需要接口 → CGLIB 继承生成；
- **AOP 五要素**：Aspect / Pointcut / Advice / JoinPoint / Weaving；
- **Advice 顺口溜**：前后成异环——`@Before @After @AfterReturning @AfterThrowing @Around`；
- **`@Around` 骨架**：`try proceed → catch throw e → finally`；
- **切点四剑客**：`execution` / `@annotation` / `@within` / `A && B`；
- **切面没生效 5 大排查**：注解齐、非 private、非 this、非 @PostConstruct、不切自己所在包；
- **`this` 陷阱首选解法**：把方法拆到另一个 Service。

## 附录 C：Day09 常见问题速答

| 问题 | 回答 |
|------|------|
| 上传返回 200 但浏览器打开 URL 404 | `ResourceHandler` 结尾 `/` 漏了；或 `base-dir` 是相对路径 |
| Postman 上传字段名对不上 | 前端字段名默认 `file`，若改成别的要同步改 `@RequestPart("xxx")` |
| `MultipartFile.transferTo` 落到临时目录 | 必须传**绝对路径** `File`，相对路径会以 servlet 临时目录为基点 |
| 一次传 3 张 8MB 图被拒 | `max-request-size` 没同步调大，单文件不超限但总量超限 |
| OSS 上传成功但访问 URL 403 | Bucket 权限是「私有」，改「公共读」或用签名 URL |
| `OSS ossClient` 注入不进来 | 未加 `@ConditionalOnProperty` 或 `yinxiang.upload.oss.enabled=false` |
| `@Around` 里没写 `throw e` | 业务异常被吞、Postman 拿到 200，事故等级 P1 |
| `@Transactional` 传播行为不生效 | 十有八九是 `this.method` 内部调用，见 Day09-06 |
| `@Aspect` 加了但切面没跑 | 缺 `@Component`；或切了 `private` 方法；或切了 `@PostConstruct` 时刻 |
| 项目启动就抛 `Cannot subclass final class` | 目标类有 `final`，CGLIB 靠继承没法代理 |
| 切面把自己所在包也切了 | 栈溢出，切点表达式**排除自己** |
| `AopContext.currentProxy()` 抛异常 | 未开 `@EnableAspectJAutoProxy(exposeProxy = true)` |

---

**Day09 教师教案完**
