# 《AI 应用 Web 开发》 - 教师教案（Day13：会员管理前端页面 + AI 编写前端页面与布局）

**总课时：6 课时 × 45 分钟**
**授课对象：已完成 Day01–Day12 的学生（掌握 Spring Boot 4.0.x 后端全栈、Vue 3.4 + Vite + TypeScript 工程化、Pinia 状态管理、Axios 请求实例、Element Plus 3 组件库、Day12 已封装 `PageContainer / SearchBar / ProTable` 三大通用组件、`/utils/dict.ts` 字典与 `handleErr` 错误处理）**
**知识点覆盖：** 第 25 章 会员管理前端页面（Table 分页搜索 + Form 校验 + Dialog + Drawer + 删除与批量删除 + 冻结解冻 + 前后端校验分层）+ 第 26 章 AI 编写前端页面与布局（Prompt 六要素 + 四段式验收 + 迭代式微调 + AI 工具选型 + Dashboard 布局）

**技术版本基线**：Vue 3.4 / Vite 5.x / TypeScript 5.x / Element Plus 3 / Pinia 2 / Axios 1.7 / unplugin-auto-import / IDEA 2024.3+ / VS Code + 通义灵码 + Trae + Cursor。前端项目名 `yoga-admin`。

**Day13 主线**：Day12 我们已经把 `yoga-admin` 项目跑起来、路由与登录跑通、通用组件 `PageContainer / SearchBar / ProTable` 抽出并入库，今天要把它们**真正用到第一个业务模块**——「会员管理」的完整前端页面。前 3 个课时把「列表 + 弹窗 + 抽屉 + 删除」这一整套「后台管理页面标准范式」跑通：Table + 分页 + 多字段搜索 + Form 表单校验 + 二次确认删除 + 乐观更新 + 冻结解冻状态切换；中间 1 个课时切换赛道，从「手写」跳到「AI 生成」——用通义灵码 / Trae 一次性生成第二个业务模块（教练管理）的三件套，配套四段式验收把 AI 输出打磨到可入库；最后 2 个课时抬升视角看**布局层**——把顶栏 + 侧栏 Menu + 面包屑 + Tags View 这套后台通用外壳搭起来，并复盘「页面拆分」的取舍——什么时候抽子组件、什么时候用 Emit/Props、什么时候用 `defineExpose` 让父组件通过 ref 调子组件。Day13 结束后，`yoga-admin` 已经具备「一个完整业务模块 + 一份可复用的 AI 生成流程 + 一套完整后台外壳」——从下一天开始，任意新业务模块的前端交付可以从「1 天」压缩到「1 小时」。

---

## 第 1 课时：会员列表页 —— Table + 分页 + 搜索栏

### 1.1 教学目标

#### 1.1.1 知识与技能目标
1. 能画出「`MemberListView.vue` → `PageContainer` → `SearchBar` + `ProTable` → `memberApi.page` → 后端 `/members` 接口」的完整数据流；
2. 能使用 `<el-table-column>` 完成 8 列表头设计，并区分「`prop` 直取字段」与「`#default=\"{ row }\"` 插槽自定义渲染」两种模式；
3. 能定义 `MemberQuery` 类型，包含分页字段 `pageNum / pageSize`、业务字段 `name / phone / status`、时间范围 `joinBegin / joinEnd`；
4. 能理解为什么表格列的 `sortable` 要写成 `sortable=\"custom\"` —— 默认 `sortable` 会在**前端排序**，覆盖不了后端的分页字段；
5. 能通过 `ref` 拿到 `ProTable` 实例并调用 `resetToFirst() / refresh()` 两个方法，理解「查询按钮触发 resetToFirst 而非 refresh」的语义差异。

#### 1.1.2 过程与方法目标
1. 通过「手写完整列表页」的落地，把 Day12 抽象的三大组件（`PageContainer / SearchBar / ProTable`）从「概念」升级成「肌肉记忆」；
2. 通过对比「前端排序 vs 后端排序」两种做法，训练「组件默认能力 vs 业务实际需要」的取舍思维。

### 1.2 教学重难点
- **重点**：`<el-table>` 8 列表头的两种渲染模式（`prop` vs `#default` 插槽）／`SearchBar` 表单字段与 `q` 响应式对象的双向绑定／`ProTable` 的 `loader` + `query` props 契约／`selection-change` 事件收集勾选行
- **难点**：**日期范围 `joinRange` 是数组** 而 `q.joinBegin / q.joinEnd` 是两个字段——需要 `watch(joinRange, v => { q.joinBegin = v?.[0]; q.joinEnd = v?.[1] })` 做桥接／`sortable=\"custom\"` 与 `sortable` 的差异——前者派发 `sort-change` 事件给后端，后者悄悄在前端做 in-memory 排序

### 1.3 教学过程设计（45 分钟）

#### 导入（4 分钟）
接 Day12 结尾的项目现场：`yoga-admin` 侧边栏已经有「会员管理」入口，点进去只有一个 `<h2>会员管理</h2>`——空白页。反问：「一个成熟的会员列表页有几个元素？」引导学生数：顶部操作栏（新增 / 批量删除 / 导出）、搜索栏（姓名 / 手机号 / 状态 / 入会时段）、数据表（分页 / 多选 / 排序）、右侧操作列（编辑 / 详情 / 冻结 / 删除）、弹窗与抽屉。板书画出这 5 类元素的信息架构图。抛出今天的交付画像：**「6 类元素 + 3 类交互（Dialog / Drawer / MessageBox）」**。

#### 目标（2 分钟）
一句话：**「把 Day12 三大组件真正用到第一个业务模块，跑通会员管理列表页」**。今天第 1 课时只做列表页本身，弹窗放到第 2 课时、删除放到第 3 课时。

#### 重难点（2 分钟）
在黑板上标记两个红色符号：
- 🔴 `joinRange` 数组 → `q.joinBegin / q.joinEnd` 两字段的桥接
- 🔴 `sortable=\"custom\"` vs `sortable` —— 后端排序必须用 `custom`

#### 新知讲授（14 分钟）

1. **信息架构与交互选型**（4 分钟）：
   - 板书「后台管理页面 5 类元素」图；
   - 讨论**弹窗 vs 抽屉 vs 独立路由**的选型逻辑：字段少（< 10 个）且无联动 → Dialog；需要子列表 / 详情复杂 → Drawer；表单巨大 + 分步流程 → 独立路由页；
   - 破坏性操作（删除、冻结）→ `MessageBox.confirm` **二次确认**——工程规约。

2. **`MemberQuery` 类型与 `memberApi`**（4 分钟）：
   - 打开 `src/api/member.ts`，Day12 只有 `page` 一个方法，今天补齐 `detail / create / update / remove / freeze / unfreeze` 7 个方法；
   - 讲清 `PageResult<T>` 泛型的复用价值——`{ total, records }` 是全项目分页返回的标准结构；
   - 强调 **`request` 泛型第二参数**：`request.get<any, PageResult<MemberVO>>(...)` —— Axios 响应拦截器已经解包，所以第二个泛型就是最终业务数据类型；
   - 抽学生问：「为什么 `remove` 传的是 `number[]` 而不是单个 `number`？」（预期回答：**单删就是数组长度为 1 的批量删——统一 API 表达面**）。

3. **`MemberListView.vue` 骨架**（6 分钟）：
   - `<PageContainer title=\"会员管理\">` 外层：Day12 已提供 `#actions` 具名插槽承接顶部按钮组；
   - `<SearchBar :model=\"q\" @search=\"tableRef?.resetToFirst()\">`：`model` 是响应式 `q`，`@search` 事件由 `SearchBar` 内部「查询」按钮 emit；
   - `<ProTable ref=\"tableRef\" :loader=\"memberApi.page\" :query=\"q\">`：`loader` 是函数引用，`query` 是响应式 `q`；
   - `<el-table-column>` 的两种渲染：`prop=\"phone\"` 简单直取 vs `#default=\"{ row }\">{{ GENDER[row.gender] }}</template>` 通过字典映射；
   - 板书写下**列宽经验值**：姓名 90 / 手机号 130 / 性别 60 / 生日 110 / 状态 80 / 入会时间 160 / 操作 240。

#### 课堂活动（15 分钟）

1. **示例演示：跑通空列表 → 有数据 → 分页翻页**（8 分钟）：
   - 新建 `src/views/member/MemberListView.vue`，粘贴骨架代码；
   - 侧边栏菜单加路由 `{ path: '/members', component: () => import('@/views/member/MemberListView.vue') }`；
   - 前端 `pnpm dev` 启动，浏览器 `http://localhost:5173/members`；
   - 后端 `yoga-member` 项目起来，Day09-Day12 后端接口已就绪；
   - 首次进入：应显示表头 + 分页组件 + 「暂无数据」（因为库里还没会员）；
   - 用 Postman 或 Navicat 手动插 3 条会员，刷新页面 → 列表出现 3 行；
   - 修改 `pageSize = 2`，观察分页组件的「下一页」按钮变亮。

2. **让学生调 sortable**（4 分钟）：
   - 现场把「入会时间」列的 `sortable=\"custom\"` 改成 `sortable`（去掉 `\"custom\"`）；
   - 观察：点击列头，本页数据在前端排序，但翻到下一页排序丢失——因为**下一页数据是后端新拉的**；
   - 恢复 `sortable=\"custom\"`，同时给 `q` 加 `sortBy / sortDir` 字段，并在 `<ProTable>` 上监听 `@sort-change=\"onSort\"`；
   - 板书结论：**「后端分页 + 排序 = `sortable=\"custom\"` + `sort-change` 事件回传给 query」**。

3. **AI 生成对照**（3 分钟）：
   - 把「Vue 3 + Element Plus 会员列表页」需求丢给通义灵码；
   - 观察 AI 常见错误：① 表格用了 `<template slot-scope=\"scope\">`（Vue 2 语法）；② 分页字段名写成 `pageNo / limit`（不与后端一致）；③ 日期范围没做桥接直接把数组塞 `q.joinTime`——后端一看根本不认；
   - **AI 常犯错清单**记到黑板，后面第 4 课时会用这张清单做四段式验收。

#### 小结（3 分钟）
一句话回顾：**「`PageContainer + SearchBar + ProTable` 三件套 + `q` 响应式 = 后台列表页标准范式」**。今天列表壳已经跑起来，下节课把「新增 / 编辑弹窗」补上，让页面从「只读」升级到「可写」。

### 1.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-01 会员列表页 —— Table + 分页 + 搜索   │
├───────────────────────────────────────────────┤
│  信息架构 5 类元素：                          │
│   ① 顶部操作栏  ② 搜索栏  ③ 数据表           │
│   ④ 操作列     ⑤ 弹窗/抽屉                   │
│                                               │
│  交互选型：                                   │
│   Dialog  —— 字段少无联动                     │
│   Drawer  —— 需要子列表                       │
│   独立页  —— 表单巨大分步                     │
│                                               │
│  三大组件契约：                               │
│   PageContainer  #actions 插槽               │
│   SearchBar      model + @search              │
│   ProTable       loader + query + ref         │
│                                               │
│  🔴 joinRange (数组) → q.joinBegin/joinEnd    │
│  🔴 后端排序：sortable=\"custom\" + sort-change │
│                                               │
│  列宽经验：                                   │
│   姓名 90 / 手机 130 / 性别 60 / 状态 80      │
│   入会时间 160 / 操作 240                     │
└───────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：完成 `MemberListView.vue` 的骨架，实现「姓名 + 手机号 + 状态 + 入会时段」四字段搜索、分页翻页、按入会时间后端排序，交 4 张截图（空数据 / 有数据 / 分页翻页 / 排序切换）；
2. **必做**：补齐 `src/utils/dict.ts` 里的 `GENDER / MEMBER_STATUS` 字典，性别用 `{ 0: '保密', 1: '男', 2: '女' }`，状态用 `{ 1: { label: '正常', type: 'success' }, 2: { label: '冻结', type: 'warning' } }`；
3. **挑战**：给列表增加「快速搜索」输入框——`@vueuse/core` 的 `useDebounceFn`，300ms 防抖直接触发 `tableRef?.resetToFirst()`，不占用 `SearchBar` 的位置。

### 1.6 教学反思提示
- 学生最容易忘 `<el-table-column type=\"selection\">` 的 `width=\"42\"`——默认宽度不够会挤压后续列；
- 日期范围 `joinRange` 的 watch 桥接是**最常见的第一次踩坑点**——很多学生想「为什么后端收到的 `joinBegin` 一直是 `undefined`」；建议现场故意漏 `watch`，让学生自己发现问题；
- 后端如果 `/members` 接口分页字段名不是 `pageNum / pageSize`（有的老项目叫 `page / size`），务必提前对齐，否则连查询都发不出去。

---

## 第 2 课时：会员新增 / 修改页 —— Form + 校验 + Dialog

### 2.1 教学目标

#### 2.1.1 知识与技能目标
1. 能用 `<el-dialog>` + `<el-form>` + `FormRules` 三件套完成一个完整表单弹窗；
2. 能给 `MemberFormDialog` 组件用 `defineExpose({ open(id?) })` 暴露方法，让父组件通过 `ref` 调用；
3. 能理解 `open()` 里「先 reset 再赋值」的必要性——防止「打开一瞬看到上次的旧数据」；
4. 能写出 5 类字段的校验规则：必填 / 长度 / 正则（手机号 `/^1[3-9]\\d{9}$/`）/ change 触发 / blur 触发；
5. 能理解「编辑态手机号禁用」的业务规约——手机号是**身份**不允许改，如需改要走「换绑手机号」的另一个流程；
6. 能区分 `<el-dialog>` 的 `@close` 与 `@closed` 两个事件——前者是关闭前动画开始，后者是关闭动画结束，reset 数据只能用后者。

#### 2.1.2 过程与方法目标
1. 通过手写完整表单弹窗，让学生把「响应式对象 + FormRules + validate + emit」这条前端表单标准链路建立肌肉记忆；
2. 通过对比 `@close` 与 `@closed`，让学生亲眼看到「动画未结束就 reset」造成的视觉闪烁——理解为什么这两个事件必须分开设计。

### 2.2 教学重难点
- **重点**：`FormRules<T>` 泛型约束表单规则的字段名／`formRef.value?.validate()` 返回 Promise 需 `.catch(() => false)`／`Object.assign(form, r)` 而不是 `form = r`——响应式对象引用不能换／`defineExpose` 暴露 `open` 方法给父组件
- **难点**：编辑态时 `open(id)` 里的**并发**——`reset() → visible=true → await memberApi.detail(id) → Object.assign(form, r)`——中间用户如果快速点关闭，赋值会打在已关闭的表单上／`@closed` vs `@close` 的时序差异

### 2.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接第 1 课时的空列表页现场：学生点「新增会员」按钮，控制台报 `Cannot read properties of undefined (reading 'open')`——因为 `MemberFormDialog` 组件还没写。反问：「一个『新增 + 编辑』复用的弹窗，最少要几个 props / 事件？」引导学生思考：**「打开方法（`open(id?)`）+ 保存后通知（`emit('saved')`）」——只有这两个契约**。板书写下 API 契约：

```
父 --ref.open(id?)--> 子 (弹窗)
子 --emit('saved')--> 父 (刷新列表)
```

#### 目标（2 分钟）
一句话：**「一份 Dialog 组件同时支持『新增』与『编辑』，父组件只通过 `open(id?)` 一个 API 交互」**。

#### 重难点（3 分钟）
- 🔴 `open()` 里**先 reset 再赋值**——顺序颠倒就闪烁
- 🔴 `@closed`（关闭动画结束）而非 `@close`（关闭前）
- 🔴 `validate()` 必须 `.catch(() => false)`——不然 reject 的 promise 直接冒到 window `unhandledrejection`

#### 新知讲授（15 分钟）

1. **`FormRules<T>` 与 5 类字段规则**（5 分钟）：
   - 讲清 `FormRules<MemberFormDTO>` 泛型如何约束**规则的 key 必须是 T 的字段名**——写错字段名 TS 直接报错；
   - 5 类规则：`required`、`min/max`（长度）、`pattern`（正则）、`type: 'email' | 'number' | ...`（内置类型）、`validator`（自定义函数）；
   - `trigger` 两个取值：`'blur'`（离焦）用于文本输入、`'change'`（值变化）用于 select / radio / checkbox；
   - 板书写下手机号规则的完整形态：`{ pattern: /^1[3-9]\\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }`。

2. **`open(id?)` 的两段式赋值**（5 分钟）：
   - 现场敲 `open` 方法骨架：`reset() → visible.value = true → if (id) { isEdit=true; editId=id; await memberApi.detail(id); Object.assign(form, r) }`；
   - 强调**顺序**：**必须先 reset**——不然用户会看到「上一次编辑的姓名」在 detail 请求返回前**穿帮**；
   - 讲清 `Object.assign(form, r)` 而非 `form.value = r` 的原因——`form` 是 `reactive` 对象，**引用不能换**，只能改内容；
   - **异常兜底**：`await memberApi.detail(id)` 失败要 `toastErr(e); visible.value = false`——不能让用户看着一个「加载中」的空表单傻等。

3. **`@closed` vs `@close` 的时序**（3 分钟）：
   - 现场演示：把 `@closed=\"reset\"` 改成 `@close=\"reset\"`，点关闭按钮——**关闭动画中间用户能看到表单被清空**，一个视觉抖动；
   - 恢复 `@closed`：动画结束后才 reset，看不出任何异常；
   - **口诀**：**`@close` 是**关**门开始，`@closed` 是**关**门结束**——**过去时才是「完成」**。

4. **`defineExpose({ open })` 暴露给父**（2 分钟）：
   - `<script setup>` 默认**所有变量都是私有的**——父组件通过 ref 拿到实例也调不到 `open`；
   - `defineExpose({ open })` 显式白名单；
   - 父组件 `<MemberFormDialog ref=\"dialogRef\" @saved=\"tableRef?.refresh()\"/>` + `dialogRef.value?.open(row.id)`。

#### 课堂活动（15 分钟）

1. **示例演示：跑通新增流程**（6 分钟）：
   - 新建 `MemberFormDialog.vue`，粘贴模板与 script；
   - 父组件 `MemberListView.vue` 加 `<MemberFormDialog ref=\"dialogRef\" @saved=\"tableRef?.refresh()\"/>`；
   - `onAdd()` → `dialogRef.value?.open()`；
   - 点「新增会员」按钮 → 弹窗打开 → 字段全空 → 输入「张三 / 13800001111 / 男 / 月卡」→ 点保存 → 弹窗关 → 列表刷新出现新行；
   - 强调看**Network 面板**：POST `/members` body 是 `MemberFormDTO`，返回 200 + 新 id。

2. **示例演示：跑通编辑流程 + 手机号禁用**（5 分钟）：
   - 点列表某行的「编辑」→ `dialogRef.value?.open(row.id)`；
   - 弹窗出现，标题变「编辑会员」，字段从 `memberApi.detail(id)` 拉回填；
   - 手机号输入框呈**灰色禁用**——`:disabled=\"isEdit\"`；
   - 让学生改姓名 + 备注 → 保存 → 列表刷新看到新姓名；
   - 抽学生问：「编辑态的 `submit()` 走 update 还是 create？」（预期回答：`if (isEdit.value) update({ ...form, id: editId.value }) else create(form)`）。

3. **抽学生复现 `@close` 闪烁**（2 分钟）：
   - 让学生把 `@closed` 改成 `@close`；
   - 点关闭——观察表单在关闭动画的 300ms 里被清空的**视觉闪烁**；
   - 板书标注：**「关门时不清桌子，关完门才清」**。

4. **AI 生成对照**（2 分钟）：
   - 让 AI 生成 `MemberFormDialog.vue`；
   - 常见错误：① `<el-radio :label=\"1\">`（Element Plus 3.x 应用 `:value`）；② `@close=\"reset\"` 而非 `@closed`；③ `validate()` 没 catch；④ 编辑态没禁用手机号。

#### 小结（3 分钟）
一句话回顾：**「弹窗的 4 个契约：`open(id?)` / `emit('saved')` / `@closed` reset / `validate().catch(false)`」**。今天弹窗完成，下节课处理「删除 + 批量删除」并引入乐观更新。

### 2.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-02 Form + 校验 + Dialog                │
├───────────────────────────────────────────────┤
│  Dialog 组件契约：                            │
│   父 --ref.open(id?)--> 子                    │
│   子 --emit('saved')--> 父                    │
│                                               │
│  open(id?) 两段式：                           │
│   ① reset()          ← 顺序不能颠倒           │
│   ② visible = true                            │
│   ③ if(id) await detail → Object.assign(form) │
│                                               │
│  FormRules 5 类：                             │
│   required / min-max / pattern / type / validator│
│  trigger：blur（文本）/ change（选择）        │
│                                               │
│  🔴 编辑态手机号 :disabled=isEdit             │
│  🔴 @closed 而非 @close                       │
│  🔴 validate().catch(() => false)             │
│  🔴 form 用 Object.assign，不能重赋值         │
│                                               │
│  defineExpose({ open })                       │
│   —— <script setup> 私有默认，白名单暴露      │
└───────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：完成 `MemberFormDialog.vue`，包含 6 个字段（姓名、手机号、性别、生日、会员卡、备注），跑通新增 + 编辑两个场景，交 6 张截图（新增空验证 / 手机号格式错 / 新增成功 / 编辑加载 / 手机号禁用 / 保存成功）；
2. **必做**：给「生日」加 `disabled-date` 禁止选未来日期——`(d: Date) => d > new Date()`；
3. **挑战**：把「备注」的 `<el-input type=\"textarea\">` 加上 `show-word-limit` + `maxlength=\"200\"` 字数统计，观察为什么 `show-word-limit` 只在配了 `maxlength` 后才生效。

### 2.6 教学反思提示
- 学生最容易忘 `defineExpose({ open })`——父组件 `dialogRef.value?.open` 就是 `undefined`，报 `dialogRef.value?.open is not a function`；建议现场故意漏一次让学生排查；
- `Object.assign(form, r)` 中如果 `r` 的字段名和 `form` 不完全一致（如后端返回 `member_name` 而前端 `name`），会静默不生效——建议在 `open` 里手动映射每个字段而非 `Object.assign(form, r)` 一把梭；
- `<el-radio :value=\"1\">` 是 Element Plus 3.x 的新 API，AI 生成的代码经常混用 `:label=\"1\"` 的 2.x 语法——课堂上要明确指出「Element Plus 3.x 用 `:value`」。

---

## 第 3 课时：会员删除 + 批量删除 + 乐观更新

### 3.1 教学目标

#### 3.1.1 知识与技能目标
1. 能用 `ElMessageBox.confirm` 完成破坏性操作的二次确认，理解 `type: 'warning'` 与 `confirmButtonClass: 'el-button--danger'` 的视觉规约；
2. 能区分「单删」与「批量删」——统一为 `remove(ids: number[])` 一个后端 API，前端根据勾选状态决定 `ids` 数组长度；
3. 能实现「批量操作按钮」的启用逻辑——`selected` 数组为空时 `:disabled=\"!selected.length\"`；
4. 能理解「乐观更新（Optimistic UI）」的概念——先本地删除后调接口，接口失败时**回滚**；
5. 能实现「冻结 / 解冻」的状态切换——同一个按钮根据 `row.status` 变化显示不同文案与颜色。

#### 3.1.2 过程与方法目标
1. 通过「乐观更新 vs 悲观更新」两条路径的对照实验，让学生亲手感受**响应速度**的用户体验差异；
2. 通过「回滚补偿」的编码练习，训练「凡是异步操作都要考虑失败路径」的工程思维。

### 3.2 教学重难点
- **重点**：`ElMessageBox.confirm(...).then(...)`（或直接 await） 的两条路径处理／`selected` 数组通过 `@selection-change` 事件由 `ProTable` 收集／乐观更新的三步「① 备份原状态 ② 立即改本地 ③ 接口失败回滚」／`onToggleFreeze` 用同一个按钮切换两个 API
- **难点**：**`ElMessageBox.confirm` 点取消抛的是 rejection**——不 catch 会污染 console／乐观更新失败后的**回滚时机**——ElMessage.error 先弹再回滚 vs 先回滚再弹的用户体验差异

### 3.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接上节课的弹窗现场：学生现在能新增会员了，但页面上的「删除」按钮点了没反应。反问：「删除按钮直接调 `api.remove` 是否合适？」——大多学生答「要二次确认」。追问：「二次确认之外还要什么？」引出**乐观更新**——用户点删除后**立即看到行消失**，而不是等 500ms 后端返回。板书今天的三个能力：

```
① 单删 + 二次确认
② 批量删 + 未选禁用
③ 乐观更新 + 失败回滚
```

#### 目标（2 分钟）
一句话：**「破坏性操作都要二次确认；批量操作要考虑空选状态；异步操作都要有回滚补偿」**。

#### 重难点（3 分钟）
- 🔴 `ElMessageBox.confirm` 取消抛 rejection，必须 `.catch(() => {})`
- 🔴 乐观更新三步：**备份 → 立改 → 失败回滚**
- 🔴 `selected` 由 `@selection-change` 事件通过 `<el-table-column type=\"selection\">` 收集

#### 新知讲授（14 分钟）

1. **`ElMessageBox.confirm` 的两条路径**（4 分钟）：
   - 讲清返回值：**Promise**——点确认 resolve、点取消 reject；
   - 两种写法对比：`.then(() => {...}).catch(() => {})` vs `await ... catch (e) { if (e === 'cancel') return; ... }`；
   - 推荐**第一种**——`await` 后不 catch 直接抛 rejection 到 window `unhandledrejection`；
   - `confirmButtonClass: 'el-button--danger'` 让确认按钮**变红**——视觉规约：**破坏性操作红色**。

2. **`selected` 数组的收集**（3 分钟）：
   - `<el-table-column type=\"selection\" width=\"42\">`——第一列勾选框；
   - `@selection-change=\"v => selected = v\"`——`v` 是当前所有勾选的行对象数组；
   - 顶部「批量删除」按钮 `:disabled=\"!selected.length\"`——空选禁用；
   - 讲清**列宽 42**——默认宽度不够会挤压后续列。

3. **乐观更新的三步骨架**（5 分钟）：
   - 板书三步：**① 备份原列表 ② 立即从本地列表移除 ③ 调接口，失败则恢复备份**；
   - 现场敲代码：
     ```typescript
     const backup = [...tableRef.value?.rows]
     tableRef.value?.rows = tableRef.value?.rows.filter(r => r.id !== row.id)
     try { await memberApi.remove([row.id]) }
     catch (e) { tableRef.value?.rows = backup; toastErr(e) }
     ```
   - **但**：`ProTable` 的 `rows` 是内部状态，暴露给外部会破坏封装——**权衡**：中小型项目直接调 `refresh()` 就够了，大型项目才做乐观更新；
   - 今天的做法：**主流程用 `refresh()` 悲观更新**，把乐观更新作为**挑战作业**。

4. **`onToggleFreeze` 状态切换**（2 分钟）：
   - 同一个按钮，`row.status === 1` 时显示「冻结」（黄色），`row.status === 2` 时显示「解冻」（绿色）；
   - 内部根据 status 调 `memberApi.freeze(id)` 或 `unfreeze(id)`；
   - 二次确认文案也要动态：`` `确认${action}「${row.name}」？` ``。

#### 课堂活动（15 分钟）

1. **示例演示：单删 + 二次确认**（4 分钟）：
   - 补齐 `onDelete(row)` 方法，`await ElMessageBox.confirm(...)` → `await memberApi.remove([row.id])` → `ElMessage.success('删除成功')` → `tableRef.value?.refresh()`；
   - 点某行的「删除」→ 弹窗「确认删除会员『张三』？」→ 点取消 → 弹窗关闭，无任何变化；
   - 再点删除 → 点确认（红色）→ 弹「删除成功」绿色气泡，列表刷新，该行消失。

2. **示例演示：批量删除**（4 分钟）：
   - 顶部按钮 `@click=\"onBatchDelete\"`；
   - `onBatchDelete()` 里 `const ids = selected.value.map(m => m.id)`；
   - 空选时按钮灰色不可点——`:disabled=\"!selected.length\"`；
   - 勾 3 条 → 点批量删除 → 弹窗「即将删除 3 条记录，是否继续？」→ 确认 → 3 行消失；
   - 抽学生问：「删完后 `selected` 数组会自动清空吗？」（答：**不会**——`refresh()` 会重新拉数据，勾选状态本来就不再对应任何行，但 `selected` 值本身还在。工程上要在 `refresh()` 后手动 `selected.value = []`）。

3. **示例演示：冻结 / 解冻状态切换**（4 分钟）：
   - 补齐 `onToggleFreeze(row)` 方法；
   - 点某行「冻结」按钮 → 弹窗确认 → 该行状态 tag 变为黄色「冻结」，按钮文案变为「解冻」；
   - 再点「解冻」→ 弹窗 → 状态 tag 恢复绿色「正常」，按钮变回「冻结」；
   - 强调这里没做乐观更新——是**为了对照挑战作业**。

4. **AI 生成对照**（3 分钟）：
   - 让 AI 生成「批量删除 + 乐观更新」；
   - 常见错误：① 忘掉 `ElMessageBox` 取消场景，await 后直接调 API——用户点取消却真的删了；② 乐观更新回滚忘了同时清 `ElMessage.error`——用户看到「删除失败」但行还是没了；③ 二次确认文案硬编码「你确定吗？」——**不告诉用户具体要删什么**，UX 差。

#### 小结（3 分钟）
一句话回顾：**「破坏性操作 = 二次确认 + 具体文案；批量操作 = 未选禁用 + 数组统一 API；异步操作 = 失败回滚（可选）」**。今天会员管理的**完整 CRUD 闭环**已经跑通，下节课换赛道——让 AI 帮我们生成第二个业务模块。

### 3.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-03 删除 + 批量删除 + 乐观更新          │
├───────────────────────────────────────────────┤
│  ElMessageBox.confirm 两路径：                │
│   resolve → 执行破坏操作                      │
│   reject  → 用户取消，静默返回                │
│  确认按钮红：confirmButtonClass 'el-button--danger'│
│                                               │
│  批量操作三要素：                             │
│   ① <el-table-column type=\"selection\">       │
│   ② @selection-change 收集 selected           │
│   ③ :disabled=\"!selected.length\"              │
│                                               │
│  统一 API 表达：remove(ids: number[])         │
│   单删 = 长度 1 的批量                        │
│                                               │
│  乐观更新三步：                               │
│   ① 备份原状态                                │
│   ② 立即改本地                                │
│   ③ 接口失败回滚                              │
│                                               │
│  状态切换按钮：                               │
│   status===1 ? '冻结' : '解冻'                │
│   动态颜色 / 动态 API                         │
│                                               │
│  🔴 confirm 取消 = rejection，必须 catch      │
│  🔴 二次确认文案带具体对象名，不写「你确定吗」│
└───────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：完成 `onDelete / onBatchDelete / onToggleFreeze` 三个方法，跑通「单删 → 批量删 → 冻结 → 解冻」四个场景，交 4 张截图；
2. **必做**：把 `refresh()` 后手动 `selected.value = []`，避免残留勾选数据污染下次批量操作；
3. **挑战**：给单删实现**乐观更新 + 失败回滚**——需要在 `ProTable` 里加一个 `removeRow(id)` 方法暴露出来，删除失败调 `insertRow(row, index)` 恢复；写一个后端故意返回 500 的测试用例验证回滚。

### 3.6 教学反思提示
- 学生最容易漏 `ElMessageBox.confirm` 的 `.catch(() => {})`——控制台会跳出 `Uncaught (in promise) cancel`，看起来「像 Bug 又不影响功能」；
- 批量删除时如果后端接口是 `DELETE /members` body 传数组，Axios 默认 `DELETE` 不带 body——必须写 `request.delete(url, { data: ids })`，学生第一次踩这个坑会怀疑「后端没收到参数」；
- 冻结 / 解冻按钮的 `type` 动态绑定 `:type=\"row.status===1?'warning':'success'\"`——用 Vue 表达式 `link :type` 时经常写成大写字符串报错，建议现场演示报错信息。

---

## 第 4 课时：AI 编写前端页面流程 —— 提示词 → 生成 → 审查修改

### 4.1 教学目标

#### 4.1.1 知识与技能目标
1. 能理解「后台管理页面 = 通用模板 + 业务变化点」——为什么这类页面最适合 AI 生成；
2. 能写出「Prompt 六要素」的完整提示词：技术栈版本 / 目录约定 / 复用组件 / 业务字段与校验 / 交互细节 / 输出格式；
3. 能对 AI 输出走「四段式验收」：跑得起来 / 逻辑正确 / 边界完整 / 风格一致；
4. 能识别 AI 生成前端代码的 8 类典型错误（Element Plus 版本混淆、`@close` vs `@closed`、`disabled-date` 参数类型、`specialty: undefined` 初始化缺失等）；
5. 能进行「迭代式微调」——每轮只改 3 个点，不要重新描述已经对的部分；
6. 能对比通义灵码 / Trae / Cursor / Copilot 的适用场景，选择合适工具。

#### 4.1.2 过程与方法目标
1. 通过「一次性生成教练管理三件套」的真实工作流，让学生亲手感受**AI 生成 vs 手写**的效率差距（1 小时 vs 1 天）；
2. 通过「验收 + 反哺」的过程，训练学生**批判性接受 AI 输出**——AI 是脚手架，人是架构师。

### 4.2 教学重难点
- **重点**：Prompt 六要素的完整表达／四段式验收的 checklist（跑得起来、逻辑正确、边界完整、风格一致）／迭代式微调「每轮只改 3 个点」／AI 常犯错清单
- **难点**：**AI 幻觉的接口路径**——它猜的接口和你后端不一致（如 `/coach/list` vs `/coaches`）必须在 prompt 明确／**AI 忽略你的通用组件重造轮子**——必须在 prompt 强调「不要重写」

### 4.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接前三课的现场：学生刚刚花了 3 个课时（约 3 小时）手写完了会员管理页。反问：「现在项目还有教练管理 / 课程管理 / 教室管理 / 订单管理 / 会员卡管理 …… 至少 15 个模块，都手写要多久？」学生心里估算：**15 × 3 = 45 小时 ≈ 一周**。抛出今天的主题：**「让 AI 一次性生成教练管理，1 小时搞定」**——不是取代前面的手写，而是把手写沉淀的**知识**变成 AI 能吃的**提示词**。

#### 目标（2 分钟）
一句话：**「用 Prompt 六要素 + 四段式验收，把 AI 变成能持续产出可入库代码的初级前端」**。

#### 重难点（3 分钟）
- 🔴 Prompt 六要素缺一不可，特别是**技术栈版本**（Element Plus 2 vs 3 差异很大）
- 🔴 四段式验收——**边界完整**是学生最容易漏的一段
- 🔴 每轮只改 3 个点——AI 会因为「说得多」而**改坏已经对的地方**

#### 新知讲授（16 分钟）

1. **为什么后台管理页面适合 AI**（3 分钟）：
   - 后台管理页面 5 层结构：API 层 / 列表页 / 弹窗 / 路由 / 通用能力（字典、错误处理、样式）；
   - **变化点**：API 路径与字段、表格列、搜索字段、表单校验规则；
   - **不变部分**：`PageContainer / SearchBar / ProTable` 通用组件、`toastErr` 错误处理、`Object.assign(form, r)` 编辑态回填；
   - 结论：**80% 是模板，20% 是业务差异**——最适合 AI 生成；
   - AI 生成的**最佳边界**：一次生成 **API + 列表页 + 弹窗**三件套，路由和字典人工接。

2. **Prompt 六要素**（6 分钟）：
   - 板书 6 要素及其**缺失后果**：
     - **技术栈版本**：缺 → 生成过时 API（如 `<el-radio :label>`）
     - **目录约定**：缺 → 输出散乱、引入路径不对
     - **复用组件**：缺 → 从零重写，风格漂移
     - **业务字段 + 校验规则**：缺 → 字段错位或校验缺失
     - **交互细节**：缺 → 缺二次确认 / 缺关闭时机 reset
     - **输出格式**：缺 → 一坨代码难拆分
   - 现场敲完整提示词模板（约 60 行）；
   - 强调 `// FILE: 路径` 分隔——AI 一次输出多个文件时**必须**这么写。

3. **四段式验收**（4 分钟）：
   - **① 跑得起来**：复制 → `pnpm dev` → 无红字 → 页面渲染无报错；
   - **② 逻辑正确**：分页字段名与后端一致 / 编辑态手机号禁用 / update 带 id / 校验覆盖 required 字段；
   - **③ 边界完整**：空数据占位 / `toastErr` 包裹 / saving loading 状态 / `@closed` 而非 `@close` / MessageBox reject 吞掉；
   - **④ 风格一致**：列宽与会员管理页一致 / 按钮颜色统一 / 字典集中在 `dict.ts`；
   - 每段验收都有**改法**——「一句话补丁」丢回给 AI 再生成一次。

4. **迭代式微调**（3 分钟）：
   - 第一轮 = **完整提示词**，第二轮以后 = **补丁式指令**；
   - 补丁式指令模板：
     ```
     上一版有 3 个问题请修正：
     1. <el-radio :label=\"1\"> 换成 :value=\"1\"
     2. 手机号编辑态要 :disabled=isEdit
     3. specialty 默认值改为 []
     保持其余不变，重新输出这两个文件。
     ```
   - **关键**：**每轮只改 3 个点**——不重复描述已经对的部分，否则 AI 会**改坏已经对的地方**。

#### 课堂活动（15 分钟）

1. **示例演示：用完整 Prompt 一次性生成教练管理三件套**（8 分钟）：
   - 现场打开通义灵码 / Trae，粘贴完整提示词（60 行）；
   - AI 输出三个文件：`src/api/coach.ts`、`src/views/coach/CoachListView.vue`、`src/views/coach/CoachFormDialog.vue`；
   - 复制到项目相应位置；
   - 路由文件加 `{ path: '/coaches', component: () => import('@/views/coach/CoachListView.vue') }`；
   - `pnpm dev` → 打开 `/coaches` → 走**跑得起来**这段验收——大概率**红字 3~5 处**：`import` 路径大小写、`ElMessage` 未 import、`FormRules` 类型缺 import 等；
   - 现场把这 3 处一起丢回给 AI 做补丁修正；
   - 二次生成 → 复制 → 打开页面 → 页面渲染完成。

2. **示例演示：走完剩余 3 段验收**（4 分钟）：
   - **逻辑正确**：Postman 测试 POST /coaches，发现前端 `phone` 字段传的是 `mobile`（AI 混淆）——记下修正 1；
   - **边界完整**：故意在断网下点新增，弹窗直接白屏没错误提示——AI 忘了 `toastErr(e)`，记下修正 2；
   - **风格一致**：教练列表的「工号」列宽 120，会员管理里手机号是 130，团队规约都是 130——记下修正 3；
   - 三个补丁一起丢回 AI 修正。

3. **抽学生复现「AI 改坏已经对的地方」**（2 分钟）：
   - 让学生第三轮把**所有原始提示词**再念一遍给 AI，加上 3 个补丁；
   - AI 输出：`ProTable` 的 ref 类型被换成了另一种写法，`SearchBar` 里的 `@search` 变成了 `@click`——**改坏了**；
   - 板书画红色警告：**「补丁指令要精简，只说要改的点」**。

4. **建立团队 PROMPTS.md**（1 分钟）：
   - 布置作业：把这次成功的提示词沉淀到 `docs/PROMPTS.md`；
   - **每个新业务模块**都可以复用这份模板，**只改**接口清单和字段。

#### 小结（3 分钟）
一句话回顾：**「Prompt 六要素 + 四段式验收 + 迭代 3 点 = AI 变成合格的初级前端」**。今天教练管理页跑通，接下来两个课时抬升视角看**布局层**——顶栏 + 侧栏 + 面包屑这套外壳。

### 4.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-04 AI 编写前端页面流程                 │
├───────────────────────────────────────────────┤
│  为什么后台页适合 AI：                        │
│   80% 模板 + 20% 业务差异                     │
│   最佳边界：一次生成 API + 列表 + 弹窗        │
│                                               │
│  Prompt 六要素：                              │
│   ① 技术栈版本  ② 目录约定  ③ 复用组件       │
│   ④ 业务字段+校验  ⑤ 交互细节  ⑥ 输出格式    │
│                                               │
│  四段式验收：                                 │
│   ① 跑得起来  Compile & Render                │
│   ② 逻辑正确  Business Correctness            │
│   ③ 边界完整  Corner Cases                    │
│   ④ 风格一致  Consistency                     │
│                                               │
│  迭代式微调：                                 │
│   每轮只改 3 个点                             │
│   补丁式指令，不重念原提示                    │
│                                               │
│  AI 8 大常犯错：                              │
│   :label vs :value / @close vs @closed        │
│   disabled-date 参数 / specialty 未初始化     │
│   接口路径幻觉 / 重造通用组件                 │
│   过度包装 composable / 版本混淆              │
│                                               │
│  工具选型：                                   │
│   通义灵码 / Trae   项目上下文，实战主战场    │
│   ChatGPT / Claude  学习 + Prompt 打磨        │
│   Copilot          行内补全                   │
│   v0.dev           Landing / 营销页           │
└───────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：用本课时的提示词模板，让 AI 一次性生成「教室管理」的 API + 列表页 + 弹窗——字段 `roomNo / name / capacity / location / equipments[] / status`；走完四段式验收；交完整代码 + 验收记录（4 段各发现多少问题）；
2. **必做**：把本次成功的提示词沉淀到 `docs/PROMPTS.md`，加上「本团队约定」段——通用组件路径、字典约定、错误处理规则；
3. **挑战**：让 AI 生成 Dashboard 首页（4 个数字卡片 + 2 个 ECharts 图表 + 1 个操作日志 ProTable），走完验收，特别关注**ECharts 的 dispose 逻辑**——组件卸载时是否释放实例。

### 4.6 教学反思提示
- 学生第一次用 AI 生成时最容易出现的问题不是「AI 错了」而是「学生没意识 AI 错了」——四段式验收要**手把手做一遍**，特别是「边界完整」这段最容易被跳过；
- 「AI 常犯错清单」建议做成教室墙上的一张实体海报，每次课后有新发现就补一行——学生会因为「亲手验证过」而记得更牢；
- 一定要明确「**AI 是脚手架，人是架构师**」——**你必须能逐行看懂 AI 生成的每一行**，出问题时半夜爬起来修的是你，不是 AI。

---

## 第 5 课时：后台通用布局 —— 顶栏 + 侧栏 Menu + 面包屑

### 5.1 教学目标

#### 5.1.1 知识与技能目标
1. 能画出「`Layout.vue` → `Header + Sidebar + Main` → `<router-view>` 挂载具体业务页」的整体外壳结构；
2. 能用 `<el-container> / <el-header> / <el-aside> / <el-main>` 完成三栏经典布局；
3. 能用 `<el-menu>` 递归渲染多级菜单，理解 `router` 属性开启路由模式、`default-active` 与当前路由的联动；
4. 能实现「侧边栏折叠」——`<el-menu :collapse=\"isCollapse\">` + 一个折叠按钮切换 `isCollapse.value`；
5. 能实现「面包屑」——从 `route.matched` 动态生成 `<el-breadcrumb>` 每一级；
6. 能理解「路由 meta」的用途——`meta: { title, icon, hidden }` 承接菜单显示元数据。

#### 5.1.2 过程与方法目标
1. 通过手写完整布局层，让学生把「路由结构 + 菜单结构 + 面包屑」这三个原本分散的概念**统一在一个数据源**（`route.matched`）；
2. 通过对比「静态菜单 vs 动态菜单」，理解为什么中大型系统菜单要从**路由 meta 派生**——单一数据源原则。

### 5.2 教学重难点
- **重点**：`<el-container>` 三栏结构与 CSS flex 落地／`<el-menu>` 的 `router` + `default-active` + `unique-opened` 三属性／`<el-breadcrumb>` 从 `route.matched` 派生／路由 `meta: { title, icon }` 作为**菜单显示的单一数据源**
- **难点**：**`default-active` 与 `route.path` 的同步**——路由变化后菜单高亮要跟着变／**面包屑跳过根路由**——`route.matched.filter(r => r.meta?.title)` 而不是全量渲染／**折叠状态**要持久化到 localStorage，否则每次刷新都展开

### 5.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接第 4 课时的现场：教练管理已用 AI 生成完成——但页面**外壳**还是 Day12 简易版：顶部一行 logo、左侧一个 `<router-link>` 列表、没有面包屑、没有折叠。反问：「一个真实的后台管理系统外壳有哪些标准元素？」引导学生列出：顶栏（logo + 面包屑 + 用户菜单）、侧栏（多级菜单 + 折叠）、内容区（`<router-view>`）、Tags View（选修）。板书今天的交付：**「4 个组件 —— Layout / Header / Sidebar / Breadcrumb」**。

#### 目标（2 分钟）
一句话：**「用 4 个组件搭出后台通用外壳，让所有业务页面共享导航体验」**。

#### 重难点（3 分钟）
- 🔴 菜单 `default-active` 要监听 `route.path` 变化联动
- 🔴 面包屑跳过没有 title 的路由层级
- 🔴 折叠状态持久化到 localStorage

#### 新知讲授（16 分钟）

1. **`<el-container>` 三栏经典布局**（4 分钟）：
   - 板书结构：
     ```
     <el-container>              vertical flex
       <el-header>               top bar 60px
       <el-container>            horizontal flex
         <el-aside>              sidebar 210px (or 64px collapsed)
         <el-main>               content area
     ```
   - 强调 `<el-container>` 的**方向自适应**——直接子有 `<el-header>` 或 `<el-footer>` 时纵向，否则横向；
   - CSS 要点：`height: 100vh`；`<el-aside>` 需 `transition: width 0.3s` 让折叠有动画。

2. **`<el-menu>` 三属性**（4 分钟）：
   - `router` —— 开启路由模式，`<el-menu-item index=\"/members\">` 点击会 `router.push('/members')`；
   - `default-active` —— 当前高亮项，绑定 `route.path`；
   - `unique-opened` —— 同一层级只能展开一个子菜单；
   - `collapse` —— 折叠模式，`<el-menu-item>` 只显图标，文字变悬浮 popover；
   - **递归组件**：多级菜单需要写一个 `MenuItem.vue` 组件递归自身——先讲两级够用，深层递归作为挑战作业。

3. **路由 meta 作为菜单单一数据源**（4 分钟）：
   - 传统写法：路由和菜单**各写一份**——路由改字段名菜单要跟着改，两处失同步；
   - 单一数据源：**菜单从路由派生**——
     ```typescript
     const routes = [
       { path: '/members', component: MemberListView,
         meta: { title: '会员管理', icon: 'User' } }
     ]
     ```
   - `<Sidebar>` 里读 `router.options.routes` 过滤 `meta.title` 存在的，渲染菜单；
   - 增加 `meta.hidden = true` 让某些路由**不出现在菜单**（如登录页、404）。

4. **面包屑 `<el-breadcrumb>` 从 `route.matched` 派生**（4 分钟）：
   - `useRoute().matched` 返回**当前路由的所有父级链**——`[{ path: '/', meta: {} }, { path: '/members', meta: { title: '会员管理' }}]`；
   - 过滤：`matched.filter(r => r.meta?.title)`——跳过没有 title 的顶层布局路由；
   - 渲染：最后一层灰色不可点，前面几层是链接；
   - 首页固定一个「首页 → ...」头元素，工程习惯。

#### 课堂活动（15 分钟）

1. **示例演示：搭出 Layout 骨架**（5 分钟）：
   - 新建 `src/layout/Layout.vue` + `Header.vue` + `Sidebar.vue` + `Breadcrumb.vue` 四个文件；
   - 路由改成嵌套结构：
     ```typescript
     { path: '/', component: Layout, children: [
       { path: 'members', component: MemberListView, meta: { title: '会员管理' } },
       { path: 'coaches', component: CoachListView, meta: { title: '教练管理' } },
     ]}
     ```
   - 启动 → 浏览器 → 页面出现三栏结构 + 空面包屑 + 空菜单——但架子对了。

2. **示例演示：Sidebar 菜单联动**（5 分钟）：
   - `<Sidebar>` 读 `router.options.routes` 递归渲染两级；
   - `default-active` 绑 `route.path`；
   - 打开 `/members` → 侧边菜单「会员管理」高亮蓝色；
   - 手动改地址栏为 `/coaches` → 「教练管理」高亮，「会员管理」褪色；
   - 折叠按钮：`<el-icon @click=\"isCollapse = !isCollapse\">Fold/Expand</el-icon>`；
   - 折叠后菜单变 64px 宽，文字变悬浮 popover。

3. **示例演示：面包屑动态渲染**（4 分钟）：
   - `<Breadcrumb>` 用 `<script setup>` + `useRoute()` + `computed`；
   - 计算 `crumbs = route.matched.filter(r => r.meta?.title)`；
   - 模板 `<el-breadcrumb-item v-for=\"c in crumbs\">{{ c.meta.title }}</el-breadcrumb-item>`；
   - 首页固定一个 `<el-breadcrumb-item :to=\"{ path: '/' }\">首页</el-breadcrumb-item>`；
   - 切换菜单 → 面包屑跟着变。

4. **抽学生实现「折叠状态持久化」**（1 分钟）：
   - 提示：`useStorage` from `@vueuse/core`——`const isCollapse = useStorage('sidebar-collapse', false)`；
   - 一行代码把 `ref` 换成 `useStorage`，刷新页面折叠状态保留。

#### 小结（3 分钟）
一句话回顾：**「路由 + 菜单 + 面包屑 = 一个数据源三种视图（`meta.title`）」**。今天外壳搭完，下节课复盘「组件拆分」——什么时候抽子组件、什么时候用 Emit/Props。

### 5.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-05 后台通用布局                        │
├───────────────────────────────────────────────┤
│  <el-container> 三栏：                        │
│   <el-header>   60px                          │
│   <el-aside>    210px / 64px                  │
│   <el-main>     <router-view/>                │
│                                               │
│  <el-menu> 三属性：                           │
│   router + default-active + unique-opened     │
│   collapse ← isCollapse                       │
│                                               │
│  路由 meta 单一数据源：                       │
│   { title, icon, hidden }                     │
│   Sidebar 从 router.options.routes 派生       │
│   Breadcrumb 从 route.matched 派生            │
│                                               │
│  🔴 default-active 绑 route.path 自动联动     │
│  🔴 面包屑 filter(r => r.meta?.title)         │
│  🔴 isCollapse 用 useStorage 持久化           │
│                                               │
│  组件文件：                                   │
│   layout/                                     │
│     Layout.vue      —— 三栏骨架               │
│     Header.vue      —— logo + breadcrumb + 用户│
│     Sidebar.vue     —— 递归 el-menu           │
│     Breadcrumb.vue  —— matched → items        │
└───────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：完成 4 个布局组件，跑通「会员管理 / 教练管理」的完整外壳（顶栏 + 侧栏 + 面包屑），刷新保留折叠状态，交 4 张截图（展开态 / 折叠态 / 面包屑深两层 / 首页）；
2. **必做**：给路由 meta 加 `hidden` 字段，把「登录页」`/login` 从菜单中隐藏；
3. **挑战**：实现 Tags View——顶栏下方一排 tab，每个 tab 对应一个「打开过的路由」，可关闭；用 Pinia 存 `openedTags` 数组，`router.afterEach` 里 push 新 tag。

### 5.6 教学反思提示
- 学生最容易忘 `default-active` 绑 `route.path`——菜单高亮不联动，看着「像 Bug 但页面能用」；
- `<el-aside>` 折叠动画卡顿的常见原因：没写 `transition: width 0.3s`——CSS 单加一行搞定；
- Sidebar 递归组件是学生第一次接触**组件自引用**，很多人会写死 `<MenuItem>` 而 export 名字用了 `default` 而不是显式命名——建议直接给出 `defineOptions({ name: 'MenuItem' })` 模板。

---

## 第 6 课时：页面拆分与子组件抽取 —— Emit / Props / defineExpose

### 6.1 教学目标

#### 6.1.1 知识与技能目标
1. 能识别「什么时候该抽子组件」——超过 3 个信号：模板超过 200 行、内部有独立业务逻辑、可能被多处复用；
2. 能用 `defineProps<T>() + withDefaults` 完成子组件属性契约；
3. 能用 `defineEmits<T>()` 定义强类型事件契约；
4. 能理解三种父子交互模式的选型：**Props 单向** / **Emit 事件** / **`defineExpose` 命令式调用**；
5. 能理解「双向绑定 `v-model` 底层就是 Props + Emit」——`v-model:visible` = `:visible` + `@update:visible`；
6. 能重构 `MemberListView.vue`——把顶部操作栏抽成 `MemberToolbar.vue`，把表格列定义抽成 `MemberColumns.vue`（列配置对象）。

#### 6.1.2 过程与方法目标
1. 通过「先写在一起 → 再拆分」的重构过程，让学生体会**过早抽象**的成本——**先让它跑起来，再让它优雅**；
2. 通过对比三种父子交互模式，训练「用最少信息完成契约」的接口设计思维。

### 6.2 教学重难点
- **重点**：`defineProps<T>() + withDefaults(defineProps<T>(), { ... })` 类型 + 默认值语法／`defineEmits<{ (e: 'saved'): void; (e: 'delete', id: number): void }>()` 元组类型语法／三种交互模式的选型
- **难点**：**双向绑定的语法糖**——`v-model:visible=\"visible\"` 等价于 `:visible=\"visible\" @update:visible=\"v => visible = v\"`，很多学生只会用不理解／**`defineExpose` 的使用时机**——只在「命令式调用」不可避免时使用，能用 props/emit 就不用 ref

### 6.3 教学过程设计（45 分钟）

#### 导入（3 分钟）
接第 5 课时的现场：`MemberListView.vue` 现在已经 300+ 行——模板 + script + 导入 + 类型定义。反问：「这个文件哪一段最独立、可以拆出去？」引导学生识别：① 顶部按钮组（新增 / 批量删 / 导出）→ `MemberToolbar`；② 表格列定义 → 可以抽成配置对象；③ 弹窗、抽屉本来就是独立文件。板书拆分方案：**「1 个主页 + 3 个子组件 + 1 个列配置」**。

#### 目标（2 分钟）
一句话：**「用 Props / Emit / defineExpose 三种契约，把大页面拆成小组件；让每个文件的职责单一」**。

#### 重难点（3 分钟）
- 🔴 三种交互模式的**选型**：Props 单向数据、Emit 事件通知、defineExpose 命令式方法
- 🔴 `v-model` 是语法糖——`v-model:visible` = `:visible + @update:visible`
- 🔴 **不要过早抽象**——先跑起来再重构

#### 新知讲授（16 分钟）

1. **什么时候抽子组件**（4 分钟）：
   - 板书三个信号：
     - **信号 1**：模板超过 200 行 → 阅读困难 → 抽
     - **信号 2**：内部有独立业务逻辑（弹窗自己管 visible/form/rules） → 抽
     - **信号 3**：可能被多处复用（Dialog、Drawer 是天然的复用者） → 抽
   - **反例**：一个只有 5 行的按钮组抽成组件 → **过度抽象**，反而变复杂；
   - **原则**：**Rule of Three**——同一段代码写第 3 次时才抽——前两次先复制粘贴。

2. **`defineProps<T>()` + `withDefaults`**（4 分钟）：
   - 类型式 props：`defineProps<{ modelValue: boolean; title?: string }>()`；
   - 默认值：`withDefaults(defineProps<...>(), { title: '默认标题' })`；
   - **必填 vs 可选** 由 `?` 决定；
   - **只读**：props 是**单向数据流**——子组件不能改 props（改了 dev 环境会报 Warning）。

3. **`defineEmits<T>()` 元组语法**（4 分钟）：
   - 三种写法对比：
     ```typescript
     // 简单数组（无类型约束）
     defineEmits(['saved', 'delete'])
     // 类型式（推荐）
     defineEmits<{ (e: 'saved'): void; (e: 'delete', id: number): void }>()
     // 3.4+ 更简洁写法
     defineEmits<{ saved: []; delete: [id: number] }>()
     ```
   - 强类型约束让编译期就能发现「emit 事件名拼错」「参数类型不对」；
   - `emit('saved')` 无参数，`emit('delete', row.id)` 带参数。

4. **`v-model` 的语法糖本质**（2 分钟）：
   - `<Dialog v-model=\"visible\">` = `<Dialog :model-value=\"visible\" @update:model-value=\"v => visible = v\">`；
   - `v-model:foo=\"bar\"` = `:foo=\"bar\" @update:foo=\"v => bar = v\"`；
   - **多个 v-model**：一个组件可以同时 `v-model:visible` + `v-model:tabName`——本质是两组 Props+Emit；
   - Element Plus 的 Dialog / Drawer / Table 都用这个模式。

5. **`defineExpose` 的使用时机**（2 分钟）：
   - **首选 Props/Emit**——数据流单向、事件流单向；
   - `defineExpose` 只用于「**父不得不命令式调用子**」的场景：Dialog 的 `open(id?)` 是典型——**父不给 props 只发命令**；
   - 反例：用 `defineExpose` 暴露内部数据给父读——**破坏封装**，应改用 emit 或 v-model。

#### 课堂活动（15 分钟）

1. **示例演示：抽 `MemberToolbar.vue`**（5 分钟）：
   - 新建 `src/views/member/MemberToolbar.vue`；
   - Props：`disabledBatch: boolean`（勾选为空时禁用）；
   - Emits：`{ add: []; batchDelete: []; export: [] }`；
   - 模板：3 个按钮 + 图标；
   - 父组件 `MemberListView.vue` 改用 `<MemberToolbar :disabled-batch=\"!selected.length\" @add=\"onAdd\" @batch-delete=\"onBatchDelete\" @export=\"onExport\"/>`；
   - 主页从 300 行降到 260 行——**局部可读性显著提升**。

2. **示例演示：抽列配置对象**（4 分钟）：
   - 新建 `src/views/member/memberColumns.ts` 导出 `MEMBER_COLUMNS` 数组；
   - 每一项：`{ prop, label, width, formatter?, slot? }`；
   - 主页 `<ProTable :columns=\"MEMBER_COLUMNS\">` 或 `v-for` 渲染 `<el-table-column>`；
   - 列配置从**声明式模板**变成**数据驱动**——后续加隐藏列、拖动列宽等能力更容易。

3. **示例演示：`v-model:visible` 与 `defineExpose` 对比**（4 分钟）：
   - 演示 `MemberFormDialog.vue` 两种控制方式：
     - 方式 A：`v-model:visible` + Props `editId?: number` —— 父组件掌控**所有状态**；
     - 方式 B：`defineExpose({ open(id?) })` —— 子组件自己管 state；
   - 讨论：**新增+编辑复用**且**弹窗关闭后完全 destroy**时——方式 B 更简洁；**Drawer 侧边常驻**或**需要外部读弹窗状态**时——方式 A 更好；
   - 项目里两种都有用，**看场景**——不要僵化。

4. **抽学生复现「过度抽象反例」**（2 分钟）：
   - 让学生把一个只有 3 行的「新增按钮」抽成 `AddButton.vue` 组件；
   - 观察抽完后主页 import 多了 1 行、子组件文件 20 行、还得写 Props/Emit——比原来更繁；
   - **口诀**：**Rule of Three——写第 3 次时才抽**。

#### 小结（3 分钟）
一句话回顾：**「Props 单向数据 / Emit 事件通知 / defineExpose 命令式调用——三种模式各司其职，不要滥用 ref」**。今天 Day13 结束——`yoga-admin` 拥有「一个完整业务模块 + AI 生成流程 + 通用布局 + 组件拆分心法」，Day14 开始接入课程与预约管理。

### 6.4 板书设计
```
┌───────────────────────────────────────────────┐
│  Day13-06 页面拆分与子组件抽取                │
├───────────────────────────────────────────────┤
│  什么时候抽子组件（3 信号）：                 │
│   ① 模板 > 200 行                             │
│   ② 有独立业务逻辑                            │
│   ③ 可能被多处复用                            │
│  → Rule of Three：第 3 次才抽                 │
│                                               │
│  三种父子交互契约：                           │
│   Props        父 → 子   数据单向             │
│   Emit         子 → 父   事件通知             │
│   defineExpose 父 → 子   命令式调用           │
│                                               │
│  语法：                                       │
│   defineProps<{ modelValue: boolean }>()      │
│   withDefaults(defineProps<T>(), {...})       │
│   defineEmits<{ saved: []; delete: [id:number] }>()│
│                                               │
│  v-model 是语法糖：                           │
│   v-model:foo = :foo + @update:foo            │
│   多个 v-model 完全 OK                        │
│                                               │
│  🔴 defineExpose 只用于「必须命令式」的场景   │
│  🔴 Props 单向：子不能改 props                │
│  🔴 不要过早抽象——先跑起来再优雅              │
└───────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：把 `MemberListView.vue` 拆成 `MemberToolbar / MemberSearch / MemberColumns / MemberFormDialog / MemberDetailDrawer` 5 个组件 / 配置，主页保留在 150 行以内；交拆分前后的 wc -l 对比截图；
2. **必做**：给 `MemberFormDialog` 增加**双向绑定版本**——`v-model:visible` + Props `editId?: number` —— 与 `defineExpose({ open })` 版本共存，写一个对比 README；
3. **挑战**：把「教练管理」也做同样的组件拆分，观察是否有可以进一步**上移到通用层**的组件（如 `BaseToolbar` 抽出「新增 + 批量删除 + 导出」三段式）。

### 6.6 教学反思提示
- 学生最容易在**过度抽象**上翻车——今天一定要现场演示「抽了个 3 行按钮」的反例，让学生记住 Rule of Three；
- `defineEmits<{ saved: []; delete: [id: number] }>()` 这种「简化元组语法」是 Vue 3.4 新增的，老版本要用 `(e: 'saved'): void` 老写法——版本一定要对齐；
- `v-model` 语法糖学生理解慢——建议现场把 `v-model:visible` 手动展开成 `:visible + @update:visible`，让学生**亲眼看到**它就是两行代码的合并；
- Day13 结束时一定要复盘：**「从 Day10 的后端 AOP + 缓存 + 事务，到 Day13 的前端完整业务模块 + AI 生成 + 布局」——前后端已经全线打通**，学生应能独立完成一个业务模块的**全栈交付**。

---

## Day13 全日总结

**知识产出**：
- 会员管理前端完整闭环（列表 + 弹窗 + 抽屉 + 删除 + 冻结）
- AI 编写前端页面的 Prompt 六要素 + 四段式验收方法论
- 后台通用布局四组件（Layout / Header / Sidebar / Breadcrumb）
- 组件拆分三大契约（Props / Emit / defineExpose）与选型经验

**代码产出**：
- `src/api/member.ts` 补齐 7 个方法
- `src/views/member/*` 完整 5 文件
- `src/api/coach.ts` + `src/views/coach/*` AI 生成三件套
- `src/layout/*` 布局四组件
- `docs/PROMPTS.md` 团队提示词模板

**能力沉淀**：
- 手写业务模块用时从「1 天」压缩到「3 小时」
- AI 生成业务模块用时从「1 天」压缩到「1 小时」
- 后台外壳一次搭建全项目复用

**下一日预告**：Day14 接入课程管理 + 排课日历，使用第 5 讲的 AI 流程一次性生成三件套，深化「AI 是脚手架，人是架构师」的工程哲学。
