# 《AI 应用 Web 开发》 - 教师教案（Day02：JavaScript/jQuery + AI 编写前端）

**总课时：6 课时 × 45 分钟**
**授课对象：Web 开发初学者（大一/大二本科生，已完成 Day01 HTML+CSS 学习）**
**知识点覆盖：** 第 3 章 JavaScript 与 jQuery 基础 + 第 4 章 AI 辅助编写前端界面实战
**贯穿案例：** 《印想瑜伽会馆客户管理系统》前端界面（会员登录、课程列表、会员管理表格）
**版本基线：** Node.js 20 / Vue 3.5+（预告）/ jQuery 3.7.1 / 通义灵码 + Trae

---

## 第 1 课时：JavaScript 引入方式 + 变量与数据类型

### 1.1 教学目标
#### 1.1.1 知识与技能目标
1. 说出 JavaScript 三种引入方式（行内 / 内部 / 外部）及各自适用场景；
2. 理解 `defer` 与 `async` 的区别，能说出\"项目中一般用 `defer`\"的原因；
3. 区分 `let`、`const`、`var` 的差异，并能背出\"能用 `const` 就用 `const`\"口诀；
4. 列举 JavaScript 的 7 种原始类型与 3 种引用类型；
5. 说出 `==` 与 `===` 的差别，理解 `typeof null === 'object'` 是历史遗留 bug。

#### 1.1.2 过程与方法目标
1. 通过\"三种引入方式对比演示\"，让学生亲眼看到\"外部脚本 + defer\"是工业级做法；
2. 通过 DevTools Console 现场跑 `typeof` 表达式，把抽象的数据类型概念直接落到浏览器中；
3. 通过\"改一行代码 → 页面立即变化\"的即时反馈，建立 JavaScript 学习的正向循环。

### 1.2 教学重难点
- **重点**：`<script defer>` / `let` vs `const` / `===` 严格相等 / 6 种类型的 `typeof` 结果
- **难点**：`var` 的变量提升与作用域坑（不深讲，只强调\"不要用\"）／`typeof null === 'object'` 反直觉

### 1.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
向学生提问：\"**Day01 我们写的 HTML 页面，用户点击按钮为什么什么都不会发生？**\"随机抽 2 位同学回答。引出 JavaScript 的定位——**浏览器唯一\"会说\"的编程语言，负责让页面\"动起来\"**。口播强调：HTML 是骨架、CSS 是皮肤、JavaScript 是灵魂。板书写下这句话。

#### 新知讲授（16 分钟）
按三小节推进：

1. **JavaScript 引入方式**（5 分钟）：投影演示三种引入方式的代码：
   - 行内脚本：`<button onclick="alert('点了')">点我</button>`（讲师提问：\"这样写有什么问题？\" 引导出\"HTML 与 JS 耦合、难维护\"）；
   - 内部脚本：`<script>console.log('hi')</script>`（小 Demo 可以用）；
   - 外部脚本（推荐）：`<script src="app.js" defer></script>`。板书圈红 `defer` 两字，口播讲清：**`defer` 会等 HTML 解析完再执行，避免\"找不到 DOM 元素\"报错**。`async` 不保证顺序、通常用于统计脚本。

2. **变量与常量**（5 分钟）：投影三段代码：
   ```javascript
   let age = 18;
   const PI = 3.14159;
   var name = '张三';
   ```
   板书写下口诀：**能用 `const` 就用 `const`，需要重新赋值再用 `let`，不要用 `var`**。抽 3 位同学问：\"这三行分别是什么意思？\"

3. **数据类型**（6 分钟）：板书画一张分类图，先讲 7 种原始类型：`number / string / boolean / null / undefined / symbol / bigint`；再讲 3 种引用类型：`object / array / function`。投影演示 `typeof` 结果：

   ```javascript
   typeof 123;         // 'number'
   typeof '你好';      // 'string'
   typeof true;        // 'boolean'
   typeof undefined;   // 'undefined'
   typeof null;        // 'object'  ← 历史遗留 bug
   typeof [];          // 'object'
   typeof function(){};// 'function'
   ```

   **口播强调**：`typeof null` 得到 `'object'`，这是 JavaScript 设计时的 bug，向后兼容至今——**面试常考、写代码要用 `=== null` 判断**。

#### 示例演示（12 分钟）
1. **DevTools Console 实操**（6 分钟）：打开浏览器 F12 → Console 面板，现场输入变量声明、`typeof`、`==` 与 `===` 对比：

   ```javascript
   '1' == 1;    // true  （宽松相等，会类型转换）
   '1' === 1;   // false （严格相等）
   0 == false;  // true
   0 === false; // false
   ```

   投影演示，抽 1 位同学预测结果、验证。板书圈红一句话：**永远用 `===`，除非你有充分理由用 `==`**。

2. **《印想瑜伽会馆》案例引入**（6 分钟）：现场新建 `member-login.html`，写一个最简登录框，用外部脚本 `member-login.js`：

   ```html
   <input id="phone" placeholder="手机号">
   <input id="pwd" type="password" placeholder="密码">
   <button id="btn">登录</button>
   <script src="member-login.js" defer></script>
   ```

   在 `member-login.js` 里：

   ```javascript
   const btn = document.getElementById('btn');
   btn.onclick = () => {
       const phone = document.getElementById('phone').value;
       const pwd = document.getElementById('pwd').value;
       console.log('手机号：', phone, ' 密码：', pwd);
   };
   ```

   投影演示：输入手机号 → 点击登录 → Console 打印。**这是本课程贯穿案例\"会员登录\"的第一版**。

#### 课堂练习（10 分钟）
1. 学生独立完成：在自己电脑上新建 `warmup.html` + `warmup.js`，用 `defer` 方式引入，脚本中声明 3 个变量（分别用 `const`、`let`、`var`），并 `console.log` 各自的 `typeof`。教师巡视。
2. 抽 2 位同学到讲台，投影展示自己的代码，全班一起排错。

#### 小结（3 分钟）
一句话总结：**外部脚本 + `defer` + `const/let` + `===`，就是现代 JavaScript 的第一天\"新兵入伍\"**。预告下一课时：流程控制、函数、数组与对象——**用 JavaScript 处理\"会员列表\"这样的一堆数据**。

### 1.4 板书设计
```
┌──────────────────────────────────────────────┐
│  第 1 课时：JS 引入 + 变量与类型              │
├──────────────────────────────────────────────┤
│  引入三方式：                                │
│   行内 / 内部 / 外部（推荐）                 │
│   <script src="app.js" defer></script>       │
│   defer = HTML 解析完再执行                  │
│                                              │
│  变量口诀：                                  │
│   const → let → 不要 var                     │
│                                              │
│  原始 7 型 / 引用 3 型：                     │
│   number / string / boolean / null           │
│   undefined / symbol / bigint                │
│   object / array / function                  │
│                                              │
│  相等：== 会转型，=== 严格（推荐）           │
│  typeof null === 'object' ← 历史遗留 bug     │
└──────────────────────────────────────────────┘
```

### 1.5 课后作业
1. **必做**：为《印想瑜伽会馆》登录页 `member-login.html` 增加一个\"记住我\"复选框，在 `member-login.js` 中读取其 `checked` 状态并打印。
2. **必做**：整理\"JavaScript 常见数据类型速查表\"，每种类型至少给 2 个例子，保存为 Markdown。
3. **挑战题**：查阅资料 200 字回答：\"为什么 JavaScript 里 `0.1 + 0.2 !== 0.3`？\" 并给出至少一种解决方案。

### 1.6 教学反思提示
- 学生若从 Java/C 迁移过来，容易忽视 `===`；一定要通过\"字符串数字相等\"这类反直觉例子让他们记住。
- `defer` 与 `async` 的区别只需初步理解，不必展开讲事件循环。
- 若课堂时间紧张，可跳过 `symbol` / `bigint` 的深入，只让学生知道\"存在这两种类型\"。

---

## 第 2 课时：流程控制 + 函数 + 数组与对象

### 2.1 教学目标
#### 2.1.1 知识与技能目标
1. 熟练使用 `if / else`、`for`、`while`、`for..of`、`for..in` 五种流程控制；
2. 掌握三种函数写法：函数声明、函数表达式、箭头函数，并能说出各自适用场景；
3. 掌握数组常用 6 大方法：`push` / `pop` / `map` / `filter` / `find` / `reduce`；
4. 掌握对象字面量、点/中括号访问、解构、展开语法；
5. 理解 `?.` 可选链、`??` 空值合并两个现代语法。

#### 2.1.2 过程与方法目标
1. 通过\"会员数组处理\"实战，把数组方法映射到具体业务场景（筛选未过期会员、映射为姓名列表、计算总消费）；
2. 通过\"函数三种写法\"对比，感受 ES6 箭头函数的简洁性；
3. 通过\"解构 + 展开\"改造代码，体验现代 JavaScript 的表达力。

### 2.2 教学重难点
- **重点**：`for..of` 遍历数组 / 箭头函数 / `map`、`filter`、`reduce` / 解构赋值
- **难点**：`reduce` 的累加器思维 / 箭头函数的 `this` 不同于普通函数（本节只提一句，不展开）

### 2.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
提问：\"**给你一个包含 100 位会员的数组，怎么筛出\"年费到期\"的？怎么按消费金额排序？**\" 引出\"数组方法是前端开发的基本功\"。板书写\"3 个动作\"——**筛（filter）、映（map）、合（reduce）**。

#### 新知讲授（18 分钟）
1. **流程控制**（5 分钟）：投影五种控制结构，重点讲 `for..of` 与 `for..in` 的差异：

   ```javascript
   for (const item of ['A','B','C']) console.log(item);   // 值
   for (const key in {a:1,b:2}) console.log(key);         // 键
   ```

   口播强调：**`for..of` 拿值（数组）、`for..in` 拿键（对象）**。板书圈红这句口诀。

2. **函数三写法**（5 分钟）：投影：
   ```javascript
   function add(a, b) { return a + b; }               // 函数声明
   const mul = function(a, b) { return a * b; };     // 函数表达式
   const div = (a, b) => a / b;                       // 箭头函数（最常用）
   ```
   讲师提问：\"三者有什么区别？\" 抽 1 位同学回答，教师补充：**箭头函数最简洁、没有自己的 `this` 与 `arguments`，回调场景首选**。再补充默认参数和剩余参数：
   ```javascript
   function greet(name = 'World') { return `Hello, ${name}!`; }
   function sum(...nums) { return nums.reduce((s, n) => s + n, 0); }
   ```

3. **数组 6 大方法**（4 分钟）：投影表格逐行讲：

   | 方法 | 作用 | 是否改原数组 |
   |---|---|---|
   | `push` / `pop` | 尾插 / 尾删 | ✅ 改 |
   | `map(fn)` | 映射为新数组 | ❌ 不改 |
   | `filter(fn)` | 筛选 | ❌ 不改 |
   | `find(fn)` | 找到第一个 | ❌ 不改 |
   | `reduce(fn, init)` | 累加/汇总 | ❌ 不改 |
   | `forEach(fn)` | 只遍历不返回 | ❌ 不改 |

4. **对象 + 解构 + 展开 + 可选链**（4 分钟）：投影：
   ```javascript
   const user = { name: '张三', age: 20 };
   const { name, age } = user;                // 解构
   const clone = { ...user, age: 21 };        // 展开 + 覆盖
   const email = user?.contact?.email ?? '无'; // 可选链 + 空值合并
   ```
   板书写口诀：**`?.` 防空指针，`??` 防空值**。

#### 示例演示（14 分钟）
现场演示《印想瑜伽会馆》会员数组处理：

```javascript
const members = [
    { id: 1, name: '张三', level: 'VIP',    expired: false, spent: 3800 },
    { id: 2, name: '李四', level: '普通',   expired: true,  spent: 1200 },
    { id: 3, name: '王五', level: 'VIP',    expired: false, spent: 6500 },
    { id: 4, name: '赵六', level: '体验卡', expired: false, spent: 200  },
];

// 1. 筛选：未过期的 VIP
const activeVip = members.filter(m => !m.expired && m.level === 'VIP');

// 2. 映射：所有会员姓名
const names = members.map(m => m.name);

// 3. 汇总：总消费
const total = members.reduce((sum, m) => sum + m.spent, 0);

// 4. 查找：id 为 3 的会员
const target = members.find(m => m.id === 3);

console.log({ activeVip, names, total, target });
```

投影演示每一步在 DevTools 里的结果。抽 2 位同学到讲台上，让他们用同一份数据写出\"按消费金额排序（降序）\"和\"求平均消费\"。

#### 课堂练习（7 分钟）
学生独立完成：为上面 `members` 数组写出：
1. 筛出\"消费大于 3000\"的会员，并映射为\"姓名（等级）\"字符串数组；
2. 用 `reduce` 分别统计 VIP、普通、体验卡三类会员的人数（返回一个对象 `{VIP: n1, 普通: n2, 体验卡: n3}`）；

抽 2 位同学口头讲思路，教师纠偏。

#### 小结（3 分钟）
一句话总结：**流程控制学\"三种循环\"、函数学\"箭头函数\"、数组学\"filter/map/reduce\"、对象学\"解构与展开\"**。预告下一课时：**用这些工具去操纵网页——DOM 操作**。

### 2.4 板书设计
```
┌──────────────────────────────────────────────┐
│  第 2 课时：流程控制 + 函数 + 数组对象        │
├──────────────────────────────────────────────┤
│  for..of 拿值，for..in 拿键                  │
│                                              │
│  函数三写：声明 / 表达式 / 箭头（推荐）      │
│  const f = (a, b) => a + b;                  │
│                                              │
│  数组 6 招：                                 │
│   push/pop  map  filter  find  reduce forEach│
│                                              │
│  对象四招：                                  │
│   字面量 / 解构 / 展开 / 可选链 ?. ??        │
│                                              │
│  会员数据处理三部曲：                        │
│   筛（filter）→ 映（map）→ 合（reduce）      │
└──────────────────────────────────────────────┘
```

### 2.5 课后作业
1. **必做**：为《印想瑜伽会馆》写一个 `stats.js`，读取 20 条模拟会员数据（自己造），用 `filter/map/reduce` 输出：VIP 人数、平均消费、消费最高会员姓名。
2. **必做**：用箭头函数 + 剩余参数实现 `max(...nums)` 求最大值，测试 5 组数据。
3. **挑战题**：用一行 `reduce` 实现 `[1,2,3,4,5].reverse()` 的功能，不能调用 `reverse`。

### 2.6 教学反思提示
- `reduce` 是最容易劝退的方法，一定要用\"会员总消费\"这种具象场景引导。
- 若发现学生对箭头函数简写形式（`x => x * 2`）不适应，可多写几个等价的普通函数形式做过渡。
- 提示学生 `map` / `filter` 都返回**新数组**，不改原数组——这是函数式思维的起点。

---

## 第 3 课时：DOM 操作（选择元素、修改属性、增删节点）

### 3.1 教学目标
#### 3.1.1 知识与技能目标
1. 理解 DOM 是浏览器把 HTML 解析成的\"文档树\"；
2. 掌握 5 种查询 API：`getElementById` / `getElementsByClassName` / `getElementsByTagName` / `querySelector` / `querySelectorAll`；
3. 掌握修改内容与属性：`textContent` / `innerHTML` / `setAttribute` / `classList` / `style`；
4. 掌握增删节点：`createElement` / `appendChild` / `remove`；
5. 理解 `innerHTML` 的 XSS 风险。

#### 3.1.2 过程与方法目标
1. 通过\"课程列表动态渲染\"实战，把 DOM 操作串成一条业务线；
2. 通过\"F12 → Elements 面板 → 实时改文档\"演示，让学生看到\"DOM 就是活的 HTML\"；
3. 通过一段\"错误使用 innerHTML\"的 XSS 例子，建立安全意识。

### 3.2 教学重难点
- **重点**：`querySelector` / `querySelectorAll` / `classList` / `createElement`+`appendChild`
- **难点**：`innerHTML` 与 `textContent` 的区别 / `HTMLCollection` 与 `NodeList` 的差异（只提及）

### 3.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
打开 Day01 的《印想瑜伽会馆》首页 → F12 → Elements 面板 → **右键任意元素 → 编辑为 HTML** → 现场把 `<h1>印想瑜伽</h1>` 改成 `<h1>Hello 同学</h1>`。学生惊叹后引出：**HTML 加载后就变成了 DOM 树，JavaScript 能读能写这棵树**。板书画一棵简易 DOM 树。

#### 新知讲授（15 分钟）
1. **DOM 概念**（3 分钟）：板书画树：
   ```
   document
     └─ html
         ├─ head
         └─ body
             ├─ h1
             └─ ul
                 ├─ li
                 └─ li
   ```
   口播：**每一个 HTML 元素就是一个 JavaScript 对象**。

2. **查询元素**（5 分钟）：投影：
   ```javascript
   document.getElementById('title');
   document.getElementsByClassName('item');   // HTMLCollection
   document.getElementsByTagName('p');
   document.querySelector('.card > h1');       // ✅ 推荐
   document.querySelectorAll('.item');         // NodeList
   ```
   讲师提问：\"用 CSS 选择器查询，哪一个 API 最方便？\"抽 1 位同学回答（`querySelector`）。板书圈红 `querySelector` / `querySelectorAll`。

3. **修改内容与属性**（4 分钟）：投影：
   ```javascript
   const h1 = document.querySelector('h1');
   h1.textContent = '新标题';           // 只读写文本
   h1.innerHTML = '<em>富文本</em>';    // 会解析 HTML（注意 XSS）
   h1.setAttribute('data-id', 42);
   h1.classList.add('active');
   h1.classList.toggle('hidden');
   h1.style.color = 'red';
   ```
   **口播划重点**：`textContent` 安全、`innerHTML` 危险（XSS）。板书写\"⚠️ 用户输入禁用 innerHTML\"。

4. **增删节点**（3 分钟）：投影：
   ```javascript
   const li = document.createElement('li');
   li.textContent = '瑜伽入门课';
   document.querySelector('ul').appendChild(li);
   li.remove();   // 现代浏览器直接移除自己
   ```

#### 示例演示（12 分钟）
《印想瑜伽会馆》**课程列表动态渲染**——现场编码：

```html
<h2>课程列表</h2>
<ul id="course-list"></ul>
<script src="course-list.js" defer></script>
```

```javascript
// course-list.js
const courses = [
    { name: '哈他瑜伽入门', teacher: '林老师', duration: 60 },
    { name: '流瑜伽进阶',   teacher: '陈老师', duration: 75 },
    { name: '孕妇瑜伽',     teacher: '王老师', duration: 45 },
    { name: '空中瑜伽',     teacher: '李老师', duration: 60 },
];

const ul = document.querySelector('#course-list');
courses.forEach(c => {
    const li = document.createElement('li');
    li.textContent = `${c.name} —— ${c.teacher}（${c.duration} 分钟）`;
    li.classList.add('course-item');
    ul.appendChild(li);
});
```

投影演示：保存 → 刷新页面 → 4 个课程条目自动出现。抽 1 位同学到讲台，让他**再往数组里加一条数据**，全班看效果。

**XSS 演示**（2 分钟）：把 `courses[0].name` 改成 `<img src=x onerror=alert('XSS')>`，然后把 `li.textContent` 改成 `li.innerHTML = c.name`——现场看到弹窗。**再改回 `textContent`，弹窗消失**。学生印象深刻。

#### 课堂练习（10 分钟）
学生独立完成：
1. 在\"课程列表\"下方增加一个\"添加课程\"按钮，点击时用 `createElement` 追加一条固定内容的 `<li>`（先不涉及事件绑定的高级用法，用 `onclick` 属性即可）；
2. 给每个 `<li>` 加一个 `data-id` 属性（用 `setAttribute`），值为课程数组下标；
3. 用 `classList.toggle('done')` 让点击某条课程时切换\"已报名\"样式。

教师巡视，抽 2 位同学讲台演示。

#### 小结（4 分钟）
一句话总结：**查（querySelector）→ 改（textContent / classList）→ 增（createElement + appendChild）→ 删（remove）**。预告下一课时：**给 DOM 装上\"耳朵\"——事件处理与 jQuery**。

### 3.4 板书设计
```
┌──────────────────────────────────────────────┐
│  第 3 课时：DOM 操作                          │
├──────────────────────────────────────────────┤
│  DOM = 文档树（每个标签 = 一个对象）         │
│                                              │
│  查（5 种，推荐 querySelector）：            │
│   getElementById / ClassName / TagName       │
│   querySelector / querySelectorAll ✅         │
│                                              │
│  改：                                        │
│   textContent（安全）                        │
│   innerHTML（⚠️ XSS 风险）                    │
│   setAttribute / classList / style           │
│                                              │
│  增删：                                      │
│   createElement + appendChild / remove       │
│                                              │
│  口诀：查 → 改 → 增 → 删                     │
└──────────────────────────────────────────────┘
```

### 3.5 课后作业
1. **必做**：为《印想瑜伽会馆》做一个\"课程详情面板\"：点击课程列表任一条目时，把该课程的 name/teacher/duration 显示到旁边一个 `<div id="detail">` 中。
2. **必做**：写一个\"清空课程列表\"按钮，用 `remove()` 清空 `<ul>` 里所有 `<li>`。
3. **挑战题**：用 `classList` + `setAttribute`，为每条课程添加\"报名 / 取消报名\"的双状态切换，报名后 `<li>` 边框变绿。

### 3.6 教学反思提示
- XSS 演示必须谨慎，把弹窗关掉后一定要恢复代码，否则学生下课后可能忘掉安全教训。
- 学生常混淆 `getElementsByClassName`（返回**动态** HTMLCollection）与 `querySelectorAll`（返回**静态** NodeList），本节课不深挖，只要让他们**默认用 `querySelector` 系**即可。
- `innerHTML` vs `textContent` 是常考面试题，务必强调。

---

## 第 4 课时：事件处理 + jQuery 简介

### 4.1 教学目标
#### 4.1.1 知识与技能目标
1. 掌握三种事件绑定方式：行内 / 属性绑定 / `addEventListener`；
2. 熟悉 8 种常见事件：`click` / `dblclick` / `input` / `change` / `submit` / `mouseenter` / `keydown` / `DOMContentLoaded`；
3. 掌握事件对象常用属性：`e.target` / `e.preventDefault()` / `e.key`；
4. 理解并会用**事件委托**优化列表交互；
5. 会写最简版 jQuery 代码（`$('#id').on('click', fn)`），能读懂遗留项目。

#### 4.1.2 过程与方法目标
1. 通过\"三种绑定方式对比\"让学生记住 `addEventListener` 的最佳实践；
2. 通过\"表单提交阻止默认行为\"实战，理解 `e.preventDefault()`；
3. 通过\"事件委托 = 一个父监听搞定 100 个子元素\"，感受性能与灵活性；
4. 通过 jQuery 与原生 API 的对照表，让学生看到\"简洁 = 有代价（额外 90KB）\"。

### 4.2 教学重难点
- **重点**：`addEventListener` / `e.preventDefault()` / 事件委托 / jQuery 常用 API 对照
- **难点**：事件委托中 `e.target.tagName === 'LI'` 的判断 / jQuery 的 `this` 与箭头函数的兼容问题

### 4.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
把上节课的\"课程列表\"打开，问：\"**能不能让用户点击某个课程就弹出详情？**\" 引出事件——**让 DOM 会\"回应\"用户**。板书写：\"DOM = 说什么 + 长什么样 + **会回应什么**\"。

#### 新知讲授（17 分钟）
1. **三种绑定方式**（5 分钟）：投影：
   ```html
   <!-- 1. 行内（不推荐） -->
   <button onclick="alert(1)">A</button>

   <!-- 2. 属性绑定（覆盖式，只能一个回调） -->
   <script>
       btn.onclick = () => alert(2);
   </script>

   <!-- 3. 事件监听（可绑多个，推荐 ✅） -->
   <script>
       btn.addEventListener('click', () => alert(3));
   </script>
   ```
   板书圈红 `addEventListener`。口播：\"**属性绑定同一个事件后面赋值会覆盖前面，`addEventListener` 可以叠加**。\"

2. **常见事件**（4 分钟）：投影表格：

   | 事件 | 触发时机 |
   |------|----------|
   | `click` | 单击 |
   | `dblclick` | 双击 |
   | `input` | 输入框内容变化时 |
   | `change` | 值改变并失焦 |
   | `submit` | 表单提交 |
   | `mouseenter/mouseleave` | 鼠标进入/离开 |
   | `keydown/keyup` | 键盘按下/抬起 |
   | `DOMContentLoaded` | HTML 解析完成 |

3. **事件对象**（4 分钟）：投影登录表单示例：
   ```javascript
   form.addEventListener('submit', (e) => {
       e.preventDefault();               // 阻止默认提交（页面刷新）
       console.log(e.target.username.value);
   });
   ```
   板书圈红 `e.preventDefault()`。口播：\"**表单默认会 GET 一次刷新页面，`e.preventDefault()` 让它不刷新，我们才能用 Ajax 提交**。\"

4. **事件委托**（4 分钟）：投影：
   ```javascript
   document.querySelector('ul').addEventListener('click', (e) => {
       if (e.target.tagName === 'LI') {
           console.log('点了：', e.target.textContent);
       }
   });
   ```
   板书画示意图：**父节点 UL 一个监听器 → 通过 `e.target` 判断具体点的是哪个子 LI**。口播强调两大好处：**监听器少 → 性能好**；**动态生成的 LI 也自动生效**。

#### 示例演示（12 分钟）
**《印想瑜伽会馆》会员登录表单**——加上事件处理，成为完整可交互版：

```html
<form id="loginForm">
    <input name="phone" placeholder="手机号（11 位）">
    <input name="password" type="password" placeholder="密码（6-16 位）">
    <button type="submit">登录</button>
    <div id="msg"></div>
</form>
<script src="login.js" defer></script>
```

```javascript
// login.js
const form = document.getElementById('loginForm');
const msg  = document.getElementById('msg');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    const { phone, password } = e.target;

    if (!/^1\d{10}$/.test(phone.value)) {
        msg.textContent = '手机号格式不正确';
        return;
    }
    if (password.value.length < 6 || password.value.length > 16) {
        msg.textContent = '密码长度需 6—16 位';
        return;
    }
    msg.textContent = `欢迎回来，${phone.value}`;
});
```

投影演示：故意输错手机号、超长密码，观察消息变化。

**事件委托实战**：把上节课的\"课程列表\"改为**委托监听**——点击任意课程 `<li>` 时切换 `.selected` 样式：

```javascript
document.querySelector('#course-list').addEventListener('click', (e) => {
    if (e.target.tagName === 'LI') {
        e.target.classList.toggle('selected');
    }
});
```

投影演示：不管有几条课程，一个监听器搞定。

**jQuery 对照演示**（3 分钟）：把上面的委托代码改为 jQuery 版本，投影对比：

```javascript
$('#course-list').on('click', 'li', function () {
    $(this).toggleClass('selected');
});
```

投影表格对照：

| 原生 JS | jQuery |
|---------|--------|
| `document.querySelector('.a')` | `$('.a')` |
| `el.addEventListener('click', fn)` | `$('.a').click(fn)` |
| `el.classList.add('b')` | `$('.a').addClass('b')` |
| `el.textContent = 'x'` | `$('.a').text('x')` |

**口播强调**：**新项目请使用 Vue/React，不要用 jQuery 新写业务代码**——但**老项目会遇到，必须能读懂**。

#### 课堂练习（10 分钟）
学生独立完成：
1. 在会员登录表单基础上增加\"记住我\"复选框，若勾选则在 `msg` 中额外显示\"已开启记住我\"；
2. 用**事件委托**为课程列表增加\"双击删除\"：`dblclick` 事件 → `e.target.remove()`；
3. 抽 2 位同学到讲台演示。

#### 小结（3 分钟）
一句话总结：**`addEventListener` 是唯一正确的姿势 / 表单 `submit` 记得 `preventDefault` / 列表用事件委托 / jQuery 学能读就行**。预告下一课时：**AI 出场——通义灵码 + Trae，让 AI 帮你写前端**。

### 4.4 板书设计
```
┌──────────────────────────────────────────────┐
│  第 4 课时：事件处理 + jQuery                 │
├──────────────────────────────────────────────┤
│  绑定 3 方式（推荐 addEventListener）：      │
│   行内 / onclick 属性 / addEventListener ✅   │
│                                              │
│  常见事件：                                  │
│   click dblclick input change submit         │
│   keydown DOMContentLoaded mouseenter        │
│                                              │
│  事件对象：                                  │
│   e.target / e.preventDefault() / e.key      │
│                                              │
│  事件委托：                                  │
│   父监听 + e.target 判断子标签               │
│   → 监听器少 + 支持动态元素                  │
│                                              │
│  jQuery = 简写糖 + 兼容老项目               │
│  $('.a').on('click', fn) 能读即可            │
└──────────────────────────────────────────────┘
```

### 4.5 课后作业
1. **必做**：为登录表单增加\"3 次输错锁定 30 秒\"功能，用 `setTimeout` 与计数器实现。
2. **必做**：用事件委托实现\"点击 `<ul>` 里任意 `<li>` 都能移到列表末尾\"（`appendChild` 到同一父节点时会移动，而不是复制）。
3. **挑战题**：把\"课程列表\"用 jQuery 重写一遍，感受两种写法差异（≤ 30 行）。

### 4.6 教学反思提示
- 事件委托是本课时最重要也最难的知识点，务必用\"100 个按钮\"这样的极端例子引导学生思考\"为什么需要委托\"。
- `e.target` 与 `e.currentTarget` 的区别本节课不深讲，只强调\"委托里用 `e.target`\"。
- jQuery 里的 `function` + `this` 与箭头函数不兼容——若学生把 `.on('click', 'li', () => $(this))` 写错，要现场解释\"箭头函数没有自己的 `this`\"。

---

## 第 5 课时：通义灵码/Trae 使用入门 + AI 生成第一个前端页面

### 5.1 教学目标
#### 5.1.1 知识与技能目标
1. 完成通义灵码（TONGYI Lingma）在 Trae / VS Code 中的安装与登录；
2. 说出通义灵码 6 大核心功能：代码补全 / 智能问答 / 代码解释 / 代码优化 / 生成注释 / 生成单测；
3. 熟练使用 3 种触发方式：Tab 补全 / `/` 快捷指令 / `@` 引用文件；
4. 掌握 CRISPE 简化版\"角色+背景+目标+约束+输出\"提示词模板；
5. 用 AI 一次生成一个符合业务需求的登录页 HTML 文件。

#### 5.1.2 过程与方法目标
1. 通过\"模糊提示 vs 精准提示\"对比，让学生亲眼看到\"提示词质量决定产出质量\"；
2. 建立\"需求 → 提示词 → 代码 → 审查 → 调优\"AI 编程闭环意识；
3. 让学生学会用 Trae + 通义灵码进行日常开发，为后续所有实战打底。

### 5.2 教学重难点
- **重点**：通义灵码 3 种触发方式（Tab / `/` / `@`） / 精准提示词的 5 要素结构 / 生成后\"插入编辑器\"操作
- **难点**：约束条件的粒度控制——太宽 AI 瞎发挥、太窄 AI 缩手缩脚 / 学生易把\"提示词工程\"当成\"甩锅给 AI\"

### 5.3 教学过程设计（45 分钟）
#### 导入（4 分钟）
提问：\"**上节课的登录页你写了多久？**\" 抽 3 位同学回答（大概率 30 分钟以上）。教师现场用通义灵码 90 秒生成一个更完整的登录页——**同样的代码，90 秒 vs 30 分钟，差距在哪？答案：AI 提示词。** 板书写：\"AI = 会 100 种技能的实习生，但你不给需求他啥都干不了\"。

#### 新知讲授（16 分钟）
1. **通义灵码功能全景**（6 分钟）：投影表格：

   | 功能 | 快捷键（Trae/VS Code） | 用途 |
   |------|-----------------------|------|
   | 代码补全 | 输入自动触发（按 Tab 接受） | 智能续写光标处代码 |
   | 智能问答 | `Ctrl+Shift+L` 唤起侧栏 | 自由对话、生成整块代码 |
   | 代码解释 | 选中代码 → 右键 → Lingma → 解释 | 解读遗留代码 |
   | 代码优化 | 同上 → 优化 | 重构、性能改进 |
   | 生成注释 | 同上 → 生成注释 | JSDoc / JavaDoc |
   | 生成单测 | 同上 → 生成单元测试 | 一键出测试文件 |

   板书写\"6 大功能\"。**口播强调**：**80% 的日常编码需求都被这 6 个覆盖**。

2. **三种触发方式**（4 分钟）：
   - **Tab 补全**：写一半代码，等灰色提示出来按 Tab；
   - **`/` 快捷指令**：侧栏输入 `/explain`、`/fix`、`/tests` 等；
   - **`@` 引用文件**：`@file:login.js`、`@workspace`——让 AI 知道上下文。

3. **精准提示词 5 要素**（6 分钟）：投影模板：

   ```text
   【角色】：<Web 初学者/后端工程师/前端专家>
   【背景】：<正在做什么项目、使用什么技术栈>
   【目标】：<清晰、单一的一件事>
   【约束】：<必须遵守的规则>
   【输出】：<代码 + 简要说明 / 表格 / 步骤>
   ```

   板书画一个五格竖表，口播：**\"每一格都填清楚，AI 就一次到位；漏一格，AI 就要猜\"**。

#### 示例演示（15 分钟）
1. **反例 → 正例**（4 分钟）：投影两次尝试。

   **反例**（AI 只会给通用模板）：
   ```text
   写一个登录页面。
   ```

   **正例**（精准提示词）：
   ```text
   【角色】前端初学者，学过 HTML/CSS/JS。
   【背景】《印想瑜伽会馆客户管理系统》，需要为会员做登录入口。
   【目标】生成 login.html 单文件。
   【约束】
   1. 内联 <style>，Flex 居中，卡片宽 360px、圆角 8px、投影柔和；
   2. 表单字段：手机号（11 位，1 开头）+ 密码（6-16 位）；
   3. 点击\"登录\"按钮校验字段并 alert 结果，不发起真实请求；
   4. 不引入任何外部 CDN 或库；
   5. 主色调 #667eea（瑜伽紫）。
   【输出】完整的单文件 HTML。
   ```

   现场把两段提示词分别发给通义灵码侧栏，投影对比结果。**差异一目了然**。

2. **完整流程演示**（8 分钟）：
   - 在 Trae 里新建 `login.html`；
   - `Ctrl+Shift+L` 打开 Lingma 侧栏，粘贴上面精准版提示词；
   - 观察 AI 输出，点击代码块右上角 **\"插入到编辑器\"**；
   - 保存 → 右键\"Open with Live Server\"预览；
   - 出现小 bug（比如错误提示颜色不对），继续在侧栏追问：\"错误提示颜色请改为 #e53e3e，字号 12px\"。

3. **上下文引用演示**（3 分钟）：新建 `member-list.html`（空文件），侧栏输入：
   ```text
   @file:login.html 参考这个登录页的风格，再帮我做一个会员列表页面 member-list.html，
   展示 5 条 mock 数据（姓名、手机号、等级、注册日期）。
   ```
   让学生看到 `@file:` 引用带来的**风格一致性**。

#### 课堂练习（7 分钟）
学生独立完成：
1. 打开 Trae，按讲师流程安装并登录通义灵码；
2. 用精准提示词模板，让 AI 生成一个《印想瑜伽会馆》**首页**：顶部 Logo + 导航（首页/课程/会员/联系我们）+ Banner（一张纯色背景 + 一句标语）+ 页脚——单文件、内联样式、Flex 布局；
3. 抽 1—2 位同学到讲台，投影自己的提示词和 AI 输出，全班点评。

#### 小结（3 分钟）
一句话总结：**通义灵码 6 大功能 + 3 种触发 + 5 要素提示词**。预告下一课时：**AI 生成的代码，不能直接用——今天教你审查、调优与排错**。

### 5.4 板书设计
```
┌───────────────────────────────────────────────┐
│  第 5 课时：通义灵码 + AI 生成前端            │
├───────────────────────────────────────────────┤
│  通义灵码 6 大功能：                          │
│   补全 / 问答 / 解释 / 优化 / 注释 / 单测     │
│                                               │
│  3 种触发：                                   │
│   Tab / /explain,/fix,/tests / @file:xxx      │
│                                               │
│  精准提示词 5 要素：                          │
│   ┌──────────┐                                │
│   │ 角色      │                                │
│   ├──────────┤                                │
│   │ 背景      │                                │
│   ├──────────┤                                │
│   │ 目标      │                                │
│   ├──────────┤                                │
│   │ 约束      │                                │
│   ├──────────┤                                │
│   │ 输出      │                                │
│   └──────────┘                                │
│                                               │
│  闭环：需求 → 提示词 → 代码 → 审查 → 调优     │
└───────────────────────────────────────────────┘
```

### 5.5 课后作业
1. **必做**：用精准提示词让 AI 生成《印想瑜伽会馆》**课程详情页** `course-detail.html`：课程封面 + 标题 + 教练 + 时长 + 报名按钮，单文件。
2. **必做**：整理\"我的第一个提示词库\"，收录至少 3 个精准提示词模板（登录页 / 列表页 / 详情页），保存为 `.md`。
3. **挑战题**：让 AI 用 CSS 变量重写\"瑜伽紫\"主题色，全站色彩由 CSS 变量集中控制。

### 5.6 教学反思提示
- Trae + 通义灵码首次登录容易被防火墙拦截，建议提前准备好\"手机验证码 / 钉钉扫码\"两种登录方式。
- 学生易犯\"提示词越长越好\"的误区——本节课要强调**约束条件要精准、不要罗嗦**。
- 若课堂无法访问通义灵码，可用 DeepSeek/豆包/Kimi 网页版作为备份，但要提示学生这样就没有\"插入编辑器\"的一键操作。

---

## 第 6 课时：AI 生成代码的审查、调优与排错实战

### 6.1 教学目标
#### 6.1.1 知识与技能目标
1. 掌握\"AI 代码审查清单\"5 条：约束满足 / 语法错误 / 边界条件 / 可访问性 / 命名可读；
2. 会用通义灵码 `解释代码` 功能读懂陌生代码；
3. 会把浏览器控制台报错直接贴给 AI，让它诊断修复；
4. 会用 `生成注释` 与 `生成单元测试` 功能补齐工程规范；
5. 铭记 AI 编程三条纪律：责任在自己 / 不泄密 / 保持思考肌肉。

#### 6.1.2 过程与方法目标
1. 通过\"AI 生成后台管理页 + 4 问阅读器\"实战，训练\"边读边改\"能力；
2. 通过\"控制台报错 → 贴给 AI → 修复\"的完整闭环，建立正确的 AI 协作节奏；
3. 通过一个\"故意留 bug 让 AI 修\"的练习，让学生学会**用 `/fix` 快捷指令**。

### 6.2 教学重难点
- **重点**：AI 代码审查 5 条清单 / 4 问阅读器（做什么 / 数据流 / 更简洁 / 何时崩） / `/fix` 修复流程
- **难点**：如何识别 AI 生成代码中的\"看起来对但边界错\" bug / 让学生真正读代码而不是\"甩给 AI\"

### 6.3 教学过程设计（45 分钟）
#### 导入（3 分钟）
现场重现一段**AI 生成的错误代码**：`document.getElementById('xxx').addEventListener(...)` 但 `<script>` 放在了 `<head>` 里没加 `defer`，页面一打开就报 `Cannot read properties of null`。学生猜错在哪、抽 1 位同学回答。**引出主题**：**AI 生成的代码，你要能审、能改、能救**。

#### 新知讲授（15 分钟）
1. **实战：AI 生成《印想瑜伽会馆》后台会员列表页**（6 分钟）：投影一段精准提示词：
   ```text
   【角色】前端工程师。
   【背景】《印想瑜伽会馆》后台管理，需要展示会员列表。
   【目标】生成 emp.html：顶部标题栏 + \"新增会员\"按钮，
        中部表格（姓名/手机号/等级/入会日期/操作），
        底部分页栏（上一页 / 页码 / 下一页），
        JS 数组模拟 20 条数据。
   【约束】单文件、Flex + 表格样式、不引入外部库、每页 5 条。
   【输出】完整 HTML。
   ```
   现场执行，投影 AI 输出。

2. **代码审查 5 条清单**（4 分钟）：投影：

   | # | 检查项 | 该看什么 |
   |---|---|---|
   | 1 | 约束满足 | 提示词里的每一条是否都被实现 |
   | 2 | 语法错误 | Trae 用红波浪线会提示 |
   | 3 | 边界条件 | 空输入、超长输入、极端数据 |
   | 4 | 可访问性 | `<input>` 是否配了 `<label>` |
   | 5 | 命名可读 | 变量名是否清晰、代码是否可读 |

3. **4 问阅读器**（5 分钟）：板书写下：
   ```
   Q1  这段代码做什么？（一句话）
   Q2  读了什么，写了什么？（数据流）
   Q3  有没有更简洁的写法？
   Q4  什么情况下会崩？（边界）
   ```
   讲师提问：抽 3 位同学分别用这 4 问审查 AI 输出中的 `render(page)` 分页函数。教师纠偏。

#### 示例演示（15 分钟）
1. **场景一：控制台报错 → AI 修复**（5 分钟）：故意把 AI 生成的 `<script>` 从 `</body>` 前拽到 `<head>` 里，刷新页面看到红色报错：
   ```text
   Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
       at emp.html:87
   ```
   把这段报错**整段粘贴**到通义灵码侧栏，输入：
   ```text
   以下报错什么原因？如何修复？
   Uncaught TypeError: Cannot read properties of null (reading 'addEventListener')
       at emp.html:87
   ```
   AI 会答：\"脚本在 DOM 加载前执行……解决方案：1. `<script>` 放到 `</body>` 前；2. 使用 `defer`；3. 包裹在 `DOMContentLoaded` 里。\" 现场按方案 2 修复，报错消失。

2. **场景二：AI 解释一段\"天书代码\"**（4 分钟）：选中 AI 输出里的 `render(page)` 函数 → 右键 → `Lingma → 解释代码`。侧栏会逐行讲解，投影展示。**这在你接手老项目时非常有用**。

3. **场景三：AI 生成注释与单测**（3 分钟）：
   - 选中 `render(page)` → `Lingma → 生成注释` → JSDoc 一次到位；
   - 选中 → `Lingma → 生成单元测试` → 输出可跑的 Jest 代码。

4. **AI 编程三条纪律**（3 分钟）：板书写下：
   - **代码是自己的责任**——AI 只是助手，代码错了你担责；
   - **不要泄露敏感信息**——DB 密码、AccessKey、公司内网地址不要贴进对话；
   - **保持思考肌肉**——先自己想 30 秒再问 AI，避免变成\"提示词工人\"。

#### 课堂练习（9 分钟）
学生分组（2 人一组）：
1. 让 AI 生成一段\"数字加法\"函数（`add(a, b)`），故意在提示词里要求\"必须支持字符串数字\"，然后**审查 AI 的输出**——大概率会有\"`add('1', '2')` 得 `'12'` 而不是 `3`\"的坑；
2. 用 `/fix` 让 AI 修复；
3. 用\"生成单元测试\"命令，让 AI 出至少 5 条测试用例，包含边界：空字符串、负数、极大数、非数字字符。
4. 抽 2 组同学到讲台，投影演示自己发现的 bug 与修复过程。

#### 小结（3 分钟）
一句话总结：**5 条审查清单 + 4 问阅读器 + 3 条纪律**。**AI 让你快 10 倍，前提是你会看、会改、会救**。本日 6 课时结束，Day02 学习到此完成。预告 Day03：**Vue 3 前端框架开始**。

### 6.4 板书设计
```
┌───────────────────────────────────────────────┐
│  第 6 课时：AI 代码审查 + 调优 + 排错         │
├───────────────────────────────────────────────┤
│  审查 5 条：                                  │
│   约束 / 语法 / 边界 / 可访问性 / 命名        │
│                                               │
│  4 问阅读器：                                 │
│   Q1 做什么？                                 │
│   Q2 读什么/写什么？                          │
│   Q3 更简洁？                                 │
│   Q4 何时崩？                                 │
│                                               │
│  AI 帮排错三招：                              │
│   贴报错 → 解释代码 → /fix 修复               │
│                                               │
│  三条纪律：                                   │
│   责任在己 / 不泄密 / 先自己想 30 秒          │
└───────────────────────────────────────────────┘
```

### 6.5 课后作业
1. **必做**：用 AI 生成《印想瑜伽会馆》**会员列表页 + 新增会员弹窗**，按 5 条清单自查并写一份 ≤ 300 字的\"AI 代码 Review 报告\"。
2. **必做**：让 AI 为你 Day02 写的所有 JS 函数生成 JSDoc 注释，提交前逐个通读修改。
3. **挑战题**：给 AI 一段**你自己写错的 JS 代码**（例如死循环、内存泄漏、XSS 漏洞），用 `/fix` 让它修复，写 200 字点评修复质量。

### 6.6 教学反思提示
- 学生最容易陷入\"AI 生成 → 直接用\"的坏习惯，本节课务必让每人**至少改动一次 AI 输出**才算完成练习。
- 控制台报错贴给 AI 之前，**先让学生自己看错误行号与堆栈**——培养基本调试直觉，不要把 AI 当拐杖。
- \"三条纪律\"的**不泄密**部分要重点讲——课程后期涉及公司项目时，这一条会救命。

---

## 附录：Day02 参考资源

- 教程原文：`/AI应用Web开发教程/chapters/03.md`、`/AI应用Web开发教程/chapters/04.md`
- MDN 文档：[developer.mozilla.org/zh-CN/docs/Web/JavaScript](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript)
- jQuery 官方：[jquery.com](https://jquery.com/)（当前稳定版 3.7.1）
- 通义灵码 Trae 插件市场：搜索 `TONGYI Lingma`

**总备注**：Day02 是从\"读代码\"到\"写代码\"再到\"用 AI 写代码\"的关键跨越课。教师需时刻观察学生手上是否真的在敲键盘——**JS 是练出来的，不是听出来的**。
