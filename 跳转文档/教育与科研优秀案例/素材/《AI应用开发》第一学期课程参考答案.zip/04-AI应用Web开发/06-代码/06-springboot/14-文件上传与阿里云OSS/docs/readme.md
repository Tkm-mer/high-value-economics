



1. application.yml 代码示例：

```yaml
#...其它代码略

#文件上传路径
upload:
  #文件存储物理路径
  location: d:/gcbs2025/upload/
  #文件访问路径
  url-prefix: http://localhost:8080/upload
```

2. CommonConfig.java 代码示例：

```java
package com.situ.gcbs.server.config;

@Configuration
public class CommonConfig implements WebMvcConfigurer {
    private JwtHandlerInterceptor jwtHandlerInterceptor;

    //文件上传物理路径
    @Value("${upload.location}")
    private String uploadLocation;
    
    //...其它代码略

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/upload/**")
                .addResourceLocations("file:/" + uploadLocation);
    }
}

```

3. 上传代码控制器代码示例。

```java
package com.situ.gcbs.server.api;

@RestController
@RequestMapping(value = "/api/v1/members", produces = MediaType.APPLICATION_JSON_VALUE)
public class MemberApi {
    private UploadService uploadService;

    @Autowired
    public void setUploadService(UploadService uploadService) {
        this.uploadService = uploadService;
    }
    
    //...其它代码略
    
    /**
     * 保存会员实体
     *
     * @return 响应结果
     */
    @PostMapping
    public ResponseEntity<JsonResult> save(@RequestBody @NonNull @Validated(Add.class) Member member) {
        boolean success = memberService.save(member);

        if (success) {
            if (StringUtils.hasText(member.getAvatar())) {
                redisTemplate.opsForValue().set(member.getAvatar(), true, Duration.ofMinutes(5));
            }
            return ResponseEntity.ok(JsonResult.success(member));
        } else {
            return ResponseEntity.ok(JsonResult.fail("保存会员失败"));
        }
    }

    /**
     * 上传客户头像
     *
     * @return 头像
     */
    @PostMapping("/avatar")
    public ResponseEntity<JsonResult> avatar(MultipartFile file,
                                             @RequestParam(defaultValue = "member_avatar") String type) {
        //此处可以选择将文件上传到本地，或阿里云，七牛云等等，本处演示上传到本地
        String url = this.uploadService.uploadImage(file, type);
        return ResponseEntity.ok(JsonResult.success(url));
    }

}

```

4. 上传文件业务类实现。

```java
package com.situ.gcbs.server.service.impl;

@Service
public class UploadServiceImpl implements UploadService {
    private final ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(10);
    
    //文件上传本地路径
    @Value("${upload.location}")
    private String uploadLocation;
    
    //访问前缀
    @Value("${upload.url-prefix}")
    private String urlPrefix;
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 上传头像，返回图片地址
     *
     * @param file 头像文件
     * @return 存储相对路径
     */
    @Override
    public String uploadImage(MultipartFile file, String type) {
        File dir = new File(uploadLocation + "/images/" + type);
        if (!dir.exists()) {
            boolean b = dir.mkdirs();
            if (!b) {
                throw new RuntimeException("创建目录失败");
            }
        }

        String fileName = file.getOriginalFilename();//上传文件名
        assert fileName != null;
        int idx = fileName.lastIndexOf(".");

        //文件扩展名，包括点
        String ext = fileName.substring(idx);
        fileName = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));

        //追加3位随机数
        Random random = new Random();
        int num = random.nextInt(1000);
        fileName = fileName + "-" + num + ext;

        try {
            File target = new File(dir.getCanonicalPath() + "/" + fileName);
            file.transferTo(target);//传输文件

            if (urlPrefix.endsWith("/")) {
                urlPrefix = urlPrefix.substring(0, urlPrefix.length() - 1);
            }

            String url = urlPrefix + "/images/" + type + "/" + fileName;

            //定时删除任务
            scheduledExecutorService.schedule(() -> {
                if (!redisTemplate.hasKey(url)) {
                    boolean _ = target.delete();//删除文件
                }
            }, 5, TimeUnit.MINUTES);

            return url;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

```

