# Spring 表达式语言（SpEL）完全教程

最后更新：2026-08-10

## 简介

本教程面向 Java / Spring 开发者，从零开始系统讲解 Spring Expression Language（SpEL）。学习完你将掌握：

- SpEL 的核心语法与运算符体系
- 在 `@Value`、`@PreAuthorize` 等注解中的常见用法
- 使用 `SpelExpressionParser` 以编程方式解析和执行表达式
- 集合选择（Selection）与投影（Projection）等高级特性
- 自定义函数、变量、`T()` 类型引用与安全沙箱配置
- 实际工程中的最佳实践与常见陷阱

> 预计学习时间：2.5 小时

参考资料：
- [Baeldung 中文网 - Spring 表达式语言指南](https://www.baeldung-cn.com/spring-expression-language)
- [Spring Framework Reference - Expression Language](https://docs.spring.io/spring-framework/docs/3.2.x/spring-framework-reference/html/expressions.html)
- [Spring Security - Method Security](https://docs.spring.io/spring-security/reference/servlet/authorization/method-security.html)

---

## 目录

- [1. 前言与概述](#1-前言与概述)
  - [1.1 什么是 SpEL](#11-什么是-spel)
  - [1.2 为什么需要 SpEL](#12-为什么需要-spel)
  - [1.3 核心特性一览](#13-核心特性一览)
- [2. 环境准备](#2-环境准备)
  - [2.1 引入依赖](#21-引入依赖)
  - [2.2 表达式占位符语法](#22-表达式占位符语法)
- [3. 基础运算符](#3-基础运算符)
  - [3.1 算术运算符](#31-算术运算符)
  - [3.2 关系运算符](#32-关系运算符)
  - [3.3 逻辑运算符](#33-逻辑运算符)
  - [3.4 条件运算符与 Elvis](#34-条件运算符与-elvis)
  - [3.5 正则表达式 matches](#35-正则表达式-matches)
- [4. Bean 引用与上下文](#4-bean-引用与上下文)
  - [4.1 在 XML 中引用 Bean](#41-在-xml-中引用-bean)
  - [4.2 在 @Value 注解中引用 Bean](#42-在-value-注解中引用-bean)
  - [4.3 访问 List 和 Map](#43-访问-list-和-map)
- [5. 编程方式解析表达式](#5-编程方式解析表达式)
  - [5.1 SpelExpressionParser 基础用法](#51-spelexpressionparser-基础用法)
  - [5.2 字符串模板模式 TemplateParserContext](#52-字符串模板模式-templateparsercontext)
  - [5.3 StandardEvaluationContext](#53-standardevaluationcontext)
  - [5.4 设置值与类型转换](#54-设置值与类型转换)
  - [5.5 SpelParserConfiguration](#55-spelparserconfiguration)
- [6. 高级特性](#6-高级特性)
  - [6.1 集合选择 Selection](#61-集合选择-selection)
  - [6.2 集合投影 Projection](#62-集合投影-projection)
  - [6.3 类型引用 T() 与构造函数 new](#63-类型引用-t-与构造函数-new)
  - [6.4 变量、#this 与 #root](#64-变量this-与-root)
  - [6.5 安全导航运算符 ?\.](#65-安全导航运算符-)
  - [6.6 自定义函数 registerFunction](#66-自定义函数-registerfunction)
- [7. 实战场景](#7-实战场景)
  - [7.1 配置文件动态注入](#71-配置文件动态注入)
  - [7.2 Spring Security 权限控制](#72-spring-security-权限控制)
  - [7.3 自定义工具类](#73-自定义工具类)
  - [7.4 Spring Cache 缓存键与条件](#74-spring-cache-缓存键与条件)
- [8. 性能与安全](#8-性能与安全)
  - [8.1 表达式解析与执行缓存](#81-表达式解析与执行缓存)
  - [8.2 SpEL 注入风险](#82-spel-注入风险)
  - [8.3 SimpleEvaluationContext 沙箱](#83-simpleevaluationcontext-沙箱)
- [9. 常见问题 FAQ](#9-常见问题-faq)
- [10. 总结与扩展阅读](#10-总结与扩展阅读)

---

## 1. 前言与概述

### 1.1 什么是 SpEL

Spring Expression Language（简称 SpEL）是 Spring 3.0 引入的一种**功能强大的表达式语言**，支持在运行时查询和操作对象图。

它的语法与 OGNL、JSF EL 类似，但额外提供了：

- **方法调用**
- **字符串模板**
- **集合操作（选择、投影）**
- **类型引用与构造函数**
- **Bean 引用**

SpEL 既可以独立使用（通过 `SpelExpressionParser` API），也可以与 Spring 框架深度集成，用于：

- XML / Java Config 中的 Bean 配置
- `@Value` 注解动态注入
- `@PreAuthorize` / `@PostFilter` 等 Spring Security 表达式
- 数据校验、规则引擎等业务场景

### 1.2 为什么需要 SpEL

没有 SpEL 之前，Bean 的属性往往是**静态的**：

```java
@Value("John")
private String name;
```

有了 SpEL，我们可以做到**动态计算**：

```java
@Value("#{systemProperties['user.name']}")  // 引用系统属性
private String currentUser;

@Value("#{userService.getDefaultName() ?: 'Anonymous'}")  // 方法调用 + Elvis 兜底
private String displayName;
```

SpEL 让 Spring 的配置从“写死”走向了“可编程”。

### 1.3 核心特性一览

| 特性 | 示例 | 说明 |
|------|------|------|
| 字面量 | `'Hello'`、`42`、`3.14`、`true` | 支持字符串、数字、布尔、null |
| 算术运算 | `#{1 + 2 * 3}` | `+ - * / % ^ div mod` |
| 关系运算 | `#{1 < 2}` | `== != < > <= >=` 及字母别名 `eq lt gt` |
| 逻辑运算 | `#{a and b}` | `and or not` |
| 三元 / Elvis | `#{a ?: 'default'}` | 简化空值处理 |
| 正则 | `#{'abc' matches '[a-z]+'}` | `matches` 运算符 |
| 集合选择 | `#{list.?[age > 18]}` | `?[expr]` |
| 集合投影 | `#{list.![name]}` | `![expr]` |
| 类型引用 | `#{T(Math).PI}` | 调用静态方法、访问常量 |
| 构造函数 | `#{new String('hi')}` | 任意对象实例化 |
| Bean 引用 | `#{myBean.field}` | 引用 IOC 容器中的 Bean |
| 安全导航 | `#{user?.name}` | null 安全 |
| 模板 | `#{'Hello ${name}'}` | 字符串插值（需 `#{}` 内嵌） |

---

## 2. 环境准备

### 2.1 引入依赖

SpEL 是 `spring-core` 模块的一部分，**只要使用 Spring 就自带**，无需额外依赖。

**Maven**：

```xml
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-core</artifactId>
    <version>6.1.x</version>
</dependency>
<!-- 仅独立使用 SpEL 时需要 -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-expression</artifactId>
    <version>6.1.x</version>
</dependency>
```

**Gradle**：

```groovy
implementation 'org.springframework:spring-core:6.1.x'
```

**Spring Boot 用户**：

```groovy
// build.gradle
dependencies {
    implementation 'org.springframework.boot:spring-boot-starter'
}
```

### 2.2 表达式占位符语法

SpEL 在 Spring 中有两种调用方式：

| 语法 | 用途 |
|------|------|
| `#{expression}` | 真正的 SpEL 表达式 |
| `${property.name}` | 属性占位符（来自 properties / yaml） |

两者可以**互相嵌套**：

```java
@Value("#{${server.port} + 1000}")
private int adminPort;
```

注意：属性占位符中**不能再嵌入 SpEL**，但 SpEL 中可以引用属性：

```java
@Value("#{T(Integer).parseInt('${server.port}') + 1}")
private int nextPort;
```

---

## 3. 基础运算符

### 3.1 算术运算符

所有基本算术运算都支持，并且都提供**字母别名**（便于 XML 配置使用）。

```java
@Value("#{19 + 1}")            
private double add;          // 20

@Value("#{'Hi ' + 'SpEL'}")    
private String addString;    // "Hi SpEL"

@Value("#{20 - 1}")            
private double subtract;     // 19

@Value("#{10 * 2}")            
private double multiply;     // 20

@Value("#{36 / 2}")            
private double divide;       // 18

@Value("#{36 div 2}")          
private double divideAlpha;  // 18

@Value("#{37 % 10}")           
private double modulo;       // 7

@Value("#{37 mod 10}")         
private double moduloAlpha;  // 7

@Value("#{2 ^ 9}")             
private double power;        // 512

@Value("#{(2 + 2) * 2 + 9}")   
private double brackets;     // 17
```

要点：

- `+` 可用于**字符串拼接**：`#{'A' + 'B'}` → `"AB"`
- `div` 等同于 `/`，`mod` 等同于 `%`
- `^` 是**幂运算**（Java 没有原生运算符，SpEL 特有）
- 括号用于**控制优先级**

### 3.2 关系运算符

```java
@Value("#{1 == 1}") 	
private boolean equal;          		// true

@Value("#{1 eq 1}")  	
private boolean equalAlpha;    			// true

@Value("#{1 != 1}") 	
private boolean notEqual;       		// false

@Value("#{1 ne 1}")  	
private boolean notEqualAlpha; 			// false

@Value("#{1 < 1}")   	
private boolean lessThan;      			// false

@Value("#{1 lt 1}")  	
private boolean lessThanAlpha; 			// false

@Value("#{1 <= 1}")  	
private boolean lessOrEqual;   			// true

@Value("#{1 le 1}")  	
private boolean lessOrEqualAlpha; 		// true

@Value("#{1 >= 1}")  	
private boolean greaterOrEqual; 		// true

@Value("#{1 ge 1}")  	
private boolean greaterOrEqualAlpha; 	// true
```

> **为什么需要字母别名？** XML 中 `<` 和 `>` 是保留字符，不能直接使用，必须用 `lt` / `gt` / `le` / `ge` / `eq` / `ne`。

### 3.3 逻辑运算符

```java
@Value("#{250 > 200 && 200 < 4000}") 	
private boolean and;     					// true

@Value("#{250 > 200 and 200 < 4000}") 	
private boolean andAlpha; 					// true

@Value("#{400 > 300 || 150 < 100}")   	
private boolean or;      					// true

@Value("#{400 > 300 or 150 < 100}")   	
private boolean orAlpha; 					// true

@Value("#{!true}")                     	
private boolean not;     					// false

@Value("#{not true}")                  	
private boolean notAlpha; 					// false
```

### 3.4 条件运算符与 Elvis

**三元运算符**：

```java
@Value("#{2 > 1 ? 'a' : 'b'}") 
private String ternary; // "a"

// 经典模式：null 时使用默认值
@Value("#{user.name != null ? user.name : 'Anonymous'}")
private String displayName;
```

**Elvis 运算符**（`?:`）：**Groovy** 中的命名，能将“判断 null + 取值”两步合并：

```java
@Value("#{user.name ?: 'Anonymous'}")
private String elvis;  // 当 user.name 为 null 时使用 'Anonymous'
```

> Elvis 不等同于 `?:` 的合并含义。SpEL 中 `?:` 只表示：**当左侧不为 null 时返回左侧，否则返回右侧**。

### 3.5 正则表达式 matches

`matches` 运算符用于判断字符串是否匹配某个正则：

```java
@Value("#{'100' matches '\\d+'}")                       
private boolean isDigit;     // true

@Value("#{'100fghdjf' matches '\\d+'}")                  
private boolean isNotDigit;  // false

@Value("#{'valid alphabetic string' matches '[a-zA-Z\\s]+'}")
private boolean isAlpha;     // true

@Value("#{'invalid #$1' matches '[a-zA-Z\\s]+'}")
private boolean isNotAlpha;  // false
```

**注意反斜杠转义**：Java 字符串中 `\\d` 才是真正的 `\d`（正则里的数字字符）。

---

## 4. Bean 引用与上下文

### 4.1 在 XML 中引用 Bean

```java
public class Engine {
    private int capacity;
    private int horsePower;
    private int numberOfCylinders;
    // getters / setters
}

public class Car {
    private String make;
    private int model;
    private Engine engine;
    private int horsePower;
    // getters / setters
}
```

`applicationContext.xml`：

```xml
<bean id="engine" class="com.example.spel.Engine">
    <property name="capacity"         value="3200"/>
    <property name="horsePower"       value="250"/>
    <property name="numberOfCylinders" value="6"/>
</bean>

<bean id="someCar" class="com.example.spel.Car">
    <property name="make"      value="Some make"/>
    <property name="model"     value="Some model"/>
    <property name="engine"    value="#{engine}"/>          <!-- Bean 引用 -->
    <property name="horsePower" value="#{engine.horsePower}"/> <!-- 访问属性 -->
</bean>
```

### 4.2 在 @Value 注解中引用 Bean

```java
@Component
public class CarService {

    @Value("#{engine.horsePower}")   // 直接注入 engine Bean 的 horsePower 字段
    private int power;
}
```

**结合属性占位符**：

```java
@Value("#{T(Integer).parseInt('${app.max-size:100}')}")
private int maxSize;
```

### 4.3 访问 List 和 Map

定义一个数据 Bean：

```java
@Component("workersHolder")
public class WorkersHolder {
    private List<String> workers = new LinkedList<>();
    private Map<String, Integer> salaryByWorkers = new HashMap<>();

    public WorkersHolder() {
        workers.add("John");
        workers.add("Susie");
        workers.add("Alex");
        workers.add("George");

        salaryByWorkers.put("John",   35000);
        salaryByWorkers.put("Susie",  47000);
        salaryByWorkers.put("Alex",   12000);
        salaryByWorkers.put("George", 14000);
    }

    // getters / setters
}
```

SpEL 访问：

```java
@Value("#{workersHolder.salaryByWorkers['John']}")   
private Integer johnSalary;    // 35000

@Value("#{workersHolder.salaryByWorkers['Susie']}")  
private Integer susieSalary;   // 47000

@Value("#{workersHolder.workers[0]}")                
private String firstWorker;    // "John"

@Value("#{workersHolder.workers[3]}")                
private String lastWorker;     // "George"

@Value("#{workersHolder.workers.size()}")            
private Integer numberOfWorkers; // 4
```

要点：

- `bean.list[i]` 取下标
- `bean.map[key]` 取键
- `bean.list.size()` 调方法
- 链式访问：`workersHolder.salaryByWorkers['John']`

---

## 5. 编程方式解析表达式

### 5.1 SpelExpressionParser 基础用法

在配置之外使用 SpEL 同样简单：

```java
ExpressionParser parser = new SpelExpressionParser();

// 1. 字面量
Expression exp = parser.parseExpression("'Any string'");
String result = (String) exp.getValue();  // "Any string"

// 2. 方法调用
Expression exp2 = parser.parseExpression("'Any string'.length()");
Integer len = (Integer) exp2.getValue();  // 10

// 3. 构造函数
Expression exp3 = parser.parseExpression("new String('Any string').length()");

// 4. 属性访问
Expression exp4 = parser.parseExpression("'Any string'.bytes");
byte[] bytes = (byte[]) exp4.getValue();  // 字符串的 byte[]

// 5. 方法链
Expression exp5 = parser.parseExpression("'Any string'.replace(\" \", \"\").length()");
Integer noSpaceLen = (Integer) exp5.getValue();  // 9
```

**避免类型转换**：使用泛型版本 `getValue(Class)`：

```java
Integer result = expression.getValue(Integer.class);
```

> 如果返回值不能转换为目标类型，会抛出 `EvaluationException`。

### 5.2 字符串模板模式 TemplateParserContext

`parseExpression` 的**第二个参数**是 `ParserContext`，用来改变默认的解析行为。`SpEL` 内置了 `TemplateParserContext`，让表达式可以在**普通文本字符串**中工作，模板边界语法是 `#{ ... }`。

**为什么需要它？** 默认情况下，整个字符串就是表达式，文本字面量必须用引号包裹。如果想在文本里**嵌入**多个表达式插值，就必须用模板模式。

**最简单的例子**：

```java
ExpressionParser parser = new SpelExpressionParser();

// 注意：第二个参数传入 TemplateParserContext
Expression exp = parser.parseExpression(
    "Hello, #{'World'}!",                       // 表达式片段用 #{...} 包裹
    new TemplateParserContext()
);

String result = (String) exp.getValue();      // "Hello, World!"
```

**自定义边界符号**（默认前缀 `#{` / 后缀 `}`，可通过构造器替换）：

```java
// TemplateParserContext(prefix, suffix) 构造器
Expression exp = parser.parseExpression(
    "随机数: ${T(java.lang.Math).random()}",
    new TemplateParserContext("${", "}")       // 把表达式边界改为 ${...}
);

String result = (String) exp.getValue();      // 形如 "随机数: 0.7234..."
```

**实战用法——在文本中引用变量**：

```java
User user = new User("Alice", 25);

StandardEvaluationContext context = new StandardEvaluationContext(user);
context.setVariable("name", user.getName());
context.setVariable("age",  user.getAge());

String template = "用户 #{#name} 今年 #{#age} 岁，明年生日就 #{#age + 1} 啦。";
Expression exp = parser.parseExpression(template, new TemplateParserContext());

String greeting = (String) exp.getValue(context);
// "用户 Alice 今年 25 岁，明年生日就 26 啦。"
```

**关键差异对比**：

| 项 | 默认模式（无 ParserContext） | 模板模式（TemplateParserContext） |
|----|----------------------------|-----------------------------------|
| 表达式边界 | 整段字符串就是表达式 | 字符串中的 `#{...}` 片段 |
| 字面量文本 | 必须用引号 `'...'` 包裹 | 可以直接写文字 |
| 自定义边界 | 不支持 | `new TemplateParserContext(prefix, suffix)` |
| 多个表达式插值 | 需用 `+` 拼接 | 同一文本里多个 `#{...}` |
| 典型用途 | 纯计算、属性注入 | 字符串模板、日志、消息拼接、动态 SQL 文案 |

**与 `@Value` 的关系**：Spring 的 `@Value` 默认**不开启**模板模式（`@Value` 内部把整段当作 SpEL 处理）。要真正使用模板语法，需要通过 `ExpressionParser` API 自己解析，或借助 `PropertyPlaceholderHelper` 等工具链。

### 5.3 StandardEvaluationContext

**针对特定对象计算**：

```java
Car car = new Car();
car.setMake("Good manufacturer");
car.setModel("Model 3");
car.setYearOfProduction(2014);

ExpressionParser parser = new SpelExpressionParser();
Expression exp = parser.parseExpression("model");

// 指定根对象
EvaluationContext context = new StandardEvaluationContext(car);
String model = (String) exp.getValue(context);  // "Model 3"
```

**省略 context（不推荐）**：

```java
String model = (String) exp.getValue(car);
```

**复用 context 提升性能**：`StandardEvaluationContext` 创建后**不能修改根对象**，但内部会构建缓存，重复使用同一实例可以**让后续表达式计算更快**。

```java
// 推荐：复用
StandardEvaluationContext context = new StandardEvaluationContext(car);
parser.parseExpression("model").getValue(context);
parser.parseExpression("make").getValue(context);

// 如果根对象会变，每次新建或使用单参数 getValue(根对象)
```

### 5.4 设置值与类型转换

`setValue` 可以直接修改对象属性，SpEL 会**自动处理类型转换**（基于 `ConversionService`）：

```java
@Component
public class CarPark {
    private List<Car> cars = new ArrayList<>();
    public List<Car> getCars() { return cars; }
    public void setCars(List<Car> cars) { this.cars = cars; }
}

// 演示
Car car = new Car();
car.setMake("Good manufacturer");
car.setModel("Model 3");
car.setYearOfProduction(2014);

CarPark carPark = new CarPark();
carPark.getCars().add(car);

StandardEvaluationContext context = new StandardEvaluationContext(carPark);
ExpressionParser parser = new SpelExpressionParser();

// 修改 cars[0].model
parser.parseExpression("cars[0].model").setValue(context, "Other model");

System.out.println(car.getModel());  // "Other model"
```

### 5.5 SpelParserConfiguration

默认情况下，给一个不存在的下标赋值会抛出异常：

```
EL1025E: (pos 4): The collection has '0' elements, index '0' is invalid
```

通过 `SpelParserConfiguration` 开启**自动增长**：

```java
SpelParserConfiguration config = new SpelParserConfiguration(true, true);
StandardEvaluationContext context = new StandardEvaluationContext(carPark);
ExpressionParser parser = new SpelExpressionParser(config);

// autoGrowNullReferences = true
// autoGrowCollections    = true
parser.parseExpression("cars[0]").setValue(context, car);

Car first = carPark.getCars().get(0);  // 刚刚插入的 car
```

参数说明：

| 参数 | 作用 |
|------|------|
| `autoGrowNullReferences` | 索引位置为 null 时自动创建元素 |
| `autoGrowCollections` | 自动扩容集合 / 数组以容纳新元素 |

---

## 6. 高级特性

### 6.1 集合选择 Selection

语法：`collection.?[condition]`

**需求**：从 `List<Integer>` 中选出所有奇数。

```java
List<Integer> numbers = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);

ExpressionParser parser = new SpelExpressionParser();
Expression exp = parser.parseExpression("#root.?[#this % 2 == 1]");

List<Integer> odds = (List<Integer>) exp.getValue(numbers);
// [1, 3, 5, 7, 9]
```

> `#this` 代表集合中**当前正在遍历的元素**。

**对象集合筛选**：

```java
public class User {
    private String name;
    private int age;
    private List<String> interests;
    // getters / setters
}

User alice = new User("Alice", 25, List.of("Music", "Basketball"));
User bob   = new User("Bob",   17, List.of("Football"));
User carol = new User("Carol", 30, List.of("TennisBall", "Piano"));

List<User> users = List.of(alice, bob, carol);

// 选出成年人
List<User> adults = (List<User>) parser
    .parseExpression("?[#this.age >= 18]")
    .getValue(users);
// [Alice, Carol]

// 选出名字以 'B' 开头的
List<User> bUsers = (List<User>) parser
    .parseExpression("?[#this.name.startsWith('B')]")
    .getValue(users);
// [Bob]
```

### 6.2 集合投影 Projection

语法：`collection.![projectionExpression]`

把集合里**每个元素的某部分**抽出来组成新集合。

```java
// 抽出所有名字
List<String> names = (List<String>) parser
    .parseExpression("![name]")
    .getValue(users);
// [Alice, Bob, Carol]

// 计算每个人名字的长度
List<Integer> nameLengths = (List<Integer>) parser
    .parseExpression("![name.length()]")
    .getValue(users);
// [5, 3, 5]
```

**和 Selection 组合**：

```java
// 选出成年人，再取名字
List<String> adultNames = (List<String>) parser
    .parseExpression("?[#this.age >= 18].![name]")
    .getValue(users);
// [Alice, Carol]
```

**Map 投影**：对 Map 使用 `![key]` / `![value]` 投影键值。

```java
Map<String, Integer> map = Map.of("a", 1, "b", 2, "c", 3);
List<String> keys   = (List<String>) parser.parseExpression("![key]").getValue(map);
List<Integer> values = (List<Integer>) parser.parseExpression("![value]").getValue(map);
```

### 6.3 类型引用 T() 与构造函数 new

**`T(Class)` 引用 Java 类型**：

```java
@Value("#{T(java.lang.Math).PI}")   
private double pi;        // 3.14159...

@Value("#{T(Math).PI}")             
private double piShort;   // 同上，java.lang 可省略

@Value("#{T(Integer).MAX_VALUE}")   
private long maxInt;      // 2147483647

@Value("#{T(System).currentTimeMillis()}")
private long now;  // 当前时间戳
```

注意：除了 `java.lang` 包，其他类型必须写**全限定名**。

**`new` 构造对象**：

```java
Expression exp = parser.parseExpression("new String('Hello SpEL').toUpperCase()");
String result = (String) exp.getValue();  // "HELLO SPEL"
```

**应用**：在 `@Value` 中实例化对象：

```java
@Value("#{new java.text.SimpleDateFormat('yyyy-MM-dd').parse('2026-08-10')}")
private Date specificDate;
```

### 6.4 变量、#this 与 #root

**#root**：上下文根对象。

**#this**：当前正在评估的对象（在集合遍历中等价于每个元素）。

```java
parser.parseExpression("#root.?[#this > 5]").getValue(List.of(1, 3, 5, 7, 9));
```

**自定义变量**：

```java
SimpleEvaluationContext context = SimpleEvaluationContext.forReadWriteDataBinding().build();
context.setVariable("today", LocalDate.now());
context.setVariable("threshold", 18);

String msg = (String) parser
    .parseExpression("'Today is ' + #today + ', age threshold = ' + #threshold")
    .getValue(context);
```

### 6.5 安全导航运算符 ?.

避免空指针：

```java
@Value("#{user?.name}")   // user 为 null 时返回 null，不抛 NPE
private String userName;
```

等价于：

```java
@Value("#{user == null ? null : user.name}")
private String userName;
```

### 6.6 自定义函数 registerFunction

**推荐用 `registerFunction`**（比 `setVariable` 更明确），底层绑定的是一个 `Method`：

```java
public class StringUtils {
    public static String reverse(String input) {
        return new StringBuilder(input).reverse().toString();
    }
}

// 在 SpEL 中使用 reverse('Hello')
Method reverseMethod = ... // 反射获取 StringUtils.reverse
StandardEvaluationContext context = new StandardEvaluationContext();
context.registerFunction("reverse", reverseMethod);

ExpressionParser parser = new SpelExpressionParser();
String result = (String) parser
    .parseExpression("#reverse('Hello')")
    .getValue(context);
// "olleH"
```

> `setVariable("reverse", ...)` 也可以实现类似效果，但语义上是“变量”而不是“函数”。`registerFunction` 才是官方推荐做法。

---

## 7. 实战场景

### 7.1 配置文件动态注入

`application.yml`：

```yaml
app:
  max-size: 200
  whitelist: alice,bob,carol
  rate-limit:
    qps: 100
    burst: 200
```

注入：

```java
@Component
public class AppConfig {

    @Value("#{T(Integer).parseInt('${app.max-size:100}')}")
    private int maxSize;

    @Value("#{'${app.whitelist}'.split(',')}")
    private String[] whitelist;

    @Value("#{${app.rate-limit.qps} * 2}")
    private int doubledQps;

    @Value("#{${app.rate-limit.burst} > ${app.rate-limit.qps} ? 'OK' : 'INVALID'}")
    private String burstStatus;
}
```

### 7.2 Spring Security 权限控制

```java
@Configuration
@EnableMethodSecurity
public class SecurityConfig { }

@Service
public class DocumentService {

    // 仅 ADMIN 可访问
    @PreAuthorize("hasRole('ADMIN')")
    public void delete(Long id) { /* ... */ }

    // 拥有读权限或者资源 owner
    @PreAuthorize("hasAuthority('doc:read') or #userId == authentication.principal.id")
    public Document get(Long docId, Long userId) { /* ... */ }

    // 过滤返回值，只保留当前用户可访问的部分
    @PostFilter("filterObject.owner == authentication.principal.username")
    public List<Document> findAll() { /* ... */ }
}
```

SpEL 在 Security 中可直接访问：

- `authentication`：当前认证对象
- `principal`：登录用户（通常是 `UserDetails`）
- `#参数名`：方法参数（如 `#userId`）
- `filterObject`：集合中的当前元素（`@PostFilter`）
- 内置函数：`hasRole()` / `hasAuthority()` / `hasAnyRole()` / `isAuthenticated()` / `denyAll()`

### 7.3 自定义工具类

**需求**：根据一个 SpEL 表达式，从一个对象中动态取值。

```java
public class SpelExtractor {

    private final SpelExpressionParser parser = new SpelExpressionParser();

    public <T> T extract(Object root, String expression, Class<T> desiredType) {
        Expression exp = parser.parseExpression(expression);
        EvaluationContext context = new StandardEvaluationContext(root);
        return exp.getValue(context, desiredType);
    }
}

// 使用
SpelExtractor extractor = new SpelExtractor();
String name = extractor.extract(user, "name", String.class);
List<String> tags = extractor.extract(article, "tags.![title]", List.class);
```

### 7.4 Spring Cache 缓存键与条件

`@Cacheable` / `@CacheEvict` / `@CachePut` 等注解的 `key`、`condition`、`unless` 都是 **SpEL 表达式**。Spring Cache 提供了专门的元数据上下文，让我们能在表达式里访问方法、参数、返回结果。

**启用缓存**：

```java
@Configuration
@EnableCaching
public class CacheConfig { }
```

**1) 用 `#参数名` 拼装缓存 key**

```java
@Service
public class BookService {

    // key = 方法参数 id
    @Cacheable(cacheNames = "book", key = "#id")
    public Book findById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    // 组合参数：使用复合 key
    @Cacheable(cacheNames = "book", key = "#author + ':' + #title")
    public Book findByAuthorAndTitle(String author, String title) {
        return bookRepository.findByAuthorAndTitle(author, title);
    }
}
```

**2) 用 `#root` 访问方法元信息**

`#root` 在缓存场景下提供以下属性：

| 属性 | 含义 |
|------|------|
| `#root.method` | 当前 `Method` 对象 |
| `#root.methodName` | 方法名 |
| `#root.target` | 目标对象（被代理的 Bean） |
| `#root.targetClass` | 目标对象的 Class |
| `#root.args` | 所有参数的数组 |
| `#root.caches` | 当前方法关联的 `Cache` 集合 |

```java
// key = 类名 + 方法名 + 第一个参数
@Cacheable(cacheNames = "calc", key = "#root.targetClass.simpleName + ':' + #root.methodName + ':' + #a0")
public BigInteger factorial(int n) { /* ... */ }

// args[0] 写法等价于 #a0 / #p0（参数索引）
@Cacheable(cacheNames = "calc", key = "#root.args[0]")
public BigInteger square(int n) { /* ... */ }
```

**3) `condition`：方法执行前判断（满足才进缓存）**

```java
// 只有当书名长度 < 32 时才缓存
@Cacheable(cacheNames = "book", key = "#name", condition = "#name.length() < 32")
public Book findByName(String name) { /* ... */ }

// 跳过 null 入参
@Cacheable(cacheNames = "user", key = "#user.id", condition = "#user != null")
public User load(UserQuery user) { /* ... */ }
```

**4) `unless`：方法执行后判断（满足则否决缓存）**

`#result` 指向**方法返回值**本身。**注意：对于 `Optional<T>` 返回值，`#result` 指向的是 `T` 而不是 `Optional`**。

```java
// null 结果不缓存（业务上不缓存无效查找）
@Cacheable(cacheNames = "book", key = "#id", unless = "#result == null")
public Book findById(Long id) { /* ... */ }

// 只缓存平装书（hardback=false 的才进缓存）
@Cacheable(
    cacheNames = "book",
    key      = "#name",
    condition = "#name.length() < 32",
    unless   = "#result?.hardback"   // #result 可能为 null，用 ?. 安全导航
)
public Optional<Book> findBook(String name) { /* ... */ }
```

**5) `@CacheEvict` 用 SpEL 动态 key**

```java
// 更新某本书后清掉它的缓存
@CacheEvict(cacheNames = "book", key = "#book.id")
public Book update(Book book) { /* ... */ }

// 清空整个 cacheNames 下所有 key
@CacheEvict(cacheNames = "book", allEntries = true)
public void reloadAll() { /* ... */ }
```

**6) `@CachePut`：用 SpEL 保证 key 与读侧一致**

`@CachePut` 每次都会执行方法并**用返回值覆盖缓存**，所以 `key` 必须和 `@Cacheable` 一致：

```java
@CachePut(cacheNames = "user", key = "#user.id")
public User update(User user) {
    return userRepository.save(user);
}
```

**7) 完整业务示例**

```java
@Service
public class ProductService {

    // 读：按 id 缓存，null 结果不缓存
    @Cacheable(
        cacheNames = "product",
        key       = "#id",
        unless    = "#result == null"
    )
    public Product findById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    // 列表查询：分页参数 + 关键字组合 key
    @Cacheable(
        cacheNames = "productList",
        key       = "#keyword + ':' + #page + ':' + #size",
        condition = "#keyword != null and #keyword.length() > 0"
    )
    public Page<Product> search(String keyword, int page, int size) {
        return productRepository.search(keyword, PageRequest.of(page, size));
    }

    // 写：更新并覆盖缓存
    @CachePut(cacheNames = "product", key = "#product.id")
    public Product update(Product product) {
        return productRepository.save(product);
    }

    // 写：删除并清缓存
    @CacheEvict(cacheNames = "product", key = "#id")
    public void delete(Long id) {
        productRepository.deleteById(id);
    }
}
```

**常见坑**：

1. **编译必须加 `-parameters`**：表达式中 `#参数名` 依赖参数名，编译时不加 `-parameters` 会被改成 `#a0` / `#p0`（按位置访问）。Spring 6.1 起若 `key` 因 `null` 参数名计算成 `null`，会抛 `IllegalArgumentException`；但**如果 key 是包含 null 的列表则会静默失败**——所以务必加 `-parameters`。
   - Maven：`<configuration><compilerArgs><arg>-parameters</arg></compilerArgs></configuration>`
   - Gradle：`compileJava { options.compilerArgs.add('-parameters') }`
   - Spring Boot 父工程默认已开启。

2. **`#result` 不能用于 `condition`**：`condition` 在方法执行前评估，此时 `#result` 还不存在。只能用 `unless` 引用返回值。

3. **`@CacheEvict` 默认在方法之后执行**：如果想在方法前清缓存，加 `beforeInvocation = true`。

4. **`unless` 拿到的 `Optional`**：当方法返回 `Optional<T>` 时，`#result` 是 `T`（可能为 `null`），需要用 `#result?.field` 访问其属性。

---

## 8. 性能与安全

### 8.1 表达式解析与执行缓存

`Expression` 对象**是无状态的、可复用的**。`parseExpression()` 内部会**自动缓存**已解析的表达式：

```java
// 第一次解析：会构造 AST
Expression exp1 = parser.parseExpression("name + '_' + age");

// 第二次：命中缓存，零成本
Expression exp2 = parser.parseExpression("name + '_' + age");
```

因此：

- **复用 `Expression` 对象**，不要每次 `parseExpression` 后立即 `getValue` 一次就丢弃
- 同样地，**复用 `StandardEvaluationContext`**（只要根对象不变）

### 8.2 SpEL 注入风险

当 SpEL 表达式中**包含用户输入**时，要极度小心——`T()`、`new`、`Runtime.exec()` 等都是危险的入口。

**危险示例**：

```java
@PostMapping("/calc")
public String calc(@RequestParam String expr) {
    ExpressionParser parser = new SpelExpressionParser();
    Expression exp = parser.parseExpression(expr);          // ← 用户输入直接拼进表达式
    return exp.getValue().toString();
}
// 攻击者传入: T(java.lang.Runtime).getRuntime().exec('rm -rf /')
// 默认 StandardEvaluationContext 拥有完整类访问权限 → RCE
```

**风险点**：

| 能力 | 默认 | 攻击场景 |
|------|------|----------|
| `T(Class)` 引用任意类 | 开启 | 加载 `Runtime` / `ProcessBuilder` |
| `new ClassName(...)` 构造 | 开启 | 实例化任意类 |
| Bean 引用 | 开启 | 触发未公开 Bean 的方法 |
| 属性 / 方法访问 | 开启 | 反射调用 `getClass()` 等 |

### 8.3 SimpleEvaluationContext 沙箱

处理**用户输入的 SpEL 表达式**时，使用 `SimpleEvaluationContext` 限制能力：

```java
// 只读、只允许数据绑定、不允许 Java 类型引用
SimpleEvaluationContext context = SimpleEvaluationContext
    .forReadOnlyDataBinding()
    .build();

Expression exp = parser.parseExpression("name + ' is ' + age");
String result = exp.getValue(context, user);

// 攻击者再传入 T(Runtime).exec(...) 也会抛 SpelEvaluationException
```

`SimpleEvaluationContext` 提供的工厂方法：

| 工厂 | 能力 |
|------|------|
| `forReadOnlyDataBinding()` | 只读 + 数据绑定（最安全） |
| `forReadWriteDataBinding()` | 可写 + 数据绑定 |
| `forPropertyAccessors(...)` | 自定义属性访问器 |

**核心原则**：

1. **任何来自用户输入的 SpEL 表达式** → 必须用 `SimpleEvaluationContext`
2. **任何未信任的 `@Value` / `@PreAuthorize` 字符串** → 不要用 `@Value` 等注解拼接，改为白名单枚举
3. **不要将 HTTP 参数拼到 SpEL 字符串里**

---

## 9. 常见问题 FAQ

**Q1：`#{}` 和 `${}` 的区别？**
- `${}`：属性占位符，读取 `application.properties` / yaml 等配置。
- `#{}`：真正的 SpEL 表达式，可以引用 Bean、调用方法、做运算。
- 可以嵌套：`#{${someProp} + 1}`，但 `${}` 内部**不能**再写 SpEL。

**Q2：为什么我的 `@Value("#{xxx}")` 注入失败？**
- 表达式语法错误（括号、引号不匹配）。
- 目标 Bean 不存在或未注册。
- 目标字段**没有 setter / 是 final**，SpEL 必须通过反射注入。
- 类型无法转换（如字符串到自定义对象）。

**Q3：SpEL 表达式里能调用 static 方法吗？**
- 可以，用 `T()` 包裹类名，例如 `T(java.util.UUID).randomUUID()`。

**Q4：如何对 SpEL 做单元测试？**
- 直接使用 `SpelExpressionParser`，传入测试对象验证结果。
- 配合 `@SpringBootTest` 验证 `@Value` 注入是否符合预期。

**Q5：`@PreAuthorize` 表达式里能调用自定义 Bean 的方法吗？**
- 可以。Bean 名称默认是首字母小写的类名，或 `@Component("name")` 指定的名称。
  ```java
  @PreAuthorize("@permissionService.canRead(#docId, authentication)")
  ```

**Q6：SpEL 性能如何？**
- 解析后执行很快，接近反射调用。
- 重复执行的场景务必**复用 Expression 对象**和 **EvaluationContext**。
- 高并发下，每次新建 `StandardEvaluationContext` 会触发缓存构建，**不要**这样用。

**Q7：能调用泛型方法吗？**
- 通过 `T()` 引用类后调用，SpEL 会在运行时处理泛型擦除：
  ```java
  T(java.util.Collections).emptyList()
  ```

---

## 10. 总结与扩展阅读

### 关键要点回顾

1. **SpEL = 运行时表达式引擎**，能访问对象图、调用方法、做运算。
2. 在 Spring 中**两种语法**：`#{expression}` 和 `${property}`，可嵌套。
3. 算术 / 关系 / 逻辑 / 三元 / Elvis / matches 运算符全部支持，XML 中记得用字母别名。
4. **集合选择 `?[]`** 与 **投影 `![]`** 是 SpEL 的杀手锏。
5. 编程式使用：`SpelExpressionParser` + `StandardEvaluationContext`，**复用对象以提升性能**。
6. **安全第一**：用户输入的 SpEL 表达式必须用 `SimpleEvaluationContext` 沙箱化。

### 下一步学习方向

- 深入阅读 **Spring Framework Reference** 的 Expression Language 章节
- 研究 **SpEL 编译模式**（`SpelCompilerMode`，Spring 4.3+ 引入的 JIT 加速）
- 学习 **Spring Integration** 中的 SpEL 用法（`@Router`、`@Transformer` 等）
- 了解 **Spring Security** 中 `@PostAuthorize`、`@PreFilter` 等更复杂的 SpEL 用法

### 扩展阅读

- [Baeldung 中文网 - Spring 表达式语言指南](https://www.baeldung-cn.com/spring-expression-language) — 本文主线参考
- [Spring Framework Reference - Expression Language](https://docs.spring.io/spring-framework/docs/3.2.x/spring-framework-reference/html/expressions.html) — 官方权威
- [Spring Framework Reference - Declarative Annotation-based Caching](https://docs.spring.io/spring-framework/reference/integration/cache/annotations.html) — SpEL 在 `@Cacheable` 中的官方说明（含 `#root` / `#result` 元数据表）
- [Spring Security - Method Security](https://docs.spring.io/spring-security/reference/servlet/authorization/method-security.html) — SpEL 在权限控制中的应用
- [DZone - Beginner's Guide to SpEL with Spring Boot](https://dzone.com/articles/beginners-guide-to-spring-expression-language-with) — 入门实战
- [Understanding SpEL: The Hidden Power Inside Spring](https://medium.com/@ayoubtaouam/understanding-spring-expression-language-spel-the-hidden-power-inside-spring-065e357e07bd) — 进阶视角
- [SpEL Injection Cheat Sheet](https://0xn3ba.gitbook.io/cheat-sheets/framework/spring/spel-injection) — 安全反面教材
