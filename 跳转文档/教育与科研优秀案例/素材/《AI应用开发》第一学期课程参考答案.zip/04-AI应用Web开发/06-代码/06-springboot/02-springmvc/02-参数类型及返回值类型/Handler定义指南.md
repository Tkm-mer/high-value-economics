# Handler 定义指南

## 一、Spring MVC 的 Controller 参数都可以是哪些类型？

Spring MVC 的 Controller 方法签名非常灵活，支持多种参数类型。框架会自动将 HTTP 请求中的信息（如参数、头信息、请求体等）转换并注入到这些参数中。

### 📝 Controller 方法参数类型速查表

| 类别                 | 参数类型 / 注解                             | 描述与用途                                                   |
| :------------------- | :------------------------------------------ | :----------------------------------------------------------- |
| **Servlet API 对象** | `HttpServletRequest`, `HttpServletResponse` | 直接访问原生的请求和响应对象。                               |
|                      | `HttpSession`                               | 访问 HTTP 会话。注意，此参数**永不为 null**，会强制创建一个会话。 |
|                      | `WebRequest`, `NativeWebRequest`            | Spring 提供的通用请求访问接口，无需直接使用 Servlet API。    |
| **输入/输出流**      | `InputStream` / `Reader`                    | 获取原始的请求体（Request Body）。                           |
|                      | `OutputStream` / `Writer`                   | 直接向响应体（Response Body）写入原始数据。                  |
| **请求内容绑定**     | `@RequestParam`                             | 绑定单个 HTTP 请求参数（如查询参数或表单数据）。对于非字符串类型的参数，Spring 会自动进行类型转换。 |
|                      | `@PathVariable`                             | 绑定 URL 模板中的变量值，如 `/users/{id}` 中的 `id`。        |
|                      | `@RequestHeader`                            | 绑定 HTTP 请求头（Header）的值。                             |
|                      | `@CookieValue`                              | 绑定 HTTP Cookie 的值。                                      |
|                      | `@MatrixVariable`                           | 绑定 URL 路径段中的键值对（Matrix 变量），如 `/cars;color=red;year=2022`。 |
|                      | `@RequestBody`                              | 将 HTTP 请求体（如 JSON 或 XML）反序列化为 Java 对象。       |
|                      | `@RequestPart`                              | 访问 `multipart/form-data` 请求中的一部分（如表单字段或文件）。 |
| **数据模型**         | `Model`, `ModelMap`, `Map`                  | 向视图中添加数据，用于页面渲染。                             |
|                      | `@ModelAttribute`                           | 将请求参数绑定到一个 Java 对象（POJO）上。此注解在复杂对象参数上通常是可选的。 |
|                      | `RedirectAttributes`                        | 用于重定向时传递参数，包括 URL 查询参数和 Flash 属性（临时存储）。 |
| **校验与状态**       | `Errors`, `BindingResult`                   | 获取数据绑定或校验（如 `@Valid`）的结果。**必须紧跟在被校验的参数之后声明**。 |
|                      | `SessionStatus`                             | 配合 `@SessionAttributes` 使用，用于标记会话属性的清理。     |
| **安全与上下文**     | `java.security.Principal`                   | 获取当前已认证的用户信息。                                   |
|                      | `Locale`, `TimeZone` / `ZoneId`             | 获取当前请求的本地化信息（如语言、时区）。                   |
|                      | `HttpMethod`                                | 获取当前请求的 HTTP 方法（GET、POST 等）。                   |
| **其他**             | `HttpEntity<B>`                             | 同时访问请求头和请求体。                                     |
|                      | `UriComponentsBuilder`                      | 用于构建相对于当前请求的 URL。                               |
|                      | `@SessionAttribute`                         | 访问已存的 Session 属性。                                    |
|                      | `@RequestAttribute`                         | 访问 Request 作用域内的属性。                                |
|                      | `PushBuilder`                               | Servlet 4.0+ 支持，用于 HTTP/2 的 Server Push。              |

### ⚙️ 自动参数解析规则

Spring MVC 有一套默认的参数解析逻辑。如果方法中的参数没有匹配到上述表格中的任何一项，则会按以下规则处理：

*   **简单类型**：如果参数是`int`、`long`、`String`、`Date`等“简单类型”，它会被自动当作一个 `@RequestParam` 来处理。
*   **复杂类型**：如果参数是普通的 Java 对象（POJO），它会被自动当作一个 `@ModelAttribute` 来处理，即框架会尝试将请求参数同名字段绑定到该对象的属性上。

### 📌 特别注意事项

*   **`@RequestParam` 是可选的**：对于简单类型的参数（如 `String name`），即使不添加 `@RequestParam` 注解，Spring 也会自动将其识别为请求参数。
*   **`@ModelAttribute` 也是可选的**：对于复杂对象参数（如 `User user`），Spring 也会自动使用 `@ModelAttribute` 逻辑进行绑定。
*   **`java.util.Optional`**：可以作为方法参数类型，与 `@RequestParam`、`@RequestHeader` 等注解配合使用，表示该参数是可选的，效果等同于 `required=false`。

总的来说，Spring MVC 提供了非常灵活的参数绑定机制，你可以根据业务需求自由组合使用。

## 二、返回值类型

与 Controller 方法参数类似，其返回值类型也非常灵活，主要可以归为两大类：**处理页面跳转（服务端渲染）** 和**直接响应数据（如RESTful API）**。

为了方便你查阅，我将主要的返回值类型整理成了下表：

### 📝 Controller 方法返回值类型速查表

| 类别                    | 返回值类型 / 注解                     | 描述与用途                                                   |
| :---------------------- | :------------------------------------ | :----------------------------------------------------------- |
| **视图/页面跳转**       | `String`                              | **最常用**，返回逻辑视图名称。由视图解析器（ViewResolver）解析为具体页面（如JSP）。支持 `redirect:` 或 `forward:` 前缀实现重定向或转发。 |
|                         | `View`                                | 直接返回一个 `View` 接口的实现类实例（如 `JstlView`、`FreeMarkerView`），用于渲染。 |
|                         | `ModelAndView`                        | 一个包含**视图**和**模型数据**的对象，可同时指定要跳转的页面和传递的数据。 |
|                         | `void` (配合`HttpServletResponse`)    | 方法本身不返回值，需通过 `HttpServletResponse` 对象**手动**控制响应输出，常用于文件下载等场景。 |
|                         | `Map` / `Model` / `ModelMap`          | 仅向模型（Model）中添加属性，视图名由 `RequestToViewNameTranslator` 根据请求URL **隐式**推断。 |
|                         | `@ModelAttribute`                     | 同 `Map`/`Model`，将返回值本身作为一个属性添加到模型中。     |
| **数据响应 (REST API)** | `@ResponseBody`                       | **核心注解**。将方法返回值通过 `HttpMessageConverter` **直接写入** HTTP 响应体（Body）。可返回任何 POJO，Spring 会自动转为 JSON/XML 等格式。 |
|                         | `HttpEntity<T>` / `ResponseEntity<T>` | 更灵活地控制整个HTTP响应，除了响应体外，还能**自定义**状态码（Status Code）和请求头（Headers）。 |
|                         | `HttpHeaders`                         | 仅返回HTTP头部信息，不包含响应体。                           |
|                         | `ErrorResponse` / `ProblemDetail`     | 用于生成符合**RFC 9457**规范的标准错误响应，包含错误详情。   |
| **异步处理**            | `DeferredResult<V>`                   | 使控制器方法可以异步处理请求，从其他线程返回结果。           |
|                         | `Callable<V>`                         | 另一种实现异步处理的方式，Spring MVC会将其提交给`TaskExecutor`执行。 |
|                         | 响应式类型 (Reactive)                 | 支持 `Flux`、`Mono`（Project Reactor）等，可**流式**返回数据，非常适合处理实时数据流。 |
| **其他**                | `void` (配合`@ResponseStatus`)        | 配合 `@ResponseStatus` 注解使用，表示方法已完全处理响应，仅返回一个**状态码**。 |

### 💡 关键点说明

*   **`@Controller` vs `@RestController`**：`@RestController` 是 `@Controller` 和 `@ResponseBody` 的组合注解。使用 `@RestController` 时，类中**所有**方法的返回值默认都会自动通过 `HttpMessageConverter` 写入响应体，无需再为每个方法添加 `@ResponseBody`。
*   **`String` 类型的双重身份**：返回 `String` 时，Spring MVC 会根据方法是否标注 `@ResponseBody` 来决定其含义：
    *   有 `@ResponseBody`：返回的字符串**直接**作为HTTP响应体的内容。
    *   无 `@ResponseBody`：返回的字符串被解释为**逻辑视图名**，用于页面跳转。

总的来说，选择哪种返回值类型，取决于你的应用场景：是传统的服务端渲染（选 String、ModelAndView 等），还是构建RESTful API（选 `@ResponseBody`、`ResponseEntity`等）。