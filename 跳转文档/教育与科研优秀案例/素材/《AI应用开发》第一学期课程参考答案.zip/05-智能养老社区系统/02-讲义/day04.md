# 《智能养老社区系统》- 学生讲义 - Day04：客房管理模块开发

**授课日：Day 04 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01-03 已完成——数据库表结构（含 `room_type`、`room_info` 两张表）、SpringBoot + MyBatis-Plus + Vue3 + Element Plus 骨架、Result/PageBean 统一封装、会员 CRUD 全流程（DTO/VO/Entity 分层、逻辑删除、Postman 联调）**

---

## 第 1 讲：客房数据模型与关联查询

### 1.1 本讲要点
- 理解客房与房型的多对一关系（一个客房只有一种房型，一种房型对应多间客房）
- 掌握 `LEFT JOIN` 语法与 `INNER JOIN` 的差别
- 理解 MyBatis XML 的 `<resultMap>` 用法：把 join 出来的多列映射为一个 Java 对象
- 掌握\"VO 冗余\"设计：`RoomVO` 在实体基础上追加 `typeName` / `typePrice`
- 熟悉 `status` 枚举含义（0 空闲 / 1 已预约 / 2 入住 / 3 维护）

### 1.2 知识点详解

#### 1.2.1 表结构回顾
```sql
CREATE TABLE room_type (
    id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    type_name    VARCHAR(50)  NOT NULL,
    price        DECIMAL(10,2) NOT NULL,
    capacity     INT NOT NULL,
    description  VARCHAR(255)
);

CREATE TABLE room_info (
    id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    room_no      VARCHAR(20)  NOT NULL UNIQUE,
    type_id      BIGINT NOT NULL,
    floor        INT,
    status       TINYINT DEFAULT 0,
    image_url    VARCHAR(255),
    create_time  DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

> 💡 **技巧：** `room_info.type_id` 只存 ID 不存 `type_name`，这样房型改名不会破坏历史数据。查询时用 JOIN 关联即可。

#### 1.2.2 LEFT JOIN 与 INNER JOIN 差别

| 类型 | 效果 | 示意 |
|------|------|------|
| INNER JOIN | 只保留两表都能匹配上的行 | room_info 的 type_id 找不到 room_type 时 → 该客房消失 |
| LEFT JOIN | 保留左表所有行，右表缺失字段用 NULL 填 | room_type 被删也不丢客房 |
| RIGHT JOIN | 保留右表所有行 | 反过来，不常用 |

> ⚠️ **注意：** 养老场景一律用 **LEFT JOIN**，避免房型偶尔被清理导致客房档案消失。

#### 1.2.3 RoomInfo（实体） vs RoomVO（视图对象）

| 类 | 用途 | 字段 |
|----|------|------|
| RoomInfo | 只映射 room_info 表 | id / roomNo / typeId / floor / status / imageUrl / createTime |
| RoomVO | 前端展示用，冗余房型信息 | 上述所有 + typeName + typePrice |

> 💡 **技巧：** \"实体只对应表、VO 只对应界面\"是分层设计的准则。**永远不要**把 RoomVO 拿去 insert 或 update。

#### 1.2.4 status 枚举

| 值 | 含义 | 触发场景 |
|----|------|----------|
| 0 | 空闲 | 新建即为此状态；退房自动回落 |
| 1 | 已预约 | Day06 智能预约成功后 |
| 2 | 入住 | 老人办理入住 |
| 3 | 维护 | 维修 / 消杀 |

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| resultMap | MyBatis 把\"多列查询结果\"映射为\"一个 Java 对象\"的规则 |
| LEFT JOIN | 左表为主，即使右表匹配不上也保留该行 |
| VO 冗余 | 在视图对象里加上查询得来的关联字段（如 typeName），减少前端二次查询 |
| status 枚举 | 用小整数代表状态，节省存储且便于索引 |

### 1.4 示例代码/例题解析

**示例 1：完整的 RoomInfo 实体**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("room_info")
public class RoomInfo {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String roomNo;
    private Long typeId;
    private Integer floor;
    private Integer status;
    private String imageUrl;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
```
原理解释：`@TableField(fill = FieldFill.INSERT)` 让 MyBatis-Plus 在 INSERT 时自动填充 `create_time`，前提是项目里配置了 `MetaObjectHandler`（Day02 已经放好）。

**示例 2：RoomVO**
```java
package com.itcast.smart_elder.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RoomVO {
    private Long id;
    private String roomNo;
    private Long typeId;
    private String typeName;      // ← 冗余
    private BigDecimal typePrice; // ← 冗余
    private Integer floor;
    private Integer status;
    private String imageUrl;
    private LocalDateTime createTime;
}
```

**示例 3：resultMap 与 SQL 片段**
```xml
<resultMap id="RoomVOMap" type="com.itcast.smart_elder.vo.RoomVO">
    <id     property="id"         column="id"/>
    <result property="roomNo"     column="room_no"/>
    <result property="typeId"     column="type_id"/>
    <result property="typeName"   column="type_name"/>
    <result property="typePrice"  column="price"/>
    <result property="floor"      column="floor"/>
    <result property="status"     column="status"/>
    <result property="imageUrl"   column="image_url"/>
    <result property="createTime" column="create_time"/>
</resultMap>

<sql id="joinCols">
    r.id, r.room_no, r.type_id, r.floor, r.status,
    r.image_url, r.create_time,
    t.type_name, t.price
</sql>
```

### 1.5 课后练习
1. 【基础】在 Navicat 中给 `room_type` 和 `room_info` 各插入 3-5 条测试数据，并执行 LEFT JOIN 观察结果。
2. 【综合】修改 `RoomVO`，加上 `capacity` 字段，并同步修改 `<resultMap>` 与 SQL 片段。
3. 【挑战】如果一个房型可以对应\"折扣价\"（周末价/工作日价两个字段），你会如何设计表结构与 VO？

---

## 第 2 讲：客房分页与条件筛选接口

### 2.1 本讲要点
- 掌握 `RoomPageDTO` 的字段设计与默认值兜底
- 掌握 MyBatis 中 `<where>` `<if>` 动态 SQL 用法
- 掌握手写 XML 分页时 `IPage<T>` 参数**必须放第一位**的规则
- 完成 Controller → Service → Mapper → XML 四层落地，Postman 一次跑通

### 2.2 知识点详解

#### 2.2.1 RoomPageDTO 设计
```java
package com.itcast.smart_elder.dto;

import lombok.Data;

@Data
public class RoomPageDTO {
    private String  roomNo;   // 模糊
    private Long    typeId;   // 精确
    private Integer status;   // 精确
    private Integer pageNum  = 1;
    private Integer pageSize = 10;
}
```
> 💡 **技巧：** DTO 里给 `pageNum/pageSize` 默认值，前端不传也不会 NPE。

#### 2.2.2 \<where> 与 \<if> 组合

| 场景 | 代码 |
|------|------|
| roomNo 有值 | `<if test="q.roomNo != null and q.roomNo != ''"> AND r.room_no LIKE CONCAT('%', #{q.roomNo}, '%') </if>` |
| typeId 有值 | `<if test="q.typeId != null"> AND r.type_id = #{q.typeId} </if>` |
| status 有值 | `<if test="q.status != null"> AND r.status = #{q.status} </if>` |

> ⚠️ **注意：** `<where>` 会自动帮你把第一个多余的 AND 去掉，如果不用 `<where>` 就得手动写 `WHERE 1=1 <if>...`。

#### 2.2.3 IPage 参数必须放第一位

```java
// ✅ 正确
IPage<RoomVO> pageVO(IPage<RoomVO> page, @Param("q") RoomPageDTO dto);

// ❌ 错误：Page 放后面，分页拦截器不会生效
IPage<RoomVO> pageVO(@Param("q") RoomPageDTO dto, IPage<RoomVO> page);
```

> ⚠️ **注意：** 这是 MyBatis-Plus 分页拦截器的硬规则；错了不会报错，只是不会 LIMIT，看起来\"分页失效\"。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| <where> | MyBatis 动态 SQL 标签，自动去除多余 AND/OR |
| <if> | 条件为真才拼接内容 |
| IPage | MyBatis-Plus 的分页返回值接口，字段 total/records |
| PageBean | 本项目自定义的分页封装，字段 total/rows |

### 2.4 示例代码/例题解析

**示例 1：完整的 Mapper + XML + Service + Controller**

```java
// RoomMapper.java
public interface RoomMapper extends BaseMapper<RoomInfo> {
    IPage<RoomVO> pageVO(IPage<RoomVO> page, @Param("q") RoomPageDTO dto);
    RoomVO selectVOById(@Param("id") Long id);
}
```

```xml
<!-- RoomMapper.xml -->
<select id="pageVO" resultMap="RoomVOMap">
    SELECT <include refid="joinCols"/>
    FROM room_info r
    LEFT JOIN room_type t ON t.id = r.type_id
    <where>
        <if test="q.roomNo != null and q.roomNo != ''">
            AND r.room_no LIKE CONCAT('%', #{q.roomNo}, '%')
        </if>
        <if test="q.typeId != null">
            AND r.type_id = #{q.typeId}
        </if>
        <if test="q.status != null">
            AND r.status = #{q.status}
        </if>
    </where>
    ORDER BY r.floor ASC, r.room_no ASC
</select>
```

```java
// RoomServiceImpl（片段）
@Override
public PageBean<RoomVO> page(RoomPageDTO dto) {
    IPage<RoomVO> p = new Page<>(dto.getPageNum(), dto.getPageSize());
    IPage<RoomVO> res = roomMapper.pageVO(p, dto);
    return new PageBean<>(res.getTotal(), res.getRecords());
}
```

```java
// RoomController（片段）
@GetMapping("/page")
public Result<PageBean<RoomVO>> page(RoomPageDTO dto) {
    return Result.success(roomService.page(dto));
}
```

请求示例：
```http
GET /api/rooms/page?roomNo=A&typeId=1&status=0&pageNum=1&pageSize=10

响应：
{
  "code": 1, "msg": "success",
  "data": {
    "total": 12,
    "rows": [
      {
        "id": 1, "roomNo": "A-101", "typeId": 1,
        "typeName": "单人间", "typePrice": 3200.00,
        "floor": 1, "status": 0,
        "imageUrl": "/files/rooms/9a3f...c1.jpg",
        "createTime": "2026-07-09 10:00:00"
      }
    ]
  }
}
```

原理解释：`<where>` 自动去掉多余 AND；`CONCAT('%', #{q.roomNo}, '%')` 保证百分号在 SQL 侧拼接，避免\"注入%\" 风险；`ORDER BY r.floor, r.room_no` 保证\"同楼层的房号相邻显示\"，视觉更整齐。

### 2.5 课后练习
1. 【基础】把接口跑通，用 Postman 输出至少 3 组不同参数的响应。
2. 【综合】增加\"楼层筛选\" `floor` 字段，仿照 `status` 做精确匹配。
3. 【挑战】改成\"按房型分组\"返回，如返回 `{ 单人间: [...], 双人间: [...] }`。

---

## 第 3 讲：图片上传与本地存储

### 3.1 本讲要点
- 理解 `multipart/form-data` 表单类型
- 掌握 `MultipartFile` 的常用方法：`getOriginalFilename` / `getSize` / `transferTo`
- 掌握 `UUID + 原后缀` 命名，杜绝文件名冲突
- 掌握 `WebMvcConfigurer.addResourceHandlers` 把\"磁盘目录\"映射为可访问 URL
- 掌握文件大小 / MIME 类型的白名单校验

### 3.2 知识点详解

#### 3.2.1 SpringBoot 上传三兄弟

| 层 | 位置 | 作用 |
|----|------|------|
| 配置层 | `application.yml` `spring.servlet.multipart` | 限定框架层最大字节数 |
| 参数层 | `MultipartFile file` | 接收前端 `<input type="file">` |
| 存储层 | `file.transferTo(dest)` | 落盘到磁盘 |

application.yml 示例：
```yaml
spring:
  servlet:
    multipart:
      max-file-size: 5MB
      max-request-size: 10MB

app:
  upload:
    dir: D:/upload/rooms/           # Windows；Linux 改 /data/upload/rooms/
    url-prefix: /files/rooms/
```

#### 3.2.2 静态资源映射原理
Spring MVC 默认只把 `classpath:/static/**` 暴露给浏览器；我们想让\"磁盘任意目录\"被访问，需要自定义 `WebMvcConfigurer`：

```
磁盘 D:/upload/rooms/xxx.jpg
     ↓ addResourceHandlers
URL  http://localhost:8080/files/rooms/xxx.jpg
```

> 💡 **技巧：** `.addResourceLocations("file:" + dir)` 里的 `file:` 前缀不能省，这是 Spring Resource 表示\"文件系统路径\"的协议前缀。

#### 3.2.3 文件名策略

| 策略 | 优点 | 缺点 |
|------|------|------|
| 原文件名 | 直观 | 冲突频繁 |
| 时间戳 + 原名 | 大概率不冲突 | 高并发仍会撞 |
| UUID + 后缀 | 几乎不冲突 | 不可读 |
| 用户 ID + 时间戳 | 溯源方便 | 需要登录信息 |

本课程选择 **UUID + 原后缀**，简单可靠。

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| MultipartFile | Spring 抽象的上传文件对象 |
| transferTo | 一键落盘方法 |
| addResourceHandlers | 磁盘目录 ↔ URL 前缀的映射方法 |
| MIME 类型 | 如 image/png，用于白名单校验 |

### 3.4 示例代码/例题解析

**示例 1：完整的 FileController + WebConfig**

```java
// UploadProperties
@Data
@Component
@ConfigurationProperties("app.upload")
public class UploadProperties {
    private String dir;
    private String urlPrefix;
}
```

```java
// WebConfig
@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {
    private final UploadProperties uploadProperties;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(uploadProperties.getUrlPrefix() + "**")
                .addResourceLocations("file:" + uploadProperties.getDir());
    }
}
```

```java
// FileController
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class FileController {

    private static final Set<String> ALLOWED = Set.of(".jpg", ".jpeg", ".png", ".gif", ".webp");
    private static final long MAX_SIZE = 5L * 1024 * 1024;

    private final UploadProperties props;

    @PostMapping("/upload")
    public Result<String> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) return Result.fail("上传文件为空");
        if (file.getSize() > MAX_SIZE)      return Result.fail("文件不能超过 5MB");

        String origin = file.getOriginalFilename();
        if (origin == null || !origin.contains(".")) return Result.fail("文件必须有后缀");
        String ext = origin.substring(origin.lastIndexOf(".")).toLowerCase();
        if (!ALLOWED.contains(ext)) return Result.fail("只支持 " + ALLOWED);

        File dir = new File(props.getDir());
        if (!dir.exists() && !dir.mkdirs()) return Result.fail("上传目录创建失败：" + props.getDir());

        String newName = UUID.randomUUID().toString().replace("-", "") + ext;
        File dest = new File(dir, newName);
        file.transferTo(dest);

        String url = props.getUrlPrefix() + newName;
        return Result.success(url);
    }
}
```

请求：
```http
POST /api/upload
Content-Type: multipart/form-data
Body: file=<选择本地一张 jpg>

响应：
{ "code": 1, "msg": "success", "data": "/files/rooms/9a3f...c1.jpg" }
```

原理解释：`transferTo` 会尝试用零拷贝把文件从临时目录移到目标目录，这比手动 `InputStream / OutputStream` 循环快。响应里返回**相对路径**是为了将来切换域名/CDN 时前端不用改。

**示例 2：Postman form-data 上传步骤（重要）**
1. Method = POST，URL = `http://localhost:8080/api/upload`
2. Body → 选择 `form-data`
3. 新增一行：`Key = file`，右侧下拉从 `Text` 改成 `File`，然后选一张本地图片
4. Send → 应返回相对路径
5. 复制路径，浏览器输入 `http://localhost:8080/files/rooms/xxx.jpg`，看到图片

### 3.5 课后练习
1. 【基础】跑通上传接口，用 Postman + 浏览器双验证。
2. 【综合】加\"按天存子目录\"策略：`D:/upload/rooms/2026-07-09/xxx.jpg`。
3. 【挑战】上传成功后额外生成一张 200×150 缩略图并返回两个 URL。

---

## 第 4 讲：客房新增/修改（含图片）

### 4.1 本讲要点
- 掌握 DTO 分裂：`RoomAddDTO` / `RoomUpdateDTO` / `RoomStatusDTO`
- 掌握\"字段冗余处理\"：只保存 `typeId`，永不保存 `typeName`
- 掌握房号唯一性校验：Service 层 count + DB 唯一索引双保险
- 理解 `@Transactional` 的使用时机
- `status` 新增默认 0；修改接口不动 status

### 4.2 知识点详解

#### 4.2.1 DTO 分裂原则

| DTO | 用途 | 关键字段 |
|-----|------|----------|
| RoomAddDTO | 新增时前端传的字段 | 无 id；有 roomNo/typeId/floor/imageUrl |
| RoomUpdateDTO | 修改时前端传的字段 | 有 id；不含 status |
| RoomStatusDTO | 单字段修改状态 | 只有 id + status |
| RoomPageDTO | 分页查询条件 | roomNo/typeId/status + 分页 |

> 💡 **技巧：** \"接口不同 → DTO 不同\"能让入参一目了然，即使字段大量重合。

#### 4.2.2 字段冗余处理

| 字段 | 写库时 | 查询时 |
|------|--------|--------|
| type_id | ✅ 存 | ✅ 用于 JOIN |
| type_name | ❌ 不存 | ✅ 通过 JOIN 带出到 VO |
| type_price | ❌ 不存 | ✅ 通过 JOIN 带出到 VO |

> ⚠️ **注意：** 唯一违反此原则的场景是\"下订单快照\"：Day06 生成订单时把房型名与价格**当时**冻结存入订单表，避免房型改名/涨价影响历史订单金额。

#### 4.2.3 唯一性校验双保险

```
Service 层 count 校验    ← 用户友好，第一道防线
        ↓
DB 层 UNIQUE 索引        ← 最后一道防线，防止并发时序漏洞
```

代码：
```java
try {
    roomMapper.insert(info);
} catch (DuplicateKeyException e) {
    throw new BusinessException("房号已存在：" + dto.getRoomNo());
}
```

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| DTO 分裂 | 不同接口用不同 DTO，字段最小化 |
| 字段冗余 | 只在 VO 层扩展关联字段，不写入实体表 |
| DuplicateKeyException | Spring 抛出的 DB 唯一约束冲突 |
| @Transactional | 声明式事务，方法抛异常时回滚 |

### 4.4 示例代码/例题解析

**示例 1：Add / Update / Status 三 DTO + Service 完整实现**

```java
@Data
public class RoomAddDTO {
    private String  roomNo;
    private Long    typeId;
    private Integer floor;
    private String  imageUrl;
}

@Data
public class RoomUpdateDTO {
    private Long    id;
    private String  roomNo;
    private Long    typeId;
    private Integer floor;
    private String  imageUrl;
}

@Data
public class RoomStatusDTO {
    private Long    id;
    private Integer status;
}
```

```java
@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomMapper roomMapper;

    @Override
    @Transactional
    public void add(RoomAddDTO dto) {
        checkRoomNo(dto.getRoomNo(), null);
        RoomInfo info = new RoomInfo();
        info.setRoomNo(dto.getRoomNo());
        info.setTypeId(dto.getTypeId());
        info.setFloor(dto.getFloor());
        info.setImageUrl(dto.getImageUrl());
        info.setStatus(0);
        try {
            roomMapper.insert(info);
        } catch (DuplicateKeyException e) {
            throw new BusinessException("房号已存在：" + dto.getRoomNo());
        }
    }

    @Override
    @Transactional
    public void update(RoomUpdateDTO dto) {
        if (dto.getId() == null) throw new BusinessException("id 必填");
        checkRoomNo(dto.getRoomNo(), dto.getId());
        RoomInfo info = new RoomInfo();
        info.setId(dto.getId());
        info.setRoomNo(dto.getRoomNo());
        info.setTypeId(dto.getTypeId());
        info.setFloor(dto.getFloor());
        info.setImageUrl(dto.getImageUrl());
        // 不改 status
        roomMapper.updateById(info);
    }

    @Override
    public void changeStatus(RoomStatusDTO dto) {
        RoomInfo info = new RoomInfo();
        info.setId(dto.getId());
        info.setStatus(dto.getStatus());
        roomMapper.updateById(info);
    }

    @Override
    @Transactional
    public void delete(List<Long> ids) {
        if (ids == null || ids.isEmpty()) throw new BusinessException("ids 必填");
        roomMapper.deleteBatchIds(ids);
    }

    private void checkRoomNo(String roomNo, Long excludeId) {
        if (!StringUtils.hasText(roomNo)) throw new BusinessException("房号必填");
        Long cnt = roomMapper.selectCount(new LambdaQueryWrapper<RoomInfo>()
                .eq(RoomInfo::getRoomNo, roomNo)
                .ne(excludeId != null, RoomInfo::getId, excludeId));
        if (cnt != null && cnt > 0) {
            throw new BusinessException("房号已存在：" + roomNo);
        }
    }
}
```

**示例 2：Controller 完整版**
```java
@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @GetMapping("/page")
    public Result<PageBean<RoomVO>> page(RoomPageDTO dto) {
        return Result.success(roomService.page(dto));
    }

    @GetMapping("/{id}")
    public Result<RoomVO> getById(@PathVariable Long id) {
        return Result.success(roomService.getById(id));
    }

    @PostMapping
    public Result<Void> add(@RequestBody RoomAddDTO dto) {
        roomService.add(dto);
        return Result.success();
    }

    @PutMapping
    public Result<Void> update(@RequestBody RoomUpdateDTO dto) {
        roomService.update(dto);
        return Result.success();
    }

    @PutMapping("/status")
    public Result<Void> changeStatus(@RequestBody RoomStatusDTO dto) {
        roomService.changeStatus(dto);
        return Result.success();
    }

    @DeleteMapping("/{ids}")
    public Result<Void> delete(@PathVariable List<Long> ids) {
        roomService.delete(ids);
        return Result.success();
    }
}
```

原理解释：`@PathVariable List<Long> ids` 支持 URL 里\"1,2,3\"这样的逗号分隔，Spring 自动切分成 List。这是 Day03 会员管理已用过的写法，此处复用。

### 4.5 课后练习
1. 【基础】完成 6 个接口的 Postman 用例。
2. 【综合】在\"新增\"里加\"typeId 是否真的存在\"的额外校验（防止乱传 999）。
3. 【挑战】给\"批量删除\"加\"如果任何一间房处于入住状态则拒绝\"的业务保护。

---

## 第 5 讲：前端客房列表 + 图片展示

### 5.1 本讲要点
- 在 `src/api/room.ts` 里一次性封装 6 个接口 + 上传接口 + 房型下拉
- 掌握 `el-table` 的图片列（`el-image` + `preview-src-list` 预览）
- 掌握 `el-tag` 按 status 4 色显示
- 前端拼接图片完整 URL：`import.meta.env.VITE_API_BASE + row.imageUrl`

### 5.2 知识点详解

#### 5.2.1 API 封装模式

| 项目做法 | 说明 |
|----------|------|
| 一个模块一个文件 | `api/room.ts` `api/member.ts` |
| 方法名与接口一一对应 | `pageRoom` / `addRoom` / `updateRoom` |
| 分页统一 GET + params | 便于浏览器缓存 |
| 上传统一 `multipart/form-data` | 自定义 headers |

#### 5.2.2 图片显示与预览

```vue
<el-image v-if="row.imageUrl"
          :src="apiBase + row.imageUrl"
          :preview-src-list="[apiBase + row.imageUrl]"
          fit="cover"
          hide-on-click-modal
          style="width:80px;height:60px"/>
```

> 💡 **技巧：** `preview-src-list` 就是\"点击后可以放大预览的图片列表\"。这里传一个单元素数组即可。

#### 5.2.3 status → tag 颜色映射

```ts
const statusMap: Record<number, { text: string; type: any }> = {
  0: { text: '空闲',    type: 'success' },
  1: { text: '已预约',  type: 'warning' },
  2: { text: '入住中',  type: 'primary' },
  3: { text: '维护中',  type: 'danger'  }
}
```

用对象存比 switch 简洁，还便于遍历生成 select 选项。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| VITE_API_BASE | Vite 环境变量，定义在 `.env` |
| el-image | Element Plus 的图片组件，支持懒加载、预览、失败占位 |
| el-tag | 状态标签，支持 success/warning/primary/danger |
| selection-change | el-table 多选事件，回传选中数组 |

### 5.4 示例代码/例题解析

**示例 1：api/room.ts 完整版**
```ts
import request from '@/utils/request'

export interface RoomPageParams {
  roomNo?: string
  typeId?: number
  status?: number
  pageNum?: number
  pageSize?: number
}

export const pageRoom          = (params: RoomPageParams) =>
  request({ url: '/api/rooms/page', method: 'get', params })

export const getRoomById       = (id: number) =>
  request({ url: `/api/rooms/${id}`, method: 'get' })

export const addRoom           = (data: any) =>
  request({ url: '/api/rooms', method: 'post', data })

export const updateRoom        = (data: any) =>
  request({ url: '/api/rooms', method: 'put',  data })

export const updateRoomStatus  = (data: { id: number; status: number }) =>
  request({ url: '/api/rooms/status', method: 'put', data })

export const deleteRooms       = (ids: number[]) =>
  request({ url: `/api/rooms/${ids.join(',')}`, method: 'delete' })

export const listRoomTypes     = () =>
  request({ url: '/api/roomTypes', method: 'get' })

export const uploadFile = (file: File) => {
  const fd = new FormData()
  fd.append('file', file)
  return request({
    url: '/api/upload',
    method: 'post',
    data: fd,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}
```

**示例 2：`.env` 与 `apiBase`**
```
# .env.development
VITE_API_BASE=http://localhost:8080
```

```ts
const apiBase = import.meta.env.VITE_API_BASE
// 使用：apiBase + row.imageUrl
```

原理解释：Vite 只暴露前缀为 `VITE_` 的环境变量到客户端，避免密钥泄漏。

### 5.5 课后练习
1. 【基础】完成搜索栏 → 表格 → 图片列 → 分页的显示。
2. 【综合】给 `el-image` 加 `lazy` 懒加载属性，观察网络面板变化。
3. 【挑战】把图片列改为\"圆形头像 + 悬停放大预览\"。

---

## 第 6 讲：前端客房表单联调 + 状态管理

### 6.1 本讲要点
- 掌握 `el-dialog` + `el-form` 复用做新增/修改（`form.id` 判定）
- 掌握 `el-upload` 的 `http-request` 自定义上传逻辑
- 掌握上传前 `beforeUpload` 做 MIME/大小检查
- 状态切换用 `el-dropdown`，失败要**手动回滚** UI
- 通过 Day04 收官：把六个课时的成果串成一条完整链路

### 6.2 知识点详解

#### 6.2.1 el-upload 两种模式

| 模式 | 用法 | 优缺点 |
|------|------|--------|
| 默认 action | `action="/api/upload"` | 简单；但不走 axios 拦截器，Token、错误处理都要重写 |
| http-request | `:http-request="customUpload"` | 复杂一点点；可以用统一的 axios，一致的错误提示 |

我们选择第 2 种。

#### 6.2.2 Dialog 复用逻辑

```
点击"新增" → openAdd() → form 清空 → dialog 打开
点击"编辑" → openEdit(id) → 请求详情 → form 回填 → dialog 打开
点击"保存" → submit()
    ├── form.id 有值   → updateRoom
    └── form.id 未定义 → addRoom
```

> 💡 **技巧：** 一份 `form` + `emptyForm()` 工厂函数 + `Object.assign(form, emptyForm())` 就能做出\"新增/修改共用\"的干净代码。

#### 6.2.3 状态切换 + 失败回滚

```ts
const onStatusChange = async (row: any, status: number) => {
  const oldStatus = row.status
  try {
    await updateRoomStatus({ id: row.id, status })
    row.status = status
    ElMessage.success('状态已更新')
  } catch {
    row.status = oldStatus   // ← 请求失败，UI 手动回滚
  }
}
```

> ⚠️ **注意：** 如果不做 UI 回滚，即使后端失败，表格上的状态标签也会\"看起来变了\"，用户会误以为改成功了。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| el-upload http-request | 自定义上传函数，覆盖组件默认 XHR |
| beforeUpload | 上传前钩子，返回 false 可拦截 |
| 表单复用 | 用 `form.id` 是否有值区分新增/修改 |
| 状态回滚 | 请求失败时把 UI 状态还原 |

### 6.4 示例代码/例题解析

**示例 1：views/room/list.vue 完整版**

```vue
<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus'
import { ArrowDown, Plus } from '@element-plus/icons-vue'
import {
  pageRoom, addRoom, updateRoom, deleteRooms,
  updateRoomStatus, getRoomById, listRoomTypes, uploadFile
} from '@/api/room'

const apiBase = import.meta.env.VITE_API_BASE
const statusMap: Record<number, { text: string; type: any }> = {
  0: { text: '空闲',    type: 'success' },
  1: { text: '已预约',  type: 'warning' },
  2: { text: '入住中',  type: 'primary' },
  3: { text: '维护中',  type: 'danger'  }
}

const loading = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const selected = ref<any[]>([])
const typeList = ref<any[]>([])

const query = reactive({
  roomNo: '', typeId: undefined, status: undefined,
  pageNum: 1, pageSize: 10
})

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await pageRoom(query)
    rows.value = res.data.rows
    total.value = res.data.total
  } finally { loading.value = false }
}

const loadTypes = async () => {
  const res: any = await listRoomTypes()
  typeList.value = res.data || []
}

const onSearch = () => { query.pageNum = 1; loadData() }
const onReset  = () => {
  query.roomNo = ''; query.typeId = undefined; query.status = undefined
  query.pageNum = 1; loadData()
}

// ==== Dialog + Form ====
const dialogVisible = ref(false)
const formRef = ref<FormInstance>()
const emptyForm = () => ({
  id: undefined as number | undefined,
  roomNo: '', typeId: undefined as number | undefined,
  floor: 1, imageUrl: ''
})
const form = reactive<any>(emptyForm())
const fileList = ref<any[]>([])

const rules = {
  roomNo: [
    { required: true, message: '房号必填', trigger: 'blur' },
    { min: 2, max: 20, message: '房号长度 2-20', trigger: 'blur' }
  ],
  typeId: [{ required: true, message: '房型必选', trigger: 'change' }],
  floor:  [{ required: true, message: '楼层必填', trigger: 'blur' }]
}

const openAdd = () => {
  Object.assign(form, emptyForm())
  fileList.value = []
  dialogVisible.value = true
}

const openEdit = async (id: number) => {
  const res: any = await getRoomById(id)
  Object.assign(form, emptyForm(), res.data)
  fileList.value = form.imageUrl
    ? [{ name: '当前图片', url: apiBase + form.imageUrl }]
    : []
  dialogVisible.value = true
}

const customUpload = async (opt: any) => {
  try {
    const res: any = await uploadFile(opt.file)
    form.imageUrl = res.data
    fileList.value = [{ name: opt.file.name, url: apiBase + res.data }]
    ElMessage.success('图片上传成功')
    opt.onSuccess(res)
  } catch (e: any) {
    ElMessage.error(e?.message || '图片上传失败')
    opt.onError(e)
  }
}

const beforeUpload = (file: File) => {
  const ok = ['image/jpeg','image/png','image/gif','image/webp'].includes(file.type)
  if (!ok) { ElMessage.error('只支持 jpg/png/gif/webp'); return false }
  if (file.size > 5 * 1024 * 1024) { ElMessage.error('图片不能超过 5MB'); return false }
  return true
}

const onRemoveImg = () => { form.imageUrl = ''; fileList.value = [] }

const submit = async () => {
  await formRef.value?.validate()
  if (form.id) {
    await updateRoom(form); ElMessage.success('修改成功')
  } else {
    await addRoom(form);    ElMessage.success('新增成功')
  }
  dialogVisible.value = false
  loadData()
}

const onDelete = async (ids: number[]) => {
  await ElMessageBox.confirm('确定删除吗？', '提示', { type: 'warning' })
  await deleteRooms(ids)
  ElMessage.success('删除成功')
  loadData()
}
const onBatchDelete = () => onDelete(selected.value.map(r => r.id))

const onStatusChange = async (row: any, status: number) => {
  const oldStatus = row.status
  try {
    await updateRoomStatus({ id: row.id, status })
    row.status = status
    ElMessage.success('状态已更新')
  } catch {
    row.status = oldStatus
  }
}

onMounted(() => { loadTypes(); loadData() })
</script>

<template>
  <div class="room-page">
    <!-- 搜索栏 -->
    <el-form :inline="true" class="search-bar">
      <el-form-item label="房号">
        <el-input v-model="query.roomNo" placeholder="模糊查询" clearable/>
      </el-form-item>
      <el-form-item label="房型">
        <el-select v-model="query.typeId" placeholder="全部" clearable style="width:160px">
          <el-option v-for="t in typeList" :key="t.id" :label="t.typeName" :value="t.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="query.status" placeholder="全部" clearable style="width:140px">
          <el-option label="空闲"   :value="0"/>
          <el-option label="已预约" :value="1"/>
          <el-option label="入住中" :value="2"/>
          <el-option label="维护中" :value="3"/>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSearch">搜索</el-button>
        <el-button @click="onReset">重置</el-button>
        <el-button type="success" @click="openAdd">新增客房</el-button>
        <el-button type="danger" :disabled="!selected.length" @click="onBatchDelete">批量删除</el-button>
      </el-form-item>
    </el-form>

    <!-- 表格 -->
    <el-table :data="rows" @selection-change="v => selected = v" v-loading="loading" border stripe>
      <el-table-column type="selection" width="45"/>
      <el-table-column prop="roomNo"    label="房号"     width="100"/>
      <el-table-column prop="typeName"  label="房型"     width="110"/>
      <el-table-column prop="typePrice" label="租金/月" width="100"/>
      <el-table-column prop="floor"     label="楼层"     width="70"/>
      <el-table-column label="图片" width="120">
        <template #default="{ row }">
          <el-image v-if="row.imageUrl"
                    :src="apiBase + row.imageUrl"
                    :preview-src-list="[apiBase + row.imageUrl]"
                    :initial-index="0"
                    fit="cover"
                    hide-on-click-modal
                    style="width:80px;height:60px;border-radius:4px"/>
          <span v-else style="color:#c0c4cc">暂无</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="110">
        <template #default="{ row }">
          <el-tag :type="statusMap[row.status]?.type">
            {{ statusMap[row.status]?.text }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="170"/>
      <el-table-column label="操作" width="240" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row.id)">编辑</el-button>
          <el-dropdown @command="cmd => onStatusChange(row, cmd)" trigger="click">
            <el-button link type="warning">
              改状态<el-icon><arrow-down/></el-icon>
            </el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item :command="0">置为空闲</el-dropdown-item>
                <el-dropdown-item :command="1">置为已预约</el-dropdown-item>
                <el-dropdown-item :command="2">置为入住</el-dropdown-item>
                <el-dropdown-item :command="3">置为维护</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <el-button link type="danger" @click="onDelete([row.id])">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination class="pagination"
                   background layout="total, sizes, prev, pager, next"
                   :total="total"
                   v-model:current-page="query.pageNum"
                   v-model:page-size="query.pageSize"
                   :page-sizes="[10,20,50]"
                   @size-change="loadData"
                   @current-change="loadData"/>

    <!-- Dialog -->
    <el-dialog v-model="dialogVisible"
               :title="form.id ? '编辑客房' : '新增客房'"
               width="520px"
               :close-on-click-modal="false">
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="房号" prop="roomNo">
          <el-input v-model="form.roomNo" placeholder="如 A-101"/>
        </el-form-item>
        <el-form-item label="房型" prop="typeId">
          <el-select v-model="form.typeId" placeholder="请选择">
            <el-option v-for="t in typeList" :key="t.id" :label="t.typeName" :value="t.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="楼层" prop="floor">
          <el-input-number v-model="form.floor" :min="1" :max="99"/>
        </el-form-item>
        <el-form-item label="图片">
          <el-upload :file-list="fileList"
                     list-type="picture-card"
                     :http-request="customUpload"
                     :before-upload="beforeUpload"
                     :on-remove="onRemoveImg"
                     :limit="1"
                     accept="image/*">
            <el-icon><Plus/></el-icon>
          </el-upload>
          <div style="color:#909399;font-size:12px">
            只支持 jpg/png/gif/webp，≤ 5MB
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<style scoped>
.search-bar { margin-bottom: 16px; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

原理解释：`el-upload` 通过 `http-request` 把控制权交给我们的 `customUpload`，从而复用了 axios 的拦截器与统一错误处理。上传成功后立即把返回的 URL 写入 `form.imageUrl`，此时**表单还没提交**，图片仅是\"预上传\"到磁盘。若用户最终没点\"保存\"，磁盘上会留下这张\"孤儿图\" —— 第 3 讲课后思考里已经埋下伏笔，Day10 系统优化可以用\"定时任务扫描无引用图片\"的方式治理。

### 6.5 课后练习
1. 【基础】通过 Dialog 完成\"新增 → 上传图片 → 保存 → 列表刷新\"全链路。
2. 【综合】给\"改状态\"加一个确认框，避免误点。
3. 【挑战】把上传组件改成支持\"多张\"（客房相册），前后端都要改。

---

# 附录 A：Day04 后端接口清单

| 编号 | 接口名 | 方法 | URL | 请求参数 | 响应 |
|------|--------|------|-----|----------|------|
| ① | 客房分页查询 | GET | /api/rooms/page | query: roomNo, typeId, status, pageNum, pageSize | Result&lt;PageBean&lt;RoomVO&gt;&gt; |
| ② | 客房详情回显 | GET | /api/rooms/{id} | path: id | Result&lt;RoomVO&gt; |
| ③ | 客房新增 | POST | /api/rooms | body: RoomAddDTO | Result&lt;Void&gt; |
| ④ | 客房修改 | PUT | /api/rooms | body: RoomUpdateDTO | Result&lt;Void&gt; |
| ⑤ | 客房状态切换 | PUT | /api/rooms/status | body: RoomStatusDTO {id,status} | Result&lt;Void&gt; |
| ⑥ | 客房批量删除 | DELETE | /api/rooms/{ids} | path: 1,2,3 | Result&lt;Void&gt; |
| ⑦ | 图片上传 | POST | /api/upload | form-data: file | Result&lt;String&gt; 返回相对URL |
| ⑧ | 房型下拉 | GET | /api/roomTypes | 无 | Result&lt;List&lt;RoomType&gt;&gt; |

**静态资源映射：** `/files/rooms/**` → 磁盘 `${app.upload.dir}`

**统一响应结构：**
```json
{ "code": 1, "msg": "success", "data": { ... } }
```
- code = 1 成功；code = 0 业务失败（校验、房号重复、文件超限等）

---

# 附录 B：Postman 测试用例

> 建议在 Postman 里新建 Collection \"智能养老-客房管理\"，Environment 里设 `baseUrl=http://localhost:8080`。

### 用例 1：分页查询
- 方法：GET
- URL：`{{baseUrl}}/api/rooms/page?roomNo=A&status=0&pageNum=1&pageSize=10`
- 预期：`code=1`，`data.rows` 里每条都有 `typeName` 与 `typePrice`。

### 用例 2：图片上传
- 方法：POST
- URL：`{{baseUrl}}/api/upload`
- Body：form-data → `file` = 本地一张 jpg
- 预期：`code=1`，`data` 类似 `/files/rooms/9a3f...c1.jpg`。
- 复核：浏览器打开 `{{baseUrl}}/files/rooms/9a3f...c1.jpg` 应显示图片。

### 用例 3：新增客房（正常）
- 方法：POST
- URL：`{{baseUrl}}/api/rooms`
- Body（JSON）：
```json
{
  "roomNo": "A-101",
  "typeId": 1,
  "floor": 1,
  "imageUrl": "/files/rooms/9a3f...c1.jpg"
}
```
- 预期：`code=1`，`status` 默认 0。

### 用例 4：新增客房（房号重复）
- Body 里房号继续用 `A-101`。
- 预期：`code=0`，msg 包含\"房号已存在\"。

### 用例 5：修改客房
- 方法：PUT
- URL：`{{baseUrl}}/api/rooms`
- Body：
```json
{ "id": 1, "roomNo": "A-101", "typeId": 2, "floor": 1, "imageUrl": "/files/rooms/9a3f...c1.jpg" }
```
- 预期：`code=1`，再查详情 `typeId=2`，`typeName` 也随之变化。

### 用例 6：状态切换
- 方法：PUT
- URL：`{{baseUrl}}/api/rooms/status`
- Body：`{ "id": 1, "status": 3 }`
- 预期：`code=1`，再分页查询该房 status=3、tag 变红。

### 用例 7：批量删除
- 方法：DELETE
- URL：`{{baseUrl}}/api/rooms/2,3`
- 预期：`code=1`，被删的房不再出现在分页列表。

### 用例 8：文件超限
- 方法：POST，URL：`/api/upload`
- Body：一张 > 5MB 图片
- 预期：`code=0`，msg = \"文件不能超过 5MB\"。

---

**Day04 总结：** 一天完成\"客房数据模型 → 关联分页 → 图片上传 → 新增/修改/状态切换 → 前端列表带图 → 前端表单联调\"六个环节。掌握了三项新能力：**LEFT JOIN + `<resultMap>`**、**MultipartFile + `addResourceHandlers`**、**`el-upload` 自定义上传**。这套骨架将在 Day06 客房预约中直接复用（同样是复杂表单 + 状态机 + 关联查询）。
