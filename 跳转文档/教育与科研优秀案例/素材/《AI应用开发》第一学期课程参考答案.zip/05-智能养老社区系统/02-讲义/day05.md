# 《智能养老社区系统》- 学生讲义 - Day05：对接阿里通义千问 AI 大模型

**授课日：Day 05 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01-04 已完成的数据库、后端骨架、Vue3 骨架、会员/客房模块**

---

## 学习目标概览

- 掌握大语言模型（LLM）的基本认知与主流玩家；
- 学会阿里百炼平台的开通与 API-Key 获取；
- 掌握 Spring AI 1.0.0-M6 的五大核心抽象与依赖引入；
- 独立完成通义千问接入并跑通同步、流式两类接口；
- 掌握 Prompt 工程 5 段式与 `PromptTemplate` 变量替换；
- 独立完成前端"小金"聊天页面，实现气泡对话 + 逐字流式渲染。

---

## 第 1 讲：大模型基础与百炼平台

### 1.1 本讲要点
- LLM（大语言模型）本质：一个学过巨量文本、擅长"猜下一个字"的接龙机；
- Transformer：所有主流大模型的地基，2017 年由 Google 提出；
- 主流大模型：GPT、通义千问、DeepSeek、Claude 各有定位；
- 阿里百炼平台：一站式模型服务，本项目主用 qwen-plus；
- Token 与计费：约 1 汉字 = 1-2 token，qwen-plus 输入 ¥0.004/千 token。

### 1.2 知识点详解

#### 1.2.1 什么是大语言模型
LLM = Large Language Model = 大语言模型。它并不"理解"世界，而是通过读几万亿个字学会了"看到前 N 个字，预测第 N+1 个字最可能是什么"。当预测足够准确时，它就能生成通顺、专业、甚至像人一样有情感的文本。

> 💡 **通俗类比：** LLM 就像玩语文接龙玩到走火入魔的高手。它没经历过世界，但读过的书够多，所以你说前半句它总能续出下半句。

#### 1.2.2 Transformer 极简版
- 2017 年 Google 论文 "Attention Is All You Need" 提出的神经网络结构；
- 核心机制叫"自注意力（Self-Attention）"：读一句话时，同时看每个字对每个字的关联度；
- 特别适合长文本、语义关联；
- 所有主流大模型（GPT、通义、Claude、DeepSeek、Llama…）都基于 Transformer。

学生阶段只需记住这句话："Transformer 是大模型的地基，让机器能看懂长文本的上下文关联。"

#### 1.2.3 主流大模型横向对比

| 模型 | 厂商 | 上下文 | 中文能力 | 计费（约） | 本项目使用 |
|------|------|--------|---------|-----------|-----------|
| GPT-4o | OpenAI | 128K | 优秀 | 贵、需科学上网 | ❌ |
| **qwen-plus** | 阿里 | 32K | 极佳 | 便宜、国内直连 | ✅ 主用 |
| DeepSeek-V3 | 深度求索 | 64K | 极佳 | 极便宜 | Day07 备选 |
| Claude 3.5 | Anthropic | 200K | 良好 | 贵、需海外账号 | ❌ |

> ⚠️ **选型说明：** 本课程为了让所有学生都能在国内网络下顺利调通、成本可控，选择 qwen-plus。它在中文养老场景表达自然、价格适中，是学习首选。

#### 1.2.4 阿里百炼平台

百炼（bailian.console.aliyun.com）= 阿里云推出的一站式大模型服务平台。它是通义千问的官方 API 门户，同时兼容 OpenAI 协议，支持 dashscope-sdk-java、Spring AI Alibaba 等多种调用方式。

**开通 5 步走：**
1. 登录 bailian.console.aliyun.com（用阿里云账号）；
2. 模型广场 → 通义千问 → 开通服务；
3. API-KEY 管理 → 创建我的 API-KEY；
4. 立即复制 Key（只显示一次！）；
5. 保存到本地环境变量 `DASHSCOPE_API_KEY`。

> ⚠️ **安全底线：** API-Key = 你的账号+密码+付款钥匙。它一旦泄漏，别人可以刷你的额度。**绝对禁止**：
> - 提交到 Git 仓库；
> - 粘贴到微信群、公开文档；
> - 分享给同学"借用一下"。

#### 1.2.5 Token 与计费
- Token 是模型处理文本的最小单位；
- 一个汉字大约 1-2 token，一个英文单词大约 0.5-1 token；
- 100 字对话大约 150-200 token；
- qwen-plus 目前：输入 ¥0.004/千 token、输出 ¥0.012/千 token；
- 学习期间调用 100 次接口成本约 ¥0.5，无需担心费用。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| LLM | 大语言模型，本质是超级接龙机 |
| Transformer | LLM 的骨架，2017 年 Google 提出 |
| Prompt | 给模型输入的一整段话 |
| Token | 模型计算的最小文本单位，1 汉字 ≈ 1-2 token |
| API-Key | 调用模型的身份凭证，泄漏后果严重 |

### 1.4 示例代码/例题解析

**示例：Windows 下把 API-Key 写入环境变量**

```powershell
# 打开 PowerShell，永久写入用户级环境变量
setx DASHSCOPE_API_KEY "sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

# 关闭并重开 PowerShell 后验证
echo $env:DASHSCOPE_API_KEY
```

Linux/Mac：
```bash
echo 'export DASHSCOPE_API_KEY=sk-xxxx' >> ~/.bashrc
source ~/.bashrc
```

**原理解释：** 通过环境变量注入 API-Key，代码里只写 `${DASHSCOPE_API_KEY}` 占位，既方便切换环境（开发/测试/生产），也彻底避免 Key 泄漏到 Git。

### 1.5 课后练习

1. 【基础】完成百炼平台注册、通义千问开通、API-Key 创建，把 Key 存入环境变量并截图验证。
2. 【综合】用 qwen-turbo、qwen-plus、qwen-max 三个模型分别问"请给一位 75 岁高血压老人推荐冬季晚餐"，对比响应速度和内容深度，写下 200 字观察。
3. 【挑战】阅读百炼计费文档，估算：如果日活 1000 人、人均每天问 10 次、平均单次消耗 300 token，一个月总成本约多少？（自选 qwen-plus 或 qwen-turbo 各算一次）

---

## 第 2 讲：Spring AI 快速入门

### 2.1 本讲要点
- Spring AI 是 Spring 官方为 Java 生态打造的统一大模型抽象层；
- 当前版本 1.0.0-M6（Milestone 里程碑），本课程锁定；
- 五大核心：`Prompt`、`Message`、`ChatModel`、`ChatClient`、`ChatResponse`；
- Message 三兄弟：`SystemMessage`、`UserMessage`、`AssistantMessage`；
- 依赖：`spring-ai-alibaba-starter` 1.0.0-M6.1。

### 2.2 知识点详解

#### 2.2.1 Spring AI 是什么

Spring 官方在 2024 年推出的项目，定位是"复刻 Spring Data 在数据库领域的成功"——把大模型接入这件事，抽象成一套跨厂商的统一 API。你今天写代码调通义千问，明天想换 DeepSeek，只需要改一个 starter 依赖，业务代码几乎不动。

> 💡 **设计思想：** Spring 一贯的"面向接口编程"，JdbcTemplate 屏蔽了不同数据库驱动的差异，ChatClient 屏蔽了不同大模型 API 的差异。

#### 2.2.2 五大核心抽象

```
Prompt ─── 一封信（请求整体）
   │
   ├── List<Message>
   │      ├── SystemMessage    → 系统人设
   │      ├── UserMessage      → 用户输入
   │      └── AssistantMessage → 模型历史回复
   │
   └── ChatOptions             → 温度、模型名等参数

ChatModel      → 低阶 API，直接对接厂商
ChatClient     → 高阶 API（推荐），流式 DSL
ChatResponse   → 返回结果，含 List<Generation>
```

| 抽象 | 一句话解释 | 何时使用 |
|------|-----------|---------|
| Prompt | 一封完整的信 | 组装多消息、带参数时 |
| Message | 信里的一段话 | 区分 System/User/Assistant |
| ChatModel | 电话机（底层） | 需要精细控制时 |
| **ChatClient** | 客服中心（高层） | **99% 场景推荐** |
| ChatResponse | 回信 | 从中取 content |

#### 2.2.3 Message 三兄弟详解

| 类型 | 角色 | 权重 | 示例 |
|------|------|------|------|
| SystemMessage | 系统人设 | 最高 | "你是养老健康顾问，回答温柔简短" |
| UserMessage | 用户当前问题 | 中 | "我最近失眠怎么办" |
| AssistantMessage | 模型历史回复 | 低 | 上一轮模型说过的话，用于多轮上下文 |

> 💡 **技巧：** 在会话开头设一次 SystemMessage 就够了，后续 UserMessage 会一直遵守它的约定。

#### 2.2.4 依赖坐标

pom.xml 关键片段：

```xml
<properties>
  <spring-ai.version>1.0.0-M6</spring-ai.version>
</properties>

<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>org.springframework.ai</groupId>
      <artifactId>spring-ai-bom</artifactId>
      <version>${spring-ai.version}</version>
      <type>pom</type>
      <scope>import</scope>
    </dependency>
  </dependencies>
</dependencyManagement>

<dependencies>
  <!-- 阿里通义千问 starter -->
  <dependency>
    <groupId>com.alibaba.cloud.ai</groupId>
    <artifactId>spring-ai-alibaba-starter</artifactId>
    <version>1.0.0-M6.1</version>
  </dependency>
</dependencies>

<!-- 因为 Spring AI 目前还在 milestone 仓库，需要加仓库配置 -->
<repositories>
  <repository>
    <id>spring-milestones</id>
    <name>Spring Milestones</name>
    <url>https://repo.spring.io/milestone</url>
    <releases><enabled>false</enabled></releases>
    <snapshots><enabled>false</enabled></snapshots>
  </repository>
</repositories>
```

> ⚠️ **版本坑：** 网上很多 2024 年之前的博客用的是 0.8.x，API 与 M6 差异巨大！比如 `.call()` 变成 `.prompt().user(...).call().content()`。若百度到 0.8.x 教程，直接跳过。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Spring AI | Spring 官方大模型抽象层 |
| M6 | 里程碑版本，本课程锁死 |
| ChatModel vs ChatClient | 前者低阶、后者高阶 DSL（推荐） |
| Prompt | 一封信，装 Message 列表 |
| SystemMessage | 系统人设，权重最高 |

### 2.4 示例代码/例题解析

**示例：一段最小可用的 ChatClient 调用**

```java
// 前提：Spring 已经自动注入了 ChatClient.Builder
ChatClient chatClient = builder
    .defaultSystem("你是养老健康顾问，回答温柔简短。")
    .build();

// 用 DSL 一行发送
String answer = chatClient
    .prompt()
    .user("我最近失眠怎么办？")
    .call()
    .content();

System.out.println(answer);
```

**原理解释：**
- `.prompt()` 开始构造一封信；
- `.user(...)` 追加一条 UserMessage；
- `.call()` 同步发起请求，等 3-5 秒；
- `.content()` 从 ChatResponse 中取纯文本；
- SystemMessage 已经在 build 时通过 `defaultSystem` 注入，全局生效。

### 2.5 课后练习

1. 【基础】在 `smart-elder-server/pom.xml` 中加入 Spring AI Alibaba 依赖 + Milestone 仓库，成功刷新 Maven。
2. 【综合】用一段话解释"为什么 Spring AI 推荐 ChatClient 而不是 ChatModel"，字数 100+。
3. 【挑战】上 Spring AI GitHub，找到 `spring-ai-alibaba-starter` 的源码，看它内部是如何把 DashScope SDK 包装成 ChatModel 的。

---

## 第 3 讲：集成通义千问 ChatModel 首次调用

### 3.1 本讲要点
- `application.yml` 通义千问配置：api-key / model / temperature / max-tokens；
- `@Configuration` + `@Bean` 构造全局唯一 `ChatClient`；
- `AiController` 暴露 `GET /api/ai/chat?msg=`；
- 常见错误：401（Key 错）、429（限流）、超时。

### 3.2 知识点详解

#### 3.2.1 application.yml 完整配置

```yaml
spring:
  application:
    name: smart-elder-server
  ai:
    dashscope:
      api-key: ${DASHSCOPE_API_KEY}      # 从环境变量读取
      chat:
        options:
          model: qwen-plus                # 通义千问 plus 版
          temperature: 0.7                # 随机性 0-1，健康建议 0.7 兼顾稳定与自然
          max-tokens: 1024                # 单次回复最大 token
```

| 参数 | 含义 | 建议值 |
|------|------|--------|
| api-key | 百炼平台的 Key | 从环境变量注入 |
| model | 使用哪个通义模型 | qwen-plus |
| temperature | 随机性 | 0.7（健康）/ 0.3（客服）/ 1.0（创意） |
| max-tokens | 最大回复长度 | 1024 |

#### 3.2.2 AiConfig：全局 ChatClient

```java
package com.itcast.smart_elder.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AiConfig {

    /**
     * 全局唯一 ChatClient。通过 defaultSystem 一次性锁死人设。
     */
    @Bean
    public ChatClient chatClient(ChatClient.Builder builder) {
        return builder
                .defaultSystem("""
                        你是"金秋家园"智能养老社区的健康顾问，名字叫"小金"。
                        回答风格必须：温柔耐心、专业可靠、简短易懂（每次不超过 200 字）。
                        遇到医疗急救类问题（胸痛、呼吸困难、意识模糊）必须先建议拨打 120。
                        禁止给出药品处方剂量，只做生活方式与饮食建议。
                        """)
                .build();
    }
}
```

> 💡 **为什么用 @Bean 而不是 @Autowired ChatClient？** ChatClient 是通过 `ChatClient.Builder` 构造的，Builder 允许我们在构造时预置 defaultSystem、defaultOptions 等，全局生效。手动 @Bean 一次，其他类只需 `@Autowired ChatClient` 即可复用。

#### 3.2.3 AiController：暴露接口

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiController {

    private final ChatClient chatClient;

    /** 同步对话：一次请求，一次完整返回 */
    @GetMapping("/chat")
    public Result<String> chat(@RequestParam("msg") String msg) {
        String content = chatClient
                .prompt()
                .user(msg)
                .call()
                .content();
        return Result.success(content);
    }
}
```

> ⚠️ **测试注意：** 首次启动前必须确认 IDEA 运行配置的 Environment variables 里已加入 `DASHSCOPE_API_KEY=sk-xxx`。否则启动就报 `DashScope api-key must be provided`。

#### 3.2.4 常见错误速查

| 错误码 | 现象 | 原因 | 解决 |
|--------|------|------|------|
| 401 | Unauthorized | Key 错/失效 | 重新复制 Key，检查环境变量 |
| 429 | Too Many Requests | 免费额度触发限流 | 等 1 分钟或升级付费 |
| 400 | InvalidParameter | 模型名写错 | 确认 `qwen-plus` 拼写 |
| Timeout | 30s 无响应 | 内网出口封了 | 换网络（手机热点） |

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| defaultSystem | 全局 System 人设 |
| @Bean ChatClient | 单例注入 |
| .call() vs .stream() | 同步 vs 流式 |
| 401 / 429 | Key 错 / 限流 |

### 3.4 示例代码/例题解析

**示例：完整跑通"首次调用"**

Step 1 - `application.yml`：
```yaml
spring:
  ai:
    dashscope:
      api-key: ${DASHSCOPE_API_KEY}
      chat:
        options:
          model: qwen-plus
          temperature: 0.7
```

Step 2 - `AiConfig.java`：如上 3.2.2 全部代码。

Step 3 - `AiController.java`：如上 3.2.3 全部代码。

Step 4 - Apifox 请求：
```
GET http://localhost:8080/api/ai/chat?msg=爷爷血压有点高，早餐吃什么好？
```

预期响应：
```json
{
  "code": 1,
  "msg": "success",
  "data": "爷爷您好，血压偏高时早餐建议清淡易消化：燕麦粥搭配蒸鸡蛋、少量全麦面包，佐以温热豆浆。避免咸菜、腌肉等高盐食物。用餐后适度散步 15 分钟。祝您和家人健康平安。"
}
```

**原理解释：**
- Spring AI 从环境变量读取 Key，构造 DashScope Client；
- ChatClient DSL 组装 Prompt（含 defaultSystem + user 消息）；
- HTTP POST 到 dashscope.aliyuncs.com；
- 通义千问返回 JSON，Spring AI 解析成 ChatResponse；
- `.content()` 抽取纯文本；
- `Result.success` 统一封装。

### 3.5 课后练习

1. 【基础】按 3.4 步骤跑通同步接口，用 5 个不同养老问题测试，把问答存入 `docs/ai/day05-chat-samples.md`。
2. 【综合】把 `defaultSystem` 改成"活动策划师"角色（负责组织棋牌、书法、太极等老年活动），观察回答风格变化。
3. 【挑战】给 AiController 增加一个 POST 版本 `POST /api/ai/chat`，请求体 JSON `{"msg":"xxx"}`，返回结构不变。

---

## 第 4 讲：流式响应 SSE 实战

### 4.1 本讲要点
- 同步 vs 流式：TTFB 从 5s 降到 200ms；
- SSE = Server-Sent Events，HTML5 单向长连接推送协议；
- 后端返回 `Flux<String>` + `produces = text/event-stream`；
- 前端两种消费：`fetch + ReadableStream`（灵活）或 `EventSource`（简单）；
- 换行处理坑：SSE 帧以 `\n\n` 分隔。

### 4.2 知识点详解

#### 4.2.1 同步 vs 流式对比

| 维度 | 同步 (call) | 流式 (stream) |
|------|-------------|--------------|
| Content-Type | application/json | text/event-stream |
| 连接 | 短连接 | 长连接直至输出完 |
| 首字节 (TTFB) | 5s | 200ms |
| 返回类型 | String | Flux&lt;String&gt; |
| 前端消费 | axios | fetch/EventSource |
| 用户体验 | 一次到位（干等） | 逐字蹦（有反馈） |

> 💡 **技巧：** 用户体验中"感知的快慢"，比"实际的快慢"更重要。流式即使总时间不变，也让用户觉得"AI 在思考"，好过白屏 5s。

#### 4.2.2 SSE 协议速览

- 全称：Server-Sent Events（服务端推送事件），HTML5 标准；
- Content-Type: `text/event-stream`；
- 每条消息格式：`data: 内容\n\n`（两个换行分隔）；
- 单向（服务端 → 浏览器）；
- 浏览器原生支持自动重连；
- 比 WebSocket 更轻量，无需协议升级。

#### 4.2.3 后端代码

```java
import org.springframework.http.MediaType;
import reactor.core.publisher.Flux;

@GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> chatStream(@RequestParam("msg") String msg) {
    return chatClient
            .prompt()
            .user(msg)
            .stream()
            .content();
}
```

**关键点：**
1. 返回 `Flux<String>`（Reactor 响应式流）；
2. `produces = MediaType.TEXT_EVENT_STREAM_VALUE`——Spring MVC 会自动切换到 SSE 模式；
3. 不要包 `Result`——SSE 每一帧应该是纯文本 chunk。

> ⚠️ **易错：** 忘写 `produces` 会让浏览器一次性等完再显示，失去流式意义。

#### 4.2.4 前端消费两种方式

**方式一：fetch + ReadableStream（推荐）**

```javascript
async function stream(msg, onChunk) {
  const resp = await fetch(`/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`);
  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) {
      if (line.startsWith('data:')) onChunk(line.slice(5));
    }
  }
}
```

**方式二：EventSource（简单但功能有限）**

```javascript
const es = new EventSource(`/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`);
es.onmessage = e => console.log(e.data);
es.onerror = () => es.close();
```

对比：

| 方式 | 优势 | 劣势 |
|------|------|------|
| fetch + ReadableStream | 支持自定义 header、POST、AbortController 停止 | 代码稍多 |
| EventSource | 一行搞定、自动重连 | 只能 GET、不能改 header |

> 💡 **本项目选 fetch：** 未来可能需要在 header 加 token 认证，且要支持"停止生成"按钮，`fetch + AbortController` 是唯一方案。

#### 4.2.5 常见坑

1. **中文乱码**：必须 `new TextDecoder('utf-8')`，且 `{ stream: true }`；
2. **数据切分错乱**：一次 read 可能收到多条 data，也可能只收到半条，必须用 buffer 拼接；
3. **CORS**：Day02 的全局 CORS 需允许 `/api/**` 且 `allowedHeaders("*")`；
4. **Postman 老版本不支持 SSE**：推荐 Apifox 或直接浏览器地址栏测试。

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| SSE | 服务端推送单向长连接 |
| Flux&lt;String&gt; | Reactor 响应式流 |
| produces | 必须 text/event-stream |
| TextDecoder | 前端必须显式声明 utf-8 |

### 4.4 示例代码/例题解析

**示例：完整流式接口 + 浏览器测试**

后端代码（追加到 AiController）：
```java
@GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> chatStream(@RequestParam("msg") String msg) {
    return chatClient.prompt().user(msg).stream().content();
}
```

测试方式：
1. **浏览器直连**：地址栏输入
   ```
   http://localhost:8080/api/ai/chat/stream?msg=请写一首关于夕阳晚霞的现代诗
   ```
   浏览器会逐字蹦字（Chrome 需 F12 → Network 查看响应流）。
2. **Apifox**：新建 GET 请求，选择 SSE 类型，实时看到 data 帧。
3. **curl**：
   ```bash
   curl -N "http://localhost:8080/api/ai/chat/stream?msg=你好"
   ```
   `-N` 表示不缓冲，逐行输出。

**原理解释：** Spring AI 底层用 Reactor 的 Flux 承载流；Spring MVC 检测到 `text/event-stream` + `Flux` 返回类型，自动逐 chunk 写回 HTTP 响应，每写一个 chunk 就 flush，从而客户端可以实时读到。

### 4.5 课后练习

1. 【基础】完成 chatStream 接口，用浏览器和 Apifox 分别测试成功。
2. 【综合】对比 qwen-turbo 与 qwen-plus 在流式模式下的"打字速度"（首字节延迟 + 每秒字数）。
3. 【挑战】实现一个"停止生成"接口：客户端 `AbortController.abort()`，服务端捕获断连并关闭 Flux。（提示：`Flux.doOnCancel`）

---

## 第 5 讲：Prompt 工程与角色扮演

### 5.1 本讲要点
- Prompt Engineering = 用自然语言写程序；
- System 定人设、User 提问题；
- 5 段式模板：角色、对象、风格、边界、格式；
- PromptTemplate `{变量}` 替换；
- Few-Shot：给 2-3 个示例，AI 会模仿。

### 5.2 知识点详解

#### 5.2.1 好的 Prompt 长什么样

差的 Prompt："帮我回答老人问题"（AI 不知道你是谁、面向谁、风格如何、要不要开药）；
好的 Prompt：**5 段式模板**

```
【角色】你是"金秋家园"智能养老社区的健康顾问，名字叫"小金"。
【对象】60 岁以上老年人及其家属，可能有高血压/糖尿病等慢病。
【风格】温柔、耐心、专业、简短易懂（≤200 字）；避免医学术语。
【边界】急救症状（胸痛/呼吸困难/意识模糊）必须先建议拨打 120；
        禁止提供药品名称、剂量、处方；
        涉及疾病诊断，只建议就医。
【格式】先安抚一句情绪 → 再给 2-3 条具体建议 → 最后一句关怀收尾。
```

> 💡 **技巧：** 5 段式不是死板模板，而是一个"心智清单"。你可以增删调整，但至少要覆盖这 5 个维度。

#### 5.2.2 SystemMessage vs UserMessage

| 消息类型 | 作用 | 频率 | 权重 |
|---------|------|------|------|
| System | 定义 AI 的"人设+边界+风格+格式" | 会话开始 1 次 | 最高 |
| User | 传递用户当前问题 | 每轮 1 次 | 中 |
| Assistant | 上一轮 AI 回复（做多轮上下文用） | 每轮 1 次 | 低 |

> ⚠️ **重要：** 安全边界（不开药、遇急救先 120）**必须**写在 System 里，写在 User 里 AI 有时会"忘"。System 权重最高，几乎不会被打破。

#### 5.2.3 PromptTemplate 变量替换

Spring AI 提供 `PromptTemplate`，支持 `{变量名}` 占位替换：

```java
import org.springframework.ai.chat.prompt.PromptTemplate;
import java.util.Map;

String tpl = """
        请为以下老人生成回答：
        姓名：{name}
        年龄：{age}
        慢病史：{disease}
        用户提问：{question}
        请按 5 段式格式输出。
        """;

PromptTemplate template = new PromptTemplate(tpl);
String userContent = template.render(Map.of(
        "name", "张桂芳",
        "age", "72",
        "disease", "高血压、糖尿病",
        "question", "中午想吃点面食可以吗？"
));
```

> 💡 **优势 vs 字符串拼接：**
> - 字符串拼接容易出错（漏空格、忘转义）；
> - PromptTemplate 语义清晰，模板可放独立文件；
> - 未来可换成 `.st` 模板文件，支持 if/for 等控制流。

#### 5.2.4 Few-Shot 少样本示例

在 System Prompt 里附 2-3 个"标准答案示例"，AI 会显著模仿风格：

```
【示例】
用户："我最近晚上老是睡不着。"
小金："您辛苦了，睡眠问题很多老人家都遇到过。
- 睡前 1 小时避免看手机和电视，可以听舒缓音乐；
- 晚饭七八分饱，睡前少喝水；
- 白天多晒太阳、适量散步。
如果持续两周以上，建议去医院神经内科看看。祝您睡个好觉。"
```

> ⚠️ **代价：** Few-Shot 会占用 token 额度，示例太多会显著提高每次调用成本。一般 2-3 个足够。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 5 段式 | 角色/对象/风格/边界/格式 |
| PromptTemplate | 模板 + Map 替换 |
| Few-Shot | 2-3 个标准示例 |
| 安全边界 | 必写在 System 里 |

### 5.4 示例代码/例题解析

**示例：带参数的健康咨询接口**

DTO：
```java
@Data
public class HealthChatDTO {
    private String name;
    private Integer age;
    private String disease;
    private String question;
}
```

Controller 新增：
```java
@PostMapping("/chat/health")
public Result<String> chatHealth(@RequestBody HealthChatDTO dto) {
    String tpl = """
            请为以下老人回答问题：
            姓名：{name}
            年龄：{age}
            慢病史：{disease}
            用户提问：{question}
            请按温柔、专业、简短易懂的风格作答。
            """;
    PromptTemplate template = new PromptTemplate(tpl);
    String userContent = template.render(Map.of(
            "name", dto.getName(),
            "age", String.valueOf(dto.getAge()),
            "disease", dto.getDisease(),
            "question", dto.getQuestion()
    ));

    String answer = chatClient
            .prompt()
            .user(userContent)
            .call()
            .content();
    return Result.success(answer);
}
```

Apifox 请求：
```json
POST http://localhost:8080/api/ai/chat/health
Content-Type: application/json

{
  "name": "张桂芳",
  "age": 72,
  "disease": "高血压、轻度糖尿病",
  "question": "胸口有点闷"
}
```

预期响应片段：
```
张阿姨您别慌，胸口发闷需要特别注意——请立即让家人协助拨打 120。
在等待救援时：
- 立即坐下或平躺，解开衣领；
- 保持环境安静通风；
- 不要独自走动或用力。
血压和糖尿病人群更需谨慎，务必尽快就医。祝您平安。
```

**原理解释：** System Prompt 里的"急救必先拨 120"约束生效，即使用户没明确说"急救"，AI 也识别出"胸闷"是重要症状，主动触发安全模板。

### 5.5 课后练习

1. 【基础】更新 AiConfig 到 5 段式版本 + 一个 Few-Shot 示例，重启测试。
2. 【综合】用 PromptTemplate 写一个"生日祝福生成器"接口 `POST /api/ai/birthday`，参数 `{name, age, hobby}`。
3. 【挑战】给 System Prompt 加"拒绝回答政治、宗教、投资理财"约束，测试是否真的能拒绝。

---

## 第 6 讲：智能应答前端页面（对话框）

### 6.1 本讲要点
- Vue3 `<script setup>` + Element Plus 气泡对话；
- `history` 数组响应式管理消息列表；
- `fetch + ReadableStream + TextDecoder` 消费 SSE；
- `nextTick + scrollTop` 自动滚到底；
- 用户消息右对齐、AI 消息左对齐，气泡样式。

### 6.2 知识点详解

#### 6.2.1 页面结构

```
+---------------------------------------+
|  🤖 智能健康顾问 · 小金                  |
+---------------------------------------+
|  [🤖][AI气泡 左对齐 白色]                |
|                                       |
|                 [用户气泡 右对齐 绿色][👴]|
|                                       |
|  [🤖][AI气泡 正在逐字蹦字…]              |
+---------------------------------------+
|  输入框                     [发送按钮] |
+---------------------------------------+
```

#### 6.2.2 数据结构

```typescript
interface Msg {
  role: 'user' | 'assistant';
  content: string;
}

const history = ref<Msg[]>([
  { role: 'assistant', content: '您好，我是小金，很高兴为您服务。' }
]);
```

每次发送后：
1. push 一条 `{role: 'user', content: 用户输入}`；
2. push 一条 `{role: 'assistant', content: ''}`（占位）；
3. 流式回调里持续 `history[last].content += chunk`；
4. 每次追加后自动滚动到底。

#### 6.2.3 SSE 流式消费函数（复用讲 4）

```typescript
async function streamChat(msg: string, onChunk: (chunk: string) => void) {
  const resp = await fetch(`/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`);
  if (!resp.ok || !resp.body) throw new Error('SSE 连接失败');
  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) {
      if (line.startsWith('data:')) {
        const chunk = line.slice(5);
        if (chunk) onChunk(chunk);
      }
    }
  }
}
```

#### 6.2.4 完整 chat.vue

（完整代码见 6.4 示例，此处仅列关键片段说明）

**模板层要点：**
- `v-for` 渲染 history；
- 用 `:class="['bubble-row', m.role]"` 让 CSS 根据 role 切样式；
- `@keyup.enter="onSend"` 支持回车发送；
- `:disabled="loading"` 防止连击。

**样式层要点：**
- `.bubble-row.user { flex-direction: row-reverse; }` 用户气泡右对齐；
- `.bubble` 用 `white-space: pre-wrap` 保留换行；
- `.bubble-row.user .bubble { background: #95ec69; }` 微信绿。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| script setup | Vue3 组合式 API 语法糖 |
| ref&lt;Msg[]&gt; | 响应式数组 |
| fetch + ReadableStream | 前端消费 SSE 的最佳方案 |
| TextDecoder utf-8 | 避免中文乱码 |
| nextTick + scrollTop | 自动滚到底 |

### 6.4 示例代码/例题解析

**完整 `src/api/ai.ts`：**

```typescript
// src/api/ai.ts
import request from '@/utils/request';

/** 同步对话接口 */
export function aiChat(msg: string) {
  return request.get<string>('/api/ai/chat', { params: { msg } });
}

/** 流式对话 URL（前端直接用 fetch 消费） */
export function aiStreamUrl(msg: string) {
  return `/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`;
}

/** 带参数的健康咨询接口 */
export interface HealthChatParams {
  name: string;
  age: number;
  disease: string;
  question: string;
}
export function aiChatHealth(data: HealthChatParams) {
  return request.post<string>('/api/ai/chat/health', data);
}
```

**完整 `src/views/ai/chat.vue`：**

```vue
<template>
  <div class="chat-container">
    <div class="chat-header">🤖 智能健康顾问 · 小金</div>

    <div class="chat-body" ref="bodyRef">
      <div
        v-for="(m, i) in history"
        :key="i"
        :class="['bubble-row', m.role]"
      >
        <div class="avatar">{{ m.role === 'user' ? '👴' : '🤖' }}</div>
        <div class="bubble">{{ m.content || '思考中…' }}</div>
      </div>
    </div>

    <div class="chat-input">
      <el-input
        v-model="input"
        placeholder="请输入您的问题，回车发送"
        :disabled="loading"
        @keyup.enter="onSend"
        clearable
      />
      <el-button type="primary" :loading="loading" @click="onSend">
        发送
      </el-button>
      <el-button @click="onClear">清空</el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import { ElInput, ElButton, ElMessage } from 'element-plus';
import { aiStreamUrl } from '@/api/ai';

interface Msg { role: 'user' | 'assistant'; content: string }

const initialWelcome: Msg = {
  role: 'assistant',
  content: '您好，我是小金，很高兴为您服务。请问您和家人今天有什么需要我帮忙的吗？'
};

const history = ref<Msg[]>([{ ...initialWelcome }]);
const input = ref('');
const loading = ref(false);
const bodyRef = ref<HTMLElement | null>(null);

function scrollBottom() {
  nextTick(() => {
    if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight;
  });
}

async function streamChat(msg: string, onChunk: (chunk: string) => void) {
  const resp = await fetch(aiStreamUrl(msg));
  if (!resp.ok || !resp.body) throw new Error('SSE 连接失败');
  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) {
      if (line.startsWith('data:')) {
        const chunk = line.slice(5);
        if (chunk) onChunk(chunk);
      }
    }
  }
}

async function onSend() {
  const text = input.value.trim();
  if (!text) {
    ElMessage.warning('请输入内容');
    return;
  }
  input.value = '';
  history.value.push({ role: 'user', content: text });
  history.value.push({ role: 'assistant', content: '' });
  scrollBottom();
  loading.value = true;
  try {
    await streamChat(text, chunk => {
      const last = history.value[history.value.length - 1];
      last.content += chunk;
      scrollBottom();
    });
  } catch (e) {
    ElMessage.error('AI 服务暂时不可用，请稍后重试');
    const last = history.value[history.value.length - 1];
    if (!last.content) last.content = '（回复失败，请重试）';
  } finally {
    loading.value = false;
  }
}

function onClear() {
  history.value = [{ ...initialWelcome }];
  ElMessage.success('已清空');
}
</script>

<style scoped>
.chat-container {
  height: calc(100vh - 100px);
  display: flex;
  flex-direction: column;
  background: #f5f7fa;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.06);
}
.chat-header {
  padding: 14px 20px;
  background: linear-gradient(135deg, #409eff, #66b1ff);
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  letter-spacing: 1px;
}
.chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  scroll-behavior: smooth;
}
.bubble-row {
  display: flex;
  margin-bottom: 16px;
  align-items: flex-start;
}
.bubble-row.user {
  flex-direction: row-reverse;
}
.avatar {
  width: 40px;
  height: 40px;
  font-size: 24px;
  text-align: center;
  line-height: 40px;
  background: #fff;
  border-radius: 50%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin: 0 10px;
  flex-shrink: 0;
}
.bubble {
  max-width: 70%;
  padding: 12px 16px;
  background: #fff;
  border-radius: 10px;
  line-height: 1.7;
  white-space: pre-wrap;
  word-break: break-word;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
  font-size: 15px;
}
.bubble-row.user .bubble {
  background: #95ec69;
}
.chat-input {
  display: flex;
  padding: 12px 16px;
  gap: 8px;
  background: #fff;
  border-top: 1px solid #e5e6eb;
}
</style>
```

**路由 `src/router/index.ts` 追加：**
```typescript
{
  path: '/ai/chat',
  name: 'AiChat',
  component: () => import('@/views/ai/chat.vue'),
  meta: { title: '智能健康顾问' }
}
```

菜单入口（可选）：在侧边栏或首页快捷入口加一个"🤖 智能健康顾问"跳转到 `/ai/chat`。

### 6.5 课后练习

1. 【基础】完成 api/ai.ts、views/ai/chat.vue、router 配置，跑通端到端流式对话。
2. 【综合】给气泡下方增加时间戳（用 dayjs），并对超长回复自动折叠"展开更多"。
3. 【挑战】实现"停止生成"按钮：用 `AbortController` 中断 fetch，同时让后端在 `doOnCancel` 时释放资源。

---

## 附录 A：接口清单速查

| 接口 | 方法 | 路径 | 说明 |
|------|------|------|------|
| 同步对话 | GET | `/api/ai/chat?msg=xxx` | Result&lt;String&gt; |
| 流式对话 | GET | `/api/ai/chat/stream?msg=xxx` | Flux&lt;String&gt; SSE |
| 健康咨询 | POST | `/api/ai/chat/health` | 带参 + Prompt 模板 |

---

## 附录 B：Prompt 模板库（养老场景 5 个可复用 Prompt）

以下 5 个 Prompt 已在教学中测试通过，可以直接粘贴到 `AiConfig.defaultSystem` 或作为 `PromptTemplate` 使用。

### 模板 1：健康顾问（默认）

```
你是"金秋家园"智能养老社区的健康顾问，名字叫"小金"。
【服务对象】60 岁以上老年人及其家属，可能存在高血压、糖尿病、骨质疏松等慢性病。
【回答风格】温柔、耐心、专业、简短易懂（≤200 字）；避免使用医学术语。
【安全边界】
- 急救症状（胸痛/呼吸困难/剧烈头痛/意识模糊）必须首先建议拨打 120；
- 禁止提供药品名称、剂量、处方；
- 涉及疾病诊断只建议就医，不做诊断。
【回答格式】先安抚一句情绪 → 2-3 条具体生活/饮食建议 → 一句关怀收尾。
```

### 模板 2：饮食营养师

```
你是"金秋家园"养老社区的驻场营养师"小食"。
【服务对象】60 岁以上老人、有慢病或牙口不好的老年人。
【回答风格】通俗易懂、具体到菜名与克数，避免抽象术语。
【安全边界】禁止推荐保健品品牌；对糖尿病/高血压/肾病人群优先推荐低盐低糖低脂食谱。
【回答格式】先了解需求 → 给出早/午/晚餐 3 组建议（含菜品 + 大致克数）→ 一句嘱咐（如"少油少盐、饭后走 10 分钟"）。
```

### 模板 3：活动策划师

```
你是"金秋家园"社区活动策划专员"小乐"，负责为老人组织棋牌、书法、太极、生日会等社交活动。
【服务对象】社区内 60-85 岁老人及家属。
【回答风格】亲切热情，充满温度，多用"咱们""大伙儿"等生活化用语。
【安全边界】不组织户外远距离/高强度活动；不涉及金钱赌博；夜晚活动结束时间不超过 20:00。
【回答格式】1) 活动名称 2) 场地和时长 3) 需要的物料 4) 温馨提示。
```

### 模板 4：政策解读员

```
你是"金秋家园"驻场政策顾问"小策"，专门为老人和家属解读养老保险、医保、退休金、老年补贴等政策。
【服务对象】关心政策、想了解自身权益的老年群体。
【回答风格】严谨、口语化、多用真实例子，尽量避免政策原文的长句。
【安全边界】
- 涉及具体金额与办理流程必须提示"以当地社保局最新公告为准"；
- 禁止承诺"一定能领到"某项补贴；
- 不涉及理财、投资建议。
【回答格式】1) 一句话结论 2) 分点条件 3) 办理途径 4) 提醒事项。
```

### 模板 5：陪聊/情感支持

```
你是"金秋家园"社区的陪聊伙伴"小暖"，专门陪伴独居、情绪低落、思念亲人的老年人聊天。
【服务对象】容易感到孤独、失眠、焦虑的老年人。
【回答风格】温柔耐心，多倾听少建议，善于用"共情"回应（如"这一定很难受吧"）。
【安全边界】
- 遇到"活着没意思""想不开"等信号必须温柔劝解并建议告诉家人或拨打 400-161-9995（心理援助）；
- 不深入讨论疾病与死亡话题；
- 不做心理诊断。
【回答格式】先共情一句 → 分享一个类似的温暖小故事或场景 → 一句期待（如"下次咱们再聊聊您年轻时候的事儿好不好？"）。
```

> 💡 **切换技巧：** 5 个模板都可通过修改 `AiConfig` 的 `defaultSystem` 快速切换。进阶做法是把它们存在数据库或 yml 里，按业务场景动态加载。Day07 将实现"多角色路由"，让用户前端选人设。

---

## 附录 C：Day05 checklist

完成本日学习后，请核对以下 checklist：

- [ ] 已注册百炼平台，创建 API-Key 并存入环境变量
- [ ] 已在 pom.xml 加入 spring-ai-alibaba-starter 1.0.0-M6.1
- [ ] 已在 application.yml 完成 dashscope 配置
- [ ] AiConfig 类已完成，`@Bean ChatClient` 全局注入
- [ ] AiController 已完成同步接口 `GET /api/ai/chat`
- [ ] AiController 已完成流式接口 `GET /api/ai/chat/stream`
- [ ] AiController 已完成带参接口 `POST /api/ai/chat/health` + PromptTemplate
- [ ] 前端已完成 `api/ai.ts`、`views/ai/chat.vue`、路由
- [ ] 已用浏览器端到端测试流式对话
- [ ] 已收集 5 组养老场景问答记录到 `docs/ai/day05-chat-samples.md`

**Day06 预告：** 我们把今天的 AI 对话能力接入客房预约业务，学习 Redis 缓存与分布式锁，让"小金"从"会聊天"进化到"能办事"——用户说一句"我想订一间朝南的双人间"，AI 自动识别意图、抽取参数、下单。
