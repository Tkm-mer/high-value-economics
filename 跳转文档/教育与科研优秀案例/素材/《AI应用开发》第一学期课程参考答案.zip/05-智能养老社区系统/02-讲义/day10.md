# 《智能养老社区系统》- 学生讲义 - Day10：性能优化与调优实战

**授课日：Day 10 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01 建表完成；Day03 已有会员分页接口 `/api/members/page`；Day06 已有预约接口 `/api/reservations` 并接入 Redis；Day08 已有报表 SQL；Day09 已有 AOP 日志与全局异常。**

---

## 第 1 讲：慢 SQL 定位与执行计划

### 1.1 本讲要点
- 线上性能问题 80% 来自慢 SQL，"诊断先于治疗"
- MySQL 慢查询日志三参数：`slow_query_log` / `long_query_time` / `log_queries_not_using_indexes`
- `mysqldumpslow` 聚合分析工具（`-s at/t/c` 三种排序）
- `EXPLAIN` 12 字段速览，重点掌握 `type` / `key` / `rows` / `Extra`
- `type` 等级从优到差：`system > const > eq_ref > ref > range > index > ALL`
- `Extra` 四大警告：`Using filesort` / `Using temporary` / `Using join buffer` / `Using where`
- B+ 树索引原理：高扇出、低高度，通常 3-4 层

### 1.2 知识点详解

#### 1.2.1 为什么先讲"诊断"

一个 Java Web 系统 80% 以上的性能故障 = **慢 SQL**。剩下 20% 分给：缓存不命中、GC 频繁、外部 API 抖动、锁竞争。所以优化的**第一枪永远打向数据库**。

在动手加索引之前，最重要的一步是：**找到到底哪一条 SQL 慢，以及它究竟慢在哪一步**。诊断错了，加再多索引也是白加。

#### 1.2.2 开启 MySQL 慢查询日志

MySQL 自带慢日志功能，默认关闭。开启三步走：

```sql
-- 1) 查当前状态
SHOW VARIABLES LIKE 'slow_query_log%';
SHOW VARIABLES LIKE 'long_query_time';

-- 2) 临时开启（重启失效）
SET GLOBAL slow_query_log = ON;
SET GLOBAL long_query_time = 1;                -- 超过 1 秒算慢
SET GLOBAL log_queries_not_using_indexes = ON; -- 不走索引也记
SET GLOBAL slow_query_log_file = '/var/log/mysql/slow.log';

-- 3) 永久开启：写入 my.cnf 的 [mysqld] 节
-- slow_query_log = 1
-- long_query_time = 1
-- slow_query_log_file = /var/log/mysql/slow.log
```

> **注意：** `long_query_time` 默认 10 秒，太宽松了。**开发/测试环境建议设 1 秒，生产环境 2-3 秒**。写业务代码时你自己都嫌 1 秒慢，何况用户？

#### 1.2.3 mysqldumpslow：慢日志聚合

原始慢日志一天可能几十万行，`mysqldumpslow` 把"结构相同、参数不同"的 SQL 聚合成同一条：

```bash
# TOP 10 平均耗时最长
mysqldumpslow -s at -t 10 /var/log/mysql/slow.log

# TOP 10 总耗时最长（最关注的）
mysqldumpslow -s t -t 10 /var/log/mysql/slow.log

# TOP 10 执行次数最多
mysqldumpslow -s c -t 10 /var/log/mysql/slow.log
```

输出示例：
```
Count: 2843  Time=3.42s (9721s)  Lock=0.00s (2s)  Rows=1.0 (2843)  root[root]@localhost
SELECT * FROM elder_member WHERE phone = 'S' ORDER BY create_time DESC LIMIT N
```
"`Count=2843` 次、总耗时 9721 秒"——这就是要优先优化的对象。

> **技巧：** 生产环境更推荐 Percona 的 `pt-query-digest`，它比 `mysqldumpslow` 输出更丰富，能给出耗时分布直方图、锁等待占比等。命令：`pt-query-digest slow.log > report.txt`。

#### 1.2.4 EXPLAIN 十二字段

```sql
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800000001';
```

| 字段 | 含义 | 关注点 |
|------|------|--------|
| id | 查询序号 | 数字大的先执行；相同则从上到下 |
| select_type | 查询类型 | SIMPLE / PRIMARY / SUBQUERY / DERIVED / UNION |
| table | 涉及表 | 派生表显示 `<derivedN>` |
| partitions | 分区 | 未分区显示 NULL |
| **type** ★ | **访问类型** | **本行最重要** |
| possible_keys | 可能用到的索引 | 优化器"考虑过"的候选 |
| **key** ★ | **实际用到的索引** | NULL 表示没走索引 |
| key_len | 索引使用长度 | 联合索引用了几个字段可算出 |
| ref | 与索引对比的列/常量 | `const` / 表.列 |
| **rows** ★ | **预估扫描行数** | 越小越好；量级即效率 |
| filtered | 过滤后剩余百分比 | 100 表示条件几乎没过滤 |
| **Extra** ★ | **附加信息** | Using index / Using filesort / Using temporary |

#### 1.2.5 type 等级从优到差

```
system > const > eq_ref > ref > range > index > ALL
                                                 ↑
                                           全表扫描（灾难）
```

| 等级 | 场景 | 示例 |
|------|------|------|
| `const` | 主键或唯一索引等值 | `WHERE id = 1` |
| `eq_ref` | join 时用主键或唯一索引等值 | `ON a.id = b.aid` |
| `ref` | 普通索引等值 | `WHERE phone = ?` |
| `range` | 范围 | `WHERE create_time > '2024-01-01'` |
| `index` | 全索引扫描（不回表） | 比 ALL 好但仍需警惕 |
| `ALL` | 全表扫描 | **生产上 rows > 1 万还是 ALL = 慢 SQL 前兆** |

#### 1.2.6 Extra 四大警告

| Extra 值 | 含义 | 是否需要优化 |
|----------|------|-------------|
| Using index | 覆盖索引，不回表 | ✅ 好 |
| Using where | Server 层再过滤 | 中性 |
| Using filesort | 无法用索引排序 | ⚠️ 要优化 |
| Using temporary | 用了临时表 | ⚠️ 高危 |
| Using join buffer | 无索引 join | ⚠️ 慢 |

#### 1.2.7 B+ 树：为什么加索引就快

```
         [30 | 60]                    ← 根节点（1 次 IO）
        /    |    \
   [10|20][40|50][70|80]              ← 中间层（1 次 IO）
     |      |      |
  叶子链表 ← 双向链表串起所有数据 →     ← 叶子节点（1 次 IO）
```

一句话：**B+ 树把 O(n) 查找降为 O(log n)**，一张 500 万行表通常 3 层就够。加索引 = 让 MySQL 从"翻 500 万页"变成"翻 3 页"。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 慢查询日志 | MySQL 内置，`long_query_time` 阈值 |
| mysqldumpslow | 聚合分析器，按 at/t/c 排序 |
| EXPLAIN | 查看执行计划，重点四字段 |
| B+ 树 | 高扇出低高度，索引核心结构 |

### 1.4 示例代码/例题解析

**示例 1：造 100 万行数据（MySQL 8.0+）**
```sql
INSERT INTO elder_member (name, gender, age, phone, id_card, address,
                          member_level, create_time)
SELECT
  CONCAT('会员', LPAD(seq, 7, '0')),
  IF(seq % 2 = 0, 1, 2),
  60 + seq % 30,
  CONCAT('138', LPAD(seq, 8, '0')),
  CONCAT('4101', LPAD(seq, 14, '0')),
  '河南省郑州市金水区',
  1 + seq % 4,
  DATE_ADD('2020-01-01', INTERVAL seq MINUTE)
FROM (
  WITH RECURSIVE t(seq) AS (
    SELECT 1 UNION ALL SELECT seq+1 FROM t WHERE seq < 1000000
  )
  SELECT seq FROM t
) x;
```

**示例 2：删索引 → 观察全表扫描**
```sql
ALTER TABLE elder_member DROP INDEX idx_phone;
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800500000';
-- 输出：type=ALL, key=NULL, rows≈1000000, Extra=Using where
```

**示例 3：加回索引 → ref 型访问**
```sql
ALTER TABLE elder_member ADD INDEX idx_phone (phone);
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800500000';
-- 输出：type=ref, key=idx_phone, rows=1, Extra=Using where
```
**原理解释：** 100 万行 → 1 行，仅是把"翻书"变成"看目录再翻页"。

### 1.5 课后练习

1. 【基础】写一条 SQL 让 EXPLAIN 输出 `type=const`。
2. 【基础】写一条 SQL 让 EXPLAIN 输出 `Extra=Using index`（提示：覆盖索引）。
3. 【综合】在自己的 MySQL 里执行 `SET GLOBAL slow_query_log = ON; SET GLOBAL long_query_time = 0.1;`，造 10 万行数据后跑 3 条 SQL，把 `EXPLAIN` 结果记录到 Excel。
4. 【挑战】如果一张表 3 亿行，B+ 树高度会不会超过 4 层？（提示：单页 16KB，主键 8 字节 + 指针 6 字节，扇出约 1170）

### 1.6 课后思考

- `long_query_time` 单位是什么？可以设成小数吗？
- `EXPLAIN` 输出里 `type=index` 和 `type=ALL` 哪个更好？为什么？
- `Extra` 里出现 `Using filesort` 意味着什么问题？

### 1.7 课后作业

1. 把慢日志开启并跑一天，第二天用 `mysqldumpslow -s t -t 10` 截图给组长。
2. 对 Day03 会员分页接口执行的完整 SQL 跑一次 `EXPLAIN`，把结果贴到日报里。
3. 阅读《MySQL 高性能》第 3 章"schema 与数据类型优化"。

---

## 第 2 讲：索引优化与 SQL 改写

### 2.1 本讲要点
- 单列索引 vs 联合索引：**联合索引一顶多个**
- **最左前缀原则**：`(a,b,c)` 索引只对以 `a` 开头的过滤生效
- **覆盖索引**：`SELECT` 的列全部落在索引里，避免"回表"
- **索引下推 ICP**：MySQL 5.6+，把 WHERE 部分条件下推到存储引擎层
- 索引失效 10 大场景：函数、隐式转换、`OR` 混用、`LIKE '%x'`、`!=`、`IS NULL`、字符集不一致、优化器估算失误、跳列、方向不一致
- SQL 改写常见套路：分页深翻页 → 延迟关联；`IN(大集合)` → JOIN 子表

### 2.2 知识点详解

#### 2.2.1 单列 vs 联合索引

```sql
-- 单列
KEY idx_phone (phone)
KEY idx_level (member_level)
KEY idx_ctime (create_time)

-- 联合（推荐，一条顶三条）
KEY idx_level_ctime_phone (member_level, create_time, phone)
```

**联合索引省空间也省维护**。三条单列索引对同一张 100 万行表 = 三棵 B+ 树 = 三份维护成本；一条联合索引 = 一棵树。

#### 2.2.2 最左前缀原则

```
idx_a_b_c (a, b, c)
── WHERE a=?                    ✅ 命中 (a)
── WHERE a=? AND b=?             ✅ 命中 (a, b)
── WHERE a=? AND b=? AND c=?     ✅ 全命中
── WHERE b=?                    ❌ 跳过 a，索引失效
── WHERE a=? AND c=?             ⚠️ 只命中 (a)，c 走不到
── WHERE b=? AND a=?             ✅ 命中 (a, b)（优化器会自动调换顺序）
```

> **注意：** "顺序"是指**查询里必须出现前缀字段**，而不是"SQL 里字段的书写顺序"。MySQL 优化器会自动重排 `AND`，你只需保证"前缀字段被 WHERE 用到"。

#### 2.2.3 覆盖索引 vs 回表

InnoDB 的两类索引：
- **聚簇索引**（主键索引）：叶子节点存**整行数据**
- **辅助索引**（普通索引）：叶子节点存**主键值**

```
辅助索引 idx_phone
  └─ 叶子节点：(phone, id)     ← 只有主键，没有其他字段

  查询：SELECT * FROM elder_member WHERE phone = '138xxx'
  流程：走 idx_phone → 拿到 id → 回聚簇索引查完整行  ← 回表
```

**覆盖索引** = SELECT 列全在辅助索引里，不需要回表：
```sql
-- 回表（要 * 全列）
SELECT * FROM elder_member WHERE phone = '13800000001';

-- 覆盖索引
SELECT id, phone FROM elder_member WHERE phone = '13800000001';
-- EXPLAIN 会看到 Extra=Using index
```

#### 2.2.4 索引下推 (Index Condition Pushdown)

MySQL 5.6+ 新特性。传统流程：
```
存储引擎按索引扫 → 拿主键回表 → Server 层再过滤 WHERE
```
ICP 流程：
```
存储引擎按索引扫 + 直接在索引上过滤 → 只回表满足条件的行
```
`Extra=Using index condition` 就代表 ICP 生效。收益：**减少回表次数**。

#### 2.2.5 索引失效 10 大场景

| # | 场景 | 反例 | 正例 |
|---|------|------|------|
| 1 | 函数计算 | `WHERE DATE(create_time)='2024-01-01'` | `WHERE create_time >= '2024-01-01' AND create_time < '2024-01-02'` |
| 2 | 隐式类型转换 | `WHERE phone = 13800000001`（数字） | `WHERE phone = '13800000001'`（字符串） |
| 3 | `OR` 混用非索引列 | `WHERE phone=? OR address=?` | UNION 或给 `address` 加索引 |
| 4 | `LIKE '%xxx'` | `WHERE name LIKE '%张'` | `WHERE name LIKE '张%'` 或用 ES |
| 5 | `!=` / `<>` / `NOT IN` | `WHERE status != 0` | 改用 `IN (1,2,3)` |
| 6 | `IS NULL` | 老版本 MySQL | 建索引时 `NOT NULL DEFAULT ''` |
| 7 | 字符集/校对规则不一致 | join 两表字符集不同 | 统一 `utf8mb4_general_ci` |
| 8 | 优化器估算失误 | 数据倾斜时选错索引 | `FORCE INDEX(idx_x)` |
| 9 | 联合索引跳列 | `(a,b,c)` 索引查 `a=? AND c=?` | 补 `b=?` 或改索引顺序 |
| 10 | ORDER BY 方向不一致 | idx `(a ASC, b DESC)` 查 `ORDER BY a ASC, b ASC` | 建索引时按查询方向 |

> 💡 **口诀速记：** "**函型或模非空集，字估跳向**"——分别对应函数、类型、OR、LIKE、非等、NULL、字符集、估算、跳列、方向。

#### 2.2.6 SQL 改写案例 1：分页深翻页

问题 SQL：
```sql
SELECT id, name, phone FROM elder_member
ORDER BY create_time DESC
LIMIT 100000, 20;   -- 深翻页
```
原理上 MySQL 要**扫 100020 行再丢掉前 100000 行**，越翻越慢。

改写 —— **延迟关联**：
```sql
SELECT m.id, m.name, m.phone
FROM elder_member m
JOIN (
  SELECT id FROM elder_member
  ORDER BY create_time DESC
  LIMIT 100000, 20
) t ON m.id = t.id;
```
子查询只在**覆盖索引** `(create_time, id)` 上跑，避免了回表 100020 次。实测提升 5-10 倍。

再进一步 —— **游标翻页**（推荐给"下拉加载更多"）：
```sql
SELECT id, name, phone FROM elder_member
WHERE create_time < ?    -- 上一页最后一条的 create_time
ORDER BY create_time DESC LIMIT 20;
```
无论翻到第几页都是**常数时间**。

#### 2.2.7 SQL 改写案例 2：IN 大集合

问题 SQL：
```sql
SELECT * FROM room_reservation
WHERE member_id IN (SELECT id FROM elder_member WHERE member_level = 3);
```

改写 —— **改 JOIN**：
```sql
SELECT r.* FROM room_reservation r
JOIN elder_member m ON r.member_id = m.id
WHERE m.member_level = 3;
```

MySQL 8.0+ 已经把大部分 IN 子查询自动优化为半连接（semi-join），但**旧版本或复杂场景写 JOIN 更保险**。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 联合索引 | 一条顶多条，字段顺序遵守"等值→排序→范围" |
| 最左前缀 | 前缀字段必须在 WHERE 出现 |
| 覆盖索引 | SELECT 列都在索引里，不回表 |
| 索引下推 | 引擎层多做一次过滤，减少回表 |
| 延迟关联 | 深翻页神器：子查询走覆盖索引 |

### 2.4 示例代码/例题解析

**示例 1：给 Day03 会员分页 SQL 加索引**
```sql
-- 目标 SQL
SELECT id, name, phone, member_level, create_time
FROM elder_member
WHERE member_level = 3 AND phone LIKE '138%'
ORDER BY create_time DESC
LIMIT 0, 20;

-- 设计索引（等值 → 排序 → 范围）
CREATE INDEX idx_level_ctime_phone
ON elder_member (member_level, create_time, phone);

-- EXPLAIN 前
-- type=ref, key=idx_member_level, rows=250000, Extra=Using where; Using filesort

-- EXPLAIN 后
-- type=range, key=idx_level_ctime_phone, rows≈100,
-- Extra=Using where; Using index condition
```
**原理解释：** `filesort` 消失、`rows` 从 25 万降到 100 —— **性能提升 2500 倍**。

**示例 2：给 Day06 预约表加索引**
```sql
-- "我的预约"列表
CREATE INDEX idx_member_status_date
ON room_reservation (member_id, status, check_in_date);

-- 管理端"某日待入住"
CREATE INDEX idx_date_status
ON room_reservation (check_in_date, status);
```

**示例 3：识别索引失效并改写**
```sql
-- ❌ 函数计算导致 idx_ctime 失效
SELECT * FROM elder_member WHERE DATE(create_time) = '2024-01-01';

-- ✅ 改写
SELECT * FROM elder_member
WHERE create_time >= '2024-01-01' AND create_time < '2024-01-02';
```

### 2.5 课后练习

1. 【基础】给定 SQL `SELECT id, name FROM elder_member WHERE age > 70 ORDER BY member_level`，写出最合适的索引 DDL。
2. 【基础】说出下列语句为什么索引失效，并改写：
   - `SELECT * FROM elder_member WHERE SUBSTRING(phone, 1, 3) = '138'`
   - `SELECT * FROM room_reservation WHERE status + 1 = 2`
3. 【综合】把 Day03 会员分页接口改成"延迟关联"版本，测试 `LIMIT 100000, 20` 前后耗时。
4. 【挑战】联合索引 `(a, b, c)` 上，SQL `WHERE a=? AND c=? ORDER BY b` 能否用到索引？为什么？

### 2.6 课后思考

- `KEY idx (a, b, c)` 联合索引，`WHERE b=1 AND a=2` 能走索引吗？
- 什么叫"回表"？什么情况下会发生？
- `Extra=Using index condition` 是什么？

### 2.7 课后作业

1. 对 Day08 大屏所有 SQL 跑一遍 EXPLAIN，把 `type=ALL` 或 `Using filesort` 的 SQL 找出来，为每条设计一条改进索引。
2. 阅读文档《MySQL 索引下推》并写 200 字心得。
3. 用延迟关联改写自己项目里任意一个分页接口，提交 PR。

---

## 第 3 讲：缓存优化——热点数据与穿透/雪崩/击穿

### 3.1 本讲要点
- 缓存三兄弟的**准确定义**：穿透 / 雪崩 / 击穿
- 穿透对策：**空值缓存** + **布隆过滤器**（Guava BloomFilter）
- 雪崩对策：**随机 TTL** + Redis 集群 + 熔断降级
- 击穿对策：**分布式锁**（Redis `setIfAbsent` + Lua 释放）+ 逻辑过期
- 多级缓存：**Caffeine（本地）→ Redis（集中）→ MySQL**
- 缓存命中率监控、Key 命名规范

### 3.2 知识点详解

#### 3.2.1 三兄弟一图看懂

| 名称 | 触发条件 | 危害 | 对策 |
|------|---------|------|------|
| **缓存穿透** | 查询"根本不存在的数据"，缓存永远命不中 | 恶意攻击可打死 DB | 空值缓存 + 布隆过滤器 |
| **缓存雪崩** | 大量 key 同一时间失效 / Redis 宕机 | 数据库瞬时压力剧增 | 随机 TTL + 集群 + 熔断 |
| **缓存击穿** | 单个"热点 key"失效瞬间被高并发打穿 | 单点数据库压力剧增 | 互斥锁 + 逻辑过期 |

> **注意：** 三个词老被混用。记忆技巧——**穿透 = 无中生有；雪崩 = 大面积失效；击穿 = 单点大流量**。

#### 3.2.2 穿透对策 1：空值缓存

```java
public MemberDTO getMember(Long id) {
    String key = "member:" + id;
    String cached = redis.opsForValue().get(key);
    if (cached != null) {
        if ("NULL".equals(cached)) return null;   // 空对象标记
        return JSON.parseObject(cached, MemberDTO.class);
    }
    MemberDTO db = memberMapper.selectById(id);
    if (db == null) {
        // 空值也缓存，TTL 短一点，防止占用内存
        redis.opsForValue().set(key, "NULL", 60, TimeUnit.SECONDS);
        return null;
    }
    redis.opsForValue().set(key, JSON.toJSONString(db), 30, TimeUnit.MINUTES);
    return db;
}
```

**优点：** 简单直接，不影响正常业务。
**缺点：** 攻击者用**海量随机 ID** 打，还是把无数 `NULL` 塞进 Redis 浪费内存。

#### 3.2.3 穿透对策 2：布隆过滤器

**布隆过滤器（Bloom Filter）** 是一种**空间高效的概率数据结构**：
- `mightContain(x) = false` → **一定不存在**（无假阴性）
- `mightContain(x) = true` → **可能存在**（有假阳性，概率 = `fpp`）

三个参数：
```
BloomFilter.create(funnel, expectedInsertions, fpp)
                  漏斗类型   预期元素数量        假阳性率
```

```java
// 引入 Guava：com.google.guava:guava:32.1.3-jre

@Component
public class MemberBloomFilter {
    private BloomFilter<Long> filter;

    @Autowired
    private ElderMemberMapper memberMapper;

    @PostConstruct
    public void init() {
        filter = BloomFilter.create(
            Funnels.longFunnel(),
            1_000_000L,   // 预期元素数量
            0.01          // 假阳性率 1%
        );
        // 项目启动时把所有 member.id 装进去
        for (Long id : memberMapper.selectAllIds()) {
            filter.put(id);
        }
    }

    public boolean mightContain(Long id) {
        return filter.mightContain(id);
    }

    public void put(Long id) {
        filter.put(id);
    }
}
```

在查询前先问布隆：
```java
public MemberDTO getMember(Long id) {
    if (!memberBloomFilter.mightContain(id)) {
        return null;   // 一定不存在，直接返回，不查 Redis 也不查 DB
    }
    // ... 之后才走 Redis + DB
}
```

**空间开销：** 100 万元素、fpp=1% 只需 1.2 MB；fpp=0.1% 需要 1.8 MB。**fpp 越小内存越大**。

**缺点：** 不支持删除；插入新元素时要同步 `put`。

#### 3.2.4 雪崩对策：随机 TTL

```java
// ❌ 错误示范：所有 key 都是 30 分钟
redis.opsForValue().set(key, val, 30, TimeUnit.MINUTES);

// ✅ 正确示范：基础 30 分钟 + 0~5 分钟随机
long ttlSec = 30 * 60 + ThreadLocalRandom.current().nextInt(300);
redis.opsForValue().set(key, val, ttlSec, TimeUnit.SECONDS);
```

再加上 Redis 主从 / Cluster，即使一台宕机也不至于全部失效。**熔断降级**（Sentinel / Resilience4j）作为最后一道防线：DB 抖动时直接返回默认值或旧数据。

#### 3.2.5 击穿对策：分布式互斥锁

关键疑问：**为什么不能用 `synchronized`？**
答：`synchronized` 只锁**当前 JVM 内**的线程；分布式部署有 4 台机器，每台机器都各自解锁，DB 还是被打 4 次。

正确姿势：**Redis `setIfAbsent` 抢锁 + Lua 释放**。

```java
public RoomTypeDTO getRoomType(Long id) {
    String key = "room:type:" + id;
    String cached = redis.opsForValue().get(key);
    if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);

    // 缓存不存在，尝试拿分布式锁
    String lockKey = "lock:" + key;
    String reqId = UUID.randomUUID().toString();
    Boolean got = redis.opsForValue().setIfAbsent(lockKey, reqId, 10, TimeUnit.SECONDS);
    if (!Boolean.TRUE.equals(got)) {
        // 没拿到锁，睡一会儿再查缓存（自旋 + 双重检查）
        try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return getRoomType(id);
    }
    try {
        cached = redis.opsForValue().get(key);   // 双重检查
        if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);
        RoomTypeDTO db = roomTypeMapper.selectById(id);
        redis.opsForValue().set(key, JSON.toJSONString(db), 30, TimeUnit.MINUTES);
        return db;
    } finally {
        // Lua 脚本释放锁（防误删）
        String lua = "if redis.call('get', KEYS[1]) == ARGV[1] " +
                     "then return redis.call('del', KEYS[1]) else return 0 end";
        redis.execute(new DefaultRedisScript<>(lua, Long.class),
                      Collections.singletonList(lockKey), reqId);
    }
}
```

> **注意：** 释放锁**必须**用 Lua 保证"判断+删除"原子性，否则可能删掉别人加的锁。

#### 3.2.6 多级缓存：Caffeine + Redis

```
用户请求
   │
   ▼
Caffeine (JVM 内 ~100ns 级)  ────  命中直接返回
   │ 未命中
   ▼
Redis (集中式 1-2ms)  ────  命中回写 Caffeine
   │ 未命中
   ▼
MySQL
```

Caffeine 是 Google 出品的高性能本地缓存，性能是 Guava Cache 的 2-3 倍：

```java
// pom.xml：com.github.ben-manes.caffeine:caffeine:3.1.8

Cache<String, MemberDTO> local = Caffeine.newBuilder()
    .maximumSize(10_000)
    .expireAfterWrite(2, TimeUnit.MINUTES)
    .recordStats()   // 打开命中率统计
    .build();
```

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 缓存穿透 | 查不存在的数据，用空值 + 布隆挡 |
| 缓存雪崩 | 大量 key 同时失效，随机 TTL 抖 |
| 缓存击穿 | 单点热 key 失效，分布式锁挡 |
| 布隆过滤器 | 概率结构，有假阳性无假阴性 |
| Caffeine | JVM 本地缓存，多级缓存第一层 |

### 3.4 示例代码/例题解析

**示例 1：给 RoomTypeService 加多级缓存 + 击穿保护**
```java
@Service
@RequiredArgsConstructor
public class RoomTypeServiceImpl implements RoomTypeService {
    private final RoomTypeMapper roomTypeMapper;
    private final StringRedisTemplate redis;

    private final Cache<String, RoomTypeDTO> localCache = Caffeine.newBuilder()
            .maximumSize(1_000)
            .expireAfterWrite(2, TimeUnit.MINUTES)
            .recordStats()
            .build();

    private static final String LOCK_LUA =
        "if redis.call('get', KEYS[1]) == ARGV[1] " +
        "then return redis.call('del', KEYS[1]) else return 0 end";

    @Override
    public RoomTypeDTO getById(Long id) {
        String key = "room:type:" + id;
        // 1) Caffeine
        RoomTypeDTO local = localCache.getIfPresent(key);
        if (local != null) return local;

        // 2) Redis
        String cached = redis.opsForValue().get(key);
        if (cached != null) {
            if ("NULL".equals(cached)) return null;
            RoomTypeDTO r = JSON.parseObject(cached, RoomTypeDTO.class);
            localCache.put(key, r);
            return r;
        }

        // 3) 加锁访问 DB
        String lockKey = "lock:" + key;
        String reqId = UUID.randomUUID().toString();
        Boolean got = redis.opsForValue().setIfAbsent(lockKey, reqId, 10, TimeUnit.SECONDS);
        if (!Boolean.TRUE.equals(got)) {
            try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            return getById(id);
        }
        try {
            cached = redis.opsForValue().get(key);
            if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);
            RoomTypeDTO db = roomTypeMapper.selectDtoById(id);
            long ttl = 30 * 60 + ThreadLocalRandom.current().nextInt(300);
            if (db == null) {
                redis.opsForValue().set(key, "NULL", 60, TimeUnit.SECONDS);
                return null;
            }
            redis.opsForValue().set(key, JSON.toJSONString(db), ttl, TimeUnit.SECONDS);
            localCache.put(key, db);
            return db;
        } finally {
            redis.execute(new DefaultRedisScript<>(LOCK_LUA, Long.class),
                          Collections.singletonList(lockKey), reqId);
        }
    }
}
```
**原理解释：** 20 个并发同时 `GET /api/room-types/1`，日志里 SQL 只查 1 次，其余全部 Caffeine + Redis 命中——**击穿保护成功**。

**示例 2：查看缓存命中率**
```java
@GetMapping("/actuator/cache-stats")
public Map<String, Object> stats() {
    CacheStats s = localCache.stats();
    return Map.of(
        "hitCount", s.hitCount(),
        "missCount", s.missCount(),
        "hitRate", s.hitRate(),
        "evictionCount", s.evictionCount()
    );
}
```

### 3.5 课后练习

1. 【基础】写一段代码：设置 `member:*` 的 TTL 为 `1800 + Random(0, 300)` 秒。
2. 【基础】给 `MemberService.getById` 加空值缓存（TTL 60 秒）。
3. 【综合】给 `RoomTypeService.getById` 加一个"逻辑过期"版本（value 里带 `expireTime` 字段，永不主动过期，异步刷新）。
4. 【挑战】用 Redisson `RBloomFilter` 替代 Guava BloomFilter，让多台机器共用同一份布隆。

### 3.6 课后思考

- 缓存穿透与缓存击穿的关键区别是什么？
- 为什么击穿场景不能用 `synchronized` 而必须用分布式锁？
- `BloomFilter.mightContain` 返回 true 一定说明数据存在吗？
- 布隆过滤器不支持删除，那我们删掉一个会员后，布隆里那个 bit 位怎么办？（提示：Counting Bloom Filter / Cuckoo Filter）

### 3.7 课后作业

1. 把项目里所有"缓存 key 相同 TTL"的代码全部改成加随机偏移。
2. 阅读一篇布隆过滤器的博客并写一段"为什么 fpp 越小内存越大"的推导。
3. 给 `MemberServiceImpl` 加上 BloomFilter + Caffeine + Redis 三层保护，并用 JMeter 压 1000 并发观察 DB QPS。

---

## 第 4 讲：JVM 调优与 GC 观察（Arthas）

### 4.1 本讲要点
- JVM 内存区域：**堆 / 方法区（元空间） / 栈 / 本地方法栈 / 程序计数器**
- 堆分代：**Eden + S0 + S1 + 老年代**
- JVM 启动参数：`-Xms` / `-Xmx` / `-Xmn` / `-XX:MetaspaceSize` / `-XX:+UseG1GC`
- G1 与 ParNew+CMS 对比（CMS 已在 JDK 14 移除）
- GC 日志：`-Xlog:gc*:file=gc.log`
- **Arthas 五大命令：** `dashboard` / `thread -n 3` / `jvm` / `watch` / `trace`
- Arthas 三大神操作：`heapdump` / `jad` / `redefine`

### 4.2 知识点详解

#### 4.2.1 JVM 内存区域

```
      ┌──── JVM 进程 ──────────────────────┐
      │                                    │
      │  堆 Heap (线程共享，最大)           │
      │  ┌───────┬────┬────┬─────────┐    │
      │  │ Eden  │ S0 │ S1 │ 老年代   │    │
      │  └───────┴────┴────┴─────────┘    │
      │  方法区 / 元空间 (类元数据)          │
      │  程序计数器 / 虚拟机栈 / 本地方法栈  │
      │                                    │
      └────────────────────────────────────┘
```

| 区域 | 作用 | 线程私有？ | 溢出错误 |
|------|------|-----------|---------|
| 堆 | 存放对象 | 共享 | `OutOfMemoryError: Java heap space` |
| 方法区/元空间 | 类元数据 | 共享 | `OutOfMemoryError: Metaspace` |
| 虚拟机栈 | 方法调用栈帧 | 私有 | `StackOverflowError` |
| 本地方法栈 | native 方法 | 私有 | 同上 |
| 程序计数器 | 字节码行号 | 私有 | 唯一不会 OOM |

#### 4.2.2 核心启动参数

| 参数 | 含义 | 示例（4G 机器） |
|------|------|---------------|
| `-Xms` | 堆初始大小 | `-Xms2g` |
| `-Xmx` | 堆最大大小 | `-Xmx2g`（**必须与 Xms 相等**） |
| `-Xmn` | 新生代大小 | `-Xmn768m` |
| `-Xss` | 每个线程栈大小 | `-Xss512k`（默认 1M，线程多可调小） |
| `-XX:MetaspaceSize` | 元空间初始 | `256m` |
| `-XX:MaxMetaspaceSize` | 元空间上限 | `512m` |
| `-XX:+UseG1GC` | 用 G1 收集器 | JDK 9+ 默认 |
| `-XX:MaxGCPauseMillis` | 目标停顿 | `200` |
| `-Xlog:gc*` | GC 日志 | 排障必备 |

> **为什么 Xms = Xmx？** 若不等，堆会在运行中动态扩展/收缩，触发 Full GC。生产上**必须相等**。

推荐（JDK 17）：
```bash
java -Xms1g -Xmx1g -Xmn384m \
     -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m \
     -XX:+UseG1GC -XX:MaxGCPauseMillis=200 \
     -Xlog:gc*:file=/var/log/smart-elder/gc.log:time,tags:filecount=10,filesize=10M \
     -jar smart-elder.jar
```

#### 4.2.3 GC 收集器：ParNew+CMS vs G1

| 维度 | ParNew+CMS | G1 |
|------|-----------|----|
| 分代 | 显式（新/老） | Region 化，逻辑分代 |
| 停顿目标 | 无 | 可指定 `MaxGCPauseMillis` |
| 堆大小上限 | 4-8G 较合适 | 数十 GB 也行 |
| 状态 | JDK 9 弃用、14 移除 | JDK 9 默认（server）、17 默认 |
| 结论 | 只在维护老项目时接触 | **新项目直接用 G1** |

#### 4.2.4 GC 日志速读

打开日志会看到：
```
[2026-07-09T10:23:15.123+0800][gc,start] GC(12) Pause Young (Normal) (G1 Evacuation Pause)
[2026-07-09T10:23:15.145+0800][gc     ] GC(12) Pause Young (Normal) (G1 Evacuation Pause) 128M->32M(512M) 22.153ms
```

关键字段：
- `Pause Young` = Young GC；`Pause Full` = Full GC（**警报**）
- `128M->32M(512M)` = GC 前 128M → GC 后 32M / 堆总 512M
- `22.153ms` = 本次停顿

**判断"是否 GC 频繁"：** 1 分钟内 Young GC > 10 次 或 出现 Full GC → 需要调优。

#### 4.2.5 Arthas：线上救命神器

Arthas 是阿里开源的 Java 诊断工具，**无需重启进程即可 attach**：

```bash
# 下载
curl -O https://arthas.aliyun.com/arthas-boot.jar

# 启动（列出 JVM 进程供选择）
java -jar arthas-boot.jar
```

启动后会出现类似菜单：
```
[INFO] arthas-boot version: 3.7.2
[INFO] Found existing java process, please choose one and hit RETURN.
* [1]: 12345 smart-elder.jar
  [2]: 67890 IntelliJ IDEA
```
输入 `1` 回车即 attach 到进程。

#### 4.2.6 救命命令四件套

**（1）`dashboard` —— 实时仪表盘**
```
Memory                          used   total    max     usage    GC
heap                            320M   512M    1024M   31.25%   gc.g1_young_generation.count 12
g1_eden_space                   256M   288M    -1      88.88%   gc.g1_young_generation.time  240 ms
g1_old_generation                64M   224M    1024M   6.25%    gc.g1_old_generation.count   0
```
一屏看清：堆分布 / GC 次数 / GC 耗时 / CPU / 线程数。

**（2）`thread` —— 线程分析**
```bash
thread                     # 所有线程
thread -n 3                # CPU TOP3 线程
thread --state BLOCKED     # 查看阻塞线程
thread -b                  # 查找死锁
```

**（3）`jvm` —— JVM 详情**
打印所有 JVM 启动参数、JIT 信息、当前 GC 状态。

**（4）`watch` / `trace` —— 方法级观察**
```bash
# 观察方法入参、返回值、耗时
watch com.itcast.smart_elder.controller.MemberController page '{params, returnObj}' -x 2

# 追踪一个方法内部每个子调用耗时
trace com.itcast.smart_elder.service.impl.MemberServiceImpl page
```

#### 4.2.7 Arthas 三大神操作

- **`heapdump /tmp/dump.hprof`** —— 一键堆转储（配合 MAT 分析内存泄漏）
- **`jad com.itcast.smart_elder.controller.MemberController`** —— 反编译**线上运行中的类**（确认是不是"新代码没生效"）
- **`redefine /tmp/HelloController.class`** —— 热加载修改后的类（谨慎，不重启改代码）

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 堆分代 | Eden / S0 / S1 / 老年代 |
| G1 | 现代默认收集器，可控停顿 |
| Arthas | JVM 活体诊断工具 |
| dashboard | 一屏看清资源状态 |
| watch/trace | 无侵入观察方法 |

### 4.4 示例代码/例题解析

**示例 1：启动脚本（含 GC 日志）**
```bash
#!/bin/bash
# deploy/start.sh
JAR=smart-elder.jar
LOG_DIR=/var/log/smart-elder
mkdir -p $LOG_DIR

nohup java \
  -Xms1g -Xmx1g -Xmn384m \
  -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m \
  -XX:+UseG1GC -XX:MaxGCPauseMillis=200 \
  -Xlog:gc*:file=$LOG_DIR/gc.log:time,tags:filecount=10,filesize=10M \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=$LOG_DIR/heapdump.hprof \
  -jar $JAR --spring.profiles.active=prod > $LOG_DIR/stdout.log 2>&1 &

echo "PID=$!"
```

**示例 2：Arthas watch 常见表达式**
```bash
# 只在耗时超过 100ms 时打印
watch com.itcast.smart_elder.service.impl.MemberServiceImpl page \
  '{params, returnObj, #cost}' '#cost > 100' -x 2

# 只在抛异常时打印
watch com.itcast.smart_elder.controller.MemberController save \
  '{params, throwExp}' -e

# 打印执行 5 次后自动退出
watch com.itcast.smart_elder.controller.MemberController page \
  '{params, returnObj}' -n 5
```

**示例 3：现场排查一次"CPU 100%"**
```
1. jps                                       # 找到 Java 进程 PID
2. top -Hp <PID>                             # 找到消耗 CPU 最高的线程 ID
3. printf "%x\n" <线程ID>                    # 十进制转 16 进制
4. java -jar arthas-boot.jar                 # attach
5. thread -n 3                               # CPU TOP3 线程
   → 看到 http-nio-8080-exec-4 CPU=98%
6. thread <线程ID>                           # 打出栈
   → 定位到 XXXServiceImpl.badMethod
7. jad XXXServiceImpl                        # 反编译，确认代码
8. 修改代码 → 发版 → dashboard 验证
```

### 4.5 课后练习

1. 【基础】写出一个 JDK 17 的推荐启动命令，堆 2G、G1、GC 日志滚动 10 个 20M。
2. 【基础】用一句 `watch` 只打印 `MemberService.page` 的耗时（提示：`#cost`）。
3. 【综合】把项目 JVM 参数写死到启动脚本 `start.sh` 里，交到 Git 仓库 `deploy/` 目录。
4. 【挑战】故意写一个死循环接口，用 Arthas `thread -n 3` 定位并修复。

### 4.6 课后思考

- `-Xmx` 与 `-Xms` 一般设成相等还是不等？为什么？
- Arthas 的 `watch` 与 `trace` 有什么区别？
- `jad` 命令有什么用途？
- 如果 Arthas 的 `thread -n 3` 显示 CPU TOP3 全是 `GC Thread`，说明什么问题？

### 4.7 课后作业

1. 下载 arthas-boot.jar，attach 到自己的 smart-elder 进程，依次跑 `dashboard`、`thread -n 3`、`jvm`、`watch`、`trace`，把截图放到日报里。
2. 阅读 Arthas 官方 5 分钟入门，跑通 `getstatic` / `stack` 两个命令。
3. 用 `heapdump` 导出一次 hprof 文件，用 MAT（或 VisualVM）打开，找出 TOP5 内存占用类。

---

## 第 5 讲：接口性能压测（JMeter）

### 5.1 本讲要点
- 压测三大指标：**TPS（吞吐量）/ RT（响应时间 p95/p99）/ Error%（错误率）**
- Little 定律：**TPS × RT ≈ 并发数**
- 性能拐点：TPS 不再上升 + RT 直线上升的临界点
- JMeter 组件：**Thread Group + HTTP Request + View Results Tree + Aggregate Report**
- 命令行模式：`jmeter -n -t plan.jmx -l result.jtl -e -o report/`
- 阶梯压测找拐点：50 / 100 / 200 / 300 / 500

### 5.2 知识点详解

#### 5.2.1 压测的三大核心指标

| 指标 | 全称 | 定义 | 好坏参考 |
|------|------|------|---------|
| TPS | Transactions Per Second | 每秒事务数 | 一般 web 接口 100-1000 |
| RT | Response Time | 单次请求耗时 | p99 一般要求 < 500ms |
| Error% | 错误率 | 失败请求占比 | 生产要求 < 0.1% |

**关系：** `TPS × RT ≈ 并发数`（Little 定律）。当并发上升到某点，TPS 不再涨，RT 反而暴涨——即"**性能拐点**"，是系统真实的容量上限。

> **注意：** 面试和线上运维**只看 p99 和 p95**，不看 Average——因为长尾请求才是用户抱怨"太卡"的元凶。

#### 5.2.2 JMeter 安装

从 https://jmeter.apache.org/download_jmeter.cgi 下载 zip，解压即可。启动：
- Windows：`bin\jmeter.bat`（GUI）
- Linux/Mac：`bin/jmeter.sh`
- 命令行：`bin/jmeter -n -t plan.jmx -l result.jtl -e -o report/`

> **教师强调：** 图形界面**只用来编写与调试脚本**，正式压测一律走命令行 —— GUI 本身很吃内存，会污染压测结果。

#### 5.2.3 JMeter 组件表

| 组件类别 | 常用元件 | 作用 |
|---------|--------|------|
| 线程 | Thread Group | 控制并发用户数与循环 |
| 取样器 | HTTP Request | 发起 HTTP 请求 |
| 配置元件 | HTTP Header Manager / HTTP Request Defaults | 全局请求头、默认地址 |
| 前置处理器 | User Parameters / CSV Data Set Config | 参数化 |
| 定时器 | Constant Timer / Uniform Random Timer | 加思考时间 |
| 断言 | Response Assertion / JSON Assertion | 断言返回值 |
| 监听器 | View Results Tree / Aggregate Report | 结果展示 |

#### 5.2.4 Thread Group 三大参数

```
线程数 (Number of Threads)  = 并发用户数 = 100
Ramp-up (秒)                = 100 个线程在多少秒内全部启动 = 5 秒
循环次数 (Loop Count)         = 每个线程跑几遍 = 10
```
总请求数 = 100 × 10 = 1000。Ramp-up 用于避免瞬时打满 —— 5 秒内每秒起 20 个用户。

#### 5.2.5 Aggregate Report 字段详解

| 字段 | 含义 |
|------|------|
| Label | 请求名（对应 HTTP Request 元件） |
| # Samples | 总请求数 |
| Average | 平均响应时间 (ms) |
| Median | 50% 分位 |
| 90% Line | 90% 分位（90% 请求 ≤ 该值） |
| 95% Line | 95% 分位 |
| 99% Line | 99% 分位（面试常问） |
| Min / Max | 最短/最长 |
| Error% | 错误率 |
| Throughput | 每秒请求数（即 TPS） |
| Received / Sent KB/sec | 带宽 |

#### 5.2.6 阶梯加压：找性能拐点

对同一接口跑 5 组不同并发（脚本相同、机器相同、数据一致）：

| 并发 | TPS | p99 | Error% | 备注 |
|------|-----|-----|--------|------|
| 50 | 190 | 65ms | 0% | 轻松扛住 |
| 100 | 380 | 120ms | 0% | 正常 |
| 200 | 620 | 380ms | 0% | 接近拐点 |
| 300 | 680 | 950ms | 0.3% | **拐点已过** |
| 500 | 690 | 2200ms | 2.5% | 崩溃边缘 |

从 200 → 300 并发 TPS 只涨了 60，p99 却从 380ms 飙到 950ms —— **性能拐点在 200 附近**。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| TPS | 每秒事务数，越大越好 |
| p99 | 99% 请求响应时间，越小越好 |
| Little 定律 | TPS × RT ≈ 并发数 |
| Ramp-up | 避免瞬间打满，缓慢加压 |
| 拐点 | TPS 不涨、RT 暴涨的临界点 |

### 5.4 示例代码/例题解析

**示例 1：手动搭一个压测计划**

菜单树：
```
Test Plan
├── Thread Group (100/5/10)
│   ├── HTTP Request Defaults      // Server: localhost, Port: 8080
│   ├── HTTP Header Manager        // Content-Type: application/json
│   │                              // Authorization: Bearer ***
│   ├── HTTP Request               // /api/members/page?page=1&size=20
│   ├── Uniform Random Timer       // 100-300ms
│   ├── Response Assertion         // 响应含 "code":0
│   ├── View Results Tree
│   └── Aggregate Report
```

保存为 `member-page.jmx`，先 GUI 跑一次，观察 Aggregate Report：
```
Label        Samples  Average  Median  95%Line  99%Line  Error%  Throughput
member/page  1000     52ms     45ms    120ms    180ms    0.00%   190.5/sec
```
**TPS ≈ 190、p99 = 180ms、错误率 0%**，这是**基线数据**。

**示例 2：命令行跑压测并生成 HTML 报告**
```bash
# -n 无界面模式  -t 脚本  -l 结果  -e 生成HTML  -o 输出目录
bin/jmeter -n -t member-page.jmx -l result.jtl -e -o report/

# 用浏览器打开报告
xdg-open report/index.html   # Linux
start report/index.html      # Windows
open report/index.html       # macOS
```

HTML 报告包含：
- **APDEX 分数**（用户满意度指标，0-1，越接近 1 越好）
- **响应时间随时间变化曲线**
- **每秒事务数曲线**
- **响应时间百分位分布**
- **错误分类**

**示例 3：Uniform Random Timer 模拟真实用户**
```
Constant Delay Offset: 100
Random Delay Maximum:  200
```
每个请求间隔 `100 + [0,200)` = 100-300ms，模拟真实用户"点了看两眼"的思考时间。

**示例 4：CSV 参数化 - 每个线程用不同的 memberId**

`data/member-ids.csv`：
```
1001
1002
1003
...
```
JMeter 里加 **CSV Data Set Config**：
```
Filename:            /path/to/data/member-ids.csv
Variable Names:      memberId
Recycle on EOF:      True
```
在 HTTP Request Path 里：`/api/members/${memberId}`，每个虚拟用户拿到不同 id。

**示例 5：阶梯压测 shell 脚本**
```bash
#!/bin/bash
# perf/step.sh
for t in 50 100 200 300 500; do
  echo "======== Threads=$t ========"
  bin/jmeter -n -t member-page.jmx \
    -Jthreads=$t -Jrampup=5 -Jloops=20 \
    -l result-$t.jtl -e -o report-$t/
done
```

在 Thread Group 里用 `${__P(threads,100)}` 引用命令行参数。

### 5.5 课后练习

1. 【基础】写一个 `Uniform Random Timer` 让每个请求间隔 100-300ms（模拟真实用户思考时间）。
2. 【基础】增加 `Response Assertion`，如果响应体不包含 `"code":0` 则视为失败。
3. 【综合】对 Day06 预约下单接口 `POST /api/reservations` 做一次 100 并发压测（注意登录 token）。
4. 【挑战】用 JMeter 分布式模式（1 master + 2 slave）压 1000 并发。

### 5.6 课后思考

- 平均响应时间和 p99 响应时间，哪个更能反映用户真实感受？
- 100 并发、Ramp-up = 5 秒，第 3 秒时并发用户数大约是多少？
- 为什么正式压测要用命令行而不是 GUI？
- 如果 Error% > 1% 之后再继续加压，压测数据还有意义吗？

### 5.7 课后作业

1. 对 Day03 会员分页、Day06 预约下单两个核心接口，分别用阶梯压测（50/100/200/300/500）做出 TPS/p99 曲线图。
2. 阅读文档《JMeter 分布式压测》，简述为什么单机压测存在瓶颈。
3. 把压测脚本 `.jmx` 与阶梯压测 `step.sh` 提交到项目仓库 `deploy/perf/`。

---

## 第 6 讲：优化前后对比与性能报告输出

### 6.1 本讲要点
- **性能报告五段式：背景 / 问题 / 方案 / 数据 / 结论**
- 指标口径统一：TPS、p95、p99、CPU、GC 次数、慢 SQL 计数、缓存命中率
- Markdown 对比表规范：**优化前 | 优化后 | 变化幅度**
- 数据的**可比性**——同机器、同数据量、同压测脚本，只改动待验证变量
- 面试可用的表达："p99 从 950ms → 180ms，下降 81%"
- 遗留问题 & Roadmap 也要写（体现工程素养）

### 6.2 知识点详解

#### 6.2.1 为什么要写性能报告

前 5 讲我们做了慢 SQL 诊断、索引改造、缓存加固、JVM 调优、JMeter 压测。这些工作**你自己知道很牛**，但**别人看不到**。

一份产品级的性能优化报告能带来 3 个价值：
1. **对内**：产品/测试/运维知道你做了什么，能复现测试。
2. **对上**：Leader 能拿去做季度 OKR 交付物。
3. **对外（简历）**：面试时最硬的证据——"这行代码是我优化的、数据是我测的、报告是我写的"。

#### 6.2.2 五段式结构

```
1. 背景 (Context)     系统是什么？为什么要优化？          3-5 行
2. 问题 (Problem)     发现的核心瓶颈                     TOP3 表格
3. 方案 (Solution)    针对每个问题的具体改动              代码 + 表格
4. 数据 (Data)        优化前后对比                       关键表 + 图
5. 结论 (Conclusion)  量化收益 + 遗留 & Roadmap          一段话
```

#### 6.2.3 指标口径统一

| 指标 | 单位 | 优化目标 | 采集方式 |
|------|------|---------|---------|
| TPS | req/s | 越大越好 | JMeter Aggregate Report |
| p99 RT | ms | 越小越好 | JMeter Aggregate Report |
| p95 RT | ms | 越小越好 | JMeter Aggregate Report |
| CPU 使用率 | % | 60-70% 为宜 | `top` / Arthas dashboard |
| GC 频次 | 次/分钟 | 越少越好 | GC 日志 |
| GC 停顿 | ms | 越短越好 | GC 日志 |
| 慢 SQL 计数 | 条/天 | 归零 | mysqldumpslow |
| 缓存命中率 | % | > 95% | Actuator / Caffeine.stats() |
| DB QPS | req/s | 越少越好 | MySQL `SHOW GLOBAL STATUS` |

#### 6.2.4 Markdown 对比表模板

```markdown
| 接口 | 指标 | 优化前 | 优化后 | 变化 |
|------|------|--------|--------|------|
| 会员分页 | TPS | 190 | 850 | +347% |
| 会员分页 | p99 | 950ms | 130ms | -86% |
| 房型详情 | 缓存命中率 | 0% | 98.5% | — |
```

> **技巧：** 变化列用 **`+xxx%`**（TPS 类越大越好）或 **`-xxx%`**（RT 类越小越好），一眼看出方向。

#### 6.2.5 如何避免"数据美化"

真实项目里有时优化后 TPS 反而下降：例如加了缓存击穿保护，缓存 miss 时因为要抢锁反而慢一点点，但**避免了雪崩**。这种情况**如实写**，反而体现工程理性。

数据可比性四原则：
1. **同机器**：CPU / 内存 / 磁盘完全一致
2. **同数据量**：优化前后表里都是 100 万行
3. **同压测脚本**：连并发数、Ramp-up 也一致
4. **同网络**：本机 or 内网稳定，别 Wi-Fi 抖动

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 五段式 | 背景/问题/方案/数据/结论 |
| 变量控制 | 只变待验证的一个因子 |
| 遗留 & Roadmap | 体现工程素养，不隐瞒问题 |
| 量化优先 | "从 X 到 Y，提升 Z%"

### 6.4 示例代码/例题解析

**示例：完整报告模板（拷贝即用）**

保存为 `docs/performance-report-v1.md`：

````markdown
# AI 智能养老社区系统 v1.0 性能优化报告

## 1. 背景

AI 智能养老社区系统于 2026-06 上线，一期覆盖会员管理、客房预约、AI 智能问答等模块。上线 3 周后运维反馈：**会员分页接口日均峰值 QPS 200，p99 达 1s；房型详情接口 Redis 命中率 0%（未接入缓存）**。本报告记录 Day10 优化前后关键指标对比。

## 2. 发现的核心问题（TOP3）

| # | 问题 | 表现 | 根因 |
|---|------|------|------|
| 1 | 会员分页慢 | p99 = 950ms | `WHERE member_level=? AND phone LIKE '138%' ORDER BY create_time` 缺联合索引，`Using filesort` |
| 2 | 房型详情缓存缺失 | 命中率 0% | `RoomTypeService.getById` 直查 DB |
| 3 | 缓存击穿风险 | 单点热点 key 失效瞬间打库 | 无互斥锁 |

## 3. 优化方案

### 3.1 慢 SQL 索引优化
```sql
CREATE INDEX idx_level_ctime_phone ON elder_member(member_level, create_time, phone);
CREATE INDEX idx_member_status_date ON room_reservation(member_id, status, check_in_date);
CREATE INDEX idx_date_status ON room_reservation(check_in_date, status);
```

### 3.2 缓存三兄弟改造
- 穿透：`MemberService` 加入 Guava BloomFilter，`@PostConstruct` 装载全部 id
- 雪崩：所有 `member:*`、`room:type:*` key TTL = `1800 + Random(0,300)` 秒
- 击穿：`RoomTypeServiceImpl` 加分布式锁 + 双重检查 + Lua 释放锁
- 多级：Caffeine + Redis + MySQL

### 3.3 JVM 参数
```
-Xms1g -Xmx1g -Xmn384m -XX:+UseG1GC -XX:MaxGCPauseMillis=200
```

## 4. 数据对比

### 4.1 会员分页接口（100 并发 × 10 轮）

| 指标 | 优化前 | 优化后 | 变化 |
|------|--------|--------|------|
| TPS | 190 req/s | 850 req/s | **+347%** |
| p95 | 620ms | 95ms | **-85%** |
| p99 | 950ms | 130ms | **-86%** |
| CPU 峰值 | 92% | 55% | -37pt |
| MySQL 慢查询 | 32 条 | 0 条 | -100% |

### 4.2 房型详情接口（500 并发 × 5 轮）

| 指标 | 优化前 | 优化后 | 变化 |
|------|--------|--------|------|
| TPS | 320 | 4200 | **+1213%** |
| p99 | 780ms | 12ms | **-98%** |
| Redis 命中率 | 0% | 98.5% | +98.5pt |
| DB 每秒查询 | 320 | 4.6 | -98.5% |

### 4.3 GC 观察

| 指标 | 优化前 | 优化后 |
|------|--------|--------|
| Young GC 次数/分钟 | 24 | 8 |
| Full GC 次数/小时 | 3 | 0 |
| GC 平均停顿 | 180ms | 45ms |

## 5. 结论

- **TPS 综合提升 4-12 倍**；**p99 全部降至 200ms 以内**；**慢 SQL 归零**；**GC 频次减半**。
- 关键手段：**联合索引 3 条 + Caffeine 多级缓存 + 分布式锁防击穿 + G1 GC**。
- 遗留 & 下一步：
  1. 预约下单接口尚未做压测（Day11 待补）
  2. Redis Cluster 尚未上（Day11 部署时切）
  3. AI 接口的流式响应压测方式待研究

---

**报告作者：** 你的名字
**报告日期：** 2026-07-09
**测试机器：** 4C8G / MySQL 8.0.34 / Redis 7.2 / JDK 17
**测试脚本：** `perf/*.jmx`（已提交到 Git 仓库 `deploy/perf/`）
````

**导出 PDF**：
```bash
# 需要先装 pandoc
pandoc docs/performance-report-v1.md \
       -o docs/pdf/performance-report-v1.pdf \
       --pdf-engine=xelatex \
       -V mainfont="Noto Sans CJK SC"
```

### 6.5 课后练习

1. 【基础】写出五段式报告的每一段名称。
2. 【基础】选一个你还没测过的接口，用同样格式写一段简短对比。
3. 【综合】把报告模板 copy 到你的项目 `docs/`，用**自己昨天的真实压测数据**替换所有数字。
4. 【挑战】用 `mermaid` 语法给报告加一张"缓存命中率随时间变化"的曲线图。

### 6.6 课后思考

- 性能报告最能打动面试官的是哪一部分？
- "变量控制"要保证哪些不变？
- 为什么要在报告里写"遗留问题"？
- 如果优化后某接口 TPS 反而下降，报告怎么写才既诚实又不给自己挖坑？

### 6.7 课后作业

1. 完善你的性能报告，做到"背景、问题、方案、数据、结论"五段齐全，提交到 Git。
2. 更新简历的项目经历，把量化数据（TPS 850、p99 130ms、GC 减半）加进去。
3. 挑一位同学互评报告，写 5 条改进建议。

---

## 附录 A：Day10 优化前后指标一览

### A.1 综合对比表

| 模块 | 指标 | 优化前 | 优化后 | 变化 | 用到的手段 |
|------|------|--------|--------|------|-----------|
| 会员分页 | TPS | 190 | 850 | +347% | 联合索引 |
| 会员分页 | p99 (ms) | 950 | 130 | -86% | 联合索引 + 覆盖索引 |
| 房型详情 | TPS | 320 | 4200 | +1213% | Caffeine + Redis + 分布式锁 |
| 房型详情 | p99 (ms) | 780 | 12 | -98% | 多级缓存 |
| 房型详情 | Redis 命中率 | 0% | 98.5% | +98.5pt | 缓存改造 |
| 预约"我的" | TPS | 240 | 720 | +200% | idx_member_status_date |
| 预约"我的" | p99 (ms) | 580 | 95 | -84% | 索引 + ICP |
| MySQL | 慢 SQL 条/天 | 32 | 0 | -100% | 索引 + SQL 改写 |
| MySQL | 峰值 DB QPS | 4300 | 890 | -79% | 缓存卸载 |
| JVM | Young GC 次/分 | 24 | 8 | -67% | G1 + 合理堆大小 |
| JVM | Full GC 次/时 | 3 | 0 | -100% | G1 |
| JVM | GC 停顿 (ms) | 180 | 45 | -75% | MaxGCPauseMillis=200 |

### A.2 每讲用到的核心工具

| 讲次 | 主题 | 核心工具 |
|------|------|---------|
| 1 | 慢 SQL 定位 | MySQL 慢日志 + mysqldumpslow / pt-query-digest + EXPLAIN |
| 2 | 索引优化 | EXPLAIN + CREATE INDEX + 延迟关联 SQL |
| 3 | 缓存优化 | Guava BloomFilter + Caffeine + StringRedisTemplate + Lua |
| 4 | JVM 调优 | java -Xms/-Xmx/-XX + Arthas |
| 5 | 压测 | Apache JMeter（GUI + CLI） |
| 6 | 报告输出 | Markdown + pandoc + Git |

---

## 附录 B：性能优化 10 大常见陷阱

### B.1 加了索引反而变慢

**症状：** 建了索引后查询更慢。
**原因：** 数据量小、数据倾斜、优化器估算失误。
**对策：** 用 `EXPLAIN` 验证是否走了索引；`FORCE INDEX` 强制指定。

### B.2 联合索引字段顺序错误

**症状：** `EXPLAIN` 显示 `type=ALL` 或 `rows` 巨大。
**原因：** 违背"等值 → 排序 → 范围"设计原则。
**对策：** 按 WHERE 等值列 → ORDER BY 列 → 范围列的顺序排列。

### B.3 SELECT * 无法用覆盖索引

**症状：** `Extra` 从没出现 `Using index`。
**对策：** 只 SELECT 需要的列；生产严禁 `SELECT *`。

### B.4 Redis Value 过大

**症状：** 单 key 十几 MB，网络传输拖慢；大 key 阻塞主线程。
**对策：** 拆分（member:1:base / member:1:contact）；用 Hash 结构；启用 `client-output-buffer-limit`。

### B.5 缓存与 DB 双写不一致

**症状：** 更新 DB 后 Redis 里还是旧值。
**对策：** 先更 DB 再 `del` 缓存（Cache Aside Pattern）；重要业务用 canal 订阅 binlog。

### B.6 Xms ≠ Xmx

**症状：** 运行几小时后 Full GC 频繁。
**原因：** 堆自动扩容/缩容触发 Full GC。
**对策：** 二者设成相等。

### B.7 打开 GC 日志前忘了 rotate

**症状：** `gc.log` 涨到几个 G。
**对策：** `-Xlog:gc*:file=gc.log:time,tags:filecount=10,filesize=10M`。

### B.8 JMeter 用 GUI 跑压测

**症状：** 结果里 TPS 远低于实际，机器爆掉。
**对策：** GUI 只调脚本，正式压测走命令行 `jmeter -n -t ... -l ... -e -o ...`。

### B.9 压测数据没有基线

**症状：** 优化了半天，不知道对比啥。
**对策：** **优化前先跑一遍完整压测保存为 v0 基线**，改动后跑 v1、v2 逐次对比。

### B.10 报告只写好数据不写坏数据

**症状：** 面试官追问遗留问题时答不上。
**对策：** 报告里必写一段 Roadmap，把已知未解的问题都摆出来。

---

## 附录 C：Day10 交付清单

**新增文件：**
- `docs/performance-report-v1.md` —— 性能优化报告
- `deploy/perf/member-page.jmx` —— 会员分页压测脚本
- `deploy/perf/reservation-create.jmx` —— 预约下单压测脚本
- `deploy/perf/step.sh` —— 阶梯压测 shell
- `deploy/start.sh` —— 附带 JVM 参数的启动脚本
- `sql/day10-index.sql` —— 本日新增索引 DDL
- `src/main/java/.../bloomfilter/MemberBloomFilter.java`
- `src/main/java/.../service/impl/RoomTypeServiceImpl.java`（多级缓存改造）
- `src/main/resources/application.yml`（Caffeine 与 Redis 配置调优）

**新增依赖（pom.xml）：**
- `com.google.guava:guava:32.1.3-jre`
- `com.github.ben-manes.caffeine:caffeine:3.1.8`

**Git 建议提交：**
1. `perf(sql): add composite index for member/reservation`
2. `perf(cache): multi-level cache with distributed lock for hotspot`
3. `perf(jvm): use G1 with 1G heap and gc log rotation`
4. `test(perf): jmeter scripts and step.sh`
5. `docs(perf): performance report v1`

---

## Day11 预告

**Day11 主题：项目部署上线（Nginx + Docker + CI/CD）**

**你会学到：**
- Docker 与 Docker Compose 一键起 MySQL / Redis / 后端 / 前端
- Nginx 反向代理与静态资源部署
- 前端 Vue 项目 build + Nginx 挂载
- 后端 Jar 打包与 Docker 镜像构建
- 生产环境的日志切割与容器编排
- Github Actions CI/CD：push → build → 部署到测试机
- 域名与 HTTPS（Let's Encrypt）
- 生产上线 Checklist（安全组、日志、备份、监控）

**为什么衔接得上：**
- Day10 已把项目**优化到生产可用**
- Day11 把这个"生产可用"的项目**真正部署上线**
- Day12 再把 Day10 + Day11 的成果**打磨成面试稿**

**预习任务：**
1. 装好 Docker Desktop（Windows/Mac）或 docker-ce（Linux）
2. 跑通 `docker run -d -p 3306:3306 --name mysql8 -e MYSQL_ROOT_PASSWORD=root mysql:8.0`
3. 阅读 Docker 中文文档"入门"章节

---

## Day10 全天小结

Day10 是**能力质变的一天**。前 9 天你会**写业务**，Day10 你会**优化业务**——发现问题、定位问题、解决问题、量化收益。

**技能地图：**
1. **诊断力**：慢日志 → EXPLAIN → Arthas dashboard
2. **改造力**：联合索引 → 覆盖索引 → 缓存三兄弟 → 多级缓存
3. **观察力**：JMeter TPS/p99 → GC 日志 → 缓存命中率
4. **表达力**：性能报告五段式 → 简历量化数据

**你的项目从今天起已具备：**
- 数据库百万数据下毫秒级响应
- 缓存三级保护
- JVM 参数可控、GC 可观测
- 完整的性能基线报告

至此 Day10 完成。**恭喜你，从今天起你的项目已具备生产可运维能力**。
