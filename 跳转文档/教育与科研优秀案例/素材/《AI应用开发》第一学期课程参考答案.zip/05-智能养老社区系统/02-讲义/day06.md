# 《智能养老社区系统》- 学生讲义 - Day06：客房智能预约管理

**授课日：Day 06 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day05 通义千问 ChatClient / SSE / Prompt 模板**

---

## 第 1 讲：预约业务分析与状态机

### 1.1 本讲要点
- 客房预约表 `room_reservation` 字段与业务映射
- 5 个状态与 6 条合法迁移边
- 时间区间重叠的正确 SQL 表达式
- 并发下单为什么必须用分布式锁

### 1.2 知识点详解

#### 1.2.1 room_reservation 表结构回顾

| 字段 | 类型 | 说明 |
|------|------|------|
| id | bigint | 主键 |
| member_id | bigint | 下单会员（Day03 会员表 FK） |
| room_id | bigint | 客房（Day04 客房表 FK） |
| check_in_date | date | 入住日 |
| check_out_date | date | 离店日 |
| status | tinyint | 0待支付 1已确认 2已入住 3已完成 4已取消 |
| total_price | decimal(10,2) | 冗余总价（防止价格调整穿透订单） |
| create_time | datetime | 下单时间 |

> 💡 **技巧：** `total_price` 一定要冗余存下单当时的价格，避免客房日均价 3 个月后调价影响历史订单。

#### 1.2.2 状态机迁移图

```
     ┌──── 创建 ────┐
     ▼             │
[0 待支付]         │
 │   │             │
 支付  超时/取消    │
 ▼      ▼          │
[1 已确认] ──取消─►[4 已取消]  (终态)
 │
 入住
 ▼
[2 已入住] ──退房──►[3 已完成] (终态)
```

**合法迁移白名单**（用代码校验）：
| 原状态 | 目标状态 | 触发接口 |
|--------|----------|----------|
| 0 | 1 | 支付回调 |
| 0 | 4 | 用户取消 / 定时任务 |
| 1 | 2 | 到店办入住 |
| 1 | 4 | 用户取消 |
| 2 | 3 | 退房 |

> ⚠️ **注意：** 已完成(3)、已取消(4)一旦到达不可再变；一切"回退"都要走新单，不改老单。

#### 1.2.3 时间重叠 SQL 的正确写法

已有一段 `[A_in, A_out)`，新预约 `[B_in, B_out)`，**重叠** ⇔ `B_in < A_out AND B_out > A_in`。

```sql
SELECT COUNT(*) FROM room_reservation
WHERE room_id = 101
  AND status IN (0, 1, 2)          -- 只让活跃订单参与冲突判定
  AND check_in_date < '2026-07-20'  -- 新预约的离店日
  AND check_out_date > '2026-07-16';-- 新预约的入住日
```

**常见错误写法**：
```sql
-- ❌ 只判断入住日在区间内，遗漏"新单完全包含已有单"的情况
WHERE check_in_date BETWEEN #{in} AND #{out}
```

> ⚠️ **注意：** 边界约定：如果一个人 07-18 退房，另一个人 07-18 当天入住，业务上一般算不冲突（酒店同理）。用 `<` 而不是 `<=` 就能自动跳过这种边界。

#### 1.2.4 为什么本地锁不够用

`synchronized` 只锁住当前 JVM。生产上后端至少两台机器做负载均衡，两个请求分别打到两台机器，两个 JVM 各自 synchronized、各自成功。所以要用**跨 JVM 的锁**：Redis / ZooKeeper / DB 行锁。本课程选 Redis（性能高、部署简单）。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 状态机 | 状态 + 事件 → 新状态的白名单 |
| 时间重叠 | `B_in < A_out AND B_out > A_in` |
| 分布式锁 | 跨 JVM 的互斥，保护"读-判-写"复合操作 |
| 冲突 SQL | 只对活跃订单(0/1/2)判定 |

### 1.4 示例代码/例题解析

**示例 1：Java 判断重叠**
```java
public static boolean overlap(LocalDate aIn, LocalDate aOut,
                               LocalDate bIn, LocalDate bOut) {
    return bIn.isBefore(aOut) && bOut.isAfter(aIn);
}
```
原理：把闭区间左端点、开区间右端点组合，等价于"两个区间的交集非空"。

### 1.5 课后练习
1. 【基础】把状态迁移白名单画成 5×5 表格。
2. 【综合】写 SQL 找出 2026 年 7 月被"最多次预约"的 Top 3 客房。
3. 【挑战】如果允许连续入住（旧客当天退新客当天入），SQL 需要如何调整？

---

## 第 2 讲：预约接口开发（下单/取消）

### 2.1 本讲要点
- ReservationDTO / VO / Entity 三层
- 下单五步：校验 → 存在 → 冲突 → 计算 → 落库
- `@Transactional` 事务边界与回滚
- 取消订单的合法状态判定

### 2.2 知识点详解

#### 2.2.1 接口清单

| 动作 | 方法 | URL | 请求体 |
|------|------|-----|--------|
| 下单 | POST | /api/reservations | ReservationDTO |
| 取消 | PUT | /api/reservations/{id}/cancel | 无 |
| 详情 | GET | /api/reservations/{id} | 无 |
| 分页 | GET | /api/reservations/page | query |

#### 2.2.2 DTO 与 Entity 拆分

**为什么要拆？** 前端可能传恶意字段，Entity 直接用 `@RequestBody` 接收会被"越权写入"。DTO 只有 memberId、roomId、checkInDate、checkOutDate 4 个字段，从根源上避免 total_price、status 被前端伪造。

```java
@Data
public class ReservationDTO {
    @NotNull(message = "会员ID不能为空")
    private Long memberId;
    @NotNull(message = "客房ID不能为空")
    private Long roomId;
    @NotNull(message = "入住日期不能为空")
    private LocalDate checkInDate;
    @NotNull(message = "离店日期不能为空")
    private LocalDate checkOutDate;
}
```

#### 2.2.3 下单五步核心代码

```java
@Service
@RequiredArgsConstructor
public class ReservationServiceImpl implements ReservationService {
    private final ReservationMapper reservationMapper;
    private final RoomMapper roomMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long createReservation(ReservationDTO dto) {
        // ① 校验入住 < 离店
        if (!dto.getCheckInDate().isBefore(dto.getCheckOutDate())) {
            throw new BizException("退房日期必须晚于入住日期");
        }
        // ② 客房存在且可预订
        Room room = roomMapper.selectById(dto.getRoomId());
        if (room == null || room.getStatus() != 1) {
            throw new BizException("客房不可用");
        }
        // ③ 时间冲突
        int cnt = reservationMapper.countConflict(
            dto.getRoomId(), dto.getCheckInDate(), dto.getCheckOutDate());
        if (cnt > 0) throw new BizException("该时段已被预订");
        // ④ 计算总价
        long days = ChronoUnit.DAYS.between(dto.getCheckInDate(), dto.getCheckOutDate());
        BigDecimal total = room.getDailyPrice().multiply(BigDecimal.valueOf(days));
        // ⑤ 落库
        RoomReservation entity = new RoomReservation();
        BeanUtils.copyProperties(dto, entity);
        entity.setStatus(0);
        entity.setTotalPrice(total);
        entity.setCreateTime(LocalDateTime.now());
        reservationMapper.insert(entity);
        return entity.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelReservation(Long id) {
        RoomReservation r = reservationMapper.selectById(id);
        if (r == null) throw new BizException("订单不存在");
        if (r.getStatus() != 0 && r.getStatus() != 1) {
            throw new BizException("当前状态不允许取消");
        }
        r.setStatus(4);
        reservationMapper.updateById(r);
    }
}
```

#### 2.2.4 Mapper XML

```xml
<mapper namespace="com.itcast.smart_elder.mapper.ReservationMapper">
    <select id="countConflict" resultType="int">
        SELECT COUNT(*) FROM room_reservation
        WHERE room_id = #{roomId}
          AND status IN (0, 1, 2)
          AND check_in_date &lt; #{checkOut}
          AND check_out_date &gt; #{checkIn}
    </select>

    <select id="pageQuery" resultType="com.itcast.smart_elder.vo.ReservationVO">
        SELECT r.*, rm.room_no AS roomNo, m.name AS memberName
        FROM room_reservation r
        LEFT JOIN room rm ON r.room_id = rm.id
        LEFT JOIN elder_member m ON r.member_id = m.id
        <where>
            <if test="memberId != null"> AND r.member_id = #{memberId} </if>
            <if test="status != null"> AND r.status = #{status} </if>
        </where>
        ORDER BY r.create_time DESC
    </select>
</mapper>
```

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| DTO | 前端 → 后端的入参对象 |
| VO | 后端 → 前端的出参对象 |
| @Transactional | 声明式事务，方法级 |
| 冲突 SQL | status IN(0,1,2) + 区间判定 |

### 2.4 示例代码/例题解析

**示例 1：Postman 触发冲突**
```http
POST /api/reservations
{ "memberId":1, "roomId":101, "checkInDate":"2026-07-15", "checkOutDate":"2026-07-18" }
→ 第 1 次：code=1
→ 第 2 次（相同参数）：code=0, msg="该时段已被预订"
```

### 2.5 课后练习
1. 【基础】完成 `getDetail(id)` 返回 ReservationVO。
2. 【综合】给取消接口加上"最近 5 分钟内可取消"限制。
3. 【挑战】用 `SELECT ... FOR UPDATE` 替换本节冲突 SQL，观察行锁效果。

---

## 第 3 讲：Redis 基础与集成

### 3.1 本讲要点
- Redis 五大数据结构与典型场景
- Spring Boot + Redis 的三步集成
- RedisConfig 序列化替换的必要性
- CacheDemoService 现场演示

### 3.2 知识点详解

#### 3.2.1 五大数据结构速记

| 类型 | 典型场景 | 关键命令 | Java 操作 |
|------|----------|----------|-----------|
| String | 缓存、计数器、令牌 | SET/GET/INCR | opsForValue |
| Hash | 对象缓存 | HSET/HGETALL | opsForHash |
| List | 消息队列、时间线 | LPUSH/RPOP | opsForList |
| Set | 去重、标签 | SADD/SISMEMBER | opsForSet |
| ZSet | 排行榜 | ZADD/ZRANGE | opsForZSet |

> 💡 **技巧：** "对象存 Hash、列表存 List、去重存 Set、排行 ZSet、其他 String"是入门口诀。

#### 3.2.2 集成三件事

**Step 1：pom.xml**
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

**Step 2：application.yml**
```yaml
spring:
  data:
    redis:
      host: 127.0.0.1
      port: 6379
      database: 0
      lettuce:
        pool:
          max-active: 8
          max-idle: 8
          min-idle: 0
```

**Step 3：RedisConfig.java**
```java
@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory cf) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(cf);

        StringRedisSerializer strSer = new StringRedisSerializer();
        Jackson2JsonRedisSerializer<Object> jsonSer =
            new Jackson2JsonRedisSerializer<>(Object.class);
        ObjectMapper om = new ObjectMapper();
        om.registerModule(new JavaTimeModule());
        om.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        om.activateDefaultTyping(LaissezFaireSubTypeValidator.instance,
            ObjectMapper.DefaultTyping.NON_FINAL);
        jsonSer.setObjectMapper(om);

        template.setKeySerializer(strSer);
        template.setHashKeySerializer(strSer);
        template.setValueSerializer(jsonSer);
        template.setHashValueSerializer(jsonSer);
        template.afterPropertiesSet();
        return template;
    }
}
```

> ⚠️ **注意：** 若跳过 RedisConfig，redis-cli 里看到的 value 会是 `"\xac\xed\x00\x05..."` 这种 JDK 序列化二进制，人不可读，跨语言也读不了。

#### 3.2.3 五种类型操作演示

```java
@Service
@RequiredArgsConstructor
public class CacheDemoService {
    private final RedisTemplate<String, Object> redisTemplate;

    public void demo() {
        // String
        redisTemplate.opsForValue().set("greet:1", "早上好，桂芳阿姨", 60, TimeUnit.SECONDS);

        // Hash：会员档案对象缓存
        Map<String, Object> profile = new HashMap<>();
        profile.put("name", "张桂芳");
        profile.put("age", 78);
        profile.put("level", "GOLD");
        redisTemplate.opsForHash().putAll("member:1", profile);

        // List：最近浏览客房
        redisTemplate.opsForList().leftPush("recent:member:1", 101L);
        redisTemplate.opsForList().leftPush("recent:member:1", 202L);
        redisTemplate.opsForList().trim("recent:member:1", 0, 9); // 保留最新 10 条

        // Set：客房标签
        redisTemplate.opsForSet().add("room:101:tags", "安静", "南向", "花园");
        Boolean isQuiet = redisTemplate.opsForSet().isMember("room:101:tags", "安静");

        // ZSet：客房热度榜
        redisTemplate.opsForZSet().incrementScore("room:hot", "101", 1);
        redisTemplate.opsForZSet().incrementScore("room:hot", "202", 3);
        Set<Object> top3 = redisTemplate.opsForZSet().reverseRange("room:hot", 0, 2);
    }
}
```

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Lettuce | Spring Boot 默认的 Redis 客户端，异步 NIO |
| RedisTemplate | Java 端操作 Redis 的门面 |
| Jackson2JsonRedisSerializer | 让 value 变成人类可读 JSON |
| StringRedisSerializer | 让 key 保持普通字符串 |

### 3.4 示例代码/例题解析

**示例 1：redis-cli 验证**
```
> KEYS *
1) "greet:1"
2) "member:1"
3) "room:101:tags"
> GET greet:1
"\"早上好，桂芳阿姨\""
> HGETALL member:1
1) "name"  2) "\"张桂芳\""
3) "age"   4) "78"
```

### 3.5 课后练习
1. 【基础】写代码把当前登录会员 id 缓存 30 分钟。
2. 【综合】统计"过去 1 小时"客房浏览量 Top 5（提示：ZSet + 时间桶 key）。
3. 【挑战】把 Jackson 换成 GenericJackson2JsonRedisSerializer，观察差异。

---

## 第 4 讲：Redis 实战：缓存与分布式锁

### 4.1 本讲要点
- Cache-Aside 三步走
- 随机 TTL 防雪崩
- setIfAbsent 分布式锁 + try-finally + TTL 兜底
- 释放锁前 check value

### 4.2 知识点详解

#### 4.2.1 Cache-Aside 模式

```
读：Redis 命中 → 直接返回
    Redis 未命中 → DB 查询 → 回填 Redis(带 TTL) → 返回
写：先更新 DB → 删除对应缓存 key（不是改）
```

**为什么删而不是改？** 高并发下"改缓存"存在时序错乱：DB 已更新为 v2，但两个线程分别拿到 v1、v2 去写缓存，v1 后写就脏了。**删缓存**的策略下，下次读会重新回填最新值。

#### 4.2.2 客房列表缓存

```java
@Service
@RequiredArgsConstructor
public class RoomCacheService {
    private final RedisTemplate<String, Object> redisTemplate;
    private final RoomMapper roomMapper;
    private static final String KEY = "room:list:available";

    @SuppressWarnings("unchecked")
    public List<Room> listAvailable() {
        Object cached = redisTemplate.opsForValue().get(KEY);
        if (cached != null) return (List<Room>) cached;

        List<Room> list = roomMapper.selectAvailable();
        int ttl = 300 + new Random().nextInt(60);  // 5-6 分钟随机 TTL
        redisTemplate.opsForValue().set(KEY, list, ttl, TimeUnit.SECONDS);
        return list;
    }

    public void evict() { redisTemplate.delete(KEY); }
}
```

> ⚠️ **注意：** 客房上下架、修改后必须调用 `evict()`，否则缓存最长 6 分钟才失效。

#### 4.2.3 分布式锁 setIfAbsent

Redis 命令 `SET key value NX EX seconds` 是原子的：只有 key 不存在时才设置，同时带过期时间。Spring Data Redis 对应：

```java
Boolean ok = redisTemplate.opsForValue().setIfAbsent(key, value, ttl, TimeUnit.SECONDS);
```

**四要素**：
1. **value 用 UUID**：区分不同线程的所有者
2. **必须带 TTL**：兜底防死锁
3. **try-finally 释放**：业务再抛异常也要释放
4. **释放前 check value**：避免释放别人的锁

```java
@Component
@RequiredArgsConstructor
public class RedisLock {
    private final RedisTemplate<String, Object> redisTemplate;

    public String tryLock(String key, long ttlSeconds) {
        String token = UUID.randomUUID().toString();
        Boolean ok = redisTemplate.opsForValue()
            .setIfAbsent(key, token, ttlSeconds, TimeUnit.SECONDS);
        return Boolean.TRUE.equals(ok) ? token : null;
    }

    public void unlock(String key, String token) {
        Object cur = redisTemplate.opsForValue().get(key);
        if (token != null && token.equals(cur)) {
            redisTemplate.delete(key);
        }
    }
}
```

> 💡 **技巧：** 更严谨的做法是把"判断 + 删除"做成 Lua 脚本原子执行。本课程为控制复杂度只用 get + delete 两步，业务并发不高时可接受，生产环境建议 Redisson。

#### 4.2.4 下单加锁

```java
public Long createReservation(ReservationDTO dto) {
    String lockKey = "lock:reservation:room:" + dto.getRoomId();
    String token = redisLock.tryLock(lockKey, 10);
    if (token == null) throw new BizException("操作过于频繁，请稍后再试");
    try {
        return doCreate(dto);       // 原五步
    } finally {
        redisLock.unlock(lockKey, token);
    }
}
```

**锁粒度**：以 `room_id` 为锁 key，粒度到"单间客房"。不同客房下单互不影响。

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Cache-Aside | 应用层负责读缓存/回填/删缓存 |
| 缓存雪崩 | 大量 key 同时过期 → 冲击 DB |
| 随机 TTL | 让过期时间打散 |
| SETNX | SET if Not eXists |
| 锁粒度 | 锁 key 越细，并发越高 |

### 4.4 示例代码/例题解析

**示例 1：两个 Postman 同时下单**
```
终端 A: POST /api/reservations {...roomId=101...}
终端 B: POST /api/reservations {...roomId=101...}  (与 A 相同时段)

只有一个能成功，另一个：
- 若锁抢占失败 → "操作过于频繁，请稍后再试"
- 若拿到锁但发现冲突 → "该时段已被预订"
```

### 4.5 课后练习
1. 【基础】给"客房详情"加缓存 `room:detail:{id}` TTL 10 分钟。
2. 【综合】客房修改接口调用 evict()，编写测试用例。
3. 【挑战】压力测试：JMeter 200 并发同参下单，验证只有 1 单成功。

---

## 第 5 讲：基于 AI 的智能预约推荐

### 5.1 本讲要点
- 自然语 → 结构化参数的 AI 抽取思路
- Prompt 强约束 JSON 输出
- Jackson ObjectMapper 反序列化
- 与客房搜索接口的对接

### 5.2 知识点详解

#### 5.2.1 整体链路

```
用户："下周末两个人入住希望安静靠近花园"
   │
   ▼
Controller 收到
   │
   ▼
拼 Prompt（含当天日期、用户输入）
   │
   ▼
ChatClient 调通义千问
   │
   ▼
拿到 JSON: {"checkIn":"...","checkOut":"...","guestNum":2,"keywords":["安静","花园"]}
   │
   ▼
Jackson 反序列化 → RecommendParam
   │
   ▼
RoomMapper.searchByKeywords → 客房列表
   │
   ▼
Result<List<Room>>
```

#### 5.2.2 Prompt 三要素

1. **角色**：告诉模型它是谁
2. **任务**：告诉模型要干什么
3. **输出格式**：给出 JSON schema + 示例 + "只输出 JSON"约束

```
你是"AI 智能养老社区系统"的预约助手。
请从用户下面这句话中，提取入住/离店日期、人数、偏好关键字。
今天日期是 2026-07-09，请把"下周""周末"等相对时间换算为具体日期(yyyy-MM-dd)。
必须只输出一个 JSON 对象，不要任何解释，不要 markdown 代码块。
JSON 字段：
  checkIn(string,yyyy-MM-dd)、checkOut(string,yyyy-MM-dd)、
  guestNum(int)、keywords(string[])
用户输入：下周末两个人入住希望安静靠近花园
```

> 💡 **技巧：** 加"必须只输出 JSON"能极大提高稳定性；把当天日期告诉模型，"下周末"才能被换算成具体日期。

#### 5.2.3 完整实现

```java
@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiRecommendController {
    private final AiRecommendService aiRecommendService;

    @PostMapping("/recommend")
    public Result<List<Room>> recommend(@RequestBody Map<String, String> body) {
        return Result.success(aiRecommendService.recommend(body.get("text")));
    }
}
```

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class AiRecommendService {
    private final ChatClient chatClient;
    private final RoomMapper roomMapper;
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final String TPL = """
        你是"AI 智能养老社区系统"的预约助手。
        请从用户下面这句话中，提取入住/离店日期、人数、偏好关键字。
        今天日期是 {today}，请把"下周""周末"等相对时间换算为具体日期(yyyy-MM-dd)。
        必须只输出一个 JSON 对象，不要任何解释，不要 markdown 代码块。
        JSON 字段：
          checkIn(string,yyyy-MM-dd)、checkOut(string,yyyy-MM-dd)、
          guestNum(int)、keywords(string[])
        用户输入：{userText}
        """;

    public List<Room> recommend(String userText) {
        String prompt = TPL
            .replace("{today}", LocalDate.now().toString())
            .replace("{userText}", userText);

        String raw = chatClient.prompt().user(prompt).call().content();
        String json = stripCodeFence(raw);
        RecommendParam p;
        try {
            p = objectMapper.readValue(json, RecommendParam.class);
        } catch (Exception e) {
            log.warn("AI 输出解析失败：{}", raw, e);
            throw new BizException("请把您的需求描述得更清楚一些");
        }
        return roomMapper.searchByKeywords(p.getKeywords());
    }

    private String stripCodeFence(String s) {
        s = s.trim();
        if (s.startsWith("```")) {
            s = s.replaceAll("(?s)^```(json)?", "").replaceAll("```$", "").trim();
        }
        return s;
    }

    @Data
    public static class RecommendParam {
        private String checkIn;
        private String checkOut;
        private Integer guestNum;
        private List<String> keywords;
    }
}
```

**Mapper 侧关键字模糊匹配**：
```xml
<select id="searchByKeywords" resultType="com.itcast.smart_elder.entity.Room">
    SELECT * FROM room WHERE status = 1
    <if test="list != null and list.size() > 0">
        AND (
            <foreach collection="list" item="kw" separator=" OR ">
                tags LIKE CONCAT('%', #{kw}, '%')
            </foreach>
        )
    </if>
    ORDER BY id LIMIT 10
</select>
```

> ⚠️ **注意：** 模型偶尔仍会输出 ```json 代码块或 "根据您的输入..." 之类的解释文字。用 `stripCodeFence` 剥壳；解析失败要给用户友好提示而不是 500。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 结构化抽取 | 把自然语转成 Java 对象 |
| JSON schema | 在 Prompt 里给出字段定义 |
| 剥壳 | 去掉模型返回的 markdown 代码块 |
| few-shot | 在 Prompt 里给示例，提高稳定性 |

### 5.4 示例代码/例题解析

**示例 1：三种输入的抽取结果**
| 用户输入 | AI 抽取的 JSON |
|----------|----------------|
| 下周末两个人入住希望安静靠近花园 | `{"checkIn":"2026-07-17","checkOut":"2026-07-19","guestNum":2,"keywords":["安静","花园"]}` |
| 这周四想住豪华套房带阳台 | `{"checkIn":"2026-07-09","checkOut":"2026-07-10","guestNum":1,"keywords":["豪华","阳台"]}` |
| 8 月 1 号一个人住 5 天要南向 | `{"checkIn":"2026-08-01","checkOut":"2026-08-06","guestNum":1,"keywords":["南向"]}` |

### 5.5 课后练习
1. 【基础】修改 Prompt，让 AI 额外抽取"预算区间"。
2. 【综合】把 keywords 匹配从 OR 改为 AND，比较召回率。
3. 【挑战】给 AI 增加"若信息不足回问用户"的策略，Prompt 返回 `{"ask":"..."}`。

---

## 第 6 讲：前端预约页面与日历组件

### 6.1 本讲要点
- el-date-picker daterange 用法
- 客房卡片列表与选中态
- AI 智能推荐按钮联动
- 表单提交后闭环刷新

### 6.2 知识点详解

#### 6.2.1 页面结构

```
booking.vue
├── 顶部卡片
│   ├── el-date-picker daterange
│   └── el-input + [智能推荐] 按钮
├── 客房卡片列表 (el-row/el-col + el-card)
└── 订单摘要 + [立即预约] 按钮
```

#### 6.2.2 API 封装

```ts
// src/api/reservation.ts
import request from '@/utils/request'
export const listAvailableRooms = () => request.get('/api/rooms/available')
export const createReservation = (data: any) => request.post('/api/reservations', data)
export const aiRecommend = (text: string) => request.post('/api/ai/recommend', { text })
```

#### 6.2.3 booking.vue 完整代码

```vue
<template>
  <div class="booking">
    <el-card>
      <el-form :model="form" label-width="90px">
        <el-form-item label="入住日期">
          <el-date-picker
            v-model="form.dateRange"
            type="daterange"
            value-format="YYYY-MM-DD"
            range-separator="至"
            start-placeholder="入住"
            end-placeholder="离店" />
        </el-form-item>
        <el-form-item label="智能推荐">
          <el-input v-model="aiText"
            placeholder="例：下周末两人入住希望安静靠近花园" />
          <el-button type="primary" style="margin-top:8px;"
            @click="handleRecommend">智能推荐</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-row :gutter="12" class="room-list">
      <el-col :span="8" v-for="r in rooms" :key="r.id">
        <el-card
          :class="['room-card', { active: form.roomId === r.id }]"
          @click="form.roomId = r.id">
          <h3>{{ r.roomNo }} · {{ r.roomType }}</h3>
          <p>￥{{ r.dailyPrice }} / 晚</p>
          <p class="tags">{{ r.tags }}</p>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="summary">
      <p>已选客房：{{ selectedRoom?.roomNo || '未选择' }}</p>
      <p>预计总价：￥{{ totalPrice }}</p>
      <el-button type="success" size="large" @click="submit">立即预约</el-button>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { listAvailableRooms, createReservation, aiRecommend }
  from '@/api/reservation'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()
const form = ref({ dateRange: [] as string[], roomId: null as number | null })
const aiText = ref('')
const rooms = ref<any[]>([])

const loadRooms = async () => {
  const { data } = await listAvailableRooms()
  rooms.value = data
}
loadRooms()

const selectedRoom = computed(() =>
  rooms.value.find(r => r.id === form.value.roomId))

const totalPrice = computed(() => {
  if (!selectedRoom.value || form.value.dateRange.length !== 2) return 0
  const [s, e] = form.value.dateRange
  const days = (+new Date(e) - +new Date(s)) / 86400000
  return (selectedRoom.value.dailyPrice * days).toFixed(2)
})

const handleRecommend = async () => {
  if (!aiText.value) return ElMessage.warning('请先输入需求')
  const { data } = await aiRecommend(aiText.value)
  rooms.value = data
  ElMessage.success(`AI 推荐了 ${data.length} 间客房`)
}

const submit = async () => {
  if (!form.value.roomId) return ElMessage.warning('请选择客房')
  if (form.value.dateRange.length !== 2) return ElMessage.warning('请选择日期')
  await createReservation({
    memberId: userStore.memberId,
    roomId: form.value.roomId,
    checkInDate: form.value.dateRange[0],
    checkOutDate: form.value.dateRange[1]
  })
  ElMessage.success('预约成功')
  form.value = { dateRange: [], roomId: null }
  loadRooms()
}
</script>

<style scoped>
.room-list { margin-top: 12px; }
.room-card { cursor: pointer; transition: all .2s; }
.room-card.active { border: 2px solid #409eff; }
.summary { margin-top: 16px; text-align: center; }
</style>
```

> 💡 **技巧：** `value-format="YYYY-MM-DD"` 让 v-model 直接是字符串，省去前端 dayjs 转换的一步。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| daterange | el-date-picker 的范围选择模式 |
| 卡片选中态 | 用 class 绑定 + 点击回填 form.roomId |
| computed | 派生状态（总价、选中客房） |
| Pinia userStore | 复用登录会员的 memberId |

### 6.4 示例代码/例题解析

**示例 1：完整下单闭环**
```
① 选日期 [2026-07-15, 2026-07-18]
② 输入"希望南向安静" → 智能推荐 → 卡片刷新为 3 间
③ 点选 101 → 摘要显示 ￥900
④ 立即预约 → toast "预约成功" → 列表刷新（101 从可用列表移除）
```

### 6.5 课后练习
1. 【基础】增加"我的预约"页面 `views/reservation/mine.vue`，展示当前会员所有订单。
2. 【综合】给 daterange 加 `disabled-date`，禁止选历史日期。
3. 【挑战】用 el-calendar 组件做全月客房占用视图（进阶）。

---

## 附录 A：Redis 常用命令速查表

### A.1 通用命令

| 命令 | 作用 | 示例 |
|------|------|------|
| KEYS pattern | 匹配 key（生产禁用！） | `KEYS room:*` |
| SCAN cursor MATCH pat COUNT n | 分批扫描 key | `SCAN 0 MATCH room:* COUNT 100` |
| EXISTS key | 判断是否存在 | `EXISTS greet:1` |
| DEL key | 删除 | `DEL greet:1` |
| EXPIRE key seconds | 设过期时间 | `EXPIRE greet:1 60` |
| TTL key | 剩余生存秒数 | `TTL greet:1` |
| TYPE key | 查数据类型 | `TYPE room:hot` → zset |
| FLUSHDB | 清空当前 DB（危险！） | `FLUSHDB` |

### A.2 String

| 命令 | 说明 |
|------|------|
| SET k v [EX s] [NX] | 写入，NX = 只当 k 不存在写 |
| GET k | 读取 |
| INCR k / DECR k | 自增/自减 |
| INCRBY k n | 加 n |
| SETEX k s v | 带过期时间写 |
| MGET k1 k2 | 批量读 |

### A.3 Hash

| 命令 | 说明 |
|------|------|
| HSET k field v | 写字段 |
| HGET k field | 读字段 |
| HMSET k f1 v1 f2 v2 | 批量写 |
| HGETALL k | 全部字段+值 |
| HDEL k field | 删字段 |
| HINCRBY k field n | 字段自增 |

### A.4 List

| 命令 | 说明 |
|------|------|
| LPUSH k v | 头部入 |
| RPUSH k v | 尾部入 |
| LPOP k | 头部出 |
| RPOP k | 尾部出 |
| LRANGE k 0 -1 | 全部元素 |
| LLEN k | 长度 |
| LTRIM k s e | 保留 [s,e] 区间 |

### A.5 Set

| 命令 | 说明 |
|------|------|
| SADD k m1 m2 | 添加成员 |
| SREM k m | 删成员 |
| SISMEMBER k m | 是否包含 |
| SMEMBERS k | 全部成员 |
| SCARD k | 成员数 |
| SINTER k1 k2 | 交集 |
| SUNION k1 k2 | 并集 |

### A.6 ZSet

| 命令 | 说明 |
|------|------|
| ZADD k score m | 添加带分数成员 |
| ZINCRBY k n m | 分数自增 |
| ZSCORE k m | 查询分数 |
| ZRANGE k 0 -1 [WITHSCORES] | 升序取全 |
| ZREVRANGE k 0 9 | 降序前 10 |
| ZRANGEBYSCORE k min max | 按分数范围 |
| ZCARD k | 成员数 |

### A.7 分布式锁模板

```
# 加锁（NX + EX 原子）
SET lock:room:101 uuid-abc NX EX 10

# 释放锁（生产环境应用 Lua 保原子）
GET lock:room:101         # 若值 == uuid-abc
DEL lock:room:101
```

### A.8 排障命令

| 命令 | 作用 |
|------|------|
| INFO | 服务器信息 |
| CLIENT LIST | 客户端列表 |
| MEMORY USAGE key | key 占用内存 |
| SLOWLOG GET 10 | 慢日志 |
| MONITOR | 实时命令流（诊断用，别长期开） |

---

**Day06 讲义结束**：今天你完成了从"预约业务规则"到"AI 自然语抽参"的一次全链路穿越——数据库、事务、缓存、锁、大模型五种技术在一个业务里协同。明天进入 Day07 AI 智能体（Function Calling + RAG），继续升级 AI 深度。
