# 《智能养老社区系统》- 学生讲义 - Day03：会员管理模块开发

**授课日：Day 03 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day02 已完成 SpringBoot + MyBatis-Plus 后端骨架、Vue3 + Element Plus 前端骨架**

---

## 第 1 讲：会员业务分析与接口约定

### 1.1 本讲要点
- 理解会员在养老社区系统中的定位（不是电商 VIP，而是"入住老人档案"）
- 掌握会员生命周期：注册 → 审核 → 激活 → 停用/注销
- 学会拆解一组 CRUD 接口的 6 个动作
- 掌握 RESTful 命名规范：名词复数 + HTTP 动词
- 复用 Day02 已经封装好的 `Result<T>` 与 `PageBean<T>`

### 1.2 知识点详解

#### 1.2.1 会员生命周期
在企业真实业务中，会员不是"建了就能用"，而要走完一个状态流：

| 状态 | 含义 | 触发方 |
|------|------|--------|
| 待审核 | 前台登记后提交 | 前台工作人员 |
| 已激活 | 审核通过、可正常使用 | 管理员 |
| 已停用 | 因欠费或违规临时关闭 | 管理员 |
| 已注销 | 老人离世或搬离，逻辑删除 | 管理员 |

> 💡 **技巧：** 本课程为了聚焦"技术骨架"，只保留 `status` 字段（1=启用/0=停用）+ `deleted`（1=已注销）两个字段。业务扩展留作 Day10 优化时讨论。

#### 1.2.2 6 个接口的 RESTful 约定

| 编号 | 动作 | 请求方式 | URL | 参数位置 | 响应 |
|------|------|----------|-----|----------|------|
| ① | 分页 | GET | /api/members/page | query | Result&lt;PageBean&lt;ElderMember&gt;&gt; |
| ② | 详情 | GET | /api/members/{id} | path | Result&lt;MemberVO&gt; |
| ③ | 新增 | POST | /api/members | body(JSON) | Result&lt;Void&gt; |
| ④ | 修改 | PUT | /api/members | body(JSON) | Result&lt;Void&gt; |
| ⑤ | 批量删除 | DELETE | /api/members/{ids} | path | Result&lt;Void&gt; |
| ⑥ | 启停 | PUT | /api/members/status | body(JSON) | Result&lt;Void&gt; |

> ⚠️ **注意：** URL 里的资源名一定用**复数**（members），别写成 member；启停之所以单独设计是为了"只改一个字段"而不与整体修改混淆。

#### 1.2.3 复用 Day02 的封装
```java
// Day02 已封装（本讲无需再写）
public class Result<T> {
    private Integer code;   // 1=成功 0=失败
    private String msg;
    private T data;
    public static <T> Result<T> success() { ... }
    public static <T> Result<T> success(T data) { ... }
    public static <T> Result<T> fail(String msg) { ... }
}

public class PageBean<T> {
    private Long total;
    private List<T> rows;
    public PageBean(Long total, List<T> rows) { ... }
}
```

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| DTO | Data Transfer Object，只接收前端参数 |
| VO | View Object，只封装返给前端的数据 |
| Entity | 只映射数据库表 |
| RESTful | 名词复数 URL + HTTP 动词表达操作 |

### 1.4 示例代码/例题解析

**示例 1：一个完整的接口请求-响应对**
```http
# 请求
GET /api/members/page?name=张&pageNum=1&pageSize=10

# 响应
{
  "code": 1,
  "msg": "success",
  "data": {
    "total": 128,
    "rows": [
      {
        "id": 1,
        "name": "张桂芳",
        "phone": "13800001111",
        "memberLevel": "GOLD",
        "createTime": "2026-07-01 10:00:00"
      }
    ]
  }
}
```
原理解释：GET 的分页参数放 query，是因为便于浏览器分享、便于缓存；如果放 body，浏览器不会为 GET 请求发送 body。

### 1.5 课后练习
1. 【基础】把 6 个接口在 Postman 中占位建好，写清 URL 与请求方式。
2. 【综合】为每个接口列出可能出现的失败情况（如 ⑤ 批量删除的 ids 为空）。
3. 【挑战】思考如果同时有前台 App 和后台管理端，接口应该分成两组还是共用？

---

## 第 2 讲：会员分页查询接口开发

### 2.1 本讲要点
- 掌握 MyBatis-Plus 的分页插件注册
- 学会 `IPage`、`Page`、`LambdaQueryWrapper` 三兄弟的搭配
- 掌握"条件为空则不拼接"的 `hasText` 用法
- 完成 Controller → Service → Mapper 三层落地
- 用 Postman 完成第一次真实接口测试

### 2.2 知识点详解

#### 2.2.1 分页插件注册
MyBatis-Plus 的分页不是开箱即用，需要注册拦截器（Day02 已经放好）：

```java
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
```

> ⚠️ **注意：** 不注册这个 Bean，`selectPage` 也不会报错，但也不会 LIMIT，会把整张表查出来！

#### 2.2.2 LambdaQueryWrapper 的条件表达

| 场景 | 代码 | 生成 SQL |
|------|------|----------|
| 姓名模糊 | `.like(hasText(name), ElderMember::getName, name)` | `AND name LIKE '%张%'` |
| 手机号模糊 | `.like(hasText(phone), ElderMember::getPhone, phone)` | `AND phone LIKE '%138%'` |
| 等级精确 | `.eq(hasText(level), ElderMember::getMemberLevel, level)` | `AND member_level = 'GOLD'` |
| 创建时间倒序 | `.orderByDesc(ElderMember::getCreateTime)` | `ORDER BY create_time DESC` |

> 💡 **技巧：** `.like(condition, field, value)` 的第 1 个参数是**布尔条件**，为 false 时该条件不会拼到 SQL 里 —— 这就是"动态 SQL"的精髓。

#### 2.2.3 IPage 与 PageBean 的转换
```java
IPage<ElderMember> mp = memberMapper.selectPage(new Page<>(1, 10), wrapper);
PageBean<ElderMember> pb = new PageBean<>(mp.getTotal(), mp.getRecords());
```
`IPage` 是 MyBatis-Plus 的返回值，字段名是 `total/records`；我们的 `PageBean` 字段是 `total/rows`，故只做一次简单包装。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Page&lt;T&gt; | MyBatis-Plus 的分页入参对象 |
| IPage&lt;T&gt; | MyBatis-Plus 的分页返回值接口 |
| LambdaQueryWrapper | 基于方法引用的类型安全条件构造器 |
| hasText | Spring 提供的字符串非空判断（会排除全空格） |

### 2.4 示例代码/例题解析

**示例 1：完整的 DTO/Controller/Service/Mapper**

```java
// DTO
@Data
public class MemberPageDTO {
    private String name;
    private String phone;
    private String memberLevel;
    private Integer pageNum = 1;
    private Integer pageSize = 10;
}

// Controller
@RestController
@RequestMapping("/api/members")
@RequiredArgsConstructor
public class MemberController {
    private final MemberService memberService;

    @GetMapping("/page")
    public Result<PageBean<ElderMember>> page(MemberPageDTO dto) {
        return Result.success(memberService.page(dto));
    }
}

// Service
public interface MemberService {
    PageBean<ElderMember> page(MemberPageDTO dto);
}

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {
    private final MemberMapper memberMapper;

    @Override
    public PageBean<ElderMember> page(MemberPageDTO dto) {
        Page<ElderMember> p = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<ElderMember> w = new LambdaQueryWrapper<ElderMember>()
                .like(StringUtils.hasText(dto.getName()), ElderMember::getName, dto.getName())
                .like(StringUtils.hasText(dto.getPhone()), ElderMember::getPhone, dto.getPhone())
                .eq(StringUtils.hasText(dto.getMemberLevel()), ElderMember::getMemberLevel, dto.getMemberLevel())
                .orderByDesc(ElderMember::getCreateTime);
        IPage<ElderMember> r = memberMapper.selectPage(p, w);
        return new PageBean<>(r.getTotal(), r.getRecords());
    }
}

// Mapper
public interface MemberMapper extends BaseMapper<ElderMember> { }
```

原理解释：Controller 只做协议翻译（HTTP ↔ Java 对象），Service 承接业务逻辑，Mapper 承接持久化。三层清晰隔离，任何一层都能单独替换（比如换个 NoSQL 数据源只改 Mapper）。

**示例 2：MemberMapper.xml（可选，若用 XML 方式）**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.itcast.smart_elder.mapper.MemberMapper">

  <select id="pageQuery" resultType="com.itcast.smart_elder.entity.ElderMember">
    SELECT id, name, gender, age, phone, id_card, address,
           emergency_contact, health_status, member_level, status,
           create_time, update_time
    FROM elder_member
    <where>
      deleted = 0
      <if test="name != null and name != ''">
        AND name LIKE CONCAT('%', #{name}, '%')
      </if>
      <if test="phone != null and phone != ''">
        AND phone LIKE CONCAT('%', #{phone}, '%')
      </if>
      <if test="memberLevel != null and memberLevel != ''">
        AND member_level = #{memberLevel}
      </if>
    </where>
    ORDER BY create_time DESC
  </select>
</mapper>
```

> 💡 **技巧：** 本课程主推 `LambdaQueryWrapper`，但 XML 版本用于对比学习和面试装备。企业内部两种写法都常见。

### 2.5 课后练习
1. 【基础】把上面代码跑通，Postman 请求 `GET /api/members/page?pageNum=1&pageSize=5` 能返回 5 条真实数据。
2. 【综合】增加"按性别（gender）"筛选条件。
3. 【挑战】将查询改为"支持一次传入多个等级 memberLevels=GOLD,SILVER"（提示：DTO 用 `List<String>`，Wrapper 用 `.in`）。

---

## 第 3 讲：会员新增与修改接口

### 3.1 本讲要点
- 掌握 JSR303 参数校验（`@NotBlank`、`@NotNull`、`@Pattern`、`@Size`、`@Min`、`@Max`）
- 学会用 `@RestControllerAdvice` 统一处理校验异常
- 使用 MyBatis-Plus 通用字段自动填充 `MetaObjectHandler`
- `save` 与 `updateById` 的区别与调用姿势
- 双保险原则：前端校验 + 后端 @Valid 兜底

### 3.2 知识点详解

#### 3.2.1 常用校验注解

| 注解 | 作用 | 示例 |
|------|------|------|
| @NotBlank | 字符串不为空且不全空格 | 姓名、手机号 |
| @NotNull | 对象非 null（含数字类型） | 年龄、id |
| @Pattern | 正则匹配 | 手机号、身份证 |
| @Size | 字符串/集合长度区间 | 姓名 2-20 位 |
| @Min / @Max | 数值区间 | 年龄 0-120 |
| @Email | 邮箱格式 | 邮箱字段 |

> 💡 **技巧：** `@NotBlank` 只能作用于 `String`；`@NotNull` 才能作用于 `Integer`、`Long` 等包装类型。

#### 3.2.2 真实可用的正则

| 字段 | 正则 | 说明 |
|------|------|------|
| 手机号 | `^1[3-9]\d{9}$` | 1 开头，第 2 位 3-9 |
| 身份证 | `^\d{17}[0-9Xx]$` | 17 位数字 + 1 位数字或 X |
| 中文姓名 | `^[\u4e00-\u9fa5]{2,20}$` | 2-20 位汉字 |

#### 3.2.3 自动填充的原理
MyBatis-Plus 通过 `MetaObjectHandler` 在 insert/update 语句拦截阶段自动写入字段值，避免每处都手动 `setCreateTime(...)`。

```java
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        this.strictInsertFill(metaObject, "createTime", LocalDateTime.class, LocalDateTime.now());
        this.strictInsertFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
    }
    @Override
    public void updateFill(MetaObject metaObject) {
        this.strictUpdateFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
    }
}
```
在实体字段上加：
```java
@TableField(fill = FieldFill.INSERT)          private LocalDateTime createTime;
@TableField(fill = FieldFill.INSERT_UPDATE)   private LocalDateTime updateTime;
```

> ⚠️ **注意：** `strictInsertFill` 只在实体对应字段为 null 时才填充，避免覆盖调用方主动赋值。

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| @Valid | 触发 JSR303 校验的开关 |
| BindingResult | 校验错误集合，Spring 自动注入 |
| MethodArgumentNotValidException | @RequestBody + @Valid 校验失败抛出的异常 |
| MetaObjectHandler | MyBatis-Plus 自动填充接口 |

### 3.4 示例代码/例题解析

**示例 1：完整的 ElderMember 实体**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("elder_member")
public class ElderMember {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private String gender;
    private Integer age;
    private String phone;
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    private String memberLevel;
    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableLogic
    private Integer deleted;
}
```

**示例 2：新增 DTO 与修改 DTO**
```java
@Data
public class MemberAddDTO {
    @NotBlank(message = "姓名必填")
    @Size(min = 2, max = 20, message = "姓名长度 2-20")
    private String name;
    @NotBlank(message = "性别必填")
    private String gender;
    @NotNull(message = "年龄必填")
    @Min(value = 0, message = "年龄非法")
    @Max(value = 120, message = "年龄非法")
    private Integer age;
    @NotBlank(message = "手机号必填")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;
    @NotBlank(message = "身份证必填")
    @Pattern(regexp = "^\\d{17}[0-9Xx]$", message = "身份证格式不正确")
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    @NotBlank(message = "会员等级必填")
    private String memberLevel;
}

@Data
public class MemberUpdateDTO {
    @NotNull(message = "id 必填")
    private Long id;
    @Size(min = 2, max = 20)
    private String name;
    private String gender;
    private Integer age;
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;
    @Pattern(regexp = "^\\d{17}[0-9Xx]$", message = "身份证格式不正确")
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    private String memberLevel;
}
```

**示例 3：Controller 与 Service 追加**
```java
// Controller
@PostMapping
public Result<Void> add(@RequestBody @Valid MemberAddDTO dto) {
    memberService.add(dto);
    return Result.success();
}

@PutMapping
public Result<Void> update(@RequestBody @Valid MemberUpdateDTO dto) {
    memberService.update(dto);
    return Result.success();
}

// Service
@Override
public void add(MemberAddDTO dto) {
    ElderMember m = new ElderMember();
    BeanUtils.copyProperties(dto, m);
    m.setStatus(1);
    memberMapper.insert(m);
}

@Override
public void update(MemberUpdateDTO dto) {
    ElderMember m = new ElderMember();
    BeanUtils.copyProperties(dto, m);
    memberMapper.updateById(m);
}
```

**示例 4：全局异常处理**
```java
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("；"));
        return Result.fail(msg);
    }

    @ExceptionHandler(Exception.class)
    public Result<Void> handleAll(Exception e) {
        return Result.fail("系统错误：" + e.getMessage());
    }
}
```

原理解释：`@Valid` 触发校验后，`BindingResult` 若不写就会抛异常。异常经过 `@RestControllerAdvice` 拦截，最后统一以 `Result` 返回给前端，前端再取 `msg` 弹提示。

### 3.5 课后练习
1. 【基础】用 Postman 发送 `phone=12345` 的非法请求，验证返回 msg 包含"手机号格式不正确"。
2. 【综合】给 `MemberAddDTO` 加上"电子邮箱"字段，用 `@Email` 校验。
3. 【挑战】在 Service 层加入"手机号唯一"业务校验，重复时抛自定义 `BizException` 并被全局异常捕获。

---

## 第 4 讲：会员删除与详情回显

### 4.1 本讲要点
- 掌握 `@TableLogic` 逻辑删除的用法与配置
- 学会两种批量删除入参：路径逗号 `List<Long>` 与 body 数组
- 掌握 VO 设计原则：脱敏敏感字段（身份证、手机号）
- 理解幂等性与二次防误删
- 独立设计"启用/停用"接口

### 4.2 知识点详解

#### 4.2.1 逻辑删除
物理删除是 `DELETE FROM ...`，逻辑删除是 `UPDATE ... SET deleted = 1`。MyBatis-Plus 只需要三步：
1. 实体字段加 `@TableLogic`。
2. `application.yml` 配置删除值。
3. `deleteBatchIds(ids)` 会自动改成 UPDATE。

```yaml
mybatis-plus:
  global-config:
    db-config:
      logic-delete-field: deleted
      logic-delete-value: 1
      logic-not-delete-value: 0
```

> ⚠️ **注意：** 逻辑删除后，`selectById`、`selectPage` 都会自动加 `WHERE deleted=0`；如需查询已删数据，需要用 `Db.getMapper(...).selectList` 加自定义 SQL。

#### 4.2.2 批量删除路径的写法
```java
@DeleteMapping("/{ids}")
public Result<Void> delete(@PathVariable List<Long> ids) { ... }
```
Spring MVC 会把 `/1,2,3` 自动解析为 `List<Long>[1,2,3]`。

> 💡 **技巧：** 若接口设计规定用 body 传入 `{"ids":[1,2,3]}`，Controller 参数改成 `@RequestBody List<Long> ids` 即可。

#### 4.2.3 VO 脱敏
身份证前 6 位是地区码可保留，中间 8 位打星号，后 4 位保留；手机号前 3 位保留、中间 4 位星号、后 4 位保留。

```java
private String desensitizeIdCard(String idCard) {
    if (idCard == null || idCard.length() < 10) return idCard;
    return idCard.substring(0, 6) + "********" + idCard.substring(idCard.length() - 4);
}

private String desensitizePhone(String phone) {
    if (phone == null || phone.length() != 11) return phone;
    return phone.substring(0, 3) + "****" + phone.substring(7);
}
```

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| @TableLogic | 声明字段为逻辑删除标志 |
| deleteBatchIds | MyBatis-Plus 批量删除方法 |
| VO 脱敏 | 隐私字段返给前端时打星号 |
| 幂等性 | 相同请求多次结果一致 |

### 4.4 示例代码/例题解析

**示例 1：完整的三个接口 + VO**
```java
// Controller
@DeleteMapping("/{ids}")
public Result<Void> delete(@PathVariable List<Long> ids) {
    memberService.deleteByIds(ids);
    return Result.success();
}

@GetMapping("/{id}")
public Result<MemberVO> getById(@PathVariable Long id) {
    return Result.success(memberService.getVOById(id));
}

@PutMapping("/status")
public Result<Void> updateStatus(@RequestBody @Valid MemberStatusDTO dto) {
    memberService.updateStatus(dto);
    return Result.success();
}
```

```java
// MemberVO
@Data
public class MemberVO {
    private Long id;
    private String name;
    private String gender;
    private Integer age;
    private String phone;          // 已脱敏
    private String idCard;         // 已脱敏
    private String address;
    private String emergencyContact;
    private String healthStatus;
    private String memberLevel;
    private Integer status;
    private LocalDateTime createTime;
}
```

```java
// MemberStatusDTO
@Data
public class MemberStatusDTO {
    @NotNull(message = "id 必填")
    private Long id;
    @NotNull(message = "状态必填")
    @Min(value = 0, message = "状态只能是 0 或 1")
    @Max(value = 1, message = "状态只能是 0 或 1")
    private Integer status;
}
```

```java
// Service 实现追加
@Override
public void deleteByIds(List<Long> ids) {
    if (CollectionUtils.isEmpty(ids)) return;
    memberMapper.deleteBatchIds(ids);
}

@Override
public MemberVO getVOById(Long id) {
    ElderMember m = memberMapper.selectById(id);
    if (m == null) return null;
    MemberVO vo = new MemberVO();
    BeanUtils.copyProperties(m, vo);
    vo.setIdCard(desensitizeIdCard(m.getIdCard()));
    vo.setPhone(desensitizePhone(m.getPhone()));
    return vo;
}

@Override
public void updateStatus(MemberStatusDTO dto) {
    ElderMember m = new ElderMember();
    m.setId(dto.getId());
    m.setStatus(dto.getStatus());
    memberMapper.updateById(m);
}
```

原理解释：`updateById` 只更新非 null 字段，所以我们只 set 了 id 和 status，其他字段不会被清空。这是 MyBatis-Plus 一个非常关键的默认行为。

### 4.5 课后练习
1. 【基础】用 Postman 删除 id=1 的会员，SQL 后台看到 UPDATE 语句。
2. 【综合】添加"根据手机号查会员"接口 `GET /api/members/byPhone/{phone}`。
3. 【挑战】设计"恢复已注销会员"接口 `PUT /api/members/restore/{id}`（提示：需绕开 @TableLogic 的默认查询）。

---

## 第 5 讲：前端会员列表页面

### 5.1 本讲要点
- 掌握 Element Plus 的 `el-table`、`el-pagination`、`el-form`
- 学会 `<script setup>` + `reactive` 组合式写法
- 掌握 `src/api/member.ts` 请求封装模式
- 完成"搜索栏 + 表格 + 分页"三段式页面
- 学会与后端 `pageNum/pageSize` 字段对齐

### 5.2 知识点详解

#### 5.2.1 目录约定
```
src/
├── api/
│   └── member.ts        # 所有会员相关请求方法
├── views/
│   └── member/
│       └── list.vue     # 页面
├── utils/
│   └── request.ts       # Day02 已封装
└── router/
    └── index.ts         # 加一条路由 /member/list
```

> 💡 **技巧：** "页面只管视图，请求方法独立收拢"是企业标准。当 Mock 后端时，只需要替换 `api/member.ts`，页面代码不动。

#### 5.2.2 el-pagination 关键属性

| 属性 | 说明 |
|------|------|
| v-model:current-page | 当前页，双向绑定 pageNum |
| v-model:page-size | 每页条数，双向绑定 pageSize |
| :total | 总条数 |
| @size-change / @current-change | 变化后触发查询 |

> ⚠️ **注意：** Element Plus 默认字段名是 `page/limit`，与我们的后端 `pageNum/pageSize` 不同 —— 靠 `v-model` 显式绑定就能解决。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| reactive | Vue3 组合式 API 声明响应式对象 |
| ref | 声明响应式基本类型/数组 |
| onMounted | 组件挂载后立刻执行 |
| v-loading | Element Plus 加载遮罩指令 |

### 5.4 示例代码/例题解析

**示例 1：完整的 api/member.ts（本讲部分）**
```typescript
import request from '@/utils/request'

export interface MemberPageParams {
  name?: string
  phone?: string
  memberLevel?: string
  pageNum: number
  pageSize: number
}

export const getMemberPage = (params: MemberPageParams) =>
  request.get('/api/members/page', { params })

export const getMemberById = (id: number | string) =>
  request.get(`/api/members/${id}`)

export const deleteMembers = (ids: (number | string)[]) =>
  request.delete(`/api/members/${ids.join(',')}`)
```

**示例 2：完整的 views/member/list.vue（搜索+表格+分页部分）**
```vue
<template>
  <div class="member-list">
    <el-form :inline="true" :model="query" class="search-bar">
      <el-form-item label="姓名">
        <el-input v-model="query.name" placeholder="请输入姓名" clearable />
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="query.phone" placeholder="请输入手机号" clearable />
      </el-form-item>
      <el-form-item label="等级">
        <el-select v-model="query.memberLevel" placeholder="请选择" clearable style="width:120px">
          <el-option label="金卡" value="GOLD" />
          <el-option label="银卡" value="SILVER" />
          <el-option label="普通" value="NORMAL" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="loadData">查询</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableData" v-loading="loading" @selection-change="onSelect" border stripe>
      <el-table-column type="selection" width="55" />
      <el-table-column prop="id" label="编号" width="80" />
      <el-table-column prop="name" label="姓名" width="120" />
      <el-table-column prop="gender" label="性别" width="80" />
      <el-table-column prop="age" label="年龄" width="80" />
      <el-table-column prop="phone" label="手机号" width="140" />
      <el-table-column prop="memberLevel" label="等级" width="100">
        <template #default="{ row }">
          {{ levelText(row.memberLevel) }}
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="180" />
    </el-table>

    <el-pagination
      class="pagination"
      v-model:current-page="query.pageNum"
      v-model:page-size="query.pageSize"
      :page-sizes="[10, 20, 50]"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      @size-change="loadData"
      @current-change="loadData"
    />
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue'
import { getMemberPage, type MemberPageParams } from '@/api/member'

const query = reactive<MemberPageParams>({
  name: '',
  phone: '',
  memberLevel: '',
  pageNum: 1,
  pageSize: 10
})
const tableData = ref<any[]>([])
const total = ref(0)
const loading = ref(false)
const selected = ref<any[]>([])

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await getMemberPage(query)
    tableData.value = res.data.rows
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

const resetQuery = () => {
  query.name = ''
  query.phone = ''
  query.memberLevel = ''
  query.pageNum = 1
  loadData()
}

const onSelect = (rows: any[]) => { selected.value = rows }

const levelText = (l: string) => ({ GOLD: '金卡', SILVER: '银卡', NORMAL: '普通' }[l] || l)

onMounted(loadData)
</script>

<style scoped>
.search-bar { margin-bottom: 16px; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

原理解释：`query` 用 `reactive` 声明，`el-form-item` 的 `v-model` 与之双向绑定；点击"查询"或翻页都会读取当前 `query` 发请求。这种"共享一个查询状态对象"的模式适用于所有 CRUD 页面。

### 5.5 课后练习
1. 【基础】把上面代码在自己项目里跑通，能看到 Day01 灌入的种子数据。
2. 【综合】给"状态"列加上 `el-tag`：启用绿色、停用灰色。
3. 【挑战】把搜索条件写入 localStorage，下次进页面自动还原。

---

## 第 6 讲：前端会员表单与联调

### 6.1 本讲要点
- 掌握 `el-dialog` 承载新增/修改表单的复用模式
- 学会 `el-form` 的 `rules` 校验规则
- 掌握批量删除（多选）与二次确认
- 掌握 `el-switch` 启停接口的调用
- 完成前后端 CRUD 全链路联调

### 6.2 知识点详解

#### 6.2.1 Dialog + Form 复用四要点
1. `v-model:visible` 控制 Dialog 显示。
2. `form` 对象在打开时初始化（新增置空、修改回显）。
3. 提交时根据 `form.id` 决定调 add 还是 update。
4. 提交成功后关闭 Dialog + 刷新列表。

#### 6.2.2 rules 校验规则（真实可用）
```typescript
const rules = {
  name: [
    { required: true, message: '姓名必填', trigger: 'blur' },
    { min: 2, max: 20, message: '姓名长度 2-20', trigger: 'blur' }
  ],
  phone: [
    { required: true, message: '手机号必填', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
  ],
  idCard: [
    { required: true, message: '身份证必填', trigger: 'blur' },
    { pattern: /^\d{17}[0-9Xx]$/, message: '身份证格式不正确', trigger: 'blur' }
  ],
  memberLevel: [{ required: true, message: '等级必填', trigger: 'change' }]
}
```

> 💡 **技巧：** 前端 rules 与后端 `@Pattern`、`@NotBlank`、`@Size` 规则保持一致，做到"双保险"。

#### 6.2.3 el-switch 启停回滚
```typescript
const onStatusChange = async (row: any, v: 0 | 1) => {
  try {
    await updateMemberStatus({ id: row.id, status: v })
    ElMessage.success(v === 1 ? '已启用' : '已停用')
  } catch {
    row.status = v === 1 ? 0 : 1  // 请求失败 UI 回滚
  }
}
```

> ⚠️ **注意：** `el-switch` 的 `v-model` 已经把值改到 row 上，如果请求失败必须手动回滚，否则 UI 与数据库不一致。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| ElMessageBox.confirm | Element Plus 二次确认弹窗 |
| formRef.validate() | 手动触发全表单校验 |
| :active-value / :inactive-value | el-switch 与后端字段对齐 |
| BeanUtils.copyProperties | 后端字段复制（前端可用 Object.assign） |

### 6.4 示例代码/例题解析

**示例 1：api/member.ts 完整版**
```typescript
import request from '@/utils/request'

export interface MemberPageParams {
  name?: string
  phone?: string
  memberLevel?: string
  pageNum: number
  pageSize: number
}

export const getMemberPage = (params: MemberPageParams) =>
  request.get('/api/members/page', { params })

export const getMemberById = (id: number | string) =>
  request.get(`/api/members/${id}`)

export const addMember = (data: any) =>
  request.post('/api/members', data)

export const updateMember = (data: any) =>
  request.put('/api/members', data)

export const deleteMembers = (ids: (number | string)[]) =>
  request.delete(`/api/members/${ids.join(',')}`)

export const updateMemberStatus = (data: { id: number; status: 0 | 1 }) =>
  request.put('/api/members/status', data)
```

**示例 2：list.vue 完整版（承接第 5 讲，增加 Dialog + 操作列 + 批量删除 + 启停）**
```vue
<template>
  <div class="member-list">
    <!-- 搜索栏 + 新增/批量删除 -->
    <el-form :inline="true" :model="query" class="search-bar">
      <el-form-item label="姓名">
        <el-input v-model="query.name" placeholder="请输入姓名" clearable />
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="query.phone" placeholder="请输入手机号" clearable />
      </el-form-item>
      <el-form-item label="等级">
        <el-select v-model="query.memberLevel" placeholder="请选择" clearable style="width:120px">
          <el-option label="金卡" value="GOLD" />
          <el-option label="银卡" value="SILVER" />
          <el-option label="普通" value="NORMAL" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="loadData">查询</el-button>
        <el-button @click="resetQuery">重置</el-button>
        <el-button type="success" @click="openAdd">新增</el-button>
        <el-button type="danger" :disabled="!selected.length" @click="onBatchDelete">批量删除</el-button>
      </el-form-item>
    </el-form>

    <!-- 表格 -->
    <el-table :data="tableData" v-loading="loading" @selection-change="onSelect" border stripe>
      <el-table-column type="selection" width="55" />
      <el-table-column prop="id" label="编号" width="80" />
      <el-table-column prop="name" label="姓名" width="120" />
      <el-table-column prop="gender" label="性别" width="80" />
      <el-table-column prop="age" label="年龄" width="80" />
      <el-table-column prop="phone" label="手机号" width="140" />
      <el-table-column prop="memberLevel" label="等级" width="100">
        <template #default="{ row }">{{ levelText(row.memberLevel) }}</template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-switch
            v-model="row.status"
            :active-value="1"
            :inactive-value="0"
            @change="(v: 0 | 1) => onStatusChange(row, v)"
          />
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="180" />
      <el-table-column label="操作" width="200" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row.id)">编辑</el-button>
          <el-button link type="danger" @click="onDelete([row.id])">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 分页 -->
    <el-pagination
      class="pagination"
      v-model:current-page="query.pageNum"
      v-model:page-size="query.pageSize"
      :page-sizes="[10, 20, 50]"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      @size-change="loadData"
      @current-change="loadData"
    />

    <!-- 新增/编辑 Dialog -->
    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑会员' : '新增会员'" width="600px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="90px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="性别" prop="gender">
          <el-select v-model="form.gender" style="width:100%">
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
          </el-select>
        </el-form-item>
        <el-form-item label="年龄" prop="age">
          <el-input-number v-model="form.age" :min="0" :max="120" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="身份证" prop="idCard">
          <el-input v-model="form.idCard" />
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="form.address" />
        </el-form-item>
        <el-form-item label="紧急联系人">
          <el-input v-model="form.emergencyContact" />
        </el-form-item>
        <el-form-item label="健康状况">
          <el-input v-model="form.healthStatus" />
        </el-form-item>
        <el-form-item label="会员等级" prop="memberLevel">
          <el-select v-model="form.memberLevel" style="width:100%">
            <el-option label="金卡" value="GOLD" />
            <el-option label="银卡" value="SILVER" />
            <el-option label="普通" value="NORMAL" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submit">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue'
import { ElMessage, ElMessageBox, type FormInstance } from 'element-plus'
import {
  getMemberPage, getMemberById, addMember, updateMember,
  deleteMembers, updateMemberStatus, type MemberPageParams
} from '@/api/member'

const query = reactive<MemberPageParams>({
  name: '', phone: '', memberLevel: '', pageNum: 1, pageSize: 10
})
const tableData = ref<any[]>([])
const total = ref(0)
const loading = ref(false)
const selected = ref<any[]>([])
const dialogVisible = ref(false)
const formRef = ref<FormInstance>()

const emptyForm = () => ({
  id: undefined as number | undefined,
  name: '', gender: '男', age: 60, phone: '', idCard: '',
  address: '', emergencyContact: '', healthStatus: '良好', memberLevel: 'NORMAL'
})
const form = reactive<any>(emptyForm())

const rules = {
  name: [
    { required: true, message: '姓名必填', trigger: 'blur' },
    { min: 2, max: 20, message: '姓名长度 2-20', trigger: 'blur' }
  ],
  gender: [{ required: true, message: '性别必填', trigger: 'change' }],
  age: [{ required: true, message: '年龄必填', trigger: 'blur' }],
  phone: [
    { required: true, message: '手机号必填', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
  ],
  idCard: [
    { required: true, message: '身份证必填', trigger: 'blur' },
    { pattern: /^\d{17}[0-9Xx]$/, message: '身份证格式不正确', trigger: 'blur' }
  ],
  memberLevel: [{ required: true, message: '等级必填', trigger: 'change' }]
}

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await getMemberPage(query)
    tableData.value = res.data.rows
    total.value = res.data.total
  } finally { loading.value = false }
}

const resetQuery = () => {
  query.name = ''; query.phone = ''; query.memberLevel = ''
  query.pageNum = 1; loadData()
}

const onSelect = (rows: any[]) => { selected.value = rows }
const levelText = (l: string) => ({ GOLD: '金卡', SILVER: '银卡', NORMAL: '普通' }[l] || l)

const openAdd = () => {
  Object.assign(form, emptyForm())
  dialogVisible.value = true
}

const openEdit = async (id: number) => {
  const res: any = await getMemberById(id)
  Object.assign(form, emptyForm(), res.data)
  dialogVisible.value = true
}

const submit = async () => {
  await formRef.value?.validate()
  if (form.id) {
    await updateMember(form)
    ElMessage.success('修改成功')
  } else {
    await addMember(form)
    ElMessage.success('新增成功')
  }
  dialogVisible.value = false
  loadData()
}

const onDelete = async (ids: number[]) => {
  await ElMessageBox.confirm('确定删除吗？', '提示', { type: 'warning' })
  await deleteMembers(ids)
  ElMessage.success('删除成功')
  loadData()
}

const onBatchDelete = () => onDelete(selected.value.map(r => r.id))

const onStatusChange = async (row: any, v: 0 | 1) => {
  try {
    await updateMemberStatus({ id: row.id, status: v })
    ElMessage.success(v === 1 ? '已启用' : '已停用')
  } catch {
    row.status = v === 1 ? 0 : 1
  }
}

onMounted(loadData)
</script>

<style scoped>
.search-bar { margin-bottom: 16px; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

原理解释：整个页面通过一个 `form` 对象承载新增/修改的双重职责，通过 `form.id` 是否有值来区分模式。这种"一份表单两种用途"是企业实战的黄金模式，比"分开写两个 Dialog"简洁得多。

### 6.5 课后练习
1. 【基础】完整跑通 CRUD 流程：新增一条、修改姓名、启用停用、批量删除。
2. 【综合】新增"详情"按钮，点击弹出只读 Dialog 显示脱敏后的身份证。
3. 【挑战】给表单加"实时唯一性校验"—— 手机号 blur 时立刻请求后端 `/api/members/checkPhone` 检查是否重复。

---

# 附录 A：Day03 接口清单

| 编号 | 接口名 | 方法 | URL | 请求参数 | 响应 |
|------|--------|------|-----|----------|------|
| ① | 分页查询 | GET | /api/members/page | query: name, phone, memberLevel, pageNum, pageSize | Result&lt;PageBean&lt;ElderMember&gt;&gt; |
| ② | 详情回显 | GET | /api/members/{id} | path: id | Result&lt;MemberVO&gt; |
| ③ | 新增 | POST | /api/members | body: MemberAddDTO | Result&lt;Void&gt; |
| ④ | 修改 | PUT | /api/members | body: MemberUpdateDTO | Result&lt;Void&gt; |
| ⑤ | 批量删除 | DELETE | /api/members/{ids} | path: 1,2,3 | Result&lt;Void&gt; |
| ⑥ | 启用/停用 | PUT | /api/members/status | body: {id, status} | Result&lt;Void&gt; |

**统一响应结构：**
```json
{ "code": 1, "msg": "success", "data": { ... } }
```
- code=1 成功，code=0 业务失败（校验、幂等冲突等）

---

# 附录 B：Postman 测试用例

> 建议在 Postman 里新建一个 Collection "智能养老-会员管理"，把以下 6 条用例存好，并在 Environment 里设 `baseUrl=http://localhost:8080`。

### 用例 1：分页查询
- 方法：GET
- URL：`{{baseUrl}}/api/members/page?name=张&pageNum=1&pageSize=10`
- 预期：`code=1`，`data.rows` 长度 ≤ 10。

### 用例 2：详情查询
- 方法：GET
- URL：`{{baseUrl}}/api/members/1`
- 预期：`data.idCard` 中间是 8 个星号；`data.phone` 中间是 4 个星号。

### 用例 3：新增（正常）
- 方法：POST
- URL：`{{baseUrl}}/api/members`
- Body（JSON）：
```json
{
  "name": "李建国",
  "gender": "男",
  "age": 72,
  "phone": "13900002222",
  "idCard": "410102195301011234",
  "address": "郑州市金水区花园路 88 号",
  "emergencyContact": "李小刚 13700003333",
  "healthStatus": "良好",
  "memberLevel": "SILVER"
}
```
- 预期：`code=1`，数据库多一条记录，`create_time`/`update_time` 有值。

### 用例 4：新增（校验失败）
- 方法：POST
- URL：`{{baseUrl}}/api/members`
- Body（JSON）：
```json
{
  "name": "王",
  "gender": "",
  "age": 200,
  "phone": "12345",
  "idCard": "410102",
  "memberLevel": ""
}
```
- 预期：`code=0`，`msg` 包含"姓名长度 2-20；性别必填；年龄非法；手机号格式不正确；身份证格式不正确；会员等级必填"。

### 用例 5：修改
- 方法：PUT
- URL：`{{baseUrl}}/api/members`
- Body（JSON）：
```json
{ "id": 1, "name": "张桂芳（改）", "memberLevel": "GOLD" }
```
- 预期：`code=1`，再查详情 name 变化，`update_time` 更新。

### 用例 6：批量删除
- 方法：DELETE
- URL：`{{baseUrl}}/api/members/2,3`
- 预期：`code=1`，数据库中 id=2,3 记录的 `deleted=1`，分页查询列表不再出现。

### 用例 7：启用/停用
- 方法：PUT
- URL：`{{baseUrl}}/api/members/status`
- Body（JSON）：
```json
{ "id": 1, "status": 0 }
```
- 预期：`code=1`，数据库 id=1 的 `status=0`；再切回 1 也应成功。

---

**Day03 总结：** 一天完成"接口约定 → 分页查询 → 新增/修改 → 删除/详情/启停 → 前端列表 → 前端表单联调"六个环节。所有会员的 CRUD 已经打通。这个骨架将在 Day04 客房、Day06 预约等模块中反复复用，确保学到的不是"某一次搞定"，而是"任意 CRUD 都能十分钟搭出来"。
