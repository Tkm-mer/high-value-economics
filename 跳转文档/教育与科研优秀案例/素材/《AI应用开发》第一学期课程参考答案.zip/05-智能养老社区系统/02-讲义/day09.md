# 《智能养老社区系统》- 学生讲义 - Day09：AOP 操作日志管理

**授课日：Day 09 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01 已建 `operation_log` 表；Day02 已有 SpringBoot 骨架 + `Result` 封装；Day03 已引入 `GlobalExceptionHandler`（本日补齐错误码体系）；Day04-Day08 各业务模块 Controller/Service 已就绪。**

---

## 第 1 讲：AOP 原理与 Spring AOP

### 1.1 本讲要点
- AOP 面向切面编程的诞生动机——把\"横切关注点\"从业务代码抽出来
- AOP 五术语：JoinPoint / Pointcut / Advice / Aspect / Weaving
- Spring AOP 基于动态代理：JDK 代理 vs CGLIB
- 五种通知：`@Before` / `@After` / `@AfterReturning` / `@AfterThrowing` / `@Around`
- 切点表达式：`execution(...)` 与 `@annotation(...)`

### 1.2 知识点详解

#### 1.2.1 OOP 与 AOP 的分工

OOP 沿业务纵向分层，AOP 沿关注点横向切片。日志、事务、权限、监控、限流——这些每个业务方法都需要的\"周边能力\"，不属于业务本身，就叫**横切关注点**。

| 维度 | OOP 视角 | AOP 视角 |
|------|---------|---------|
| 会员管理 | MemberController → Service → Mapper | 日志/权限/事务 |
| 客房管理 | RoomController → Service → Mapper | 日志/权限/事务 |
| 预约管理 | ReservationController → Service → Mapper | 日志/权限/事务 |

右侧一列在每个业务里**几乎一模一样**——这就是 AOP 抽取的对象。

#### 1.2.2 五大术语

| 术语 | 英文 | 通俗解释 | 本项目对应 |
|------|------|---------|-----------|
| 连接点 | JoinPoint | 一个具体的方法调用位置 | 每次 Controller 方法被调用 |
| 切点 | Pointcut | 描述\"我要拦哪些方法\"的规则 | 打了 `@OperationLog` 的方法 |
| 通知 | Advice | 在切点匹配时执行的动作 | 记录一条操作日志 |
| 切面 | Aspect | 切点+通知的封装类 | `OperationLogAspect` |
| 织入 | Weaving | 把 Advice 编入目标方法的过程 | Spring 启动时用动态代理完成 |

> **技巧：** 记忆口诀\"点点通面织\" —— **点**(JoinPoint) 、**点**(Pointcut) 、**通**(Advice) 、**面**(Aspect) 、**织**(Weaving) 。

#### 1.2.3 Spring AOP 的两种代理

Spring 不改字节码，而是在容器启动时给 Bean **生成代理对象**：

| 类型 | 触发条件 | 特点 | 备注 |
|------|---------|------|------|
| JDK 动态代理 | 目标类实现了接口 | 只能代理接口方法 | 反射调用，快 |
| CGLIB 代理 | 目标类无接口 | 生成子类；`final` 方法不能被代理 | SpringBoot 2.x 起默认全用 CGLIB |

> **注意：** `private` / `static` / `final` 方法都**不能**被 Spring AOP 代理，因为子类无法覆写。日志切面别切私有方法。

#### 1.2.4 五种通知

| 通知 | 触发时机 | 能做什么 |
|------|---------|---------|
| `@Before` | 方法执行前 | 记录\"开始\"、参数校验 |
| `@After` | 方法执行后（无论成败） | 清理资源 |
| `@AfterReturning` | 方法正常返回后 | 记录返回值 |
| `@AfterThrowing` | 方法抛异常后 | 记录异常 |
| `@Around` ★ | 方法\"包围\" | 决定是否执行、修改参数、修改返回值、包 try-catch |

> **技巧：** 操作日志、耗时统计、权限校验、限流几乎都用 `@Around`——因为它\"啥都能干\"。

#### 1.2.5 切点表达式

**方法级匹配**：`execution(修饰符? 返回类型 包.类.方法(参数))`
```
execution(* com.itcast.smart_elder.controller..*.*(..))
```
- `*` 任意返回类型
- `com.itcast.smart_elder.controller..` 该包及所有子包
- `*.*` 任意类的任意方法
- `(..)` 任意参数

**注解级匹配**（推荐）：`@annotation(全限定注解名)`
```
@annotation(com.itcast.smart_elder.annotation.OperationLog)
```
只切贴了注解的方法，粒度最精细。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 横切关注点 | 日志/事务/权限等在每个业务都出现的\"周边能力\" |
| 动态代理 | Spring AOP 的实现基石，运行期生成代理对象 |
| `@Around` | 通知里的\"全能选手\" |
| `@annotation(...)` | 只切贴了指定注解的方法 |

### 1.4 示例代码/例题解析

**示例 1：最简耗时统计切面**
```java
@Aspect
@Component
@Slf4j
public class TimingAspect {
    @Around(\"execution(* com.itcast.smart_elder.service..*.*(..))\")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        try {
            return pjp.proceed();
        } finally {
            log.info(\"{} cost {}ms\", pjp.getSignature().toShortString(),
                    System.currentTimeMillis() - start);
        }
    }
}
```
**原理解释：** `pjp.proceed()` 才是真正调用目标方法；`try/finally` 保证异常也能记录耗时。

### 1.5 课后练习
1. 【基础】用一句 `execution` 表达式，只切 `controller` 包下方法名以 `save` `update` `delete` 开头的方法。
2. 【综合】用 `@annotation` 切点写一个 `LogTimeAspect`，只有贴了自定义 `@LogTime` 注解的方法才被切。
3. 【挑战】给 `TimingAspect` 加一个字段 `slowThresholdMs=1000`，只有超过该阈值才打 `warn` 日志。

---

## 第 2 讲：自定义注解 @OperationLog

### 2.1 本讲要点
- Java 注解本质：一个标记，本身不做事
- 元注解：`@Target` / `@Retention` / `@Documented`
- 保留策略三阶段：SOURCE / CLASS / RUNTIME
- 字段设计：`module` / `operation` / `saveParams` / `saveResult`
- 注解 + AOP = 精细切点

### 2.2 知识点详解

#### 2.2.1 元注解一览

| 元注解 | 作用 | 常用取值 |
|--------|------|---------|
| `@Target` | 注解能贴在哪 | METHOD / TYPE / FIELD / PARAMETER |
| `@Retention` | 注解保留到什么阶段 | SOURCE / CLASS / RUNTIME |
| `@Documented` | 是否进入 Javadoc | 一般加上 |
| `@Inherited` | 子类是否继承 | 谨慎使用 |
| `@Repeatable` | 是否可重复贴 | JDK 8+ |

#### 2.2.2 Retention 三阶段对比

| 阶段 | 存活范围 | 反射可读 | 例子 |
|------|---------|--------|------|
| SOURCE | 仅 .java | 否 | `@Override` |
| CLASS | 编译进 .class | 否（默认） | Lombok 的部分注解 |
| RUNTIME | 运行期 | ✅ | Spring 的 `@Autowired` |

> **注意：** AOP 切面在运行期通过反射读注解，必须 **RUNTIME**。写错就是\"注解没生效\"这种常见的\"静默失败\"。

#### 2.2.3 @OperationLog 字段设计

| 字段 | 类型 | 默认值 | 用途 |
|------|------|--------|------|
| module | String | \"\" | 业务模块名 |
| operation | String | \"\" | 具体动作 |
| saveParams | boolean | true | 是否记录入参 |
| saveResult | boolean | false | 是否记录返回值 |

> **技巧：** `saveResult` 默认 false 是为了避免\"分页 100 条数据\"这种大响应把日志表撑爆。需要时手动开。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 注解 | 一个带标记的接口，自己不做事 |
| 元注解 | 定义\"注解的行为边界\" |
| RUNTIME | 反射可读的唯一保留策略 |
| default | 注解字段可提供默认值 |

### 2.4 示例代码/例题解析

**示例 1：@OperationLog 完整定义**
```java
package com.itcast.smart_elder.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperationLog {
    String module() default \"\";
    String operation() default \"\";
    boolean saveParams() default true;
    boolean saveResult() default false;
}
```

**示例 2：在 Controller 上使用**
```java
@RestController
@RequestMapping(\"/api/members\")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @OperationLog(module = \"会员管理\", operation = \"新增\")
    @PostMapping
    public Result<Void> save(@RequestBody MemberDTO dto) {
        memberService.save(dto);
        return Result.success();
    }

    @OperationLog(module = \"会员管理\", operation = \"删除\")
    @DeleteMapping(\"/{id}\")
    public Result<Void> delete(@PathVariable Long id) {
        memberService.delete(id);
        return Result.success();
    }
}
```
**原理解释：** 贴注解只是\"打标记\"，运行项目本身**不会**打日志。真正干活的切面在下一讲。

### 2.5 课后练习
1. 【基础】给 Day04 客房管理的 4 个写接口贴上 `@OperationLog`，`module=\"客房管理\"`。
2. 【综合】给 `@OperationLog` 追加一个字段 `slowThresholdMs() default 0`（大于 0 时表示只有超过阈值才落库）。
3. 【挑战】允许 `@OperationLog` 贴在 **类**上，表示类下所有方法都自动记录，`module` 从类注解继承。

---

## 第 3 讲：环绕通知与参数解析

### 3.1 本讲要点
- 切面骨架 6 步：切点匹配 → 计时 → 反射取注解 → 调 proceed → 组装实体 → 记录
- `ProceedingJoinPoint` 用法与 `MethodSignature` 反射
- Jackson 序列化参数，过滤 `HttpServletRequest` / `MultipartFile`
- 从请求头 `X-User-Id` 简化获取当前用户
- 从 `X-Forwarded-For` / `X-Real-IP` / `RemoteAddr` 获取真实 IP

### 3.2 知识点详解

#### 3.2.1 切面骨架

```java
@Around(\"@annotation(operationLog)\")
public Object around(ProceedingJoinPoint pjp, OperationLog operationLog) throws Throwable {
    long start = System.currentTimeMillis();
    Throwable throwable = null;
    Object result = null;
    try {
        result = pjp.proceed();     // 执行业务方法
        return result;
    } catch (Throwable e) {
        throwable = e;
        throw e;
    } finally {
        long cost = System.currentTimeMillis() - start;
        try {
            OperationLogEntity entity = buildLog(pjp, operationLog, result, throwable, cost);
            operationLogService.saveAsync(entity);
        } catch (Exception ignore) {
            // 日志失败不能影响主业务
        }
    }
}
```

> **技巧：** `try/catch/finally` 三段结构必背——**成功走 try，异常走 catch 但要 rethrow，无论成败 finally 都要打日志**。

#### 3.2.2 反射取注解三行套路

```java
MethodSignature signature = (MethodSignature) pjp.getSignature();
Method method = signature.getMethod();
OperationLog opLog = method.getAnnotation(OperationLog.class);
```

#### 3.2.3 参数序列化的过滤

`pjp.getArgs()` 返回 `Object[]`，直接 Jackson 序列化会踩坑：

| 危险类型 | 表现 | 处理 |
|---------|------|------|
| `HttpServletRequest` / `Response` | 循环引用，栈溢出 | 过滤跳过 |
| `MultipartFile` | 二进制流，序列化失败 | 只记文件名 |
| `byte[]` | 巨大 | 记长度 |
| `BindingResult` | 反引用 target | 过滤跳过 |

> **注意：** 千万不要直接 `objectMapper.writeValueAsString(pjp.getArgs())`，第一次遇到文件上传接口就 GG。

#### 3.2.4 当前用户 ID：教学简化方案

本课程约定：**前端所有请求都在 header 里带 `X-User-Id: 1`**。切面直接读，不做鉴权。生产项目会用 JWT + Interceptor 解析放到 `ThreadLocal`，Day10/Day12 补充。

#### 3.2.5 客户端真实 IP

```java
String ip = req.getHeader(\"X-Forwarded-For\");
if (ip == null || ip.isEmpty() || \"unknown\".equalsIgnoreCase(ip))
    ip = req.getHeader(\"X-Real-IP\");
if (ip == null || ip.isEmpty()) ip = req.getRemoteAddr();
if (ip != null && ip.contains(\",\")) ip = ip.split(\",\")[0].trim();
```

**取值顺序**：`X-Forwarded-For` > `X-Real-IP` > `getRemoteAddr()`。前两个都是 Nginx/代理层写入的\"真实客户端 IP\"。

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| `ProceedingJoinPoint` | `@Around` 专属，能 `proceed()` 决定是否放行 |
| `MethodSignature` | 从 JoinPoint 拿到 `Method` 对象，进而反射 |
| try/catch/finally | 保证耗时统计与日志记录 |
| 参数过滤 | 避免序列化炸掉 |

### 3.4 示例代码/例题解析

**示例：接口清单**

| 方法 | URL | 功能 |
|------|-----|------|
| GET | `/api/logs/page` | 分页查询日志 |
| GET | `/api/logs/{id}` | 单条详情 |

**示例 1：OperationLog 实体（映射 `operation_log` 表）**
```java
@Data
@TableName(\"operation_log\")
public class OperationLogEntity {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private String module;
    private String operation;
    private String method;       // Controller.methodName
    private String params;       // 入参 JSON
    private String result;       // 返回值 JSON
    private String ip;
    private Long costTime;       // ms
    private LocalDateTime createTime;
}
```

**示例 2：完整切面**
```java
package com.itcast.smart_elder.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itcast.smart_elder.annotation.OperationLog;
import com.itcast.smart_elder.entity.OperationLogEntity;
import com.itcast.smart_elder.service.OperationLogService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Aspect
@Component
@Slf4j
public class OperationLogAspect {

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private OperationLogService operationLogService;

    @Around(\"@annotation(operationLog)\")
    public Object around(ProceedingJoinPoint pjp, OperationLog operationLog) throws Throwable {
        long start = System.currentTimeMillis();
        Throwable throwable = null;
        Object result = null;
        try {
            result = pjp.proceed();
            return result;
        } catch (Throwable e) {
            throwable = e;
            throw e;
        } finally {
            long cost = System.currentTimeMillis() - start;
            try {
                OperationLogEntity entity = buildLog(pjp, operationLog, result, throwable, cost);
                operationLogService.saveAsync(entity);
            } catch (Exception ignore) {
                log.warn(\"记录操作日志失败: {}\", ignore.getMessage());
            }
        }
    }

    private OperationLogEntity buildLog(ProceedingJoinPoint pjp, OperationLog op,
                                        Object result, Throwable throwable, long cost) throws Exception {
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();

        OperationLogEntity entity = new OperationLogEntity();
        entity.setModule(op.module());
        entity.setOperation(op.operation());
        entity.setMethod(method.getDeclaringClass().getSimpleName() + \".\" + method.getName());
        entity.setCostTime(cost);
        entity.setCreateTime(LocalDateTime.now());

        if (op.saveParams())
            entity.setParams(serializeArgs(pjp.getArgs()));

        if (op.saveResult() && throwable == null)
            entity.setResult(safeSerialize(result));

        if (throwable != null)
            entity.setResult(\"Exception: \" + throwable.getMessage());

        HttpServletRequest request = getRequest();
        if (request != null) {
            String uid = request.getHeader(\"X-User-Id\");
            if (uid != null && !uid.isEmpty()) {
                try { entity.setUserId(Long.parseLong(uid)); } catch (Exception ignored) {}
            }
            entity.setIp(getClientIp(request));
        }
        return entity;
    }

    private String serializeArgs(Object[] args) {
        if (args == null || args.length == 0) return \"[]\";
        List<Object> safe = new ArrayList<>();
        for (Object a : args) {
            if (a == null) { safe.add(null); continue; }
            if (a instanceof HttpServletRequest) continue;
            if (a instanceof HttpServletResponse) continue;
            if (a instanceof MultipartFile) {
                safe.add(\"[MultipartFile:\" + ((MultipartFile) a).getOriginalFilename() + \"]\");
                continue;
            }
            if (a instanceof byte[]) { safe.add(\"[bytes:\" + ((byte[]) a).length + \"]\"); continue; }
            safe.add(a);
        }
        return safeSerialize(safe);
    }

    private String safeSerialize(Object obj) {
        try {
            String json = objectMapper.writeValueAsString(obj);
            return json.length() > 2000 ? json.substring(0, 2000) + \"...(truncated)\" : json;
        } catch (Exception e) {
            return \"[serialize error]\";
        }
    }

    private HttpServletRequest getRequest() {
        try {
            ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            return attrs != null ? attrs.getRequest() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String getClientIp(HttpServletRequest req) {
        String ip = req.getHeader(\"X-Forwarded-For\");
        if (ip == null || ip.isEmpty() || \"unknown\".equalsIgnoreCase(ip)) ip = req.getHeader(\"X-Real-IP\");
        if (ip == null || ip.isEmpty()) ip = req.getRemoteAddr();
        if (ip != null && ip.contains(\",\")) ip = ip.split(\",\")[0].trim();
        return ip;
    }
}
```

### 3.5 课后练习
1. 【基础】把切面的 `saveResult=true` 且返回是 `Result` 时，只保留 `code` 和 `msg` 字段（去掉 data）。
2. 【综合】在实体里增加 `requestUrl` 字段，切面里从 request 取 URI 填入。
3. 【挑战】给切面加\"敏感字段脱敏\"能力，如果参数 JSON 里包含 `password`、`idCard`，替换为 `***`。

---

## 第 4 讲：日志异步落库

### 4.1 本讲要点
- 异步落库的动机：不阻塞主业务、不增加接口 RT
- `@EnableAsync` 一次开启，`@Async` 逐个方法启用
- 生产必须自定义 `ThreadPoolTaskExecutor` 六参数
- 拒绝策略选 `CallerRunsPolicy`——日志不丢、主业务降级
- 自调用陷阱：`this.saveAsync()` 走不了代理
- 日志失败必须 `try/catch` 吞掉，不能影响主业务
- 拓展阅读：Spring Event 是解耦更优雅的替代方案

### 4.2 知识点详解

#### 4.2.1 两把钥匙

| 注解 | 位置 | 作用 |
|------|------|------|
| `@EnableAsync` | 启动类或任一 `@Configuration` | 打开异步能力 |
| `@Async(\"beanName\")` | 方法上 | 该方法被扔到指定线程池 |

#### 4.2.2 默认线程池的坑

不指定线程池时，SpringBoot 使用 `SimpleAsyncTaskExecutor` —— **每次任务 new 一个新线程，无上限**。并发一高，服务器很快 OOM 或 CPU 打满。

> **注意：** 生产**一定要**自定义 `ThreadPoolTaskExecutor`，并在 `@Async` 里显式指定 bean name，避免不小心用了默认执行器。

#### 4.2.3 线程池六参数经验值

| 参数 | 值 | 依据 |
|------|-----|------|
| corePoolSize | 2 | 日志频率不高，常驻不需多 |
| maxPoolSize | 10 | 突发流量最多扩到 10 个 |
| queueCapacity | 500 | 缓冲 500 条日志够用 |
| keepAliveSeconds | 60 | 空闲线程 1 分钟回收 |
| threadNamePrefix | `elder-log-` | 排查问题一眼识别 |
| rejectPolicy | `CallerRunsPolicy` | 队列满时降级到主线程执行 |

#### 4.2.4 四种拒绝策略对比

| 策略 | 行为 | 是否丢日志 | 是否拖慢主业务 |
|------|------|-----------|----------------|
| AbortPolicy（默认） | 抛异常 | ❌ 日志抛出 | 抛给上层 |
| CallerRunsPolicy ★ | 提交者线程自己执行 | 不丢 | 略拖，起背压 |
| DiscardPolicy | 静默丢弃 | 丢 | 不影响 |
| DiscardOldestPolicy | 丢队头最老任务 | 丢 | 不影响 |

**日志场景推荐 `CallerRunsPolicy`**：不丢日志，让主线程\"顺便\"跑一条起到降级。

#### 4.2.5 自调用陷阱

```java
@Service
public class FooService {
    public void a() { this.b(); }         // ❌ this 不是代理，@Async 失效
    @Async public void b() { ... }
}
```

**破解办法**：把异步方法放到**另一个 Bean**里调用（比如切面调用 `OperationLogService.saveAsync`），走的是容器代理，自然生效。

#### 4.2.6 日志失败不影响主业务

日志入库如果 DB 挂掉，`insert` 会抛异常。这时**不能让日志把主业务拖下水**。所以在 `saveAsync` 方法内部 `try/catch` 吞异常，只写 `log.error`。

> **技巧：** \"降级为可观测\"—— 主业务永远优先，日志缺一条可以补，主业务失败要退款。

#### 4.2.7 拓展阅读：Spring Event 方案

另一种做法：切面 `applicationContext.publishEvent(new OperationLogEvent(entity))`，然后有一个 `@Async @EventListener` 消费。优点：**业务和日志更解耦**，切面不用注入 Service。缺点：初学阶段增加认知负担。**本课程主写线程池方案**，此思路留作 Day10 系统优化的自选阅读。

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| `@EnableAsync` | 异步总开关 |
| `@Async(\"logTaskExecutor\")` | 走指定线程池 |
| `CallerRunsPolicy` | 队列满时降级到调用线程 |
| 自调用 | this 不是代理，@Async 失效 |

### 4.4 示例代码/例题解析

**示例 1：AsyncConfig**
```java
package com.itcast.smart_elder.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
@Slf4j
public class AsyncConfig {

    @Bean(\"logTaskExecutor\")
    public Executor logTaskExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(2);
        exec.setMaxPoolSize(10);
        exec.setQueueCapacity(500);
        exec.setKeepAliveSeconds(60);
        exec.setThreadNamePrefix(\"elder-log-\");
        exec.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        exec.setWaitForTasksToCompleteOnShutdown(true);
        exec.setAwaitTerminationSeconds(30);
        exec.initialize();
        log.info(\"日志异步线程池就绪\");
        return exec;
    }
}
```

**示例 2：OperationLogService + Mapper**
```java
// OperationLogMapper.java
@Mapper
public interface OperationLogMapper extends BaseMapper<OperationLogEntity> {}

// OperationLogService.java
@Service
@Slf4j
public class OperationLogService {

    @Autowired
    private OperationLogMapper operationLogMapper;

    @Async(\"logTaskExecutor\")
    public void saveAsync(OperationLogEntity entity) {
        try {
            operationLogMapper.insert(entity);
        } catch (Exception e) {
            log.error(\"操作日志入库失败: {}\", e.getMessage(), e);
        }
    }

    // 供第 6 讲的查询接口使用
    public PageBean<OperationLogEntity> pageQuery(Integer page, Integer size, String module,
                                                  Long userId, LocalDateTime start, LocalDateTime end) {
        Page<OperationLogEntity> p = new Page<>(page, size);
        LambdaQueryWrapper<OperationLogEntity> qw = new LambdaQueryWrapper<>();
        if (module != null && !module.isEmpty()) qw.eq(OperationLogEntity::getModule, module);
        if (userId != null) qw.eq(OperationLogEntity::getUserId, userId);
        if (start != null) qw.ge(OperationLogEntity::getCreateTime, start);
        if (end != null) qw.le(OperationLogEntity::getCreateTime, end);
        qw.orderByDesc(OperationLogEntity::getCreateTime);
        IPage<OperationLogEntity> r = operationLogMapper.selectPage(p, qw);
        PageBean<OperationLogEntity> pb = new PageBean<>();
        pb.setTotal(r.getTotal());
        pb.setRows(r.getRecords());
        return pb;
    }

    public OperationLogEntity getById(Long id) {
        OperationLogEntity e = operationLogMapper.selectById(id);
        if (e == null) throw new BusinessException(ErrorCode.OPERATION_LOG_NOT_FOUND);
        return e;
    }
}
```

**原理解释：** `@Async(\"logTaskExecutor\")` 由 Spring 代理在方法调用时把任务交给我们自定义的线程池，主线程立即返回。

### 4.5 课后练习
1. 【基础】把线程池前缀改成 `elder-oplog-`，重启后从控制台确认线程名。
2. 【综合】临时把 `queueCapacity=2` `maxPoolSize=2`，for 循环 20 次调接口，观察哪些日志由 `http-nio-...` 主线程记录（`CallerRunsPolicy` 生效证据）。
3. 【挑战】用 Spring Event 方案改写：定义 `OperationLogEvent`，切面 `publishEvent`，用 `@Async @EventListener` 消费。对比两种方案代码耦合度。

---

## 第 5 讲：全局异常处理 + 统一响应

### 5.1 本讲要点
- 错误码分段：1xxx 参数 / 2xxx 权限 / 3xxx 业务 / 4xxx 数据 / 5xxx 系统
- `BusinessException` 使用姿势：Service 主动抛，Controller 不 catch
- `@Valid` 校验失败异常：`MethodArgumentNotValidException`
- `@Validated` 单参异常：`ConstraintViolationException`
- 系统兜底：`Exception.class` fallback 必须放最后

### 5.2 知识点详解

#### 5.2.1 错误码分段规则

| 段 | 范围 | 大类 | 举例 |
|----|------|------|------|
| 0 | 0000 | 成功 | 0000 |
| 1xxx | 1001-1999 | 客户端参数 | 1001 参数校验失败 |
| 2xxx | 2001-2999 | 认证/授权 | 2001 未登录 |
| 3xxx | 3001-3999 | 业务规则 | 3001 会员不存在 |
| 4xxx | 4001-4999 | 数据/资源 | 4001 唯一约束冲突 |
| 5xxx | 5000-5999 | 系统级 | 5000 内部错误 |

> **技巧：** 一看 code 前缀就知大类，团队沟通有共同语言。

#### 5.2.2 抛异常还是 return null？

| 场景 | 建议做法 |
|------|---------|
| 参数校验失败 | 用 `@Valid`，交给全局处理器 |
| 会员/客房不存在 | 抛 `BusinessException(MEMBER_NOT_FOUND)` |
| 权限不足 | 抛 `BusinessException(FORBIDDEN)` |
| DB 唯一约束冲突 | try/catch `DuplicateKeyException` 转 4001 |
| 未知异常 | 让它冒到 `Exception.class` fallback |

> **注意：** **Controller 里不要 try/catch**！让异常冒到 `@RestControllerAdvice` 统一响应，避免每个 Controller 都写一堆样板。

#### 5.2.3 三种校验异常

| 异常 | 场景 |
|------|------|
| `MethodArgumentNotValidException` | `@RequestBody DTO` 上 `@Valid` 校验失败 |
| `BindException` | `@ModelAttribute` 表单绑定校验失败 |
| `ConstraintViolationException` | `@Validated` 单参数（如 `@RequestParam @Min(1) Integer page`）校验失败 |

三个都要覆盖，否则某种参数校验会\"漏网\"。

#### 5.2.4 顺序陷阱

```java
@ExceptionHandler(Exception.class)         // ← 放最前面就完蛋，业务异常也被它吃掉
@ExceptionHandler(BusinessException.class)
```

> **注意：** Spring 匹配最\"具体\"的 handler，但也依赖类继承层次。习惯把 `Exception` 放最后，眼睛看着放心。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| ErrorCode | 用 enum 承载 code+msg |
| BusinessException | 承载业务异常的运行时异常 |
| `@RestControllerAdvice` | 全局异常处理器，自带 `@ResponseBody` |
| fallback | 兜底 handler 放最后，避免 500 直接抛前端 |

### 5.4 示例代码/例题解析

**示例 1：ErrorCode**
```java
package com.itcast.smart_elder.common;

import lombok.Getter;

@Getter
public enum ErrorCode {
    SUCCESS(0, \"成功\"),

    PARAM_INVALID(1001, \"参数校验失败\"),
    PARAM_MISSING(1002, \"参数缺失\"),
    PARAM_TYPE_MISMATCH(1003, \"参数类型错误\"),

    UNAUTHORIZED(2001, \"未登录或登录已过期\"),
    FORBIDDEN(2003, \"无权限访问\"),

    MEMBER_NOT_FOUND(3001, \"会员不存在\"),
    ROOM_NOT_FOUND(3002, \"客房不存在\"),
    ROOM_OCCUPIED(3003, \"客房已被占用\"),
    RESERVATION_NOT_FOUND(3004, \"预约单不存在\"),
    RESERVATION_STATUS_ILLEGAL(3005, \"预约状态不合法\"),
    OPERATION_LOG_NOT_FOUND(3006, \"操作日志不存在\"),

    DATA_DUPLICATE(4001, \"数据重复，请检查唯一字段\"),
    DATA_NOT_FOUND(4002, \"数据不存在\"),

    SYSTEM_ERROR(5000, \"服务器内部错误，请稍后重试\");

    private final int code;
    private final String msg;

    ErrorCode(int code, String msg) { this.code = code; this.msg = msg; }
}
```

**示例 2：BusinessException**
```java
@Getter
public class BusinessException extends RuntimeException {
    private final int code;
    public BusinessException(ErrorCode ec) { super(ec.getMsg()); this.code = ec.getCode(); }
    public BusinessException(ErrorCode ec, String msg) { super(msg); this.code = ec.getCode(); }
}
```

**示例 3：GlobalExceptionHandler 全代码**
```java
package com.itcast.smart_elder.handler;

import com.itcast.smart_elder.common.BusinessException;
import com.itcast.smart_elder.common.ErrorCode;
import com.itcast.smart_elder.common.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBusiness(BusinessException e) {
        log.warn(\"业务异常: code={} msg={}\", e.getCode(), e.getMessage());
        return Result.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<?> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + \" \" + fe.getDefaultMessage())
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    @ExceptionHandler(BindException.class)
    public Result<?> handleBind(BindException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + \" \" + fe.getDefaultMessage())
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public Result<?> handleConstraint(ConstraintViolationException e) {
        String msg = e.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    @ExceptionHandler(Exception.class)
    public Result<?> handleAny(Exception e) {
        log.error(\"未预期异常: \", e);
        return Result.error(ErrorCode.SYSTEM_ERROR);
    }
}
```

**示例 4：Service 抛业务异常**
```java
public MemberVO getById(Long id) {
    Member m = memberMapper.selectById(id);
    if (m == null) throw new BusinessException(ErrorCode.MEMBER_NOT_FOUND);
    return convert(m);
}
```

调用 `GET /api/members/9999` → 拿到 `{code:3001, msg:\"会员不存在\", data:null}`，HTTP 200。

### 5.5 课后练习
1. 【基础】新增错误码 `ROOM_STATUS_ILLEGAL(3007, \"客房状态不合法\")`。
2. 【综合】改造 `handleAny`：把请求 URL 也 log 出来（`HttpServletRequest.getRequestURI()`）。
3. 【挑战】把错误消息国际化：`ErrorCode` 里加 `msgEn` 字段，根据 `Accept-Language` 请求头切换。

---

## 第 6 讲：前端日志查询页面 + 联调

### 6.1 本讲要点
- 后端分页接口：`/api/logs/page` 参数 page/size/module/userId/时间区间
- Vue3 组合式 API：`ref` + `reactive` + `onMounted`
- `el-table` 展开行：`<el-table-column type=\"expand\">`
- `el-date-picker` 双向绑定时间区间
- CSV 前端导出三部曲：拼字符串 → Blob → createObjectURL → `a.download`
- UTF-8 BOM：`\\uFEFF` 让 Excel 正确识别中文

### 6.2 知识点详解

#### 6.2.1 后端接口清单

| 方法 | URL | 参数 | 返回 |
|------|-----|------|------|
| GET | `/api/logs/page` | page,size,module,userId,startTime,endTime | `PageBean<OperationLogEntity>` |
| GET | `/api/logs/{id}` | id | `OperationLogEntity` |

`startTime` / `endTime` 使用 `@DateTimeFormat(pattern=\"yyyy-MM-dd HH:mm:ss\")` 接收 URL 上的字符串。

#### 6.2.2 前端页面结构

```
┌───────────────────────────────────────────┐
│  筛选表单                                   │
│  [时间区间] [模块] [用户ID] 查询 重置 导出   │
├───────────────────────────────────────────┤
│  数据表格                                   │
│  ▶ ID 用户 模块 操作 方法 IP 耗时 时间      │
│  展开行显示完整 params/result              │
├───────────────────────────────────────────┤
│  分页                                       │
└───────────────────────────────────────────┘
```

#### 6.2.3 CSV 导出三步曲

**步 1：转义**
```typescript
const csvEscape = (v: any) => {
  if (v == null) return ''
  const s = String(v)
  return /[\",\\n\\r]/.test(s) ? '\"' + s.replace(/\"/g, '\"\"') + '\"' : s
}
```

**步 2：拼字符串**
```typescript
const lines = [header.join(',')]
rows.forEach(r => lines.push([r.id, r.module, ...].map(csvEscape).join(',')))
```

**步 3：Blob 下载**
```typescript
const blob = new Blob(['\\uFEFF' + lines.join('\\n')], { type: 'text/csv;charset=utf-8' })
const url = URL.createObjectURL(blob)
const a = document.createElement('a')
a.href = url
a.download = 'operation_log_' + Date.now() + '.csv'
a.click()
URL.revokeObjectURL(url)
```

> **技巧：** 加 `\\uFEFF` 是 UTF-8 BOM，让 Excel/WPS 正确识别中文，不加就乱码。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 展开行 | `type=\"expand\"` 的列，`<template #default>` 定义内容 |
| Blob | 前端\"内存文件\" |
| BOM | UTF-8 头 3 字节 `\\uFEFF`，Excel 识别的关键 |
| CSV 转义 | 含逗号/引号/换行的值用双引号包裹，内部引号变 `\"\"` |

### 6.4 示例代码/例题解析

**示例 1：LogController**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.entity.OperationLogEntity;
import com.itcast.smart_elder.service.OperationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping(\"/api/logs\")
public class LogController {

    @Autowired
    private OperationLogService operationLogService;

    @GetMapping(\"/page\")
    public Result<PageBean<OperationLogEntity>> page(
            @RequestParam(defaultValue = \"1\") Integer page,
            @RequestParam(defaultValue = \"20\") Integer size,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false)
            @DateTimeFormat(pattern = \"yyyy-MM-dd HH:mm:ss\") LocalDateTime startTime,
            @RequestParam(required = false)
            @DateTimeFormat(pattern = \"yyyy-MM-dd HH:mm:ss\") LocalDateTime endTime
    ) {
        return Result.success(operationLogService.pageQuery(page, size, module, userId, startTime, endTime));
    }

    @GetMapping(\"/{id}\")
    public Result<OperationLogEntity> detail(@PathVariable Long id) {
        return Result.success(operationLogService.getById(id));
    }
}
```

**示例 2：api/log.ts**
```typescript
import request from '@/utils/request'

export interface LogQuery {
  page: number
  size: number
  module?: string
  userId?: number
  startTime?: string
  endTime?: string
}

export const pageLog = (params: LogQuery) =>
  request.get('/api/logs/page', { params })

export const detailLog = (id: number) =>
  request.get(`/api/logs/${id}`)
```

**示例 3：views/log/list.vue**
```vue
<template>
  <div class=\"log-page\">
    <el-card class=\"filter-card\">
      <el-form :inline=\"true\" :model=\"query\">
        <el-form-item label=\"时间区间\">
          <el-date-picker
            v-model=\"query.range\"
            type=\"datetimerange\"
            range-separator=\"至\"
            start-placeholder=\"开始时间\"
            end-placeholder=\"结束时间\"
            value-format=\"YYYY-MM-DD HH:mm:ss\"
          />
        </el-form-item>
        <el-form-item label=\"模块\">
          <el-select v-model=\"query.module\" placeholder=\"全部\" clearable style=\"width:150px\">
            <el-option label=\"会员管理\" value=\"会员管理\" />
            <el-option label=\"客房管理\" value=\"客房管理\" />
            <el-option label=\"预约管理\" value=\"预约管理\" />
            <el-option label=\"大屏统计\" value=\"大屏统计\" />
          </el-select>
        </el-form-item>
        <el-form-item label=\"用户ID\">
          <el-input v-model.number=\"query.userId\" placeholder=\"用户ID\" clearable style=\"width:120px\" />
        </el-form-item>
        <el-form-item>
          <el-button type=\"primary\" @click=\"onSearch\">查询</el-button>
          <el-button @click=\"onReset\">重置</el-button>
          <el-button type=\"success\" @click=\"onExport\">导出 CSV</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card>
      <el-table :data=\"rows\" v-loading=\"loading\" border stripe>
        <el-table-column type=\"expand\">
          <template #default=\"{ row }\">
            <div class=\"expand-detail\">
              <p><b>入参 params：</b></p>
              <pre>{{ row.params }}</pre>
              <p><b>返回 result：</b></p>
              <pre>{{ row.result || '（未记录）' }}</pre>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop=\"id\" label=\"ID\" width=\"70\" />
        <el-table-column prop=\"userId\" label=\"用户\" width=\"80\" />
        <el-table-column prop=\"module\" label=\"模块\" width=\"110\" />
        <el-table-column prop=\"operation\" label=\"操作\" width=\"90\" />
        <el-table-column prop=\"method\" label=\"方法\" min-width=\"200\" show-overflow-tooltip />
        <el-table-column prop=\"ip\" label=\"IP\" width=\"130\" />
        <el-table-column prop=\"costTime\" label=\"耗时(ms)\" width=\"90\" />
        <el-table-column prop=\"createTime\" label=\"时间\" width=\"170\" />
      </el-table>

      <el-pagination
        class=\"pagination\"
        v-model:current-page=\"query.page\"
        v-model:page-size=\"query.size\"
        :total=\"total\"
        :page-sizes=\"[10, 20, 50, 100]\"
        layout=\"total, sizes, prev, pager, next, jumper\"
        @size-change=\"loadData\"
        @current-change=\"loadData\"
      />
    </el-card>
  </div>
</template>

<script setup lang=\"ts\">
import { ref, reactive, onMounted } from 'vue'
import { pageLog } from '@/api/log'
import { ElMessage } from 'element-plus'

const rows = ref<any[]>([])
const total = ref(0)
const loading = ref(false)

const query = reactive({
  page: 1,
  size: 20,
  module: '',
  userId: undefined as number | undefined,
  range: [] as string[]
})

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await pageLog({
      page: query.page,
      size: query.size,
      module: query.module || undefined,
      userId: query.userId,
      startTime: query.range?.[0],
      endTime: query.range?.[1]
    })
    rows.value = res.data.rows
    total.value = res.data.total
  } catch (e: any) {
    ElMessage.error(e.message || '查询失败')
  } finally {
    loading.value = false
  }
}

const onSearch = () => { query.page = 1; loadData() }
const onReset = () => {
  query.module = ''
  query.userId = undefined
  query.range = []
  query.page = 1
  loadData()
}

// —— CSV 导出 ——
const csvEscape = (v: any) => {
  if (v === null || v === undefined) return ''
  const s = String(v)
  if (/[\",\\n\\r]/.test(s)) return '\"' + s.replace(/\"/g, '\"\"') + '\"'
  return s
}
const onExport = () => {
  if (rows.value.length === 0) { ElMessage.warning('当前没有数据可导出'); return }
  const header = ['ID','用户','模块','操作','方法','IP','耗时(ms)','时间','入参','返回']
  const lines = [header.join(',')]
  rows.value.forEach(r => {
    lines.push([r.id, r.userId, r.module, r.operation, r.method, r.ip,
                r.costTime, r.createTime, r.params, r.result]
      .map(csvEscape).join(','))
  })
  const blob = new Blob(['\\uFEFF' + lines.join('\\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `operation_log_${new Date().getTime()}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

onMounted(loadData)
</script>

<style scoped>
.log-page { padding: 16px; }
.filter-card { margin-bottom: 16px; }
.expand-detail pre { background: #f5f7fa; padding: 8px; border-radius: 4px; max-height: 300px; overflow: auto; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

**示例 4：路由注册**
```typescript
// router/index.ts
{
  path: '/log',
  name: 'Log',
  component: () => import('@/views/log/list.vue'),
  meta: { title: '操作日志' }
}
```

**联调步骤：**
1. 启动后端 → 前端 `pnpm dev`。
2. 从 Day03/Day04 触发几次\"新增/删除/修改\"接口，制造数据。
3. 访问 `/log`，筛选\"过去 1 小时 + 会员管理\"，观察 SQL where。
4. 展开某条记录看 params。
5. 点\"导出 CSV\"，用 WPS 打开确认中文正常。

### 6.5 课后练习
1. 【基础】新增\"操作\"筛选下拉（新增/修改/删除/查询/导出）。
2. 【综合】加\"耗时>1000ms\"复选框，过滤慢操作。
3. 【挑战】改造为\"服务端流式导出\"：后端 `/api/logs/export` 用 `HttpServletResponse` 直接输出 CSV，前端 `window.open` 触发下载，突破前端内存瓶颈。

---

## 附录 A：切点表达式速查表

### A.1 execution 表达式语法

```
execution(修饰符? 返回类型 全限定包.类.方法(参数) 异常?)
```

| 通配符 | 含义 | 例子 |
|--------|------|------|
| `*` | 任意一个（返回类型/包段/方法名/参数类型） | `execution(* save*(..))` |
| `..` | 任意多个（包段 或 参数） | `execution(* com.foo..*.*(..))` |
| `+` | 类型及其子类 | `execution(* Service+.*(..))` |

### A.2 常用示例

| 需求 | 表达式 |
|------|-------|
| 所有 Controller 方法 | `execution(* com.itcast.smart_elder.controller..*.*(..))` |
| 所有 Service 方法 | `execution(* com.itcast.smart_elder.service..*.*(..))` |
| 只切写操作 | `execution(* com.itcast.smart_elder.controller..*.save*(..)) \\|\\| execution(* ..controller..*.update*(..)) \\|\\| execution(* ..controller..*.delete*(..))` |
| 只切返回 Result 的方法 | `execution(com.itcast.smart_elder.common.Result+ *(..))` |
| 只切带一个 Long 参数的方法 | `execution(* *(java.lang.Long))` |

### A.3 其它切点指示符

| 指示符 | 用途 | 例子 |
|--------|------|------|
| `@annotation(注解类)` | 匹配打了指定注解的方法 | `@annotation(com.itcast.smart_elder.annotation.OperationLog)` |
| `@within(注解类)` | 匹配类上打了指定注解的所有方法 | `@within(org.springframework.stereotype.Service)` |
| `@target(注解类)` | 运行期检查目标类注解 | 少用 |
| `within(包.类)` | 匹配某包/类下所有方法 | `within(com.itcast.smart_elder.controller..*)` |
| `bean(名字)` | 按 Bean 名匹配 | `bean(*Service)` |

### A.4 组合使用

```java
@Pointcut(\"execution(* com.itcast.smart_elder.controller..*.*(..))\")
public void controllerLayer() {}

@Pointcut(\"@annotation(com.itcast.smart_elder.annotation.OperationLog)\")
public void operationLogAnnotation() {}

@Around(\"controllerLayer() && operationLogAnnotation()\")
public Object around(ProceedingJoinPoint pjp) throws Throwable { ... }
```

> **技巧：** 把 Pointcut 拆成有名字的方法再用 `&&` / `||` / `!` 组合，可读性高、复用好。

---

## 附录 B：AOP 常见陷阱与对策

### B.1 自调用失效

```java
@Service
public class FooService {
    public void a() { this.b(); }         // ❌ this 走不了代理
    @Async public void b() { ... }
    @Transactional public void c() { ... }
}
```
**对策：**
- 把 `b()` / `c()` 挪到**另一个 Bean**，由外部调用。
- 或者注入自己：`@Autowired FooService self;` 然后 `self.b()`（不推荐，破坏封装）。
- 或者 `AopContext.currentProxy()`（需要 `exposeProxy=true`）。

### B.2 私有/静态/final 方法不能被代理

Spring AOP 通过 CGLIB 生成**子类**代理，无法覆写 `private` / `static` / `final`。

**对策：** 保持切面方法为 **public、非 final**。

### B.3 @Async 注解写错线程池 Bean 名

```java
@Async(\"logExecutor\")   // ❌ AsyncConfig 里叫 logTaskExecutor
```
**症状：** 静默使用默认 `SimpleAsyncTaskExecutor`，线程飙升。
**对策：** IDEA 快捷键 F2/双击 Bean 名核对拼写；启动日志里搜 `TaskExecutor` 确认。

### B.4 忘记 @EnableAsync

**症状：** `@Async` 方法\"变同步执行\"。
**对策：** 在启动类或任一 `@Configuration` 类上加 `@EnableAsync`。

### B.5 注解 Retention 写错

```java
@Retention(RetentionPolicy.CLASS)    // ❌ 运行期反射读不到
public @interface OperationLog { ... }
```
**症状：** 切面永远不生效，且**不报任何错**。
**对策：** 只有 `RUNTIME` 才能被反射读取。

### B.6 切点表达式包名拼错

```java
@Around(\"@annotation(com.itcast.smart_alder.annotation.OperationLog)\")  // smart_alder 打错
```
**症状：** 静默失效，学生调试半天不知道错在哪。
**对策：** **不要手敲全限定名**，直接把注解类拖进来让 IDE 自动补全，或用形参绑定 `@Around(\"@annotation(operationLog)\") ... OperationLog operationLog`。

### B.7 Jackson 序列化 HttpServletRequest 栈溢出

**症状：** `StackOverflowError`。
**对策：** 序列化前把 `HttpServletRequest` / `Response` / `MultipartFile` 从 args 中过滤掉。

### B.8 多个切面顺序不确定

**症状：** `@Transactional` 与 `@OperationLog` 顺序不确定，日志有时候拿不到最终事务提交结果。
**对策：** 给切面加 `@Order(1)`（数字越小越先执行外层），或让日志切面 `HIGHEST_PRECEDENCE`。

### B.9 日志表爆炸

**症状：** `operation_log` 每天涨几十万条，磁盘告警。
**对策：**
- 高频查询接口**不贴**注解。
- 按月分表 / 定时归档冷数据。
- 加上 `saveResult=false` 减少 TEXT 字段体积。
- Day10 系统优化会讲更多。

### B.10 时间时区

**症状：** `create_time` 与本地时间差 8 小时。
**对策：** `application.yml` 里配置 `spring.jackson.time-zone=GMT+8` 与 `spring.jackson.date-format=yyyy-MM-dd HH:mm:ss`；数据库连接串加 `serverTimezone=Asia/Shanghai`。

---

## 附录 C：Day09 交付清单

**后端新增文件：**
- `annotation/OperationLog.java`
- `aspect/OperationLogAspect.java`
- `entity/OperationLogEntity.java`
- `mapper/OperationLogMapper.java`
- `service/OperationLogService.java`
- `config/AsyncConfig.java`
- `common/ErrorCode.java`
- `common/BusinessException.java`
- `common/Result.java`（补齐 `error(code,msg)`）
- `handler/GlobalExceptionHandler.java`（补齐 5 个 handler）
- `controller/LogController.java`

**前端新增文件：**
- `src/api/log.ts`
- `src/views/log/list.vue`
- `src/router/index.ts` 追加 `/log` 路由

**Git 建议提交：**
1. `feat(aop): custom @OperationLog and aspect`
2. `feat(aop): async persist operation log`
3. `feat(common): unified error code and global exception handler`
4. `feat(log): admin operation log page and CSV export`

至此 Day09 完成。**你的项目已经从\"业务能跑\"升级为\"可运维、可追溯\"**，恭喜！
