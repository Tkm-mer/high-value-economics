# 《智能养老社区系统》- 学生讲义 - Day11：项目部署运维

**授课日：Day 11 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day10 完成系统优化与压测；Day02-Day09 各模块业务已开发完毕；本讲义按 6 讲对应 6 课时，配套 `deploy/` 目录产物：两个 Dockerfile、docker-compose.yml、nginx.conf、systemd unit、start/stop 脚本、上线 Checklist。**

---

## 第 1 讲：Linux 基础与部署环境准备

### 1.1 本讲要点
- 8 条最常用 Linux 命令（`ls / cd / vim / tail / grep / ps / netstat / systemctl`）
- 目录约定 `/app/smart-elder/{backend, web, deploy}`
- 防火墙 `firewalld`：`--permanent --add-port + --reload`
- JDK17 用 tar 手工装 + `/etc/profile` 环境变量
- MySQL 8 yum 装 + 修改初始密码 + 建库导 Day01 脚本
- Redis 7 装 + `requirepass` + `bind` 内网

### 1.2 知识点详解

#### 1.2.1 Linux 常用命令速查

| 命令 | 高频用法 | 场景 |
|------|---------|------|
| `ls -lh` | 查看文件、大小 | 找 jar 包位置 |
| `ls -la` | 含隐藏文件 | 看 `.gitignore` |
| `cd /app/smart-elder` | 切目录 | 切到部署目录 |
| `vim application-prod.yml` | 编辑配置 | 改数据库密码 |
| `tail -f logs/app.log` | 实时看日志 | 观察启动过程 |
| `tail -n 100 log` | 看末尾 100 行 | 快速看最近报错 |
| `grep -i error log` | 大小写不敏感过滤 | 找报错行 |
| `grep -n error log` | 显示行号 | 定位位置 |
| `grep -r "keyword" .` | 递归搜索 | 找配置在哪 |
| `ps -ef \| grep java` | 找 Java 进程 | 看服务是否活 |
| `netstat -tlnp \| grep 8080` | 看端口监听 | 排查端口占用 |
| `systemctl start/stop/status/enable X` | 系统服务四板斧 | 起停 MySQL 等 |
| `journalctl -u X -f` | 看 systemd 服务日志 | 实时看应用日志 |
| `df -h` | 磁盘使用 | 排查"日志把盘塞满" |
| `free -h` | 内存使用 | 看剩余内存 |
| `chmod +x xx.sh` | 加执行权限 | 让脚本可跑 |

> **技巧：** `tail -f` 是**追加式**看，实时刷新；`less +F` 也能实时看，还能按 `Ctrl+C` 退出实时模式做上下翻页搜索，日志分析更顺手。

> **注意：** `vim` 保存退出用 `:wq`，不保存用 `:q!`。初学者最常见的坑是**按了 Insert 后忘按 ESC**，敲什么都是插入。

#### 1.2.2 vim 三态图

```
      ┌────────── i (进入) ──────────┐
      │                              ▼
 ┌─────────┐                   ┌──────────┐
 │ Normal  │                   │ Insert   │
 │(默认)   │◀───── ESC ────────│(编辑)    │
 └────┬────┘                   └──────────┘
      │  : (进入命令)
      ▼
 ┌──────────────┐
 │ Command      │  :wq  保存退出
 │              │  :q!  不保存退出
 └──────────────┘
```

#### 1.2.3 项目目录约定

```
/app/smart-elder/
├── backend/
│   ├── smart-elder.jar
│   ├── start.sh / stop.sh / restart.sh
│   ├── application-prod.yml
│   └── logs/
├── web/
│   └── dist/          # Nginx root 指这里
├── deploy/
│   ├── Dockerfile.backend
│   ├── Dockerfile.web
│   ├── docker-compose.yml
│   ├── nginx.conf
│   └── smart-elder.service
├── mysql/data/        # docker 卷
└── redis/data/
```

#### 1.2.4 防火墙 firewalld

```bash
firewall-cmd --state                          # 状态
firewall-cmd --permanent --add-port=80/tcp    # 永久开 80
firewall-cmd --permanent --add-port=8080/tcp
firewall-cmd --reload                         # 生效
firewall-cmd --list-ports                     # 查看
```

> **注意：** 不加 `--permanent`，重启防火墙就丢；加了 `--permanent` 不 `--reload` 当次不生效。**两句都要**。

#### 1.2.5 JDK17 tar 装 + 环境变量

```bash
cd /usr/local
tar -zxvf /usr/local/src/jdk-17.0.10_linux-x64_bin.tar.gz
mv jdk-17.0.10 jdk17

vim /etc/profile
# 末尾追加：
export JAVA_HOME=/usr/local/jdk17
export PATH=$JAVA_HOME/bin:$PATH

source /etc/profile
java -version
```

> **技巧：** `/etc/profile` 是**全局登录 shell** 生效；`~/.bashrc` 是当前用户**非登录 shell** 生效。生产上一般统一改 `/etc/profile`。

#### 1.2.6 MySQL 8 安装 + 导入 Day01 脚本

```bash
rpm -Uvh https://dev.mysql.com/get/mysql80-community-release-el7-7.noarch.rpm
rpm --import https://repo.mysql.com/RPM-GPG-KEY-mysql-2022
yum install -y mysql-community-server
systemctl start mysqld
systemctl enable mysqld

# 拿临时密码
grep 'temporary password' /var/log/mysqld.log

mysql -uroot -p'临时密码'
> ALTER USER 'root'@'localhost' IDENTIFIED BY 'Elder@2026';
> CREATE DATABASE smart_elder DEFAULT CHARACTER SET utf8mb4;
> exit

# 导入 Day01 建表脚本
mysql -uroot -pElder@2026 smart_elder < /root/smart_elder.sql
```

#### 1.2.7 Redis 7 安装

```bash
yum install -y epel-release
yum install -y redis

vim /etc/redis.conf
# 修改两行：
# bind 127.0.0.1 内网IP           # 别开 0.0.0.0 到公网
# requirepass Elder@Redis        # 必开密码

systemctl start redis
systemctl enable redis
redis-cli -a 'Elder@Redis' ping   # 返回 PONG 即成功
```

> **注意：** Redis 若无密码 + 绑定 0.0.0.0 + 端口开公网 = **免费挖矿肉鸡**。三条至少堵一条。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| firewalld `--permanent + --reload` | 永久开放端口两步走 |
| `/etc/profile` | 全局登录 shell 环境变量文件 |
| `mysql -u -p < file.sql` | 直接从文件导入 SQL |
| `requirepass` | Redis 密码，生产必开 |
| `netstat -tlnp` | tcp + listen + numeric + program |

### 1.4 示例代码/例题解析

**示例 1：一次性验证三件套是否就位**
```bash
java -version && \
mysql -uroot -pElder@2026 -e "select database();" smart_elder && \
redis-cli -a 'Elder@Redis' ping
```
三条命令连成一串，任何一条失败就中断——快速自检脚本雏形。

### 1.5 课后练习

1. 【基础】把 `netstat -tlnp` 的输出中 8080 那行完整贴到笔记。
2. 【综合】写一个 `check-env.sh` 脚本，依次检查 java/mysql/redis 是否可用，任何一项失败退出码非 0。
3. 【挑战】研究 `firewalld` 的 zone 概念，把 8080 放到 `internal` zone，仅允许指定 IP 段访问。

---

## 第 2 讲：后端 jar 部署与守护

### 2.1 本讲要点
- `mvn clean package -DskipTests` 打 fat-jar
- `application-prod.yml` + `${DB_PASSWORD}` 环境变量外部化
- `nohup + &` + `pid` 文件写法的 `start.sh / stop.sh / restart.sh`
- systemd unit 让服务开机自启 + 崩了自动拉起
- `logback-spring.xml` 按天+按大小滚动 + 30 天保留

### 2.2 知识点详解

#### 2.2.1 fat-jar 打包

Spring Boot 用 `spring-boot-maven-plugin` 把所有依赖打成一个"胖 jar"（60-80MB），一条 `java -jar` 就能跑，比传统 war+Tomcat 简单太多。

```bash
mvn clean package -DskipTests
ls -lh target/smart-elder-*.jar
```

`-DskipTests` 跳过测试用例——**生产打包用**（避免测试代码里连不到本地 db 导致失败）；日常构建仍要跑测试。

#### 2.2.2 application-prod.yml

```yaml
server:
  port: 8080
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/smart_elder?useSSL=false&serverTimezone=Asia/Shanghai&characterEncoding=utf8mb4
    username: root
    password: ${DB_PASSWORD:Elder@2026}
    driver-class-name: com.mysql.cj.jdbc.Driver
  data:
    redis:
      host: 127.0.0.1
      port: 6379
      password: ${REDIS_PASSWORD:Elder@Redis}
      database: 0
logging:
  file:
    path: /app/smart-elder/backend/logs
```

> **技巧：** `${VAR:默认值}` 语法 = 优先读环境变量，读不到用默认。**生产密码永远从环境变量注入**。

#### 2.2.3 生产级 start.sh

```bash
#!/bin/bash
APP_HOME=/app/smart-elder/backend
APP_NAME=smart-elder.jar
PID_FILE=$APP_HOME/app.pid
LOG_FILE=$APP_HOME/logs/nohup.out

cd $APP_HOME
if [ -f "$PID_FILE" ] && kill -0 `cat $PID_FILE` 2>/dev/null; then
  echo "Already running, pid=`cat $PID_FILE`"
  exit 1
fi
mkdir -p logs
nohup java -Xms512m -Xmx1024m \
  -Dspring.profiles.active=prod \
  -Dfile.encoding=UTF-8 \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=$APP_HOME/logs \
  -jar $APP_NAME > $LOG_FILE 2>&1 &
echo $! > $PID_FILE
echo "Started, pid=`cat $PID_FILE`"
```

拆解每一行：
- `nohup` = No hangup，让进程忽略 SIGHUP，父终端关闭时不跟着死。
- `> $LOG_FILE 2>&1` = 标准输出重定向到 nohup.out，`2>&1` 让错误输出跟着走。
- `&` = 让命令后台运行，立即返回 shell。
- `echo $! > $PID_FILE` = `$!` 是刚才后台命令的 pid，写进 pid 文件供 stop.sh 用。

#### 2.2.4 stop.sh / restart.sh

`stop.sh`：
```bash
#!/bin/bash
PID_FILE=/app/smart-elder/backend/app.pid
if [ ! -f "$PID_FILE" ]; then echo "Not running"; exit 0; fi
PID=`cat $PID_FILE`
kill $PID
for i in {1..30}; do
  if ! kill -0 $PID 2>/dev/null; then rm -f $PID_FILE; echo "Stopped"; exit 0; fi
  sleep 1
done
echo "Force kill"
kill -9 $PID; rm -f $PID_FILE
```

先发 `SIGTERM`（`kill` 默认），给应用最多 30 秒优雅停机；超时才 `kill -9`。

`restart.sh`：
```bash
#!/bin/bash
DIR=$(cd $(dirname $0); pwd)
sh $DIR/stop.sh
sleep 2
sh $DIR/start.sh
```

给三个脚本都 `chmod +x`。

#### 2.2.5 systemd unit（企业主流）

`/etc/systemd/system/smart-elder.service`：
```ini
[Unit]
Description=Smart Elder Backend
After=network.target mysqld.service redis.service

[Service]
Type=simple
User=root
WorkingDirectory=/app/smart-elder/backend
Environment="DB_PASSWORD=Elder@2026"
Environment="REDIS_PASSWORD=Elder@Redis"
ExecStart=/usr/local/jdk17/bin/java -Xms512m -Xmx1024m \
  -Dspring.profiles.active=prod \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=/app/smart-elder/backend/logs \
  -jar /app/smart-elder/backend/smart-elder.jar
SuccessExitStatus=143
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

管理命令：
```bash
systemctl daemon-reload         # 每次改 unit 后必做
systemctl enable smart-elder    # 开机自启
systemctl start smart-elder
systemctl status smart-elder
journalctl -u smart-elder -f    # 实时日志
```

> **技巧：** systemd 让 Java 服务像 MySQL 一样被系统托管，**崩了自动拉起、重启机器自启、日志统一在 journal**。生产强烈推荐。

#### 2.2.6 logback-spring.xml 日志轮切

`src/main/resources/logback-spring.xml`：
```xml
<configuration>
  <property name="LOG_HOME" value="${LOG_FILE_PATH:-./logs}"/>
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>${LOG_HOME}/smart-elder.log</file>
    <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
      <fileNamePattern>${LOG_HOME}/smart-elder.%d{yyyy-MM-dd}.%i.log.gz</fileNamePattern>
      <maxFileSize>100MB</maxFileSize>
      <maxHistory>30</maxHistory>
      <totalSizeCap>10GB</totalSizeCap>
    </rollingPolicy>
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>
  <root level="INFO"><appender-ref ref="FILE"/></root>
</configuration>
```

按天分文件 + 单文件超 100M 再切分 + 只保留 30 天 + 累计 10G 上限——防止**日志把磁盘塞满**这个经典事故。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| fat-jar | 依赖打进单 jar，`java -jar` 直接跑 |
| `nohup + &` | 后台常驻，脱离终端 |
| `Restart=on-failure` | 崩溃自动重启（非零退出码触发） |
| `HeapDumpOnOutOfMemoryError` | OOM 自动生成 hprof |
| logback SizeAndTimeBasedRollingPolicy | 按天 + 按大小双维度切分 |

### 2.4 示例代码/例题解析

**示例 1：一次热更新**
```bash
scp target/smart-elder-1.0.1.jar root@host:/app/smart-elder/backend/smart-elder.jar
ssh root@host 'systemctl restart smart-elder && journalctl -u smart-elder -f'
```
本地打包 → 传上去覆盖 jar → 重启 systemd 服务 → 实时看日志。**一条 ssh 完成热更新**。

### 2.5 课后练习

1. 【基础】把 `start.sh` 里的 JVM 堆改成 `-Xms1g -Xmx2g`。
2. 【综合】在 systemd unit 里加 `LimitNOFILE=65535`（提升文件句柄上限）与 `TimeoutStopSec=60`（关闭超时）。
3. 【挑战】把 `application-prod.yml` 从 jar 中移出，改用 `-Dspring.config.location=file:/app/smart-elder/backend/application-prod.yml`，让配置改动无需重新打 jar。

---

## 第 3 讲：Nginx 部署 Vue3 前端

### 3.1 本讲要点
- `pnpm build` 产出 `dist/` 静态资源
- Nginx `server / location / upstream` 三大配置块
- `try_files $uri $uri/ /index.html;` 破解 Vue Router history 刷新 404
- `location /api/` 反向代理到 8080（末尾 `/` 讲究）
- SSE 流式接口 `proxy_buffering off`
- `gzip` 压缩 + 静态资源强缓存

### 3.2 知识点详解

#### 3.2.1 前端产物

```bash
cd smart-elder-web
pnpm build
ls dist/
# index.html  assets/  favicon.ico
```
`dist/` 就是纯 HTML + JS + CSS 打包成果，把它扔到 Nginx `root` 目录即可。

#### 3.2.2 完整 nginx.conf（业务片段）

放到 `/etc/nginx/conf.d/smart-elder.conf`：

```nginx
gzip on;
gzip_min_length 1k;
gzip_comp_level 6;
gzip_types text/plain text/css application/json application/javascript
           application/x-javascript text/xml application/xml application/xml+rss
           text/javascript image/svg+xml;
gzip_vary on;

server {
    listen       80;
    server_name  _;

    root  /app/smart-elder/web/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2?)$ {
        expires 7d;
        add_header Cache-Control "public, max-age=604800";
    }

    location /api/ {
        proxy_pass         http://127.0.0.1:8080/api/;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    location /api/ai/chat/stream {
        proxy_pass         http://127.0.0.1:8080/api/ai/chat/stream;
        proxy_http_version 1.1;
        proxy_set_header   Connection "";
        proxy_buffering    off;
        proxy_cache        off;
        proxy_read_timeout 3600s;
    }

    access_log /var/log/nginx/smart-elder.access.log;
    error_log  /var/log/nginx/smart-elder.error.log warn;
}
```

#### 3.2.3 三大配置块含义

| 关键字 | 作用 |
|--------|------|
| `server { ... }` | 一个虚拟主机（一个端口/域名） |
| `location xxx { ... }` | URL 路径匹配规则 |
| `upstream name { ... }` | 一组后端（配合负载均衡） |

#### 3.2.4 `try_files` 为什么救命

Vue Router 有 hash（`#/member`）和 history（`/member`）两种模式。history 模式浏览器地址栏是干净的 `/member`，但服务器磁盘里没这个文件，一刷新 Nginx 就 404。

`try_files $uri $uri/ /index.html;` 的含义：
1. 先找 `$uri`（`/member`）文件——没有
2. 再找 `$uri/`（`/member/`）目录索引——没有
3. **兜底回退到 `/index.html`**——交给前端路由自己处理

> **技巧：** 只要项目用了 Vue Router history 或 React Router BrowserRouter，Nginx 必写这一句。

#### 3.2.5 `proxy_pass` 结尾斜杠陷阱

| 写法 | 请求 `/api/member` 被转成 |
|------|--------------------------|
| `location /api/ { proxy_pass http://backend:8080/api/; }` | `/api/member`  ✅ |
| `location /api/ { proxy_pass http://backend:8080; }` | `/api/member`  ✅（保留原路径） |
| `location /api/ { proxy_pass http://backend:8080/; }` | `/member`（去掉 /api 前缀）|

> **注意：** 记不住时统一 **"两个末尾都带斜杠"**，行为最直观。

#### 3.2.6 SSE 必须关缓冲

Day05 我们用 SSE 做了 AI 流式对话。Nginx 默认 `proxy_buffering on`，会把后端一 chunk 一 chunk 推的数据攒在一起才回给浏览器——"流式"就变"一次性"了。**必须关**：
```nginx
proxy_buffering off;
proxy_cache off;
proxy_read_timeout 3600s;   # SSE 长连接
```

#### 3.2.7 三板斧

```bash
nginx -t          # 语法校验
nginx -s reload   # 平滑重载
tail -f /var/log/nginx/smart-elder.error.log
```

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| `try_files` | history 模式神器，SPA 刷新不 404 |
| `proxy_pass` | 反向代理，末尾 `/` 决定路径改写 |
| `proxy_buffering off` | SSE/长连接必须关 |
| `expires 7d` | 静态资源强缓存 |
| `gzip` | 减少传输量 60-80% |

### 3.4 示例代码/例题解析

**示例 1：调试 502 Bad Gateway**

现象：浏览器访问 `/api/member` 报 502。

排查：
```bash
curl http://127.0.0.1:8080/api/member    # 直接打后端
```
如果这条通，说明 Nginx 到后端 8080 走不通——检查 `proxy_pass` 地址、防火墙、`SELinux`（`setsebool -P httpd_can_network_connect 1`）。

如果直接打后端也 500，说明后端本身挂了——去看 backend 日志。

### 3.5 课后练习

1. 【基础】给 `smart-elder.conf` 加一个 `location /health { return 200 'ok'; }` 健康检查接口。
2. 【综合】把上传目录 `/app/smart-elder/backend/upload/` 直接由 Nginx 作为静态资源服务，省一次反代。
3. 【挑战】用 Let's Encrypt 加 HTTPS：`certbot --nginx -d elder.example.com`。

---

## 第 4 讲：Docker 容器化部署

### 4.1 本讲要点
- 容器 vs 虚拟机：Namespace + Cgroup 隔离
- 多阶段 Dockerfile：builder（打包）+ runtime（跑）
- 后端 `maven:3.9-eclipse-temurin-17` → `eclipse-temurin:17-jdk-alpine`
- 前端 `node:20-alpine` → `nginx:1.25-alpine`
- docker-compose 四服务：mysql / redis / backend / nginx
- `healthcheck` + `depends_on.condition: service_healthy`
- `volumes` 持久化数据 + `networks` 内部寻址

### 4.2 知识点详解

#### 4.2.1 后端 Dockerfile（多阶段）

`smart-elder-backend/Dockerfile`：
```dockerfile
# —— Stage 1：编译 ——
FROM maven:3.9-eclipse-temurin-17 AS builder
WORKDIR /build
COPY pom.xml .
RUN mvn dependency:go-offline -B
COPY src ./src
RUN mvn clean package -DskipTests -B

# —— Stage 2：运行 ——
FROM eclipse-temurin:17-jdk-alpine
WORKDIR /app
COPY --from=builder /build/target/smart-elder-*.jar app.jar
ENV JAVA_OPTS="-Xms512m -Xmx1024m"
ENV SPRING_PROFILES_ACTIVE=prod
EXPOSE 8080
ENTRYPOINT sh -c "java $JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/app/logs -jar app.jar"
```

> **技巧：** 先 `COPY pom.xml` 再 `mvn dependency:go-offline` —— 让 Docker layer cache 生效。只改 `src/` 时依赖层不重跑，构建速度快 10 倍。

#### 4.2.2 前端 Dockerfile

`smart-elder-web/Dockerfile`：
```dockerfile
FROM node:20-alpine AS builder
WORKDIR /build
RUN npm i -g pnpm
COPY pnpm-lock.yaml package.json ./
RUN pnpm install --frozen-lockfile
COPY . .
RUN pnpm build

FROM nginx:1.25-alpine
COPY --from=builder /build/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

同目录下要有 `nginx.conf`（第 3 讲版本，`proxy_pass` 换成 `http://backend:8080/api/`）。

#### 4.2.3 docker-compose.yml（四服务）

```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: elder-mysql
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: Elder@2026
      MYSQL_DATABASE: smart_elder
      TZ: Asia/Shanghai
    volumes:
      - ./deploy/mysql/data:/var/lib/mysql
      - ./deploy/mysql/init:/docker-entrypoint-initdb.d
    ports: ["3306:3306"]
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-pElder@2026"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks: [elder-net]

  redis:
    image: redis:7-alpine
    container_name: elder-redis
    restart: unless-stopped
    command: ["redis-server", "--requirepass", "Elder@Redis", "--appendonly", "yes"]
    volumes:
      - ./deploy/redis/data:/data
    ports: ["6379:6379"]
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "Elder@Redis", "ping"]
      interval: 10s
      timeout: 3s
      retries: 5
    networks: [elder-net]

  backend:
    build:
      context: ./smart-elder-backend
    image: smart-elder-backend:1.0.0
    container_name: elder-backend
    restart: unless-stopped
    environment:
      SPRING_PROFILES_ACTIVE: prod
      SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/smart_elder?useSSL=false&serverTimezone=Asia/Shanghai&characterEncoding=utf8mb4
      SPRING_DATASOURCE_USERNAME: root
      SPRING_DATASOURCE_PASSWORD: Elder@2026
      SPRING_DATA_REDIS_HOST: redis
      SPRING_DATA_REDIS_PASSWORD: Elder@Redis
    volumes:
      - ./deploy/backend/logs:/app/logs
    depends_on:
      mysql: { condition: service_healthy }
      redis: { condition: service_healthy }
    ports: ["8080:8080"]
    networks: [elder-net]

  nginx:
    build:
      context: ./smart-elder-web
    image: smart-elder-web:1.0.0
    container_name: elder-nginx
    restart: unless-stopped
    depends_on: [backend]
    ports: ["80:80"]
    networks: [elder-net]

networks:
  elder-net:
    driver: bridge
```

**关键点：**
- 后端连接串是 `jdbc:mysql://mysql:3306/...`——`mysql` 是 compose 里的**服务名**，同一 network 下自动解析为容器 IP。
- `service_healthy` 才是**真等 MySQL 起好**；单用 `depends_on` 只等容器创建，不等应用 ready。
- volume 都挂宿主机 `./deploy/...`，容器删了数据不丢。

#### 4.2.4 一键启停

```bash
docker-compose up -d --build      # 首次或改代码：构建 + 起
docker-compose ps                 # 状态
docker-compose logs -f backend    # 看某服务日志
docker-compose restart backend    # 只重启后端
docker-compose down               # 停并删容器（保留卷）
docker-compose down -v            # 连数据卷一起删（危险！）
```

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 多阶段构建 | builder + runtime，镜像瘦身 5-10 倍 |
| service_healthy | 依赖健康检查通过才启动 |
| 服务名寻址 | compose 内部 `jdbc:mysql://mysql:3306` |
| volume | 数据持久化，容器删了还在 |
| `--frozen-lockfile` | pnpm 严格锁版本 |

### 4.4 示例代码/例题解析

**示例 1：为什么后端连不上 MySQL？**

现象：`docker-compose up -d` 后 backend 反复重启。

排查：
```bash
docker-compose logs backend | tail -30
```
若看到 `Communications link failure`，通常有 3 种原因：
1. connection URL 里 host 写成了 `127.0.0.1`——容器里 127.0.0.1 是自己，不是 mysql 容器！**必须写服务名 `mysql`**。
2. MySQL 还没起好——加 `depends_on.condition: service_healthy`。
3. 密码不对——`docker-compose logs mysql` 看 root 密码是否被正常设置。

### 4.5 课后练习

1. 【基础】把后端 JVM 堆改成 2G（改 `JAVA_OPTS` 环境变量）。
2. 【综合】给 nginx 服务挂宿主机日志卷 `./deploy/nginx/logs:/var/log/nginx`。
3. 【挑战】把 `docker-compose.yml` 拆成 base + override 两份，dev/prod 用不同 profile。

---

## 第 5 讲：线上故障处理常用方法

### 5.1 本讲要点
- 三板斧：**看日志、看进程、看堆栈**
- CPU 100% 五步：`top` → `top -H -p` → `printf %x` → `jstack` → `grep nid`
- 内存泄漏：`jstat -gcutil` → `jmap dump` → MAT
- Arthas 神器：`dashboard / thread / trace / watch / jad`
- Day03 分页 case 复盘

### 5.2 知识点详解

#### 5.2.1 日志查看

```bash
tail -f /app/smart-elder/backend/logs/smart-elder.log
tail -f smart-elder.log | grep -i --line-buffered error
less +F smart-elder.log        # Ctrl+C 退实时，可上下翻
sed -n '/10:00/,/10:05/p' smart-elder.log > slice.log
```

> **技巧：** `grep --line-buffered` 让实时 tail 走 grep 时**每行都刷屏**（默认块缓冲会积一批才刷）。

#### 5.2.2 CPU 100% 五步法

```bash
# 1. top 找 pid（假设 12345，CPU 800%）
top

# 2. top -H 找线程（假设 tid=12360）
top -H -p 12345

# 3. 十六进制转换（jstack nid 是 hex）
printf "%x\n" 12360     # 输出 3048

# 4. 拉栈
jstack 12345 > /tmp/stack.log

# 5. 定位
grep -A 30 "nid=0x3048" /tmp/stack.log
```

输出会告诉你线程栈里的具体方法与行号——**那就是问题代码**。

#### 5.2.3 内存泄漏排查

```bash
# 看 GC（如 FGC 频繁 + old 区常年 99%）
jstat -gcutil 12345 1000 10

# dump 存活对象
jmap -dump:live,format=b,file=/tmp/heap.hprof 12345

# 传本地用 MAT 分析
scp root@host:/tmp/heap.hprof ./
```

> **注意：** jmap dump 时会 STW（Stop The World），几秒内接口不可用。**别在业务高峰期做**。可结合 `-XX:+HeapDumpOnOutOfMemoryError` 让 JVM 自己 OOM 时 dump。

#### 5.2.4 Arthas 在线诊断

```bash
curl -O https://arthas.aliyun.com/arthas-boot.jar
java -jar arthas-boot.jar
# 选 [1] com.smart.elder.Application
```

进入交互：

| 命令 | 用途 |
|------|------|
| `dashboard` | JVM/线程/CPU 大盘 |
| `thread -n 3` | 最忙 3 个线程堆栈 |
| `thread -b` | 找死锁 |
| `trace 类 方法` | 追踪方法内部每一步耗时 |
| `watch 类 方法 "{params,returnObj,throwExp}" -x 3` | 观测入参/返回/异常 |
| `jad 类` | 反编译看线上真实字节码 |
| `stop` | 退出并**恢复所有增强**（重要，别忘） |

> **技巧：** Arthas 最强在于**不改代码、不重启、直接摸问题**。生产必备。

#### 5.2.5 Day03 分页 case 完整复盘

**故障时间线**：
- 14:32 运营反馈"会员列表页转圈圈半分钟"。
- 14:33 SSH 登录，`top` 看到 java 进程 CPU 620%（8 核）。
- 14:34 `top -H -p 12345`，最热线程 tid=15234，CPU 98%。
- 14:34 `printf "%x\n" 15234` → 3b82。
- 14:35 `jstack 12345 | grep -A 20 "nid=0x3b82"`，栈顶 `MemberMapper.selectPage`。
- 14:36 `tail -f logs/smart-elder.log | grep "Preparing:"` 抓到 SQL 原文。
- 14:37 复制到 MySQL 客户端 `EXPLAIN`，看到 `type=ALL, rows≈300000`。
- 14:38 `create index idx_create_time on tb_member(create_time);` （Day10 学的）
- 14:39 EXPLAIN 变 `type=range, rows≈2000`，接口 RT 从 3s 降到 200ms。
- 14:40 通知运营恢复，撰写事后复盘。

**教训**：Day10 讲优化时如果就把这条索引加上，今天就没这场故障。**性能优化必须在压测阶段完成，不要留到线上**。

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| `nid` | 线程的 Native ID，十六进制 |
| `printf "%x\n" N` | 十进制转十六进制 |
| `jstack` | 打印所有 Java 线程栈 |
| `jstat -gcutil` | 看 GC 分代占用比例 |
| MAT | Eclipse Memory Analyzer, hprof 分析工具 |
| Arthas | 阿里在线 Java 诊断神器 |

### 5.4 示例代码/例题解析

**示例 1：Arthas 追踪单个接口耗时**

场景：会员列表接口慢，不知道慢在 Controller、Service 还是 Mapper。

```bash
# 进入 Arthas 后：
trace com.itcast.smart_elder.controller.MemberController page \
      --skipJDKMethod false -n 5
# 触发一次接口
curl "http://127.0.0.1:8080/api/member?page=1&size=20"
# Arthas 输出：
# +---[95%] MemberService.pageQuery()  2980ms  ← 慢在这
#   +---[99%] MemberMapper.selectPage() 2960ms  ← 慢在这
#     +---[10%] getConnection()  10ms
#     +---[89%] executeQuery()  2650ms  ← SQL 执行
```
一眼看出瓶颈是 SQL 执行。下一步就是抓 SQL 原文去 `EXPLAIN`。

### 5.5 课后练习

1. 【基础】写一句 Arthas 命令：观察 `RoomController.list` 每次调用的入参与返回。
2. 【综合】在自己项目里造一个"死循环接口"，走完 CPU 五步法。
3. 【挑战】研究 `arthas` 的 `profiler start / stop` 命令，生成火焰图。

---

## 第 6 讲：上线检查清单与回滚方案

### 6.1 本讲要点
- 上线 15 项 Checklist（4 阶段）
- 灰度 / 蓝绿 / 滚动三种发布策略
- Docker 环境 30 秒回滚：改 image tag + `up -d`
- DDL 上线黄金原则："只加不删"
- Postmortem 事后复盘模板

### 6.2 知识点详解

#### 6.2.1 上线 Checklist 15 项

| # | 分类 | 检查项 | 通过标准 |
|---|------|--------|---------|
| 1 | 代码 | 合并主干、评审通过 | PR merged, +2 approve |
| 2 | 代码 | CI 全绿 | 单测、集成测试 pass |
| 3 | 配置 | prod 配置正确 | 与 Nacos/Vault 一致 |
| 4 | 配置 | 密钥不硬编码 | grep 无明文 |
| 5 | 数据 | **备份数据库** | mysqldump 文件可 restore |
| 6 | 数据 | DDL 已在生产执行 | flyway/liquibase |
| 7 | 依赖 | 外部服务密钥在期 | AI/OSS/支付调用测试通过 |
| 8 | 部署 | 新镜像已推仓库 | `docker pull` 可拉 |
| 9 | 部署 | **保留上一版本镜像** | v1.0.0 与 v1.0.1 双 tag 在 |
| 10 | 监控 | Prometheus/Grafana 接入 | 新版本指标可见 |
| 11 | 监控 | 告警配置 | CPU>85%、5xx>1%、RT>2s |
| 12 | 日志 | 级别为 INFO | 非 DEBUG |
| 13 | 灰度 | 先放 10% 观察 15 分钟 | 无异常再全量 |
| 14 | 回滚 | 5 分钟内可回 | 演练过 |
| 15 | 通知 | 产品/运营/客服知晓 | 发布公告 |

> **技巧：** 把这份表打印贴办公室墙上，每次上线负责人签字画勾——**流程化能救人**。

#### 6.2.2 灰度 vs 蓝绿 vs 滚动

| 策略 | 做法 | 优点 | 缺点 | 适用 |
|------|-----|------|------|------|
| 灰度 | 部分流量到新版 | 影响小 | 需要分流机制 | 大流量、C 端 |
| 蓝绿 | 两套完整环境切换 | 秒切 | 资源翻倍 | 关键系统 |
| 滚动 | 逐 Pod 替换 | 无停机 | 中间态版本混杂 | K8s 场景 |

我们项目单机 docker-compose 走**"镜像 tag 快切"** 的简化版蓝绿。

#### 6.2.3 Docker 30 秒回滚

前提：**发布前已经打了两个 tag**（`smart-elder-backend:v1.0.1` 是旧稳定版，`:v1.0.2` 是新版）。

回滚三步：
```bash
# 1. 编辑 docker-compose.yml
vim docker-compose.yml
# 找到 backend 服务：
# image: smart-elder-backend:v1.0.2  →  改回 v1.0.1

# 2. 只重启 backend 服务
docker-compose up -d backend

# 3. 健康检查
curl http://127.0.0.1/api/hello
```
30 秒完成。

> **注意：** 如果新版本涉及**破坏性 DDL**（删字段/改类型），代码回滚 ≠ 数据回滚。要先备份、再手工 undo 结构，成本高一倍。**所以 DDL 只加不删。**

#### 6.2.4 事后复盘（Postmortem）

模板（约 300-500 字）：
```
# xxxx-xx-xx 生产事故复盘：会员列表接口超时

## 时间线
- 14:32 用户反馈
- 14:38 定位到未加索引
- 14:39 加索引恢复

## 影响范围
影响 15 分钟，会员列表接口 P95 RT 从 200ms → 3200ms，
预约、大屏等 6 个接口受牵连（数据库连接池打满）。

## 根因
1. 技术根因：tb_member.create_time 列无索引，30 万数据全表扫。
2. 流程根因：Day10 压测未覆盖 create_time 排序场景，索引评审遗漏。

## 短期修复
- 加索引 idx_create_time
- 加告警：慢 SQL > 500ms 报警

## 长期改进
- 压测场景清单纳入 CR checklist
- 上线前必跑 EXPLAIN 关键 SQL
```

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Checklist | 上线 SOP，签字画勾 |
| 灰度发布 | 部分流量渐进放量 |
| 镜像 tag 回滚 | Docker 环境 30 秒回退 |
| DDL 只加不删 | 保证代码回滚可行 |
| Postmortem | 事后复盘，5 段式模板 |

### 6.4 示例代码/例题解析

**示例 1：完整回滚流程图**

```
        ┌────────────────┐
        │  上线 v1.0.2    │
        └────────┬───────┘
                 │
        ┌────────▼────────┐
        │  灰度 10% 15min  │
        └────────┬────────┘
                 │
    ┌────────────┴────────────┐
    │                         │
[无异常]                   [告警/投诉]
    │                         │
    │                    立即冻结新请求
    │                         │
全量发布 v1.0.2         判断变更类型
    │                    │           │
    │           [仅代码/配置]     [含 DDL]
    │                    │           │
    │           改 image tag    先备份数据库
    │           v1.0.2→v1.0.1        │
    │                    │           │
    │           docker-compose   手工 undo DDL
    │           up -d backend        │
    │                    │           │
    │           curl 健康检查    改 image tag
    │                    │           │
    │           通知/复盘        再重启
    │                    └───────┬───┘
    │                            │
    │                     生产复盘 Postmortem
    │
   完成
```

**示例 2：`docker-compose.yml` 中如何优雅带版本 tag**

```yaml
services:
  backend:
    image: smart-elder-backend:${IMAGE_TAG:-v1.0.0}
```
然后：
```bash
IMAGE_TAG=v1.0.2 docker-compose up -d backend    # 发新版
IMAGE_TAG=v1.0.1 docker-compose up -d backend    # 回滚
```
一行环境变量搞定，不用改 yml。

### 6.5 课后练习

1. 【基础】把 Checklist 15 项打印或存到项目 wiki。
2. 【综合】演练完整"发布 → 触发 bug → 回滚"，掐时间要求 60 秒内完成。
3. 【挑战】用两台机器搭一个"蓝绿"简易版：Nginx `upstream` 权重可动态调整。

---

## 附录 A：Linux 常用命令速查

```
# 目录/文件
ls -lh              列文件+大小
ls -la              含隐藏
cd -                回上次
pwd                 当前目录
mkdir -p a/b/c      递归建目录
rm -rf 目录          递归删除（危险！）
cp -r src dst       递归复制
mv src dst          移动/重命名
touch xxx           建空文件
find . -name "*.sh" 递归找

# 查看
cat file            全部显示
tail -f log         实时看
tail -n 100 log     末尾 100 行
head -n 20 log      开头 20 行
less +F log         交互 + 实时
wc -l file          统计行数

# 搜索
grep -i keyword file       忽略大小写
grep -n keyword file       显示行号
grep -r keyword dir        递归
grep -A 5 keyword file     匹配行后 5 行
grep -B 5 keyword file     匹配行前 5 行
grep -v keyword file       反向匹配

# 进程/端口
ps -ef | grep java
netstat -tlnp | grep 8080
netstat -anp | grep ESTABLISHED
lsof -i:8080               看谁占了 8080
kill PID                   优雅结束
kill -9 PID                强制结束

# 系统服务
systemctl start/stop/restart/status/enable/disable/reload service
journalctl -u service -f
journalctl -u service --since "1 hour ago"

# 磁盘/内存
df -h                      磁盘
du -sh dir                 目录大小
free -h                    内存
top / htop                 实时监控
top -H -p PID              进程内线程

# 网络
curl http://127.0.0.1:8080/api/x
curl -v ...                详细
curl -H "H: v" ...         加 header
ping / traceroute
nslookup / dig

# 权限
chmod +x xx.sh
chmod 755 xx
chown user:group xx
sudo command

# 压缩
tar -zxvf xxx.tar.gz       解压
tar -zcvf out.tar.gz dir   打包
zip -r out.zip dir
unzip xxx.zip

# 网络下载
wget URL
curl -O URL
scp src root@host:/path
scp -r dir root@host:/path
rsync -avz src root@host:/path

# JDK 工具
java -version
jps -l                     列 Java 进程
jstack PID                 打线程栈
jmap -dump:live,format=b,file=x.hprof PID
jstat -gcutil PID 1000 10
```

---

## 附录 B：真实故障案例 2 则

### 案例 1：CPU 100% —— 循环里 println

**现象**：AI 对话接口上线一小时后 CPU 打满，页面转圈。

**排查**：
1. `top` → java 进程 CPU 780%。
2. `top -H -p pid` → tid=8931，CPU 99%。
3. `printf "%x\n" 8931` → `22e3`。
4. `jstack pid | grep -A 25 "nid=0x22e3"`：
   ```
   at java.io.PrintStream.write(PrintStream.java:526)
   at com.itcast.smart_elder.service.ChatService.stream(ChatService.java:88)
   ```
5. 打开代码：
   ```java
   flux.doOnNext(chunk -> {
       System.out.println("received: " + chunk);   // ← 每字符 println
   })
   ```
   `System.out.println` 在多线程下有内置锁，且直接写标准输出，1 万 tps 打爆 IO。

**修复**：改用 `log.debug`（生产 INFO 级别不打印），部署 → CPU 立刻回落。

**教训**：**上线前把所有 `System.out.println` 灭掉**。CR 时扫一遍。

---

### 案例 2：内存泄漏 —— 静态 Map 缓存无过期

**现象**：应用运行 3 天后 Full GC 频繁，重启后正常。

**排查**：
1. `jstat -gcutil pid 1000` 观察：Old 区从 70% 慢慢涨到 99%，Full GC 触发后只回到 95%——**回不来**。
2. `jmap -dump:live,format=b,file=/tmp/heap.hprof pid`。
3. scp 回本地用 MAT 打开 → Leak Suspects：
   ```
   80% memory used by com.itcast.smart_elder.util.CacheHolder
       └── java.util.HashMap  (2.3M entries)
   ```
4. 打开代码：
   ```java
   public class CacheHolder {
       public static Map<String, Object> cache = new HashMap<>();
   }
   ```
   业务代码里 `CacheHolder.cache.put(memberId, ...)`，从没 remove。用户越来越多，Map 越来越大。

**修复**：改成 Caffeine + `expireAfterAccess(1h) + maximumSize(10000)`：
```java
public static Cache<String, Object> cache = Caffeine.newBuilder()
    .maximumSize(10000)
    .expireAfterAccess(Duration.ofHours(1))
    .build();
```

**教训**：**任何 static 集合都可能是隐形内存黑洞**。CR 时看到 `static Map/List/Set` 就要问：**什么时候清？**

---

## 附录 C：回滚流程图（打印版）

```
                ┌──────────────┐
                │  灰度期发现异常 │
                └──────┬───────┘
                       │
              ┌────────▼────────┐
              │ ① 立即冻结新请求 │
              │    (关灰度)      │
              └────────┬────────┘
                       │
              ┌────────▼────────┐
              │ ② 通知同事      │
              │    (群里@ leader)│
              └────────┬────────┘
                       │
              ┌────────▼────────┐
              │ ③ 判断变更类型   │
              └────┬────────┬───┘
                   │        │
             [仅代码]    [含破坏性 DDL]
                   │        │
      ┌────────────▼──┐  ┌──▼───────────────┐
      │ ④ 改 tag 回滚  │  │ ④ 先备份数据库    │
      │ image v1.0.1  │  │ ⑤ 手工 undo DDL   │
      │ up -d backend │  │ ⑥ 改 tag + up -d  │
      └────────┬──────┘  └──────┬───────────┘
               │                │
               └────────┬───────┘
                        │
              ┌─────────▼─────────┐
              │ ⑦ 健康检查         │
              │  curl /api/health │
              └─────────┬─────────┘
                        │
              ┌─────────▼─────────┐
              │ ⑧ 恢复流量         │
              │  (打开负载均衡)     │
              └─────────┬─────────┘
                        │
              ┌─────────▼─────────┐
              │ ⑨ Postmortem 复盘  │
              │  24h 内出报告       │
              └───────────────────┘
```

---

## Day11 复盘

至此 Day11 讲义结束。你手上应该有：
- 3 个 shell 脚本（`start / stop / restart`）
- 1 份 systemd unit（`smart-elder.service`）
- 1 份 `application-prod.yml`
- 1 份 `logback-spring.xml`
- 1 份 `nginx.conf`
- 2 个 `Dockerfile`（后端、前端）
- 1 份 `docker-compose.yml`
- 1 份 15 项 Checklist
- 1 份 Postmortem 模板
- 1 份 Linux 常用命令速查

**串课回顾：**
- 部署时用到的 **Day01** 建表脚本、**Day02** 前后端骨架、**Day05** SSE 流式接口、**Day08** 大屏、**Day09** 操作日志、**Day10** 索引优化——今天全部整合上线。
- Day12 面试指导会把"能独立完成 Linux 部署 + Docker 容器化 + 线上故障排查 + 上线回滚"包装成简历亮点。请把今天所有产物整理成 `deploy/README.md` 提交到 Git，成为面试作品集的一部分。
