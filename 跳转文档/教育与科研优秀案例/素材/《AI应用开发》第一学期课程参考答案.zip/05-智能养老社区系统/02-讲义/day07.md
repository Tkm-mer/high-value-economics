# 《智能养老社区系统》- 学生讲义 - Day07：AI 智能体开发（Agent + Function Calling + RAG）

**授课日：Day 07 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day05 Spring AI 集成 · ChatClient · SSE 流式；Day06 客房预约 + AI 参数抽取**
**技术版本：Spring AI 1.0.0-M6 / spring-ai-alibaba-starter 1.0.0-M6.1 / qwen-plus / text-embedding-v2**

---

## 第 1 讲：AI Agent 概念与技术全景

### 1.1 本讲要点
- LLM 的 4 大天生缺陷及其对应解法
- Agent 的定义：LLM + Tools + Memory + Loop
- ReAct 循环（Reason → Act → Observe）
- Function Calling / RAG / Memory / Prompt Engineering 四大能力对比

### 1.2 知识点详解

#### 1.2.1 LLM 的四大缺陷

| 缺陷 | 直观现象 | 对应解法 |
|------|---------|---------|
| 时效性 | 不知道\"今天\"，不知道最新事件 | Function Calling（调实时 API） |
| 幻觉 | 一本正经胡编，尤其规章条款 | RAG（从权威文档检索证据） |
| 无法动手 | 只能说话，不能真下单/发邮件 | Function Calling / Tools |
| 无长期记忆 | 每次请求上下文清零 | ChatMemory（内存/Redis/DB） |

> 💡 **技巧：** 遇到业务需求时先问自己 —— \"这是知识问题、时效问题、动作问题，还是记忆问题？\" 答案直接决定用哪种能力。

#### 1.2.2 什么是 Agent

> **Agent = LLM（大脑） + Tools（手脚） + Memory（记忆） + Loop（循环）**

关键在\"循环\"：不是问一次答一次，而是可以在一次会话内多次调用工具、多次检索、然后再综合成回答。

#### 1.2.3 ReAct 循环

```
       ┌─────────────────────────────────────┐
       ▼                                     │
  ① Reason（推理）：我需要什么信息？        │
       │                                     │
       ▼                                     │
  ② Act（行动）：决定调哪个工具、参数是什么 │
       │                                     │
       ▼                                     │
  ③ Observe（观察）：拿到工具返回的结果     │
       │                                     │
       └──────────► 继续 Reason 或 输出答案
```

#### 1.2.4 Function Calling 的\"角色扮演\"本质

**LLM 并没有真的调用你的 Java 函数**。它只是：
1. 收到\"可用工具清单 + 用户 Query\"
2. 输出一段 JSON：\"我建议调 getWeather，参数 city='北京'\"
3. Spring AI 框架识别到 JSON，替 LLM \"跑腿\" 调 Java 函数
4. 把函数返回值再喂回 LLM
5. LLM 综合原 Query + 返回值 → 生成最终自然语言

> ⚠️ **注意：** 因为是\"角色扮演\"，@Description 描述得好不好，直接决定 LLM 会不会挑到这个工具。

#### 1.2.5 四大能力对比

| 能力 | 解决问题 | 数据源 | Spring AI 组件 |
|------|---------|--------|---------------|
| Function Calling | 时效 / 动作 | 你写的 Java Bean | @Bean Function + @Description |
| RAG | 知识 / 幻觉 | 内部文档 | VectorStore + QuestionAnswerAdvisor |
| Memory | 多轮 | 会话历史 | ChatMemory + MessageChatMemoryAdvisor |
| Prompt Engineering | 风格 / 人设 | System Message | .defaultSystem(...) |

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Agent | 会用工具、会记事、会自主循环的 AI |
| ReAct | Reason → Act → Observe 三步循环 |
| Function Calling | LLM 输出\"要调什么函数\"，框架执行 |
| RAG | 检索增强生成 = 先检索文档再生成回答 |
| Memory | 跨请求的会话上下文保存 |

### 1.4 示例代码/例题解析

**示例 1：用一句话判断该用哪种能力**

| 用户问题 | 该用哪种能力 |
|---------|-------------|
| \"上海今天多少度\" | Function Calling（调天气 API） |
| \"帮我看看 101 房间下周有没有空\" | Function Calling（查数据库） |
| \"跌倒后如何处理\" | RAG（查应急处置手册） |
| \"刚才我说了什么\" | Memory（读历史） |
| \"改用可爱风格再回答一次\" | Prompt Engineering |

### 1.5 课后练习
1. 【基础】用自己的话解释\"为什么 LLM 需要 Function Calling\"。
2. 【综合】给养老场景各举 2 个场景对应 4 种能力，共 8 个用例。
3. 【挑战】画一张时序图，展示"用户问天气 → LLM → Function Call → 真调 API → LLM → 用户"完整流程。

---

## 第 2 讲：Spring AI Function Calling 实战

### 2.1 本讲要点
- Function Bean 三要素：Bean 名 + @Description + 参数字段描述
- Request / Response 数据类的设计规范
- ChatClient 通过 `defaultFunctions(...)` 全局挂载工具
- 一次请求中 LLM 如何决定调不调工具

### 2.2 知识点详解

#### 2.2.1 三步走注册套路

```
Step 1  写 Request / Response 数据类（record 优先），字段用 @JsonPropertyDescription 描述
Step 2  实现 Function<Request, Response>，在 @Configuration 里 @Bean + @Description 注册
Step 3  ChatClient.builder().defaultFunctions("beanName", ...)
```

#### 2.2.2 描述文字的三层结构

| 层次 | 位置 | 目的 |
|------|------|------|
| 工具描述 | @Description 注解 | 告诉 LLM "什么情况用我" |
| 参数字段描述 | @JsonPropertyDescription | 告诉 LLM "每个字段填什么" |
| System Prompt | .defaultSystem(...) | 全局提醒 LLM "必要时使用工具" |

> 💡 **技巧：** 描述文字写成"当用户询问 xxx 时使用"这类**触发语义**，命中率显著高于"查询 xxx"这种"内部注释"式描述。

#### 2.2.3 Bean 名 = 工具名

```java
@Bean("getWeather")
@Description("...")
public GetWeatherFunction getWeather() { ... }
```

在 ChatClient 里必须一致：`.defaultFunctions("getWeather")`。若 Bean 名和字符串对不上 → 启动就报 `Function not found`。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| @Description | Spring 自带注解，被 Spring AI 识别为工具说明 |
| @JsonPropertyDescription | Jackson 注解，被 Spring AI 转成 JSON Schema 描述 |
| defaultFunctions | 全局挂载工具；也可以用 .functions(...) 单次挂载 |
| tool_choice | 部分模型支持强制/禁用工具，通义千问遵循 auto |

### 2.4 示例代码/例题解析

**示例 1：GetWeatherFunction 完整实现**
```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.extern.slf4j.Slf4j;
import java.util.function.Function;

@Slf4j
public class GetWeatherFunction
        implements Function<GetWeatherFunction.Request, GetWeatherFunction.Response> {

    public record Request(
            @JsonProperty(required = true, value = "city")
            @JsonPropertyDescription("城市名，如：北京、上海")
            String city
    ) {}

    public record Response(String city, double temperature, String suggestion) {}

    @Override
    public Response apply(Request req) {
        log.info("[GetWeatherFunction] AI 调用工具：{}", req);
        double temp = 15 + Math.random() * 15;
        String suggestion = temp < 20 ? "较凉，建议穿薄外套" : "较暖，可穿长袖";
        return new Response(req.city(), Math.round(temp * 10) / 10.0, suggestion);
    }
}
```

**示例 2：GetRoomAvailabilityFunction（业务型工具骨架）**
```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.itcast.smart_elder.mapper.RoomReservationMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.time.LocalDate;
import java.util.function.Function;

@Slf4j
@RequiredArgsConstructor
public class GetRoomAvailabilityFunction
        implements Function<GetRoomAvailabilityFunction.Request,
                             GetRoomAvailabilityFunction.Response> {

    private final RoomReservationMapper mapper;

    public record Request(
            @JsonProperty(required = true)
            @JsonPropertyDescription("客房编号，如 101、203") String roomNo,
            @JsonProperty(required = true)
            @JsonPropertyDescription("入住日期，格式 yyyy-MM-dd") String checkIn,
            @JsonProperty(required = true)
            @JsonPropertyDescription("离店日期，格式 yyyy-MM-dd") String checkOut
    ) {}

    public record Response(boolean available, String detail) {}

    @Override
    public Response apply(Request r) {
        log.info("[GetRoomAvailabilityFunction] AI 查询客房：{}", r);
        int overlap = mapper.countOverlap(r.roomNo(),
                LocalDate.parse(r.checkIn()), LocalDate.parse(r.checkOut()));
        return overlap == 0
                ? new Response(true, "客房 " + r.roomNo() + " 在该日期段可预约")
                : new Response(false, "客房 " + r.roomNo() + " 已有 " + overlap + " 个订单占用");
    }
}
```

**示例 3：QueryMemberInfoFunction**
```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.itcast.smart_elder.entity.Member;
import com.itcast.smart_elder.mapper.MemberMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.function.Function;

@Slf4j
@RequiredArgsConstructor
public class QueryMemberInfoFunction
        implements Function<QueryMemberInfoFunction.Request,
                             QueryMemberInfoFunction.Response> {

    private final MemberMapper memberMapper;

    public record Request(
            @JsonPropertyDescription("会员姓名，模糊匹配") String name,
            @JsonPropertyDescription("会员ID，精确匹配（优先）") Long memberId
    ) {}

    public record Response(String name, int age, String phone, String emergencyContact) {}

    @Override
    public Response apply(Request r) {
        log.info("[QueryMemberInfoFunction] AI 查询会员：{}", r);
        Member m = r.memberId() != null
                ? memberMapper.selectById(r.memberId())
                : memberMapper.selectByName(r.name());
        if (m == null) return new Response("未找到", 0, "", "");
        return new Response(m.getName(), m.getAge(), m.getPhone(), m.getEmergencyContact());
    }
}
```

### 2.5 课后练习
1. 【基础】给 GetWeatherFunction 增加 `date` 参数支持查询未来几天。
2. 【综合】写 GetActivityFunction，返回今日社区活动清单。
3. 【挑战】测试同一句 Query 打两个描述极度相似的工具，观察 LLM 的选择差异。

---

## 第 3 讲：智能体：健康评测 Function + 多轮记忆

### 3.1 本讲要点
- 业务型 Function：HealthAssessFunction（规则打分）
- InMemoryChatMemory + MessageChatMemoryAdvisor
- sessionId 作为多轮隔离键
- SystemMessage 里如何"教"AI 何时调健康评测工具

### 3.2 知识点详解

#### 3.2.1 健康评测的规则打分模型

| 维度 | 满分 | 计分规则 |
|------|------|---------|
| 血压 | 40 | 120/80 为基准，每偏 10mmHg 扣 5，最低 0 |
| 心率 | 20 | 60-100 满分；<50 或 >110 得 5；其余 12 |
| 睡眠 | 20 | 7-9h 满分；边缘时段递减 |
| 步数 | 10 | >6000 满分；3000-6000 得 6；<3000 得 2 |
| 慢性病 | 10 | 无 10；1种 6；2种 3；3种+ 0 |

综合等级：≥85 良好 / ≥70 关注 / ≥55 预警 / <55 危险。

> ⚠️ **注意：** 规则打分放在 Java 侧比让 LLM 自己算更**稳定可控**。LLM 擅长语义理解，不擅长精确数字运算。

#### 3.2.2 ChatMemory 的会话隔离

```
sessionId=zhang_20260709_001  →  历史消息 List<Message>
sessionId=li_20260709_002     →  历史消息 List<Message>
...
```

`MessageChatMemoryAdvisor` 每次请求：
1. **前置** 从 memory 取该 sessionId 的最近 N 条历史注入 Prompt
2. **后置** 把本轮的 user + assistant 消息 append 回 memory

#### 3.2.3 InMemoryChatMemory vs 生产替代方案

| 实现 | 特点 | 场景 |
|------|------|------|
| InMemoryChatMemory | 内存 Map，简单 | 教学 / 单机 Demo |
| RedisChatMemory (自实现) | 持久 + 多实例共享 | 生产 |
| DB (chat_message 表) | 可审计 | 需合规留痕 |

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| ChatMemory | 会话历史存储接口 |
| Advisor | Spring AI 的"拦截器/切面"，可注入/改写 Prompt |
| sessionId | 会话隔离键，前端首次进入生成 UUID |
| retrieveSize | 一次注入最近多少条历史，默认 100 太大，一般 6-10 |

### 3.4 示例代码/例题解析

**示例 1：HealthAssessFunction 完整实现**
```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.extern.slf4j.Slf4j;
import java.util.function.Function;

@Slf4j
public class HealthAssessFunction
        implements Function<HealthAssessFunction.Request, HealthAssessFunction.Response> {

    public record Request(
            @JsonProperty(required = true)
            @JsonPropertyDescription("老人年龄，单位岁")
            int age,
            @JsonProperty(required = true)
            @JsonPropertyDescription("收缩压/高压，单位 mmHg")
            int systolicBp,
            @JsonProperty(required = true)
            @JsonPropertyDescription("舒张压/低压，单位 mmHg")
            int diastolicBp,
            @JsonProperty(required = true)
            @JsonPropertyDescription("静息心率，单位 bpm")
            int heartRate,
            @JsonProperty(required = true)
            @JsonPropertyDescription("昨夜睡眠小时数")
            double sleepHours,
            @JsonProperty(required = true)
            @JsonPropertyDescription("昨日步数")
            int steps,
            @JsonPropertyDescription("慢性病，逗号分隔，无则填'无'")
            String diseases
    ) {}

    public record Response(int totalScore, String level, String detail, String advice) {}

    @Override
    public Response apply(Request r) {
        log.info("[HealthAssessFunction] AI 触发健康评测：{}", r);
        int bp = scoreBp(r.systolicBp(), r.diastolicBp());
        int hr = scoreHr(r.heartRate());
        int sl = scoreSleep(r.sleepHours());
        int st = scoreSteps(r.steps());
        int di = scoreDisease(r.diseases());
        int total = bp + hr + sl + st + di;
        String level = total >= 85 ? "良好" : total >= 70 ? "关注" : total >= 55 ? "预警" : "危险";
        String detail = String.format(
                "血压 %d/%d(%d) 心率 %d(%d) 睡眠 %.1fh(%d) 步数 %d(%d) 慢病(%d)",
                r.systolicBp(), r.diastolicBp(), bp, r.heartRate(), hr,
                r.sleepHours(), sl, r.steps(), st, di);
        return new Response(total, level, detail, buildAdvice(bp, hr, sl, st));
    }

    private int scoreBp(int s, int d) {
        int dev = Math.max(Math.abs(s - 120) / 10, Math.abs(d - 80) / 10);
        return Math.max(0, 40 - dev * 5);
    }
    private int scoreHr(int hr) {
        if (hr >= 60 && hr <= 100) return 20;
        if (hr < 50 || hr > 110) return 5;
        return 12;
    }
    private int scoreSleep(double h) {
        if (h >= 7 && h <= 9) return 20;
        if ((h >= 6 && h < 7) || (h > 9 && h <= 10)) return 15;
        if (h < 5 || h > 11) return 5;
        return 10;
    }
    private int scoreSteps(int s) { return s >= 6000 ? 10 : s >= 3000 ? 6 : 2; }
    private int scoreDisease(String d) {
        if (d == null || d.isBlank() || "无".equals(d.trim())) return 10;
        int n = d.split("[,，]").length;
        return n == 1 ? 6 : n == 2 ? 3 : 0;
    }
    private String buildAdvice(int bp, int hr, int sl, int st) {
        StringBuilder sb = new StringBuilder();
        if (bp < 25) sb.append("血压异常，建议每日测量并到社区卫生站就诊；");
        if (hr < 15) sb.append("心率异常，建议休息 10 分钟后复测；");
        if (sl < 15) sb.append("睡眠不足，建议 22:30 前入睡；");
        if (st < 10) sb.append("活动量偏低，建议早晚各 15 分钟散步；");
        if (sb.length() == 0) sb.append("整体良好，请保持当前生活习惯。");
        return sb.toString();
    }
}
```

**示例 2：InMemoryChatMemory 与 Advisor 挂载**
```java
@Bean
public ChatMemory chatMemory() {
    return new InMemoryChatMemory();
}

// 在 ChatClient.builder() 中：
.defaultAdvisors(new MessageChatMemoryAdvisor(chatMemory))
```

在 controller 里传 sessionId：
```java
.advisors(a -> a
    .param(MessageChatMemoryAdvisor.CHAT_MEMORY_CONVERSATION_ID_KEY, sessionId)
    .param(MessageChatMemoryAdvisor.CHAT_MEMORY_RETRIEVE_SIZE_KEY, 10))
```

### 3.5 课后练习
1. 【基础】增加\"血糖\"字段（空腹 mmol/L），扩展打分公式。
2. 【综合】改用 Redis 实现 ChatMemory，验证跨实例可读。
3. 【挑战】给 HealthAssessFunction 加"评分历史对比"（读 Day03 会员表的历史记录），返回趋势。

---

## 第 4 讲：向量数据库与 Embedding 基础

### 4.1 本讲要点
- Embedding：文本 → 向量（float[1536]）
- 余弦相似度 cos(A, B) = A·B / (|A|·|B|)
- 主流向量库对比：Chroma / Milvus / PGVector / SimpleVectorStore
- 阿里 text-embedding-v2 与 DashScopeEmbeddingModel 注入

### 4.2 知识点详解

#### 4.2.1 什么是 Embedding

一段文本经过 Embedding 模型后，会得到一串定长浮点数（本课 1536 维）。**语义越近，向量越近**。

```
"客房 101 每晚 300 元"       → [0.021, -0.104, 0.377, ...]  (1536 维)
"101 房间日均 300 块"          → [0.019, -0.099, 0.381, ...]  (方向几乎相同)
"今天下雨了"                   → [0.412, 0.088, -0.203, ...]  (方向大不相同)
```

#### 4.2.2 余弦相似度

```
cos(A, B) = Σ(Aᵢ × Bᵢ) / (√Σ Aᵢ² × √Σ Bᵢ²)

- 结果在 [-1, 1]，中文 embedding 一般在 [0, 1]
- 语义近似：0.85-1.0
- 相关但不同话题：0.5-0.85
- 无关：<0.5
```

> 💡 **技巧：** 生产上一般把阈值设为 0.6-0.75。低于阈值的检索结果就不注入 Prompt，避免"资料无关但硬塞"。

#### 4.2.3 向量库对比

| 向量库 | 部署难度 | 规模 | 适用场景 |
|--------|---------|------|---------|
| SimpleVectorStore | 无 | <10 万 | **教学 / 原型** |
| Chroma | pip 一装 | 百万级 | 单机小项目 |
| PGVector | Postgres 扩展 | 亿级 | 已有 PG |
| Milvus | K8s 集群 | 十亿级 | 生产/大数据 |
| Redis Stack | 已有 Redis | 千万级 | 低延迟 |

#### 4.2.4 SimpleVectorStore 内部结构

```
Map<String, EmbeddingRecord>  // key 是 document.id
    ↓
EmbeddingRecord { id, content, metadata, embedding: float[1536] }

similaritySearch(query, topK):
    1. q_vec = embed(query)
    2. for each record: cos(q_vec, record.embedding)
    3. 排序取 topK
```

内存 Map + JSON 持久化 = 教学利器。

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Embedding | 文本 → 定长向量 |
| Dimension | 维度，由模型固定，text-embedding-v2 = 1536 |
| Cosine Similarity | 余弦相似度，忽略长度只看方向 |
| VectorStore | 存向量 + 支持相似检索的存储 |

### 4.4 示例代码/例题解析

**示例 1：EmbeddingModel 配置**
```yaml
spring:
  ai:
    dashscope:
      api-key: ${DASHSCOPE_API_KEY}
      chat:
        options:
          model: qwen-plus
      embedding:
        options:
          model: text-embedding-v2
```

**示例 2：现场验证向量的接口**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/ai/embed")
@RequiredArgsConstructor
public class EmbeddingDemoController {

    private final EmbeddingModel embeddingModel;

    @GetMapping
    public Result<Map<String, Object>> embed(@RequestParam String text) {
        float[] vec = embeddingModel.embed(text);
        Map<String, Object> r = new HashMap<>();
        r.put("dim", vec.length);
        r.put("first10", Arrays.copyOfRange(vec, 0, 10));
        return Result.success(r);
    }

    @GetMapping("/sim")
    public Result<Double> sim(@RequestParam String a, @RequestParam String b) {
        return Result.success(cos(embeddingModel.embed(a), embeddingModel.embed(b)));
    }

    private double cos(float[] a, float[] b) {
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            na += a[i] * a[i];
            nb += b[i] * b[i];
        }
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
}
```

**示例 3：手算余弦相似度**

| 向量 A | 向量 B | 点积 A·B | \|A\| | \|B\| | cos |
|--------|--------|---------|-----|-----|-----|
| (3, 4) | (6, 8) | 50 | 5 | 10 | 1.0 |
| (1, 0) | (0, 1) | 0 | 1 | 1 | 0.0 |
| (1, 0) | (-1, 0) | -1 | 1 | 1 | -1.0 |

### 4.5 课后练习
1. 【基础】测试 5 组"意思相近"和 5 组"意思无关"的相似度，统计阈值分布。
2. 【综合】把中文 embedding 换成 text-embedding-v3（如果开通了）比较维度和速度差异。
3. 【挑战】阅读 SimpleVectorStore 源码，理解 similaritySearch 的实现细节。

---

## 第 5 讲：RAG 检索增强生成实战

### 5.1 本讲要点
- RAG 五步流程：Load → Split → Embed → Store → Retrieve
- TextReader / TokenTextSplitter / VectorStore.add / QuestionAnswerAdvisor
- SimpleVectorStore 的 JSON 持久化（避免重启烧钱）
- 内部知识库文档规划（护理/应急/收费/活动）

### 5.2 知识点详解

#### 5.2.1 RAG 完整流程图

```
     离线构建阶段（KnowledgeInitializer）
┌───────────────────────────────────────────────┐
│ resources/docs/*.md                           │
│    │                                          │
│    ▼   ① Load                                │
│ TextReader → List<Document>                   │
│    │                                          │
│    ▼   ② Split                                │
│ TokenTextSplitter (chunkSize=800, overlap=350) │
│    │                                           │
│    ▼   ③ Embed + ④ Store                      │
│ vectorStore.add(chunks) ─→ SimpleVectorStore   │
│    │                                          │
│    ▼   持久化                                 │
│ ./data/vector-store.json                      │
└───────────────────────────────────────────────┘

     在线检索阶段（每次用户提问自动触发）
┌────────────────────────────────────────────┐
│ 用户 Query                                 │
│    │                                       │
│    ▼   QuestionAnswerAdvisor 拦截          │
│ ⑤ Retrieve                                │
│  similaritySearch(topK=3, threshold=0.6)   │
│    │                                       │
│    ▼                                       │
│ 拼进 System Prompt 上下文                  │
│    │                                       │
│    ▼                                       │
│ LLM 生成回答（引用检索到的资料）           │
└────────────────────────────────────────────┘
```

#### 5.2.2 切片参数调优

| 参数 | 太小 | 太大 |
|------|------|------|
| chunkSize | 语义断裂，一句话被切两半 | 上下文稀释，命中率高但内容不精准 |
| overlap | 边界信息丢失 | 冗余存储 |
| topK | 覆盖不全 | Token 浪费 + LLM 注意力分散 |

**养老院知识库经验值：** chunkSize=800, overlap=350, topK=3, threshold=0.6。

#### 5.2.3 QuestionAnswerAdvisor 的自动化流水线

```
用户 Prompt 到达
      │
      ▼
[QuestionAnswerAdvisor.before()]
      │
      ├─ query = extractText(userMessage)
      ├─ docs  = vectorStore.similaritySearch(query, topK, threshold)
      ├─ ctx   = "以下资料可作为参考：\n[1] ...\n[2] ...\n"
      └─ 把 ctx 插到 SystemMessage 后
      │
      ▼
调用 ChatModel（此时 Prompt 已含参考资料）
      │
      ▼
[QuestionAnswerAdvisor.after()]
      │
      └─ 把 docs 的 metadata 放进 chatResponse.metadata
```

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Document | Spring AI 的文档抽象，含 content + metadata |
| TokenTextSplitter | 按 token 数切片（不是字符数） |
| SimpleVectorStore | 内存 + JSON 持久化的向量库 |
| QuestionAnswerAdvisor | Spring AI 内置的 RAG 检索 Advisor |
| SearchRequest | 相似检索请求，含 topK 与 threshold |

### 5.4 示例代码/例题解析

**示例 1：SimpleVectorStore Bean 配置**
```java
package com.itcast.smart_elder.ai.config;

import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class VectorStoreConfig {

    @Bean
    public VectorStore vectorStore(EmbeddingModel embeddingModel) {
        return new SimpleVectorStore(embeddingModel);
    }
}
```

**示例 2：KnowledgeInitializer 完整代码**
```java
package com.itcast.smart_elder.ai.rag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import java.io.File;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class KnowledgeInitializer implements CommandLineRunner {

    private final VectorStore vectorStore;

    @Value("${knowledge.store-path:./data/vector-store.json}")
    private String storePath;

    @Override
    public void run(String... args) throws Exception {
        SimpleVectorStore store = (SimpleVectorStore) vectorStore;
        File f = new File(storePath);

        if (f.exists()) {
            store.load(f);
            log.info("[Knowledge] 从 {} 加载现有向量库", storePath);
            return;
        }

        Resource[] resources = new PathMatchingResourcePatternResolver()
                .getResources("classpath:docs/*.md");
        TokenTextSplitter splitter = new TokenTextSplitter();
        int total = 0;
        for (Resource res : resources) {
            log.info("[Knowledge] 加载文档：{}", res.getFilename());
            TextReader reader = new TextReader(res);
            reader.getCustomMetadata().put("source", res.getFilename());
            List<Document> chunks = splitter.apply(reader.get());
            store.add(chunks);
            total += chunks.size();
        }

        f.getParentFile().mkdirs();
        store.save(f);
        log.info("[Knowledge] 已入库 {} 段，持久化 {}", total, storePath);
    }
}
```

**示例 3：ChatClient 上挂 QuestionAnswerAdvisor**
```java
@Bean
public ChatClient agentChatClient(ChatClient.Builder builder,
                                   VectorStore vectorStore,
                                   ChatMemory chatMemory) {
    return builder
            .defaultSystem("""
                    你是"金秋家园"智能养老助手"小金"。
                    - 遇到需要查实时业务数据时使用工具（Function）
                    - 遇到护理/应急/收费/活动等问题请优先引用检索到的资料
                    - 回答不超过 200 字，语气温柔耐心
                    """)
            .defaultFunctions("getWeather", "getRoomAvailability",
                              "queryMemberInfo", "healthAssess")
            .defaultAdvisors(
                    new QuestionAnswerAdvisor(vectorStore,
                            SearchRequest.defaults().withTopK(3).withSimilarityThreshold(0.6)),
                    new MessageChatMemoryAdvisor(chatMemory))
            .build();
}
```

**示例 4：护理知识库文档样例 `docs/care-emergency.md`**
```markdown
# 应急处置

## 老人跌倒
1. 立即按呼叫铃或拨打 120
2. 判断意识：轻拍双肩、大声呼喊
3. 不要轻易搬动，尤其疑似骨折时
4. 注意保暖，覆盖薄毯
5. 等待专业人员到场

## 呛咳/异物梗阻
1. 保持镇静，鼓励咳嗽
2. 严重时使用海姆立克急救法
3. 无意识者立即心肺复苏
```

### 5.5 课后练习
1. 【基础】写 3 篇知识库 md：日常护理、应急处置、收费标准。
2. 【综合】把切片 chunkSize 改成 300/1500，观察检索命中的差异。
3. 【挑战】给 vector-store.json 加"版本号"字段，实现文档增量入库检测。
## 第 6 讲：智能体前端联调（agent.vue）

### 6.1 本讲要点
- 复用 Day05 的聊天气泡样式，新建独立菜单 `/ai/agent`，与 `chat.vue` 并列。
- 前端保持 `sessionId`，实现多轮对话；`localStorage` 持久化。
- 后端返回 `tool_calls` 时前端渲染 🔧 徽章；返回 `sources` 时渲染 📚 引用小卡。
- 完成端到端联调：健康评测（Function Calling）+ 护理问答（RAG）+ 多轮记忆。

### 6.2 详解

**（1）为什么单独一个页面而不是复用 chat.vue？**

- Day05 的 `chat.vue` 是"通用聊天"，走 `/api/ai/chat` 接口，无工具、无知识库。
- 本讲的 `agent.vue` 走 `/api/ai/agent` 接口，返回结构里多了 `tool_calls`、`sources` 字段，UI 需要额外渲染。
- 把两个页面分开，一是不污染原来的通用聊天；二是让学员看清"智能体"和"普通对话"的差别。

**（2）sessionId 的作用**

后端用 `sessionId` 作为 `ChatMemory` 的隔离键：
- 同一个 `sessionId` → 同一段历史 → 可以说"我刚才问的那个人"。
- 不同 `sessionId` → 各聊各的。

前端策略：
```js
// 页面加载时读取
let sid = localStorage.getItem('agent_sid')
if (!sid) {
  sid = 'sid-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8)
  localStorage.setItem('agent_sid', sid)
}
```

用户点"新对话"按钮时，清空 `localStorage` 中的 `agent_sid`，前端消息列表也清空。

**（3）响应结构约定**

```json
{
  "code": 200,
  "data": {
    "reply": "王大爷（88 岁）血压 165/98…",
    "tool_calls": [
      { "name": "healthAssess", "args": {"age":88,"sbp":165,"dbp":98} }
    ],
    "sources": [
      { "title": "老年高血压护理.md", "score": 0.87, "snippet": "血压≥160…" }
    ]
  }
}
```

前端拿到后：
- `reply` → 气泡正文；
- `tool_calls` 非空 → 在气泡上方加 🔧 徽章 "已调用工具：healthAssess"；
- `sources` 非空 → 气泡下方展开 📚 引用列表。

### 6.3 完整代码

**示例 1：API 封装 `src/api/agent.ts`**

```typescript
import request from '@/utils/request'

export interface AgentReply {
  reply: string
  tool_calls?: Array<{ name: string; args: Record<string, any> }>
  sources?: Array<{ title: string; score: number; snippet: string }>
}

/** 智能体问答 */
export function askAgent(sessionId: string, message: string) {
  return request<AgentReply>({
    url: '/ai/agent',
    method: 'post',
    data: { sessionId, message }
  })
}
```

**示例 2：菜单 + 路由**

`src/router/index.ts` 追加：
```typescript
{
  path: '/ai/agent',
  name: 'AiAgent',
  component: () => import('@/views/ai/agent.vue'),
  meta: { title: '养老智能体', icon: 'robot' }
}
```

侧边栏菜单（`Layout` 中）：
```html
<el-menu-item index="/ai/chat">💬 智能问答</el-menu-item>
<el-menu-item index="/ai/agent">🤖 养老智能体</el-menu-item>
```

**示例 3：`src/views/ai/agent.vue` 完整代码**

```vue
<template>
  <div class="agent-page">
    <div class="header">
      <h3>🤖 智能养老助手</h3>
      <el-button size="small" @click="onNewChat">新对话</el-button>
      <span class="sid">会话：{{ shortSid }}</span>
    </div>

    <div class="chat-box" ref="boxRef">
      <div v-for="(m, i) in messages" :key="i"
           :class="['bubble', m.role]">
        <!-- 工具徽章 -->
        <div class="tool-badge" v-if="m.tool_calls?.length">
          🔧 已调用工具：
          <el-tag v-for="tc in m.tool_calls" :key="tc.name" size="small">
            {{ tc.name }}
          </el-tag>
        </div>

        <div class="text" v-html="renderMd(m.content)"></div>

        <!-- 引用来源 -->
        <div class="sources" v-if="m.sources?.length">
          <div class="src-title">📚 参考资料</div>
          <div v-for="(s, si) in m.sources" :key="si" class="src-card">
            <div class="src-head">
              <span class="src-name">{{ s.title }}</span>
              <span class="src-score">相关度 {{ (s.score * 100).toFixed(0) }}%</span>
            </div>
            <div class="src-snippet">{{ s.snippet }}</div>
          </div>
        </div>
      </div>

      <div v-if="loading" class="bubble ai loading">思考中…</div>
    </div>

    <div class="input-row">
      <el-input
        v-model="input"
        placeholder="请输入问题，比如：王大爷 88 岁血压 165/98，如何护理？"
        @keyup.enter="onSend"
        clearable
      />
      <el-button type="primary" :loading="loading" @click="onSend">
        发送
      </el-button>
    </div>
  </div>
</template>

```vue
<script setup lang="ts">
import { ref, computed, nextTick, onMounted } from 'vue'
import { askAgent } from '@/api/agent'
import { marked } from 'marked'

interface Msg {
  role: 'user' | 'ai'
  content: string
  tool_calls?: Array<{ name: string; args: any }>
  sources?: Array<{ title: string; score: number; snippet: string }>
}

const messages = ref<Msg[]>([])
const input = ref('')
const loading = ref(false)
const boxRef = ref<HTMLElement>()

// —— sessionId 管理 ——
const sid = ref('')
function ensureSid() {
  let s = localStorage.getItem('agent_sid')
  if (!s) {
    s = 'sid-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8)
    localStorage.setItem('agent_sid', s)
  }
  sid.value = s
}
const shortSid = computed(() => sid.value.slice(-6))

function onNewChat() {
  localStorage.removeItem('agent_sid')
  ensureSid()
  messages.value = []
}

// —— 发送消息 ——
async function onSend() {
  const text = input.value.trim()
  if (!text || loading.value) return
  input.value = ''
  messages.value.push({ role: 'user', content: text })
  loading.value = true
  await scrollBottom()

  try {
    const resp = await askAgent(sid.value, text)
    messages.value.push({
      role: 'ai',
      content: resp.data.reply,
      tool_calls: resp.data.tool_calls,
      sources: resp.data.sources
    })
  } catch (e: any) {
    messages.value.push({ role: 'ai', content: '⚠️ 出错了：' + e.message })
  } finally {
    loading.value = false
    await scrollBottom()
  }
}

function renderMd(text: string) {
  return marked.parse(text || '')
}

async function scrollBottom() {
  await nextTick()
  if (boxRef.value) {
    boxRef.value.scrollTop = boxRef.value.scrollHeight
  }
}

onMounted(() => { ensureSid() })
</script>

<style scoped>
.agent-page { display: flex; flex-direction: column; height: calc(100vh - 60px); padding: 12px; }
.header { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
.header h3 { flex: none; margin: 0; }
.sid { color: #999; font-size: 12px; }
.chat-box { flex: 1; overflow-y: auto; background: #fafafa; padding: 12px; border-radius: 8px; }
.bubble { max-width: 78%; margin: 8px 0; padding: 10px 14px; border-radius: 10px; line-height: 1.6; }
.bubble.user { background: #d4f1ff; margin-left: auto; }
.bubble.ai   { background: #fff; border: 1px solid #eee; }
.bubble.loading { color: #999; font-style: italic; }
.tool-badge { font-size: 12px; color: #666; margin-bottom: 6px; }
.tool-badge .el-tag { margin: 0 4px; }
.sources { margin-top: 10px; border-top: 1px dashed #ddd; padding-top: 8px; }
.src-title { font-size: 12px; color: #666; margin-bottom: 4px; }
.src-card { background: #f5f7fa; padding: 6px 8px; border-radius: 6px; margin: 4px 0; font-size: 12px; }
.src-head { display: flex; justify-content: space-between; }
.src-name { font-weight: 600; }
.src-score { color: #67c23a; }
.src-snippet { color: #666; margin-top: 2px; }
.input-row { display: flex; gap: 8px; margin-top: 8px; }
</style>
```

### 6.4 联调步骤

1. 启动后端 `SpringBoot`（8080），确认 Day07 三个接口都能 curl 通。
2. 启动前端 `pnpm dev`，浏览器打开 `http://localhost:3000/ai/agent`。
3. 依次测试：
   - **健康评测（Function）**：输入 "王大爷 88 岁，血压 165/98"。观察气泡上方出现 🔧 `healthAssess` 徽章。
   - **护理问答（RAG）**：输入 "老人跌倒怎么办？" 观察气泡下方出现 📚 引用小卡片，含文档名和相关度。
   - **多轮记忆**：连续问 "他年龄多大？"（引用上文的"王大爷"），确认能答上。
4. 点击"新对话"，看 `sessionId` 变化、历史清空。

### 6.5 常见问题排查

| 现象 | 排查方向 |
|---|---|
| 前端 CORS 报错 | `vite.config.ts` 里加 `proxy: { '/api': 'http://localhost:8080' }` |
| 徽章不显示 | 后端 `AgentController` 是否把 `tool_calls` 塞进 `data` 里 |
| sessionId 每次都变 | 检查 `localStorage.getItem` 是否被开发者工具关掉了 |
| RAG 检索无结果 | 确认 `vector-store.json` 生成成功、`docs/*.md` 至少有 1 篇 |
| 多轮丢上下文 | 后端 `ChatMemory` 是否按 `sessionId` 分片；`.window(10)` 是否够 |

### 6.6 课后练习
1. 【基础】把新对话按钮改成"确认弹窗"，防止误清历史。
2. 【综合】给 agent.vue 加"消息复制"按钮：点击一条 AI 回复复制文本到剪贴板。
3. 【挑战】把 `messages` 也持久化到 `localStorage`（按 sessionId 分 key），刷新页面不丢历史。

---

## Day07 总结与回顾

### 一、今日 5 大能力

| # | 能力 | 落地文件 |
|---|------|---------|
| 1 | Function Calling（工具调用） | `HealthAssessFunction.java` |
| 2 | 多轮记忆 ChatMemory | `AgentController` + `InMemoryChatMemory` |
| 3 | 向量数据库 + Embedding | `EmbeddingConfig`、`SimpleVectorStore` |
| 4 | RAG 检索增强 | `KnowledgeService` + `docs/*.md` |
| 5 | 前端联调 | `agent.vue` + `agent.ts` |

### 二、环境自检清单

- [ ] `application.yml` 中 `dashscope.api-key` 已配置且不带引号污染
- [ ] `pom.xml` 引入 `spring-ai-alibaba-starter`、`spring-ai-core`
- [ ] `docs/` 目录至少 3 篇 md 且已首次跑 `EmbeddingRunner` 生成 `vector-store.json`
- [ ] `SimpleVectorStore` 单例在 Bean 容器中
- [ ] Vue 路由 `/ai/agent` 可访问，与 `/ai/chat` 并列

### 三、预告 Day08

Day08 将进入"数据可视化 & 复杂报表 SQL"：
- Echarts 大屏（4 卡片 + 4 图表）
- 分组统计 SQL（GROUP BY + WITH ROLLUP）
- Redis 缓存报表结果，命中率优化

---
