# 《智能养老社区系统》- 学生讲义 - Day02：前后端分离项目搭建与 Vue3 模板生成

**授课日：Day 02 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**后端包名：com.itcast.smart_elder**
**前端项目名：smart-elder-web**

---

## 第 1 讲：前后端分离架构与项目结构

### 1.1 本讲要点
- 传统 JSP 模式与前后端分离模式的差异
- RESTful 接口规范（HTTP 方法 + URL 名词）
- Maven 单模块项目结构（本项目采用）
- 分层职责：controller / service / mapper / entity / dto / vo
- 前后端分离下的部署形态

### 1.2 知识点详解

#### 1.2.1 什么是前后端分离
传统 JSP 项目一个 `.jsp` 文件里既有 HTML 又有 Java 代码，前后端工程师必须挤在同一个文件里"打架"；一旦要给 App/小程序共用一份数据，就无从下手。前后端分离把这层"渲染 UI"的职责整体挪到浏览器，后端只负责一件事——**返回 JSON**。

| 对比项 | 传统 JSP | 前后端分离 |
|--------|----------|------------|
| 渲染 | Tomcat 服务端渲染 | 浏览器渲染 |
| 部署包 | 一个 war | 前端静态资源 + 后端 jar |
| 交互协议 | 页面跳转/表单 | HTTP + JSON |
| 前端语言 | HTML+JSP+JS | Vue3 + TypeScript |
| 移动端 | 难复用 | 后端接口通用 |

> 💡 **技巧：** 只要浏览器/App/小程序都通过 `HTTP + JSON` 找后端，就是前后端分离。

> ⚠️ **注意：** 前后端分离≠一定要多个仓库。本课程为便于学习，前端 `smart-elder-web` 与后端 `smart-elder-server` 放在同一个父目录 `smart-elder/` 下，共用一个 git 仓库。

#### 1.2.2 RESTful 接口规范

REST 用**名词做 URL、动词用 HTTP 方法**，例如对会员资源的 5 种操作：

| HTTP 方法 | 语义 | URL 示例 |
|----------|------|----------|
| GET | 查询列表 | `GET /api/member/page?pageNum=1&pageSize=10` |
| GET | 查询单条 | `GET /api/member/{id}` |
| POST | 新增 | `POST /api/member` |
| PUT | 修改 | `PUT /api/member` |
| DELETE | 删除 | `DELETE /api/member/{id}` |

#### 1.2.3 分层职责

- **controller**：接 HTTP 请求，做参数校验，调 service，包 `Result` 返回；不写业务；
- **service**：核心业务逻辑，事务边界；
- **mapper**：只做 SQL，一个方法一句 SQL；
- **entity**：与数据库表 1:1；
- **dto**：前端 → 后端的入参；
- **vo**：后端 → 前端的出参。

> 💡 **技巧：** 记住口诀"入 DTO、出 VO、库 entity"。

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 前后端分离 | 前端出 HTML/CSS/JS，后端出 JSON |
| RESTful | 名词做 URL，动词用 HTTP 方法 |
| 单模块 | 一个 pom.xml 一个 src；靠包名分层 |
| DTO | 数据传输对象，前端 → 后端入参 |
| VO | 视图对象，后端 → 前端出参 |

### 1.4 示例代码/例题解析

**示例 1：一个 RESTful 会员接口设计（先看看长啥样，后面几天会真的写它）**

```
GET    /api/member/page?pageNum=1&pageSize=10&name=张
GET    /api/member/1
POST   /api/member      {name:"张三", phone:"..."}
PUT    /api/member      {id:1, name:"李四"}
DELETE /api/member/1
```

统一返回：
```json
{ "code": 200, "msg": "ok", "data": { ... } }
```

### 1.5 课后练习
1. 【基础】为 `elder_room` 表设计 5 个 RESTful URL。
2. 【综合】画出前后端分离下"用户点击会员列表 → 数据到达浏览器"的时序图。
3. 【挑战】DTO 和 VO 都是普通 Java 类，为什么不用一个类同时承担两种职责？

---

## 第 2 讲：SpringBoot 后端骨架搭建

### 2.1 本讲要点
- 使用 IDEA Spring Initializr 创建项目
- pom.xml 核心依赖坐标
- application.yml 三段式配置
- 统一返回 `Result<T>`
- 分页封装 `PageBean<T>`

### 2.2 知识点详解

#### 2.2.1 Spring Initializr 参数
- Group：`com.itcast`
- Artifact：`smart-elder-server`
- Package：`com.itcast.smart_elder`
- JDK：17
- Spring Boot：3.2.5
- 初始依赖只勾 `Spring Web`、`Lombok`，其余在 pom 手加。

#### 2.2.2 pom.xml 关键依赖

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.2.5</version>
</parent>

<properties>
    <java.version>17</java.version>
    <mybatis-plus.version>3.5.7</mybatis-plus.version>
    <knife4j.version>4.5.0</knife4j.version>
</properties>

<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-spring-boot3-starter</artifactId>
        <version>${mybatis-plus.version}</version>
    </dependency>
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-jsqlparser</artifactId>
        <version>${mybatis-plus.version}</version>
    </dependency>
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
        <scope>runtime</scope>
    </dependency>
    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>druid-spring-boot-3-starter</artifactId>
        <version>1.2.23</version>
    </dependency>
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>
    <dependency>
        <groupId>com.github.xiaoymin</groupId>
        <artifactId>knife4j-openapi3-jakarta-spring-boot-starter</artifactId>
        <version>${knife4j.version}</version>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

> ⚠️ **注意：** Spring Boot 3.x 只能配 `mybatis-plus-spring-boot3-starter`，用旧的 `mybatis-plus-boot-starter` 会因 Jakarta / Javax 命名冲突而启动失败。

#### 2.2.3 application.yml

```yaml
server:
  port: 8080

spring:
  application:
    name: smart-elder-server
  datasource:
    type: com.alibaba.druid.pool.DruidDataSource
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://127.0.0.1:3306/smart_elder?useUnicode=true&characterEncoding=UTF-8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
    username: root
    password: 123456
    druid:
      initial-size: 5
      min-idle: 5
      max-active: 20

mybatis-plus:
  mapper-locations: classpath*:/mapper/**/*.xml
  type-aliases-package: com.itcast.smart_elder.entity
  configuration:
    map-underscore-to-camel-case: true
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
  global-config:
    db-config:
      id-type: auto
      logic-delete-field: deleted
      logic-delete-value: 1
      logic-not-delete-value: 0

logging:
  level:
    com.itcast.smart_elder: debug
```

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| starter | Spring Boot 依赖聚合包，一个 starter 引入一系列依赖 |
| Druid | 阿里连接池，自带监控 |
| Result<T> | 统一返回，泛型 T 是业务数据 |
| PageBean<T> | 分页返回：total + rows |

### 2.4 示例代码/例题解析

**示例 1：Result 通用返回类**
```java
package com.itcast.smart_elder.common;

import lombok.Data;
import java.io.Serializable;

@Data
public class Result<T> implements Serializable {
    private Integer code;
    private String  msg;
    private T       data;

    public static <T> Result<T> success() { return success(null); }

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.setCode(200);
        r.setMsg("ok");
        r.setData(data);
        return r;
    }

    public static <T> Result<T> error(String msg) { return error(500, msg); }

    public static <T> Result<T> error(Integer code, String msg) {
        Result<T> r = new Result<>();
        r.setCode(code);
        r.setMsg(msg);
        return r;
    }
}
```

**示例 2：PageBean 分页封装**
```java
package com.itcast.smart_elder.common;

import lombok.*;
import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageBean<T> implements Serializable {
    private Long    total;
    private List<T> rows;
}
```

**示例 3：启动类**
```java
package com.itcast.smart_elder;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.itcast.smart_elder.mapper")
public class SmartElderApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartElderApplication.class, args);
    }
}
```

### 2.5 课后练习
1. 【基础】给 `Result` 添加 `success(String msg, T data)` 重载。
2. 【综合】阅读 `spring-boot-starter-web` 的 pom，找出它传递依赖了哪些包（提示：spring-mvc、jackson、tomcat-embed）。
3. 【挑战】把 druid 换成默认 HikariCP，观察启动区别。

---

## 第 3 讲：MyBatis-Plus 与数据库连接

### 3.1 本讲要点
- MyBatis-Plus 三大注解：`@TableName` `@TableId` `@TableField`
- 继承 `BaseMapper<T>` 立刻拥有 17 个 CRUD
- 分页插件 `PaginationInnerInterceptor` 必须手动注册
- `map-underscore-to-camel-case`：下划线 <=> 驼峰
- Druid 数据源与监控页

### 3.2 知识点详解

#### 3.2.1 三大注解
| 注解 | 位置 | 作用 | 示例 |
|------|------|------|------|
| `@TableName` | 类上 | 数据库表名 | `@TableName("elder_member")` |
| `@TableId` | 主键字段 | 主键策略 | `@TableId(type = IdType.AUTO)` |
| `@TableField` | 普通字段 | 列名/自动填充/不存在 | `@TableField(fill = FieldFill.INSERT)` |

#### 3.2.2 BaseMapper 核心方法
```
selectById(id)              // 根据主键查询
selectList(Wrapper)         // 条件列表
selectPage(Page, Wrapper)   // 分页
insert(entity)              // 新增
updateById(entity)          // 根据主键更新
deleteById(id)              // 根据主键删除
```

#### 3.2.3 分页插件配置类
如果不注册插件，`selectPage` 会静默失效——SQL 里没有 LIMIT，只 count 出总数返回。

```java
@Configuration
public class MyBatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
```

> ⚠️ **注意：** 3.5.7 版本使用 MySQL 分页需要额外引入 `mybatis-plus-jsqlparser`。

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| Wrapper | 条件构造器，链式 API 拼 WHERE |
| IdType.AUTO | 数据库自增主键 |
| logic-delete-field | 逻辑删除字段名（本项目为 deleted） |
| FieldFill | 自动填充：INSERT / UPDATE / INSERT_UPDATE |

### 3.4 示例代码/例题解析

**示例 1：Member 实体**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("elder_member")
public class Member {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String realName;
    private String phone;
    private Integer gender;
    private LocalDate birthday;
    private String idCard;
    private String address;
    private Integer status;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    private Integer deleted;
}
```

**示例 2：MemberMapper 与测试**
```java
package com.itcast.smart_elder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itcast.smart_elder.entity.Member;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberMapper extends BaseMapper<Member> {
}
```

```java
@SpringBootTest
class MemberMapperTest {
    @Autowired MemberMapper mapper;

    @Test
    void testSelectList() {
        List<Member> list = mapper.selectList(null);
        list.forEach(System.out::println);
    }
}
```

原理解释：`@MapperScan` 让 Spring 在启动时扫描 mapper 包，把接口生成代理 Bean 交给容器。测试类里 `@Autowired` 拿到的其实是 MyBatis 生成的 `MapperProxy`。

### 3.5 课后练习
1. 【基础】按同样套路建 `Room` 实体（对应 `elder_room` 表）。
2. 【综合】用 `QueryWrapper<Member>().eq("status", 1).like("real_name", "张")` 查满足条件的会员。
3. 【挑战】自己实现一个 `MetaObjectHandler` 让 `createTime` / `updateTime` 自动填当前时间。

---

## 第 4 讲：通义灵码使用与 Vue3 项目模板

### 4.1 本讲要点
- 通义灵码是阿里出品的免费 AI 编程助手（IDEA / VS Code 插件）
- 五大核心功能：代码解释、代码生成、单元测试、@workspace、@terminal
- 用通义灵码生成 Vue3 + Vite 脚手架命令
- AI 生成命令必须人工复核，别被"幻觉"误导

### 4.2 知识点详解

#### 4.2.1 通义灵码基本信息
- 中文名：通义灵码；英文名：TONGYI Lingma
- 出品：阿里云
- 支持 IDE：IDEA、VS Code、Visual Studio、PyCharm、WebStorm
- 收费：个人开发者免费，需登录阿里云账号
- 官网：https://tongyi.aliyun.com/lingma

#### 4.2.2 插件安装截图描述

- **IDEA**：`File → Settings → Plugins → Marketplace`，搜索 `TONGYI Lingma`，点击 `Install`，重启 IDEA；重启后右下角状态栏可看到一个绿色 "通义灵码" 图标；点击后弹出登录窗口，选择"支付宝扫码"或"钉钉扫码"完成登录。登录成功后 IDEA 右侧边栏出现 "TONGYI Lingma" 侧栏（一个圆形对话气泡图标）。
- **VS Code**：左侧扩展市场（Ctrl+Shift+X）搜索 `TONGYI Lingma`，安装后左侧栏出现同款蓝紫色图标，点击进入对话面板；顶部有个 `Login` 按钮，扫码登录。登录后底部状态栏出现 "Lingma is ready" 字样。

#### 4.2.3 五大功能

| 功能 | 快捷调用 | 典型场景 |
|------|---------|----------|
| 代码解释 | 选中代码 → 右键 → 通义灵码 → 解释代码 | 看别人写的 SQL 或复杂正则 |
| 代码生成 | 方法上写自然语言注释 → 回车 | 快速写 controller CRUD |
| 单元测试生成 | 右键类名 → 生成单元测试 | 覆盖 service 层 |
| @workspace 项目问答 | 侧栏输入 `@workspace ...` | 跨文件定位实现 |
| @terminal 命令生成 | 侧栏输入 `@terminal ...` | 生成 npm/git/mvn 命令 |

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| AI 幻觉 | AI 编造出看起来对但实际不存在的 API、路径、版本号 |
| Prompt | 给 AI 的自然语言指令，越具体越好 |
| @workspace | 让 AI 阅读整个项目文件后回答 |
| @terminal | 让 AI 生成可复制粘贴的终端命令 |

### 4.4 示例代码/例题解析

**5 个可复现的 Prompt 示例（照着往通义灵码侧栏粘）：**

**Prompt 1：生成 Vite 脚手架命令**
```
@terminal 我想在 D:\smart-elder\ 目录下用 Vite 创建一个 Vue3 + TypeScript 的项目，
项目名 smart-elder-web，给我完整命令，并解释交互式选项应该怎么选。
```
预期输出：
```bash
cd /d D:\smart-elder
npm create vite@latest smart-elder-web -- --template vue-ts
cd smart-elder-web
npm install
```

**Prompt 2：切换到 pnpm**
```
@terminal 我不想用 npm，我想改用 pnpm。请给我 Windows 下用 npm 安装 pnpm 全局的命令，
再演示把上一步的 npm install 换成 pnpm 的命令。
```
预期输出：
```bash
npm install -g pnpm
cd smart-elder-web
Remove-Item -Recurse -Force node_modules, package-lock.json
pnpm install
```

**Prompt 3：项目目录规划**
```
帮我规划一个 Vue3 + TypeScript + Pinia + Vue Router 4 + Element Plus + axios
的企业级前端项目目录，包含 src/api、src/views、src/components、src/router、
src/stores、src/utils 六个子目录，请说明每个目录的用途。
```

**Prompt 4：依赖清单**
```
帮我列出 package.json 需要 pnpm add 的所有依赖（生产 + 开发），
并说明每个依赖的版本推荐。
```
预期输出：
```bash
pnpm add vue-router@4 pinia axios element-plus @element-plus/icons-vue
pnpm add -D unplugin-auto-import unplugin-vue-components sass
```

**Prompt 5：生成 vite.config.ts**
```
帮我写一个 vite.config.ts：
1) 端口固定 5173；
2) @ 指向 src；
3) /api 代理到 http://localhost:8080，去掉 /api 前缀；
4) 使用 unplugin-auto-import 和 unplugin-vue-components 按需引入 Element Plus。
```

> 💡 **技巧：** Prompt 越具体，命令越可跑。写清路径、版本、目标。

> ⚠️ **注意：** AI 常见幻觉：把 Element Plus 版本写成 `1.x`（实际 2.x）、把 `rewrite` 写成 `pathRewrite`（那是 vue-cli 的写法）——每条命令都要肉眼过一遍。

### 4.5 课后练习
1. 【基础】把 Prompt 1 的项目名换成 `elder-admin`，让通义灵码重新给命令。
2. 【综合】写一条 Prompt 让通义灵码检查你本机 Node.js 版本，若低于 18 就报错退出。
3. 【挑战】用 `@workspace` 问它："项目里有没有 `Result` 类？它在哪个包？" 看它能不能定位到。

---

## 第 5 讲：Vue3 + Vite + Element Plus 环境

### 5.1 本讲要点
- 使用 pnpm 安装依赖
- Vite 配置：alias / server.proxy / 按需引入插件
- Element Plus 通过 `unplugin-auto-import` + `unplugin-vue-components` 按需引入
- Vue Router 4 基本用法
- Pinia 状态管理
- axios 封装 `request.ts`（含请求/响应拦截器）

### 5.2 知识点详解

#### 5.2.1 依赖清单
```bash
pnpm add vue-router@4 pinia axios element-plus @element-plus/icons-vue
pnpm add -D unplugin-auto-import unplugin-vue-components sass
```

#### 5.2.2 vite.config.ts
```typescript
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({ resolvers: [ElementPlusResolver()] }),
    Components({ resolvers: [ElementPlusResolver()] }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
```

> 💡 **技巧：** `rewrite` 是 Vite 的写法，别写成 vue-cli 时代的 `pathRewrite`。

#### 5.2.3 main.ts 完整启动流程
```typescript
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import 'element-plus/theme-chalk/el-message.css'
import 'element-plus/theme-chalk/el-message-box.css'
import 'element-plus/theme-chalk/el-notification.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import App from './App.vue'
import router from './router'

const app = createApp(App)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}
app.use(createPinia())
app.use(router)
app.mount('#app')
```

> ⚠️ **注意：** 按需引入后，`ElMessage` `ElMessageBox` `ElNotification` 这类通过函数调用的组件不会被自动扫描到，它们的 CSS 需要手动 import。

#### 5.2.4 router/index.ts
```typescript
import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  { path: '/', redirect: '/home' },
  { path: '/home', name: 'Home',
    component: () => import('@/views/HomeView.vue'),
    meta: { title: '首页' } },
  { path: '/hello', name: 'Hello',
    component: () => import('@/views/HelloView.vue'),
    meta: { title: '联调测试' } },
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach((to, _from, next) => {
  document.title = (to.meta.title as string) ?? 'AI 智能养老社区'
  next()
})

export default router
```

#### 5.2.5 utils/request.ts
```typescript
import axios, { type AxiosInstance, type AxiosResponse } from 'axios'
import { ElMessage } from 'element-plus'

const service: AxiosInstance = axios.create({
  baseURL: '/api',
  timeout: 10000,
})

service.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) config.headers['Authorization'] = `Bearer ${token}`
    return config
  },
  (error) => Promise.reject(error),
)

service.interceptors.response.use(
  (response: AxiosResponse) => {
    const res = response.data
    if (res.code === 200) return res.data
    ElMessage.error(res.msg || '请求失败')
    return Promise.reject(new Error(res.msg || 'Error'))
  },
  (error) => {
    ElMessage.error(error.message || '网络异常')
    return Promise.reject(error)
  },
)

export default service
```

#### 5.2.6 stores/useUserStore.ts
```typescript
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useUserStore = defineStore('user', () => {
  const token = ref<string>(localStorage.getItem('token') ?? '')
  const nickname = ref<string>('访客')
  function setToken(t: string) {
    token.value = t
    localStorage.setItem('token', t)
  }
  function logout() {
    token.value = ''
    localStorage.removeItem('token')
  }
  return { token, nickname, setToken, logout }
})
```

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| alias `@` | `@` 代替 `src`，路径不用 `../../` |
| server.proxy | 开发服务器把 `/api` 请求转发到后端 8080 |
| 按需引入 | 用到什么打什么，避免 6MB 的 Element CSS |
| 拦截器 | 请求前统一处理（加 token），响应后统一处理（解 Result） |
| Pinia | Vue3 官方推荐状态管理，比 Vuex 简单 |

### 5.4 示例代码/例题解析

**示例：HomeView.vue 使用按需引入的 Element Plus**
```vue
<script setup lang="ts">
import { ref } from 'vue'
const count = ref(0)
</script>

<template>
  <el-card style="max-width: 480px; margin: 40px auto">
    <h2>AI 智能养老社区 · Vue3 首页</h2>
    <p>计数：{{ count }}</p>
    <el-button type="primary" @click="count++">
      <el-icon><Plus /></el-icon>
      +1
    </el-button>
  </el-card>
</template>
```

原理解释：`<el-card>` `<el-button>` `<el-icon>` 都没有 `import`——`unplugin-vue-components` 在编译阶段扫描到这些以 `el-` 开头的标签，自动往顶部注入 `import`。图标 `<Plus />` 因为在 main.ts 里 `for...of` 已全量 register 到 app 上，故也无需再引。

### 5.5 课后练习
1. 【基础】把 `useUserStore` 拆成两个文件：`useUserStore.ts` 和 `useAppStore.ts`。
2. 【综合】在 `request.ts` 增加 `download(url, params)` 方法（`responseType: 'blob'`）。
3. 【挑战】把 Vite 别名 `@` 之外再加一个 `@api`，指向 `src/api`。

---

## 第 6 讲：前后端联调 Hello 接口 + Git 提交

### 6.1 本讲要点
- 浏览器同源策略与跨域产生原因
- 两种跨域解决方案：Vite proxy（开发）与后端 CORS（生产）
- Spring MVC `@RestController` 写第一个业务接口
- 前端 axios 调用 + 页面渲染
- Git 一次完整提交流程

### 6.2 知识点详解

#### 6.2.1 跨域原因
浏览器"同源策略"：协议、域名、端口三者任一不同即为跨域。前端 5173、后端 8080 → 端口不同 → 跨域。跨域下浏览器会拒绝渲染响应，控制台报 `has been blocked by CORS policy`。

#### 6.2.2 两种方案

| 方案 | 生效环境 | 原理 |
|------|---------|------|
| Vite proxy | 开发 | dev server 转发 |
| 后端 CORS | 生产 | 后端响应头带 `Access-Control-Allow-Origin` |

生产环境部署时前端是静态资源，走 Nginx 反向代理即可，也可以叠加 CORS 兜底。

#### 6.2.3 Hello 接口约定
- URL：`GET /hello`
- 前端 baseURL `/api` + 请求路径 `/hello` = `/api/hello`
- Vite proxy 把 `/api/hello` 转发到 `http://localhost:8080/hello`
- 后端返回 `Result<String>`

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 同源策略 | 协议+域名+端口三者一致 |
| CORS | Cross-Origin Resource Sharing，跨域资源共享 |
| 预检请求 | 复杂请求前会先发一个 OPTIONS |
| WebMvcConfigurer | Spring MVC 全局配置接口 |

### 6.4 示例代码/例题解析

**示例 1：后端 HelloController**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/hello")
public class HelloController {
    @GetMapping
    public Result<String> hello() {
        return Result.success("Hello, Smart Elder!");
    }
}
```

**示例 2：后端全局 CORS（生产备用）**
```java
package com.itcast.smart_elder.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

**示例 3：前端 `src/api/hello.ts`**
```typescript
import request from '@/utils/request'
export function sayHello() {
  return request.get<string, string>('/hello')
}
```

**示例 4：前端 `src/views/HelloView.vue`**
```vue
<script setup lang="ts">
import { ref } from 'vue'
import { sayHello } from '@/api/hello'
import { ElMessage } from 'element-plus'

const msg = ref('')

async function onClick() {
  try {
    msg.value = await sayHello()
    ElMessage.success('调用成功')
  } catch {
    ElMessage.error('调用失败')
  }
}
</script>

<template>
  <div style="padding: 24px">
    <h2>前后端联调 Hello</h2>
    <el-button type="primary" @click="onClick">调用后端</el-button>
    <p style="margin-top: 16px">后端返回：{{ msg }}</p>
  </div>
</template>
```

**示例 5：Git 首次提交**
```bash
# 在 D:\smart-elder\ 根目录
git init

# .gitignore 建议内容
# target/
# node_modules/
# .idea/
# dist/
# *.iml
# .DS_Store
# *.log

git add .
git commit -m "feat: init smart-elder server + web with hello api"
git branch -M main
git remote add origin git@github.com:yourname/smart-elder.git
git push -u origin main
```

> 💡 **技巧：** commit message 建议用 Conventional Commits：`feat: ...` `fix: ...` `docs: ...`。

> ⚠️ **注意：** Spring Boot 3.x 用 `allowedOriginPatterns("*")`，不要用 `allowedOrigins("*")`——后者与 `allowCredentials(true)` 冲突会启动报错。

### 6.5 课后练习
1. 【基础】改成 POST `/hello`，body `{name:"张三"}`，返回 `Hello, 张三!`。
2. 【综合】关掉 Vite proxy，用后端 CORS 让 5173 直接访问 8080 也能通。
3. 【挑战】用浏览器 DevTools 观察复杂请求的 OPTIONS 预检，记录请求头和响应头。

---

## Day02 全天知识清单

- [x] 前后端分离架构、RESTful、分层职责
- [x] Spring Boot 3.2.5 + JDK 17 骨架
- [x] pom.xml / application.yml 完整可用配置
- [x] `Result<T>` `PageBean<T>` 通用类
- [x] MyBatis-Plus + Druid + 分页插件
- [x] 通义灵码 5 大功能 + 5 条可复现 Prompt
- [x] Vue3 + Vite + Element Plus 按需引入 + Router + Pinia + axios
- [x] `vite.config.ts` / `main.ts` / `router/index.ts` / `request.ts` 全套
- [x] 前后端联调 Hello 成功
- [x] Git 初始化并提交

明天 **Day03 会员管理模块开发** 将基于今日项目开发第一个真实业务 CRUD。

