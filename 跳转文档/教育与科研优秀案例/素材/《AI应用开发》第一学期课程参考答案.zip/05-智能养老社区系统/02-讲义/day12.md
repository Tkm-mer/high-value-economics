# 《智能养老社区系统》- 学生讲义 - Day12：项目就业指导

**授课日：Day 12 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**

> **本讲义定位：** 12 天课程的收官讲义，是你带回家反复翻阅的"面试小红书"。核心交付：**30 道面试题库**（含完整参考答案）+ **3 分钟自述模板** + **5 个难点四段式模板** + **3 个反问模板** + **200-300 字项目描述可拷贝样本**。

---

## 第 1 讲：项目在简历中的呈现

### 1.1 本讲要点
- 掌握 STAR 法则四段结构，套用到 AI 智能养老社区系统
- 学会用 3 类量化指标（对比 / 比例 / 绝对）为项目描述加分
- 熟悉 5 大技术亮点标签，让简历第一眼就抓住 HR/面试官
- 识别并规避简历 5 大雷区

### 1.2 知识点详解

#### 1.2.1 STAR 法则

| 段 | 含义 | 在项目描述中的角色 |
|----|------|---------------------|
| **S** Situation | 背景 / 业务场景 | 项目为谁做、解决什么问题 |
| **T** Task | 我承担的任务 | 明确"个人负责范围" |
| **A** Action | 采用的技术方案 | 亮点技术清单 + 关键实现 |
| **R** Result | 结果 / 收益 | 用数字量化——**这段最容易被忽略也最加分** |

> **技巧：** STAR 不是四段独立文字，而是可以在一段流畅描述里前后照应。写完一段回头对照：S/T/A/R 都覆盖了吗？

#### 1.2.2 5 大技术亮点标签

| # | 标签 | 一句话说明 |
|---|------|-----------|
| 1 | **AI 大模型集成** | Spring AI 1.0.0-M6 + 通义千问 + Function Calling + RAG |
| 2 | **Redis 缓存 + 分布式锁** | 热点缓存 + SETNX 防超卖 |
| 3 | **AOP 操作日志** | 自定义 @OperationLog 注解 + 环绕通知 + @Async 异步落库 |
| 4 | **Echarts 数据大屏** | 多表复杂 SQL + 5 图联动 + 10s 轮询 |
| 5 | **Docker 一键部署** | docker-compose 编排 MySQL/Redis/后端/Nginx + 回滚方案 |

#### 1.2.3 3 类量化指标

| 类型 | 表达模板 | 项目示例 |
|------|----------|-----------|
| 对比型 | "从 X 优化到 Y" | 客房列表接口 P95 从 800ms → 120ms |
| 比例型 | "达到 X% / 提升 X 倍" | Redis 缓存命中率 92%；大屏 SQL 耗时下降 85% |
| 绝对型 | "支持 X / 日均 X" | 支持 100 QPS；日均 5w 条操作日志异步入库 |

#### 1.2.4 5 大雷区（避坑）

> **注意：** 以下写法一被追问就漏，请从简历里删掉：
>
> 1. **撒谎型**："日活 10w，QPS 5000"（初学者项目根本不可能）
> 2. **名词堆砌型**：Kafka + RocketMQ + ES + Sentinel + Nacos 全写但一个没做过
> 3. **无量化型**：只写"实现了 xxx"没有一个数字
> 4. **无个人贡献型**：全篇"我们团队"，从头到尾没有"我"
> 5. **版本混乱型**：SpringBoot 2.x + JDK 17 / Spring AI + Java 8（不兼容）

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| STAR | Situation / Task / Action / Result 四段结构 |
| 亮点标签 | AI / Redis / AOP / 大屏 / 部署 |
| 量化 3 类 | 对比 / 比例 / 绝对 |
| 雷区 | 撒谎 / 堆砌 / 无数字 / 无我 / 版本乱 |

### 1.4 【可拷贝样本】200-300 字项目描述

> **AI 智能养老社区系统**（个人项目 / 2024.09-2024.12）
>
> **技术栈**：SpringBoot 3.x · MyBatis-Plus · MySQL 8 · Redis 7 · Spring AI 1.0.0-M6 · 通义千问 · Vue 3 · Element Plus · Echarts 5 · Docker
>
> **项目描述**：面向社区养老场景的一体化 SaaS，涵盖会员管理、客房管理、智能预约、AI 健康问答、AOP 操作日志、Echarts 数据大屏 6 大模块，服务社区老人与运营方。
>
> **主要工作**：
> ① 独立完成后端 60+ 接口开发与前后端联调；
> ② 基于 Spring AI + Function Calling 实现健康评测智能体，并接入本地 SimpleVectorStore 完成养老政策文档 RAG 检索增强；
> ③ 使用 Redis 缓存 + SETNX 分布式锁 + DB 唯一索引双兜底解决客房预约超卖，接口 P95 从 800ms 优化到 120ms，缓存命中率 92%；
> ④ 自定义 @OperationLog 注解 + AOP 环绕通知 + @Async 异步落库，日均 5w 条日志零阻塞主流程；
> ⑤ Echarts 大屏对接 5 个复杂聚合 SQL，10s 轮询自动刷新，通过覆盖索引优化后 SQL 耗时下降 85%；
> ⑥ 使用 Docker Compose 一键部署 + Nginx 反向代理，配合灰度与回滚方案。

（约 280 字，可直接拷贝进简历，替换里面的模块 / 数据以贴合自己实际做的内容。）

### 1.5 课后练习

1. 【基础】背诵 5 大技术亮点标签，5 分钟后默写。
2. 【综合】按 STAR 结构写自己的 250 字项目描述，含至少 3 个数字。
3. 【挑战】把项目描述压缩到 100 字（60 秒版）和扩展到 500 字（详细版），各写一份备用。

---

## 第 2 讲：项目讲解话术训练

### 2.1 本讲要点
- 3 分钟自述五段模板（背景 / 我的角色 / 模块 / 亮点 / 数字）
- 12 道场景问答的"结论 → 原因 → 项目落点"回答骨架
- 讲述纪律：先结论、不贬低、留钩子
- 用"钩子"引导面试官问你有把握的问题

### 2.2 知识点详解

#### 2.2.1 【模板】3 分钟自述五段

| 段 | 时长 | 内容 | 参考句式 |
|----|------|------|-----------|
| ① 背景 | 20s | 项目做啥、为谁做 | "我最近做的项目叫 AI 智能养老社区系统，是一个面向社区养老机构的一体化管理平台……" |
| ② 我的角色 | 20s | 独立 or 团队、覆盖范围 | "在项目中我承担后端主力开发，覆盖 6 大模块中的 5 个……" |
| ③ 模块概览 | 40s | 6 大模块一句话串起来 | "模块包括会员管理、客房管理、智能预约、AI 健康问答、AOP 日志、Echarts 大屏……" |
| ④ 亮点技术 | 60s | 选 2-3 个技术展开 | "重点做了三件事：一是接入 Spring AI……；二是 Redis 分布式锁……；三是 AOP 异步日志……" |
| ⑤ 成果指标 | 30s | 3 个数字收尾 | "接口 P95 从 800ms 优化到 120ms，Redis 命中率 92%，AI 首字节 500ms 内。" |

> **技巧：** 每段末尾可以留一个钩子，如："这里踩过一个坑……"，主动引导追问方向。

#### 2.2.2 讲述纪律（4 条）

| # | 纪律 | 反面例子 |
|---|------|-----------|
| 1 | 先讲业务，再讲技术 | ❌ "我这个项目用了 SpringBoot……" |
| 2 | 不用"感觉""大概""好像" | ❌ "感觉应该是 800ms 左右" |
| 3 | 不主动贬低 | ❌ "其实就是个练手项目" |
| 4 | 不主动透露短板 | ❌ "很多地方我还不太熟" |

#### 2.2.3 【题库】12 道场景问答（完整参考答案）

**Q1 为什么用 Redis 不用本地 Map / 内存缓存？**
> 【结论】分布式和过期能力必须。
> 【原因】① 多实例部署时本地 Map 无法共享，导致缓存不一致；② TTL 过期、发布订阅、原子命令（INCR/SETNX）这些 Map 都没有；③ Redis 提供持久化，重启后数据不丢。
> 【项目落点】客房热门房型使用 Redis String 缓存 TTL 5 分钟；预约下单使用 Redis SETNX 分布式锁防超卖。

**Q2 为什么用 SimpleVectorStore 而不上 Milvus？**
> 【结论】项目规模决定选型。
> 【原因】① 文档量 <1000 条，本地内存 List 完全够用；② Milvus 需要独立部署、维护成本高；③ Spring AI 抽象了 VectorStore 接口，未来无缝替换。
> 【项目落点】养老政策 200 篇文档切片后入 SimpleVectorStore；上线量大时可切 Redis Stack VECTOR 或 Milvus，接口层不用改。

**Q3 AOP 采集日志时如果落库失败会怎样？**
> 【结论】绝对不能阻塞主业务。
> 【实现】① @Async + 独立线程池（core=4, queue=1000）；② 内部 try-catch 全部异常记 error 日志；③ 线程池拒绝策略 DiscardOldestPolicy 保证不堵；④ 关键日志（如资金）可加 MQ / 本地文件兜底。
> 【项目落点】日均 5w 条日志无一阻塞主接口。

**Q4 AI 接口超时怎么处理？**
> 【结论】前端体验 + 后端保护双轨。
> 【实现】① WebClient / RestTemplate 全局 60s 超时；② 用 SSE 流式让用户提前看到部分内容；③ Sentinel / Semaphore 全局限流 30 QPS；④ 失败降级到本地 FAQ 或缓存过的模板答案；⑤ 失败后端记录并触发预警。
> 【项目落点】通义千问 3-8s 响应，用 SSE 首字节 <500ms。

**Q5 为什么用 MyBatis-Plus 不用 JPA？**
> 【结论】国内主流 + 复杂 SQL 可控。
> 【原因】① 复杂报表 SQL 手写更清晰；② MP 的 LambdaQueryWrapper 覆盖 80% 简单查询；③ 分页插件、乐观锁、逻辑删除、自动填充等企业能力开箱即用。
> 【项目落点】会员/客房/日志分页全部走 IPage；大屏聚合 SQL 手写 xml。

**Q6 你说的 800ms → 120ms 是怎么测的？**
> 【结论】JMeter 单接口压测取 P95。
> 【方法】① 50 并发 × 30 秒；② 优化前直查 MySQL；③ 优化后走 Redis 缓存，命中率 92%；④ P95 是排序取 95 分位，比平均值更能反映用户体感。

**Q7 Function Calling 和 RAG 有什么区别？**
> 【结论】前者让模型"调工具"，后者给模型"喂资料"。
> 【差异】Function Calling：模型返回结构化函数调用意图（name + args），后端执行拿结果回喂模型；RAG：先向量检索文档 Top-K，再把内容拼进 Prompt 让模型生成。
> 【项目落点】健康评测 evaluateHealth() 用 Function Calling；养老政策问答用 RAG。

**Q8 Prompt 你是怎么设计的？**
> 【结论】System 定角色 + User 加约束 + 少样本示范。
> 【示例】"你是一名有 30 年经验的家庭医生，回答不超过 200 字，禁止给出具体诊断结论，如涉及严重症状引导用户就医。"
> 【项目落点】5 个模块 5 套 Prompt 模板，通过 PromptTemplate 参数化。

**Q9 大屏 10s 刷一次会不会打爆数据库？**
> 【结论】不会。
> 【实现】① 接口结果放 Redis 缓存 TTL 10s；② SQL 走 (create_time, status) 覆盖索引；③ 一个接口一次返回 5 个指标合并 DTO；④ 定时任务预热热点数据。
> 【效果】DB QPS 从 50 降到 5。

**Q10 遇到最难的问题是啥？**（详见第 5 讲难点答辩）
> 【结论】预约超卖 + AI 首字节延迟高。
> 【解决】前者 Redis 分布式锁 + DB 唯一索引双兜底；后者 SSE 流式 + 前端骨架屏。

**Q11 项目做了多久？**
> 【结论】12 天集中迭代 / 4 周持续开发（选择一个口径贯彻始终）。
> 【说明】每天保证 6 小时投入，节奏参考课程 Day01-Day11。

**Q12 你觉得项目还有哪些可以改进？**
> 【结论】3 点：
> ① 分布式部署可加 Nacos + Spring Cloud Gateway；
> ② AI 可接入 DeepSeek 做对比 / 降级；
> ③ 大屏可上 WebSocket 替代轮询，实时性更好。
> 【要点】展现思考深度，但要诚实，别列 10 个来显得项目很差。

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 3 分钟自述 | 五段：背景 / 我 / 模块 / 亮点 / 数字 |
| 回答骨架 | 结论 → 原因 → 项目落点 |
| 讲述纪律 | 先结论 / 不贬低 / 留钩子 / 不透露短板 |
| 钩子 | 主动埋一个想被追问的点 |

### 2.4 课后练习

1. 【基础】12 道场景题每题写 100 字关键词提纲。
2. 【综合】录音 3 分钟自述，回听并修订，达到脱稿流畅。
3. 【挑战】与同学互相追问 3 轮，每次录音复盘。

---

## 第 3 讲：Spring / MySQL 高频面试题（15 题完整答案）

### 3.1 本讲要点
- Spring 8 题：Bean 生命周期、IOC/DI、AOP 原理、@Transactional 失效 7 种、循环依赖、事务传播 7 种、MP 分页插件、事务隔离级别
- MySQL 7 题：索引不命中 8 种、联合索引最左前缀、Explain type 全部值、悲乐锁、主从复制、分库分表、SQL 优化实例
- 每题给出完整参考答案，可直接背诵

### 3.2 【题库】Spring 面试题（8 题）

**Q1 Spring Bean 生命周期？**
> 完整 7 步：
> ① 实例化 Instantiation（无参构造）
> ② 属性填充 Populate Properties（@Autowired 注入依赖）
> ③ Aware 接口回调（BeanNameAware / BeanFactoryAware / ApplicationContextAware）
> ④ BeanPostProcessor#postProcessBeforeInitialization
> ⑤ 初始化：InitializingBean#afterPropertiesSet → @PostConstruct → init-method
> ⑥ BeanPostProcessor#postProcessAfterInitialization（AOP 代理在这里生成）
> ⑦ 使用中
> ⑧ 销毁：DisposableBean#destroy → @PreDestroy → destroy-method
>
> **项目落点**：ChatClient Bean 在 InitializingBean 阶段校验 API-Key。

**Q2 IOC 和 DI 的区别？**
> 【IOC 控制反转】原来对象由自己 new，现在交给容器管理，控制权反转。
> 【DI 依赖注入】IOC 的实现方式，容器把依赖注入进来。三种方式：构造器注入（推荐）、Setter 注入、字段注入 @Autowired。
> **项目落点**：ChatClient / RedisTemplate / OperationLogService 全部构造器注入。

**Q3 Spring AOP 原理？**
> 基于动态代理：
> ① **JDK 动态代理**：目标类实现接口时使用，Proxy.newProxyInstance；
> ② **CGLIB 代理**：目标类没有接口时使用，通过继承生成子类；
> ③ Spring 默认能用 JDK 就用 JDK，可通过 `proxyTargetClass=true` 强制 CGLIB。
>
> 核心 5 概念：Aspect 切面 / JoinPoint 连接点 / Pointcut 切点 / Advice 通知（Before/After/Around/AfterReturning/AfterThrowing）/ Weaving 织入。
>
> **项目落点**：@OperationLog 注解 + @Around 环绕通知采集操作日志。

**Q4 @Transactional 失效的 7 种场景？（高频重点）**
> ① **方法非 public**：Spring AOP 只代理 public 方法。
> ② **同类内部方法调用**：this.methodB() 走的是原生对象非代理对象，AOP 不生效。→ 解决：AopContext.currentProxy().methodB() 或者拆到另一个 Bean。
> ③ **异常被 catch 吞掉**：事务是靠抛异常回滚的，catch 掉就不回滚。
> ④ **异常类型不匹配**：默认只回滚 RuntimeException 和 Error；Checked Exception 不回滚，除非 rollbackFor = Exception.class。
> ⑤ **数据库引擎不支持事务**：MyISAM 不支持事务，必须 InnoDB。
> ⑥ **多线程调用**：新线程和主线程不共享事务上下文（ThreadLocal）。
> ⑦ **注解加错地方**：加在接口或私有方法上无效；也常见于 final 方法、static 方法。
>
> **项目落点**：预约扣库存曾遇到内部调用失效，改用 AopContext.currentProxy() 解决。

**Q5 Spring 循环依赖如何解决？**
> Spring 只解决 **单例 Setter/字段注入** 循环，通过 **三级缓存**：
> - `singletonObjects`：完全初始化好的 Bean（一级）
> - `earlySingletonObjects`：早期未完成初始化的 Bean（二级）
> - `singletonFactories`：Bean 的工厂对象，可提前暴露引用（三级）
>
> 流程：创建 A → 属性填充需要 B → 创建 B → 属性填充需要 A → 从三级缓存拿到 A 的早期引用（未完成）→ B 初始化完成 → A 完成属性填充 → A 初始化完成。
>
> **无解**：构造器循环依赖 / 原型 Bean 循环依赖。

**Q6 事务传播的 7 种？**
| 传播行为 | 说明 | 使用场景 |
|-----------|------|-----------|
| REQUIRED（默认） | 有事务加入，没事务新建 | 大部分业务 |
| REQUIRES_NEW | 挂起当前，新建独立事务 | 日志、异步通知 |
| SUPPORTS | 有事务加入，没事务非事务方式 | 只读查询 |
| NOT_SUPPORTED | 有事务挂起，非事务方式 | 不需要事务 |
| MANDATORY | 必须有事务，没有报错 | 强约束 |
| NEVER | 必须没事务，有就报错 | 强隔离 |
| NESTED | 嵌套事务，Savepoint 回滚 | 部分回滚 |
> **项目落点**：操作日志用 REQUIRES_NEW，业务失败也要记录。

**Q7 MyBatis-Plus 分页插件原理？**
> `PaginationInnerInterceptor` 拦截 SQL 执行前：
> ① 检测方法参数是否有 IPage；
> ② 自动生成 count SQL 统计总数；
> ③ 在原 SQL 末尾拼接 LIMIT / OFFSET；
> ④ 结果封装回 IPage 对象。
> **项目落点**：会员/客房/日志分页全部走 `service.page(new Page<>(current, size), wrapper)`。

**Q8 事务隔离级别？**
| 级别 | 脏读 | 不可重复读 | 幻读 |
|------|------|------------|------|
| READ UNCOMMITTED | ✗ | ✗ | ✗ |
| READ COMMITTED | √ | ✗ | ✗ |
| REPEATABLE READ（MySQL 默认） | √ | √ | InnoDB 通过 MVCC + Gap Lock 解决 |
| SERIALIZABLE | √ | √ | √ |
>
> 三类问题：
> - **脏读**：读到未提交的数据
> - **不可重复读**：两次读同一行结果不同（其他事务 UPDATE）
> - **幻读**：两次读同一范围行数不同（其他事务 INSERT）

### 3.3 【题库】MySQL 面试题（7 题）

**Q9 索引不命中的 8 种场景？**
> ① 索引列使用函数 / 运算：`WHERE YEAR(create_time)=2026`
> ② 隐式类型转换：字符串字段传数字 `WHERE phone=13800000000`
> ③ LIKE 以 % 开头：`WHERE name LIKE '%张'`
> ④ OR 一侧无索引：`WHERE a=1 OR b=2`（b 无索引）
> ⑤ != 或 NOT IN
> ⑥ 联合索引不满足最左前缀
> ⑦ is NULL / is NOT NULL（部分场景）
> ⑧ 优化器估算全表扫描更快（数据量小或选择性差）

**Q10 联合索引最左前缀？**
> 联合索引 `(a, b, c)`：
> - `WHERE a=?` ✓ 用
> - `WHERE a=? AND b=?` ✓ 用
> - `WHERE a=? AND b=? AND c=?` ✓ 用
> - `WHERE b=?` ✗ 不用
> - `WHERE a=? AND c=?` △ 只 a 命中，c 不命中
> - `WHERE a=? ORDER BY b` ✓ 用（用到排序）
> - `WHERE a > ? AND b=?` △ a 命中范围后 b 不再走索引排序

**Q11 Explain type 全部值（由优到劣）？**
| type | 说明 |
|------|------|
| system | 表只有一行（系统表） |
| const | 主键 / 唯一索引等值查询 |
| eq_ref | join 时主键或唯一索引匹配 |
| ref | 非唯一索引等值 |
| range | 范围查询（BETWEEN / < / >） |
| index | 全索引扫描（比 ALL 好，因索引比表小） |
| ALL | 全表扫描（最差） |
> **项目落点**：客房分页优化后从 ALL → range。

**Q12 悲观锁 vs 乐观锁？**
> **悲观锁**：先加锁再操作。MySQL 行锁 `SELECT ... FOR UPDATE`。适合写多。
> **乐观锁**：假设不冲突，提交时用 version / CAS 判断。适合读多写少。
> ```sql
> UPDATE room SET status=1, version=version+1
> WHERE id=? AND version=?
> -- 返回影响行数 0 → 冲突，需重试
> ```
> **项目落点**：预约用乐观锁（version）+ Redis SETNX 分布式锁双兜底。

**Q13 MySQL 主从复制原理？**
> 3 个关键线程：
> ① Master 的 **binlog dump 线程**：把 binlog 事件推给 Slave；
> ② Slave 的 **IO 线程**：接收并写入 relay log；
> ③ Slave 的 **SQL 线程**：读 relay log 重放到 Slave 库。
>
> binlog 三种格式：
> - **STATEMENT**：记 SQL 语句，日志小但可能主从不一致（NOW() 等）
> - **ROW**：记行变更，安全但日志大
> - **MIXED**：混合模式
>
> 应用：读写分离、备份、灾备。

**Q14 分库分表方案？**
> **垂直**：按业务模块拆库（用户库 / 订单库 / 商品库）。
> **水平**：按 ID 取模 / 范围 / 一致性哈希拆表。
> 中间件：**ShardingSphere**（推荐，透明化）、MyCAT。
> 常见问题：跨库 join / 分布式事务 / 主键生成（Snowflake）/ 数据迁移。
> **项目落点**：本项目规模内不做，但能讲选型思路。

**Q15 SQL 优化实例（大屏"每日预约统计"）**
> **优化前**（3.2s）：
> ```sql
> SELECT DATE(create_time) day, COUNT(*), SUM(amount)
> FROM reservation
> WHERE create_time BETWEEN '2026-01-01' AND '2026-06-30'
> GROUP BY DATE(create_time);
> ```
> 问题：函数 DATE() 导致索引失效、SELECT * 冗余字段。
>
> **优化后**（180ms）：
> ```sql
> -- 加联合索引 (create_time, status, amount)
> SELECT create_time_day, COUNT(*), SUM(amount)
> FROM reservation
> WHERE create_time >= '2026-01-01' AND create_time < '2026-07-01'
>   AND status = 1
> GROUP BY create_time_day;  -- 冗余存储 DATE
> ```
> 关键：① 冗余存日期列避免函数；② 联合索引覆盖 SELECT 字段（覆盖索引避免回表）；③ 用 >= < 替代 BETWEEN + DATE 转换。

### 3.4 重点概念回顾

| 概念 | 一句话 |
|------|--------|
| Bean 生命周期 | 实例化 → 属性 → Aware → BPP → 初始化 → BPP → 用 → 销毁 |
| @Transactional 失效 | 非 public / 内部调用 / 吞异常 / Checked / 非 InnoDB / 多线程 / 加错位置 |
| Explain type | system > const > eq_ref > ref > range > index > ALL |
| 最左前缀 | 联合索引从左往右连续用 |
| 悲乐锁 | FOR UPDATE vs version + CAS |

### 3.5 课后练习

1. 【基础】15 题闭卷背诵，每题写 3-5 个关键词。
2. 【综合】挑 3 题写"项目落点"一句话，落回 AI 智能养老社区系统。
3. 【挑战】用 Explain 分析你项目中一段 SQL，写优化前后对比。

---

## 第 4 讲：Redis / AI 大模型 高频题（15 题完整答案）

### 4.1 本讲要点
- Redis 7 题：缓存穿透 / 雪崩 / 击穿、布隆过滤器、RDB/AOF、Redis 集群三方案、分布式锁 Redis vs Redisson、SETNX 手写代码
- AI 大模型 8 题：LLM 原理、Prompt 5 法则、RAG 4 步、Function Calling、Embedding 相似度、向量库选型、AI 限流令牌桶、Hallucination 应对 + 预算控制

### 4.2 【题库】Redis 面试题（7 题）

**Q1 缓存穿透（Cache Penetration）**
> **定义**：查询一个数据库中根本不存在的数据（如 id=-1），缓存永远不命中，请求直击 DB。
> **解决**：
> ① **布隆过滤器**：请求前先判断 key 是否可能存在；
> ② **缓存空值**：DB 查完是 null 也写入 Redis TTL 短（如 60s）；
> ③ 参数合法性校验（负数 ID 直接拒绝）。

**Q2 缓存雪崩（Cache Avalanche）**
> **定义**：大量 key 同时过期 或 Redis 宕机，请求全部打到 DB。
> **解决**：
> ① **TTL 随机**：热点 key 过期时间加随机偏移；
> ② **多级缓存**：本地 Caffeine + Redis；
> ③ **熔断限流**：Sentinel 保护 DB；
> ④ **高可用**：Redis 主从 + 哨兵 / 集群。

**Q3 缓存击穿（Hot Key Miss）**
> **定义**：某个 **热点 key** 过期瞬间，大量并发请求都打到 DB。
> **解决**：
> ① **互斥锁重建**：只有一个线程去查 DB 重建缓存，其他等待；
> ② **逻辑过期**：value 里带过期时间字段，异步重建；
> ③ 热点数据永不过期。
> **项目落点**：客房热门房型使用 SETNX 互斥锁重建。

**Q4 布隆过滤器（Bloom Filter）**
> **原理**：一个 bit 数组 + k 个哈希函数；插入时把 k 个位置 bit 置 1；查询时全为 1 才可能存在。
> **特性**：只误判"存在"（可能其实不存在），不误判"不存在"（不在就一定不在）。
> **调优**：数组越大误判率越低，但内存占用越多。
> **应用**：缓存穿透防护、爬虫去重、垃圾邮件识别。

**Q5 RDB vs AOF**
| 对比项 | RDB | AOF |
|--------|-----|-----|
| 原理 | 全量快照 | 追加写命令日志 |
| 恢复速度 | 快 | 慢 |
| 文件大小 | 小 | 大 |
| 数据安全 | 可能丢最近一次快照后的数据 | 最多丢 1 秒（appendfsync everysec） |
| 生产建议 | RDB + AOF **双开** |
> **触发**：RDB 通过 save / bgsave；AOF 通过 appendfsync always/everysec/no。

**Q6 Redis 集群三方案**
| 方案 | 特点 | 适用 |
|------|------|------|
| 主从复制 | 主写从读，无高可用 | 小规模读多写少 |
| **哨兵 Sentinel** | 主从 + 自动故障转移 | 中等规模、需高可用 |
| **Cluster 分片** | 数据分 16384 槽，多主多从，水平扩展 | 大规模海量数据 |
> **项目落点**：单机足够，能讲选型。

**Q7 分布式锁 Redis vs Redisson**
> **Redis SETNX（简单版）**：
> ```
> SET lock:room:1:20260710 uuid NX EX 10
> ```
> 释放时用 Lua 保证原子性：
> ```lua
> if redis.call('get', KEYS[1]) == ARGV[1] then
>     return redis.call('del', KEYS[1])
> else
>     return 0
> end
> ```
> **问题**：业务超过 EX 时间，锁自动释放导致其他线程进入。
>
> **Redisson**：
> - **WatchDog 看门狗**：每 10s 自动续期，业务不结束锁不释放；
> - 可重入锁、公平锁、读写锁、信号量、闭锁；
> - 依赖 Netty，性能好。
>
> **项目落点**：本项目使用 SETNX + Lua，业务简单可控 EX=10s 足够；量大时切 Redisson。

### 4.3 【题库】AI 大模型面试题（8 题）

**Q8 LLM 大语言模型工作原理（简版）？**
> 核心：**基于 Transformer 架构的下一个 token 概率预测器**。
> 流程：
> ① **预训练**：海量语料无监督学习，学到语言分布；
> ② **SFT 有监督微调**：用人工标注的指令-回复对训练；
> ③ **RLHF 人类反馈强化学习**：用人类偏好排序训练奖励模型，再用 PPO 优化生成策略；
> ④ **推理**：给定上下文，逐 token 生成，采样策略（温度 temperature / top-p）控制多样性。
> 关键组件：**Self-Attention 注意力机制**，让模型关注上下文中相关词。

**Q9 Prompt 工程 5 法则**
> ① **明确角色**（System Message）："你是一名有 30 年经验的家庭医生……"
> ② **提供上下文**（Context）：把用户历史 / 相关文档拼进来
> ③ **给出示例**（Few-shot）：给 1-3 个"输入-输出"示范
> ④ **限制输出格式**：JSON schema / 最多 N 字 / 只输出结论
> ⑤ **链式思考**（Chain-of-Thought）：加"Let's think step by step"，让模型显式推理
>
> **项目落点**：健康评测 Prompt 用 System 定医生角色 + Few-shot 示范 + JSON 输出。

**Q10 RAG 检索增强生成 4 步**
> ① **文档切片**（Chunk）：按段 / 按固定长度切，考虑重叠避免语义断裂；
> ② **Embedding 入库**：调用 embedding 模型把每片转成向量，存入向量库（存 id + text + vector）；
> ③ **相似度检索**：用户 Query 也 Embedding 化，与向量库计算余弦相似度取 Top-K；
> ④ **拼 Prompt 生成**：把 Top-K 文档 + 用户 Query 一起送给 LLM 生成答案，可要求"仅基于上述内容回答"。
>
> **项目落点**：200 篇养老政策切片 → text-embedding-v2 入 SimpleVectorStore → 用户提问检索 Top-3 → 拼 Prompt 让通义千问回答。

**Q11 Function Calling 原理**
> ① 客户端把可用函数以 JSON schema 描述给模型（name/description/parameters）；
> ② 模型判断需要调用时返回结构化 `{name: "xxx", args: {...}}`；
> ③ 客户端拦截并执行本地方法（Spring Bean）；
> ④ 把执行结果作为 tool message 回喂给模型；
> ⑤ 模型基于结果生成自然语言回答。
>
> **项目落点**：`evaluateHealth(age, systolic, diastolic)` 本地方法，Spring AI @Bean 注册为 Function。

**Q12 Embedding 与向量相似度**
> **Embedding**：把文本 / 图片 / 音频映射到高维向量（如 1536 维），语义相近的向量距离近。
> **余弦相似度**：
> $$\cos\theta = \frac{A \cdot B}{|A| \cdot |B|}$$
> 值域 [-1, 1]，越接近 1 越相似。
> **其他距离**：欧氏距离、点积、Jaccard。
> **项目落点**：使用通义 text-embedding-v2 模型（1024/1536 维），余弦相似度检索。

**Q13 向量库选型**
| 类型 | 代表 | 特点 |
|------|------|------|
| 本地/内嵌 | SimpleVectorStore / Chroma | 无运维、适合 <10w 条 |
| 独立部署 | **Milvus** / Qdrant / Weaviate | 高性能、支持 HNSW/IVF 索引 |
| 云服务 | Pinecone | 免运维、按量付费 |
| 数据库扩展 | Redis Stack VECTOR / pgvector | 已有数据库直接扩展 |
> 选型看：数据量 / 运维成本 / 是否要过滤条件 / 是否需要更新频繁。

**Q14 AI 接口限流：令牌桶算法**
> **原理**：一个桶按固定速率生成令牌，请求需要拿到令牌才能通过。
> **实现**：
> - Guava `RateLimiter.create(30)`（30 QPS）
> - Bucket4j（分布式）
> - Sentinel（自适应流控）
> **项目落点**：AI 问答接口全局 30 QPS，避免烧钱。
> ```java
> RateLimiter aiLimiter = RateLimiter.create(30);
> if (!aiLimiter.tryAcquire()) return "AI 忙线中，请稍后";
> ```

**Q15 预算控制 + Hallucination（幻觉）应对**
> **预算控制**：
> ① Token 计数：请求前预估 tokens，超预算拒绝；
> ② 每日总额上限（USD/CNY），到达停服务；
> ③ 每用户配额（新用户 20 次/日）；
> ④ 优先小模型 → 复杂再上大模型（模型分级）。
>
> **Hallucination（幻觉）**：模型编造事实。应对：
> ① **降 temperature** 到 0.2 甚至 0（更确定性）；
> ② **RAG 强制引用**：Prompt 加"仅基于以下文档回答，无相关内容说不知道"；
> ③ **敏感领域加免责声明**：医疗 / 法律 / 金融必加；
> ④ **关键回答人工审核**：进入队列等人工确认；
> ⑤ **多模型交叉验证**：同一问题问 2 个模型对比。
>
> **项目落点**：养老政策问答 temperature=0.2 + RAG 强制引用 + 免责声明。

### 4.4 重点概念回顾

| 概念 | 一句话 |
|------|--------|
| 缓存三兄弟 | 穿透查不存在 / 雪崩全过期 / 击穿单热点 |
| RAG 4 步 | 切片 → Embedding → 检索 → 拼 Prompt |
| Function Calling | 模型调工具 |
| RAG vs FC | 喂资料 vs 调工具 |
| Hallucination | 温度低 + RAG 引用 + 免责 + 人审 |

### 4.5 课后练习

1. 【基础】15 题背诵，能自主区分穿透 / 雪崩 / 击穿。
2. 【综合】手写 SETNX 分布式锁 + Lua 释放脚本，不看讲义。
3. 【挑战】设计一个 Function Calling JSON schema，用于"根据身高体重返回 BMI 及健康建议"。

---

## 第 5 讲：项目难点与解决方案答辩

### 5.1 本讲要点
- 掌握"难点四段式"表达模板：背景 → 尝试方案 → 最终方案 → 手写代码/ASCII 图
- 5 个典型难点完整模板可背诵
- 学会用"尝试方案"展示思考过程

### 5.2 【模板】难点答辩四段式

```
① 背景（30s）
   业务场景 + 问题现象 + 影响面
② 尝试方案（60s）
   曾经试过什么，为什么放弃
③ 最终方案（60s）
   实际采用方案 + 原理讲解
④ 手写代码 3-5 行 / ASCII 白板图（30s）
   面试官会问"能不能画一下"
```

> **技巧：** 缺少"尝试方案"就等于说"我第一次做就成功了"——不真实、不加分。故意暴露一个错路，反而显得思考深入。

### 5.3 5 个典型难点

#### 难点 1：预约防超卖

**① 背景**：同一房间同一入住日期被两个用户同时抢单，DB 出现两条 status=1 的预约记录，运营方投诉。
**② 尝试方案**：最初用 Java `synchronized` 锁方法，单机测试通过，但一上线部署两个实例就失效——`synchronized` 只锁 JVM。
**③ 最终方案**：Redis SETNX 分布式锁（key = `lock:room:{roomId}:{date}`）+ MySQL 唯一索引 `(room_id, check_in_date)` 双兜底；释放锁用 Lua 保证"判断 + 删除"原子性。
**④ 手写代码 + 白板图**：
```java
String lockKey = "lock:room:" + roomId + ":" + date;
String uuid = UUID.randomUUID().toString();
Boolean ok = redis.opsForValue().setIfAbsent(lockKey, uuid, 10, SECONDS);
if (!Boolean.TRUE.equals(ok)) throw new BizException("已被预约");
try { reservationService.create(...); } finally { luaRelease(lockKey, uuid); }
```
```
用户A ──► SETNX 成功 ──► 扣库存 ──► DB Insert ──► 释放锁
用户B ──► SETNX 失败 ──► 返回"已被预约"
DB 唯一索引 ◄── 兜底：即使锁失效，插入报错回滚
```

#### 难点 2：AI 接口流式实时性

**① 背景**：通义千问一次问答 3-8s，前端一直转圈用户以为卡死，客服反馈"AI 用不了"。
**② 尝试方案**：把接口改成异步 + 前端 3s 轮询，用户体验仍是"卡 + 突然出现"，没有输入感。
**③ 最终方案**：SSE（Server-Sent Events）流式响应。后端使用 Spring AI `stream()` 返回 `Flux<String>`，配合 `MediaType.TEXT_EVENT_STREAM_VALUE`；前端 EventSource 逐 token 接收显示。
**④ 手写代码 + 白板图**：
```java
@GetMapping(value = "/ai/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> chat(@RequestParam String msg) {
    return chatClient.prompt().user(msg).stream().content();
}
```
```
前端 EventSource ──┐
                    │ 逐字 push (SSE data: xxx\n\n)
后端 Flux<String> ── Spring AI stream() ── 通义千问 SSE
效果：首字节 <500ms，用户 1s 内看到输入
```

#### 难点 3：RAG 知识库更新

**① 背景**：养老政策文档每月更新，向量库 200 篇 × 3 chunk = 600 条向量，每次全量重建耗时 5 分钟且浪费 Embedding Token。
**② 尝试方案**：每次接口调用前扫描目录，慢且每天空跑几百次；改为定时任务全量重建，仍然浪费。
**③ 最终方案**：MD5 指纹表 + 增量更新。文档表存 doc_id、file_path、md5、version；定时任务扫描目录计算 md5，发现变化则删除该文档旧向量、重新切片入库并 version+1；提供后台"手动重建"按钮兜底。
**④ 手写代码**：
```java
String newMd5 = md5(readFile(path));
DocFingerprint old = docMapper.selectByPath(path);
if (old == null || !old.getMd5().equals(newMd5)) {
    vectorStore.delete(List.of(old != null ? old.getDocId() : null));
    List<Document> chunks = splitter.split(readFile(path));
    vectorStore.add(chunks);
    docMapper.upsert(new DocFingerprint(path, newMd5, version+1));
}
```

#### 难点 4：AOP 操作日志性能损耗

**① 背景**：接入 @OperationLog 后核心接口 P99 从 120ms 升到 180ms，接口越多影响越大，运维告警。
**② 尝试方案**：先加数据库连接池、把 log 表分区——治标不治本，因为日志表写入本身是同步的。
**③ 最终方案**：**异步 + 批量**双管齐下：@Async 独立线程池（core=4, max=8, queue=1000, DiscardOldestPolicy）+ 定时批量 flush（100 条 or 500ms 触发一次 INSERT INTO ... VALUES (),(),()）+ 日志表使用 InnoDB 简单索引 + 按天分表可选。
**④ 手写代码**：
```java
@Async("logExecutor")
public void save(OperationLog log) {
    buffer.offer(log);
    if (buffer.size() >= 100) flush();
}

@Scheduled(fixedDelay = 500)
public void flush() {
    List<OperationLog> batch = new ArrayList<>();
    buffer.drainTo(batch, 100);
    if (!batch.isEmpty()) logMapper.batchInsert(batch);
}
```
**效果**：P99 回到 125ms，与不加日志几乎无差。

#### 难点 5：大屏实时性

**① 背景**：Echarts 大屏 5 个图 + 10s 轮询，一开始直连 DB，每次 5 个复杂 SQL 齐发，大屏一打开 DB QPS 直接 50+，压测把 DB 压崩过。
**② 尝试方案**：单纯给 SQL 加索引，降到 3s 但 DB 压力仍在；改成前端错峰轮询，用户体验变差。
**③ 最终方案**：**多层缓存 + SQL 覆盖索引 + DTO 聚合接口**。
- 一个接口 `/dashboard/all` 一次返回 5 个指标（DTO 合并）；
- 接口结果放 Redis TTL 10s，key = `dashboard:v1`；
- 复杂 SQL 全部走 `(create_time, status)` 覆盖索引；
- 定时任务提前预热（每 8s 主动刷新缓存）。
**④ 手写代码**：
```java
@GetMapping("/dashboard/all")
@Cacheable(value = "dashboard", key = "'v1'", unless = "#result == null")
public DashboardVO all() {
    return dashboardService.aggregate();
}
```
**效果**：大屏加载 3.2s → 300ms，DB QPS 从 50 → 5。

### 5.4 重点概念回顾

| 难点 | 关键技术 |
|------|----------|
| 预约超卖 | Redis SETNX + Lua + DB 唯一索引 |
| AI 流式 | SSE + Flux + ChatClient.stream() |
| RAG 更新 | MD5 指纹 + 增量入库 |
| AOP 性能 | @Async + 批量 flush |
| 大屏实时 | Redis 缓存 + 覆盖索引 + DTO 聚合 |

### 5.5 课后练习

1. 【基础】5 个难点每个写 300 字四段式提纲。
2. 【综合】选 2 个难点画 ASCII 白板图。
3. 【挑战】跟同学互相追问，每个难点接受 3 个追问不卡壳。

---

## 第 6 讲：模拟面试 + 一对一点评

### 6.1 本讲要点
- 掌握 30 分钟标准面试流程 5 环节
- 掌握"金牌 3 反问"模板
- 掌握四维点评模板（仪态 / 思路 / 深度 / 建议）
- 掌握"不会答"的救急话术

### 6.2 知识点详解

#### 6.2.1 【模板】30 分钟标准面试流程

| # | 环节 | 时长 | 内容 | 关键动作 |
|---|------|------|------|-----------|
| 1 | 自我介绍 | 2min | 名字 / 学历 / 项目主线 | 3 分钟自述压缩版 |
| 2 | 项目讲解 | 5-8min | 3 分钟自述 + 追问 | 讲完主线再展开 |
| 3 | 技术追问 | 10-15min | Spring/MySQL/Redis/AI | **结论 → 原理 → 项目落点** |
| 4 | 场景 / 手写 | 5-8min | 白板代码 or 系统设计 | 边想边说 |
| 5 | 反问环节 | 3-5min | 3 个反问 | 别问薪资 / 加班 |

#### 6.2.2 【模板】金牌 3 反问

**Q1 业务侧**：
> "贵司这个岗位在团队里主要负责哪块业务？现阶段团队最重要的 KPI 是什么？"

**Q2 技术侧**：
> "团队目前使用的技术栈里，您觉得哪一块是新人上手后最需要花时间理解的？"

**Q3 成长侧**：
> "如果我加入，前 3 个月的成长路径大概是什么样的？团队是否有 mentor 或 code review 机制？"

> **禁忌反问**：加班多不多 / 薪资多少 / 竞对公司 / 面试官个人隐私。这些问 HR。

#### 6.2.3 【模板】四维点评

| 维度 | 观察点 | 好 | 一般 | 差 |
|------|--------|----|------|-----|
| 仪态 | 眼神 / 手势 / 语速 | 平稳自然 | 偶尔低头 / 语速偏快 | 全程低头 / 抖腿 / 语无伦次 |
| 思路 | 结构 / 逻辑 | 结论先行 / 分点清晰 | 有点跳跃 | 想到哪说到哪 |
| 技术深度 | 原理 / 权衡 | 原理 + 项目落点 + 权衡 | 只讲现象 | 只有名词 |
| 建议 | 具体化程度 | 精确到某一句 | 泛泛 | 无 |

**点评模板句式**：
- 亮点：__（具体到某一段/某一句）__
- 待改进：__（具体到哪个知识点或哪句话）__
- 具体动作：__（下周应该干什么）__

#### 6.2.4 【模板】不会答的 3 句救急话术

- ① **迂回展开**："这个问题我实际项目中没直接碰到，但我的思路是……先想 A，然后 B……"
- ② **谦虚求教**："我目前的理解是这样，如果不准确请您指正——"
- ③ **给出计划**："这块之前只看过资料没落地过，如果给我一天时间，我会先做 X 再做 Y 来验证。"

> **避免**：沉默 20 秒 / 瞎编技术名词 / 直接说"不会"就完事。

#### 6.2.5 【模板】复盘改进计划

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
姓名：____   模拟日期：____
━━━━━━━━━━━━━━━━━━━━━━━━━━━━

本次表现：
1. 亮点（1 条）：__________
2. 待改进（1 条）：__________
3. 具体动作（1 条）：__________

下周 3 件事：
① 补 __________ 面试题（deadline __月__日）
② 重录 3 分钟自述（deadline __月__日）
③ 找 __ 人再模拟 1 次（deadline __月__日）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### 6.3 重点概念回顾

| 概念 | 一句话 |
|------|--------|
| 5 环节 | 自述 / 项目 / 追问 / 场景 / 反问 |
| 3 反问 | 业务 / 技术 / 成长 |
| 4 维点评 | 仪态 / 思路 / 深度 / 建议 |
| 3 救急 | 迂回 / 请指正 / 给我一天 |

### 6.4 【总结】12 天课程收官清单

离开教室时，你应该拥有：

| 沉淀物 | 描述 |
|--------|------|
| ✅ 简历项目描述 | 200-300 字，可直接投递 |
| ✅ 3 分钟自述 | 脱稿录音版 |
| ✅ 30 道面试题 | Spring/MySQL/Redis/AI 完整答案 |
| ✅ 5 个难点 | 四段式讲述 + 白板图 |
| ✅ 3 个反问 | 业务 / 技术 / 成长 |
| ✅ 至少 1 次模拟面试录音 | 用于复盘 |
| ✅ 复盘改进计划表 | 明确未来一周动作 |

### 6.5 【最终口诀】

> **"背景一句 + 我做啥一句 + 5 个亮点 + 3 个数字 + 5 个难点 + 30 个题目 + 3 个反问 + 1 次录音 = 一份合格的求职者。"**

### 6.6 课后练习

1. 【基础】完整 30 分钟模拟面试 1 次，录音留档。
2. 【综合】用四维模板给同学写点评单 1 份，并接受同学的点评。
3. 【挑战】一周内至少 3 次真人模拟面试（同学 / 学长 / AI 陪练均可），每次录音 + 复盘表 + 修订版 3 分钟自述。

---

## 附录 A：面试题速查表（30 道）

**Spring 8 题**
1. Bean 生命周期
2. IOC / DI 区别
3. Spring AOP 原理
4. @Transactional 失效 7 种
5. Spring 循环依赖
6. 事务传播 7 种
7. MP 分页插件原理
8. 事务隔离级别

**MySQL 7 题**
9. 索引不命中 8 种
10. 联合索引最左前缀
11. Explain type 全部值
12. 悲观锁 vs 乐观锁
13. MySQL 主从复制
14. 分库分表方案
15. SQL 优化实例

**Redis 7 题**
16. 缓存穿透
17. 缓存雪崩
18. 缓存击穿
19. 布隆过滤器
20. RDB vs AOF
21. Redis 集群三方案
22. 分布式锁 Redis vs Redisson

**AI 大模型 8 题**
23. LLM 原理（Transformer + SFT + RLHF）
24. Prompt 工程 5 法则
25. RAG 4 步流程
26. Function Calling
27. Embedding 与余弦相似度
28. 向量库选型
29. AI 限流令牌桶
30. Hallucination 应对 + 预算控制

---

## 附录 B：可直接拷贝的模板集合

### B.1 200-300 字项目描述（见 §1.4）
### B.2 3 分钟自述五段（见 §2.2.1）
### B.3 难点答辩四段式（见 §5.2）
### B.4 3 反问模板（见 §6.2.2）
### B.5 复盘改进计划表（见 §6.2.5）

> 🎉 **恭喜完成 12 天课程！**
> 面试是可以练的，项目是可以讲的，你已经准备好了。
> **祝你 offer 拿到手软。**
