# 《智能养老社区系统》- 学生讲义 - Day01：需求分析与数据库设计（AI 辅助）

**授课日：Day 01 / 共 12 天**
**适用对象：Java 全栈方向初学者（已完成 Java SE / MySQL / 前端 HTML+JS 基础）**
**项目案例：AI 智能养老社区系统**

---

## 第 1 讲：项目概述与需求分析方法

### 1.1 本讲要点
- 认识「AI 智能养老社区系统」的业务背景与商业价值
- 掌握用户角色划分（超级管理员 / 前台管理员 / 会员）
- 掌握六大核心模块及其数据流动关系
- 理解需求分析的三段式流程：调研 → 梳理 → 评审
- 能区分「功能需求（FR）」与「非功能需求（NFR）」

### 1.2 知识点详解

#### 1.2.1 项目定位
「AI 智能养老社区系统」是一款面向社区型养老服务机构的 SaaS 系统。区别于传统养老院信息管理系统，它把「AI 大模型」深度嵌入到业务流程中：会员在前台可以直接向 AI 客服咨询、由 AI 生成健康评测建议；管理员在后台通过 AI 快速生成报表分析和运营建议。

系统一期覆盖 **前台会员端 + 后台管理端** 两端，用户群体是 **老人本人 + 家属 + 社区管理员**。教学中我们把它作为「贯穿 12 天」的完整实战案例，Day01 打地基，Day02—Day09 造楼层，Day10—Day12 装修和验收。

#### 1.2.2 用户角色矩阵

| 角色         | 使用端     | 主要动作                                           | 权限点举例                      |
|--------------|------------|----------------------------------------------------|---------------------------------|
| 超级管理员   | 后台管理端 | 系统配置、账号管理、审计日志、AI 模型配置             | user:*, log:*, config:*         |
| 前台管理员   | 后台管理端 | 会员登记、客房调度、预约审核、健康档案                | member:*, room:*, reserve:*     |
| 会员/家属    | 前台会员端 | 浏览房型、下单预约、查看健康报告、AI 问答             | reserve:create, health:read     |

> 💡 **技巧：** 在设计权限时，先把「谁能做什么」列成表格，再翻译成权限编码（`资源:动作`），避免后续接口开发时权限混乱。

#### 1.2.3 六大核心模块与数据流

```
[会员管理] ── 产生会员 ID ──→ [预约管理] ──→ [客房管理]
                                │
                                └──→ [健康评测] ──→ [AI 智能应答]
                                                        │
                                                        ↓
                                              [数据可视化大屏]
```

- **会员管理**：老人的档案（基础信息、健康状态、会员等级）；
- **客房管理**：房型 + 房间 + 图片 + 状态；
- **预约管理**：把会员和房间在一段时间内绑定并出账单；
- **健康评测**：定期采集血压/心率/血糖，结合 AI 生成建议；
- **AI 智能应答**：面向会员的智能问答（Day05—Day07 讲解）；
- **数据可视化大屏**：面向管理员的运营看板（Day08 讲解）。

#### 1.2.4 需求分析三段式流程

| 阶段 | 输出物                                | 关键动作                                |
|------|---------------------------------------|-----------------------------------------|
| 调研 | 访谈记录、竞品对比表                    | 走访至少 2 家养老社区，对标 2 家竞品     |
| 梳理 | 用例图、功能清单、原型图                | 分模块梳理，字段/流程/异常分离           |
| 评审 | 评审会议纪要、需求文档 v1               | 客户、产品、开发、测试四方签字确认       |

> ⚠️ **注意：** 不要跳过「评审」这一步——超过 60% 的项目延期，都源于「需求评审阶段偷懒」。

#### 1.2.5 FR vs NFR

| 类型 | 全称                | 描述层次       | 示例                                         |
|------|---------------------|----------------|----------------------------------------------|
| FR   | Functional Req.     | 系统「做什么」  | FR-01 支持按姓名/手机号搜索会员，支持分页       |
| NFR  | Non-Functional Req. | 系统「做得怎样」| NFR-01 列表接口平均响应时间 < 500 ms          |

FR 要「可测试」——每条需求都能写成一个测试用例；NFR 要「可度量」——每条都能给出数字目标。

### 1.3 重点概念回顾

| 概念       | 说明                                    |
|------------|-----------------------------------------|
| SaaS       | Software as a Service，多租户订阅制软件  |
| 前台/后台   | 前台面向 C 端会员，后台面向 B 端管理员    |
| FR/NFR     | 功能需求 / 非功能需求                    |
| 需求评审   | 客户+产品+开发+测试四方签字的正式过程     |

### 1.4 示例代码/例题解析

**示例 1：一份规范的需求清单片段**
```markdown
# 会员管理模块 - 需求清单 v0.1
## 功能需求
| 编号   | 优先级 | 描述                                                       |
|--------|--------|------------------------------------------------------------|
| FR-01  | P0     | 支持按姓名 / 手机号 / 会员等级搜索会员，支持分页             |
| FR-02  | P0     | 新增会员时校验身份证（18 位，末位可为 X）与手机号（11 位）    |
| FR-03  | P1     | 会员详情页展示最近 3 次健康检测记录                          |

## 非功能需求
| 编号   | 描述                                                       |
|--------|------------------------------------------------------------|
| NFR-01 | 列表查询接口平均响应 < 500ms，P95 < 1s                     |
| NFR-02 | 身份证、手机号在数据库中加密存储（AES-128）                  |
```
原理解释：编号「FR-01」的编码规则便于评审时精确定位；优先级 P0/P1/P2 便于排期。

### 1.5 课后练习

1. 【基础】用一句话概括「AI 智能养老社区系统」的核心业务定位，字数不超过 40 字。
2. 【综合】为「健康评测模块」写出 5 条 FR + 2 条 NFR，采用规范化编号与措辞。
3. 【挑战】画出六大模块之间的数据流动图（可用手绘、draw.io、Excalidraw），并标注关键字段依赖。

---

## 第 2 讲：使用 DeepSeek 辅助需求分析

### 2.1 本讲要点
- 认识 DeepSeek 大模型的特点与登录方式
- 掌握「角色 + 任务 + 输出格式」三段式 Prompt 结构
- 学会用 Prompt 让 AI 输出结构化功能清单
- 学会用「AI 评审四问」审校 AI 输出，识别幻觉

### 2.2 知识点详解

#### 2.2.1 DeepSeek 简介
DeepSeek 是国内深度求索公司推出的开源大模型，具备中文理解强、代码能力强、成本低（相对海外闭源模型）三大特点。使用方式：
- 网页版：<https://chat.deepseek.com>（今天使用）
- API：与 OpenAI 协议兼容，`base_url=https://api.deepseek.com`（Day05 后使用）

登录方式：手机号 + 验证码，无需科学上网。免费额度足够学习使用。

#### 2.2.2 三段式 Prompt 结构

| 段落          | 目的                             | 常用起手式                                     |
|---------------|----------------------------------|------------------------------------------------|
| 角色 Role     | 让 AI 代入身份，约束风格与深度     | 「你是一名有 10 年 XX 经验的 YY…」              |
| 任务 Task     | 明确要做什么、覆盖范围、约束      | 「请为 XX 模块拆解 15 条以上功能需求…」         |
| 输出 Format   | 强约束结构，方便复用与解析        | 「使用 Markdown 表格，列依次为：编号 优先级 描述」|

> 💡 **技巧：** 越是「让 AI 少发挥」的 Prompt，越能得到工业化可用的输出。三段式的本质是把「不确定的语言」变为「确定的表格」。

> ⚠️ **注意：** Prompt 中的「不少于 15 条」比「多写一些」更有效，AI 对数字更敏感。

#### 2.2.3 AI 评审四问
每次拿到 AI 输出，都要问自己：
1. **是否偏离业务？** —— AI 可能虚构不存在的功能（如「区块链健康档案」）；
2. **是否可测试？** —— 「支持强大的搜索功能」不合格，改为「支持按姓名、手机号、身份证号三种维度模糊搜索」；
3. **是否与其它模块冲突？** —— 字段命名、接口路径是否重复；
4. **是否遗漏边界？** —— 空数据、大数据量、并发操作、异常回滚是否考虑。

### 2.3 重点概念回顾

| 概念        | 说明                                              |
|-------------|---------------------------------------------------|
| Prompt      | 输入给大模型的提示词，决定输出上限                 |
| 幻觉        | AI 编造看似合理实则错误的内容                     |
| 三段式      | 角色 + 任务 + 输出格式                            |
| 评审四问    | 偏业务？可测试？冲突？边界？                       |

### 2.4 示例代码/例题解析

**示例 1：客房管理模块的三段式 Prompt**
```text
# 角色
你是一名有 10 年 SaaS 系统经验的高级产品经理，同时熟悉智慧养老行业。

# 任务
项目背景：正在开发「AI 智能养老社区系统」（前台会员端 + 后台管理端）。
请为「客房管理」模块拆解详细功能需求：
1. 不少于 15 条 FR，至少 3 条 NFR；
2. 每条需求措辞需可测试；
3. 覆盖：房型维护、房间维护、图片管理、上下架、批量操作、状态流转；
4. 与「预约管理」的交互需明确指出，但预约的具体规则不在本次范围。

# 输出格式
Markdown 表格，列依次为：编号 | 类型 | 优先级(P0/P1/P2) | 需求描述 | 备注
```

原理解释：
- 角色段先「设定语境」；
- 任务段用**编号列表**表述约束，AI 会逐条回应；
- 输出段直接指定表格结构，方便复制到需求文档。

**示例 2：AI 输出片段（真实 DeepSeek 风格）**
```markdown
| 编号   | 类型 | 优先级 | 需求描述                                                | 备注                     |
|--------|------|--------|---------------------------------------------------------|--------------------------|
| FR-01  | FR   | P0     | 支持新增房型：包含房型名称、日单价、可住人数、描述        | 房型名称唯一             |
| FR-02  | FR   | P0     | 支持按房型名称、房间号搜索房间，支持分页                  | 与预约管理共用列表接口   |
| FR-03  | FR   | P0     | 支持上传房间图片（≤ 2MB，jpg/png），可批量上传 5 张        | 存 OSS 或本地            |
| ...    | ...  | ...    | ...                                                     | ...                      |
| NFR-01 | NFR  | -      | 图片上传接口平均响应 < 1s                                | 使用 CDN                 |
```

学生要做的：读一遍，圈出「与预约管理接口共用」这类**跨模块耦合项**，评审时重点讨论。

### 2.5 课后练习

1. 【基础】按三段式，为「AI 智能应答模块」写出 Prompt 并粘贴 AI 输出结果。
2. 【综合】把 AI 输出的 FR 中，找出至少 2 条**幻觉/偏业务**的条目，标注理由并改写。
3. 【挑战】用一份 Prompt 让 AI 输出**六大模块**的整体功能清单，尝试通过一次调用得到可用的 v1.0 版需求文档骨架。

---

## 第 3 讲：数据库设计原则与 E-R 建模

### 3.1 本讲要点
- 掌握第一、第二、第三范式的定义与工程解读
- 理解「反范式」在报表、快照场景下的合理性
- 熟练使用 E-R 图表达实体与关系（1:1 / 1:N / M:N）
- 掌握字段类型选择：VARCHAR / INT / DECIMAL / DATETIME
- 掌握团队级命名规范（小写下划线 + id + create_time / update_time）

### 3.2 知识点详解

#### 3.2.1 三大范式

| 范式 | 一句话定义                       | 违反例子                                     | 工程建议                     |
|------|----------------------------------|----------------------------------------------|------------------------------|
| 1NF  | 字段不可再分（原子性）             | address = "北京市海淀区中关村1号" 需分省市     | 视业务粒度决定                |
| 2NF  | 非主键字段完全依赖主键            | 联合主键时，字段只依赖其中一列                | 尽量单列主键 `id`             |
| 3NF  | 非主键字段无传递依赖              | 员工表存部门 ID 又存部门名                    | 冗余需权衡（见反范式）        |

> 💡 **技巧：** 学生阶段严格遵守三范式；进入优化阶段（Day10）时按场景反范式。

#### 3.2.2 反范式的三种合理场景
1. **报表大屏**：多表 join 太慢，把常用汇总冗余到一张宽表；
2. **历史快照**：订单表冗余「下单时的会员姓名/手机」，避免会员改名后订单错乱；
3. **性能优化**：预计算字段（如 `total_price` 存起来而不是每次计算）。

#### 3.2.3 E-R 图核心元素

| 元素 | 图形 | 说明                                    |
|------|------|-----------------------------------------|
| 实体 | 矩形 | 一张表，如 `elder_member`                |
| 属性 | 椭圆 | 一列字段，实操中常用字段清单代替椭圆       |
| 关系 | 菱形 | 表与表之间的关系，标注基数（1:1/1:N/M:N）|

**M:N 关系必须引入中间表**。本项目暂无 M:N，因为一次预约只对应一个房间。

#### 3.2.4 字段类型选择

| 类型              | 场景                    | 常见错误                             |
|-------------------|-------------------------|--------------------------------------|
| `VARCHAR(N)`      | 变长字符串              | N 一律 255（浪费索引空间）           |
| `CHAR(N)`         | 定长（身份证 18 位）     | 短字段用会浪费                       |
| `TINYINT`         | 状态、性别、角色         | 用 INT 存 0/1（浪费空间）            |
| `INT`             | 一般整数                | 存手机号（超长溢出）                 |
| `BIGINT`          | 主键、雪花 ID            | 与 `Long` 匹配                       |
| `DECIMAL(10,2)`   | 金额、比率              | 用 FLOAT/DOUBLE（精度丢失）          |
| `DATETIME`        | 业务时间戳              | 用 `TIMESTAMP`（2038 问题）          |

> ⚠️ **注意：** 金额字段永远不要用浮点，`0.1 + 0.2 !== 0.3` 的教训不能忘。

#### 3.2.5 命名规范

| 层次       | 规则                                                | 示例                     |
|------------|-----------------------------------------------------|--------------------------|
| 数据库名   | 小写下划线                                           | `smart_elder`            |
| 表名       | 小写下划线，业务前缀 + 名词                          | `elder_member`, `sys_user` |
| 字段名     | 小写下划线                                           | `member_level`, `create_time` |
| 主键       | 统一 `id`（BIGINT AUTO_INCREMENT）                   | `id`                     |
| 时间字段   | `create_time` / `update_time`                        | `DATETIME`               |
| 布尔字段   | `is_xxx` 或 `status` + 字典                          | `is_deleted`, `status`   |
| 索引名     | `idx_列名` / `uk_列名`                               | `idx_phone`, `uk_username` |

### 3.3 重点概念回顾

| 概念     | 说明                                              |
|----------|---------------------------------------------------|
| 三范式   | 原子 → 完全依赖 → 无传递依赖                       |
| 反范式   | 为性能/快照允许可控冗余                            |
| E-R 图   | 实体—关系—属性的直观表达                          |
| 逻辑外键 | 不建物理 FOREIGN KEY，靠应用层保证一致性            |

### 3.4 示例代码/例题解析

**示例 1：把 E-R 翻译成 DDL 片段**
```sql
-- room_type ↔ room_info：1:N
CREATE TABLE room_type (
  id        BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '房型ID',
  type_name VARCHAR(50) NOT NULL COMMENT '房型名称',
  price     DECIMAL(10,2) NOT NULL COMMENT '日单价',
  capacity  INT NOT NULL DEFAULT 1 COMMENT '可住人数',
  UNIQUE KEY uk_type_name (type_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型表';

CREATE TABLE room_info (
  id      BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '房间ID',
  room_no VARCHAR(20) NOT NULL COMMENT '房间号',
  type_id BIGINT NOT NULL COMMENT '房型ID',
  status  TINYINT NOT NULL DEFAULT 0 COMMENT '0空闲 1入住 2维修 3下架',
  UNIQUE KEY uk_room_no (room_no),
  KEY idx_type_id (type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间表';
```

原理解释：`type_id` 通过 `idx_type_id` 建立索引以加速 join 查询；不建 FOREIGN KEY 是团队约定。

### 3.5 课后练习

1. 【基础】判断以下字段类型是否合理，并给出理由：
   - `phone INT`
   - `price FLOAT(10,2)`
   - `create_time TIMESTAMP`
2. 【综合】为「健康检测」画出 E-R 图，并写出 DDL 片段（至少包含 6 个字段）。
3. 【挑战】列举 2 个本项目适合「反范式」的场景，并写出冗余字段。

---

## 第 4 讲：使用 DeepSeek 生成建表 SQL

### 4.1 本讲要点
- 掌握「AI 生成 DDL」的 Prompt 要点
- 掌握 6 项人工审校清单（字符集 / 引擎 / 类型 / 索引 / 注释 / 外键）
- 理解本项目为何选择「逻辑外键 + 索引」策略
- 建立「AI 打草稿，人拍板」的工程习惯

### 4.2 知识点详解

#### 4.2.1 生成 DDL 的 Prompt 关键点
1. 明确 MySQL 版本（8.0）与字符集（utf8mb4）；
2. 提供命名规范（第 3 讲小节 3.2.5）；
3. 提供**每张表字段清单**（AI 才知道要建哪些列）；
4. 明确约束：InnoDB、每字段 COMMENT、索引策略、外键策略；
5. 明确输出格式：可直接执行的 SQL 脚本，`DROP + CREATE`。

#### 4.2.2 人工审校六项清单

| 序号 | 检查项       | 常见错误                                   | 修正示例                                     |
|------|--------------|--------------------------------------------|----------------------------------------------|
| 1    | 字符集       | `utf8` 而非 `utf8mb4`                     | `DEFAULT CHARSET=utf8mb4`                    |
| 2    | 引擎         | 输出 `MyISAM`                              | `ENGINE=InnoDB`                              |
| 3    | 类型/长度    | `phone INT` / `id_card VARCHAR(15)`        | `phone VARCHAR(20)`, `id_card VARCHAR(20)`   |
| 4    | 索引         | 高频查询字段无索引                          | 加 `KEY idx_phone (phone)`                   |
| 5    | 注释         | 字段/表 COMMENT 缺失                       | 补 `COMMENT '中文说明'`                      |
| 6    | 外键         | 不符合团队约定（本项目：逻辑外键）           | 移除 `FOREIGN KEY`，保留 `KEY idx_xx`         |

#### 4.2.3 外键策略选择

| 策略        | 优点               | 缺点                     | 适用场景          |
|-------------|--------------------|--------------------------|-------------------|
| 物理外键    | 强一致、自动级联    | 分库分表难、并发差、迁移麻烦 | 内部管理系统       |
| 逻辑外键    | 灵活、性能好        | 需应用层保证一致性         | 互联网/SaaS 项目 |

**本项目采用逻辑外键** —— 用 `KEY idx_xxx` 保证查询效率，一致性由 Service 层事务与幂等控制。

> ⚠️ **注意：** 阿里巴巴《Java 开发手册》明确规定：「【强制】不得使用外键与级联，一切外键概念必须在应用层解决」。这是主流互联网公司的一致选择。

### 4.3 重点概念回顾

| 概念        | 说明                                              |
|-------------|---------------------------------------------------|
| DDL         | Data Definition Language：CREATE/ALTER/DROP        |
| 逻辑外键    | 只建索引不建 FK 约束                              |
| 索引        | 加速查询的数据结构（B+ 树）                        |
| 审校清单    | 6 项：字符集/引擎/类型/索引/注释/外键              |

### 4.4 示例代码/例题解析

**示例 1：生成 DDL 的完整 Prompt**
```text
# 角色
你是一名资深 Java 后端架构师，熟悉 MySQL 8.0 与阿里 Java 开发手册。

# 任务
请为「AI 智能养老社区系统」生成以下 7 张表的建表 DDL：
1. sys_user 系统用户表：id, username, password, real_name, phone, role,
   create_time, update_time
2. elder_member 会员表：id, name, gender, age, phone, id_card, address,
   emergency_contact, health_status, member_level, create_time
3. room_type 房型表：id, type_name, price, capacity, description
4. room_info 房间表：id, room_no, type_id, floor, status, image_url, create_time
5. room_reservation 预约表：id, member_id, room_id, check_in_date,
   check_out_date, status, total_price, create_time
6. health_check 健康检测表：id, member_id, check_date, blood_pressure,
   heart_rate, blood_sugar, advice
7. operation_log 操作日志表：id, user_id, operation, method, params,
   ip, cost_time, create_time

# 约束
- MySQL 8.0，全部 InnoDB + utf8mb4_unicode_ci；
- 主键统一 id BIGINT AUTO_INCREMENT；
- 表和每个字段都要 COMMENT；
- 不使用物理外键，但为外键字段建索引；
- phone VARCHAR(20)，id_card VARCHAR(20)，金额 DECIMAL(10,2)；
- status 类字段用 TINYINT 并在注释里列出取值；
- 查询高频字段（phone、id_card、member_id、room_id、create_time）建索引。

# 输出格式
可直接执行的 SQL 脚本，每张表用 DROP TABLE IF EXISTS + CREATE TABLE 表示，
每张表之间空一行。
```

原理解释：Prompt 越具体，AI 越难跑偏。**约束段中的每一句都对应一项审校清单。**

**示例 2：审校后修正片段**
```sql
-- ❌ AI 原始输出（错误）
`phone` INT DEFAULT NULL COMMENT '手机号',

-- ✅ 审校修正
`phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
KEY `idx_phone` (`phone`),
```

### 4.5 课后练习

1. 【基础】把上面的 Prompt 复制到 DeepSeek 运行，把输出保存为 `smart_elder_ai_v0.sql`。
2. 【综合】按 6 项清单，逐条对比 `smart_elder_ai_v0.sql` 与本讲义文末「附录 A 建表脚本汇总」，标注至少 5 处差异。
3. 【挑战】把 Prompt 改造为「为 sys_user 表增加软删除字段 `is_deleted TINYINT`」的修改语句，让 AI 输出 `ALTER TABLE` 脚本。

---

## 第 5 讲：完善建表脚本并导入 MySQL

### 5.1 本讲要点
- 掌握「附录 A」中 7 张完整表的最终结构
- 掌握两种 SQL 导入方式：命令行、Navicat
- 熟悉常见导入错误的排查方法
- 能够独立完成数据库初始化并做基础验证

### 5.2 知识点详解

#### 5.2.1 数据库与用户准备
```sql
CREATE DATABASE IF NOT EXISTS smart_elder
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE smart_elder;
```

#### 5.2.2 三种导入方式对比

| 方式        | 命令/操作                                        | 优势         | 劣势               |
|-------------|--------------------------------------------------|--------------|--------------------|
| 命令行 pipe | `mysql -uroot -p smart_elder < ddl.sql`          | 快、脚本化    | 需熟悉命令         |
| MySQL 交互  | `source /path/to/ddl.sql;`                       | 交互友好      | 需先 `USE`         |
| Navicat     | 右键数据库 → 运行 SQL 文件                       | 图形化       | 依赖客户端安装      |

> 💡 **技巧：** 团队开发中约定 `sql/init.sql` 为项目初始化脚本，新成员本地开发前只需执行一次即可。

#### 5.2.3 常见错误速查

| 错误信息                                | 原因                        | 处理                                 |
|-----------------------------------------|-----------------------------|--------------------------------------|
| `Row size too large`                    | 字段过多或 VARCHAR 过长      | 缩小 VARCHAR / 拆表                  |
| `Incorrect string value`                | 字符集不是 utf8mb4          | 数据库、表、字段都改为 utf8mb4        |
| `Duplicate entry ... for key`           | 重复插入或表未 DROP          | 加 `DROP TABLE IF EXISTS`            |
| `Unknown collation utf8mb4_0900_ai_ci`  | MySQL 版本低于 8.0          | 改为 `utf8mb4_unicode_ci`            |
| `Access denied for user`                | 账号密码或权限不对           | 检查用户与授权 `GRANT`               |

### 5.3 重点概念回顾

| 概念              | 说明                                              |
|-------------------|---------------------------------------------------|
| `source` 命令      | MySQL 客户端执行外部 SQL 文件                      |
| utf8mb4           | 4 字节 UTF-8，支持 Emoji 与生僻字                  |
| InnoDB            | 支持事务、行锁、外键（本项目不用 FK 但用其他能力）   |
| 校对集 collation  | 决定字符串比较规则                                 |

### 5.4 示例代码/例题解析

**示例 1：完整导入并验证**
```bash
# 1. 在命令行导入
mysql -uroot -p123456 < smart_elder_v1.sql

# 2. 进入 MySQL 验证
mysql -uroot -p123456
```

```sql
-- 3. 在 MySQL 提示符下
USE smart_elder;
SHOW TABLES;
-- 期望输出 7 张表

SHOW CREATE TABLE elder_member\G
-- 检查字符集是否 utf8mb4，引擎是否 InnoDB
```

**示例 2：插入测试数据**
```sql
-- 系统用户（超管 + 前台）
INSERT INTO sys_user(username, password, real_name, phone, role)
VALUES ('admin', '$2a$10$demoHashForClassOnly', '超级管理员', '13800000000', 1),
       ('front01', '$2a$10$demoHashForClassOnly', '张前台', '13900000001', 2);

-- 会员
INSERT INTO elder_member(name, gender, age, phone, id_card, address,
                         emergency_contact, health_status, member_level)
VALUES ('王秀兰', 2, 72, '13800001111', '110101195301010012', '北京市海淀区xx小区',
        '王小明 13711112222', '良好', 3),
       ('李国庆', 1, 78, '13800002222', '110101194801010021', '北京市朝阳区yy小区',
        '李红 13722223333', '一般', 2);

-- 房型
INSERT INTO room_type(type_name, price, capacity, description)
VALUES ('单人间', 288.00, 1, '独立卫浴 · 阳光房'),
       ('双人间', 388.00, 2, '双床 · 独立卫浴'),
       ('康复房', 588.00, 1, '带监测设备 · 24 小时护理');

-- 房间
INSERT INTO room_info(room_no, type_id, floor, status)
VALUES ('101', 1, 1, 0),
       ('102', 1, 1, 0),
       ('201', 2, 2, 1);
```

原理解释：先插基础表（`sys_user`, `elder_member`, `room_type`），再插关联表（`room_info` 依赖 `room_type`），最后才可以插入 `room_reservation`。**顺序错了会因约束失败**。

**示例 3：错误示范排查**
```sql
-- ❌ 尝试插入超范围枚举
INSERT INTO elder_member(name, gender) VALUES ('测试', 5);
-- 结果：本项目未加 CHECK 约束，会插入成功，但业务上是脏数据

-- ✅ 建议在应用层用枚举/校验兜住；也可加 CHECK：
ALTER TABLE elder_member ADD CONSTRAINT ck_gender CHECK (gender IN (0,1,2));
```

### 5.5 课后练习

1. 【基础】使用 `source` 命令导入本讲义附录 A 的完整 DDL，并截图 `SHOW TABLES` 结果。
2. 【综合】为每张表插入 3 条测试数据，形成 `data.sql`，作业提交时一起上交。
3. 【挑战】故意制造 3 种错误（字符集、字段过长、状态取值超范围），并写下你的排查步骤和结论。

---

## 第 6 讲：小结 + 项目文档整理 + Git 初始化

### 6.1 本讲要点
- 掌握需求文档、数据库设计文档的标准结构
- 掌握 Git 基础流程：init → add → commit → remote → push
- 熟练编写 `.gitignore` 与 Commit Message 规范
- 建立 Day01 的完整闭环：需求 → E-R → DDL → 导入 → 文档 → Git

### 6.2 知识点详解

#### 6.2.1 需求文档模板
```
1. 项目背景
2. 用户角色
3. 模块划分（一句话概括每个模块）
4. 功能需求清单（编号 | 优先级 | 描述 | 备注）
5. 非功能需求
6. 术语表
7. 版本历史
```

#### 6.2.2 数据库设计文档模板
```
1. 命名规范
2. 表清单（表名 | 中文名 | 说明 | 记录数量级）
3. 逐表字段清单（字段名 | 类型 | 是否为空 | 默认值 | 说明 | 索引）
4. E-R 图
5. 索引说明
6. 版本历史
```

#### 6.2.3 Git 基础命令

| 命令                          | 作用                    |
|-------------------------------|-------------------------|
| `git init`                    | 初始化本地仓库           |
| `git status`                  | 查看工作区状态           |
| `git add .`                   | 全部改动加入暂存区        |
| `git commit -m "msg"`         | 提交暂存区到本地仓库      |
| `git remote add origin <url>` | 关联远程仓库              |
| `git push -u origin main`     | 首次推送并追踪主分支      |
| `git log --oneline`           | 查看提交历史             |

#### 6.2.4 .gitignore 关键条目
```gitignore
# JetBrains
.idea/
*.iml

# Maven
target/

# Node
node_modules/
dist/

# Logs
logs/
*.log

# Local config
application-local.yml
```

#### 6.2.5 Commit Message 规范（Conventional Commits 简版）

| 前缀     | 含义              | 示例                                  |
|----------|-------------------|---------------------------------------|
| `feat`   | 新功能            | `feat: 会员分页查询接口`               |
| `fix`    | Bug 修复          | `fix: 会员搜索大小写敏感问题`           |
| `docs`   | 文档              | `docs: init day01 requirements`        |
| `chore`  | 构建/杂项          | `chore: add .gitignore`                |
| `refactor` | 重构           | `refactor: 抽取分页工具类`             |

> 💡 **技巧：** 一条提交只做一件事，Message 用现在时动词开头，中文英文都可以，团队内保持一致。

### 6.3 重点概念回顾

| 概念              | 说明                                              |
|-------------------|---------------------------------------------------|
| 工作区/暂存区/仓库 | Git 三大区，`add` 从工作区到暂存，`commit` 到仓库  |
| 远程仓库          | 存放在 Gitee/GitHub 服务器上的仓库副本              |
| .gitignore        | 声明不进入 Git 管理的路径与文件                    |
| Commit Message    | 遵循规范便于自动化生成 CHANGELOG                   |

### 6.4 示例代码/例题解析

**示例 1：Day01 结束的完整初始化流程**
```bash
# 1. 项目目录
mkdir smart-elder && cd smart-elder
mkdir docs sql

# 2. 拷入今日产出
cp ~/Downloads/smart_elder_v1.sql sql/
# docs/需求清单v1.md   docs/数据库设计文档v1.md 手写完成

# 3. Git 初始化
git init
git branch -M main

# 4. .gitignore
cat > .gitignore <<'EOF'
.idea/
*.iml
target/
node_modules/
dist/
logs/
*.log
application-local.yml
EOF

# 5. README 占位
cat > README.md <<'EOF'
# AI 智能养老社区系统

面向社区型养老服务机构的 SaaS 系统，覆盖会员、客房、预约、健康评测、
AI 智能应答、数据大屏等 6 大模块。

## 技术栈
- 后端：SpringBoot + MyBatis-Plus + MySQL 8.0 + Redis + Spring AI
- 前端：Vue 3 + Vite + Element Plus + Echarts
- 部署：Nginx + Docker
EOF

# 6. 首次提交
git add .
git commit -m "docs: init day01 requirements & database design"

# 7. 关联远程并推送（先在 Gitee 建好空仓库）
git remote add origin git@gitee.com:your-account/smart-elder.git
git push -u origin main
```

原理解释：先建目录，再拷贝产出物，再 `git init`，避免遗漏子目录；`.gitignore` 一定要在第一次 `add` 前放好，否则 `.idea/` 已经进入版本库，后续删除麻烦。

### 6.5 课后练习

1. 【基础】按上面流程完成本地仓库初始化，并把 Day01 所有产出（sql + docs + README）提交一次，`git log --oneline` 至少 1 条记录。
2. 【综合】把仓库推送到 Gitee，创建 `dev` 分支，在 `dev` 上追加一次 `docs: add erd` 提交（把 E-R 图放入 `docs/`）。
3. 【挑战】用 Git 命令模拟一次「误提交敏感文件」并回滚：先 `git commit` 一个 `application-local.yml`（包含假密码），再补 `.gitignore` 并把该文件从历史中移除（`git rm --cached`）。

---

## 附录 A：Day01 建表脚本汇总（完整可运行）

```sql
-- ============================================================
-- 《AI 智能养老社区系统》数据库初始化脚本 v1.0
-- 环境：MySQL 8.0 · InnoDB · utf8mb4_unicode_ci
-- 说明：本脚本会 DROP 已有 smart_elder 库，谨慎在生产使用！
-- ============================================================

DROP DATABASE IF EXISTS smart_elder;
CREATE DATABASE smart_elder
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE smart_elder;

-- ------------------------------------------------------------
-- 1. 系统用户表 sys_user
-- ------------------------------------------------------------
DROP TABLE IF EXISTS sys_user;
CREATE TABLE sys_user (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  username     VARCHAR(50)  NOT NULL COMMENT '登录账号',
  password     VARCHAR(100) NOT NULL COMMENT '密码（BCrypt 加密）',
  real_name    VARCHAR(50)  DEFAULT NULL COMMENT '真实姓名',
  phone        VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  role         TINYINT      NOT NULL DEFAULT 2 COMMENT '角色：1超管 2前台管理员',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_username (username),
  KEY idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- ------------------------------------------------------------
-- 2. 会员表 elder_member
-- ------------------------------------------------------------
DROP TABLE IF EXISTS elder_member;
CREATE TABLE elder_member (
  id                 BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  name               VARCHAR(50)  NOT NULL COMMENT '姓名',
  gender             TINYINT      NOT NULL DEFAULT 0 COMMENT '性别：0未知 1男 2女',
  age                INT          DEFAULT NULL COMMENT '年龄',
  phone              VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  id_card            VARCHAR(20)  DEFAULT NULL COMMENT '身份证号',
  address            VARCHAR(255) DEFAULT NULL COMMENT '家庭住址',
  emergency_contact  VARCHAR(100) DEFAULT NULL COMMENT '紧急联系人（姓名+电话）',
  health_status      VARCHAR(50)  DEFAULT '良好' COMMENT '健康状态：良好/一般/较差',
  member_level       TINYINT      NOT NULL DEFAULT 1 COMMENT '会员等级：1普通 2银卡 3金卡 4钻石',
  create_time        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_phone (phone),
  KEY idx_id_card (id_card),
  KEY idx_member_level (member_level),
  KEY idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='养老会员表';

-- ------------------------------------------------------------
-- 3. 房型表 room_type
-- ------------------------------------------------------------
DROP TABLE IF EXISTS room_type;
CREATE TABLE room_type (
  id           BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  type_name    VARCHAR(50)   NOT NULL COMMENT '房型名称',
  price        DECIMAL(10,2) NOT NULL COMMENT '日单价（元）',
  capacity     INT           NOT NULL DEFAULT 1 COMMENT '可住人数',
  description  VARCHAR(500)  DEFAULT NULL COMMENT '房型描述',
  PRIMARY KEY (id),
  UNIQUE KEY uk_type_name (type_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型表';

-- ------------------------------------------------------------
-- 4. 房间信息表 room_info
-- ------------------------------------------------------------
DROP TABLE IF EXISTS room_info;
CREATE TABLE room_info (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  room_no      VARCHAR(20)  NOT NULL COMMENT '房间号',
  type_id      BIGINT       NOT NULL COMMENT '房型ID（逻辑外键 → room_type.id）',
  floor        INT          NOT NULL COMMENT '楼层',
  status       TINYINT      NOT NULL DEFAULT 0 COMMENT '状态：0空闲 1入住 2维修 3下架',
  image_url    VARCHAR(255) DEFAULT NULL COMMENT '房间图片URL',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_room_no (room_no),
  KEY idx_type_id (type_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间信息表';

-- ------------------------------------------------------------
-- 5. 客房预约表 room_reservation
-- ------------------------------------------------------------
DROP TABLE IF EXISTS room_reservation;
CREATE TABLE room_reservation (
  id              BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  member_id       BIGINT        NOT NULL COMMENT '会员ID（逻辑外键 → elder_member.id）',
  room_id         BIGINT        NOT NULL COMMENT '房间ID（逻辑外键 → room_info.id）',
  check_in_date   DATE          NOT NULL COMMENT '入住日期',
  check_out_date  DATE          NOT NULL COMMENT '退房日期',
  status          TINYINT       NOT NULL DEFAULT 0 COMMENT '状态：0待确认 1已确认 2已入住 3已退房 4已取消',
  total_price     DECIMAL(10,2) NOT NULL COMMENT '订单总价',
  create_time     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_member_id (member_id),
  KEY idx_room_id (room_id),
  KEY idx_status (status),
  KEY idx_check_in_date (check_in_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房预约表';

-- ------------------------------------------------------------
-- 6. 健康检测表 health_check
-- ------------------------------------------------------------
DROP TABLE IF EXISTS health_check;
CREATE TABLE health_check (
  id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  member_id       BIGINT       NOT NULL COMMENT '会员ID（逻辑外键 → elder_member.id）',
  check_date      DATETIME     NOT NULL COMMENT '检测时间',
  blood_pressure  VARCHAR(20)  DEFAULT NULL COMMENT '血压（收缩压/舒张压 mmHg）',
  heart_rate      INT          DEFAULT NULL COMMENT '心率（次/分）',
  blood_sugar     DECIMAL(5,2) DEFAULT NULL COMMENT '血糖（mmol/L）',
  advice          VARCHAR(500) DEFAULT NULL COMMENT 'AI 建议或医生备注',
  PRIMARY KEY (id),
  KEY idx_member_id (member_id),
  KEY idx_check_date (check_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='健康检测表';

-- ------------------------------------------------------------
-- 7. 操作日志表 operation_log
-- ------------------------------------------------------------
DROP TABLE IF EXISTS operation_log;
CREATE TABLE operation_log (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  user_id      BIGINT       DEFAULT NULL COMMENT '操作人ID（逻辑外键 → sys_user.id）',
  operation    VARCHAR(100) DEFAULT NULL COMMENT '操作描述',
  method       VARCHAR(200) DEFAULT NULL COMMENT '被调用方法（类+方法名）',
  params       TEXT         DEFAULT NULL COMMENT '请求参数（JSON）',
  ip           VARCHAR(50)  DEFAULT NULL COMMENT '请求 IP',
  cost_time    BIGINT       DEFAULT NULL COMMENT '耗时（毫秒）',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_user_id (user_id),
  KEY idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';
```

## 附录 B：Day01 常用命令速查

```bash
# MySQL 导入
mysql -uroot -p smart_elder < smart_elder_v1.sql
# 或进入 MySQL 后
mysql> USE smart_elder;
mysql> source /path/to/smart_elder_v1.sql;

# 验证
mysql> SHOW TABLES;
mysql> SHOW CREATE TABLE elder_member\G

# Git
git init
git add .
git commit -m "docs: init day01 requirements & database design"
git remote add origin git@gitee.com:your-account/smart-elder.git
git push -u origin main
```
