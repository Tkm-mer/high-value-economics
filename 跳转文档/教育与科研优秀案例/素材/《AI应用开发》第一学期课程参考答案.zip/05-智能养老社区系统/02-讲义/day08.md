# 《智能养老社区系统》- 学生讲义 - Day08：Echarts 统计大屏（复杂报表 SQL + 可视化）

**授课日：Day 08 / 共 12 天**
**适用对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**技术点：技术点 10 - 复杂报表 SQL + Echarts 可视化 + 大屏适配**

---

## 第 1 讲：报表需求与大屏原型

### 1.1 本讲要点
- 大屏的定位：面向决策层的"驾驶舱"，非面向操作
- 5 大 KPI 指标 + 4 类图表的完整清单
- 三栏布局比例：顶 20% / 中 55% / 底 25%
- 深色科技风色板（#0a1128 主色）

### 1.2 知识点详解

#### 1.2.1 大屏 vs 后台管理页

| 维度 | 后台管理页 | 大屏 |
|------|-----------|-----|
| 使用者 | 运营 / 客服 | 老板 / 决策层 |
| 目标 | 处理业务 | 观察指标 |
| 交互 | 增删改查、筛选 | 只看，不交互 |
| 分辨率 | 自适应 | 固定 1920×1080 |
| 色调 | 白底浅色 | 深色科技风 |
| 刷新 | 主动请求 | 定时轮询（30s） |

> 💡 **技巧：** 大屏首要目标是"3 秒内看清今天状况"，任何需要点击 2 次才能看到的数字都不合适放上去。

#### 1.2.2 五大 KPI 指标定义

| 指标 | 数据来源 | SQL 表达 |
|------|---------|---------|
| 总会员数 | member | `SELECT COUNT(*) FROM member WHERE deleted=0` |
| 总客房数 | room | `SELECT COUNT(*) FROM room WHERE deleted=0` |
| 入住率 | room | `SUM(CASE WHEN status IN (1,2) THEN 1 ELSE 0 END) / COUNT(*)` |
| 总收入 | room_reservation | `SUM(total_price) WHERE status IN (1,2,3)` |
| 今日预约 | room_reservation | `WHERE DATE(create_time) = CURDATE()` |

> **注意：** 入住率的分母是"客房总数"，不是"订单总数"。一间房可能有多条历史订单。

#### 1.2.3 深色科技风色板

| 用途 | 色值 | 说明 |
|------|------|------|
| 主背景 | `#0a1128` | 大屏整体底色 |
| 卡片背景 | `#1a2555` | KPI/图表容器 |
| 主文字 | `#ffffff` | 数字、标题 |
| 辅助文字 | `#a0b3d6` | 坐标轴文字 |
| 分割线 | `#22345f` | grid 网格线 |
| 图表 1 | `#4facfe` | 主色（蓝） |
| 图表 2 | `#00f2fe` | 副色（青） |
| 图表 3 | `#43e97b` | 强调（绿） |
| 图表 4 | `#fa709a` | 警示（粉） |

### 1.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| 驾驶舱 | 面向决策层的信息汇总视图 |
| KPI | Key Performance Indicator，核心指标 |
| CSS Grid | 二维网格布局，替代 float/flex 拼装 |

### 1.4 示例代码/例题解析

**示例 1：原型草图（用 ASCII 表示）**
```
┌────────────────────────────────────────────────────────┐
│  智能养老社区数据大屏                     2026-07-09   │  ← header
├────┬────┬────┬────┬────────────────────────────────────┤
│1024│ 80 │85% │¥12M│  今日新预约 24                     │  ← top KPI
├────┴────┴────┴────┴────────────────────────────────────┤
│  近 7 日趋势     房型占比     近 6 月收入              │  ← mid charts
│  ┌────────┐    ┌──────┐    ┌────────┐                  │
│  │ 折线   │    │ 饼图 │    │ 柱状   │                  │
│  └────────┘    └──────┘    └────────┘                  │
├────────────────────────────────────────────────────────┤
│  入住率仪表盘        │    今日新预约明细               │  ← bottom
│  ┌────────┐          │    张三 - 豪华间 - 3 天         │
│  │  仪表  │          │    李四 - 标准间 - 5 天         │
│  └────────┘          │    ...                          │
└────────────────────────────────────────────────────────┘
```

### 1.5 课后练习
1. 【基础】列出你为大屏设计的 5 个 KPI 与 4 张图表。
2. 【综合】用 Figma / Excalidraw 画高保真原型，含尺寸标注。
3. 【挑战】给大屏加一个"高频客户 TOP5"排行榜，思考应该放哪里、用什么图表。

---

## 第 2 讲：复杂报表 SQL——分组与时间维度

### 2.1 本讲要点
- `GROUP BY` 的执行顺序与常见误区
- 6 个高频日期函数（`CURDATE`/`DATE`/`DATE_FORMAT`/`DATE_SUB`/`DATEDIFF`/`MONTH`）
- `CASE WHEN` 在报表分类计数中的经典用法
- 近 7 天趋势的完整 SQL + 零值补全

### 2.2 知识点详解

#### 2.2.1 SQL 执行顺序（重点）

```
FROM  →  WHERE  →  GROUP BY  →  HAVING  →  SELECT  →  ORDER BY  →  LIMIT
```

- `WHERE` 在分组前，用来过滤行；
- `HAVING` 在分组后，用来过滤组；
- 别名不能在 WHERE 里用，因为 SELECT 还没执行。

> ⚠️ **注意：** SELECT 列表中出现的非聚合列必须全部在 GROUP BY 里，否则不同数据库表现不同（MySQL 宽松，其他严格）。

#### 2.2.2 常用日期函数速查

| 函数 | 作用 | 示例 |
|------|------|------|
| `CURDATE()` | 当前日期 | `2026-07-09` |
| `NOW()` | 当前时间戳 | `2026-07-09 14:23:11` |
| `DATE(dt)` | 取日期部分 | `DATE('2026-07-09 14:00')` → `2026-07-09` |
| `DATE_FORMAT(dt, fmt)` | 格式化 | `DATE_FORMAT(NOW(), '%Y-%m')` → `2026-07` |
| `DATE_SUB(d, INTERVAL n DAY)` | 日期减 | 30 天前 |
| `DATE_ADD(d, INTERVAL n DAY)` | 日期加 | 30 天后 |
| `DATEDIFF(a, b)` | 天数差 | `DATEDIFF('2026-07-09','2026-07-01')` → 8 |
| `YEAR(dt)`/`MONTH(dt)`/`DAY(dt)` | 提取 | 单值提取 |
| `WEEKDAY(dt)` | 星期数（0=周一） | |

> 💡 **技巧：** `DATE_FORMAT` 常用占位符：`%Y` 4 位年、`%m` 月、`%d` 日、`%H` 24 小时制、`%i` 分钟、`%s` 秒。

#### 2.2.3 CASE WHEN 分类统计

一次 SQL 求多个口径：
```sql
SELECT
  SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END) AS pending,
  SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END) AS confirmed,
  SUM(CASE WHEN status = 4 THEN 1 ELSE 0 END) AS cancelled,
  COUNT(*)                                    AS total
FROM room_reservation
WHERE deleted = 0;
```
比多条 `COUNT + WHERE` 高效——**只扫一遍表**。

#### 2.2.4 近 7 天预约趋势 SQL

```sql
SELECT
    DATE_FORMAT(create_time, '%Y-%m-%d') AS `date`,
    COUNT(*)                              AS cnt
FROM room_reservation
WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
  AND deleted = 0
GROUP BY DATE_FORMAT(create_time, '%Y-%m-%d')
ORDER BY `date` ASC;
```

> ⚠️ **注意：** `INTERVAL 6 DAY` 而不是 7，因为 `CURDATE()` 自身占第 7 天。

#### 2.2.5 零值日期补全

若某一天完全没预约，SQL 结果就少一行 → 前端折线断裂。解决方案：**Java 端补 0**。

```java
Map<String, Long> map = raw.stream()
    .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt));
List<TrendVO> result = new ArrayList<>(7);
LocalDate today = LocalDate.now();
for (int i = 6; i >= 0; i--) {
    String d = today.minusDays(i).toString();
    result.add(new TrendVO(d, map.getOrDefault(d, 0L)));
}
```

### 2.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| GROUP BY | 分组后每组聚合成一行 |
| HAVING | 分组后过滤，可用聚合函数 |
| CASE WHEN | 在 SELECT 中做行内 if/else |
| 零值补全 | 保证时间序列连续，前端图表不断线 |

### 2.4 示例代码/例题解析

**示例 1：房型入住占比**
```sql
SELECT room_type, COUNT(*) AS cnt
FROM room
WHERE status IN (1, 2) AND deleted = 0
GROUP BY room_type;
```

**示例 2：入住率（一行输出）**
```sql
SELECT ROUND(
    SUM(CASE WHEN status IN (1,2) THEN 1 ELSE 0 END) * 100.0
    / COUNT(*), 2
) AS rate
FROM room
WHERE deleted = 0;
```
原理：把布尔条件转为 0/1，`SUM/COUNT` 得比例，乘 100 得百分数。

### 2.5 课后练习
1. 【基础】写出"每月新增会员数"的 SQL。
2. 【综合】一句 SQL 同时输出"本月订单总数 / 已完成数 / 已取消数"。
3. 【挑战】不用 Java 端补 0，纯 SQL 让近 7 天每天都有一行（提示：`CROSS JOIN` 日期表）。

---

## 第 3 讲：复杂报表 SQL——多表联合与优化

### 3.1 本讲要点
- 四种 JOIN 的差异与选用
- 子查询与 JOIN 的等价改写
- `EXPLAIN` 三大关键列：type / rows / Extra
- 覆盖索引（covering index）与 Using index

### 3.2 知识点详解

#### 3.2.1 JOIN 类型对比

| JOIN | 结果 | 场景 |
|------|------|------|
| INNER JOIN | 两表交集 | 严格匹配 |
| LEFT JOIN | 保留左表 | 报表兜底（右表可能无数据） |
| RIGHT JOIN | 保留右表 | 少用，通常用 LEFT 反写 |
| CROSS JOIN | 笛卡尔积 | 生成日期序列、维度组合 |

#### 3.2.2 多表 JOIN 报表 SQL

近 6 月各房型收入：
```sql
SELECT
    r.room_type,
    DATE_FORMAT(rr.create_time, '%Y-%m') AS month,
    SUM(rr.total_price)                   AS revenue
FROM room_reservation rr
INNER JOIN room r ON rr.room_id = r.id
WHERE rr.create_time >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH)
  AND rr.status IN (1, 2, 3)
  AND rr.deleted = 0
GROUP BY r.room_type, DATE_FORMAT(rr.create_time, '%Y-%m')
ORDER BY month, r.room_type;
```

#### 3.2.3 子查询 vs JOIN

**子查询**：
```sql
SELECT name FROM member
WHERE id IN (
    SELECT member_id FROM room_reservation
    WHERE room_id IN (SELECT id FROM room WHERE room_type = '豪华间')
);
```

**JOIN 版**：
```sql
SELECT DISTINCT m.name
FROM member m
INNER JOIN room_reservation rr ON m.id = rr.member_id
INNER JOIN room r              ON rr.room_id = r.id
WHERE r.room_type = '豪华间';
```

> 💡 **技巧：** 3 层及以上嵌套子查询首选改 JOIN，可读性和执行效率都更好。

#### 3.2.4 EXPLAIN 三大列

| 列 | 含义 | 好 → 坏 |
|----|------|---------|
| type | 访问类型 | `const > eq_ref > ref > range > index > ALL` |
| rows | 扫描行数估算 | 越少越好 |
| Extra | 附加信息 | `Using index` 好；`Using filesort`/`Using temporary` 差 |

> ⚠️ **注意：** `type = ALL` 一定是全表扫描，是报表调优的第一个信号。

#### 3.2.5 覆盖索引（covering index）

如果 SELECT 用到的字段全部在索引里，MySQL 无需回表，直接从索引读取——`Extra` 显示 `Using index`。

例子：`room(room_type, id)` 联合索引，则以下 SQL 走覆盖索引：
```sql
SELECT room_type FROM room WHERE room_type = '豪华间';
```

### 3.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| INNER JOIN | 内连接，只保留匹配行 |
| LEFT JOIN | 左连接，保留左表全部 |
| EXPLAIN | 显示 SQL 执行计划 |
| 覆盖索引 | 索引已包含所需字段，避免回表 |

### 3.4 示例代码/例题解析

**示例 1：EXPLAIN 前后对比**
```sql
-- 加索引前
EXPLAIN SELECT * FROM room_reservation WHERE room_id = 101;
-- type: ALL, rows: 12000

ALTER TABLE room_reservation ADD INDEX idx_room_id(room_id);

-- 加索引后
EXPLAIN SELECT * FROM room_reservation WHERE room_id = 101;
-- type: ref, rows: 3
```

### 3.5 课后练习
1. 【基础】用 EXPLAIN 分析你的 3 条报表 SQL，截图 type / rows / Extra。
2. 【综合】改写"预约过豪华间的会员"的子查询为 JOIN 版并对比结果。
3. 【挑战】为 `room_reservation` 设计一个 3 字段联合索引，让"近 7 日趋势"SQL 走覆盖索引。

---

## 第 4 讲：报表接口聚合与 DTO 设计

### 4.1 本讲要点
- "一接口多指标"设计模式
- DashboardVO / TrendVO / PieItemVO 三层 VO
- Redis 缓存报表数据 30 分钟
- Java 端补 0 的完整实现

### 4.2 知识点详解

#### 4.2.1 接口约定

```
GET /api/statistics/dashboard
Response: Result<DashboardVO>
```

#### 4.2.2 DTO/VO 分层

| 类名 | 定位 | 字段 |
|------|------|------|
| DashboardVO | 顶层聚合 | 5 KPI + 3 List |
| TrendVO | 折线/柱状元素 | date, cnt |
| PieItemVO | 饼图元素 | name, value |

#### 4.2.3 Redis 缓存策略

- Key: `dashboard:stats`
- TTL: 30 分钟
- 值: JSON 字符串（Jackson 序列化）
- 击穿风险: 低（大屏不高频访问），无需分布式锁

#### 4.2.4 补 0 循环模板

```java
private List<TrendVO> fillZero(List<TrendVO> raw, int days, DateTimeFormatter fmt) {
    Map<String, Long> map = raw.stream()
        .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt));
    List<TrendVO> result = new ArrayList<>(days);
    LocalDate today = LocalDate.now();
    for (int i = days - 1; i >= 0; i--) {
        String key = today.minusDays(i).format(fmt);
        result.add(new TrendVO(key, map.getOrDefault(key, 0L)));
    }
    return result;
}
```

### 4.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| VO | View Object，返回给前端的对象 |
| 聚合接口 | 一次返回多个业务数据 |
| 缓存兜底 | Redis 30min 减轻 DB 压力 |

### 4.4 示例代码/例题解析

**示例 1：完整 Mapper**

```java
package com.itcast.smart_elder.mapper;

import com.itcast.smart_elder.vo.PieItemVO;
import com.itcast.smart_elder.vo.TrendVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface StatisticsMapper {

    @Select("SELECT COUNT(*) FROM member WHERE deleted = 0")
    Long countMembers();

    @Select("SELECT COUNT(*) FROM room WHERE deleted = 0")
    Long countRooms();

    @Select("SELECT IFNULL(ROUND(" +
            "  SUM(CASE WHEN status IN (1,2) THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2), 0) " +
            "FROM room WHERE deleted = 0")
    BigDecimal occupancyRate();

    @Select("SELECT IFNULL(SUM(total_price), 0) FROM room_reservation " +
            "WHERE status IN (1,2,3) AND deleted = 0")
    BigDecimal totalRevenue();

    @Select("SELECT COUNT(*) FROM room_reservation " +
            "WHERE DATE(create_time) = CURDATE() AND deleted = 0")
    Long todayReservations();

    @Select("SELECT DATE_FORMAT(create_time,'%Y-%m-%d') AS `date`, COUNT(*) AS cnt " +
            "FROM room_reservation " +
            "WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND deleted = 0 " +
            "GROUP BY DATE_FORMAT(create_time,'%Y-%m-%d') " +
            "ORDER BY `date`")
    List<TrendVO> weekTrend();

    @Select("SELECT room_type AS name, COUNT(*) AS value " +
            "FROM room WHERE status IN (1,2) AND deleted = 0 " +
            "GROUP BY room_type")
    List<PieItemVO> roomTypePie();

    @Select("SELECT DATE_FORMAT(rr.create_time,'%Y-%m') AS `date`, " +
            "IFNULL(SUM(rr.total_price),0) AS cnt " +
            "FROM room_reservation rr " +
            "WHERE rr.create_time >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
            "  AND rr.status IN (1,2,3) AND rr.deleted = 0 " +
            "GROUP BY DATE_FORMAT(rr.create_time,'%Y-%m') " +
            "ORDER BY `date`")
    List<TrendVO> monthRevenue();
}
```

**示例 2：Service + Controller**

```java
package com.itcast.smart_elder.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

@Data
public class DashboardVO {
    private Long totalMembers;
    private Long totalRooms;
    private BigDecimal occupancyRate;
    private BigDecimal totalRevenue;
    private Long todayReservations;
    private List<TrendVO>   weekTrend;
    private List<PieItemVO> roomTypePie;
    private List<TrendVO>   monthRevenue;
}

@Data @AllArgsConstructor @NoArgsConstructor
class TrendVO {
    private String date;
    private Long   cnt;
}

@Data @AllArgsConstructor @NoArgsConstructor
class PieItemVO {
    private String name;
    private Long   value;
}
```

```java
package com.itcast.smart_elder.service;

public interface StatisticsService {
    DashboardVO getDashboard();
}
```

```java
package com.itcast.smart_elder.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itcast.smart_elder.mapper.StatisticsMapper;
import com.itcast.smart_elder.service.StatisticsService;
import com.itcast.smart_elder.vo.DashboardVO;
import com.itcast.smart_elder.vo.TrendVO;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class StatisticsServiceImpl implements StatisticsService {

    private final StatisticsMapper mapper;
    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;
    private static final String CACHE_KEY = "dashboard:stats";
    private static final long TTL_MINUTES = 30;

    @Override
    @SneakyThrows
    public DashboardVO getDashboard() {
        // 1. 优先读 Redis
        String cached = redisTemplate.opsForValue().get(CACHE_KEY);
        if (cached != null) {
            log.info("[dashboard] hit cache");
            return objectMapper.readValue(cached, DashboardVO.class);
        }
        log.info("[dashboard] miss cache, query db");

        // 2. 查库
        DashboardVO vo = new DashboardVO();
        vo.setTotalMembers(mapper.countMembers());
        vo.setTotalRooms(mapper.countRooms());
        vo.setOccupancyRate(mapper.occupancyRate());
        vo.setTotalRevenue(mapper.totalRevenue());
        vo.setTodayReservations(mapper.todayReservations());
        vo.setWeekTrend(fillZeroForWeek(mapper.weekTrend()));
        vo.setRoomTypePie(mapper.roomTypePie());
        vo.setMonthRevenue(fillZeroForMonth(mapper.monthRevenue()));

        // 3. 回写缓存
        redisTemplate.opsForValue().set(
                CACHE_KEY,
                objectMapper.writeValueAsString(vo),
                TTL_MINUTES, TimeUnit.MINUTES);
        return vo;
    }

    private List<TrendVO> fillZeroForWeek(List<TrendVO> raw) {
        Map<String, Long> map = raw.stream()
                .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt, (a, b) -> a));
        List<TrendVO> result = new ArrayList<>(7);
        LocalDate today = LocalDate.now();
        for (int i = 6; i >= 0; i--) {
            String d = today.minusDays(i).toString();
            result.add(new TrendVO(d, map.getOrDefault(d, 0L)));
        }
        return result;
    }

    private List<TrendVO> fillZeroForMonth(List<TrendVO> raw) {
        Map<String, Long> map = raw.stream()
                .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt, (a, b) -> a));
        List<TrendVO> result = new ArrayList<>(6);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM");
        LocalDate today = LocalDate.now();
        for (int i = 5; i >= 0; i--) {
            String m = today.minusMonths(i).format(fmt);
            result.add(new TrendVO(m, map.getOrDefault(m, 0L)));
        }
        return result;
    }
}
```

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.service.StatisticsService;
import com.itcast.smart_elder.vo.DashboardVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsService statisticsService;

    @GetMapping("/dashboard")
    public Result<DashboardVO> dashboard() {
        return Result.success(statisticsService.getDashboard());
    }
}
```

**示例 3：Postman 返回样本**
```json
{
  "code": 200,
  "msg": "ok",
  "data": {
    "totalMembers": 1024,
    "totalRooms": 80,
    "occupancyRate": 85.00,
    "totalRevenue": 1234567.80,
    "todayReservations": 24,
    "weekTrend": [
      { "date": "2026-07-03", "cnt": 12 },
      { "date": "2026-07-04", "cnt": 18 },
      { "date": "2026-07-05", "cnt": 0  },
      { "date": "2026-07-06", "cnt": 24 },
      { "date": "2026-07-07", "cnt": 33 },
      { "date": "2026-07-08", "cnt": 27 },
      { "date": "2026-07-09", "cnt": 24 }
    ],
    "roomTypePie": [
      { "name": "豪华间",   "value": 20 },
      { "name": "标准间",   "value": 40 },
      { "name": "单人间",   "value": 10 },
      { "name": "亲情套房", "value": 10 }
    ],
    "monthRevenue": [
      { "date": "2026-02", "cnt": 180000 },
      { "date": "2026-03", "cnt": 210000 },
      { "date": "2026-04", "cnt": 250000 },
      { "date": "2026-05", "cnt": 300000 },
      { "date": "2026-06", "cnt": 320000 },
      { "date": "2026-07", "cnt": 108000 }
    ]
  }
}
```

### 4.5 课后练习
1. 【基础】完成 3 层代码并联调成功，把 JSON 返回贴到笔记。
2. 【综合】增加"本月新增会员数"KPI，端到端跑通。
3. 【挑战】用 `CompletableFuture` 并发执行 4 个查询，对比总耗时。

---

## 第 5 讲：Echarts 集成——折线/柱状/饼图

### 5.1 本讲要点
- Echarts 5 安装与使用三步
- 全量 vs 按需引入的差异
- 自定义 `useChart` composable 复用初始化/resize/dispose
- 3 张图完整 option 代码

### 5.2 知识点详解

#### 5.2.1 安装

```bash
pnpm install echarts
```

`package.json` 新增：
```json
"dependencies": {
  "echarts": "^5.5.0"
}
```

#### 5.2.2 引入方式对比

| 方式 | 写法 | 包体积 | 适用 |
|------|------|--------|------|
| 全量 | `import * as echarts from 'echarts'` | ~1 MB | 学习/项目初期 |
| 按需 | 独立注册 chart / component | ~200 KB | 生产环境 |

**按需引入模板**（附录）：
```typescript
import * as echarts from 'echarts/core'
import { LineChart, BarChart, PieChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, GridComponent,
  LegendComponent, DatasetComponent
} from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

echarts.use([
  LineChart, BarChart, PieChart,
  TitleComponent, TooltipComponent, GridComponent,
  LegendComponent, DatasetComponent, CanvasRenderer
])
export default echarts
```

#### 5.2.3 使用三步走

```typescript
const chart = echarts.init(document.getElementById('lineChart'))  // 1
const option = { ... }                                             // 2
chart.setOption(option)                                            // 3
```

> **注意：** `init` 之前容器 div 必须显式有宽高，否则图表看不见。

#### 5.2.4 useChart composable

复用初始化/resize/销毁逻辑：

```typescript
// src/composables/useChart.ts
import * as echarts from 'echarts'
import { onMounted, onUnmounted, type Ref } from 'vue'

export function useChart(el: Ref<HTMLElement | null>) {
  let chart: echarts.ECharts | null = null

  const init = (option: any) => {
    if (!el.value) return
    chart = echarts.init(el.value)
    chart.setOption(option)
  }

  const setOption = (option: any, notMerge = false) => {
    chart?.setOption(option, notMerge)
  }

  const resize = () => chart?.resize()

  onMounted(() => window.addEventListener('resize', resize))
  onUnmounted(() => {
    window.removeEventListener('resize', resize)
    chart?.dispose()
    chart = null
  })

  return { init, setOption, resize }
}
```

#### 5.2.5 API 层封装

```typescript
// src/api/statistics.ts
import request from '@/utils/request'

export interface TrendItem { date: string; cnt: number }
export interface PieItem   { name: string; value: number }

export interface DashboardVO {
  totalMembers: number
  totalRooms: number
  occupancyRate: number
  totalRevenue: number
  todayReservations: number
  weekTrend: TrendItem[]
  roomTypePie: PieItem[]
  monthRevenue: TrendItem[]
}

export const getDashboard = () =>
  request.get<any, DashboardVO>('/api/statistics/dashboard')
```

### 5.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| init/setOption/dispose | Echarts 三大生命周期 API |
| composable | Vue3 逻辑复用单元（等价 hook） |
| 容器高度 | 图表看不见的 90% 是因为容器无高度 |

### 5.4 示例代码/例题解析

**示例 1：折线图 option**

```typescript
export const buildLineOption = (data: { date: string; cnt: number }[]) => ({
  title: {
    text: '近 7 日预约趋势',
    left: 'left',
    textStyle: { color: '#fff', fontSize: 16 }
  },
  tooltip: { trigger: 'axis' },
  grid: { left: '10%', right: '5%', top: '20%', bottom: '15%' },
  xAxis: {
    type: 'category',
    data: data.map(d => d.date.slice(5)),          // 只显示 MM-DD
    axisLabel: { color: '#a0b3d6' },
    axisLine: { lineStyle: { color: '#3d5a80' } }
  },
  yAxis: {
    type: 'value',
    axisLabel: { color: '#a0b3d6' },
    splitLine: { lineStyle: { color: '#22345f' } }
  },
  series: [{
    type: 'line',
    smooth: true,
    symbol: 'circle',
    symbolSize: 8,
    data: data.map(d => d.cnt),
    lineStyle: { color: '#4facfe', width: 3 },
    itemStyle: { color: '#4facfe' },
    areaStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: 'rgba(79,172,254,0.6)' },
          { offset: 1, color: 'rgba(79,172,254,0)'   }
        ]
      }
    }
  }]
})
```

**示例 2：饼图 option**

```typescript
export const buildPieOption = (data: { name: string; value: number }[]) => ({
  title: {
    text: '房型入住占比',
    left: 'left',
    textStyle: { color: '#fff', fontSize: 16 }
  },
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: {
    bottom: 0,
    left: 'center',
    textStyle: { color: '#a0b3d6' }
  },
  color: ['#4facfe', '#00f2fe', '#43e97b', '#fa709a', '#f5576c'],
  series: [{
    type: 'pie',
    radius: ['40%', '65%'],
    center: ['50%', '48%'],
    label: {
      color: '#fff',
      formatter: '{b}\n{d}%'
    },
    labelLine: { lineStyle: { color: '#a0b3d6' } },
    data
  }]
})
```

**示例 3：柱状图 option**

```typescript
export const buildBarOption = (data: { date: string; cnt: number }[]) => ({
  title: {
    text: '近 6 月收入（元）',
    left: 'left',
    textStyle: { color: '#fff', fontSize: 16 }
  },
  tooltip: {
    trigger: 'axis',
    formatter: (params: any) => {
      const p = params[0]
      return `${p.name}<br/>收入：¥${Number(p.value).toLocaleString()}`
    }
  },
  grid: { left: '13%', right: '5%', top: '20%', bottom: '15%' },
  xAxis: {
    type: 'category',
    data: data.map(d => d.date),
    axisLabel: { color: '#a0b3d6' },
    axisLine: { lineStyle: { color: '#3d5a80' } }
  },
  yAxis: {
    type: 'value',
    axisLabel: {
      color: '#a0b3d6',
      formatter: (v: number) => v >= 10000 ? (v / 10000) + '万' : v
    },
    splitLine: { lineStyle: { color: '#22345f' } }
  },
  series: [{
    type: 'bar',
    barWidth: '45%',
    data: data.map(d => d.cnt),
    itemStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: '#4facfe' },
          { offset: 1, color: '#00f2fe' }
        ]
      },
      borderRadius: [6, 6, 0, 0]
    }
  }]
})
```

**示例 4：仪表盘 option**

```typescript
export const buildGaugeOption = (rate: number) => ({
  title: { text: '入住率', left: 'center', textStyle: { color: '#fff' } },
  series: [{
    type: 'gauge',
    startAngle: 210,
    endAngle: -30,
    min: 0,
    max: 100,
    progress: { show: true, width: 18 },
    axisLine: { lineStyle: { width: 18, color: [[1, '#22345f']] } },
    pointer: { icon: 'path://M2,0 L-2,0 L0,-60 Z', length: '60%' },
    detail: {
      valueAnimation: true,
      formatter: '{value}%',
      color: '#4facfe',
      fontSize: 28
    },
    data: [{ value: rate }]
  }]
})
```

### 5.5 课后练习
1. 【基础】把 4 个 option 分别渲染到独立测试页面。
2. 【综合】将折线图改为叠加双 y 轴（本周订单数 + 收入）。
3. 【挑战】把全量引入改为按需引入，用打包分析工具（vite-bundle-visualizer）对比包体积。

---

## 第 6 讲：大屏适配与自动刷新

### 6.1 本讲要点
- 两种适配方案：rem/flex vs transform:scale
- scale 缩放公式：`min(w/1920, h/1080)`
- CSS Grid 三栏布局
- 定时轮询 + onUnmounted 清理

### 6.2 知识点详解

#### 6.2.1 适配方案对比

| 方案 | 优点 | 缺点 | 推荐场景 |
|------|------|------|---------|
| rem/flex | 交互精准、字体清晰 | 每个断点都要重写 | 交互密集的普通页 |
| transform:scale | 一次写完，任何分辨率通用 | hover 命中区会偏移；文字可能糊 | 展示型大屏 ✅ |

#### 6.2.2 scale 缩放公式

```javascript
const scale = Math.min(
  window.innerWidth  / 1920,
  window.innerHeight / 1080
)
container.style.transform = `scale(${scale})`
container.style.transformOrigin = 'top left'
```

> 💡 **技巧：** `min` 而不是单独 `w/1920`，是为了不同长宽比屏幕都能完整看到，等比缩放不变形。

#### 6.2.3 CSS Grid 三栏布局

```css
.dashboard {
  width: 1920px;
  height: 1080px;
  display: grid;
  grid-template-rows: 200px 1fr 260px;   /* 顶 KPI / 中图 / 底图 */
  gap: 20px;
  padding: 20px;
  background: #0a1128;
  color: #fff;
}
.top-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; }
.mid-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.bot-row { display: grid; grid-template-columns: 1fr 1fr;       gap: 20px; }
```

#### 6.2.4 定时轮询

```typescript
let timer: number | null = null
let loading = false

const loadData = async () => {
  if (loading) return          // 防重入
  loading = true
  try {
    dashboard.value = await getDashboard()
    updateCharts()
  } finally {
    loading = false
  }
}

onMounted(() => {
  loadData()
  timer = window.setInterval(loadData, 30_000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
})
```

> **注意：** onUnmounted 里必须 `clearInterval`，否则页面切走后仍在偷偷请求。

### 6.3 重点概念回顾

| 概念 | 说明 |
|------|------|
| transform:scale | CSS 缩放，最简大屏适配方案 |
| CSS Grid | 二维网格布局，比 flex 更适合大屏 |
| setInterval/clearInterval | 定时器成对出现，防内存泄漏 |
| loading flag | 防止上一次请求未回，下一次又发出 |

### 6.4 示例代码/例题解析

**示例 1：完整 `views/dashboard/index.vue`**

```vue
<script setup lang="ts">
import { onMounted, onUnmounted, ref, computed, nextTick } from 'vue'
import * as echarts from 'echarts'
import { getDashboard, type DashboardVO } from '@/api/statistics'
import {
  buildLineOption, buildPieOption,
  buildBarOption,  buildGaugeOption
} from '@/utils/chart-options'

/* ---------- 数据 ---------- */
const dashboard = ref<DashboardVO | null>(null)

const kpis = computed(() => {
  if (!dashboard.value) return []
  const d = dashboard.value
  return [
    { label: '总会员数',   value: d.totalMembers },
    { label: '总客房数',   value: d.totalRooms },
    { label: '入住率',     value: d.occupancyRate + '%' },
    { label: '总收入(元)', value: Number(d.totalRevenue).toLocaleString() },
    { label: '今日预约',   value: d.todayReservations }
  ]
})

/* ---------- 图表实例 ---------- */
const lineEl  = ref<HTMLElement | null>(null)
const pieEl   = ref<HTMLElement | null>(null)
const barEl   = ref<HTMLElement | null>(null)
const gaugeEl = ref<HTMLElement | null>(null)

let lineChart:  echarts.ECharts | null = null
let pieChart:   echarts.ECharts | null = null
let barChart:   echarts.ECharts | null = null
let gaugeChart: echarts.ECharts | null = null

const initCharts = () => {
  if (lineEl.value)  lineChart  = echarts.init(lineEl.value)
  if (pieEl.value)   pieChart   = echarts.init(pieEl.value)
  if (barEl.value)   barChart   = echarts.init(barEl.value)
  if (gaugeEl.value) gaugeChart = echarts.init(gaugeEl.value)
}

const updateCharts = () => {
  if (!dashboard.value) return
  const d = dashboard.value
  lineChart?.setOption(buildLineOption(d.weekTrend))
  pieChart?.setOption(buildPieOption(d.roomTypePie))
  barChart?.setOption(buildBarOption(d.monthRevenue))
  gaugeChart?.setOption(buildGaugeOption(Number(d.occupancyRate)))
}

/* ---------- 加载数据（含防重入） ---------- */
let loading = false
const loadData = async () => {
  if (loading) return
  loading = true
  try {
    dashboard.value = await getDashboard()
    await nextTick()
    updateCharts()
  } catch (e) {
    console.error('[dashboard] load failed', e)
  } finally {
    loading = false
  }
}

/* ---------- 大屏 scale 适配 ---------- */
const scaleBox = ref<HTMLElement | null>(null)
const applyScale = () => {
  if (!scaleBox.value) return
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080)
  scaleBox.value.style.transform = `scale(${s})`
  lineChart?.resize()
  pieChart?.resize()
  barChart?.resize()
  gaugeChart?.resize()
}

/* ---------- 生命周期 ---------- */
let timer: number | null = null
onMounted(async () => {
  initCharts()
  await loadData()
  applyScale()
  window.addEventListener('resize', applyScale)
  timer = window.setInterval(loadData, 30_000)
})

onUnmounted(() => {
  if (timer) clearInterval(timer)
  window.removeEventListener('resize', applyScale)
  lineChart?.dispose()
  pieChart?.dispose()
  barChart?.dispose()
  gaugeChart?.dispose()
})
</script>

<template>
  <div class="dashboard-wrapper">
    <div class="dashboard" ref="scaleBox">
      <!-- 顶部 5 KPI -->
      <div class="top-row">
        <div class="kpi-card" v-for="k in kpis" :key="k.label">
          <div class="kpi-label">{{ k.label }}</div>
          <div class="kpi-value">{{ k.value }}</div>
        </div>
      </div>

      <!-- 中间 3 图表 -->
      <div class="mid-row">
        <div class="chart-card" ref="lineEl"></div>
        <div class="chart-card" ref="pieEl"></div>
        <div class="chart-card" ref="barEl"></div>
      </div>

      <!-- 底部 -->
      <div class="bot-row">
        <div class="chart-card" ref="gaugeEl"></div>
        <div class="chart-card recent">
          <div class="chart-title">今日新预约</div>
          <ul class="recent-list">
            <li v-for="i in 5" :key="i">
              <span>老人 {{ i }}</span>
              <span>豪华间</span>
              <span>3 天</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.dashboard-wrapper {
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background: #0a1128;
  display: flex;
  align-items: flex-start;
  justify-content: flex-start;
}
.dashboard {
  width: 1920px;
  height: 1080px;
  transform-origin: top left;
  display: grid;
  grid-template-rows: 200px 1fr 260px;
  gap: 20px;
  padding: 20px;
  box-sizing: border-box;
  color: #fff;
}
.top-row  { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; }
.mid-row  { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.bot-row  { display: grid; grid-template-columns: 1fr 1fr;       gap: 20px; }

.kpi-card {
  background: linear-gradient(135deg, #1a2555 0%, #22345f 100%);
  border: 1px solid #3d5a80;
  border-radius: 12px;
  padding: 24px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  box-shadow: 0 4px 20px rgba(79,172,254,0.15);
}
.kpi-label { color: #a0b3d6; font-size: 18px; }
.kpi-value { color: #4facfe; font-size: 44px; font-weight: bold; }

.chart-card {
  background: #1a2555;
  border: 1px solid #22345f;
  border-radius: 12px;
  padding: 16px;
  height: 100%;
  box-sizing: border-box;
}
.chart-card.recent { padding: 20px; }
.chart-title { color: #fff; font-size: 16px; margin-bottom: 12px; }
.recent-list { list-style: none; padding: 0; margin: 0; }
.recent-list li {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  color: #a0b3d6;
  border-bottom: 1px dashed #22345f;
}
</style>
```

**示例 2：路由注册**

```typescript
// src/router/index.ts (片段)
{
  path: '/dashboard',
  name: 'Dashboard',
  component: () => import('@/views/dashboard/index.vue'),
  meta: { fullScreen: true, hideMenu: true }
}
```

### 6.5 课后练习
1. 【基础】完整敲出 `views/dashboard/index.vue` 并跑通。
2. 【综合】改为按需引入 Echarts，观察打包体积变化。
3. 【挑战】将底部"今日新预约"接入真实接口 `GET /api/reservations/today`，用同一轮询定时刷新。

---

## 附录 A：大屏颜色方案

| 用途 | 色值 | 备注 |
|------|------|------|
| 主背景 | `#0a1128` | 深蓝，长时间观察不刺眼 |
| 卡片背景 | `#1a2555` | 略浅，形成层次感 |
| 卡片渐变（可选） | `linear-gradient(135deg, #1a2555 0%, #22345f 100%)` | 增加科技感 |
| 边框 | `#3d5a80` | 分割卡片 |
| 分割线 | `#22345f` | 图表 grid 线 |
| 主文字 | `#ffffff` | KPI 数字、标题 |
| 辅助文字 | `#a0b3d6` | 坐标轴、次要文字 |
| 数据蓝 | `#4facfe` | 主色系图表 |
| 数据青 | `#00f2fe` | 渐变搭配 |
| 数据绿 | `#43e97b` | 强调、正向 |
| 数据粉 | `#fa709a` | 警示、负向 |
| 危险红 | `#f5576c` | 预警指标 |

## 附录 B：常用日期函数速查

| 函数 | 作用 | 示例结果 |
|------|------|---------|
| `CURDATE()` | 当前日期 | `2026-07-09` |
| `NOW()` | 当前时间戳 | `2026-07-09 14:23:11` |
| `CURTIME()` | 当前时间 | `14:23:11` |
| `DATE(dt)` | 取日期部分 | `DATE(NOW())` → `2026-07-09` |
| `DATE_FORMAT(dt, '%Y-%m-%d')` | 年月日 | `2026-07-09` |
| `DATE_FORMAT(dt, '%Y-%m')` | 年月 | `2026-07` |
| `DATE_FORMAT(dt, '%Y%m%d')` | 无分隔 | `20260709` |
| `DATE_ADD(d, INTERVAL 1 DAY)` | 加 1 天 | |
| `DATE_SUB(d, INTERVAL 7 DAY)` | 减 7 天 | |
| `DATEDIFF(a, b)` | 天数差 | `DATEDIFF('2026-07-09','2026-07-01') = 8` |
| `TIMESTAMPDIFF(HOUR, a, b)` | 小时差 | |
| `YEAR(dt)` | 年 | `2026` |
| `MONTH(dt)` | 月 | `7` |
| `DAY(dt)` | 日 | `9` |
| `WEEKDAY(dt)` | 星期数（0=周一） | `3` |
| `LAST_DAY(dt)` | 当月最后一天 | `2026-07-31` |
| `DAYOFYEAR(dt)` | 今年第几天 | `190` |
| `UNIX_TIMESTAMP()` | 秒级时间戳 | `1783543391` |
| `FROM_UNIXTIME(ts)` | 时间戳转日期 | |

**DATE_FORMAT 常用占位符：**

| 占位符 | 含义 | 示例 |
|--------|------|------|
| `%Y` | 4 位年 | `2026` |
| `%y` | 2 位年 | `26` |
| `%m` | 补零月 | `07` |
| `%c` | 无零月 | `7` |
| `%d` | 补零日 | `09` |
| `%e` | 无零日 | `9` |
| `%H` | 24 小时 | `14` |
| `%h`/`%I` | 12 小时 | `02` |
| `%i` | 分钟 | `23` |
| `%s` | 秒 | `11` |
| `%W` | 星期名 | `Thursday` |
| `%w` | 星期数（0=周日） | `4` |

## 附录 C：接口清单速查

| 方法 | URL | 说明 |
|------|-----|------|
| GET | `/api/statistics/dashboard` | 一次返回大屏所有指标 |

## 附录 D：文件清单

**后端**
- `com.itcast.smart_elder.controller.StatisticsController`
- `com.itcast.smart_elder.service.StatisticsService`
- `com.itcast.smart_elder.service.impl.StatisticsServiceImpl`
- `com.itcast.smart_elder.mapper.StatisticsMapper`
- `com.itcast.smart_elder.vo.DashboardVO` / `TrendVO` / `PieItemVO`

**前端**
- `src/api/statistics.ts`
- `src/utils/chart-options.ts`
- `src/composables/useChart.ts`
- `src/views/dashboard/index.vue`
- `src/router/index.ts`（新增路由）

---

**Day08 完成✔️  明日：Day09 AOP 操作日志管理**
