# 《智能养老社区系统》- 教师教案 - Day01：需求分析与数据库设计（AI 辅助）

**授课日：Day 01 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 1（使用 DeepSeek 进行项目需求分析 · 0.5 天）+ 技术点 2（使用 DeepSeek 对生成的需求设计数据库表 · 0.5 天）**
**授课对象：Java 全栈方向初学者（已完成 Java SE / MySQL / 前端 HTML+JS 基础）**
**项目案例：AI 智能养老社区系统**

---

## 第 1 课时：项目概述与需求分析方法

### 一、教学目标
- 知识目标：理解「AI 智能养老社区系统」的业务背景、用户角色与核心模块；掌握软件工程中需求分析的三个阶段（调研 → 梳理 → 评审）与常见输出物。
- 能力目标：能够独立描述本项目的主要业务流程；能够为一个新模块列出至少 5 条功能需求，并区分「功能需求」与「非功能需求」。

### 二、教学重难点
- 重点：模块划分（会员管理 / 客房管理 / 预约管理 / 健康评测 / AI 应答 / 数据可视化）与用户角色划分（超级管理员 / 前台管理员 / 会员）。
- 难点：从模糊的业务描述中抽象出具体、可开发、可验证的功能条目，避免「大而空」的需求。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
提问：「同学们家里有老人吗？如果奶奶需要预约一次社区体检、一次康复房，你会希望手机 APP 上有哪些按钮？」通过生活化提问激活学生已有认知，引入本项目的六大业务模块，并强调这是一个「贯穿 12 天」的实战项目，今天的一切设计将直接决定后续 11 天写的每一行代码。

#### 2. 讲授（18 分钟）
**（1）项目背景**：中国老龄化加速，2035 年预计 60 岁以上人口占比超过 30%。传统养老院信息化程度低，本项目定位为「社区型智慧养老 SaaS 系统」，服务对象包含独居老人、家属、社区管理方。

**（2）用户角色矩阵**：

| 角色         | 使用端     | 主要动作                                          |
|--------------|------------|---------------------------------------------------|
| 超级管理员   | 后台管理端 | 系统配置、账号管理、日志审计                        |
| 前台管理员   | 后台管理端 | 会员登记、客房调度、预约审核、健康档案维护          |
| 会员/家属    | 前台会员端 | 浏览房型、下单预约、查看健康报告、AI 智能问答       |

**（3）六大模块**：会员管理、客房管理、预约管理、健康评测、AI 智能应答、数据可视化大屏。教师在黑板上画出模块之间的数据流动（会员 → 预约 → 客房 → 健康档案 → 大屏），让学生看到「表与表」不是孤立的。

**（4）需求分析三段式流程**：**调研**（业务方访谈、竞品对比：如「乌镇雅园」「泰康之家」）→ **梳理**（用脑图/清单/用例图分层）→ **评审**（客户、产品、开发、测试四方会审，输出「需求评审记录」）。

强调「功能需求 vs 非功能需求」：前者是「系统能做什么」（登录、预约），后者是「系统做得怎么样」（响应时间 < 2s、并发 500）。

#### 3. 演示（10 分钟）
教师现场演示一份「初稿需求清单」的书写方式（会员管理模块）：

```markdown
# 会员管理模块 - 需求清单 v0.1
## 功能需求
FR-01 支持按姓名/手机号/会员等级搜索会员，支持分页
FR-02 新增会员时校验身份证格式（18 位、末位 X 允许）
FR-03 会员详情中展示最近 3 次健康检测记录
## 非功能需求
NFR-01 列表查询接口平均响应 < 500ms
NFR-02 身份证/手机号加密存储（AES-128）
```

演示要点：编号规则（FR/NFR + 两位序号）、每条需求「可测试」的措辞。

#### 4. 实操（10 分钟）
学生分组（3 人一组）为「健康评测模块」写 5 条 FR + 2 条 NFR，写在纸上或飞书文档，教师巡回点评常见问题：「支持导出报告」不够具体，应改为「支持导出 PDF 格式健康报告，字段包含 xxxx」。

#### 5. 小结（3 分钟）
回顾：项目定位、角色、模块、需求三段式。预告：下一节课将请出 AI「军师」DeepSeek，把我们今天手写的清单快速扩展为一份完整功能需求文档。

### 四、课上提问
1. 本项目共有几种用户角色？分别使用哪个端？
2. 「支持登录」是功能需求还是非功能需求？如何改写才更规范？
3. 客房管理与预约管理之间是通过哪个字段关联的？

### 五、课堂练习
1. 用一句话概括「AI 智能养老社区系统」的业务定位。
2. 为「客房管理模块」列出 3 条 FR、2 条 NFR。
3. 画出六大模块之间的数据流向草图。

### 六、课后思考
如果客户临时提出「新增陪诊服务预约」，作为开发者，你会补充哪些表？会不会影响到已经写好的预约表？「可扩展性」在需求阶段就该考虑吗？

### 七、课后作业
1. 完成 6 大模块每个模块 3 条 FR 的清单（手写或 markdown 均可）。
2. 阅读《软件需求》第 2 章「需求工程概览」。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-1 项目概述与需求分析                   │
├───────────────────────────────────────────────┤
│ 1. 三种角色：超管 / 前台 / 会员               │
│ 2. 六大模块：会员/客房/预约/健康/AI/大屏      │
│ 3. 三段式：调研 → 梳理 → 评审                 │
│ 4. FR vs NFR：能做什么 vs 做得怎样            │
│ 5. 需求编号规则：FR-01 / NFR-01               │
└───────────────────────────────────────────────┘
```

---

## 第 2 课时：使用 DeepSeek 辅助需求分析

### 一、教学目标
- 知识目标：了解 DeepSeek 的定位与优势，掌握「角色 + 任务 + 输出格式」三段式 Prompt 结构，理解 AI 输出的「幻觉」与「颗粒度」问题。
- 能力目标：能够写出高质量 Prompt，让 DeepSeek 输出结构化的功能清单，并能对 AI 结果做人工评审与二次修正。

### 二、教学重难点
- 重点：三段式 Prompt 的编写方法，输出格式约束（Markdown 表格 / JSON）。
- 难点：如何识别 AI「一本正经胡说八道」的部分，比如虚构字段、遗漏边界条件。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示两段 Prompt：一段是「给我写一下养老系统的需求」，另一段是完整的三段式 Prompt。让学生猜哪一段输出质量更高，引出「Prompt 决定产出上限」。

#### 2. 讲授（18 分钟）
**（1）DeepSeek 简介**：由深度求索公司开发，具备中文强、代码强、成本低三大特点，官网 chat.deepseek.com；也提供 API（OpenAI 兼容协议）。今天先用网页版，第 5 天再讲 API 集成。

**（2）三段式 Prompt 结构**：

| 段落         | 作用                                | 关键词                                    |
|--------------|-------------------------------------|-------------------------------------------|
| 角色（Role）  | 让模型代入身份，收敛输出风格         | 「你是一名 10 年经验的产品经理…」         |
| 任务（Task）  | 明确要做什么、覆盖范围、约束条件     | 「请为 XX 模块拆解功能，不少于 15 条…」   |
| 输出（Format）| 强约束输出结构，便于后续复用         | 「用 Markdown 表格，列：编号 优先级 描述」|

**（3）需求拆解案例**：以「客房管理模块」为例，现场输入 Prompt 让 DeepSeek 产出 20+ 条 FR，教师带学生一起逐条评审：哪些合理保留、哪些是幻觉（如「支持 VR 看房」在项目一期不需要）、哪些需要拆分（一条包含两个动作的需要拆成两条）。

**（4）AI 输出评审四问**：① 是否偏离业务？② 是否可测试？③ 字段/接口是否与其他模块冲突？④ 是否遗漏边界（如「会员注销后其历史订单如何处理」）。

#### 3. 演示（12 分钟）
教师现场登录 chat.deepseek.com，输入完整 Prompt，并让学生记录 Prompt 全文：

```text
# 角色
你是一名有 10 年 SaaS 系统经验的高级产品经理，同时熟悉智慧养老行业。

# 任务
项目背景：我们正在开发一款「AI 智能养老社区系统」，面向社区型养老服务机构，
包含前台会员端与后台管理端。请为「客房管理」模块拆解详细功能需求：
1. 不少于 15 条功能需求（FR），至少 3 条非功能需求（NFR）；
2. 每条需求需具备「可测试」的措辞（可用于验收）；
3. 覆盖：房型维护、房间维护、图片管理、上下架、批量操作、状态流转；
4. 与「预约管理」的交互需明确指出，但预约的具体规则不在本次范围。

# 输出格式
使用 Markdown 表格，列依次为：编号 | 类型 | 优先级(P0/P1/P2) | 需求描述 | 备注
```

演示要点：光标停留在关键提示词处，让学生看到「越具体越好」。

#### 4. 实操（10 分钟）
学生 2 人一组，为「健康评测模块」自行改写 Prompt 并发送给 DeepSeek，输出结果贴到共享文档。教师随机抽取 2 组进行点评。

#### 5. 小结（2 分钟）
Prompt = 三段式；AI 是「加速器」不是「决策者」；一切输出必须评审后才能进入正式需求文档。预告下一课：从需求过渡到数据库设计。

### 四、课上提问
1. 三段式 Prompt 中最容易被初学者忽略的是哪一段？
2. 如果 DeepSeek 输出的功能与业务不符，你会怎么处理？

### 五、课堂练习
1. 用三段式 Prompt 让 DeepSeek 输出 AI 智能应答模块的 10 条 FR。
2. 从 AI 输出中挑出 2 条你认为不合理的，说明理由。

### 六、课后思考
如果同一个 Prompt 两次调用得到不一样的结果（AI 的不确定性），你在项目文档中如何保证「需求可追溯」？

### 七、课后作业
1. 使用 DeepSeek 完成六大模块的初步需求清单（每模块 ≥ 10 FR），汇总为一份 `需求清单v1.md`。
2. 圈出你认为需要人工修正的至少 5 处，用批注方式说明。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-2 DeepSeek 辅助需求分析                │
├───────────────────────────────────────────────┤
│ 三段式 Prompt = 角色 + 任务 + 输出格式        │
│ 输出格式：Markdown 表格 / JSON / 编号规则     │
│ AI 评审四问：偏业务?可测?冲突?边界?           │
│ 结论：AI 是副驾，方向盘在你手里               │
└───────────────────────────────────────────────┘
```

---

## 第 3 课时：数据库设计原则与 E-R 建模

### 一、教学目标
- 知识目标：掌握三大范式的定义、区别与工程取舍；能够绘制 E-R 图并将实体关系映射为关系表；掌握常用字段类型选择与命名规范。
- 能力目标：能针对一个业务模块画出 E-R 图并给出字段清单，说明为什么用 `VARCHAR(50)` 而不是 `VARCHAR(255)`。

### 二、教学重难点
- 重点：三大范式、主外键、字段类型选择、命名规范。
- 难点：范式与反范式的工程取舍——什么时候必须冗余？

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
展示两张糟糕的数据表：一张是把「会员姓名、手机、地址」重复冗余在每条预约记录里；另一张是把 5 个业务字段塞进一个 `info` VARCHAR(2000) 里。让学生指出问题，引出规范化设计。

#### 2. 讲授（20 分钟）
**（1）三大范式**：

| 范式 | 定义 | 反面例子 |
|------|------|----------|
| 1NF | 字段不可再分（原子性） | `address = "北京市海淀区中关村1号"` 若业务要按省市查询就不满足 |
| 2NF | 非主键字段完全依赖主键 | 联合主键场景下部分字段只依赖主键的一部分 |
| 3NF | 非主键字段不能传递依赖 | `员工表` 里既存 `部门ID` 又存 `部门名`，`部门名` 依赖 `部门ID` |

**（2）反范式的工程理由**：报表大屏、历史订单快照、性能优化。举例：`room_reservation` 里可以冗余 `member_name` 一份，防止会员改名后历史订单显示错乱。

**（3）E-R 图核心元素**：实体（矩形）、属性（椭圆）、关系（菱形，标注 1:1 / 1:N / M:N）。M:N 需要引入中间表。

**（4）字段类型选择**：

| 类型 | 使用场景 | 常见坑 |
|------|----------|--------|
| `VARCHAR(N)` | 变长字符串，N 依据实际最大值 | 不要一律 255 |
| `CHAR(N)` | 定长（如身份证 18） | 存储可能浪费 |
| `INT` | 整数、状态码、外键 | 状态码建议用 `TINYINT` |
| `BIGINT` | 主键（分布式 ID） | 与 `Long` 对应 |
| `DECIMAL(10,2)` | 金额 | 严禁用 FLOAT/DOUBLE 存金额 |
| `DATETIME` | 时间戳 | 优于 `TIMESTAMP`（2038 问题）|

**（5）命名规范**：表名小写下划线（`elder_member`）；字段名小写下划线（`create_time`）；主键统一 `id`；创建/更新时间统一 `create_time` / `update_time`；布尔类字段用 `is_xxx` 或 `status` + 字典。

#### 3. 演示（10 分钟）
教师在白板上现场画「会员 - 预约 - 客房」的 E-R 图：

```
[elder_member]--(1:N)--<room_reservation>--(N:1)--[room_info]--(N:1)--[room_type]
```

并把 E-R 图逐字段翻译为建表结构（手写）：

```sql
-- 简化演示
CREATE TABLE room_type (
  id           BIGINT PRIMARY KEY AUTO_INCREMENT COMMENT '房型ID',
  type_name    VARCHAR(50)  NOT NULL COMMENT '房型名称',
  price        DECIMAL(10,2) NOT NULL COMMENT '日单价（元）',
  capacity     INT          NOT NULL COMMENT '可住人数',
  description  VARCHAR(500) COMMENT '房型描述'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型表';
```

演示要点：每个字段都要 COMMENT；表也要 COMMENT。

#### 4. 实操（9 分钟）
学生画「健康评测」的 E-R 图（涉及 `elder_member` 和 `health_check` 两张表），列出字段清单，教师抽 2 位学生上白板展示。

#### 5. 小结（2 分钟）
回顾：三大范式、E-R、字段类型、命名规范。下一课把这些规则交给 DeepSeek，让它替我们写 DDL。

### 四、课上提问
1. 为什么金额一定要用 DECIMAL 而不是 DOUBLE？
2. `room_reservation` 是 1:N 还是 M:N？中间是否需要中间表？
3. 「性别」字段你会用什么类型？

### 五、课堂练习
1. 画「会员 - 健康检测 - 医嘱」的 E-R 图。
2. 为 `room_reservation` 列出 8 个字段并注明类型与理由。

### 六、课后思考
如果一位会员在 3 年内改了 2 次手机号，历史订单里的联系方式应该怎么存？范式与冗余怎么选？

### 七、课后作业
1. 为 6 大模块画出总体 E-R 图（可用 draw.io / 亿图 / 手画拍照）。
2. 输出《数据库设计文档 v1.md》，覆盖至少 5 张表的字段清单。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-3 数据库设计原则 & E-R                 │
├───────────────────────────────────────────────┤
│ 1NF 原子 / 2NF 完全依赖 / 3NF 无传递依赖      │
│ E-R：实体—关系—基数（1:1 / 1:N / M:N）        │
│ 类型：VARCHAR/INT/DECIMAL/DATETIME            │
│ 命名：小写下划线，id / create_time            │
│ 反范式：报表、快照、性能                      │
└───────────────────────────────────────────────┘
```

---

## 第 4 课时：使用 DeepSeek 生成建表 SQL

### 一、教学目标
- 知识目标：掌握「让 AI 生成 DDL」的 Prompt 要点；理解人工审校清单（字符集、引擎、索引、注释、外键、字段长度）。
- 能力目标：能让 DeepSeek 输出规范化 DDL，并能在 5 分钟内完成审校修正。

### 二、教学重难点
- 重点：Prompt 中如何嵌入「命名规范 + 字段清单 + 约束」；六项审校清单。
- 难点：外键处理策略——启用外键还是应用层保证？

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
提问：「上一节课我们手写了两张表，如果 7 张表都手写，需要多久？出错概率多高？」引出让 AI 批量生成的诉求。

#### 2. 讲授（16 分钟）
**（1）生成 DDL 的 Prompt 关键点**：
- 明确 MySQL 版本（5.7 / 8.0）与字符集（utf8mb4）；
- 提供命名规范；
- 提供每张表的字段清单（教师昨天已梳理）；
- 要求：InnoDB、每字段 COMMENT、合适索引、主键统一 `id BIGINT AUTO_INCREMENT`；
- 要求：不使用物理外键，而是通过应用层保证一致性（互联网项目主流做法）。

**（2）人工审校六项清单**：

| 序号 | 检查项 | 常见问题 |
|------|--------|----------|
| 1 | 字符集/校对集 | AI 有时给 `utf8` 而非 `utf8mb4`，无法存 Emoji |
| 2 | 引擎 | 有时输出 MyISAM，不支持事务 |
| 3 | 字段类型/长度 | 手机号给了 `INT`（错误），身份证给了 `VARCHAR(15)` |
| 4 | 索引 | 常用查询字段（手机号、会员ID）没索引 |
| 5 | 注释 | 字段/表 COMMENT 缺失 |
| 6 | 外键 | 是否符合团队约定 |

**（3）外键的两种策略**：

| 策略 | 优点 | 缺点 | 适用 |
|------|------|------|------|
| 物理外键（FOREIGN KEY）| 强一致 | 分库分表难、并发差 | 内部管理系统 |
| 逻辑外键（不加约束）| 灵活 | 应用层要控 | 互联网项目 |

本项目采用**逻辑外键 + 索引**策略。

#### 3. 演示（12 分钟）
教师现场输入以下 Prompt 到 DeepSeek，然后逐条对照六项清单审校：

```text
# 角色
你是一名资深 Java 后端架构师，熟悉 MySQL 8.0 与阿里 Java 开发手册。

# 任务
请为「AI 智能养老社区系统」生成以下 7 张表的建表 DDL：
1. sys_user 系统用户表：id, username, password, real_name, phone, role,
   create_time, update_time
2. elder_member 会员表：id, name, gender, age, phone, id_card, address,
   emergency_contact, health_status, member_level, create_time
3. room_type 房型表：id, type_name, price, capacity, description
4. room_info 房间表：id, room_no, type_id, floor, status, image_url, create_time
5. room_reservation 预约表：id, member_id, room_id, check_in_date,
   check_out_date, status, total_price, create_time
6. health_check 健康检测表：id, member_id, check_date, blood_pressure,
   heart_rate, blood_sugar, advice
7. operation_log 操作日志表：id, user_id, operation, method, params,
   ip, cost_time, create_time

# 约束
- MySQL 8.0，全部使用 InnoDB + utf8mb4_unicode_ci；
- 主键统一 `id BIGINT AUTO_INCREMENT`；
- 表和每个字段都必须有 COMMENT；
- 不使用物理外键，但为外键字段建立索引；
- phone 必须 VARCHAR(20)，id_card VARCHAR(20)，金额 DECIMAL(10,2)；
- status 类字段用 TINYINT + 注释说明取值；
- 查询高频字段（phone、id_card、member_id、room_id、create_time）建索引。

# 输出格式
输出可以直接执行的 SQL 脚本，包含 DROP TABLE IF EXISTS + CREATE TABLE，
每张表之间空一行。
```

现场逐条读 AI 输出，用红笔在投影上标注需要修改的点，比如：AI 可能给了 `age INT UNSIGNED` 而没加 CHECK；AI 可能忘了给 `phone` 加索引；AI 把 `create_time` 写成 `TIMESTAMP` 而不是 `DATETIME`（本项目统一 DATETIME）。

```sql
-- 修正示例（片段）
`phone`   VARCHAR(20) NOT NULL COMMENT '手机号',
`id_card` VARCHAR(20) NOT NULL COMMENT '身份证号',
KEY `idx_phone` (`phone`),
KEY `idx_id_card` (`id_card`),
```

#### 4. 实操（12 分钟）
学生复制教师 Prompt 到自己电脑上运行 DeepSeek，把结果保存为 `smart_elder_v1.sql`，然后按六项清单逐条自查，标记至少 5 处需要修正的位置。

#### 5. 小结（2 分钟）
AI 出 DDL 快，但责任在人。下一课我们把审校后的 DDL 完整导入 MySQL。

### 四、课上提问
1. 为什么本项目不用物理外键？
2. `status` 类字段选 INT 还是 TINYINT？为什么？
3. utf8 与 utf8mb4 的区别？

### 五、课堂练习
1. 完成 7 张表 DDL 的自查修正版本。
2. 为 `elder_member` 追加 3 个业务合理的索引。

### 六、课后思考
如果未来会员表要扩展到千万级，`create_time` 索引是加单列索引还是联合索引？

### 七、课后作业
1. 提交经过审校的 `smart_elder_v1.sql`（明日课上验收）。
2. 在《数据库设计文档 v2.md》补充索引列表章节。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-4 DeepSeek 生成 DDL                    │
├───────────────────────────────────────────────┤
│ Prompt 六要素：版本/字符集/命名/字段/约束/格式│
│ 审校六项：字符集 引擎 类型 索引 注释 外键     │
│ 本项目：InnoDB + utf8mb4 + 逻辑外键 + 索引    │
│ 金句：AI 打草稿，人拍板                       │
└───────────────────────────────────────────────┘
```

---

## 第 5 课时：完善建表脚本并导入 MySQL

### 一、教学目标
- 知识目标：掌握完整的 7 张核心表最终结构；掌握两种导入方式：命令行 `source` 与 Navicat 图形化。
- 能力目标：独立创建 `smart_elder` 数据库，成功导入所有表，并能用 SELECT 验证结构。

### 二、教学重难点
- 重点：完整 DDL 的最终版；导入操作。
- 难点：导入失败常见错误（字符集不一致、字段过长、约束冲突）的排查。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示上节课审校完成的 SQL 文件截图，宣布本节课「让它跑起来」。

#### 2. 讲授（10 分钟）
**（1）数据库与用户准备**：
```sql
CREATE DATABASE IF NOT EXISTS smart_elder
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE smart_elder;
```

**（2）导入方式对比**：

| 方式 | 命令/操作 | 优点 | 缺点 |
|------|-----------|------|------|
| 命令行 | `mysql -uroot -p smart_elder < smart_elder_v1.sql` | 快、可脚本化 | 需要熟悉命令 |
| MySQL 客户端 | `source /path/to/smart_elder_v1.sql;` | 交互友好 | 需先 USE |
| Navicat | 右键 → 运行 SQL 文件 | 图形化直观 | 依赖客户端 |

**（3）常见错误速查**：
- `Row size too large`：字段过多或 VARCHAR 过长；
- `Incorrect string value`：字符集不是 utf8mb4；
- `Duplicate entry`：重复插入或表未 DROP；
- `Unknown collation`：MySQL 版本低于 5.7.7。

#### 3. 演示（14 分钟）
教师给出**最终整合版 DDL**并在投影上完整执行一次：

```sql
-- ============================================================
-- 《AI 智能养老社区系统》数据库初始化脚本 v1.0
-- MySQL 8.0 · InnoDB · utf8mb4_unicode_ci
-- ============================================================
DROP DATABASE IF EXISTS smart_elder;
CREATE DATABASE smart_elder DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_elder;

-- 1. 系统用户表
DROP TABLE IF EXISTS sys_user;
CREATE TABLE sys_user (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  username     VARCHAR(50)  NOT NULL COMMENT '登录账号',
  password     VARCHAR(100) NOT NULL COMMENT '密码（BCrypt 加密）',
  real_name    VARCHAR(50)  DEFAULT NULL COMMENT '真实姓名',
  phone        VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  role         TINYINT      NOT NULL DEFAULT 2 COMMENT '角色：1超管 2前台管理员',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  update_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_username (username),
  KEY idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';

-- 2. 会员表
DROP TABLE IF EXISTS elder_member;
CREATE TABLE elder_member (
  id                 BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  name               VARCHAR(50)  NOT NULL COMMENT '姓名',
  gender             TINYINT      NOT NULL DEFAULT 0 COMMENT '性别：0未知 1男 2女',
  age                INT          DEFAULT NULL COMMENT '年龄',
  phone              VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
  id_card            VARCHAR(20)  DEFAULT NULL COMMENT '身份证号',
  address            VARCHAR(255) DEFAULT NULL COMMENT '家庭住址',
  emergency_contact  VARCHAR(100) DEFAULT NULL COMMENT '紧急联系人（姓名+电话）',
  health_status      VARCHAR(50)  DEFAULT '良好' COMMENT '健康状态：良好/一般/较差',
  member_level       TINYINT      NOT NULL DEFAULT 1 COMMENT '会员等级：1普通 2银卡 3金卡 4钻石',
  create_time        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_phone (phone),
  KEY idx_id_card (id_card),
  KEY idx_member_level (member_level),
  KEY idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='养老会员表';

-- 3. 房型表
DROP TABLE IF EXISTS room_type;
CREATE TABLE room_type (
  id           BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  type_name    VARCHAR(50)   NOT NULL COMMENT '房型名称',
  price        DECIMAL(10,2) NOT NULL COMMENT '日单价（元）',
  capacity     INT           NOT NULL DEFAULT 1 COMMENT '可住人数',
  description  VARCHAR(500)  DEFAULT NULL COMMENT '房型描述',
  PRIMARY KEY (id),
  UNIQUE KEY uk_type_name (type_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房型表';

-- 4. 房间表
DROP TABLE IF EXISTS room_info;
CREATE TABLE room_info (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  room_no      VARCHAR(20)  NOT NULL COMMENT '房间号',
  type_id      BIGINT       NOT NULL COMMENT '房型ID（逻辑外键 → room_type.id）',
  floor        INT          NOT NULL COMMENT '楼层',
  status       TINYINT      NOT NULL DEFAULT 0 COMMENT '状态：0空闲 1入住 2维修 3下架',
  image_url    VARCHAR(255) DEFAULT NULL COMMENT '房间图片URL',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  UNIQUE KEY uk_room_no (room_no),
  KEY idx_type_id (type_id),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='房间信息表';

-- 5. 预约表
DROP TABLE IF EXISTS room_reservation;
CREATE TABLE room_reservation (
  id              BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  member_id       BIGINT        NOT NULL COMMENT '会员ID（逻辑外键 → elder_member.id）',
  room_id         BIGINT        NOT NULL COMMENT '房间ID（逻辑外键 → room_info.id）',
  check_in_date   DATE          NOT NULL COMMENT '入住日期',
  check_out_date  DATE          NOT NULL COMMENT '退房日期',
  status          TINYINT       NOT NULL DEFAULT 0 COMMENT '状态：0待确认 1已确认 2已入住 3已退房 4已取消',
  total_price     DECIMAL(10,2) NOT NULL COMMENT '订单总价',
  create_time     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_member_id (member_id),
  KEY idx_room_id (room_id),
  KEY idx_status (status),
  KEY idx_check_in_date (check_in_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房预约表';

-- 6. 健康检测表
DROP TABLE IF EXISTS health_check;
CREATE TABLE health_check (
  id              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  member_id       BIGINT       NOT NULL COMMENT '会员ID（逻辑外键 → elder_member.id）',
  check_date      DATETIME     NOT NULL COMMENT '检测时间',
  blood_pressure  VARCHAR(20)  DEFAULT NULL COMMENT '血压（收缩压/舒张压 mmHg）',
  heart_rate      INT          DEFAULT NULL COMMENT '心率（次/分）',
  blood_sugar     DECIMAL(5,2) DEFAULT NULL COMMENT '血糖（mmol/L）',
  advice          VARCHAR(500) DEFAULT NULL COMMENT 'AI 建议或医生备注',
  PRIMARY KEY (id),
  KEY idx_member_id (member_id),
  KEY idx_check_date (check_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='健康检测表';

-- 7. 操作日志表
DROP TABLE IF EXISTS operation_log;
CREATE TABLE operation_log (
  id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  user_id      BIGINT       DEFAULT NULL COMMENT '操作人ID（逻辑外键 → sys_user.id）',
  operation    VARCHAR(100) DEFAULT NULL COMMENT '操作描述',
  method       VARCHAR(200) DEFAULT NULL COMMENT '被调用方法（类+方法名）',
  params       TEXT         DEFAULT NULL COMMENT '请求参数（JSON）',
  ip           VARCHAR(50)  DEFAULT NULL COMMENT '请求 IP',
  cost_time    BIGINT       DEFAULT NULL COMMENT '耗时（毫秒）',
  create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (id),
  KEY idx_user_id (user_id),
  KEY idx_create_time (create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作日志表';
```

现场执行并 `SHOW TABLES;` 验证 7 张表全部创建成功。

#### 4. 实操（15 分钟）
学生在自己的 MySQL 上：
1. 用 Navicat 或命令行创建 `smart_elder` 库；
2. `source` 上面的完整 DDL；
3. 执行 `SHOW CREATE TABLE elder_member;` 截图提交；
4. 插入 1 条测试数据到 `sys_user` 和 `elder_member`。

```sql
INSERT INTO sys_user(username, password, real_name, role)
VALUES ('admin', '$2a$10$xxxx', '超级管理员', 1);

INSERT INTO elder_member(name, gender, age, phone, id_card, member_level)
VALUES ('王秀兰', 2, 72, '13800001111', '110101195301010012', 3);
```

教师巡回排错，尤其关注字符集报错。

#### 5. 小结（3 分钟）
7 张表落地，项目「地基」建成。下一课整理文档、初始化 Git 仓库。

### 四、课上提问
1. `member_level = 3` 代表什么？
2. 如何验证一张表的字符集？
3. `source` 命令必须先 `USE` 数据库吗？

### 五、课堂练习
1. 用 SELECT 验证每张表都创建成功。
2. 尝试插入一条错误的 gender=5 数据，看是否成功，说明为什么。

### 六、课后思考
如果生产环境已有 100 万条数据，还能 `DROP TABLE` 吗？你会如何进行「灰度改表」？

### 七、课后作业
1. 提交完整的 `smart_elder_v1.sql` 与执行截图。
2. 为每张表插入 3 条测试数据，形成 `data.sql`。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-5 DDL 导入 MySQL                       │
├───────────────────────────────────────────────┤
│ CREATE DATABASE utf8mb4                       │
│ source /path/xxx.sql                          │
│ SHOW TABLES; SHOW CREATE TABLE xxx;           │
│ 7 张表：sys_user / elder_member / room_type   │
│         room_info / room_reservation /        │
│         health_check / operation_log          │
└───────────────────────────────────────────────┘
```

---

## 第 6 课时：小结 + 项目文档整理 + Git 初始化

### 一、教学目标
- 知识目标：理解需求文档、数据库设计文档的必要结构；掌握 `git init / add / commit / remote / push` 基本流程与 `.gitignore` 编写。
- 能力目标：能够独立整理 Day01 的所有产出，并推送到远程 Git 仓库（Gitee/GitHub）。

### 二、教学重难点
- 重点：文档模板、Git 基本命令、.gitignore。
- 难点：养成「先写文档再写代码」的工程习惯。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示两位学生的作业：一位有完整文档 + 代码 + Git 提交，另一位只有 SQL 文件散乱在桌面。让学生自己评价谁更「像工程师」。

#### 2. 讲授（15 分钟）
**（1）需求文档模板**：
```
1. 项目背景
2. 用户角色
3. 模块划分（一句话概括每个模块）
4. 功能需求清单（表格：编号 优先级 描述 备注）
5. 非功能需求
6. 术语表
7. 版本历史
```

**（2）数据库设计文档模板**：
```
1. 命名规范
2. 表清单（表名 中文名 说明 记录数量级）
3. 逐表字段清单（字段名 类型 是否为空 默认值 说明 索引）
4. E-R 图
5. 索引说明
6. 版本历史
```

**（3）Git 基本流程**：

| 命令 | 作用 |
|------|------|
| `git init` | 初始化本地仓库 |
| `git add .` | 加入暂存区 |
| `git commit -m "msg"` | 提交 |
| `git remote add origin <url>` | 关联远程仓库 |
| `git push -u origin main` | 首次推送并追踪 |

**（4）.gitignore 关键条目**：`target/` `*.class` `.idea/` `*.iml` `node_modules/` `dist/` `logs/` `*.log` `application-local.yml`。

**（5）Commit Message 规范**（Conventional Commits 简版）：`feat: xxx` / `fix: xxx` / `docs: xxx` / `chore: xxx`。

#### 3. 演示（12 分钟）
教师现场：

```bash
mkdir smart-elder && cd smart-elder
mkdir docs sql

# 拷贝今日成果
mv ../smart_elder_v1.sql sql/
# docs/需求清单v1.md、docs/数据库设计文档v1.md 略

git init
git branch -M main

cat > .gitignore <<'EOF'
# JetBrains
.idea/
*.iml
# Maven
target/
# Node
node_modules/
dist/
# Logs
logs/
*.log
# Local config
application-local.yml
EOF

git add .
git commit -m "docs: init day01 requirements & database design"
git remote add origin git@gitee.com:xxx/smart-elder.git
git push -u origin main
```

#### 4. 实操（12 分钟）
学生按上述步骤把今日成果推送到自己的 Gitee 仓库，教师验收提交记录。

#### 5. 小结（3 分钟）
Day01 闭环：**需求 → E-R → DDL → 导入 → 文档 → Git**。这条链条今后 11 天将不断复用。预告 Day02：用 SpringBoot + Vue3 搭建项目骨架。

### 四、课上提问
1. 为什么 `.gitignore` 里要忽略 `application-local.yml`？
2. 「feat: 新增会员分页接口」属于哪种 commit type？

### 五、课堂练习
1. 撰写完整的 `docs/需求清单v1.md` 与 `docs/数据库设计文档v1.md`。
2. 完成 Git 提交并把仓库地址提交到班级共享文档。

### 六、课后思考
Git 提交粒度多大合适？「一天一提交」还是「一功能一提交」？为什么？

### 七、课后作业
1. 保证仓库中有 `README.md`（含项目简介、启动步骤占位、技术栈）。
2. 为项目创建 `dev` 分支，并在 `dev` 上提交一次「docs: add erd」。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day01-6 文档 & Git 闭环                      │
├───────────────────────────────────────────────┤
│ 文档：需求文档 v1 + DB 设计文档 v1            │
│ Git：init → add → commit → remote → push      │
│ .gitignore：target/ node_modules/ *.log       │
│ Commit：feat/fix/docs/chore                   │
│ 闭环：需求 → E-R → DDL → 导入 → 文档 → Git    │
└───────────────────────────────────────────────┘
```
