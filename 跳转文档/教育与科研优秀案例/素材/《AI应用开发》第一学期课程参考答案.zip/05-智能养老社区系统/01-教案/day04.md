# 《智能养老社区系统》- 教师教案 - Day04：客房管理模块开发

**授课日：Day 04 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 6 - 客房管理模块（多表关联查询、条件筛选、文件上传、字段冗余、前后端联调）**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01-03 已完成——数据库表结构（含 `room_type`、`room_info` 两张表）、SpringBoot + MyBatis-Plus + Vue3 + Element Plus 骨架、Result/PageBean 统一封装、会员 CRUD 全流程（DTO/VO/Entity 分层、逻辑删除、Postman 联调）**

---

## 第 1 课时：客房数据模型与关联查询

### 一、教学目标
- 知识目标：理解客房与房型的一对多关系；掌握 `LEFT JOIN` 在多表关联查询中的语法；能够读懂 MyBatis XML 的 `<resultMap>` + `<association>` 结构；理解 `status` 枚举值的业务含义（0 空闲 / 1 已预约 / 2 入住 / 3 维护）。
- 能力目标：能根据 `room_info` 与 `room_type` 两张表独立写出\"带房型名称与价格\"的 SQL 查询语句，并把结果映射为 Java 中的 `RoomVO` 对象。

### 二、教学重难点
- 重点：一对多关系在 SQL 层面的 `LEFT JOIN` 落地；`RoomVO`（包含 `typeName` `typePrice`）与 `RoomInfo` 实体的字段拆分；`status` 枚举的四个值与业务动作的映射。
- 难点：\"什么时候用 MyBatis-Plus 内置方法（selectPage）、什么时候必须手写 XML（多表 join）\"的取舍；LEFT JOIN 与 INNER JOIN 在\"房型被删\"场景下的差异。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问：\"昨天大家把会员管理写完了，现在有个新需求 —— 后台要显示客房列表，每一行不但要有房号、楼层、状态，还要显示房型名称和价格。请问用 Day03 的 `selectPage` 能一次搞定吗？\"引导学生回忆：`selectPage` 只查一张表，房型名称必须从 `room_type` 表里\"拉过来\"。教师顺势画出两张表的关系图，写在黑板上：一间客房只能属于一种房型（多对一），一种房型可以对应多间客房。今天的第一课就是把这个\"关联\"表达清楚。

#### 2. 讲授（16 分钟）
（1）先回顾 Day01 建的两张表结构：

```sql
CREATE TABLE room_type (
  id           BIGINT PRIMARY KEY AUTO_INCREMENT,
  type_name    VARCHAR(50)  NOT NULL COMMENT '房型名称：单人间/双人间/套房',
  price        DECIMAL(10,2) NOT NULL COMMENT '每月租金',
  capacity     INT NOT NULL COMMENT '可入住人数',
  description  VARCHAR(255) COMMENT '房型描述'
);

CREATE TABLE room_info (
  id           BIGINT PRIMARY KEY AUTO_INCREMENT,
  room_no      VARCHAR(20)  NOT NULL UNIQUE COMMENT '房号，如 A-101',
  type_id      BIGINT NOT NULL COMMENT '关联房型ID',
  floor        INT COMMENT '所在楼层',
  status       TINYINT DEFAULT 0 COMMENT '0空闲 1已预约 2入住 3维护',
  image_url    VARCHAR(255) COMMENT '房间图片URL',
  create_time  DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

（2）讲 `LEFT JOIN` 的三种写法对比：

| 写法 | 特点 | 何时使用 |
|------|------|----------|
| MyBatis-Plus `selectPage`（单表） | 一行代码搞定，无 join | 只查客房自身字段 |
| MyBatis-Plus-Join `selectJoinPage` | 第三方扩展，需引依赖 | 简单 join，追求代码整洁 |
| 手写 XML + `<resultMap>` | 学习曲线陡，但 SQL 完全可控 | 复杂多表、聚合场景 |

本课程为了让学生扎实理解 join 底层，选择**手写 XML** 的方式。

（3）讲 `LEFT JOIN` 与 `INNER JOIN` 的差别，配合板书：

```
LEFT JOIN：以左表 room_info 为主，即使 room_type 被删也不丢客房记录
INNER JOIN：只保留两表都匹配的行，房型被删则该客房消失
```

结论：**养老场景下必须用 LEFT JOIN**，因为房型偶尔会调整（比如从\"豪华套房\"改名），但客房本身仍要留档。

（4）介绍 `RoomVO` 的设计思想：`RoomInfo` 只映射 `room_info` 表的字段；`RoomVO` 在 `RoomInfo` 之外**冗余**两个字段 `typeName` `typePrice`，这是\"给前端一次查完\"的标准思路。

（5）讲 `status` 枚举：

| 值 | 含义 | 触发场景 |
|----|------|----------|
| 0 | 空闲 | 新建默认；退房后重置 |
| 1 | 已预约 | Day06 智能预约成功后 |
| 2 | 入住 | 老人办理入住时 |
| 3 | 维护 | 房间维修、消杀 |

#### 3. 演示（12 分钟）
教师现场敲实体类和 XML：

**RoomType.java**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import java.math.BigDecimal;

@Data
@TableName("room_type")
public class RoomType {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String typeName;
    private BigDecimal price;
    private Integer capacity;
    private String description;
}
```

**RoomInfo.java**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("room_info")
public class RoomInfo {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String roomNo;
    private Long typeId;
    private Integer floor;
    private Integer status;
    private String imageUrl;
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
}
```

**RoomVO.java**
```java
package com.itcast.smart_elder.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RoomVO {
    private Long id;
    private String roomNo;
    private Long typeId;
    private String typeName;      // 冗余：房型名
    private BigDecimal typePrice; // 冗余：房型价
    private Integer floor;
    private Integer status;
    private String imageUrl;
    private LocalDateTime createTime;
}
```

**RoomMapper.xml（关键片段）**
```xml
<mapper namespace="com.itcast.smart_elder.mapper.RoomMapper">
    <resultMap id="RoomVOMap" type="com.itcast.smart_elder.vo.RoomVO">
        <id property="id" column="id"/>
        <result property="roomNo"     column="room_no"/>
        <result property="typeId"     column="type_id"/>
        <result property="typeName"   column="type_name"/>
        <result property="typePrice"  column="price"/>
        <result property="floor"      column="floor"/>
        <result property="status"     column="status"/>
        <result property="imageUrl"   column="image_url"/>
        <result property="createTime" column="create_time"/>
    </resultMap>

    <sql id="joinRoom">
        SELECT r.id, r.room_no, r.type_id, r.floor, r.status,
               r.image_url, r.create_time,
               t.type_name, t.price
        FROM room_info r
        LEFT JOIN room_type t ON t.id = r.type_id
    </sql>

    <select id="selectVOById" resultMap="RoomVOMap">
        <include refid="joinRoom"/>
        WHERE r.id = #{id}
    </select>
</mapper>
```

在 Navicat 里用真实数据验证：先手工执行 `<sql>` 里的 SQL 语句，让学生看清\"两张表拼在一起的一行长什么样\"。

#### 4. 实操（10 分钟）
学生任务：
1. 在自己的 `elder_db` 中给 `room_type` 手工插入 3 条数据（单人间/双人间/豪华套房）。
2. 给 `room_info` 手工插入 5 条数据（三种房型分布不均）。
3. 在 Navicat 里执行 `SELECT r.*, t.type_name FROM room_info r LEFT JOIN room_type t ON t.id = r.type_id`，观察结果。
4. 复制上面的实体类到 IDEA，编译通过。

教师巡视，重点纠正\"表名写错单复数\"和\"忘记 ON 条件写成笛卡尔积\"两种常见错误。

#### 5. 小结（3 分钟）
今天完成的是\"数据模型认识 + 关联 SQL 熟悉\"，第 2 课时会把这段 XML 扩成\"多条件动态分页\"，让前端搜索栏可用。

### 四、课上提问
1. `LEFT JOIN` 和 `INNER JOIN` 各自返回的行数在什么情况下会不同？
2. 为什么 `RoomVO` 里放 `typeName` 而不是把 `RoomType` 对象整个塞进 `RoomInfo`？
3. `status = 3` 的客房应该在预约页面显示吗？

### 五、课堂练习
1. 修改 XML，把\"入住人数\" `capacity` 也带出来放入 `RoomVO`。
2. 用 Navicat 找出\"目前处于维护状态的所有房间\"，并按楼层升序排列。

### 六、课后思考
如果一间客房临时改房型（如从单人间改双人间），历史订单里显示的\"房型\"应该跟着变吗？为什么？

### 七、课后作业
1. 补齐 `RoomType` 与 `RoomInfo` 两个实体的 Mapper 接口（继承 `BaseMapper`）。
2. 用 Postman 提前预留 6 个客房相关请求。
3. 阅读 MyBatis 官网 `<resultMap>` 章节。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  客房数据模型与关联查询                    │
├────────────────────────────────────────────┤
│ 1. 一对多：room_type <— room_info          │
│ 2. LEFT JOIN 保左表不丢                    │
│ 3. VO = Entity + 冗余(typeName, price)     │
│ 4. status: 0空闲 1约 2住 3修               │
│ 5. 手写 XML 派：<resultMap><association>   │
└────────────────────────────────────────────┘
```

---

## 第 2 课时：客房分页与条件筛选接口

### 一、教学目标
- 知识目标：掌握 `RoomPageDTO` 的字段设计与默认值兜底；能够在 XML 中用 `<where>` `<if>` 动态拼接多条件；理解手写 SQL 分页与 MyBatis-Plus 内置分页拦截器的配合。
- 能力目标：能够独立完成\"按房号模糊 + 房型精确 + 状态精确 + 分页\"的接口 Controller/Service/Mapper 全链路，并用 Postman 得到期望响应。

### 二、教学重难点
- 重点：`<where>` 标签自动去除多余的 AND；`Page<RoomVO>` 传给 `Mapper` 方法作为分页入参；把 `IPage<RoomVO>` 转 `PageBean<RoomVO>` 的写法。
- 难点：手写 XML 分页时，`Page` 参数必须是 Mapper 方法的\"第一个参数\"，否则拦截器不会注入 LIMIT。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示前端草图：一个搜索区域\"房号 [输入框] 房型 [下拉] 状态 [下拉] [搜索] [重置]\"，下面是分页列表。教师提问：\"这三个条件如果都不选，应该返回什么？如果只选状态，SQL 里应该拼几个 AND？\"引出\"动态 SQL\"必要性。

#### 2. 讲授（16 分钟）
（1）讲 `RoomPageDTO` 设计思路：只装接收字段，不装 `RoomInfo` 里的图片等大字段：

```java
package com.itcast.smart_elder.dto;

import lombok.Data;

@Data
public class RoomPageDTO {
    private String  roomNo;   // 模糊
    private Long    typeId;   // 精确
    private Integer status;   // 精确
    private Integer pageNum  = 1;
    private Integer pageSize = 10;
}
```

（2）对比\"MyBatis-Plus 单表分页\"与\"手写 XML 分页\"两种思路：

| 场景 | 用哪种 | 原因 |
|------|--------|------|
| 单表 CRUD | MyBatis-Plus `selectPage` | 无需 SQL |
| 多表 join | 手写 XML + Page 参数 | 复杂 SQL 需完全可控 |

（3）讲 `<where>` 与 `<if>` 组合：

```xml
<where>
    <if test="roomNo != null and roomNo != ''">
        AND r.room_no LIKE CONCAT('%', #{roomNo}, '%')
    </if>
    <if test="typeId != null">
        AND r.type_id = #{typeId}
    </if>
    <if test="status != null">
        AND r.status = #{status}
    </if>
</where>
```

`<where>` 会自动把第一个 `AND` 去掉，并保证\"没条件也不会写空 WHERE\"。

（4）分页 SQL 由拦截器自动加 LIMIT，学生不用手写。前提是 Mapper 方法签名必须写成 `IPage<RoomVO> pageVO(IPage<RoomVO> page, @Param(\"q\") RoomPageDTO dto);`，`Page` 是第一个参数。

#### 3. 演示（14 分钟）

**RoomMapper.java**
```java
package com.itcast.smart_elder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.itcast.smart_elder.dto.RoomPageDTO;
import com.itcast.smart_elder.entity.RoomInfo;
import com.itcast.smart_elder.vo.RoomVO;
import org.apache.ibatis.annotations.Param;

public interface RoomMapper extends BaseMapper<RoomInfo> {
    IPage<RoomVO> pageVO(IPage<RoomVO> page, @Param("q") RoomPageDTO dto);
    RoomVO selectVOById(@Param("id") Long id);
}
```

**RoomMapper.xml（完整）**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.itcast.smart_elder.mapper.RoomMapper">

    <resultMap id="RoomVOMap" type="com.itcast.smart_elder.vo.RoomVO">
        <id     property="id"         column="id"/>
        <result property="roomNo"     column="room_no"/>
        <result property="typeId"     column="type_id"/>
        <result property="typeName"   column="type_name"/>
        <result property="typePrice"  column="price"/>
        <result property="floor"      column="floor"/>
        <result property="status"     column="status"/>
        <result property="imageUrl"   column="image_url"/>
        <result property="createTime" column="create_time"/>
    </resultMap>

    <sql id="joinCols">
        r.id, r.room_no, r.type_id, r.floor, r.status,
        r.image_url, r.create_time,
        t.type_name, t.price
    </sql>

    <select id="pageVO" resultMap="RoomVOMap">
        SELECT <include refid="joinCols"/>
        FROM room_info r
        LEFT JOIN room_type t ON t.id = r.type_id
        <where>
            <if test="q.roomNo != null and q.roomNo != ''">
                AND r.room_no LIKE CONCAT('%', #{q.roomNo}, '%')
            </if>
            <if test="q.typeId != null">
                AND r.type_id = #{q.typeId}
            </if>
            <if test="q.status != null">
                AND r.status = #{q.status}
            </if>
        </where>
        ORDER BY r.floor ASC, r.room_no ASC
    </select>

    <select id="selectVOById" resultMap="RoomVOMap">
        SELECT <include refid="joinCols"/>
        FROM room_info r
        LEFT JOIN room_type t ON t.id = r.type_id
        WHERE r.id = #{id}
    </select>
</mapper>
```

**RoomService & Impl**
```java
package com.itcast.smart_elder.service;

import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.dto.RoomPageDTO;
import com.itcast.smart_elder.vo.RoomVO;

public interface RoomService {
    PageBean<RoomVO> page(RoomPageDTO dto);
    RoomVO getById(Long id);
}
```

```java
package com.itcast.smart_elder.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.dto.RoomPageDTO;
import com.itcast.smart_elder.mapper.RoomMapper;
import com.itcast.smart_elder.service.RoomService;
import com.itcast.smart_elder.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomMapper roomMapper;

    @Override
    public PageBean<RoomVO> page(RoomPageDTO dto) {
        IPage<RoomVO> p = new Page<>(dto.getPageNum(), dto.getPageSize());
        IPage<RoomVO> res = roomMapper.pageVO(p, dto);
        return new PageBean<>(res.getTotal(), res.getRecords());
    }

    @Override
    public RoomVO getById(Long id) {
        return roomMapper.selectVOById(id);
    }
}
```

**RoomController（雏形）**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.dto.RoomPageDTO;
import com.itcast.smart_elder.service.RoomService;
import com.itcast.smart_elder.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
public class RoomController {

    private final RoomService roomService;

    @GetMapping("/page")
    public Result<PageBean<RoomVO>> page(RoomPageDTO dto) {
        return Result.success(roomService.page(dto));
    }

    @GetMapping("/{id}")
    public Result<RoomVO> getById(@PathVariable Long id) {
        return Result.success(roomService.getById(id));
    }
}
```

启动项目，用 Postman 调 `GET http://localhost:8080/api/rooms/page?pageNum=1&pageSize=10`，看到 `data.rows[i].typeName` 已经带出来。

#### 4. 实操（9 分钟）
学生任务：
1. 复制上述代码，跑通\"无条件分页\"。
2. 追加 `?roomNo=A&status=0`，观察响应只剩空闲的 A 系房间。
3. 故意把 Mapper 方法签名的 `IPage<RoomVO>` 挪到第二个参数，观察响应\"没有分页\" —— 印证\"Page 必须在第一位\"。

#### 5. 小结（3 分钟）
第 2 课时完成了后端的\"查\"—— 一次搞定分页 + 多条件 + join。第 3 课时进入\"上传图片\"，为客房加上封面。

### 四、课上提问
1. `<where>` 标签的作用是什么？如果不用它需要如何避免\"WHERE 后面直接跟 AND\"？
2. 分页拦截器为什么必须要求 `Page` 参数放第一位？
3. `LIKE CONCAT('%', #{q.roomNo}, '%')` 为什么要用 CONCAT 而不是字符串拼接？

### 五、课堂练习
1. 增加\"楼层筛选\" `floor` 字段，仿照 `status` 精确匹配。
2. 把排序改为\"按 create_time 倒序\"。

### 六、课后思考
如果客房有 100 万条，`SELECT ... LEFT JOIN ...` 的性能会不会成为瓶颈？Day10 系统优化会怎么处理？

### 七、课后作业
1. 用 Postman 完成对 `GET /api/rooms/page` 的至少 5 种参数组合测试并截图。
2. 阅读\"MyBatis 分页拦截器\"源码，了解 `PageHelper` 与 MyBatis-Plus 拦截器的区别。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  客房分页 + 条件筛选                       │
├────────────────────────────────────────────┤
│ 1. DTO 装参 + 默认值兜底                   │
│ 2. <where><if> 动态 SQL                    │
│ 3. IPage 参数必须第一位                    │
│ 4. IPage→PageBean 一次转换                 │
│ 5. LEFT JOIN + CONCAT('%',#{},'%') 模糊    │
└────────────────────────────────────────────┘
```

---

## 第 3 课时：图片上传与本地存储

### 一、教学目标
- 知识目标：理解 `multipart/form-data` 表单类型；掌握 `MultipartFile` 接口的常用方法（getOriginalFilename / getSize / transferTo）；掌握 `WebMvcConfigurer.addResourceHandlers` 把磁盘目录映射为 URL 前缀。
- 能力目标：独立完成一个 `/api/upload` 接口，前端传一张图片，后端保存到本地磁盘并返回可访问的 URL，浏览器直接能打开。

### 二、教学重难点
- 重点：`UUID` + 原始后缀生成不冲突文件名；文件大小/类型白名单校验；跨平台目录（Windows `D:/upload/rooms/` vs Linux `/data/upload/rooms/`）。
- 难点：\"物理路径\"与\"访问路径\"的映射关系；上传目录必须自动创建。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问：\"如果客房要贴一张照片，你会把它存到数据库还是磁盘？\"引导学生认识\"数据库只存 URL、图片本身放文件系统\"是行业主流方案。再问：\"存到哪个盘、什么目录、URL 长啥样？\"引出配置化路径。

#### 2. 讲授（15 分钟）
（1）先讲 SpringBoot 的默认限制。`application.yml` 里加：

```yaml
spring:
  servlet:
    multipart:
      max-file-size: 5MB
      max-request-size: 10MB

app:
  upload:
    dir: D:/upload/rooms/           # Windows；Linux 改 /data/upload/rooms/
    url-prefix: /files/rooms/       # 前端拼上 http://localhost:8080 即可访问
```

（2）讲 `MultipartFile` 的关键方法：

| 方法 | 作用 |
|------|------|
| `getOriginalFilename()` | 原始文件名（可用于取后缀） |
| `getSize()` | 文件大小（byte） |
| `getContentType()` | MIME 类型（image/png、image/jpeg） |
| `getInputStream()` | 得到输入流 |
| `transferTo(File dest)` | **一键落盘**，最常用 |

（3）讲文件名生成：一律用 `UUID.randomUUID().toString().replace("-","")` + 原后缀，避免\"用户上传 1.jpg 又上传 1.jpg 冲突\"。

（4）讲静态资源映射：Spring MVC 默认只把 `classpath:/static/` 暴露为 URL。要让\"磁盘目录\"也能被浏览器访问，必须实现 `WebMvcConfigurer.addResourceHandlers`：

```
磁盘 D:/upload/rooms/xxx.jpg
  |
  | addResourceHandlers 建立映射
  V
URL http://localhost:8080/files/rooms/xxx.jpg
```

#### 3. 演示（14 分钟）

**UploadProperties（配置类）**
```java
package com.itcast.smart_elder.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("app.upload")
public class UploadProperties {
    private String dir;
    private String urlPrefix;
}
```

**WebConfig（关键：静态资源映射）**
```java
package com.itcast.smart_elder.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

    private final UploadProperties uploadProperties;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // /files/rooms/**  ==>  file:D:/upload/rooms/
        registry.addResourceHandler(uploadProperties.getUrlPrefix() + "**")
                .addResourceLocations("file:" + uploadProperties.getDir());
    }
}
```

**FileController**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.config.UploadProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class FileController {

    private static final Set<String> ALLOWED = Set.of(".jpg", ".jpeg", ".png", ".gif", ".webp");
    private static final long MAX_SIZE = 5L * 1024 * 1024;

    private final UploadProperties props;

    @PostMapping("/upload")
    public Result<String> upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            return Result.fail("上传文件为空");
        }
        if (file.getSize() > MAX_SIZE) {
            return Result.fail("文件不能超过 5MB");
        }
        String origin = file.getOriginalFilename();
        if (origin == null || !origin.contains(".")) {
            return Result.fail("文件必须有后缀");
        }
        String ext = origin.substring(origin.lastIndexOf(".")).toLowerCase();
        if (!ALLOWED.contains(ext)) {
            return Result.fail("只支持 " + ALLOWED);
        }

        // 目录自动创建
        File dir = new File(props.getDir());
        if (!dir.exists() && !dir.mkdirs()) {
            return Result.fail("上传目录创建失败：" + props.getDir());
        }

        // UUID 命名
        String newName = UUID.randomUUID().toString().replace("-", "") + ext;
        File dest = new File(dir, newName);
        file.transferTo(dest);

        // 返回可访问 URL（拼上服务器域名由前端处理）
        String url = props.getUrlPrefix() + newName;
        return Result.success(url);
    }
}
```

Postman 演示：Body → form-data → key=`file` type=File → 选一张 jpg → 发送。响应：

```json
{ "code": 1, "msg": "success", "data": "/files/rooms/9a3f...c1.jpg" }
```

再在浏览器地址栏输入 `http://localhost:8080/files/rooms/9a3f...c1.jpg`，直接看到图片。学生看到\"磁盘文件出现\"+\"浏览器打开\"的双重反馈时通常会发出赞叹。

#### 4. 实操（10 分钟）
学生任务：
1. 修改自己的 `application.yml`，把 `app.upload.dir` 改成自己电脑上真实的路径。
2. 用 Postman 上传一张 3MB 以内的 png、一张 6MB 的 jpg（应报 5MB 限制）、一张 txt（应报只支持图片）。
3. 上传成功后，在磁盘目录里找到那个 UUID 文件，用图片查看器打开。

#### 5. 小结（3 分钟）
第 3 课时把\"文件上传\"这个技术点闭环。第 4 课时把上传到的 URL 保存到 `room_info.image_url` 字段，实现\"客房新增/修改（含图片）\"。

### 四、课上提问
1. 为什么要用 UUID 命名而不是保留原文件名？
2. `addResourceHandlers` 里 `file:` 前缀能不能省？
3. `application.yml` 里的 `max-file-size` 和代码里的 `MAX_SIZE` 有什么区别？

### 五、课堂练习
1. 修改代码，把上传的图片再存一份缩略图（宽度 200px）。
2. 增加\"每天一个子目录\"策略：`D:/upload/rooms/2026-07-09/xxx.jpg`。

### 六、课后思考
如果部署到 Linux 服务器，`D:/upload/` 显然不能用。你能想到几种\"跨环境\"的解决方案？

### 七、课后作业
1. 阅读 Spring 官方文档 `Multipart resolver` 章节。
2. 试着把 `/api/upload` 改成返回**完整 URL**（含 `http://localhost:8080`），并说明生产环境有什么问题。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  文件上传流程                              │
├────────────────────────────────────────────┤
│ 1. 表单类型：multipart/form-data           │
│ 2. MultipartFile.transferTo(dest) 落盘     │
│ 3. UUID + 原后缀 命名                      │
│ 4. addResourceHandlers 磁盘 → URL          │
│ 5. 校验：size / ext / empty                │
└────────────────────────────────────────────┘
```

---

## 第 4 课时：客房新增/修改（含图片）

### 一、教学目标
- 知识目标：掌握 DTO 分裂设计（`RoomAddDTO` / `RoomUpdateDTO`）；理解\"字段冗余\"的取舍（保存 `typeId`，不保存 `typeName`）；掌握房号唯一性校验的两种时机（DB 唯一索引 + 代码提前 count）。
- 能力目标：能独立完成新增、修改两个接口，并考虑并发场景下\"两个用户同时新增房号 A-101\"的应对方案。

### 二、教学重难点
- 重点：`@Transactional` 在\"多步 DB 操作\"中的应用；`status` 默认值 0（新增即为空闲）；`image_url` 直接存前面第 3 课时返回的相对路径。
- 难点：唯一性校验的时序漏洞——先 count 再 insert 中间有其他事务插入，需要靠 DB 唯一索引\"兜底\"。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问：\"新增客房时，我们前端会传 `typeId` 还是 `typeName`？为什么？\"引出\"字段冗余是查询优化，而写入必须只写原始字段\"这一设计准则。

#### 2. 讲授（15 分钟）
（1）DTO 分裂：新增没有 `id`，修改必须有 `id`，且新增可以没 `imageUrl`（上传后再回填），修改往往需要保留旧图。

（2）字段冗余处理原则：

| 场景 | 保存/更新哪些字段 |
|------|------------------|
| 客房新增 | room_no / type_id / floor / image_url，`status` 默认 0，`create_time` 由 MP 填充 |
| 客房修改 | room_no / type_id / floor / image_url（不改 status） |
| 客房上下架 | 只改 status |
| 查询 | LEFT JOIN 一次带出 typeName / typePrice |

**永远不要**在 `room_info` 表里冗余 `type_name`：一旦房型改名，历史数据会\"脱同步\"。

（3）唯一性校验：Day01 建表时我们已经加了 `UNIQUE(room_no)`，但仍然要在 Service 层提前 `count` 一次并给出\"房号已存在\"的友好提示；如果 count 通过但 insert 冲突，捕获 `DuplicateKeyException` 也给同一提示。

（4）事务：新增虽然只有一次 insert，为了未来扩展到\"房间+图片入库\"（Day06），统一加 `@Transactional`。

#### 3. 演示（15 分钟）

**RoomAddDTO / RoomUpdateDTO**
```java
package com.itcast.smart_elder.dto;

import lombok.Data;

@Data
public class RoomAddDTO {
    private String  roomNo;
    private Long    typeId;
    private Integer floor;
    private String  imageUrl;
}

@Data
public class RoomUpdateDTO {
    private Long    id;
    private String  roomNo;
    private Long    typeId;
    private Integer floor;
    private String  imageUrl;
}
```

**RoomStatusDTO（上下架/状态切换用）**
```java
package com.itcast.smart_elder.dto;

import lombok.Data;

@Data
public class RoomStatusDTO {
    private Long    id;
    private Integer status;
}
```

**Service 接口 & 实现**
```java
public interface RoomService {
    PageBean<RoomVO> page(RoomPageDTO dto);
    RoomVO getById(Long id);
    void add(RoomAddDTO dto);
    void update(RoomUpdateDTO dto);
    void changeStatus(RoomStatusDTO dto);
    void delete(java.util.List<Long> ids);
}
```

```java
package com.itcast.smart_elder.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.itcast.smart_elder.dto.*;
import com.itcast.smart_elder.entity.RoomInfo;
import com.itcast.smart_elder.exception.BusinessException;
import com.itcast.smart_elder.mapper.RoomMapper;
import com.itcast.smart_elder.service.RoomService;
import com.itcast.smart_elder.vo.RoomVO;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RoomServiceImpl implements RoomService {

    private final RoomMapper roomMapper;

    @Override
    @Transactional
    public void add(RoomAddDTO dto) {
        checkRoomNo(dto.getRoomNo(), null);
        RoomInfo info = new RoomInfo();
        info.setRoomNo(dto.getRoomNo());
        info.setTypeId(dto.getTypeId());
        info.setFloor(dto.getFloor());
        info.setImageUrl(dto.getImageUrl());
        info.setStatus(0); // 默认空闲
        try {
            roomMapper.insert(info);
        } catch (DuplicateKeyException e) {
            throw new BusinessException("房号已存在：" + dto.getRoomNo());
        }
    }

    @Override
    @Transactional
    public void update(RoomUpdateDTO dto) {
        if (dto.getId() == null) throw new BusinessException("id 必填");
        checkRoomNo(dto.getRoomNo(), dto.getId());
        RoomInfo info = new RoomInfo();
        info.setId(dto.getId());
        info.setRoomNo(dto.getRoomNo());
        info.setTypeId(dto.getTypeId());
        info.setFloor(dto.getFloor());
        info.setImageUrl(dto.getImageUrl());
        // 注意：不改 status，避免用户误改
        roomMapper.updateById(info);
    }

    @Override
    public void changeStatus(RoomStatusDTO dto) {
        RoomInfo info = new RoomInfo();
        info.setId(dto.getId());
        info.setStatus(dto.getStatus());
        roomMapper.updateById(info);
    }

    @Override
    @Transactional
    public void delete(List<Long> ids) {
        if (ids == null || ids.isEmpty()) throw new BusinessException("ids 必填");
        roomMapper.deleteBatchIds(ids);
    }

    private void checkRoomNo(String roomNo, Long excludeId) {
        if (!StringUtils.hasText(roomNo)) throw new BusinessException("房号必填");
        Long cnt = roomMapper.selectCount(new LambdaQueryWrapper<RoomInfo>()
                .eq(RoomInfo::getRoomNo, roomNo)
                .ne(excludeId != null, RoomInfo::getId, excludeId));
        if (cnt != null && cnt > 0) {
            throw new BusinessException("房号已存在：" + roomNo);
        }
    }
    // page / getById 在第 2 课时已完成
}
```

**Controller 补齐**
```java
@PostMapping
public Result<Void> add(@RequestBody RoomAddDTO dto) {
    roomService.add(dto);
    return Result.success();
}

@PutMapping
public Result<Void> update(@RequestBody RoomUpdateDTO dto) {
    roomService.update(dto);
    return Result.success();
}

@PutMapping("/status")
public Result<Void> changeStatus(@RequestBody RoomStatusDTO dto) {
    roomService.changeStatus(dto);
    return Result.success();
}

@DeleteMapping("/{ids}")
public Result<Void> delete(@PathVariable java.util.List<Long> ids) {
    roomService.delete(ids);
    return Result.success();
}
```

Postman 验证 3 组用例：正常新增、房号重复新增（预期返回\"房号已存在\"）、修改中把房号改成\"另一间房已用\"的房号（预期同错）。

#### 4. 实操（9 分钟）
学生任务：跑通\"上传图片 → 拿到 imageUrl → 新增客房 → 分页查询看到图片\"的完整链路。教师巡视，重点纠正\"新增时 typeId 传字符串而非数字\"造成 400 的错误。

#### 5. 小结（3 分钟）
后端 6 个接口今天全部搞定。第 5、6 课时进入前端。

### 四、课上提问
1. 为什么 `updateById` 不能带 `status` 字段？
2. `selectCount` 用了 `.ne(excludeId != null, ...)`，第一个参数为什么是布尔表达式？
3. `DuplicateKeyException` 与我们代码里的 count 校验，哪个是\"最后一道防线\"？

### 五、课堂练习
1. 补齐\"批量删除\"的 Postman 用例。
2. 尝试在两个 Postman 标签里几乎同时发 `POST /api/rooms` 相同房号，观察行为。

### 六、课后思考
如果新增客房时上传的图片留在磁盘，但请求校验失败最终客房没保存，磁盘会不会\"堆一堆孤儿图片\"？如何治理？

### 七、课后作业
1. 补齐 `BusinessException` 与全局异常处理（若 Day03 已完成则复用）。
2. 完成\"客房新增\"接口的 5 种 Postman 用例并截图。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  新增 / 修改 / 上下架 / 删除               │
├────────────────────────────────────────────┤
│ 1. DTO 分裂：Add / Update / Status         │
│ 2. 只存 typeId，永不冗余 typeName          │
│ 3. status 新增默认 0，修改不动             │
│ 4. 房号唯一：count + DB 唯一索引双保险     │
│ 5. @Transactional 提前布道                 │
└────────────────────────────────────────────┘
```

---

## 第 5 课时：前端客房列表 + 图片展示

### 一、教学目标
- 知识目标：掌握 `axios` 请求方法在 `api/room.ts` 中的统一封装；掌握 Element Plus 的 `el-table` 显示图片列的两种方案；理解\"分页参数由前端组装\"的常规写法。
- 能力目标：能独立在 `views/room/list.vue` 中做出一个\"搜索栏 + 表格 + 图片列 + 状态标签 + 分页\"的完整列表页，接通 Day04 第 2 课时的分页接口。

### 二、教学重难点
- 重点：`api/room.ts` 的 6 个方法一次性写完；`el-table-column` 中 `slot` 展示 `image_url`；`el-tag` 用不同颜色渲染 4 种 `status`。
- 难点：图片 URL 拼接。后端返回相对路径 `/files/rooms/xxx.jpg`，前端要拼上 `import.meta.env.VITE_API_BASE`，避免线上环境不同。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师打开自己已经写好的一个客房列表页面截图，展示：卡片式带图片、状态标签有颜色、翻页丝滑。提问：\"这个页面看似复杂，其实拆开只有三块：搜索栏、表格、分页。今天就来拆。\"

#### 2. 讲授（14 分钟）
（1）先讲 `api/room.ts` 的封装原则：**一个模块一个文件，方法名与后端接口一一对应**。这样将来查代码时可以\"望名生义\"。

（2）讲图片 URL 拼接：`.env` 文件里定义 `VITE_API_BASE=http://localhost:8080`，运行时用 `import.meta.env.VITE_API_BASE` 拿到。表格中：

```vue
<img :src="`${apiBase}${row.imageUrl}`" style="width:80px;height:60px;object-fit:cover"/>
```

（3）讲 `status` 的 4 种颜色映射：

| status | 文案 | Element Plus tag type |
|--------|------|-----------------------|
| 0 | 空闲 | success |
| 1 | 已预约 | warning |
| 2 | 入住中 | primary |
| 3 | 维护中 | danger |

用 computed 或 map 一次性搞定。

#### 3. 演示（15 分钟）

**src/api/room.ts**
```ts
import request from '@/utils/request'

export interface RoomPageParams {
  roomNo?: string
  typeId?: number
  status?: number
  pageNum?: number
  pageSize?: number
}

// 分页
export const pageRoom = (params: RoomPageParams) =>
  request({ url: '/api/rooms/page', method: 'get', params })

// 详情
export const getRoomById = (id: number) =>
  request({ url: `/api/rooms/${id}`, method: 'get' })

// 新增
export const addRoom = (data: any) =>
  request({ url: '/api/rooms', method: 'post', data })

// 修改
export const updateRoom = (data: any) =>
  request({ url: '/api/rooms', method: 'put', data })

// 修改状态（上下架/入住/维护切换）
export const updateRoomStatus = (data: { id: number; status: number }) =>
  request({ url: '/api/rooms/status', method: 'put', data })

// 批量删除
export const deleteRooms = (ids: number[]) =>
  request({ url: `/api/rooms/${ids.join(',')}`, method: 'delete' })

// 房型下拉（另建 typeApi 也可，这里放一起）
export const listRoomTypes = () =>
  request({ url: '/api/roomTypes', method: 'get' })

// 上传
export const uploadFile = (file: File) => {
  const fd = new FormData()
  fd.append('file', file)
  return request({
    url: '/api/upload', method: 'post', data: fd,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}
```

**src/views/room/list.vue（列表部分，表单在第 6 课时）**
```vue
<template>
  <div class="room-page">
    <!-- 搜索栏 -->
    <el-form :inline="true" class="search-bar">
      <el-form-item label="房号">
        <el-input v-model="query.roomNo" placeholder="模糊查询" clearable/>
      </el-form-item>
      <el-form-item label="房型">
        <el-select v-model="query.typeId" placeholder="全部" clearable style="width:160px">
          <el-option v-for="t in typeList" :key="t.id" :label="t.typeName" :value="t.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="状态">
        <el-select v-model="query.status" placeholder="全部" clearable style="width:140px">
          <el-option label="空闲" :value="0"/>
          <el-option label="已预约" :value="1"/>
          <el-option label="入住中" :value="2"/>
          <el-option label="维护中" :value="3"/>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSearch">搜索</el-button>
        <el-button @click="onReset">重置</el-button>
        <el-button type="success" @click="openAdd">新增客房</el-button>
        <el-button type="danger" :disabled="!selected.length" @click="onBatchDelete">批量删除</el-button>
      </el-form-item>
    </el-form>

    <!-- 表格 -->
    <el-table :data="rows" @selection-change="v => selected = v" v-loading="loading" border stripe>
      <el-table-column type="selection" width="45"/>
      <el-table-column prop="roomNo"   label="房号"     width="100"/>
      <el-table-column prop="typeName" label="房型"     width="110"/>
      <el-table-column prop="typePrice" label="租金/月" width="100"/>
      <el-table-column prop="floor"    label="楼层"     width="70"/>
      <el-table-column label="图片" width="120">
        <template #default="{ row }">
          <el-image v-if="row.imageUrl"
                    :src="apiBase + row.imageUrl"
                    :preview-src-list="[apiBase + row.imageUrl]"
                    :initial-index="0"
                    fit="cover"
                    hide-on-click-modal
                    style="width:80px;height:60px;border-radius:4px"/>
          <span v-else style="color:#c0c4cc">暂无</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="110">
        <template #default="{ row }">
          <el-tag :type="statusMap[row.status]?.type">
            {{ statusMap[row.status]?.text }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="170"/>
      <el-table-column label="操作" width="220" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openEdit(row.id)">编辑</el-button>
          <el-dropdown @command="cmd => onStatusChange(row, cmd)" trigger="click">
            <el-button link type="warning">改状态<el-icon><arrow-down/></el-icon></el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item :command="0">置为空闲</el-dropdown-item>
                <el-dropdown-item :command="1">置为已预约</el-dropdown-item>
                <el-dropdown-item :command="2">置为入住</el-dropdown-item>
                <el-dropdown-item :command="3">置为维护</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
          <el-button link type="danger" @click="onDelete([row.id])">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination class="pagination"
                   background layout="total, sizes, prev, pager, next"
                   :total="total"
                   v-model:current-page="query.pageNum"
                   v-model:page-size="query.pageSize"
                   :page-sizes="[10,20,50]"
                   @size-change="loadData"
                   @current-change="loadData"/>
  </div>
</template>
```

script setup 稍后（第 6 课时里合并展示）。教师现场跑起来，效果：一张带图片的表格，状态标签有颜色，图片可以预览大图。

#### 4. 实操（10 分钟）
学生任务：
1. 复制模板，跑通页面 → 确认能显示后端返回的图片。
2. 把 `statusMap` 的颜色改成自己喜欢的组合。
3. 试着把\"图片列\"改成`el-avatar` 圆形头像风格。

#### 5. 小结（3 分钟）
今天完成了列表页的显示部分，还差\"新增/编辑弹窗\" —— 那是第 6 课时最后收尾。

### 四、课上提问
1. `el-image` 的 `preview-src-list` 起什么作用？
2. 后端返回的是相对路径，前端为什么要拼 `import.meta.env.VITE_API_BASE`？
3. `statusMap` 用对象存和用 switch 存哪个更好？

### 五、课堂练习
1. 增加\"重置\"按钮：清空 3 个搜索条件并 `loadData`。
2. 把翻页组件放在表格右下，`total-position` 靠右。

### 六、课后思考
如果一个页面同时展示 20 张 5MB 图片，网络会不会卡？前端有哪些优化手段？

### 七、课后作业
1. 添加\"点击图片查看大图\"的独立 Dialog（不用 el-image 自带）。
2. 阅读 Element Plus `el-image` 官方文档。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  前端列表 + 图片展示                       │
├────────────────────────────────────────────┤
│ 1. api/room.ts 统一封装 6 方法             │
│ 2. VITE_API_BASE 拼图片 URL                │
│ 3. el-image + preview-src-list 预览        │
│ 4. status → el-tag 四色映射                │
│ 5. 搜索栏 + 分页 + 批量删除                │
└────────────────────────────────────────────┘
```

---

## 第 6 课时：前端客房表单联调 + 状态管理

### 一、教学目标
- 知识目标：掌握 `el-dialog` + `el-form` 复用做新增/修改；掌握 `el-upload` 组件与自定义 `http-request` 的组合；理解\"上下架\"按钮如何调用 `updateRoomStatus`；掌握 `el-table` 多选后的批量删除交互。
- 能力目标：完成客房模块前端所有交互，通过 Day04 收官——从建表、后端 6 接口、图片上传、前端列表、前端表单联调全链路跑通。

### 二、教学重难点
- 重点：`el-upload` 的 `http-request` 自定义上传逻辑（不用官方默认 action）；表单校验规则与后端\"房号唯一\"错误的合并显示；`form.id` 判定新增/修改。
- 难点：图片上传后立即回显 —— 上传成功后把返回的 URL 写入 `form.imageUrl`，并让 `el-upload` 的 `file-list` 同步；提交成功后重置表单又不能把图片清得太早。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示最终效果 gif：点\"新增客房\" → Dialog 弹出 → 选图片 → 图片实时预览 → 填房号房型楼层 → 保存 → 列表刷新 → 图片显示在表格里。学生看完直呼\"就是想要的样子\"。今天就把这段 gif 变成代码。

#### 2. 讲授（14 分钟）
（1）`el-upload` 的两种模式：
- **默认模式**：设置 `action="/api/upload"`，组件自动 POST。缺点：无法用我们的 axios 拦截器统一处理 Token、错误。
- **自定义模式**：设置 `:http-request="customUpload"`，我们自己调 axios。**推荐**。

（2）Dialog 复用：一份 `form` 数据、一份 `rules` 规则，通过 `form.id` 判定：

```
form.id === undefined → 新增（走 addRoom）
form.id !== undefined → 修改（走 updateRoom）
```

（3）批量操作：`el-table` 有 `selection-change` 事件，选中项存到 `selected` 数组，批量按钮 `:disabled=!selected.length`。

#### 3. 演示（15 分钟）

**src/views/room/list.vue（完整 script setup + Dialog 模板）**
```vue
<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox, FormInstance } from 'element-plus'
import { ArrowDown } from '@element-plus/icons-vue'
import {
  pageRoom, addRoom, updateRoom, deleteRooms,
  updateRoomStatus, getRoomById, listRoomTypes, uploadFile
} from '@/api/room'

const apiBase = import.meta.env.VITE_API_BASE
const statusMap: Record<number, { text: string; type: any }> = {
  0: { text: '空闲',    type: 'success' },
  1: { text: '已预约',  type: 'warning' },
  2: { text: '入住中',  type: 'primary' },
  3: { text: '维护中',  type: 'danger'  }
}

const loading = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const selected = ref<any[]>([])
const typeList = ref<any[]>([])

const query = reactive({ roomNo: '', typeId: undefined, status: undefined,
                         pageNum: 1, pageSize: 10 })

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await pageRoom(query)
    rows.value = res.data.rows
    total.value = res.data.total
  } finally { loading.value = false }
}

const loadTypes = async () => {
  const res: any = await listRoomTypes()
  typeList.value = res.data || []
}

const onSearch = () => { query.pageNum = 1; loadData() }
const onReset  = () => {
  query.roomNo = ''; query.typeId = undefined; query.status = undefined
  query.pageNum = 1; loadData()
}

// ==== 弹窗表单 ====
const dialogVisible = ref(false)
const formRef = ref<FormInstance>()
const emptyForm = () => ({
  id: undefined as number | undefined,
  roomNo: '', typeId: undefined as number | undefined,
  floor: 1, imageUrl: ''
})
const form = reactive<any>(emptyForm())
const fileList = ref<any[]>([])

const rules = {
  roomNo:  [
    { required: true, message: '房号必填', trigger: 'blur' },
    { min: 2, max: 20, message: '房号长度 2-20', trigger: 'blur' }
  ],
  typeId:  [{ required: true, message: '房型必选', trigger: 'change' }],
  floor:   [{ required: true, message: '楼层必填', trigger: 'blur' }]
}

const openAdd = () => {
  Object.assign(form, emptyForm())
  fileList.value = []
  dialogVisible.value = true
}

const openEdit = async (id: number) => {
  const res: any = await getRoomById(id)
  Object.assign(form, emptyForm(), res.data)
  fileList.value = form.imageUrl
    ? [{ name: '当前图片', url: apiBase + form.imageUrl }]
    : []
  dialogVisible.value = true
}

// 自定义上传
const customUpload = async (opt: any) => {
  try {
    const res: any = await uploadFile(opt.file)
    form.imageUrl = res.data      // 保存相对路径
    fileList.value = [{ name: opt.file.name, url: apiBase + res.data }]
    ElMessage.success('图片上传成功')
    opt.onSuccess(res)
  } catch (e: any) {
    ElMessage.error(e?.message || '图片上传失败')
    opt.onError(e)
  }
}

const beforeUpload = (file: File) => {
  const ok = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'].includes(file.type)
  if (!ok) { ElMessage.error('只支持 jpg/png/gif/webp'); return false }
  if (file.size > 5 * 1024 * 1024) { ElMessage.error('图片不能超过 5MB'); return false }
  return true
}

const onRemoveImg = () => { form.imageUrl = ''; fileList.value = [] }

const submit = async () => {
  await formRef.value?.validate()
  if (form.id) {
    await updateRoom(form); ElMessage.success('修改成功')
  } else {
    await addRoom(form); ElMessage.success('新增成功')
  }
  dialogVisible.value = false
  loadData()
}

const onDelete = async (ids: number[]) => {
  await ElMessageBox.confirm('确定删除吗？', '提示', { type: 'warning' })
  await deleteRooms(ids)
  ElMessage.success('删除成功')
  loadData()
}
const onBatchDelete = () => onDelete(selected.value.map(r => r.id))

const onStatusChange = async (row: any, status: number) => {
  const oldStatus = row.status
  try {
    await updateRoomStatus({ id: row.id, status })
    row.status = status
    ElMessage.success('状态已更新')
  } catch {
    row.status = oldStatus
  }
}

onMounted(() => { loadTypes(); loadData() })
</script>

<template>
  <!-- 上面第 5 课时的表格模板此处保持不变，只追加 Dialog -->

  <el-dialog v-model="dialogVisible"
             :title="form.id ? '编辑客房' : '新增客房'"
             width="520px"
             :close-on-click-modal="false">
    <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item label="房号" prop="roomNo">
        <el-input v-model="form.roomNo" placeholder="如 A-101"/>
      </el-form-item>
      <el-form-item label="房型" prop="typeId">
        <el-select v-model="form.typeId" placeholder="请选择">
          <el-option v-for="t in typeList" :key="t.id" :label="t.typeName" :value="t.id"/>
        </el-select>
      </el-form-item>
      <el-form-item label="楼层" prop="floor">
        <el-input-number v-model="form.floor" :min="1" :max="99"/>
      </el-form-item>
      <el-form-item label="图片">
        <el-upload :file-list="fileList" list-type="picture-card"
                   :http-request="customUpload"
                   :before-upload="beforeUpload"
                   :on-remove="onRemoveImg"
                   :limit="1"
                   accept="image/*">
          <el-icon><Plus/></el-icon>
        </el-upload>
        <div style="color:#909399;font-size:12px">只支持 jpg/png/gif/webp，≤ 5MB</div>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="dialogVisible = false">取消</el-button>
      <el-button type="primary" @click="submit">保存</el-button>
    </template>
  </el-dialog>
</template>
```

（教师用现场调试的方式，一边讲一边把这份代码敲进 IDE，学生在自己电脑跟做。）

#### 4. 实操（10 分钟）
学生任务清单：
1. 新增一间客房，房号 A-101，房型选\"单人间\"，上传一张图片，提交。列表出现该行。
2. 点\"编辑\"，改楼层，保存。列表更新。
3. \"改状态\" → 置为\"维护中\"，观察 tag 颜色变化。
4. 勾选 3 行 → 批量删除 → 确认。
5. 故意上传一张 8MB 图片，观察前端 & 后端双重拦截。

教师巡视，重点纠正：`import.meta.env.VITE_API_BASE` 拿到 `undefined` 说明 `.env` 未生效；`el-upload` 一直转圈说明没写 `http-request`。

#### 5. 小结（3 分钟）
本日六课时闭环 —— 客房数据模型 → 分页 join → 图片上传 → 新增修改 → 前端列表 → 前端表单联调。学生首次完成了\"有图片、有状态、有多表关联\"的完整业务模块。Day05 起，接入 AI 大模型，让这个系统\"聪明起来\"。

### 四、课上提问
1. `el-upload` 的 `http-request` 相比 `action` 的优势是什么？
2. `beforeUpload` 与后端校验为什么要\"双保险\"？
3. 状态切换失败时，为什么要把 `row.status = oldStatus` 手动回滚？

### 五、课堂练习
1. 把新增和编辑分成两个 Dialog（不共用）—— 让学生对比\"复用\" vs \"拆开\"两种写法的代码量差别。
2. 给图片上传增加\"上传中\" loading 效果。

### 六、课后思考
如果一次上传多张图片（客房相册），前端和后端应该怎么改造？

### 七、课后作业
1. 完成本日所有代码 push 到自己 GitHub 仓库。
2. 补齐一个\"清空所有图片\"按钮：调用 `onRemoveImg` 并清空 `form.imageUrl`。
3. 预习 Day05：\"Spring AI + 通义千问\" 相关概念。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  客房表单联调 + 状态管理                   │
├────────────────────────────────────────────┤
│ 1. Dialog + Form 复用（form.id 判定）      │
│ 2. el-upload http-request 自定义上传       │
│ 3. 前后端双校验：type / size / required    │
│ 4. 状态切换：Dropdown + 请求失败回滚       │
│ 5. Day04 全链路收官                        │
└────────────────────────────────────────────┘
```

---

**Day04 总结**：以\"客房管理\"为载体，完成了一次\"含图片上传的、多表关联的、有状态机的\"完整业务开发。相比 Day03 的会员管理增加了三项新能力 —— 多表 LEFT JOIN、`MultipartFile` 文件上传、`el-upload` 自定义组件。学生应能把这套骨架带到 Day06 的\"客房预约\"模块中直接复用。
