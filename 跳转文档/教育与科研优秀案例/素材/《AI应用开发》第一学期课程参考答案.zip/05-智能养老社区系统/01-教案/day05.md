# 《智能养老社区系统》- 教师教案 - Day05：对接阿里通义千问 AI 大模型

**授课日：Day 05 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 7 - 基于 Spring AI 集成阿里通义千问，完成同步/流式对话与 Prompt 工程**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01-04 已完成数据库设计、SpringBoot + MyBatis-Plus 后端骨架、Vue3 + Element Plus 前端骨架、会员模块与客房模块 CRUD、图片上传。本天开始正式接入 AI 能力。**

---

## 第 1 课时：大模型基础与百炼平台

### 一、教学目标
- 知识目标：了解大语言模型（LLM）的基本概念、发展脉络与主流玩家；能够对比 GPT-4、通义千问、DeepSeek、Claude 四大模型的定位差异；理解 Transformer 结构的宏观思路（不做数学推导，只讲"输入 → 编码 → 输出"）；掌握阿里百炼平台的注册、开通、API-Key 获取流程；理解 token 的计费方式与"一个汉字约等于 1-2 token"的经验值。
- 能力目标：能独立完成百炼平台账号注册、模型服务开通、API-Key 生成，并把 Key 保存到本地环境变量 `DASHSCOPE_API_KEY` 中，为后续代码调用做好准备。

### 二、教学重难点
- 重点：主流大模型对比表；百炼平台 API-Key 的完整获取路径；token 概念与计费单价。
- 难点：学生首次接触"大模型"容易被 Transformer/注意力机制吓住，教师要用"翻译官"和"接龙游戏"两个类比拉近距离；API-Key 一旦生成必须妥善保管，不能提交到 Git，这是安全底线。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："大家用过 ChatGPT、豆包、通义千问、DeepSeek 吗？谁能用一句话说说它们在做什么？"引导学生从"聊天""写代码""写作文""翻译"等角度回答。然后教师抛出灵魂拷问："这些看起来什么都会的 AI，本质上其实只做一件事——预测下一个字。今天我们要做的，就是让我们的养老社区系统也能拥有这种预测下一个字的能力，用来给老人家做健康咨询、陪伴对话、政策解读。"

黑板画一个简笔漫画："输入：今天天气真不错，我们一起去 → 输出：公园散步吧。"用这个引入让学生理解 LLM 的核心工作机制。

#### 2. 讲授（18 分钟）

（1）LLM 是什么？

用"接龙游戏"类比：LLM 就是被喂了几万亿个字后，学会"看到前文猜下一字"的超级接龙机。它没有意识，但因为读过的字够多，所以能拼出"看起来很聪明"的句子。

Transformer 极简介绍（不写公式）：2017 年 Google 提出的一种神经网络结构，最大特点是"注意力机制"——它读一句话时，会同时关注句子里每一个字对每一个字的关联度，所以特别擅长处理长文本。你只需要记住："Transformer 是所有主流大模型的地基"就够了。

（2）主流大模型对比表（板书 + 投影）：

| 模型 | 厂商 | 上下文 | 中文能力 | 计费（约） | 项目场景 |
|------|------|--------|----------|-----------|---------|
| GPT-4o | OpenAI | 128K | 优秀 | 贵、需科学上网 | 通用 |
| 通义千问 qwen-plus | 阿里 | 32K | 极佳 | 便宜、国内直连 | **本项目首选** |
| DeepSeek-V3 | 深度求索 | 64K | 极佳 | 极便宜 | 备选，Day07 会用 |
| Claude 3.5 | Anthropic | 200K | 良好 | 贵、需海外账号 | 长文档场景 |

明确告诉学生：本项目主用通义千问 `qwen-plus`，因为国内直连、便宜、中文对养老场景表达自然。

（3）百炼平台介绍：

百炼（bailian.console.aliyun.com）是阿里云推出的一站式大模型服务平台，通义千问的 API 调用入口就在这里。它兼容 OpenAI 协议，也提供 dashscope 原生协议，Spring AI 已经封装好了。

（4）API-Key 获取流程（重点）：

1. 用阿里云账号登录 bailian.console.aliyun.com；
2. 左侧菜单 → "模型广场" → 找到通义千问 → 点击"开通服务"；
3. 左侧菜单 → "API-KEY 管理" → 点"创建我的 API-KEY"；
4. 复制 Key（形如 `sk-xxxxxxxxxxxxxx`），**只在这个页面显示一次**，务必立即保存。

（5）token 与计费：

一个汉字大约占用 1-2 个 token，一段 100 字的对话大约消耗 150-200 token。qwen-plus 目前输入约 ¥0.004/千 token、输出约 ¥0.012/千 token。教师现场用计算器算一算："如果一个学生调 100 次接口，每次 200 token，一共花费约 0.24 元"，让学生放心练习。

#### 3. 演示（10 分钟）
教师现场登录百炼平台，投屏演示：
1. 从"模型广场"进入 qwen-plus 详情页，右侧有"体验中心"，直接输入"帮我给爷爷推荐一个适合的养生早餐"，得到实时响应；
2. 点开返回结果的"消耗 token"提示，让学生看到输入 20 token、输出 180 token 的真实数据；
3. 进入"API-KEY 管理"，创建一个名为 `smart-elder-dev` 的 Key，复制到剪贴板；
4. 打开 Windows PowerShell，执行 `setx DASHSCOPE_API_KEY "sk-xxxx"`，讲解环境变量的作用与"不要写在代码里"的规范。

#### 4. 实操（10 分钟）
学生任务：
1. 注册/登录百炼平台；
2. 开通通义千问服务；
3. 创建自己的 API-Key（命名 `smart-elder-学号后四位`）；
4. 把 Key 存入本地环境变量；
5. 在百炼"体验中心"输入一句养老场景的问话，截图并粘贴到当天笔记。

教师巡视，重点检查两个坑：一是 Key 复制不全（末尾少字符导致 401）；二是学生把 Key 直接贴到微信群或 Git，教师立即警告"这条 Key 会被扫描器 3 秒内偷走"。

#### 5. 小结（3 分钟）
今天完成了 AI 之旅的"账号和门票"部分。下一节课我们进入 Spring AI 的世界，看看 Java 后端如何用 3 行代码调通大模型。

### 四、课上提问
1. GPT-4、通义千问、DeepSeek、Claude 中，我们本项目为什么选通义千问？
2. token 是什么？1000 个汉字大约多少 token？
3. API-Key 泄漏会有什么后果？如何防止？

### 五、课堂练习
1. 完成百炼平台注册与 API-Key 创建。
2. 在百炼"体验中心"分别用 qwen-turbo、qwen-plus、qwen-max 三个模型问同一个问题："请给一位 75 岁的老人推荐一份适合冬天的午餐食谱"，对比响应速度和内容质量，写下 100 字观察结论。

### 六、课后思考
如果我们不使用百炼，直接在本地部署一个开源大模型（例如 Qwen2-7B），需要什么样的硬件？和调 API 相比各有什么优劣？

### 七、课后作业
1. 把今天获取的 API-Key 妥善保存到本地环境变量或密码管理器中，禁止贴任何公共平台；
2. 阅读百炼平台"计费说明"文档，用一张表格总结 qwen-turbo / qwen-plus / qwen-max 三个模型的价格差异；
3. 预习 Spring AI 官方文档首页（docs.spring.io/spring-ai）关于 ChatClient 的 5 分钟入门。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-1  大模型基础与百炼平台             │
├────────────────────────────────────────────┤
│ 1. LLM = 超级接龙机（Transformer 地基）    │
│ 2. 四大模型对比（我们选 qwen-plus）        │
│ 3. 百炼平台流程：注册→开通→API-Key         │
│ 4. Token：约 1 汉字 = 1-2 token            │
│ 5. 安全底线：Key 不进 Git、写环境变量      │
└────────────────────────────────────────────┘
```

---

## 第 2 课时：Spring AI 快速入门

### 一、教学目标
- 知识目标：了解 Spring AI 项目的定位（"给 Java 生态一套统一的大模型抽象层"）；掌握当前 1.0.0-M6 版本的关键抽象——`ChatModel`、`ChatClient`、`Prompt`、`Message`、`ChatResponse` 的角色分工；能够画出"用户输入 → Prompt → ChatModel → ChatResponse → 用户"这条链路。
- 能力目标：能用一句话解释 `ChatModel` 与 `ChatClient` 的差异；能在 IDE 中新建一个空模块并正确引入 Spring AI 依赖，为下一课时的代码演练做好环境准备。

### 二、教学重难点
- 重点：Spring AI 五个核心抽象；Message 的三种子类（System/User/Assistant）分别代表的语义；1.0.0-M6 与后续 GA 版本的差异说明（避免学生百度到不匹配的老写法）。
- 难点：`ChatModel`（低阶 API，直接对接厂商）与 `ChatClient`（高阶流式 DSL，官方推荐用法）容易混淆；`Prompt` 与 `Message` 谁包含谁需要用图厘清。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
"上节课我们拿到了钥匙，但门后面是一大堆 HTTP 参数。如果我们每次都自己拼 JSON、自己解析响应，可能一天都写不完一个功能。今天来看 Spring 生态给我们准备的礼物——Spring AI。"教师投屏 Spring AI 官网首页，指出它已经支持 OpenAI、Anthropic、通义千问、DeepSeek、Ollama 等 20+ 种模型，"一套代码切模型只改一个 starter"。

#### 2. 讲授（20 分钟）

（1）Spring AI 定位：

Spring 官方在 2024 年推出、目标是"复刻 Spring Data 在数据库领域的成功"，做一个统一的 AI 集成层。当前主流版本为 1.0.0-M6（M = Milestone 里程碑版），2025 年将转正为 GA。本课程锁定 M6 版本，因为它是当前最稳定的里程碑版，且阿里 spring-ai-alibaba-starter 与之匹配。

**⚠️ 版本坑：** 网上大量老博客用的是 0.8.x，与 M6 的 API 差异巨大，`.call()` 变 `.prompt().user().call().content()`。学生百度到就是踩坑，教师明确说明"看老代码请直接跳过"。

（2）五个核心抽象（板书画类关系图）：

```
Prompt ─┬─ List<Message>
        │     ├─ SystemMessage   (系统设定，如"你是养老院健康顾问")
        │     ├─ UserMessage     (用户输入)
        │     └─ AssistantMessage(模型历史回复，供多轮上下文)
        └─ ChatOptions          (温度、模型名等参数)

ChatModel  <-- 低阶  一次一发 一次一收
ChatClient <-- 高阶 (推荐)  流式 DSL：prompt().user(...).call().content()
ChatResponse <- 返回值，含 List<Generation>
```

对比表：

| 抽象 | 作用 | 一句话解释 |
|------|------|----------|
| ChatModel | 与模型直接对话 | 底层"电话机" |
| ChatClient | 高层 API | 官方推荐"客服中心" |
| Prompt | 请求整体 | 一封信 |
| Message | 单条消息 | 信里的段落 |
| ChatResponse | 响应对象 | 回信 |

（3）Message 的三兄弟：

- SystemMessage：设定 AI 人设，如"你是一位温柔耐心的养老院健康顾问"。会话开头设定一次即可，权重最高。
- UserMessage：用户当前问的话。
- AssistantMessage：模型上一轮的回答，用于多轮对话时把历史塞回去。今天先不涉及多轮，只做单轮 System + User。

（4）依赖坐标（重点）：

阿里官方提供的 starter：

```xml
<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>org.springframework.ai</groupId>
      <artifactId>spring-ai-bom</artifactId>
      <version>1.0.0-M6</version>
      <type>pom</type>
      <scope>import</scope>
    </dependency>
  </dependencies>
</dependencyManagement>

<dependencies>
  <dependency>
    <groupId>com.alibaba.cloud.ai</groupId>
    <artifactId>spring-ai-alibaba-starter</artifactId>
    <version>1.0.0-M6.1</version>
  </dependency>
</dependencies>
```

提示：因为 Spring AI 目前托管在 spring-milestones 仓库，学生的 `settings.xml` 或 `pom.xml` 需要额外配置：

```xml
<repositories>
  <repository>
    <id>spring-milestones</id>
    <url>https://repo.spring.io/milestone</url>
    <releases><enabled>false</enabled></releases>
    <snapshots><enabled>false</enabled></snapshots>
  </repository>
</repositories>
```

#### 3. 演示（10 分钟）
教师在 IDEA 中打开 Day04 的 `smart-elder-server` 后端项目，直接在 pom.xml 里添加依赖，然后：
1. 展示右下角 Maven 面板刷新，看到"下载 spring-ai-core-1.0.0-M6.jar"；
2. 打开 External Libraries，展开 spring-ai-core，展示 `ChatClient`、`Prompt`、`ChatResponse` 的类文件；
3. 用 IDE 的 `Ctrl + N` 搜索 `ChatClient`，读一读官方注释里的"Fluent API for building prompts and receiving responses"。

#### 4. 实操（8 分钟）
学生任务：
1. 在自己的 `smart-elder-server/pom.xml` 中加入 spring-milestones 仓库和上面两个依赖；
2. 刷新 Maven，等待下载完成（可能需 1-2 分钟）；
3. 在 IDEA 中用 `Ctrl + N` 打开 `ChatClient` 类，截图并标注它属于哪个包（`org.springframework.ai.chat.client`）。

#### 5. 小结（3 分钟）
今天认识了 Spring AI 的骨架，五个抽象记住"Prompt 装 Message，ChatClient 发 Prompt，ChatResponse 回内容"。下一节课我们真枪实弹发一封信到通义千问。

### 四、课上提问
1. Spring AI 与 Spring Data 在设计目标上有什么共同点？
2. SystemMessage 与 UserMessage 各自适合放什么内容？
3. 为什么建议用 ChatClient 而不是直接用 ChatModel？

### 五、课堂练习
1. 完成 pom 依赖引入并成功刷新 Maven。
2. 在项目 README 中写下"Spring AI 五个核心抽象"的一段话解释（80 字左右）。

### 六、课后思考
Spring AI 让你换一家模型（例如从通义千问换到 DeepSeek）只需要改 starter，思考一下这种"面向接口编程"的抽象设计在 Spring 家族里还见过哪些例子？（提示：JdbcTemplate、JmsTemplate、Spring Data）

### 七、课后作业
1. 阅读 Spring AI 官方文档 "Concepts" 章节，做 200 字读书笔记；
2. 把今天板书的类关系图用手绘或 draw.io 重画一遍。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-2  Spring AI 快速入门               │
├────────────────────────────────────────────┤
│ 版本：1.0.0-M6（M = Milestone，锁死）      │
│ 五抽象：Prompt / Message / ChatModel       │
│         ChatClient / ChatResponse          │
│ Message：System / User / Assistant         │
│ 依赖：spring-ai-alibaba-starter 1.0.0-M6.1 │
│ 仓库：https://repo.spring.io/milestone     │
└────────────────────────────────────────────┘
```

---

## 第 3 课时：集成通义千问 ChatModel 首次调用

### 一、教学目标
- 知识目标：掌握 `application.yml` 中通义千问的配置项（api-key、model、options）；理解 `@Configuration` + `@Bean` 手动装配 `ChatClient` 的写法及其好处；能够阅读 `ChatResponse` 结构并从中取出模型回复的正文。
- 能力目标：独立完成 `AiConfig` 与 `AiController` 两个类的编写，暴露一个 `GET /api/ai/chat?msg=xxx` 接口，用 Postman/Apifox 打通"输入 → 通义千问 → 返回"完整链路。

### 二、教学重难点
- 重点：`application.yml` 配置示例；`ChatClient.Builder` 的用法；`AiController` 的接口设计。
- 难点：环境变量 `${DASHSCOPE_API_KEY}` 与 IDE 运行配置的绑定；模型名不能写错（`qwen-plus` 而非 `qwen_plus`）；网络异常时的错误消息识别（401、429、超时）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们只是把 jar 包放进项目，今天真正让它开口说话。目标：五分钟后，我们的 Java 后端能直接向通义千问打招呼并把回复打印到 Postman。"

#### 2. 讲授（15 分钟）

（1）application.yml 配置：

```yaml
spring:
  application:
    name: smart-elder-server
  ai:
    dashscope:
      api-key: ${DASHSCOPE_API_KEY}
      chat:
        options:
          model: qwen-plus
          temperature: 0.7
          max-tokens: 1024
```

字段解释：
- `api-key`：从环境变量注入，避免明文入 Git；
- `model`：通义千问家族有 qwen-turbo（便宜快）/qwen-plus（平衡）/qwen-max（贵强），本项目用 plus；
- `temperature`：随机性，0-1，值越高越"发散"，健康咨询建议 0.7 兼顾专业与自然；
- `max-tokens`：单次回复最大 token 数，1024 大约 500-800 字，够用。

（2）配置类 AiConfig：

Spring AI 已经自动注入了 `ChatClient.Builder`，我们只需要从它构造出一个 `ChatClient` 单例注入即可：

```java
package com.itcast.smart_elder.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AiConfig {

    /**
     * 全局唯一的 ChatClient，注入到所有需要调用 AI 的地方。
     * 这里预置一个"养老健康顾问"的 System Prompt，作为项目默认人设。
     */
    @Bean
    public ChatClient chatClient(ChatClient.Builder builder) {
        return builder
                .defaultSystem("""
                        你是"金秋家园"智能养老社区的健康顾问，名字叫"小金"。
                        你的回答风格必须：温柔耐心、专业可靠、简短易懂（每次不超过 200 字）。
                        遇到医疗急救类问题必须先建议拨打 120，再给出建议。
                        禁止给出药品处方剂量，只做生活方式与饮食建议。
                        """)
                .build();
    }
}
```

（3）控制器 AiController：

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiController {

    private final ChatClient chatClient;

    /**
     * 同步对话接口：一次请求，一次返回完整答案。
     * 适合短消息、命令行调试。
     */
    @GetMapping("/chat")
    public Result<String> chat(@RequestParam("msg") String msg) {
        String content = chatClient
                .prompt()
                .user(msg)
                .call()
                .content();
        return Result.success(content);
    }
}
```

强调三点：
- `.prompt().user(msg).call().content()` 是 Spring AI 的流式 DSL 写法；
- `Result.success(content)` 复用 Day02 定义的统一响应；
- 没写 SystemMessage 是因为 AiConfig 里 `defaultSystem` 已经全局注入。

#### 3. 演示（12 分钟）
教师现场：
1. 编写 AiConfig、AiController；
2. 检查 IDEA 运行配置 Environment variables 中已加入 `DASHSCOPE_API_KEY=sk-xxx`；
3. 启动服务，观察 Console 中 `Started SmartElderApplication in 4.2 seconds`；
4. 打开 Apifox，新建 GET 请求 `http://localhost:8080/api/ai/chat?msg=爷爷早上起床血压有点高，早餐吃什么好？`；
5. 发送，等待 3-5 秒，屏幕上返回："爷爷您好，早上血压偏高时建议早餐选择清淡易消化的食物，比如燕麦粥、蒸蛋、少量全麦面包，搭配一杯温热牛奶或豆浆……"
6. 教师故意把 model 改成 `qwen-pluss`（多个 s）演示报错，让学生认识 400 错误消息。

#### 4. 实操（12 分钟）
学生任务：
1. 完成 AiConfig 与 AiController 的编写；
2. 启动服务，用 Apifox 请求接口；
3. 换 5 个不同的养老场景问题（如"腰疼""失眠""便秘""降糖饮食""夜间起夜频繁"），把 5 组问答截图保存；
4. 尝试故意把 api-key 写错一位，观察 401 错误消息，感受错误链路。

教师巡视重点：
- 环境变量没设 → 报 "DashScope api-key must be provided" → 让学生 IDEA 里配 Environment variables 或 dotenv；
- 依赖没下载完就启动 → NoClassDefFoundError → 让学生等 Maven；
- 请求超时 → 90% 是内网出口封了 → 让学生切个人手机热点尝试。

#### 5. 小结（3 分钟）
今天完成了"AI Hello World"，同步接口跑通。下一节课解决一个用户体验痛点：等待 5 秒才出结果太慢，我们要让它像 ChatGPT 一样逐字往外蹦。

### 四、课上提问
1. 为什么 API-Key 要写 `${DASHSCOPE_API_KEY}` 而不是直接明文？
2. `chatClient.prompt().user(msg).call().content()` 每一步分别代表什么？
3. `defaultSystem` 与在 controller 里手动传 SystemMessage 有什么区别？

### 五、课堂练习
1. 尝试把 `defaultSystem` 从"健康顾问"改成"养老院活动策划师"，重新请求同一个问题，对比风格差异。
2. 给 AiController 加一个 POST 版本 `POST /api/ai/chat`，body 传 `{"msg":"xxx"}`。

### 六、课后思考
现在的接口每次都要等 3-5 秒才有回复，用户体验较差。为什么会这么慢？如果不改后端只改前端，能不能让页面显得"没那么慢"？（引出下一节流式的价值）

### 七、课后作业
1. 完善 AiController，把 5 组养老场景问答测试结果保存到 `docs/ai/day05-chat-samples.md`；
2. 阅读通义千问官网 `qwen-turbo/plus/max` 三个模型的定价页，用一段话回答"如果项目日活 1000 人，人均问 10 句，选哪个模型月成本最低"。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-3  首次调用通义千问                 │
├────────────────────────────────────────────┤
│ yml 配置：api-key / model / temperature    │
│ AiConfig：@Bean ChatClient (defaultSystem) │
│ AiController：GET /api/ai/chat?msg=        │
│ DSL：prompt().user().call().content()      │
│ 坑：环境变量、模型名、401/429              │
└────────────────────────────────────────────┘
```

---

## 第 4 课时：流式响应 SSE 实战

### 一、教学目标
- 知识目标：理解同步 HTTP 与流式 SSE（Server-Sent Events）的区别；掌握 `ChatClient.prompt().stream().content()` 返回 `Flux<String>` 的用法；能够正确配置 `produces = MediaType.TEXT_EVENT_STREAM_VALUE`；理解浏览器端 `fetch + ReadableStream` 与 `EventSource` 两种消费方式的取舍。
- 能力目标：独立在 `AiController` 中增加流式接口 `GET /api/ai/chat/stream`，并在 Apifox 或浏览器地址栏中观察逐字返回效果。

### 二、教学重难点
- 重点：`Flux<String>` 的返回类型；`text/event-stream` MIME 类型；换行/空格丢失问题（SSE 协议本身会吞掉换行，需要自定义 data 前缀）。
- 难点：为什么必须用 `Flux` 而不是 `Iterator`（响应式编程与背压概念）；跨域场景下 SSE 需要 CORS + `text/event-stream` 双重配置；测试工具选择（Postman 部分版本不支持 SSE，推荐 Apifox 或直接浏览器）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"打开 ChatGPT 或者豆包，你会发现回答是一个字一个字往外蹦。这不是特效，而是网络层就是这样传的。我们的同步接口要等模型全生成完才一次性返回，用户干等 5 秒。今天把它改成流式，用户 200ms 就看到第一个字。"

#### 2. 讲授（18 分钟）

（1）同步 vs 流式对比：

| 维度 | 同步 (call) | 流式 (stream) |
|------|-------------|--------------|
| HTTP 头 | Content-Type: application/json | Content-Type: text/event-stream |
| 连接生命 | 3-5s 短连接 | 长连接直到模型输出完 |
| 首字节 | 5s | 200ms |
| 返回类型 | String | Flux&lt;String&gt; |
| 前端消费 | axios.get | fetch + ReadableStream / EventSource |
| 用户感受 | 一次到位 | 逐字蹦，像打字机 |

（2）SSE 协议简介：

SSE（Server-Sent Events）是 HTML5 标准的服务端推送协议，本质是一个 `Content-Type: text/event-stream` 的 HTTP 长响应，每条消息以 `data: xxx\n\n` 格式发送。它是**单向**的（服务端 → 浏览器），比 WebSocket 更轻量，浏览器原生支持自动重连。

（3）流式接口代码：

```java
import org.springframework.http.MediaType;
import reactor.core.publisher.Flux;

/**
 * 流式对话接口：逐字返回，前端可实时渲染。
 * produces 必须是 text/event-stream，Spring MVC 会自动切换到响应式。
 */
@GetMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<String> chatStream(@RequestParam("msg") String msg) {
    return chatClient
            .prompt()
            .user(msg)
            .stream()
            .content();
}
```

**关键点：**
- 返回类型必须是 `Flux<String>`（Reactor 库的响应式流）；
- `produces` 必须写 `text/event-stream`，浏览器才会按 SSE 解析；
- 不要包 `Result`——SSE 每一条 data 应该是纯文本，包装反而丢失流式意义。

（4）换行处理坑：

SSE 协议规定 `\n\n` 是消息分隔符，所以当模型返回内容里本身有 `\n` 时，SSE 帧就会被截断成两条消息。解决方案：前端接收后自己拼串再渲染即可，Spring AI 底层已经处理了大部分兼容问题。

（5）跨域配置（如后端在 8080、前端在 5173）：

```java
// 全局 CORS，Day02 已配置过；这里再确认允许 text/event-stream
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOriginPatterns("*")
                .allowedMethods("*")
                .allowedHeaders("*")
                .allowCredentials(true);
    }
}
```

#### 3. 演示（10 分钟）
教师现场：
1. 在 AiController 中新增 `chatStream` 方法；
2. 重启服务；
3. 浏览器地址栏直接输入 `http://localhost:8080/api/ai/chat/stream?msg=请写一首关于夕阳晚霞的现代诗`；
4. 学生看到浏览器"逐字蹦字"效果；
5. 打开 Chrome DevTools → Network，找到该请求，看到 Type 是 `eventsource`，"响应"栏在实时增长；
6. 再用 Apifox 请求相同 URL，观察 Apifox 的 SSE 分屏显示。

#### 4. 实操（11 分钟）
学生任务：
1. 完成 `chatStream` 接口；
2. 用浏览器和 Apifox 两种方式各请求一次；
3. 尝试给同一个问题问三次流式，观察每次内容都略有不同（temperature=0.7 的效果）；
4. 用 Chrome DevTools 观察 Network 面板，把"逐字流"截图。

教师巡视，重点排查：
- 忘写 `produces` → 浏览器一次性等完才显示；
- 用 Postman 老版本测试 → 界面卡住，建议换 Apifox；
- CORS 报错 → 检查 Day02 WebMvcConfig 是否加了 `/api/**`。

#### 5. 小结（3 分钟）
今天让 AI 学会"打字机"式输出，用户体验提升一个数量级。下节课我们讨论怎么让 AI "更专业"——通过 Prompt 工程给它套上养老院健康顾问的人设。

### 四、课上提问
1. 同步接口和流式接口在 HTTP 层最本质的差异是什么？
2. `Flux<String>` 里的 String 是完整答案还是单个字/词？
3. 为什么流式接口不建议包 `Result<T>`？

### 五、课堂练习
1. 分别用 qwen-turbo 和 qwen-plus 请求流式接口，感受"打字速度"的差异。
2. 用 Chrome DevTools 测量首字节时间（TTFB），对比同步与流式。

### 六、课后思考
如果要在前端做一个"停止生成"按钮，应该怎么实现？（提示：AbortController.abort()）

### 七、课后作业
1. 完善 chatStream 接口测试记录；
2. 阅读 Reactor 官方文档 `Flux` 章节前 3 节，做 100 字读书笔记。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-4  流式 SSE 实战                    │
├────────────────────────────────────────────┤
│ 同步 = 等完再给 | 流式 = 一字一给          │
│ produces = text/event-stream               │
│ 返回 Flux<String>（Reactor 响应式）        │
│ .stream().content()                        │
│ 消费：fetch+ReadableStream / EventSource   │
│ 坑：忘 produces、老 Postman、跨域          │
└────────────────────────────────────────────┘
```

---

## 第 5 课时：Prompt 工程与角色扮演

### 一、教学目标
- 知识目标：理解 Prompt Engineering 的定位（"用自然语言写程序"）；掌握 SystemMessage 与 UserMessage 的分工——"System 定人设，User 提问题"；能够用 `PromptTemplate` 完成变量替换；理解 Few-Shot（少样本示例）技巧对回答质量的巨大提升。
- 能力目标：为养老院健康顾问角色写出一个 5 段式高质量 System Prompt，让 AI 稳定输出"温柔、专业、安全"的养老风格回答，并用 `PromptTemplate` 支持"给指定老人（含姓名、年龄、慢病史）个性化回复"。

### 二、教学重难点
- 重点：System/User 分工；PromptTemplate 变量替换；Few-Shot 示例的组织格式。
- 难点：Prompt 需要反复调、反复测；很多学生第一次写出的 Prompt 太笼统或太长；养老场景下"安全边界"（不能开药、不能替代医生）必须写死在 System 里。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"我们已经能让 AI 说话了，但它现在的回答其实还是通用聊天口吻，跟豆包差不多。老人问'心口发闷'，AI 有可能顺嘴说'去便利店买速效救心丸'，这是重大医疗风险。今天要给它戴上'紧箍咒'——用 Prompt 工程锁住风格和安全边界。"

#### 2. 讲授（18 分钟）

（1）Prompt Engineering 是什么？

不是"魔法咒语"，就是"用清晰的自然语言把需求描述清楚"。差的 Prompt："帮我回答老人问题"，好的 Prompt："你是……你要……你不能……如果用户问 X 请这样答，如果问 Y 请那样答。"

（2）5 段式 System Prompt 模板：

```
1. 角色定位：你是谁
2. 服务对象：面向谁
3. 回答风格：温柔/严谨/简短/……
4. 安全边界：不能做什么
5. 回答格式：分点/短句/带 emoji/……
```

我们的养老健康顾问 System Prompt 示例：

```
你是"金秋家园"智能养老社区的健康顾问，名字叫"小金"。
【服务对象】60 岁以上老年人及其家属，可能存在高血压、糖尿病、骨质疏松等慢性病。
【回答风格】温柔、耐心、专业、简短易懂，避免使用"神经元、代谢通路"等术语；每次回答不超过 200 字。
【安全边界】
- 任何医疗急救症状（胸痛、呼吸困难、剧烈头痛、意识模糊）必须首先建议拨打 120；
- 禁止提供药品名称、剂量、处方；
- 涉及疾病诊断，只能建议就医，不做诊断。
【回答格式】
- 先安抚一句情绪；
- 再给 2-3 条具体建议（用短语/短句，不写序号数字）；
- 最后一句关怀收尾（如"祝您和家人健康平安。"）。
```

（3）PromptTemplate 使用示例：

Spring AI 提供 `PromptTemplate`，支持 `{变量名}` 占位替换，非常适合"个性化健康建议"这种带参场景。

```java
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.chat.messages.Message;
import java.util.Map;

// 模板：为指定老人生成饮食建议
String tpl = """
        请为以下老人生成今日午餐建议：
        姓名：{name}
        年龄：{age}
        慢病史：{disease}
        用户当前提问：{question}
        请按 5 段式格式输出。
        """;

PromptTemplate template = new PromptTemplate(tpl);
Message userMsg = template.createMessage(Map.of(
        "name", "张桂芳",
        "age", "72",
        "disease", "高血压、轻度糖尿病",
        "question", "中午想吃点面食可以吗？"
));
```

（4）Few-Shot（少样本）技巧：

在 System Prompt 里附 2-3 个"标准答案示例"，AI 会显著模仿风格。示例：

```
【示例对话】
用户："我最近晚上老是睡不着。"
小金："您辛苦了，睡眠问题很多老人家都遇到过。
        - 睡前 1 小时避免看手机和电视，可以听舒缓音乐；
        - 晚饭七八分饱，睡前少喝水；
        - 白天多晒太阳、适量散步。
        如果持续两周以上，建议去医院神经内科看看。祝您睡个好觉。"
```

（5）代码整合到 AiController（新增带参接口）：

```java
import org.springframework.ai.chat.prompt.PromptTemplate;
import java.util.Map;

@PostMapping("/chat/health")
public Result<String> chatHealth(@RequestBody HealthChatDTO dto) {
    String tpl = """
            请为以下老人回答问题：
            姓名：{name}
            年龄：{age}
            慢病史：{disease}
            用户提问：{question}
            """;
    PromptTemplate template = new PromptTemplate(tpl);
    String userContent = template.render(Map.of(
            "name", dto.getName(),
            "age", String.valueOf(dto.getAge()),
            "disease", dto.getDisease(),
            "question", dto.getQuestion()
    ));

    String answer = chatClient
            .prompt()
            .user(userContent)
            .call()
            .content();
    return Result.success(answer);
}
```

DTO：

```java
@Data
public class HealthChatDTO {
    private String name;
    private Integer age;
    private String disease;
    private String question;
}
```

#### 3. 演示（10 分钟）
教师现场：
1. 更新 `AiConfig.defaultSystem` 为 5 段式版本 + Few-Shot；
2. 编写 `chatHealth` 接口；
3. 重启服务；
4. 用 Apifox POST `/api/ai/chat/health`，body：
```json
{"name":"张桂芳","age":72,"disease":"高血压、轻度糖尿病","question":"胸口有点闷"}
```
观察 AI 首先建议拨打 120，然后给出 3 条具体建议；
5. 把 System Prompt 里的"安全边界"整段删掉，重新请求，观察 AI 变得随意开药——学生亲眼看到"约束的力量"。

#### 4. 实操（11 分钟）
学生任务：
1. 更新 AiConfig 到 5 段式版本；
2. 完成 `chatHealth` 接口；
3. 用 3 个虚拟老人档案分别测试同一个问题（如"腿脚酸"），观察 AI 是否会因年龄、病史不同给出针对性回答；
4. 尝试关掉安全边界重复测试，感受差异。

#### 5. 小结（3 分钟）
今天让 AI 有了"人设、边界、风格"。下节课我们做前端聊天页面，把这些接口整合成一个像 ChatGPT 一样的对话框。

### 四、课上提问
1. System Prompt 的 5 段式分别是什么？
2. 为什么"安全边界"必须写在 System 而不是 User 里？
3. PromptTemplate 与直接字符串拼接相比，好处是什么？

### 五、课堂练习
1. 为"活动策划师"角色写一个 5 段式 System Prompt。
2. 用 PromptTemplate 写一个"生日祝福生成器"，占位变量 `{name} {age} {hobby}`。

### 六、课后思考
如果我们想让 AI 拒绝回答"政治""宗教""投资理财"类话题，应该在 Prompt 的哪一段增加？如何测试它是否真的拒绝了？

### 七、课后作业
1. 优化 `AiConfig.defaultSystem`，加上你自己认为重要的 Few-Shot 示例；
2. 收集 5 个养老场景常见问题（如失眠、便秘、跌倒预防、饮食搭配、情绪低落），逐一测试并记录 AI 表现。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-5  Prompt 工程与角色扮演            │
├────────────────────────────────────────────┤
│ System 定人设 | User 提问题                │
│ 5 段式：角色/对象/风格/边界/格式           │
│ PromptTemplate {变量} 替换                 │
│ Few-Shot：给 2-3 个样例                    │
│ 安全底线：不开药、遇急救先 120             │
└────────────────────────────────────────────┘
```

---

## 第 6 课时：智能应答前端页面（对话框）

### 一、教学目标
- 知识目标：掌握 Vue3 `<script setup>` 组合式 API 下的聊天页面结构；能够用 `fetch` + `ReadableStream` 消费 SSE 流并逐字渲染；理解气泡式对话 UI 的基本布局（用户消息右对齐、AI 消息左对齐）；掌握 `history` 数组的响应式管理。
- 能力目标：独立完成 `views/ai/chat.vue`、`api/ai.ts` 与路由配置，实现一个可用的"小金"聊天页面，能同时支持同步与流式两种模式（默认流式），并在流式模式下逐字渲染。

### 二、教学重难点
- 重点：`fetch + ReadableStream` 读取 SSE；`ref` + `history[]` 管理消息列表；`nextTick + scrollIntoView` 自动滚动到底部。
- 难点：SSE 数据包切分（可能一次 read 收到多条 data:）；中文乱码（必须 `TextDecoder('utf-8')`）；输入回车换行 vs Enter 发送的取舍。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"最后一步，把 AI 端到端搬到用户面前。我们要做一个像 ChatGPT 那样的对话页面——气泡、滚动、逐字。做完，就可以把链接发给你的爷爷奶奶用了。"

#### 2. 讲授（15 分钟）

（1）页面结构（HTML/模板层面）：

```
+---------------------------------------+
|  🤖 智能健康顾问 - 小金                |
+---------------------------------------+
|                                       |
|  [AI气泡] 您好，我是小金……              |
|                                       |
|                      [用户气泡] 你好 → |
|                                       |
|  [AI气泡] 很高兴认识您……                |
|                                       |
+---------------------------------------+
|  输入框                        [发送] |
+---------------------------------------+
```

用两个数组：`history: {role, content}[]`；每次发送后 push 一条 user，再 push 一条空的 assistant，然后在流式回调里持续 append content 到最后一条 assistant.content。

（2）api/ai.ts（同步接口封装）：

```typescript
// src/api/ai.ts
import request from '@/utils/request';

/** 同步对话 */
export function aiChat(msg: string) {
  return request.get<string>('/api/ai/chat', { params: { msg } });
}

/** 流式对话的 URL，前端直接用 fetch 消费 SSE */
export function aiStreamUrl(msg: string) {
  return `/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`;
}
```

（3）核心的流式消费函数（重点讲解）：

```typescript
async function streamChat(msg: string, onChunk: (chunk: string) => void) {
  const resp = await fetch(aiStreamUrl(msg));
  if (!resp.ok || !resp.body) throw new Error('SSE 建立失败');
  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    const text = decoder.decode(value, { stream: true });
    // SSE 数据格式：data:内容\n\n
    text.split(/\r?\n/).forEach(line => {
      if (line.startsWith('data:')) {
        const chunk = line.slice(5);
        if (chunk) onChunk(chunk);
      }
    });
  }
}
```

强调：
- 必须用 `TextDecoder('utf-8', { stream: true })` 才能正确拼中文；
- SSE 每条消息以 `\n\n` 分隔，逐行解析；
- 一定要处理 `done` 结束条件。

#### 3. 演示（12 分钟）
教师现场编写完整 `views/ai/chat.vue`，加路由，启动 dev server，效果：
1. 页面左上角"🤖 小金"标题；
2. 输入"我最近失眠"，回车发送；
3. AI 气泡逐字蹦出安抚 + 建议；
4. 连续问 3-4 轮，页面自动滚动到底部；
5. 打开 DevTools Network 观察 SSE 请求，看数据实时流入。

演示代码完整版：

```vue
<!-- src/views/ai/chat.vue -->
<template>
  <div class="chat-container">
    <div class="chat-header">🤖 智能健康顾问 · 小金</div>

    <div class="chat-body" ref="bodyRef">
      <div
        v-for="(m, i) in history"
        :key="i"
        :class="['bubble-row', m.role]"
      >
        <div class="avatar">{{ m.role === 'user' ? '👴' : '🤖' }}</div>
        <div class="bubble">{{ m.content || '思考中…' }}</div>
      </div>
    </div>

    <div class="chat-input">
      <el-input
        v-model="input"
        placeholder="请输入您的问题，回车发送"
        :disabled="loading"
        @keyup.enter="onSend"
      />
      <el-button type="primary" :loading="loading" @click="onSend">
        发送
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, nextTick } from 'vue';
import { ElInput, ElButton, ElMessage } from 'element-plus';

interface Msg { role: 'user' | 'assistant'; content: string }

const history = ref<Msg[]>([
  { role: 'assistant', content: '您好，我是小金，很高兴为您服务。请问有什么可以帮您的？' }
]);
const input = ref('');
const loading = ref(false);
const bodyRef = ref<HTMLElement | null>(null);

function scrollBottom() {
  nextTick(() => {
    if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight;
  });
}

async function streamChat(msg: string, onChunk: (chunk: string) => void) {
  const resp = await fetch(`/api/ai/chat/stream?msg=${encodeURIComponent(msg)}`);
  if (!resp.ok || !resp.body) throw new Error('连接失败');
  const reader = resp.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    // 按 SSE 分隔符切割
    const parts = buffer.split(/\r?\n/);
    buffer = parts.pop() || '';
    for (const line of parts) {
      if (line.startsWith('data:')) {
        const chunk = line.slice(5);
        if (chunk) onChunk(chunk);
      }
    }
  }
}

async function onSend() {
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  history.value.push({ role: 'user', content: text });
  history.value.push({ role: 'assistant', content: '' });
  scrollBottom();
  loading.value = true;
  try {
    await streamChat(text, chunk => {
      const last = history.value[history.value.length - 1];
      last.content += chunk;
      scrollBottom();
    });
  } catch (e) {
    ElMessage.error('AI 服务暂时不可用，请稍后重试');
    const last = history.value[history.value.length - 1];
    if (!last.content) last.content = '（回复失败）';
  } finally {
    loading.value = false;
  }
}
</script>

<style scoped>
.chat-container {
  height: calc(100vh - 100px);
  display: flex;
  flex-direction: column;
  background: #f5f7fa;
  border-radius: 12px;
  overflow: hidden;
}
.chat-header {
  padding: 12px 20px;
  background: #409eff;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
}
.chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}
.bubble-row {
  display: flex;
  margin-bottom: 16px;
  align-items: flex-start;
}
.bubble-row.user {
  flex-direction: row-reverse;
}
.avatar {
  width: 36px;
  height: 36px;
  font-size: 24px;
  text-align: center;
  line-height: 36px;
  background: #fff;
  border-radius: 50%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  margin: 0 8px;
}
.bubble {
  max-width: 70%;
  padding: 10px 14px;
  background: #fff;
  border-radius: 8px;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
}
.bubble-row.user .bubble {
  background: #95ec69;
}
.chat-input {
  display: flex;
  padding: 12px;
  gap: 8px;
  background: #fff;
  border-top: 1px solid #e5e6eb;
}
</style>
```

路由配置（`src/router/index.ts`）：
```typescript
{
  path: '/ai/chat',
  name: 'AiChat',
  component: () => import('@/views/ai/chat.vue'),
  meta: { title: '智能健康顾问' }
}
```

#### 4. 实操（12 分钟）
学生任务：
1. 新建 `src/api/ai.ts`；
2. 新建 `src/views/ai/chat.vue`，粘贴/照抄代码；
3. 更新 router；
4. 启动前端 `pnpm dev`，访问 `http://localhost:5173/ai/chat`；
5. 至少测试 5 轮对话，截图保存；
6. 尝试给页面加一个"清空聊天"按钮（自选加分项）。

教师巡视重点：
- 中文乱码 → 忘 `TextDecoder('utf-8')` 或 stream=false；
- 消息数组没响应式 → 忘 `ref()`；
- 自动滚动失效 → 忘 `nextTick`。

#### 5. 小结（3 分钟）
今天完成了 Day05 全部内容：从大模型基础到百炼平台，从 Spring AI 依赖到 ChatClient 首次调用，从流式接口到 Prompt 工程，最后到前端对话页面。整个 AI 链路首次跑通！

明天进入 Day06——把 AI 能力接入客房预约业务，让老人可以说一句"我下周想订一间朝南的双人间"，AI 自动帮他下单。

### 四、课上提问
1. 为什么 `fetch` 读到的中文有可能乱码？怎么解决？
2. `history` 数组为什么必须用 `ref`？如果只用普通数组会怎样？
3. 流式模式下，用户消息和 AI 消息分别在什么时刻 push 到 history？

### 五、课堂练习
1. 给 chat.vue 加一个"清空聊天"按钮，点击后 history 恢复到初始欢迎语。
2. 尝试在气泡下方增加时间戳显示（用 `dayjs`）。

### 六、课后思考
现在如果用户连续问三个问题，AI 每次都"失忆"（因为没传历史消息）。这个多轮对话记忆问题，我们计划用什么方案解决？（提示：Day06 Redis + 消息数组）

### 七、课后作业
1. 完成 chat.vue，并把最终效果录一段 30 秒视频提交；
2. 优化气泡样式（可自选主题色）；
3. 收集你自己家里长辈可能会问的 3 个健康问题，测试并把结果贴到讲义附录。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day05-6  智能应答前端页面                 │
├────────────────────────────────────────────┤
│ views/ai/chat.vue                          │
│ history: [{role, content}]                 │
│ fetch + ReadableStream + TextDecoder       │
│ SSE 逐行解析 data:                         │
│ 气泡：user 右 + assistant 左               │
│ 自动滚动：nextTick + scrollTop             │
└────────────────────────────────────────────┘
```

---

## Day05 总结与预告

**今日全景：**
```
大模型基础 → Spring AI 抽象 → 通义千问首次调用
     ↓
流式 SSE 逐字返回 → Prompt 工程 5 段式 → 前端气泡对话
     ↓
完整可运行的 AI 智能健康顾问 · 小金
```

**关键产出：**
- 后端：`AiConfig`、`AiController`（同步 + 流式 + 带参三个接口）、`application.yml` AI 配置段；
- 前端：`api/ai.ts`、`views/ai/chat.vue`、路由；
- 文档：`docs/ai/day05-chat-samples.md`（问答记录）、`docs/ai/system-prompt.md`（人设定义）。

**Day06 预告：** 将今天的对话能力融合到客房预约业务，学生学会 Redis + 分布式锁 + AI 意图识别，让 AI 真正"办事"，不再只是"聊天"。
