# 《智能养老社区系统》- 教师教案 - Day02：前后端分离项目搭建与 Vue3 模板生成

**授课日：Day 02 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 3（使用前后端分离技术搭建项目 · 0.5 天）+ 技术点 4（基于阿里 AI 通义灵码生成 Vue 3 前端项目模板 · 0.5 天）**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**后端包名：com.itcast.smart_elder**
**前端项目名：smart-elder-web**
**前置知识：** Day01 已完成需求分析、数据库设计、7 张建表脚本导入 MySQL（elder_member / elder_room / elder_room_type / elder_booking / elder_operation_log / elder_health_record / elder_dict）

---

## 第 1 课时：前后端分离架构与项目结构

### 一、教学目标
- 知识目标：理解前后端分离的产生背景、职责边界；掌握 RESTful 接口规范；说清楚后端 controller/service/mapper/entity/dto/vo 各层的作用；掌握 Maven 单模块项目的标准目录结构。
- 能力目标：能够独立说出智能养老社区系统中一个"会员分页查询"请求从浏览器出发到数据库再回到浏览器的完整链路，并画出前后端分离架构图。

### 二、教学重难点
- 重点：分层架构中各层的输入输出参数类型（DTO 入参、VO/Result 出参）、RESTful 五种常用 HTTP 方法与 URL 命名。
- 难点：为什么把 entity 和 vo 拆开？什么时候用 DTO？前后端跨域是怎么产生的？

### 三、教学过程（45 分钟）

#### 1. 导入（3-5 分钟）
向学生抛出一个真实场景问题："同学们，昨天我们已经把 7 张表建到 MySQL 里了。今天我打开浏览器，输入 http://localhost:5173/member，就想看到一个漂亮的会员分页列表页面。你们能不能告诉老师，这中间需要几个进程在跑？页面上的数据是从哪里蹦出来的？"引导学生说出：至少要一个前端开发服务器、一个后端 Java 进程、一个 MySQL 进程。然后引出：这三个进程之间是怎么"对话"的？答案就是——前后端分离 + RESTful 接口。

#### 2. 讲授（18 分钟）

**（1）传统 JSP 模式 vs 前后端分离模式**

传统 JSP 模式：浏览器请求 `.jsp` 文件，Tomcat 里 JSP 引擎渲染 HTML，直接把成品页面返回给浏览器。开发时前端工程师必须懂后端，因为 JSP 里有 `<%= %>` 表达式、`<c:if>` 标签，前后端代码耦合在同一个文件里。

前后端分离模式：前端使用 Vue3 + Vite 构建纯静态资源（HTML/CSS/JS），部署在 Nginx；后端只提供 JSON 数据接口，部署为独立的 Spring Boot 进程。前端通过 HTTP + JSON 与后端通信。

| 对比项 | 传统 JSP | 前后端分离 |
|--------|----------|------------|
| 页面渲染 | 服务端渲染（SSR） | 浏览器端渲染（CSR） |
| 部署 | 一个 war 包 | 前端 Nginx + 后端 jar |
| 分工 | 前后端耦合 | 前后端解耦、并行开发 |
| 交互协议 | 表单/HTML | HTTP + JSON |
| 学习成本 | JSP + JSTL + EL | Vue3 + axios + RESTful |
| 移动端复用 | 不方便 | 后端接口 App / 小程序共用 |

**（2）RESTful 规范**

REST（Representational State Transfer）核心思想：把每一个后端资源看作 URL 上的一个名词，用 HTTP 方法（动词）表达对该资源的操作。

| HTTP 方法 | 语义 | 智能养老社区示例 URL |
|----------|------|----------------------|
| GET | 查询 | `GET /api/member/page?pageNum=1&pageSize=10` |
| POST | 新增 | `POST /api/member` |
| PUT | 修改 | `PUT /api/member` |
| DELETE | 删除 | `DELETE /api/member/{id}` |
| GET | 查询单条 | `GET /api/member/{id}` |

命名约定：URL 名词用中划线小写、复数或单数保持一致（本项目统一用单数）；查询参数用驼峰；返回体统一 `Result<T>`。

**（3）Maven 多模块 vs 单模块**

多模块：`smart-elder-parent` 下拆 `smart-elder-common / smart-elder-mapper / smart-elder-service / smart-elder-web` 等子模块，适合中大型团队。
单模块：一个 pom.xml，一个 src，通过 Java 包名做逻辑分层，适合课程与小项目。

**本项目采用单模块**，理由：学生初学，避免被 pom 依赖传递、install 顺序绕晕；后续 Day11 会讲如果扩展到多模块该怎么改。

**（4）后端分层职责**

```
┌────────────┐   接收 HTTP 请求，参数校验，调 service，包成 Result 返回
│ controller │
└─────┬──────┘
      │  入参：@RequestBody DTO / @RequestParam
      ▼
┌────────────┐   核心业务逻辑，事务边界，编排多个 mapper
│  service   │
└─────┬──────┘
      │
      ▼
┌────────────┐   只做 SQL，一个方法一句 SQL，返回 entity
│   mapper   │
└─────┬──────┘
      │
      ▼
┌────────────┐   MySQL
│   数据库    │
└────────────┘
```

- **entity**：与数据库表一一对应，字段类型和表保持一致，加 `@TableName`。
- **dto**（Data Transfer Object）：前端 → 后端，接收表单/查询参数，只包含前端需要提交的字段，如 `MemberQueryDTO`（含 `pageNum` `pageSize` `name` `phone`）。
- **vo**（View Object）：后端 → 前端，只暴露前端需要展示的字段，可能是 entity 的子集或组合（如把 `roomId` 联查成 `roomName`）。

#### 3. 演示（8-10 分钟）

打开 IDEA 演示：先看昨天的 Day01 的 SQL 文件夹，再画一张架构图放在白板上，用 IDEA 新建一个空白 project 目录 `smart-elder-server`，展示未来 6 天要长成的目录结构：

```
smart-elder-server/           后端
├── src/main/java/com/itcast/smart_elder/
│   ├── SmartElderApplication.java
│   ├── controller/     HelloController、MemberController...
│   ├── service/        MemberService、impl/MemberServiceImpl
│   ├── mapper/         MemberMapper (继承 BaseMapper)
│   ├── entity/         Member、Room、Booking...
│   ├── dto/            MemberQueryDTO、MemberSaveDTO
│   ├── vo/             MemberVO
│   ├── common/         Result、PageBean、GlobalExceptionHandler
│   └── config/         MyBatisPlusConfig、WebConfig
├── src/main/resources/
│   ├── application.yml
│   └── mapper/         Member.xml（第 3 天用）
└── pom.xml

smart-elder-web/              前端
├── src/
│   ├── api/            member.ts、hello.ts
│   ├── views/          member/、room/、login/
│   ├── router/         index.ts
│   ├── stores/         useUserStore
│   ├── utils/          request.ts
│   ├── App.vue
│   └── main.ts
├── vite.config.ts
└── package.json
```

#### 4. 实操（10 分钟）
让学生在自己电脑上：
1. 打开 D 盘，新建 `smart-elder` 空文件夹，作为整个项目的根。
2. 里面再建两个子文件夹 `smart-elder-server` 和 `smart-elder-web`（先建空目录，第 2、4 课时才会填入代码）。
3. 用 `git init` 初始化仓库，写好 `.gitignore`（忽略 `target/` `node_modules/` `.idea/` `*.iml` `dist/`）。
4. 完成后拍照或截图发教师群，教师逐个核对目录名。

#### 5. 小结（2 分钟）
今天要记住一句话："浏览器只跟 Nginx 说话，Nginx 只跟 Spring Boot 说话，Spring Boot 只跟 MySQL 说话，说话的内容都是 JSON。" 下节课开始搭建后端 Spring Boot 骨架。

### 四、课上提问
1. 前后端分离和传统 JSP 最大的区别是什么？（提示：渲染位置、部署包）
2. 为什么 controller 里不能直接把 entity 返回给前端？（安全字段泄露、字段冗余）
3. RESTful 中修改会员用哪个 HTTP 方法？URL 长什么样？

### 五、课堂练习
1. 在纸上画出前后端分离架构图，标出前端服务器（5173）、后端（8080）、MySQL（3306）三个端口以及它们之间流转的数据格式。
2. 用一句话解释 DTO、VO、Entity 的区别，并各举一个智能养老社区的例子。

### 六、课后思考
如果未来需要给会员上线一个 App 端，前后端分离架构下需要重写后端接口吗？为什么？如果新增小程序端呢？

### 七、课后作业
1. 阅读阮一峰《RESTful API 设计指南》并整理 5 条最重要的规范到笔记。
2. 为智能养老社区系统的 7 张表都设计出 CRUD 五个 RESTful URL（`/api/room` `/api/booking` 等），交到教师邮箱。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│ 第 1 课时：前后端分离架构与项目结构          │
├──────────────────────────────────────────────┤
│ 1. 传统 JSP vs 前后端分离                    │
│ 2. RESTful：名词做 URL，动词用 HTTP 方法     │
│ 3. 单模块分层：controller→service→mapper     │
│ 4. entity / dto / vo 三兄弟                  │
│ 5. 常见错误：直接返回 entity 泄露 password   │
└──────────────────────────────────────────────┘
```

---

## 第 2 课时：SpringBoot 后端骨架搭建

### 一、教学目标
- 知识目标：掌握使用 IDEA Spring Initializr 生成 Spring Boot 项目；理解 pom.xml 里 spring-boot-starter-web、mybatis-plus-boot-starter、lombok、mysql-connector-j、knife4j 五大依赖的作用；能读懂并修改 application.yml；掌握统一返回类 `Result<T>` 与分页封装 `PageBean<T>` 的写法。
- 能力目标：能够独立创建项目、加依赖、启动成功看到 8080 端口 Spring Boot 启动 Banner。

### 二、教学重难点
- 重点：pom.xml 依赖坐标；application.yml 里 server / spring.datasource / mybatis-plus 三块配置；`Result<T>` 泛型设计。
- 难点：Spring Boot 版本与 mybatis-plus-boot-starter 版本的匹配；`Result` 静态方法泛型推导。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们说 Spring Boot 是一个 Java 进程，跑在 8080 端口。今天我们来把这只 Boot 从 0 到 1 拉起来，让它至少能启动、能连数据库、能返回一个 `{code:200, msg:'ok'}` 的 JSON。"

#### 2. 讲授（15 分钟）

**（1）IDEA Spring Initializr 参数选择**
- Server URL：`https://start.spring.io`（若网络受限用 `https://start.aliyun.com`）
- Type：**Maven**
- Language：**Java**
- Group：`com.itcast`
- Artifact：`smart-elder-server`
- Package name：`com.itcast.smart_elder`
- JDK：**17**（本课程锁定 17）
- Spring Boot：**3.2.5**
- 勾选依赖：`Spring Web`、`Lombok`

其他如 MyBatis-Plus、Knife4j、MySQL driver 需要 Initializr 之后手动加。

**（2）pom.xml 关键依赖片段**

```xml
<parent>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-parent</artifactId>
    <version>3.2.5</version>
    <relativePath/>
</parent>

<properties>
    <java.version>17</java.version>
    <mybatis-plus.version>3.5.7</mybatis-plus.version>
    <knife4j.version>4.5.0</knife4j.version>
</properties>

<dependencies>
    <!-- Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>

    <!-- MyBatis-Plus for Spring Boot 3 -->
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-spring-boot3-starter</artifactId>
        <version>${mybatis-plus.version}</version>
    </dependency>
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-jsqlparser</artifactId>
        <version>${mybatis-plus.version}</version>
    </dependency>

    <!-- MySQL 8 驱动 -->
    <dependency>
        <groupId>com.mysql</groupId>
        <artifactId>mysql-connector-j</artifactId>
        <scope>runtime</scope>
    </dependency>

    <!-- Druid 连接池 -->
    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>druid-spring-boot-3-starter</artifactId>
        <version>1.2.23</version>
    </dependency>

    <!-- Lombok -->
    <dependency>
        <groupId>org.projectlombok</groupId>
        <artifactId>lombok</artifactId>
        <optional>true</optional>
    </dependency>

    <!-- Knife4j Swagger 增强 -->
    <dependency>
        <groupId>com.github.xiaoymin</groupId>
        <artifactId>knife4j-openapi3-jakarta-spring-boot-starter</artifactId>
        <version>${knife4j.version}</version>
    </dependency>

    <!-- 参数校验 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-validation</artifactId>
    </dependency>

    <!-- 测试 -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-test</artifactId>
        <scope>test</scope>
    </dependency>
</dependencies>
```

**（3）application.yml 完整配置**

```yaml
server:
  port: 8080
  servlet:
    context-path: /

spring:
  application:
    name: smart-elder-server
  datasource:
    type: com.alibaba.druid.pool.DruidDataSource
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://127.0.0.1:3306/smart_elder?useUnicode=true&characterEncoding=UTF-8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
    username: root
    password: 123456
    druid:
      initial-size: 5
      min-idle: 5
      max-active: 20

mybatis-plus:
  mapper-locations: classpath*:/mapper/**/*.xml
  type-aliases-package: com.itcast.smart_elder.entity
  configuration:
    map-underscore-to-camel-case: true
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
  global-config:
    db-config:
      id-type: auto
      logic-delete-field: deleted
      logic-delete-value: 1
      logic-not-delete-value: 0

logging:
  level:
    com.itcast.smart_elder: debug
```

**（4）启动类 + `Result<T>` + `PageBean<T>`**

演示时展示三个文件的骨架，让学生对"返回给前端的数据长什么样"有直觉。

#### 3. 演示（12 分钟）

```java
package com.itcast.smart_elder;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.itcast.smart_elder.mapper")
public class SmartElderApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartElderApplication.class, args);
        System.out.println(">>> Smart Elder Server started at http://localhost:8080");
    }
}
```

```java
package com.itcast.smart_elder.common;

import lombok.Data;
import java.io.Serializable;

/**
 * 统一返回类
 * @param <T> 业务数据类型
 */
@Data
public class Result<T> implements Serializable {

    private Integer code;   // 200 成功，其它失败
    private String  msg;    // 提示信息
    private T       data;   // 业务数据

    public static <T> Result<T> success() {
        return success(null);
    }

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.setCode(200);
        r.setMsg("ok");
        r.setData(data);
        return r;
    }

    public static <T> Result<T> error(String msg) {
        return error(500, msg);
    }

    public static <T> Result<T> error(Integer code, String msg) {
        Result<T> r = new Result<>();
        r.setCode(code);
        r.setMsg(msg);
        return r;
    }
}
```

```java
package com.itcast.smart_elder.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;
import java.util.List;

/**
 * 分页封装
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageBean<T> implements Serializable {
    private Long    total;      // 总条数
    private List<T> rows;       // 当前页数据
}
```

演示"启动 → 浏览器输入 http://localhost:8080 → 报 whitelabel 错误页 → 说明进程已跑起来"这个完整过程。

#### 4. 实操（12 分钟）
学生按顺序：
1. Spring Initializr 新建 `smart-elder-server`；
2. 复制老师的 pom.xml 依赖并 Reload Maven；
3. 复制 application.yml，把 password 改成自己 MySQL 的真实密码；
4. 创建 `common/Result.java`、`common/PageBean.java`；
5. 点绿色三角启动，看到端口 8080 起来即算通过。

#### 5. 小结（2 分钟）
本课时结束时应有一个能启动的 Spring Boot 空壳。下节课把 MyBatis-Plus 接进来，跑一条 `selectList`。

### 四、课上提问
1. Spring Boot 3.x 为什么要用 JDK 17 而不是 JDK 8？
2. `mybatis-plus-spring-boot3-starter` 和 `mybatis-plus-boot-starter` 有什么区别？（Boot 3 用 Jakarta，Boot 2 用 Javax）

### 五、课堂练习
1. 在 `Result` 中新增一个 `success(String msg, T data)` 重载方法。
2. 修改 application.yml 让端口改成 8081，重启验证。

### 六、课后思考
为什么 `Result<T>` 要用泛型？如果统一用 `Object data` 有什么坏处？

### 七、课后作业
1. 把 pom.xml、application.yml、Result.java、PageBean.java 提交到 git，写好 commit message。
2. 阅读 Druid 官网文档，了解 initial-size / max-active / min-idle 三个参数含义。

### 八、板书设计
```
┌────────────────────────────────────────────────┐
│ 第 2 课时：SpringBoot 后端骨架                 │
├────────────────────────────────────────────────┤
│ 1. Spring Initializr 五步                      │
│ 2. pom 五大依赖 + 版本锁定                     │
│ 3. application.yml 三段：server/datasource/mp  │
│ 4. Result<T> 静态泛型工厂方法                  │
│ 5. PageBean<T> = total + rows                  │
└────────────────────────────────────────────────┘
```

---

## 第 3 课时：MyBatis-Plus 与数据库连接

### 一、教学目标
- 知识目标：掌握 MyBatis-Plus 3.5.7 与 Spring Boot 3 的整合方式；理解 Druid 数据源关键参数；掌握 `@TableName` `@TableId` `@TableField` 三大注解；学会编写继承 `BaseMapper<T>` 的 Mapper 接口；学会写分页插件 `MybatisPlusInterceptor` 配置类。
- 能力目标：能够独立创建 `Member` 实体、`MemberMapper` 接口并在测试类中调用 `selectList` 返回真实数据。

### 二、教学重难点
- 重点：`@TableName("elder_member")` 表名映射、`@TableId(type = IdType.AUTO)` 主键策略、`map-underscore-to-camel-case: true` 下划线转驼峰。
- 难点：分页插件 `PaginationInnerInterceptor` 必须显式声明；`DbType.MYSQL` 需要引入 `jsqlparser` 依赖；`@MapperScan` 与包结构对齐。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课 Spring Boot 起来了，但它还是个空壳，连数据库都没连。今天我们让它开口说话——用 MyBatis-Plus 查出昨天导入的 `elder_member` 表中的所有会员。"

#### 2. 讲授（15 分钟）

**（1）Druid 数据源**
Druid 是阿里开源的连接池，功能强于 HikariCP 的地方在于自带 SQL 监控页面。上节课 application.yml 里已经声明。启动后自动出现 http://localhost:8080/druid，用户名密码可再配置。

**（2）MyBatis-Plus 三大注解**

| 注解 | 位置 | 作用 | 示例 |
|------|------|------|------|
| `@TableName` | 类上 | 指定数据库表名 | `@TableName("elder_member")` |
| `@TableId` | 主键字段 | 主键策略 | `@TableId(type = IdType.AUTO)` |
| `@TableField` | 普通字段 | 特殊列名或忽略 | `@TableField("real_name")`、`@TableField(exist = false)` |

**（3）BaseMapper 提供的核心方法**
- `selectById(id)`：主键查
- `selectList(Wrapper)`：条件列表
- `selectPage(Page, Wrapper)`：分页
- `insert(entity)` / `updateById(entity)` / `deleteById(id)`

**（4）分页插件配置类**

MyBatis-Plus 3.4+ 分页需要手动注册 `PaginationInnerInterceptor`，否则 `selectPage` 不生效（只会 limit 全部）。

#### 3. 演示（12 分钟）

Member 实体：

```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("elder_member")
public class Member {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String realName;        // real_name
    private String phone;
    private Integer gender;         // 0 男 1 女
    private LocalDate birthday;
    private String idCard;
    private String address;
    private Integer status;         // 0 停用 1 启用

    @TableField(fill = com.baomidou.mybatisplus.annotation.FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = com.baomidou.mybatisplus.annotation.FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableField("deleted")
    private Integer deleted;        // 逻辑删除
}
```

Mapper 接口：

```java
package com.itcast.smart_elder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itcast.smart_elder.entity.Member;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MemberMapper extends BaseMapper<Member> {
}
```

分页插件配置类：

```java
package com.itcast.smart_elder.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBatisPlusConfig {

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
```

测试类：

```java
package com.itcast.smart_elder;

import com.itcast.smart_elder.entity.Member;
import com.itcast.smart_elder.mapper.MemberMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class MemberMapperTest {

    @Autowired
    private MemberMapper memberMapper;

    @Test
    void testSelectList() {
        List<Member> list = memberMapper.selectList(null);
        list.forEach(System.out::println);
        System.out.println("总条数：" + list.size());
    }
}
```

老师现场跑一遍，控制台应打出 Day01 建表时预置的会员数据。

#### 4. 实操（12 分钟）
学生：
1. 建 `entity/Member.java`，字段名与 `elder_member` 表一一对应；
2. 建 `mapper/MemberMapper.java`；
3. 建 `config/MyBatisPlusConfig.java`；
4. 建测试类 `MemberMapperTest`，运行绿色即通过；
5. 挑战：再写一个查会员总数的方法 `selectCount(null)`，打印数字。

#### 5. 小结（2 分钟）
"BaseMapper 给了我们 17 个方法，一行代码不用写就能 CRUD。第 3 天开始我们会把它包成 MemberService。"

### 四、课上提问
1. 表名 `elder_member`、类名 `Member` 靠什么关联起来？
2. 为什么在 application.yml 打开 `map-underscore-to-camel-case`？

### 五、课堂练习
1. 用 `QueryWrapper` 查所有 `status = 1` 的会员。
2. 打开 `logging.level` 让 MyBatis 打印真实 SQL。

### 六、课后思考
`@Mapper` 和 `@MapperScan` 二选一即可，为什么老师建议只用 `@MapperScan`？

### 七、课后作业
1. 按同样套路建 `Room`、`Booking` 两个实体+Mapper，各写一个 `selectList` 测试。
2. Druid 监控页 `/druid/login.html` 需要配置账号密码，查文档补上。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│ 第 3 课时：MyBatis-Plus 与数据库连接         │
├──────────────────────────────────────────────┤
│ 1. Druid 数据源 = 连接池 + 监控              │
│ 2. @TableName / @TableId / @TableField       │
│ 3. Mapper 接口 extends BaseMapper<T>         │
│ 4. 分页插件 PaginationInnerInterceptor       │
│ 5. 下划线 <=> 驼峰                           │
└──────────────────────────────────────────────┘
```

---

## 第 4 课时：通义灵码使用与 Vue3 项目模板

### 一、教学目标
- 知识目标：了解通义灵码（TONGYI Lingma）作为阿里出品的免费 AI 编程助手在 IDEA / VS Code 中的核心功能——代码解释、代码生成、单元测试生成、@workspace 项目级问答、@terminal 终端命令生成；掌握使用通义灵码生成 Vue3 + Vite 脚手架命令的完整流程。
- 能力目标：能够在 VS Code 中安装通义灵码，登录阿里云账号，通过 3-5 条 Prompt 完成 Vue3 项目脚手架生成，并成功执行 `npm create vite@latest` 拉起 `smart-elder-web` 空项目。

### 二、教学重难点
- 重点：通义灵码 5 大高频功能；Vite 脚手架命令交互式选择项。
- 难点：让 AI 生成的命令"能真跑起来"——学生必须学会核对命令、识别 AI 幻觉。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"后端已经能查数据库了，但如果我们直接手写 Vue 项目——目录怎么建、依赖怎么装、Vite 怎么配、Router 怎么写——一节课根本讲不完。今天请阿里出品的免费 AI 编程助手'通义灵码'当我们的助教，让它帮我们把 Vue3 项目从命令行到目录结构一次搭好。"

#### 2. 讲授（15 分钟）

**（1）通义灵码是什么**
- 阿里云出品的 AI 编程助手（英文名 TONGYI Lingma），底层用通义千问模型微调，专为编码场景优化。
- 支持 IDEA、VS Code、Visual Studio、PyCharm 等主流 IDE。
- 免费（对个人开发者，需登录阿里云账号）。
- 官网：https://tongyi.aliyun.com/lingma。

**（2）核心功能 5 兄弟**

| 功能 | 快捷调用 | 典型场景 |
|------|---------|----------|
| 代码解释 | 选中代码 → 右键 → 通义灵码 → 解释代码 | 看别人写的 SQL 或复杂正则 |
| 代码生成 | 在方法上写自然语言注释 → 回车 | 快速写 controller CRUD |
| 单元测试 | 右键类名 → 生成单元测试 | 覆盖 service 层 |
| @workspace | 侧边栏输入 `@workspace 项目里有没有...` | 跨文件问答，定位实现 |
| @terminal | 侧边栏输入 `@terminal 帮我...` | 生成 npm / git / mvn 命令 |

**（3）安装与登录**
- IDEA：Settings → Plugins → 搜索 `TONGYI Lingma` → 安装 → 重启 → 右下角图标登录阿里云账号（手机号/支付宝均可）。
- VS Code：扩展市场搜索 `TONGYI Lingma` → 安装 → 侧栏图标登录。

**（4）我们今天用它干什么**
让通义灵码告诉我们：
- 创建 Vue3 项目的命令；
- Vite 交互项该选哪个；
- pnpm 相比 npm 的优势和安装方式；
- 项目最终目录长什么样。

#### 3. 演示（12 分钟）

老师打开 VS Code，展示以下 5 条 Prompt（**真实可复现**）：

**Prompt 1**（生成脚手架命令）：
```
@terminal 我想在 D:\smart-elder\ 目录下用 Vite 创建一个 Vue3 + TypeScript 的项目，项目名 smart-elder-web，给我完整命令，并解释交互式选项应该怎么选。
```

预期输出（Lingma 会给出）：
```bash
cd /d D:\smart-elder
npm create vite@latest smart-elder-web -- --template vue-ts
cd smart-elder-web
npm install
```

**Prompt 2**（安装 pnpm）：
```
@terminal 我不想用 npm，我想改用 pnpm，请给我 Windows 下用 npm 安装 pnpm 全局的命令，并演示把上一步的 npm install 换成 pnpm 的命令。
```

预期输出：
```bash
npm install -g pnpm
cd smart-elder-web
rm -rf node_modules package-lock.json
pnpm install
```

**Prompt 3**（推荐目录）：
```
帮我规划一个 Vue3 + TypeScript + Pinia + Vue Router 4 + Element Plus + axios 的企业级前端项目目录，我要做一个后台管理系统，包含 src/api、src/views、src/components、src/router、src/stores、src/utils 六个子目录，请说明每个目录的用途。
```

**Prompt 4**（生成依赖清单）：
```
基于上面的目录，帮我列出 package.json 需要 pnpm add 的所有依赖（生产依赖 + 开发依赖），并说明版本推荐。
```

预期输出（我们锁定的版本）：
```bash
pnpm add vue-router@4 pinia axios element-plus @element-plus/icons-vue
pnpm add -D unplugin-auto-import unplugin-vue-components sass
```

**Prompt 5**（生成 vite.config.ts）：
```
帮我写一个 vite.config.ts，要求：
1. 端口固定 5173；
2. 配置 @ 指向 src；
3. 配置 /api 代理到 http://localhost:8080，去掉 /api 前缀；
4. 使用 unplugin-auto-import 和 unplugin-vue-components 按需引入 Element Plus。
```

Lingma 输出后老师逐行讲解——**尤其提醒学生：AI 生成的 `pathRewrite` 有时候写错，需要人工核对**。

#### 4. 实操（12 分钟）
学生在自己电脑：
1. VS Code 装通义灵码并登录；
2. 打开新终端，`cd D:\smart-elder`；
3. 依次跑 Prompt 1、Prompt 2 的命令；
4. 交互选项：`Vue` → `TypeScript`；
5. 项目建好后打开，看到 `package.json` 就算成功；
6. **提交阶段作业**：把 Prompt 2 生成的目录截屏发教师群。

#### 5. 小结（2 分钟）
"通义灵码不是 magic，它是助教——命令还是要人核实，尤其是路径、版本号、镜像源。下节课我们真正把项目跑起来。"

### 四、课上提问
1. 通义灵码免费吗？收不收 token 费用？
2. `@workspace` 和 `@terminal` 是干嘛的？
3. Vite 交互式提问"Add TypeScript?"应该选什么？

### 五、课堂练习
1. 用通义灵码 Prompt 让它帮你写一段"检查本机 Node.js 版本，如果低于 18 就报错退出"的 shell 脚本。
2. 用 `@workspace` 问它："项目里有没有 Result 类？在哪个包下？"

### 六、课后思考
如果 AI 生成的命令跑失败了，通常是哪些原因？（网络、版本、路径、权限）我们应该如何组织下一轮 Prompt 让它自动修复？

### 七、课后作业
1. 收集 5 条你个人常用的通义灵码 Prompt，写入 `personal-prompts.md`。
2. 阅读官方 Vite 中文文档 `template vue-ts` 章节。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│ 第 4 课时：通义灵码 + Vue3 脚手架            │
├──────────────────────────────────────────────┤
│ 1. Lingma 是啥：阿里+免费+多 IDE             │
│ 2. 五大功能：解释/生成/单测/@ws/@terminal    │
│ 3. Prompt 5 连击生成 Vue3 项目               │
│ 4. AI 幻觉：路径/版本要人工复核              │
│ 5. npm create vite@latest --template vue-ts  │
└──────────────────────────────────────────────┘
```

---

## 第 5 课时：Vue3 + Vite + Element Plus 环境

### 一、教学目标
- 知识目标：掌握 pnpm 依赖安装；掌握 Vite 别名、代理、按需引入的配置；掌握 Element Plus 通过 `unplugin-auto-import` + `unplugin-vue-components` 按需引入；掌握 Vue Router 4 基本路由表；掌握 Pinia 定义 store；掌握 axios `request.ts` 拦截器写法。
- 能力目标：让 `pnpm dev` 启动的 5173 端口能显示一张带 Element Plus 组件的首页，并且 `axios` 已封装可复用。

### 二、教学重难点
- 重点：`main.ts` 完整启动流程；按需引入的三处配置（vite.config、components.d.ts、无需 import）；axios 拦截器的两个函数（request、response）。
- 难点：`unplugin-vue-components` 与全量 `import 'element-plus/dist/index.css'` 的差异；Vite proxy `rewrite` 函数。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们通过通义灵码把脚手架建好了。这节课我们把 UI 库、路由、状态管理、HTTP 客户端四件套装齐，让页面能'跑'起来。"

#### 2. 讲授（15 分钟）

**（1）pnpm**——磁盘空间友好、快、避免"鬼影依赖"。

**（2）Vite 配置目标**：
1. `@` 指向 `src`；
2. 端口 5173；
3. `/api` 代理到 8080；
4. Element Plus 按需自动引入。

**（3）Element Plus 两种引入方式对比**

| 方式 | 优点 | 缺点 |
|------|------|------|
| 全量 | 一行代码 `app.use(ElementPlus)` | 打包体积大、CSS 全塞进去 |
| 按需 | `unplugin-vue-components` 扫描模板，用到什么打什么 | 需要装两个插件 + 一次配置 |

课程统一使用**按需引入**。

**（4）Router / Pinia / axios 三兄弟**
- Router：单页应用的"分屏"能力；路由表 = 数组。
- Pinia：Vue3 官方推荐的状态管理，写起来就像 Composition API。
- axios：HTTP 客户端，我们要给它加两个拦截器——请求带 token，响应统一 `Result` 解包。

#### 3. 演示（15 分钟）

**vite.config.ts**

```typescript
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath, URL } from 'node:url'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

export default defineConfig({
  plugins: [
    vue(),
    AutoImport({
      resolvers: [ElementPlusResolver()],
    }),
    Components({
      resolvers: [ElementPlusResolver()],
    }),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    open: true,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
})
```

**src/main.ts**

```typescript
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import 'element-plus/theme-chalk/dark/css-vars.css'  // 可选：暗色主题变量
import 'element-plus/theme-chalk/el-message.css'      // 手动补齐弹层样式
import 'element-plus/theme-chalk/el-message-box.css'
import 'element-plus/theme-chalk/el-notification.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'

import App from './App.vue'
import router from './router'

const app = createApp(App)

// 全局注册 Element Plus 图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(createPinia())
app.use(router)
app.mount('#app')
```

**src/router/index.ts**

```typescript
import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'

const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/home',
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import('@/views/HomeView.vue'),
    meta: { title: '首页' },
  },
  {
    path: '/hello',
    name: 'Hello',
    component: () => import('@/views/HelloView.vue'),
    meta: { title: '联调测试' },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach((to, _from, next) => {
  document.title = (to.meta.title as string) ?? 'AI 智能养老社区'
  next()
})

export default router
```

**src/utils/request.ts**

```typescript
import axios, { type AxiosInstance, type AxiosResponse } from 'axios'
import { ElMessage } from 'element-plus'

const service: AxiosInstance = axios.create({
  baseURL: '/api',        // 走 vite proxy 转到 8080
  timeout: 10000,
})

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

// 响应拦截器
service.interceptors.response.use(
  (response: AxiosResponse) => {
    const res = response.data
    if (res.code === 200) {
      return res.data          // 直接返回业务 data
    }
    ElMessage.error(res.msg || '请求失败')
    return Promise.reject(new Error(res.msg || 'Error'))
  },
  (error) => {
    ElMessage.error(error.message || '网络异常')
    return Promise.reject(error)
  },
)

export default service
```

**src/stores/useUserStore.ts**（示例 Pinia）

```typescript
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useUserStore = defineStore('user', () => {
  const token = ref<string>(localStorage.getItem('token') ?? '')
  const nickname = ref<string>('访客')

  function setToken(t: string) {
    token.value = t
    localStorage.setItem('token', t)
  }

  function logout() {
    token.value = ''
    localStorage.removeItem('token')
  }

  return { token, nickname, setToken, logout }
})
```

#### 4. 实操（10 分钟）
学生：
1. `pnpm add vue-router@4 pinia axios element-plus @element-plus/icons-vue`
2. `pnpm add -D unplugin-auto-import unplugin-vue-components sass`
3. 复制以上 5 个文件到项目对应位置；
4. 建 `views/HomeView.vue`：一个 `<el-button type="primary">Hello Element Plus</el-button>`；
5. `pnpm dev` → 浏览器 5173 → 看到按钮。

#### 5. 小结（2 分钟）
"当你看到彩色的 el-button 出现在 5173，说明 UI + 路由 + Vite 三件套已闭环。下节课我们让它真的能调后端接口。"

### 四、课上提问
1. 按需引入用的是哪两个 unplugin？
2. `request.ts` 里响应拦截器为什么直接返回 `res.data` 而不是整个响应？

### 五、课堂练习
1. 在 `HomeView.vue` 里加一个 `<el-icon><User /></el-icon>` 图标，验证图标是否可用。
2. 修改 `router` 增加一个 `/about` 路由。

### 六、课后思考
如果我们把 baseURL 直接写成 `http://localhost:8080` 会怎样？为什么我们更推荐"前端 baseURL = '/api' + Vite proxy"？

### 七、课后作业
1. 把 `request.ts` 补上一个 `download` 方法用于下载文件（`responseType: 'blob'`）。
2. 把 Pinia store 拆成 `useUserStore` 和 `useAppStore` 两个文件。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│ 第 5 课时：Vue3 环境齐活                     │
├──────────────────────────────────────────────┤
│ 1. pnpm add 依赖清单                         │
│ 2. vite.config: alias / proxy / 按需         │
│ 3. main.ts: createApp -> pinia -> router     │
│ 4. router: 数组即路由                        │
│ 5. request.ts: 两拦截器                      │
└──────────────────────────────────────────────┘
```

---

## 第 6 课时：前后端联调 Hello 接口 + Git 提交

### 一、教学目标
- 知识目标：理解跨域产生的原因；掌握两种跨域解决方案——Vite proxy（开发环境）与后端 CORS（生产环境备用）；掌握 `@RestController` 写 hello 接口并返回 `Result`；掌握前端调用后端接口并在页面渲染；掌握 Git 一次完整提交流程。
- 能力目标：完成后端 `/hello` 接口 + 前端 `HelloView.vue` 页面 → 点击按钮拿到后端返回的 `Result.data` 并渲染到页面 → git commit 首次提交。

### 二、教学重难点
- 重点：Controller 的写法；前端 axios 调用；Vite proxy 与 CORS 的选择。
- 难点：`@CrossOrigin` 只对单个 Controller 生效；`WebMvcConfigurer` 全局配置更规范。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"我们现在有一辆车（后端）、一条路（网络）、一位司机（前端），今天让它们真正跑起来——从前端点一下按钮，能拿到后端的一句问候。"

#### 2. 讲授（12 分钟）

**（1）跨域怎么产生**
浏览器安全策略：协议+域名+端口任一不同即跨域。前端 5173，后端 8080，端口不同 → 跨域 → 浏览器控制台报 `CORS blocked`。

**（2）两种解决方案**

| 方案 | 生效环境 | 原理 |
|------|---------|------|
| Vite proxy | 开发 | 让 dev server 帮我们转发，浏览器只跟 5173 通信 |
| 后端 CORS | 生产 | 后端加响应头 `Access-Control-Allow-Origin` |

**（3）RESTful Hello 接口约定**
- URL：`GET /hello`
- 前端调用：`GET /api/hello` → 经 Vite proxy → `GET http://localhost:8080/hello`
- 返回：`{"code":200,"msg":"ok","data":"Hello, Smart Elder!"}`

#### 3. 演示（15 分钟）

**后端 HelloController**

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hello")
public class HelloController {

    @GetMapping
    public Result<String> hello() {
        return Result.success("Hello, Smart Elder!");
    }
}
```

**后端全局 CORS 配置（生产备用）**

```java
package com.itcast.smart_elder.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
```

**前端 API 封装 `src/api/hello.ts`**

```typescript
import request from '@/utils/request'

export function sayHello() {
  return request.get<string, string>('/hello')
}
```

**前端 `src/views/HelloView.vue`**

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { sayHello } from '@/api/hello'
import { ElMessage } from 'element-plus'

const msg = ref('')

async function onClick() {
  try {
    msg.value = await sayHello()
    ElMessage.success('调用成功')
  } catch (e) {
    ElMessage.error('调用失败')
  }
}
</script>

<template>
  <div style="padding: 24px">
    <h2>前后端联调 Hello</h2>
    <el-button type="primary" @click="onClick">调用后端</el-button>
    <p style="margin-top: 16px">后端返回：{{ msg }}</p>
  </div>
</template>
```

浏览器打开 http://localhost:5173/hello 点按钮，页面下方出现 "Hello, Smart Elder!"，联调完成。

#### 4. 实操（12 分钟）
1. 后端建 `HelloController` 和 `WebConfig`，重启；
2. 前端建 `api/hello.ts`、`views/HelloView.vue`，pnpm dev；
3. 打开 5173/hello，点按钮，看效果；
4. **Git 首次提交**：
   ```bash
   cd D:\smart-elder
   git init
   # .gitignore 添加 target/ node_modules/ .idea/ dist/ *.iml
   git add .
   git commit -m "feat: init smart-elder server + web with hello api"
   git branch -M main
   # 若已建好远端 GitHub 仓库：
   git remote add origin git@github.com:xxx/smart-elder.git
   git push -u origin main
   ```

#### 5. 小结（3 分钟）
Day02 全天梳理：前后端分离 → 后端骨架 → MP 连库 → 通义灵码 → Vue3 齐活 → 联调成功。明天开始进入真实业务模块——会员管理 CRUD。

### 四、课上提问
1. 为什么明明后端 8080，前端却访问 `/api/hello`？
2. `@CrossOrigin` 和 `WebMvcConfigurer` 二选一，哪个更好？为什么？
3. `.gitignore` 里为什么要写 `node_modules/`？

### 五、课堂练习
1. 把接口改成 POST，携带 `{name:"张三"}` body，返回 `Hello, 张三!`。
2. 关掉 Vite proxy，观察浏览器 CORS 报错；再打开后端 `WebConfig`，验证生产方式也能通。

### 六、课后思考
如果前端 baseURL 写成 `http://localhost:8080`，Vite proxy 就不起作用了——这时到生产环境部署时，前端配置需不需要改？为什么？

### 七、课后作业
1. 将今日全部代码提交到你自己的 GitHub 仓库，仓库设为 public，把仓库地址粘到教师群。
2. 阅读 MDN 关于 CORS 预检请求（OPTIONS）的介绍并整理成一页笔记。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│ 第 6 课时：前后端联调 + Git                  │
├──────────────────────────────────────────────┤
│ 1. 跨域原因 = 协议/域名/端口任一不同         │
│ 2. Vite proxy vs 后端 CORS                   │
│ 3. Controller + Result 返回 JSON             │
│ 4. axios 调用 → 页面渲染                     │
│ 5. git init/add/commit/push                  │
└──────────────────────────────────────────────┘
```

---

## Day02 全天回顾

至此，学生获得：
- 一个可启动的 Spring Boot 后端进程（8080）
- 一个可启动的 Vue3 前端 dev server（5173）
- 一次成功的前后端联调
- 一个初始化好的 Git 仓库

明天 Day03 将基于此项目开发第一个真实业务模块——**会员管理 CRUD**。

