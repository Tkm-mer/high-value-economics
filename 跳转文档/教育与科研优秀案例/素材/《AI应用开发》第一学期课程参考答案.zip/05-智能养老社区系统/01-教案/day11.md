# 《智能养老社区系统》- 教师教案 - Day11：项目部署运维

**授课日：Day 11 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 13 - Linux + Nginx + Docker + 线上故障排查 + 上线回滚**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day10 完成系统优化与压测，接口已达到发版标准；Day02 前后端骨架、Day03-Day09 业务模块、Day08 大屏、Day09 操作日志已全部开发完毕。本天目标：把代码搬到服务器上跑起来，并具备线上排障与回滚能力。**

---

## 第 1 课时：Linux 基础与部署环境准备

### 一、教学目标
- 知识目标：掌握 Linux 部署运维最常用的 8 条命令（`ls / cd / vim / tail / grep / ps / netstat / systemctl`）的用法与常见组合；理解 `firewalld` 防火墙的开放端口机制；掌握 JDK17 用 tar 包 + `/etc/profile` 的手工安装法（面试高频，比 yum 装 openjdk 更能体现"从零搭环境"能力）；掌握 MySQL 8 与 Redis 7 的 yum 安装、初始化、密码设置；理解为什么部署要有**约定俗成的目录结构**。
- 能力目标：能在一台空的 CentOS 7.9 / Rocky 9 上，独立完成 JDK + MySQL + Redis 三件套的安装并启动；能用 `netstat -tlnp` 验证服务监听；能把 Day01 的 `smart_elder.sql` 导入到 MySQL；能给 Redis 配置 `requirepass` 并用 `redis-cli -a` 连接验证。

### 二、教学重难点
- 重点：`systemctl` 四大动作（`start / stop / status / enable`）；`tail -f` + `grep` 联动看日志；`firewall-cmd --permanent --add-port=xxx/tcp` 的**永久**开放。
- 难点：`/etc/profile` 与 `~/.bashrc` 的加载顺序（登录 shell vs 非登录 shell）；`source /etc/profile` 与重新登录的等价性；MySQL 8 默认 `caching_sha2_password` 引起的连接失败。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："大家在 IDEA 里 F5 一按项目就跑起来了，可服务器上没有 IDEA，没有图形界面，甚至连鼠标都没有——只有一个黑漆漆的 SSH 终端。请问：怎么让 Java 程序在服务器上'跑起来'？"

预设回答：`java -jar xxx.jar`。追问："那 Java 从哪来？MySQL 从哪来？Redis 从哪来？"——引出**部署环境准备**这一课题：项目落地的第一步不是写代码，是搭环境。今天我们把这一步彻底吃透。

#### 2. 讲授（18 分钟）

**（1）Linux 常用命令 8 条**

| 命令 | 高频用法 | 场景 |
|------|---------|------|
| `ls -lh` / `ls -la` | 看目录、看隐藏文件、看大小 | 找 jar 包 |
| `cd /app/smart-elder` | 切目录 | 切到部署目录 |
| `vim application-prod.yml` | 编辑配置 | 修数据库连接 |
| `tail -f logs/app.log` | **实时看日志** | 启动后观察启动过程 |
| `grep -i error logs/app.log` | 过滤关键字 | 找报错 |
| `ps -ef \| grep java` | 找 Java 进程 | 看服务是否活着 |
| `netstat -tlnp \| grep 8080` | 看端口监听 | 验证端口占用 |
| `systemctl status mysqld` | 管系统服务 | 起停 MySQL/Redis |

**vim 三态**：Normal（默认，看/移动）→ Insert（按 `i` 进入编辑）→ Command（按 `:` 输入命令）。保存退出 `:wq`，不保存退出 `:q!`。

**（2）目录约定**

我们全程使用如下目录，请学生用笔记本抄下来：
```
/app/smart-elder/
  ├── backend/          # jar 包 + 启动脚本
  │    ├── smart-elder.jar
  │    ├── start.sh / stop.sh / restart.sh
  │    ├── application-prod.yml
  │    └── logs/
  ├── web/              # 前端 dist 静态资源（Nginx root 指这里）
  ├── mysql/            # docker 数据卷映射
  ├── redis/            # docker 数据卷映射
  └── deploy/           # nginx.conf、docker-compose.yml、Dockerfile
```

**（3）防火墙 firewalld**

CentOS 7+ 默认用 `firewalld` 而不是 `iptables`。三件套命令：
```bash
firewall-cmd --state                               # 查看状态
firewall-cmd --permanent --add-port=8080/tcp       # 永久开放 8080
firewall-cmd --permanent --add-port=80/tcp
firewall-cmd --permanent --add-port=3306/tcp       # 生产环境不建议开
firewall-cmd --reload                              # 重新加载才生效
firewall-cmd --list-ports                          # 查看已开放端口
```
`--permanent` 是**永久**的关键，不加只当次生效。

**（4）JDK17 tar 包安装**

```bash
# 1. 上传 jdk-17.0.10_linux-x64_bin.tar.gz 到 /usr/local/src/
cd /usr/local
tar -zxvf /usr/local/src/jdk-17.0.10_linux-x64_bin.tar.gz
mv jdk-17.0.10 jdk17

# 2. 配置环境变量
vim /etc/profile
# 文件末尾追加：
export JAVA_HOME=/usr/local/jdk17
export PATH=$JAVA_HOME/bin:$PATH

# 3. 使配置生效
source /etc/profile
java -version   # 应输出 openjdk version "17.0.10"
```

**（5）MySQL 8 yum 安装 + 导入 Day01 脚本**

```bash
# 添加 MySQL 官方 yum 源
rpm -Uvh https://dev.mysql.com/get/mysql80-community-release-el7-7.noarch.rpm
rpm --import https://repo.mysql.com/RPM-GPG-KEY-mysql-2022
yum install -y mysql-community-server

# 启动 + 开机自启
systemctl start mysqld
systemctl enable mysqld

# 拿到初始密码
grep 'temporary password' /var/log/mysqld.log

# 登录 + 改密码 + 建库 + 导入
mysql -uroot -p'临时密码'
> ALTER USER 'root'@'localhost' IDENTIFIED BY 'Elder@2026';
> CREATE DATABASE smart_elder DEFAULT CHARACTER SET utf8mb4;
> exit
mysql -uroot -pElder@2026 smart_elder < /root/smart_elder.sql
```

**（6）Redis 7 安装 + 密码**

```bash
yum install -y epel-release
yum install -y redis
vim /etc/redis.conf
# 修改两行：
# bind 0.0.0.0             （允许外部连接，仅内网建议）
# requirepass Elder@Redis  （必开密码）
systemctl start redis
systemctl enable redis
redis-cli -a 'Elder@Redis' ping   # 返回 PONG 即成功
```

#### 3. 演示（10 分钟）
教师用一台干净的云主机（或 VirtualBox 快照），从零开始：SSH 登录 → `yum -y install vim wget` → 上传 JDK tar → 装 JDK → 装 MySQL → 导 SQL → 装 Redis → 用 `redis-cli` 与 `mysql -e "select count(*) from tb_member"` 收尾验证。每一步都念一遍命令是"做什么"。

#### 4. 实操（10 分钟）
学生任务（两人一组，一人操作一人念命令）：
1. 用讲师提供的临时云主机账号 SSH 登录（或本机 VirtualBox）。
2. 按讲义完成 JDK17、MySQL8、Redis7 安装，最终执行三条验证命令并截图：
   ```bash
   java -version
   mysql -uroot -pElder@2026 -e "select database();"
   redis-cli -a 'Elder@Redis' ping
   ```
3. 开放防火墙 80 / 8080 端口。
4. 建立 `/app/smart-elder/` 目录树。

#### 5. 小结（3 分钟）
今天上手了 Linux 常见命令 + JDK/MySQL/Redis 三件套。**部署环境是运维的地基**，环境不平不整，后面所有 jar、容器、脚本都白瞎。下一课时把 Day10 打好的 jar 包扔到这台机器上跑起来。

### 四、课上提问
1. `systemctl enable mysqld` 与 `systemctl start mysqld` 的区别？
2. `tail -f` 和 `tail -n 100` 分别看什么？
3. 我在 `/etc/profile` 里加了 `JAVA_HOME` 后 `java -version` 还是 not found，为什么？
4. Redis 不设 `requirepass` 直接暴露在公网会怎样？（比特币挖矿病毒经典入口）

### 五、课堂练习
1. 用 `netstat -tlnp` 分别列出 8080、3306、6379、80 的监听进程。
2. 编写一句命令：`过滤 /var/log/mysqld.log 中所有含 "ERROR" 的行并显示行号`（答：`grep -in error /var/log/mysqld.log`）。

### 六、课后思考
生产环境是否应该把 MySQL 的 3306 端口开在公网防火墙？（答：不应；应通过跳板机 + 内网访问，本机 3306 只允许 127.0.0.1 或指定内网 IP。）

### 七、课后作业
1. 在自己的云主机（或 VirtualBox CentOS 7.9）上把 JDK17 + MySQL8 + Redis7 全部装好并写一份**安装清单 markdown**（每条命令 + 一句注释），下节课带来。
2. 提交 Git：`docs(deploy): server env checklist`。

### 八、板书设计
```
┌───────────────────────────────────────────────────────┐
│  Day11-01  Linux 部署环境                             │
├───────────────────────────────────────────────────────┤
│ 常用命令：ls/cd/vim/tail/grep/ps/netstat/systemctl    │
│ 目录约定：/app/smart-elder/{backend,web,deploy}       │
│ JDK17：tar -zxvf + /etc/profile + source              │
│ MySQL8：yum + grep 临时密码 + ALTER USER              │
│ Redis7：requirepass + bind 内网                       │
│ firewalld：--permanent + --reload                     │
└───────────────────────────────────────────────────────┘
```

---

## 第 2 课时：后端 jar 部署与守护

### 一、教学目标
- 知识目标：掌握 `mvn clean package -DskipTests` 打 fat-jar 的原理与产物；理解 Spring Boot 多 profile（`application-dev.yml` / `application-prod.yml` / `application.yml`）的加载顺序；掌握 `nohup java -jar ... &` 后台启动的三大坑（终端关闭、日志重定向、pid 文件）；能编写生产级 `start.sh / stop.sh / restart.sh` 三件套；掌握用 `systemd` 把服务注册成系统服务的方法（比 nohup 更专业，是企业主流）；理解 `logback-spring.xml` 的日志轮切规则（按天+按大小）。
- 能力目标：能在服务器上把 `smart-elder.jar` 一次跑通，能用 `systemctl restart smart-elder` 平滑重启，能通过 `journalctl -u smart-elder -f` 实时看应用日志。

### 二、教学重难点
- 重点：`start.sh` 里的 `nohup ... > /dev/null 2>&1 &` + `echo $! > app.pid` 组合；systemd unit 文件的 `Type=simple` / `Restart=on-failure` / `User=deploy` 三项。
- 难点：`application-prod.yml` 里数据库/Redis 密码的**外部化**（用环境变量或 `--spring.config.location` 覆盖）；jar 包内 `logback-spring.xml` 与 `logback.xml` 加载差异。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问："我们在 IDEA 里点绿色三角就能跑，进程退出了 IDEA 会告诉我。可服务器上，jar 一 CTRL+C 就死了，SSH 一断开也死了。**怎么让 Java 进程像 MySQL 一样，作为一个'服务'长期活着？**"

引出两条主流方案：**nohup + shell 脚本**（手工党，速度快）与 **systemd service**（专业运维，重启/开机自启/日志托管都省心）。今天两种都要会。

#### 2. 讲授（20 分钟）

**（1）打包**

在开发机执行：
```bash
cd smart-elder-backend
mvn clean package -DskipTests
ls -lh target/smart-elder-1.0.0.jar   # 大约 60~80MB
```
产物是 **fat-jar**（把所有依赖打进一个 jar），Spring Boot Maven 插件默认行为。

**（2）application-prod.yml**

在 `src/main/resources/` 下新增：
```yaml
# application-prod.yml
server:
  port: 8080
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/smart_elder?useSSL=false&serverTimezone=Asia/Shanghai&characterEncoding=utf8mb4
    username: root
    password: ${DB_PASSWORD:Elder@2026}
    driver-class-name: com.mysql.cj.jdbc.Driver
  data:
    redis:
      host: 127.0.0.1
      port: 6379
      password: ${REDIS_PASSWORD:Elder@Redis}
      database: 0
logging:
  file:
    path: /app/smart-elder/backend/logs
```
密码用 `${DB_PASSWORD:默认}` 语法**优先取环境变量**——发到生产的 jar 里不该硬编码密码。

**（3）start.sh / stop.sh / restart.sh**

在 `/app/smart-elder/backend/` 下建三个脚本：

`start.sh`：
```bash
#!/bin/bash
APP_HOME=/app/smart-elder/backend
APP_NAME=smart-elder.jar
PID_FILE=$APP_HOME/app.pid
LOG_FILE=$APP_HOME/logs/nohup.out

cd $APP_HOME
if [ -f "$PID_FILE" ] && kill -0 `cat $PID_FILE` 2>/dev/null; then
  echo "Already running, pid=`cat $PID_FILE`"
  exit 1
fi
mkdir -p logs
nohup java -Xms512m -Xmx1024m \
  -Dspring.profiles.active=prod \
  -Dfile.encoding=UTF-8 \
  -jar $APP_NAME > $LOG_FILE 2>&1 &
echo $! > $PID_FILE
echo "Started, pid=`cat $PID_FILE`"
```

`stop.sh`：
```bash
#!/bin/bash
PID_FILE=/app/smart-elder/backend/app.pid
if [ ! -f "$PID_FILE" ]; then echo "Not running"; exit 0; fi
PID=`cat $PID_FILE`
kill $PID
for i in {1..30}; do
  if ! kill -0 $PID 2>/dev/null; then rm -f $PID_FILE; echo "Stopped"; exit 0; fi
  sleep 1
done
echo "Force kill"
kill -9 $PID; rm -f $PID_FILE
```

`restart.sh`：
```bash
#!/bin/bash
DIR=$(cd $(dirname $0); pwd)
sh $DIR/stop.sh
sleep 2
sh $DIR/start.sh
```
最后：`chmod +x *.sh`。

**（4）systemd unit（企业主流）**

新建 `/etc/systemd/system/smart-elder.service`：
```ini
[Unit]
Description=Smart Elder Backend
After=network.target mysqld.service redis.service

[Service]
Type=simple
User=root
WorkingDirectory=/app/smart-elder/backend
Environment="DB_PASSWORD=Elder@2026"
Environment="REDIS_PASSWORD=Elder@Redis"
ExecStart=/usr/local/jdk17/bin/java -Xms512m -Xmx1024m \
  -Dspring.profiles.active=prod -jar /app/smart-elder/backend/smart-elder.jar
SuccessExitStatus=143
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

四板斧：
```bash
systemctl daemon-reload             # 载入新 unit
systemctl enable smart-elder        # 开机自启
systemctl start smart-elder
systemctl status smart-elder        # 应看到 active (running)
journalctl -u smart-elder -f        # 实时看应用日志
```

**（5）logback-spring.xml 日志轮切**

`src/main/resources/logback-spring.xml`：
```xml
<configuration>
  <property name="LOG_HOME" value="${LOG_FILE_PATH:-./logs}"/>
  <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
    <file>${LOG_HOME}/smart-elder.log</file>
    <rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
      <fileNamePattern>${LOG_HOME}/smart-elder.%d{yyyy-MM-dd}.%i.log.gz</fileNamePattern>
      <maxFileSize>100MB</maxFileSize>
      <maxHistory>30</maxHistory>
      <totalSizeCap>10GB</totalSizeCap>
    </rollingPolicy>
    <encoder>
      <pattern>%d{HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n</pattern>
    </encoder>
  </appender>
  <root level="INFO"><appender-ref ref="FILE"/></root>
</configuration>
```
**按天滚动 + 单文件 100M + 保留 30 天 + 总大小上限 10G**，是生产标配。

#### 3. 演示（10 分钟）
教师依次演示：`mvn package` → `scp` 传 jar → 建 `application-prod.yml` → `start.sh` 跑通 → 用 curl 打接口验证 → 停掉，改用 systemd unit 重启 → `journalctl -u smart-elder -f` 实时看日志。

#### 4. 实操（9 分钟）
学生任务：
1. 本机 `mvn package`。
2. `scp target/smart-elder-1.0.0.jar root@主机:/app/smart-elder/backend/smart-elder.jar`。
3. 敲入三个 shell 脚本 + 一个 `application-prod.yml`，用 nohup 方式跑通，用 `curl http://127.0.0.1:8080/api/hello` 验证。
4. 再改用 systemd unit 起，观察 `journalctl` 有输出。

#### 5. 小结（3 分钟）
**nohup 是入门，systemd 是工业级**。生产环境几乎都用 systemd。日志、pid、重启、开机自启，systemd 一次全给。下节课把前端 dist 用 Nginx 挂上来。

### 四、课上提问
1. `nohup java -jar xxx.jar` 后面为什么必须 `&`？漏了会怎么样？
2. `2>&1` 是什么意思？
3. systemd 的 `Restart=on-failure` 和 `always` 的区别？

### 五、课堂练习
1. 修改 `start.sh` 让它支持 `-Dspring.config.location=file:/app/smart-elder/backend/application-prod.yml` 参数（把配置外置到 jar 之外，配置改动不用重打 jar）。
2. 修改 systemd unit 让最大堆内存改成 2G。

### 六、课后思考
为什么 systemd 不推荐用 `Type=forking`？（Spring Boot 是"前台进程"启动的，用 simple 更简单；forking 需要脚本自己 fork 并写 pid 文件，与 nohup 场景冲突。）

### 七、课后作业
1. 用 systemd 起 smart-elder，然后 `kill -9` 掉，观察是否自动拉起（应该会）。
2. 提交 Git：`chore(deploy): backend scripts + systemd unit`。

### 八、板书设计
```
┌──────────────────────────────────────────────────┐
│  Day11-02  后端 jar 部署                         │
├──────────────────────────────────────────────────┤
│ mvn clean package -DskipTests                    │
│ application-prod.yml + 环境变量 ${DB_PASSWORD}   │
│ 手工：start.sh / stop.sh / restart.sh + pid      │
│ 主流：systemd unit → daemon-reload → enable      │
│ 日志：logback-spring.xml 按天+按大小滚动         │
└──────────────────────────────────────────────────┘
```

---

## 第 3 课时：Nginx 部署 Vue3 前端

### 一、教学目标
- 知识目标：理解 SPA（单页应用）在生产环境为什么必须**静态资源 + 反向代理**双管齐下；掌握 `pnpm build` 的产物结构（`dist/index.html + assets/*.js + assets/*.css`）；掌握 Nginx 的三大核心指令块（`server` / `location` / `upstream`）；理解 `try_files` 如何解决 Vue Router history 模式刷新 404 问题；能用 `location /api/` 把前端调后端的请求反向代理到 8080。
- 能力目标：能独立在 CentOS 上装 Nginx；能写一份完整的 `nginx.conf`，让访问 80 端口时前端页面 + 后端接口双通道全部打通；能开启 gzip 压缩，能看懂 `access.log` 与 `error.log`。

### 二、教学重难点
- 重点：`try_files $uri $uri/ /index.html;` 这句是 Vue Router history 模式的"神器"；`location /api/ { proxy_pass http://127.0.0.1:8080/api/; }` 反向代理写法（末尾斜杠有讲究）。
- 难点：`proxy_pass` 结尾**带斜杠 vs 不带斜杠**的路径改写规则；gzip 中静态资源 (`.js`、`.css`) 与动态接口 (`application/json`) 都要开。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问："上节课我们已经在服务器上跑起来 8080 端口的后端 API。现在前端呢？我们平时开发用 `pnpm dev` 起 5173 端口，但生产环境要不要把 Vite 开发服务器扔到服务器上跑？"

引出核心概念：前端 Vue3 项目是**编译型**的，`pnpm build` 后产出一坨 `dist/` 静态文件（就是纯 HTML + JS + CSS），交给 Web 服务器（Nginx）当"静态资源"发送即可。**Nginx 同时也做反向代理**，把浏览器发到 `/api/xxx` 的请求转给后端 8080。

#### 2. 讲授（20 分钟）

**（1）pnpm build**

开发机执行：
```bash
cd smart-elder-web
pnpm build
ls dist/
# index.html   assets/   favicon.ico
```
把 `dist/` 整个上传到服务器：
```bash
scp -r dist root@主机:/app/smart-elder/web/
```

**（2）Nginx 安装**

```bash
yum install -y epel-release
yum install -y nginx
systemctl start nginx
systemctl enable nginx
nginx -v          # nginx/1.20.x
```

**（3）完整 nginx.conf（覆盖 `/etc/nginx/nginx.conf` 的 http 块 或 新建 `/etc/nginx/conf.d/smart-elder.conf`）**

推荐做法：**保留主 `nginx.conf` 不动，只往 `/etc/nginx/conf.d/` 加一个业务 conf**。文件 `/etc/nginx/conf.d/smart-elder.conf`：

```nginx
# —— gzip 全局开启 ——（也可放主 nginx.conf 的 http 块）
gzip on;
gzip_min_length 1k;
gzip_comp_level 6;
gzip_types text/plain text/css application/json application/javascript
           application/x-javascript text/xml application/xml application/xml+rss
           text/javascript image/svg+xml;
gzip_vary on;

server {
    listen       80;
    server_name  _;   # 或写你的域名 elder.example.com

    # —— 前端静态资源 ——
    root  /app/smart-elder/web/dist;
    index index.html;

    # 处理 Vue Router history 模式：找不到文件就回到 index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # 静态资源强缓存
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2?)$ {
        expires 7d;
        add_header Cache-Control "public, max-age=604800";
    }

    # —— 反向代理后端接口 ——
    location /api/ {
        proxy_pass         http://127.0.0.1:8080/api/;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
        proxy_send_timeout 60s;
    }

    # —— SSE 流式接口（Day05 AI 对话用）——
    location /api/ai/chat/stream {
        proxy_pass         http://127.0.0.1:8080/api/ai/chat/stream;
        proxy_http_version 1.1;
        proxy_set_header   Connection "";
        proxy_buffering    off;    # 关键：SSE 不能被 Nginx 缓存
        proxy_cache        off;
        proxy_read_timeout 3600s;
    }

    # 日志
    access_log /var/log/nginx/smart-elder.access.log;
    error_log  /var/log/nginx/smart-elder.error.log warn;
}
```

**关键点讲解：**

- `try_files $uri $uri/ /index.html;`：Vue Router 用 history 模式时，浏览器地址栏是 `/member/list`，实际磁盘上没这文件。这行让 Nginx 回退到 `index.html`，交给前端路由处理。
- `location /api/ { proxy_pass http://127.0.0.1:8080/api/; }`：末尾**都带斜杠**——请求 `/api/member/1` 被转成 `/api/member/1` 打给后端。若 `proxy_pass` 结尾不带斜杠，路径会拼接成 `/api/api/member/1`，出问题。
- SSE（Day05 讲的流式对话）必须 `proxy_buffering off`，否则 Nginx 会把服务端一批批推的 chunk 攒到一起才回给浏览器，"流式"变"结束式"。

**（4）Nginx 三板斧**

```bash
nginx -t                # 校验配置（改完必做）
nginx -s reload         # 平滑重载（推荐）
systemctl restart nginx # 强制重启（不到万不得已别用）
```

#### 3. 演示（10 分钟）
教师现场：`pnpm build` → `scp dist` → 写 `smart-elder.conf` → `nginx -t` → `nginx -s reload` → 浏览器访问 `http://主机IP/`，看到会员列表页 → 点击"新增会员"接口成功 → 打开 F12 Network 面板确认 `/api/member` 走的是 80 端口→ 演示故意关掉后端 8080 后访问 `/api/member`，看 Nginx 返回 502 Bad Gateway，讲解错误码含义。

#### 4. 实操（9 分钟）
学生任务：
1. 本机 `pnpm build`。
2. `scp -r dist` 到服务器 `/app/smart-elder/web/dist/`。
3. 复制讲义中的 `smart-elder.conf` 到 `/etc/nginx/conf.d/`。
4. `nginx -t` 通过后 `nginx -s reload`。
5. 浏览器打开 `http://主机IP/`，全流程点击一遍：登录、会员列表、AI 对话、大屏。若 AI 流式响应"卡到最后才一次性显示"，检查 SSE location 的 `proxy_buffering off`。

#### 5. 小结（3 分钟）
Nginx = **静态资源服务器 + 反向代理 + 负载均衡 + gzip 压缩**。今天用了前三个，负载均衡（`upstream`）留到面试题拓展。至此**手工部署闭环**：前后端服务器上都跑起来了，浏览器一 URL 全通。下节课换个玩法——**用 Docker 一键搞定**。

### 四、课上提问
1. 为什么 `try_files` 缺失时，Vue Router history 模式刷新会 404？
2. `proxy_pass` 结尾 `/` 有没有的路径改写规则？
3. 502 Bad Gateway 通常是什么原因？504 呢？

### 五、课堂练习
1. 在 `smart-elder.conf` 中新增 `location /upload/ {}` 把 Day04 的图片上传目录 `/app/smart-elder/backend/upload/` 直接由 Nginx 静态服务（省一次反代）。
2. 打开 F12，对比开 gzip 前后 `main.js` 的传输大小差异（一般压缩到 20-30%）。

### 六、课后思考
若前后端要走 HTTPS（`https://elder.example.com`），Nginx 应加什么配置？（`listen 443 ssl;` + `ssl_certificate` + `ssl_certificate_key`，把 80 全部 `return 301` 到 https。）

### 七、课后作业
1. 使用 Let's Encrypt 免费 SSL 证书为自己主机加 HTTPS（选做，Day12 简历亮点）。
2. Git 提交 `feat(deploy): nginx conf for smart-elder`。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-03  Nginx 部署前端                     │
├───────────────────────────────────────────────┤
│ pnpm build → dist/                            │
│ root /app/smart-elder/web/dist                │
│ try_files $uri $uri/ /index.html;   (history) │
│ location /api/ → proxy_pass 8080              │
│ SSE: proxy_buffering off                      │
│ gzip on + expires 7d                          │
└───────────────────────────────────────────────┘
```

---

## 第 4 课时：Docker 容器化部署

### 一、教学目标
- 知识目标：理解容器（Container）与虚拟机（VM）的差异，掌握"镜像=只读模板，容器=运行实例"的概念；掌握 Docker 三件套核心命令（`docker build / run / ps / logs / exec`）；掌握**多阶段 Dockerfile**（builder + runtime）为什么能大幅减小镜像体积；掌握 `docker-compose.yml` 编排多服务；理解 `volumes` 数据持久化、`networks` 内部网络、`healthcheck` 依赖控制。
- 能力目标：能为 Spring Boot 后端写一份多阶段 Dockerfile；能为 Vue3 前端写 nginx:alpine Dockerfile；能编写一份**四服务并起**（mysql / redis / backend / nginx）的 `docker-compose.yml`；执行一条 `docker-compose up -d` 让整个系统跑起来。

### 二、教学重难点
- 重点：多阶段构建里 `FROM maven AS builder` → `FROM openjdk-17-slim` 的产物拷贝写法；docker-compose 中 `depends_on` 配合 `healthcheck` 才能真正让后端等 MySQL Ready 再启动。
- 难点：数据卷 `./mysql/data:/var/lib/mysql` 的持久化机制（容器删了数据还在）；network 内**服务名即 hostname**（后端连接串写 `jdbc:mysql://mysql:3306/xxx` 而不是 IP）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问："上一课时我们手工装了 JDK、MySQL、Redis、Nginx——花了 40 分钟。假设现在客户下单同时要在 3 台机器上部署，你要不要每台机器都手工装一遍？"

预设："写脚本自动装。"

追问："脚本会遇到哪些坑？"——CentOS 版本不一样、yum 源变了、依赖冲突、密码忘了、端口冲了……。**Docker 的宗旨就是：把'环境+代码'打包成一个不可变镜像，随便丢哪都能跑。**

#### 2. 讲授（20 分钟）

**（1）容器 vs 虚拟机**

| 维度 | 虚拟机 | 容器 |
|------|-------|------|
| 隔离层 | Hypervisor（Guest OS） | Linux Namespace + Cgroup |
| 启动速度 | 分钟级 | 秒级 |
| 镜像大小 | GB 级 | MB 级 |
| 隔离度 | 强 | 中（共享内核） |

**（2）后端 Dockerfile（多阶段）**

`smart-elder-backend/Dockerfile`：
```dockerfile
# —— Stage 1：编译 ——
FROM maven:3.9-eclipse-temurin-17 AS builder
WORKDIR /build
COPY pom.xml .
RUN mvn dependency:go-offline -B
COPY src ./src
RUN mvn clean package -DskipTests -B

# —— Stage 2：运行 ——
FROM eclipse-temurin:17-jdk-alpine
WORKDIR /app
COPY --from=builder /build/target/smart-elder-*.jar app.jar
ENV JAVA_OPTS="-Xms512m -Xmx1024m"
ENV SPRING_PROFILES_ACTIVE=prod
EXPOSE 8080
ENTRYPOINT sh -c "java $JAVA_OPTS -jar app.jar"
```

**为什么两个 FROM？** 编译需要 3G 的 maven 镜像，运行只要 JRE。两阶段能把最终镜像从 1.2G 降到 ~200MB。

**（3）前端 Dockerfile**

`smart-elder-web/Dockerfile`：
```dockerfile
# —— Stage 1：构建 ——
FROM node:20-alpine AS builder
WORKDIR /build
RUN npm i -g pnpm
COPY pnpm-lock.yaml package.json ./
RUN pnpm install --frozen-lockfile
COPY . .
RUN pnpm build

# —— Stage 2：Nginx 托管 ——
FROM nginx:1.25-alpine
COPY --from=builder /build/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

前端目录下再放一份 `nginx.conf`（内容与第 3 课时同，`proxy_pass http://backend:8080/api/;`——注意主机名换成 compose 里的服务名 `backend`）。

**（4）docker-compose.yml（四服务）**

工程根目录下 `docker-compose.yml`：
```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    container_name: elder-mysql
    restart: unless-stopped
    environment:
      MYSQL_ROOT_PASSWORD: Elder@2026
      MYSQL_DATABASE: smart_elder
      TZ: Asia/Shanghai
    volumes:
      - ./deploy/mysql/data:/var/lib/mysql
      - ./deploy/mysql/init:/docker-entrypoint-initdb.d   # 启动时自动执行 sql
    ports:
      - "3306:3306"
    healthcheck:
      test: ["CMD", "mysqladmin", "ping", "-h", "localhost", "-uroot", "-pElder@2026"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks: [elder-net]

  redis:
    image: redis:7-alpine
    container_name: elder-redis
    restart: unless-stopped
    command: ["redis-server", "--requirepass", "Elder@Redis", "--appendonly", "yes"]
    volumes:
      - ./deploy/redis/data:/data
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "-a", "Elder@Redis", "ping"]
      interval: 10s
      timeout: 3s
      retries: 5
    networks: [elder-net]

  backend:
    build:
      context: ./smart-elder-backend
      dockerfile: Dockerfile
    image: smart-elder-backend:1.0.0
    container_name: elder-backend
    restart: unless-stopped
    environment:
      SPRING_PROFILES_ACTIVE: prod
      SPRING_DATASOURCE_URL: jdbc:mysql://mysql:3306/smart_elder?useSSL=false&serverTimezone=Asia/Shanghai&characterEncoding=utf8mb4
      SPRING_DATASOURCE_USERNAME: root
      SPRING_DATASOURCE_PASSWORD: Elder@2026
      SPRING_DATA_REDIS_HOST: redis
      SPRING_DATA_REDIS_PASSWORD: Elder@Redis
    volumes:
      - ./deploy/backend/logs:/app/logs
    depends_on:
      mysql:
        condition: service_healthy
      redis:
        condition: service_healthy
    ports:
      - "8080:8080"
    networks: [elder-net]

  nginx:
    build:
      context: ./smart-elder-web
      dockerfile: Dockerfile
    image: smart-elder-web:1.0.0
    container_name: elder-nginx
    restart: unless-stopped
    depends_on: [backend]
    ports:
      - "80:80"
    networks: [elder-net]

networks:
  elder-net:
    driver: bridge
```

**关键点：**
- `depends_on.condition: service_healthy` —— 只有 MySQL 通过健康检查后，后端才启动，避免"MySQL 还没起来后端就崩了"。
- `networks.elder-net` —— 四个服务在同一虚拟网段，互相通过服务名寻址（后端连接串是 `jdbc:mysql://mysql:3306/...`）。
- `volumes` —— MySQL 数据、Redis AOF、后端日志全部挂到宿主机 `./deploy/...`，容器删了数据还在。

**（5）一键启停**

```bash
docker-compose up -d              # 后台起
docker-compose ps                 # 看状态
docker-compose logs -f backend    # 看后端日志
docker-compose restart backend    # 只重启后端（改代码打新镜像用）
docker-compose down               # 停并删除容器（不删卷）
docker-compose down -v            # 连数据卷一起删（危险！）
```

#### 3. 演示（10 分钟）
教师现场：
1. 把 Day01 的 `smart_elder.sql` 放进 `./deploy/mysql/init/`。
2. `docker-compose up -d` 一条命令。
3. 用 `docker-compose ps` 观察四个容器从 `starting` → `healthy` → `running` 的过程。
4. 浏览器打开 `http://主机IP/` 全流程走一遍。
5. `docker-compose logs backend | tail -50` 看后端启动日志。

#### 4. 实操（9 分钟）
学生任务：
1. 目录结构就位：`deploy/mysql/init/smart_elder.sql`、两个 Dockerfile、`docker-compose.yml`。
2. 执行 `docker-compose up -d --build`。
3. 用 `curl http://127.0.0.1/api/hello` 与浏览器双端验证。
4. 尝试 `docker-compose down` 后再 `up -d`，验证数据卷持久化（新增的会员数据还在）。

#### 5. 小结（3 分钟）
Docker 把"环境"变成了**版本化的镜像**，`up -d` 一条命令包全场。今天两种部署方式都学了：**手工部署适合小项目 / 学生自测**，**docker-compose 适合中小团队生产**。企业更大规模走 K8s，那是后话。下节课讲**线上排障**。

### 四、课上提问
1. 多阶段 Dockerfile 里 `--from=builder` 是什么意思？如果只写一个 FROM 会怎样？
2. compose 里为什么 `depends_on` 单独用还不够，要配 `healthcheck`？
3. `docker-compose down` 与 `docker-compose down -v` 的差别？哪个更危险？

### 五、课堂练习
1. 修改 backend 服务的 `JAVA_OPTS` 环境变量把最大堆改成 2G。
2. 给 nginx 服务加一个 volume 把宿主机 `./deploy/nginx/logs:/var/log/nginx`。

### 六、课后思考
如果 MySQL 数据卷放在容器里（不挂宿主机），会发生什么？（`docker-compose down` 时数据丢失。这是初学者最常见的翻车。）

### 七、课后作业
1. 用 `docker images` 看两个自建镜像的大小，把后端从 slim → alpine 再改一次，比大小。
2. Git 提交 `feat(deploy): docker-compose stack`。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day11-04  Docker 容器化                      │
├───────────────────────────────────────────────┤
│ 多阶段 Dockerfile：builder → runtime          │
│ 后端：maven:3.9 → temurin:17-jdk-alpine       │
│ 前端：node:20 → nginx:1.25-alpine             │
│ compose 四服务：mysql/redis/backend/nginx     │
│ 关键：healthcheck + service_healthy           │
│ 内网寻址：jdbc:mysql://mysql:3306/xxx         │
└───────────────────────────────────────────────┘
```

---

## 第 5 课时：线上故障处理常用方法

### 一、教学目标
- 知识目标：掌握"线上出问题" **三板斧**——**看日志、看进程、看堆栈**；掌握 `tail -f + grep` 与 `less +F` 两种实时看日志方法的适用场景；掌握 **CPU 100% 排查五步法**（`top` → `top -H -p PID` → 找线程 → `nid` 十六进制转换 → `jstack` + grep）；掌握内存泄漏 `jmap -dump:live,format=b,file=xx.hprof PID` + MAT 分析基本流程；掌握 **Arthas** 在线诊断（`dashboard` / `trace` / `watch`）；能针对 Day03 分页接口的一个"慢查询导致 CPU 高"问题，从日志到修复走一遍。
- 能力目标：给一个"接口变慢+CPU 报警"的场景，学生能独立按套路定位到具体代码行，不再"束手无策"。

### 二、教学重难点
- 重点：`printf "%x\n" $tid` 把线程 id 转十六进制，与 `jstack` 输出里 `nid=0x...` 对照——**这是 Java 线上问题定位最高频的一步**。
- 难点：Arthas 的 `watch` 表达式（`watch 全类名 方法名 "{params,returnObj,throwExp}" -x 3`）；何时用 dump 何时用 Arthas。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："今天上午 10 点，运营同事一大早给你打电话：'系统卡死了，页面转圈圈半分钟才出来。'你在 SSH 里第一步敲什么命令？"

答：**先看日志有没有报错**（`tail -f logs/smart-elder.log | grep -i error`），**再看 CPU/内存**（`top`），**再看进程线程**（`top -H -p PID`）。今天把这套动作练成肌肉记忆。

#### 2. 讲授（18 分钟）

**（1）日志查看**

```bash
# 实时看最新（推荐）
tail -f /app/smart-elder/backend/logs/smart-elder.log

# 实时看 + 过滤 ERROR
tail -f logs/smart-elder.log | grep -i --line-buffered error

# 从大日志文件末尾开始交互式查看（可上下滚 + shift+F 实时）
less +F logs/smart-elder.log

# 按时间取一段（假设 10:00-10:05 发生问题）
sed -n '/2026-07-09 10:00/,/2026-07-09 10:05/p' logs/smart-elder.log > slice.log
```

**（2）CPU 100% 五步法**

场景：`top` 看到 java 进程 CPU 800%（8 核跑满）。

```bash
# 第 1 步：找 Java 进程 pid
top   # 假设看到 PID=12345 CPU 800%

# 第 2 步：找这个进程里最耗 CPU 的线程
top -H -p 12345   # 假设看到 tid=12360 CPU 99%

# 第 3 步：把线程 id 转成十六进制（jstack 显示的 nid 是 hex）
printf "%x\n" 12360   # 输出 3048

# 第 4 步：拿 jstack
/usr/local/jdk17/bin/jstack 12345 > /tmp/stack.log

# 第 5 步：定位那个线程
grep -A 30 "nid=0x3048" /tmp/stack.log
```
输出里能看到那个线程正卡在哪个方法（比如 `MemberService.pageQuery(MemberService.java:88)`）——**这就是我们要修的那行代码**。

**（3）内存泄漏排查**

```bash
# 看 GC 情况（发现 Full GC 频繁）
jstat -gcutil 12345 1000 10

# 生成堆 dump（存活对象）
jmap -dump:live,format=b,file=/tmp/heap.hprof 12345

# 传回本地用 Eclipse MAT 打开 → Leak Suspects Report
scp root@主机:/tmp/heap.hprof ./
```
MAT 的 Leak Suspects 直接告诉你"XX 类实例太多，占了 80% 内存"，通常是**静态 Map / 缓存无过期 / 线程池未关闭**。

**（4）Arthas 在线诊断**

Arthas 是阿里开源的 Java 诊断神器，一句 curl 就能跑：
```bash
curl -O https://arthas.aliyun.com/arthas-boot.jar
java -jar arthas-boot.jar
# 选择 [1] com.smart.elder.Application  (就是我们的 Java 进程)
```

进入 Arthas 交互后：
```
dashboard                            # 实时监控大盘：JVM/线程/CPU
thread -n 3                          # 最忙的 3 个线程堆栈
trace com.itcast.smart_elder.service.MemberService pageQuery
    # 追踪方法每一步耗时——立刻能看到是 SQL 慢还是循环慢
watch com.itcast.smart_elder.controller.MemberController page \
    "{params, returnObj, throwExp}" -x 3
    # 观察某方法的入参、返回、异常，不改代码不重启
jad com.itcast.smart_elder.service.MemberService
    # 反编译看服务器上真实跑的代码是不是我以为的那版
```
**Arthas 最大的价值：不用改代码、不用重启，线上直接摸问题。**

**（5）Day03 分页接口性能问题 case**

在 Day10 我们讲过：`会员分页 + 按创建时间倒序` 走全表扫描 30 万数据，接口 3s+，并发 100 时 CPU 打满。今天用**线上排查思路**倒推：

1. 运营反馈"会员列表页很慢"。
2. `top` 看 java 进程 CPU 600%。
3. `top -H -p pid` 找到 tid=15234。
4. `printf "%x\n" 15234` → 3b82。
5. `jstack pid | grep -A 20 "nid=0x3b82"`，看到线程栈卡在 `MemberMapper.selectPage`。
6. `tail -f logs/smart-elder.log | grep "Preparing:"` 抓到慢 SQL 原文。
7. 复制 SQL 到 MySQL：`EXPLAIN` 看到 `type=ALL`（Day10 内容），加索引 `create index idx_create_time on tb_member(create_time)`。
8. 部署新版本，问题消失。

**"运维排查 → 复盘到 SQL 层面 → 加索引"**，这是完整的问题闭环。

#### 3. 演示（10 分钟）
教师造两个"活体故障"：
- **场景 A**：写一个死循环 Controller `@GetMapping("/bomb") while(true) x++;` 演示 CPU 100% 从 `top` 一步步定位到那一行代码。
- **场景 B**：写一个 `static List<byte[]> leak = new ArrayList<>()`，接口里每次 `leak.add(new byte[1024*1024])`，演示 `jstat -gcutil` 观察 Full GC → jmap dump → 定位到 leak 变量。

用 Arthas 的 `dashboard` 展示 JVM 实时状态，学生能直观感受这个工具有多顺手。

#### 4. 实操（9 分钟）
学生任务：
1. 每人在自己项目里加一个 `/api/bomb` 接口（死循环），部署上线。
2. curl 触发，用 `top`、`top -H -p`、`jstack` 走完 5 步，找出那行代码。
3. 用 Arthas 的 `thread -b` 命令找"最忙线程"，验证结果一致。
4. 排查完立刻把接口注释掉，重新部署。

#### 5. 小结（3 分钟）
**线上排查三板斧：看日志、看进程、看堆栈**。CPU 100% 五步、内存泄漏 dump、Arthas 三大神器（`dashboard/trace/watch`）——面试高频考点。**学会这套技能，才敢自称"能上线"**。下节课收尾：上线检查清单 + 回滚方案。

### 四、课上提问
1. `top -H` 中的 `-H` 是什么意思？
2. `nid=0x3b82` 里的 `nid` 是什么？为什么是十六进制？
3. Arthas 的 `trace` 和 `watch` 有什么区别？

### 五、课堂练习
1. 写一句 Arthas 命令：追踪 `RoomController.list` 方法的执行耗时，深度 2。
   （参考答：`trace com.itcast.smart_elder.controller.RoomController list -n 5`）
2. 用 `jstat -gc pid 1000` 输出中的 `YGC/YGCT/FGC/FGCT` 分别代表什么？

### 六、课后思考
线上系统突然 OOM 挂掉，进程都没了，怎么拿 heap dump？（提前配置 `-XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/app/dumps/`，OOM 时 JVM 自动 dump。）

### 七、课后作业
1. 在 `start.sh` / systemd unit / docker `JAVA_OPTS` 里加上 OOM 自动 dump 参数。
2. Git 提交 `chore(ops): oom dump path`。

### 八、板书设计
```
┌────────────────────────────────────────────────┐
│  Day11-05  线上故障排查                        │
├────────────────────────────────────────────────┤
│ 日志：tail -f  |  grep -i error  |  less +F    │
│ CPU100%：top → top -H -p → printf %x → jstack  │
│ 内存漏：jstat -gcutil → jmap dump → MAT        │
│ Arthas：dashboard / thread / trace / watch     │
│ 案例：Day03 分页 3s → 加索引 200ms             │
└────────────────────────────────────────────────┘
```

---

## 第 6 课时：上线检查清单与回滚方案

### 一、教学目标
- 知识目标：理解"发版≠上线"，**上线是一次风险作业**，必须有 checklist、有回滚预案；掌握上线前 15 项检查清单（配置、数据库、依赖、监控、日志、备份、灰度、回滚点、审计……）；理解**灰度发布**与**蓝绿发布**两种平滑升级策略的差异与适用场景；掌握 Docker 环境下**基于镜像 tag 的一键回滚**方法；能画出发布出问题时的完整回滚流程图。
- 能力目标：学生领到一份 Checklist 后能在自己项目上打勾走一遍；能在灰度期发现问题后 5 分钟内触发回滚。

### 二、教学重难点
- 重点：Checklist 里最容易忽略但最致命的 3 项——**数据库备份、配置漂移检查、监控告警接入**；镜像 tag 策略（`smart-elder-backend:v1.0.0` / `:v1.0.1` / `:latest`）与 `docker-compose down/up` 快速切版本。
- 难点：**灰度发布**里"权重路由 + 请求打标"的技术实现（Nginx `upstream` 权重、K8s Ingress、SkyWalking 灰度头），本节仅做认知，不要求代码。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："项目终于要上线了，兴奋不？但假设你今天下午 3 点上线，晚上 8 点用户开始骂'AI 对话报错'——你现在是选择：A. 熬夜加班改 bug ？ B. 回滚到昨天的稳定版本，明天再修？"

答案永远是 **B**，因为**用户等不起**。但要做到"5 分钟内回滚"，必须提前准备。所以今天讲两件事：**Checklist 保证上得稳 + Rollback 保证下得快**。

#### 2. 讲授（18 分钟）

**（1）上线检查清单（15 项）**

分四个阶段（发前 / 发中 / 发后 / 回滚点）：

| # | 分类 | 检查项 | 通过标准 |
|---|------|--------|---------|
| 1 | 代码 | 已合并主干、代码评审通过 | PR merged, +2 approve |
| 2 | 代码 | CI 全部通过（单元测试、集成测试） | Jenkins/Actions 全绿 |
| 3 | 配置 | `application-prod.yml` 数据库/Redis/OSS 密钥都对 | 与生产 Vault 或 Nacos 一致 |
| 4 | 配置 | 环境变量 `DB_PASSWORD` 等未硬编码 | grep 检查不含明文 |
| 5 | 数据 | **上线前完整备份数据库**（`mysqldump`） | `.sql` 文件 >0，能 restore |
| 6 | 数据 | 本次涉及的表结构变更（DDL）已在生产执行 | flyway/liquibase 或手工执行 |
| 7 | 依赖 | 依赖服务（AI 大模型 API、OSS、支付）密钥在期 | 调用测试通过 |
| 8 | 部署 | Docker 镜像已构建并推到私有仓库 | `docker pull` 拉得到 |
| 9 | 部署 | 保留上一版本镜像 tag（用于回滚） | `docker images \| grep smart-elder` 有 v1.0.0 与 v1.0.1 |
| 10 | 监控 | Prometheus/Grafana/日志平台已接入 | 大盘可见新版本指标 |
| 11 | 监控 | 关键告警（CPU>85%、5xx>1%、RT>2s）已配置 | 告警群收到测试通知 |
| 12 | 日志 | 日志级别为 INFO（非 DEBUG） | `logback-spring.xml` 校对 |
| 13 | 灰度 | 先发布 10% 流量灰度节点，观察 15 分钟 | 无异常再全量 |
| 14 | 回滚 | 回滚流程 5 分钟内可完成 | 演练过 |
| 15 | 通知 | 产品/运营/客服知晓本次上线内容与时间 | 发布公告 |

**这份清单要打印贴在墙上**，每次发版负责人签字画勾。

**（2）灰度 vs 蓝绿**

| 策略 | 做法 | 优点 | 缺点 |
|------|-----|------|------|
| **灰度发布** | 只把 N% 用户流量导到新版本 | 影响面小，可回滚 | 需要能按用户/权重分流 |
| **蓝绿部署** | 完整跑两套环境（蓝=旧，绿=新），切开关 | 秒级切换 | 资源翻倍 |
| **滚动发布** | K8s 逐 Pod 替换 | 无停机 | 中间态有版本混杂 |

我们的项目单机 docker-compose，一般走**"镜像 tag 快速切换"** 的类蓝绿：新镜像跑通后，把 compose 里的 `image: smart-elder-backend:v1.0.1` 改成 `:v1.0.2`，`docker-compose up -d backend` 秒级更新；有问题改回 `:v1.0.1` 秒级回滚。

**（3）Docker 回滚三条命令**

```bash
# 1. 查看当前跑的镜像 tag
docker inspect --format='{{.Config.Image}}' elder-backend
# 输出：smart-elder-backend:v1.0.2

# 2. 改 docker-compose.yml
# 把 image: smart-elder-backend:v1.0.2 改回 v1.0.1

# 3. 一键回滚（只重启 backend 服务）
docker-compose up -d backend
```
**3 步、30 秒内完成**。前提：v1.0.1 的镜像仍在本机或私有仓库。

**如果有数据库结构变更（DDL）**，回滚更复杂：
- **加字段/表**：兼容型，旧代码能忽略新字段，回滚只回代码即可。
- **删字段/改字段类型**：破坏型，需要**先备份 → 手工回滚 DDL**。
- **DML 数据脚本**：需要"补偿脚本"（redo/undo 双份）。

原则：**上线的 DDL 尽量只做"加"，不做"改/删"**。

**（4）完整回滚流程图**

```
        ┌────────────────┐
        │  上线 v1.0.2   │
        └────────┬───────┘
                 │
        ┌────────▼────────┐
        │ 灰度 10%  15min │
        └────────┬────────┘
                 │
    ┌────────────┴────────────┐
    │                         │
[无异常]                    [告警/用户投诉]
    │                         │
全量发布 v1.0.2         ┌─────▼─────┐
    │                   │ 立即冻结  │
    │                   │  新请求？ │
    │                   └─────┬─────┘
    │                          │
    │            ┌─────────────▼────────────┐
    │            │ 判断变更类型             │
    │            └────┬────────────┬────────┘
    │                 │            │
    │           [仅代码/配置]   [含 DDL]
    │                 │            │
    │        docker-compose   备份→执行 undo
    │        image: v1.0.1        SQL
    │        up -d backend        │
    │                 │            │
    │        curl 健康检查   docker rollback
    │                 │            │
    │        通知 / 复盘 / 事后    │
    │                 └────────────┘
    │
   完成
```

**（5）事后复盘（Postmortem）**

回滚不是终点，**复盘**才是。模板：
1. 时间线（几点几分发生什么）
2. 影响范围（哪些接口/多少用户/多久）
3. 根因（技术根因 + 流程根因）
4. 短期修复（本次做了什么）
5. 长期改进（下一版本、SOP、监控增强）

#### 3. 演示（9 分钟）
教师现场演练一次**回滚**：
1. 手上先备一份 `smart-elder-backend:v1.0.1` 镜像。
2. 构建新版本 `smart-elder-backend:v1.0.2`，故意在 `MemberController` 加一个 `throw new RuntimeException("模拟 bug")`。
3. `docker-compose up -d backend` 发布 → 触发接口 → 报 500。
4. **回滚**：改 `docker-compose.yml` 的 tag → `up -d backend` → 接口正常。全程掐表 45 秒。
5. 打开 checklist 走一遍事后复盘"应该在灰度阶段就发现"。

#### 4. 实操（10 分钟）
学生任务：
1. 打两个 tag（`v1.0.0` 与 `v1.0.1`），在 `v1.0.1` 里改一行代码（把 `/api/hello` 返回改成 "world v2"）。
2. 按流程发布 → 验证 → 回滚 → 验证。掐时间。
3. 打印一份 Checklist（教材附录），画勾走一遍，标出哪几项自己没做。

#### 5. 小结（3 分钟）
**Day11 六课时走完了从"jar 变服务"到"服务出事故也能扛"的全链路**。今天最重要的话：**能 5 分钟回滚的上线才敢做**。Day12 项目就业指导会把 Day11 的所有能力包装成简历里"运维亮点"。

### 四、课上提问
1. 上线前必做的 3 项检查你会选哪 3 个？
2. 灰度 5%、10%、50%、100% 的经典节奏叫什么？（渐进式发布）
3. DDL 上线的黄金原则是什么？（只加不删；破坏性变更做双写过渡）

### 五、课堂练习
1. 为你的项目写一份**《XX 系统上线 SOP》**（1 页 A4，参考本课 Checklist）。
2. 演练"发布 → 触发 bug → 回滚"完整流程，录 1 分钟视频。

### 六、课后思考
如果你负责一家日活百万的公司的电商系统，Checklist 应该扩展到多少项？（工业界普遍 30-50 项，含容量评估、限流开关、大促预案、数据库主从延迟、消息队列积压……）

### 七、课后作业
1. 把 Checklist 存到项目 wiki 或 README 中。
2. Git 打 tag：`git tag -a v1.0.0 -m "first release"` + `git push --tags`。

### 八、板书设计
```
┌────────────────────────────────────────────────┐
│  Day11-06  上线 & 回滚                         │
├────────────────────────────────────────────────┤
│ 上线 = 风险作业 → Checklist 15 项              │
│ 灰度 10% → 15min → 全量                        │
│ 回滚 = 改 image tag + up -d = 30s              │
│ DDL 原则：只加不删；破坏性双写                 │
│ 上线后 → 复盘 Postmortem                       │
└────────────────────────────────────────────────┘
```

---

## Day11 教学总结

至此我们完成了**部署运维完整闭环**：

1. **环境**：一台空 Linux → JDK17 + MySQL8 + Redis7 三件套就位。
2. **手工部署**：`mvn package` → `nohup / systemd` 起服务 → Nginx 挂前端 + 反代 → 全链路 80 端口打通。
3. **容器部署**：两个 Dockerfile（多阶段构建）+ docker-compose（四服务 + healthcheck + volumes）→ 一条命令 `up -d`。
4. **故障排查**：三板斧（日志/进程/堆栈）+ CPU 五步 + Arthas 神器 + Day03 分页 case 复盘。
5. **上线运维**：15 项 Checklist + 灰度 / 蓝绿认知 + Docker tag 回滚 + Postmortem 模板。

**串课线索：**
- **回顾**：Day01 建表脚本今天导入生产 MySQL；Day02 打包骨架今天变 fat-jar；Day05 SSE 今天用 Nginx `proxy_buffering off` 兜住；Day08 大屏今天访问的就是 Nginx 反代过来的接口；Day09 操作日志今天在生产里滚起来了；Day10 慢 SQL 今天用 Arthas 反查了一遍。
- **展望**：Day12 面试话术里，"能独立完成 Linux 服务器部署 + Docker 容器化 + 线上故障排查"是极高分的亮点，请学生今天把 Checklist 与两个 Dockerfile、docker-compose.yml、nginx.conf、systemd unit 全部整理成一份 `/deploy/README.md`，明天带来。
