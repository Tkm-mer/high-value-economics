# 《智能养老社区系统》- 教师教案 - Day03：会员管理模块开发

**授课日：Day 03 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 5 - 完成会员管理（CRUD、分页、校验、逻辑删除、前后端联调）**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day02 已完成 SpringBoot + MyBatis-Plus 后端骨架、Vue3 + Element Plus 前端骨架、Hello 接口联调、Result/PageBean 统一封装**

---

## 第 1 课时：会员业务分析与接口约定

### 一、教学目标
- 知识目标：理解会员业务在养老社区系统中的定位；掌握 RESTful 风格接口 URL 命名规范；理解会员生命周期（注册 → 审核 → 激活 → 停用/注销）；能够独立拆解出一组 CRUD 接口的请求方法、URL、参数、返回值。
- 能力目标：能根据一句话业务需求（如"要做一个会员管理"）反推出至少 6 个接口约定，并用 Markdown 表格清晰输出接口文档，为后续 Mapper/Service/Controller 编码打好蓝图。

### 二、教学重难点
- 重点：6 个会员接口的 URL/请求方式/请求参数/响应结构；Result/PageBean 在真实业务下的复用方式。
- 难点：如何用 RESTful 风格区分"整体修改"和"单字段修改"（PUT /api/members 与 PUT /api/members/status 的差别）；分页查询的参数放 body 还是 query 的取舍。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
提问："各位如果你现在要接管社区的会员登记，你会怎么用 Excel 管理？"引导学生列出：登记（新增）、查看名单（列表分页）、修改错别字（更新）、销户（删除）、看某位老人的详细档案（详情）、临时冻结账号（改状态）。教师顺势画出对应的六个动作，写在黑板上，并宣布："今天就把这六个动作变成六个真正的 HTTP 接口，明天前端就可以调。"

#### 2. 讲授（18 分钟）
（1）先带学生回顾 Day01 建的 `elder_member` 表结构，明确字段：id、name、gender、age、phone、id_card、address、emergency_contact、health_status、member_level、create_time、update_time、deleted。强调 `deleted` 字段用于逻辑删除，不是物理 DROP。

（2）讲解 RESTful 命名约定：

| 动作 | 请求方式 | URL | 参数位置 |
|------|----------|-----|----------|
| 分页查询 | GET | /api/members/page | query |
| 详情回显 | GET | /api/members/{id} | path |
| 新增 | POST | /api/members | body(JSON) |
| 修改 | PUT | /api/members | body(JSON) |
| 批量删除 | DELETE | /api/members/{ids} | path(逗号分隔) |
| 启用/停用 | PUT | /api/members/status | body(JSON) |

（3）强调三个"约定"：接口前缀统一 `/api`；DTO 只装接收参数，VO 只装返回参数，Entity 只映射数据库；一切响应都用 `Result<T>` 包一层，分页数据用 `PageBean<ElderMember>` 装。

（4）画出前后端交互时序图（黑板画简图），让学生直观理解"前端拿到 `code=1` 才算成功，`code=0` 弹错误提示"。

#### 3. 演示（10 分钟）
教师在 IDEA 中新建 `docs/api/member.md`，逐个把 6 个接口的示例请求、示例响应贴出来。示例如下（教师现场敲）：

```http
### 分页查询
GET /api/members/page?name=张&phone=138&pageNum=1&pageSize=10

响应：
{
  "code": 1,
  "msg": "success",
  "data": {
    "total": 128,
    "rows": [
      { "id": 1, "name": "张桂芳", "phone": "13800001111", "memberLevel": "GOLD", ... }
    ]
  }
}
```

```http
### 新增
POST /api/members
Content-Type: application/json

{
  "name": "李建国",
  "gender": "男",
  "age": 72,
  "phone": "13900002222",
  "idCard": "410102195301011234",
  "address": "郑州市金水区花园路 88 号",
  "emergencyContact": "李小刚 13700003333",
  "healthStatus": "良好",
  "memberLevel": "SILVER"
}

响应： { "code": 1, "msg": "success", "data": null }
```

#### 4. 实操（10 分钟）
学生任务：以两人为一组，仿照教师的接口文档，为"启用/停用"和"批量删除"两个接口分别写出完整的请求/响应示例，粘贴到自己的 `docs/api/member.md`。教师巡视，纠正 URL 写法（例如把 `/api/member/status` 复数写掉的错误）。

#### 5. 小结（3 分钟）
回顾 6 个接口的 URL 表，强调"接口先约定、代码后开发"是工程化的关键，下一节课直接按今天定好的第一个接口（分页）动手编码。

### 四、课上提问
1. `/api/members` 用 POST 和 PUT 分别代表什么？为什么不能用 GET 做新增？
2. 分页参数为什么放在 query 上而不是 body 里？
3. 如果一次要删 10 个会员，URL 该怎么写？

### 五、课堂练习
1. 在 `docs/api/member.md` 中补齐 6 个接口的完整表格（含字段类型）。
2. 用 Apifox 或 Postman 新建一个"智能养老-会员"接口分组，占位 6 个空请求。

### 六、课后思考
如果会员一旦被"停用"就再也无法登录，那"停用"和"逻辑删除"有什么本质区别？各自适用什么业务场景？

### 七、课后作业
1. 完善接口文档，为每个接口标注错误码（1=成功，0=业务失败，401=未登录）。
2. 阅读 MyBatis-Plus 官网"条件构造器"章节，为明天的分页做预习。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  会员业务分析与接口约定                    │
├────────────────────────────────────────────┤
│ 1. 生命周期：注册→审核→激活→停用           │
│ 2. 六大接口：page/add/upd/del/get/status   │
│ 3. RESTful：名词复数 + HTTP 动词           │
│ 4. 统一响应：Result<T>、PageBean<T>        │
│ 5. 常见错误：单复数、GET 传 body           │
└────────────────────────────────────────────┘
```

---

## 第 2 课时：会员分页查询接口开发

### 一、教学目标
- 知识目标：掌握 MyBatis-Plus 的 `IPage` 分页对象和 `LambdaQueryWrapper` 条件构造器；理解分页插件的注册；能够独立完成 Controller → Service → Mapper 三层落地。
- 能力目标：能根据前端传来的查询参数动态拼接 SQL，实现"姓名模糊 + 手机号模糊 + 会员等级精确"的分页查询，并用 Postman 验证结果。

### 二、教学重难点
- 重点：`Page<T>` 对象的构造与 `page(page, wrapper)` 的返回值转换；`LambdaQueryWrapper` 的 `like`、`eq` 与 `StringUtils.hasText` 联用做条件判断。
- 难点：MyBatis-Plus 分页插件在 Day02 骨架里的注册位置；把 `IPage` 转成课程内自定义的 `PageBean` 的字段映射。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示前端草图：一个带姓名/手机号/等级的搜索栏 + 一张会员表格 + 底部的分页组件。提问："如果表里有 5000 条数据，你会一次全查出来吗？"引出分页必要性。

#### 2. 讲授（15 分钟）
（1）先讲 MyBatis-Plus 分页插件的注册，学生打开 Day02 已经写好的 `MybatisPlusConfig`，教师在黑板上把关键代码提炼：

```java
@Configuration
public class MybatisPlusConfig {
    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}
```

（2）讲 DTO 概念：`MemberPageDTO` 只放"接收前端参数"的字段，不与实体耦合。强调 `pageNum` 默认 1、`pageSize` 默认 10 的兜底写法。

（3）讲 `LambdaQueryWrapper` 与 `StringUtils.hasText`：

| 场景 | 代码 | 生成 SQL 片段 |
|------|------|---------------|
| 姓名有值 | `.like(hasText(name), ElderMember::getName, name)` | AND name LIKE '%张%' |
| 手机号有值 | `.like(hasText(phone), ElderMember::getPhone, phone)` | AND phone LIKE '%138%' |
| 等级精确 | `.eq(hasText(level), ElderMember::getMemberLevel, level)` | AND member_level = 'GOLD' |
| 未删除 | `.eq(ElderMember::getDeleted, 0)` | AND deleted = 0 |
| 按时间倒序 | `.orderByDesc(ElderMember::getCreateTime)` | ORDER BY create_time DESC |

#### 3. 演示（12 分钟）
教师现场按分层顺序敲代码：

**DTO**
```java
package com.itcast.smart_elder.dto;

import lombok.Data;

@Data
public class MemberPageDTO {
    private String name;
    private String phone;
    private String memberLevel;
    private Integer pageNum = 1;
    private Integer pageSize = 10;
}
```

**Controller**
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.dto.MemberPageDTO;
import com.itcast.smart_elder.entity.ElderMember;
import com.itcast.smart_elder.service.MemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/members")
@RequiredArgsConstructor
public class MemberController {

    private final MemberService memberService;

    @GetMapping("/page")
    public Result<PageBean<ElderMember>> page(MemberPageDTO dto) {
        return Result.success(memberService.page(dto));
    }
}
```

**Service 接口 + 实现**
```java
public interface MemberService {
    PageBean<ElderMember> page(MemberPageDTO dto);
}

@Service
@RequiredArgsConstructor
public class MemberServiceImpl implements MemberService {

    private final MemberMapper memberMapper;

    @Override
    public PageBean<ElderMember> page(MemberPageDTO dto) {
        Page<ElderMember> p = new Page<>(dto.getPageNum(), dto.getPageSize());
        LambdaQueryWrapper<ElderMember> wrapper = new LambdaQueryWrapper<ElderMember>()
                .like(StringUtils.hasText(dto.getName()), ElderMember::getName, dto.getName())
                .like(StringUtils.hasText(dto.getPhone()), ElderMember::getPhone, dto.getPhone())
                .eq(StringUtils.hasText(dto.getMemberLevel()), ElderMember::getMemberLevel, dto.getMemberLevel())
                .orderByDesc(ElderMember::getCreateTime);
        IPage<ElderMember> result = memberMapper.selectPage(p, wrapper);
        return new PageBean<>(result.getTotal(), result.getRecords());
    }
}
```

**Mapper**
```java
public interface MemberMapper extends BaseMapper<ElderMember> { }
```

演示完成后启动 SpringBoot，用 Postman 发 `GET /api/members/page?name=张&pageNum=1&pageSize=5`，展示真实响应。

#### 4. 实操（12 分钟）
学生跟着编写全套代码，教师在讲台前用 Ctrl+Shift+F10 反复演示"重启并请求"，学生在自己电脑上重复。目标：能返回 `data.total > 0` 并看到自己 Day01 灌入数据库的种子数据。

#### 5. 小结（3 分钟）
强调今天首个真正意义上的业务接口跑通了。3 个知识点必须记牢：`Page<>` 构造、`LambdaQueryWrapper` 条件判断、`Result.success` 包裹。

### 四、课上提问
1. 分页插件如果不注册会怎样？（答：SQL 后不会自动拼 LIMIT，返回全表）
2. `hasText` 和 `hasLength` 有什么区别？
3. 为什么用 `IPage` 不直接用 `Page`？

### 五、课堂练习
1. 增加一个"按年龄区间"筛选（age >= min 且 age <= max）。
2. 把排序改成"先按等级降序，再按创建时间降序"。

### 六、课后思考
分页跳到第 10000 页时性能急剧下降，为什么？可以怎么优化？

### 七、课后作业
1. 补齐"按性别查询"条件。
2. 阅读 MyBatis-Plus 文档 `IPage` 与 `Page` 章节，写 300 字读书笔记。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  会员分页查询                              │
├────────────────────────────────────────────┤
│ 1. Page<T> p = new Page<>(num, size)       │
│ 2. LambdaQueryWrapper + hasText            │
│ 3. selectPage(p, wrapper)                  │
│ 4. IPage → PageBean 转换                   │
│ 5. 常见错误：忘了注册分页插件              │
└────────────────────────────────────────────┘
```

---

## 第 3 课时：会员新增与修改接口

### 一、教学目标
- 知识目标：掌握 `@Valid` + JSR303 注解校验（`@NotBlank`、`@Pattern`、`@Min`、`@Max`）；理解 `MethodArgumentNotValidException` 的统一处理；掌握 MyBatis-Plus 的 `save`、`updateById` 用法；理解通用字段自动填充 `MetaObjectHandler`。
- 能力目标：能独立写出带前端校验+后端校验双保险的新增接口，并对更新接口做主键必填校验。

### 二、教学重难点
- 重点：`@Valid` 的位置、常用校验注解的正则规则；`MetaObjectHandler` 中 `insertFill` 和 `updateFill` 的区别。
- 难点：全局异常处理拦截参数校验异常，把字段错误信息友好地拼成 msg 返回给前端。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"如果前端不填手机号就点提交，接口会怎样？"教师故意用 Postman 发一个不带 phone 的新增请求，让 500 报错出现在屏幕上，制造问题情境。

#### 2. 讲授（15 分钟）
（1）JSR303 常用注解速览：

| 注解 | 作用 | 示例 |
|------|------|------|
| @NotBlank | 字符串非空 | @NotBlank(message="姓名必填") |
| @NotNull | 对象非空 | @NotNull(message="年龄必填") |
| @Pattern | 正则匹配 | @Pattern(regexp="^1[3-9]\\d{9}$") |
| @Min/@Max | 数值区间 | @Min(0) @Max(120) |
| @Size | 长度区间 | @Size(min=2,max=20) |

（2）讲 `@Valid` 必须写在 Controller 参数前，配合 `@RequestBody` 才生效；若校验失败会抛 `MethodArgumentNotValidException`，需要全局异常拦截并拼装 `BindingResult`。

（3）讲通用字段自动填充：`create_time` 只在 insert 时填、`update_time` 在 insert 和 update 时都填。核心是实现 `MetaObjectHandler` 并在字段上加 `@TableField(fill=FieldFill.INSERT)` 或 `INSERT_UPDATE`。

#### 3. 演示（12 分钟）

**Entity**
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@TableName("elder_member")
public class ElderMember {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String name;
    private String gender;
    private Integer age;
    private String phone;
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    private String memberLevel;
    private Integer status; // 1 启用 0 停用
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;
    @TableLogic
    private Integer deleted;
}
```

**DTO**
```java
@Data
public class MemberAddDTO {
    @NotBlank(message = "姓名必填")
    @Size(min = 2, max = 20, message = "姓名长度 2-20")
    private String name;
    @NotBlank(message = "性别必填")
    private String gender;
    @NotNull(message = "年龄必填")
    @Min(value = 0, message = "年龄非法")
    @Max(value = 120, message = "年龄非法")
    private Integer age;
    @NotBlank(message = "手机号必填")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String phone;
    @NotBlank(message = "身份证必填")
    @Pattern(regexp = "^\\d{17}[0-9Xx]$", message = "身份证格式不正确")
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    @NotBlank(message = "会员等级必填")
    private String memberLevel;
}
```

**MetaObjectHandler**
```java
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {
        this.strictInsertFill(metaObject, "createTime", LocalDateTime.class, LocalDateTime.now());
        this.strictInsertFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
    }
    @Override
    public void updateFill(MetaObject metaObject) {
        this.strictUpdateFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
    }
}
```

**Controller 追加**
```java
@PostMapping
public Result<Void> add(@RequestBody @Valid MemberAddDTO dto) {
    memberService.add(dto);
    return Result.success();
}

@PutMapping
public Result<Void> update(@RequestBody @Valid MemberUpdateDTO dto) {
    memberService.update(dto);
    return Result.success();
}
```

**Service 实现**
```java
@Override
public void add(MemberAddDTO dto) {
    ElderMember m = new ElderMember();
    BeanUtils.copyProperties(dto, m);
    m.setStatus(1);
    memberMapper.insert(m);
}

@Override
public void update(MemberUpdateDTO dto) {
    ElderMember m = new ElderMember();
    BeanUtils.copyProperties(dto, m);
    memberMapper.updateById(m);
}
```

**全局异常**
```java
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(FieldError::getDefaultMessage)
                .collect(Collectors.joining("；"));
        return Result.fail(msg);
    }
}
```

#### 4. 实操（12 分钟）
学生把上面代码补齐后，用 Postman 发一个手机号错误的新增请求，观察返回是否是 `{"code":0,"msg":"手机号格式不正确"}`。再发一个正确请求，查询数据库确认 `create_time` 有值。

#### 5. 小结（3 分钟）
"双保险"记法：前端 UI 提示 + 后端 @Valid 兜底。永远不要相信前端传来的任何数据。

### 四、课上提问
1. `@Valid` 和 `@Validated` 有什么区别？
2. 如果 `@RequestBody` 忘写 `@Valid`，校验注解还会生效吗？
3. `strictInsertFill` 与 `setInsertFieldValByName` 差别是什么？

### 五、课堂练习
1. 增加身份证 15 位兼容校验（老一辈可能是 15 位身份证号）。
2. 添加"手机号在库中唯一"的业务校验（Service 层查一次）。

### 六、课后思考
如果批量新增 1 万个会员，应该怎么写？还能用 `insert` 一条条插吗？

### 七、课后作业
1. 完成 `MemberUpdateDTO`（含 `@NotNull` id）。
2. 补齐 `create_by` `update_by` 两个字段的自动填充（值先写死 "admin"）。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  新增与修改                                │
├────────────────────────────────────────────┤
│ 1. @Valid + JSR303                         │
│ 2. 手机号 ^1[3-9]\d{9}$                    │
│ 3. 身份证 ^\d{17}[0-9Xx]$                  │
│ 4. MetaObjectHandler 自动填充              │
│ 5. GlobalExceptionHandler 统一返回         │
└────────────────────────────────────────────┘
```

---

## 第 4 课时：会员删除与详情回显

### 一、教学目标
- 知识目标：掌握 MyBatis-Plus 的 `@TableLogic` 逻辑删除；掌握路径变量 `List<Long>` 与逗号分隔 `String ids` 的两种批量删除写法；掌握根据 id 查详情并返回 VO（脱敏身份证）。
- 能力目标：能设计出符合"幂等"的删除接口——同一份请求发多次结果一致；能封装 VO 屏蔽敏感字段。

### 二、教学重难点
- 重点：`@TableLogic` 的原理（update deleted=1）；路径变量收集为 `List<Long>` 的两种 Spring MVC 写法。
- 难点：VO 与 Entity 的取舍——什么时候用 Entity 直接返回，什么时候必须封 VO。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"如果误删了张桂芳老人，还想找回来怎么办？"引出逻辑删除；"页面刷了一下网络，删除请求发了两次，会不会报错？"引出幂等性。

#### 2. 讲授（15 分钟）
（1）`@TableLogic` 原理：MyBatis-Plus 在编译期把 `DELETE` 语句改写成 `UPDATE ... SET deleted=1`，同时所有 `select` 自动带 `WHERE deleted=0`。字段值可通过 `application.yml` 配置：

```yaml
mybatis-plus:
  global-config:
    db-config:
      logic-delete-field: deleted
      logic-delete-value: 1
      logic-not-delete-value: 0
```

（2）批量删除的两种入参：路径逗号 `DELETE /api/members/1,2,3` → Spring 会自动把它转成 `List<Long> ids`（因为 `,` 是默认分隔符）。

（3）VO 设计要点：涉及个人隐私字段（身份证、手机号）必须脱敏——如身份证 `410102********1234`，手机号 `138****1111`。

#### 3. 演示（12 分钟）

**Controller**
```java
@DeleteMapping("/{ids}")
public Result<Void> delete(@PathVariable List<Long> ids) {
    memberService.deleteByIds(ids);
    return Result.success();
}

@GetMapping("/{id}")
public Result<MemberVO> getById(@PathVariable Long id) {
    return Result.success(memberService.getVOById(id));
}

@PutMapping("/status")
public Result<Void> updateStatus(@RequestBody MemberStatusDTO dto) {
    memberService.updateStatus(dto);
    return Result.success();
}
```

**Service 实现追加**
```java
@Override
public void deleteByIds(List<Long> ids) {
    if (CollectionUtils.isEmpty(ids)) return;
    memberMapper.deleteBatchIds(ids);
}

@Override
public MemberVO getVOById(Long id) {
    ElderMember m = memberMapper.selectById(id);
    if (m == null) return null;
    MemberVO vo = new MemberVO();
    BeanUtils.copyProperties(m, vo);
    vo.setIdCard(desensitizeIdCard(m.getIdCard()));
    vo.setPhone(desensitizePhone(m.getPhone()));
    return vo;
}

@Override
public void updateStatus(MemberStatusDTO dto) {
    ElderMember m = new ElderMember();
    m.setId(dto.getId());
    m.setStatus(dto.getStatus());
    memberMapper.updateById(m);
}

private String desensitizeIdCard(String idCard) {
    if (idCard == null || idCard.length() < 10) return idCard;
    return idCard.substring(0, 6) + "********" + idCard.substring(idCard.length() - 4);
}

private String desensitizePhone(String phone) {
    if (phone == null || phone.length() != 11) return phone;
    return phone.substring(0, 3) + "****" + phone.substring(7);
}
```

**MemberVO**
```java
@Data
public class MemberVO {
    private Long id;
    private String name;
    private String gender;
    private Integer age;
    private String phone;
    private String idCard;
    private String address;
    private String emergencyContact;
    private String healthStatus;
    private String memberLevel;
    private Integer status;
    private LocalDateTime createTime;
}
```

**MemberStatusDTO**
```java
@Data
public class MemberStatusDTO {
    @NotNull(message = "id 必填")
    private Long id;
    @NotNull(message = "状态必填")
    @Min(value = 0, message = "状态只能是 0 或 1")
    @Max(value = 1, message = "状态只能是 0 或 1")
    private Integer status;
}
```

#### 4. 实操（12 分钟）
学生逐一测试：
- `DELETE /api/members/1,2,3` → 数据库 `deleted` 变 1，再查 page 看不到。
- `GET /api/members/1` → 身份证被打码。
- `PUT /api/members/status` body `{"id":5,"status":0}` → status 变 0。

再让学生反复点击"停用"按钮 3 次，观察是否报错——引导思考幂等性。

#### 5. 小结（3 分钟）
逻辑删除是"业务软删"，物理 DROP 慎用；VO 是"给外面看的样子"，Entity 是"给数据库看的样子"，两者边界要清。

### 四、课上提问
1. 如果 `deleted` 字段没加 `@TableLogic`，会发生什么？
2. 批量删除接口如果 ids 为空，怎么处理？
3. 身份证脱敏一定要在服务端做吗？

### 五、课堂练习
1. 加一个"根据手机号查会员"的接口 `GET /api/members/byPhone/{phone}`。
2. 让 `deleteByIds` 打印一条 log，记录操作时间和被删 id。

### 六、课后思考
逻辑删除后如何做"恢复"功能？表结构还需要加什么字段？

### 七、课后作业
1. 完成"根据手机号查会员"接口。
2. 补齐 `MemberVO` 中把 `memberLevel` 转成中文的逻辑（GOLD→金卡，SILVER→银卡）。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  删除 & 详情                               │
├────────────────────────────────────────────┤
│ 1. @TableLogic 逻辑删除                    │
│ 2. DELETE /ids → List<Long>                │
│ 3. VO 脱敏：身份证 & 手机号                │
│ 4. status 接口独立设计                     │
│ 5. 幂等性：多次调用结果一致                │
└────────────────────────────────────────────┘
```

---

## 第 5 课时：前端会员列表页面

### 一、教学目标
- 知识目标：掌握 Element Plus 的 `el-table`、`el-pagination`、`el-form` 组件；掌握 `<script setup>` + `reactive` 的组合式写法；掌握 `api/member.ts` 请求封装模式。
- 能力目标：能独立完成"搜索栏 + 表格 + 分页"的组合式页面，能对接后端 `/api/members/page` 返回数据并正确回显。

### 二、教学重难点
- 重点：`el-pagination` 的 `v-model:current-page` / `v-model:page-size` 双向绑定；`el-table` 的 `data` 绑定和 `@selection-change` 回调。
- 难点：分页参数与后端的字段名对齐（`pageNum/pageSize` 而非 Element Plus 默认的 `page/limit`）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
展示一张运营常见的会员管理页面截图（教学 PPT 有），提问："这个页面拆开有哪些区块？分别对应我们后端哪个接口？"引导学生说出：搜索区 → page 接口、表格区 → page 接口、分页区 → page 接口的 pageNum/pageSize、操作列 → 详情/编辑/删除三个接口。

#### 2. 讲授（15 分钟）
（1）目录约定：Vue3 项目 `src/views/member/list.vue` 存页面，`src/api/member.ts` 存所有请求方法。这样"页面只管视图，请求方法单独收拢，方便复用和 Mock"。

（2）Element Plus 三个组件的关键属性：

| 组件 | 关键属性 | 说明 |
|------|----------|------|
| el-form | :inline="true" | 让搜索栏横排 |
| el-table | :data / @selection-change | 数据绑定 & 多选回调 |
| el-pagination | v-model:current-page / :total | 页码双向绑定 |

（3）请求封装：Day02 已经写过 `src/utils/request.ts`，本节直接用。

#### 3. 演示（12 分钟）

**src/api/member.ts**（本节写前 3 个方法，后 3 个下节课补）
```typescript
import request from '@/utils/request'

export interface MemberPageParams {
  name?: string
  phone?: string
  memberLevel?: string
  pageNum: number
  pageSize: number
}

export const getMemberPage = (params: MemberPageParams) =>
  request.get('/api/members/page', { params })

export const getMemberById = (id: number | string) =>
  request.get(`/api/members/${id}`)

export const deleteMembers = (ids: (number | string)[]) =>
  request.delete(`/api/members/${ids.join(',')}`)
```

**src/views/member/list.vue**（本节聚焦搜索+表格+分页）
```vue
<template>
  <div class="member-list">
    <el-form :inline="true" :model="query" class="search-bar">
      <el-form-item label="姓名">
        <el-input v-model="query.name" placeholder="请输入姓名" clearable />
      </el-form-item>
      <el-form-item label="手机号">
        <el-input v-model="query.phone" placeholder="请输入手机号" clearable />
      </el-form-item>
      <el-form-item label="等级">
        <el-select v-model="query.memberLevel" placeholder="请选择" clearable style="width:120px">
          <el-option label="金卡" value="GOLD" />
          <el-option label="银卡" value="SILVER" />
          <el-option label="普通" value="NORMAL" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="loadData">查询</el-button>
        <el-button @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-table :data="tableData" v-loading="loading" @selection-change="onSelect">
      <el-table-column type="selection" width="55" />
      <el-table-column prop="id" label="编号" width="80" />
      <el-table-column prop="name" label="姓名" width="120" />
      <el-table-column prop="gender" label="性别" width="80" />
      <el-table-column prop="age" label="年龄" width="80" />
      <el-table-column prop="phone" label="手机号" width="140" />
      <el-table-column prop="memberLevel" label="等级" width="100" />
      <el-table-column prop="createTime" label="创建时间" width="180" />
    </el-table>

    <el-pagination
      class="pagination"
      v-model:current-page="query.pageNum"
      v-model:page-size="query.pageSize"
      :page-sizes="[10, 20, 50]"
      :total="total"
      layout="total, sizes, prev, pager, next, jumper"
      @size-change="loadData"
      @current-change="loadData"
    />
  </div>
</template>

<script setup lang="ts">
import { reactive, ref, onMounted } from 'vue'
import { getMemberPage, type MemberPageParams } from '@/api/member'

const query = reactive<MemberPageParams>({
  name: '',
  phone: '',
  memberLevel: '',
  pageNum: 1,
  pageSize: 10
})
const tableData = ref<any[]>([])
const total = ref(0)
const loading = ref(false)
const selected = ref<any[]>([])

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await getMemberPage(query)
    tableData.value = res.data.rows
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

const resetQuery = () => {
  query.name = ''
  query.phone = ''
  query.memberLevel = ''
  query.pageNum = 1
  loadData()
}

const onSelect = (rows: any[]) => { selected.value = rows }

onMounted(loadData)
</script>

<style scoped>
.search-bar { margin-bottom: 16px; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

启动前端 `pnpm dev`，路由跳到 `/member/list`，展示真实数据。

#### 4. 实操（12 分钟）
学生跟做，重点检查两点：
- 分页组件切页码时 pageNum 是否变化并触发 `loadData`。
- 搜索"张"时能否命中数据。

教师巡视，纠正 Element Plus 组件版本导致的属性差异（老版本用 `current-change`，新版本可以直接 `v-model:current-page`）。

#### 5. 小结（3 分钟）
"三段式"页面：搜索栏 + 表格 + 分页。三者共享同一个 `query` 对象，做好双向绑定就完成 80% 的运营页面。

### 四、课上提问
1. `v-model:current-page` 相当于什么写法的简写？
2. `@selection-change` 什么时候会触发？
3. `request.get` 返回的数据结构第一层是什么？

### 五、课堂练习
1. 给"等级"字段加一个格式化列，把 GOLD/SILVER/NORMAL 显示成中文。
2. 增加一个"重置搜索"按钮的图标。

### 六、课后思考
如果表格数据量特别大，第一次进入页面就加载所有列，会不会慢？可以怎么优化？

### 七、课后作业
1. 补齐"状态"列显示（用 `el-tag`：启用绿色、停用灰色）。
2. 页面加载时保留上一次搜索条件（利用 localStorage）。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  会员列表页                                │
├────────────────────────────────────────────┤
│ 1. api/member.ts 请求封装                  │
│ 2. reactive(query) 三段式共享              │
│ 3. el-table :data / selection              │
│ 4. el-pagination v-model                   │
│ 5. onMounted → loadData                    │
└────────────────────────────────────────────┘
```

---

## 第 6 课时：前端会员表单与联调

### 一、教学目标
- 知识目标：掌握 `el-dialog` 承载新增/修改表单；掌握 `el-form` 的 `rules` 校验与 `ref` 手动触发；掌握多选批量删除、`el-switch` 启用停用；理解前后端全链路 CRUD 联调流程。
- 能力目标：能独立完成"新增/修改/删除/启用停用"完整闭环，并处理错误提示、二次确认、Loading 状态。

### 二、教学重难点
- 重点：Dialog + Form 组合的复用（新增/修改共用一个表单）；`el-switch` 的 `active-value` / `inactive-value` 与后端 status 对齐。
- 难点：修改时 Dialog 打开先调详情接口回显数据；删除时的二次确认 `ElMessageBox.confirm`。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们只完成了看，今天要动。新增、修改、删除、启停 —— 这四个动作在企业开发里 90% 的运营页面都要写。"

#### 2. 讲授（15 分钟）
（1）表单复用的四步：Dialog `v-model` 控制显示；`form` 对象在打开时按需初始化（新增置空、修改回显）；提交时根据 form.id 是否存在决定调 add 或 update；提交后关闭 Dialog、刷新列表。

（2）rules 校验规则（与后端一致）：

| 字段 | 规则 |
|------|------|
| name | required + min:2 max:20 |
| phone | required + pattern:^1[3-9]\d{9}$ |
| idCard | required + pattern:^\d{17}[0-9Xx]$ |
| age | required + type:number + min:0 max:120 |
| memberLevel | required |

（3）`el-switch` 直接对接 `/api/members/status`，change 事件里发请求。

#### 3. 演示（15 分钟）

**src/api/member.ts 补齐**
```typescript
export const addMember = (data: any) => request.post('/api/members', data)
export const updateMember = (data: any) => request.put('/api/members', data)
export const updateMemberStatus = (data: { id: number; status: 0 | 1 }) =>
  request.put('/api/members/status', data)
```

**list.vue 增强：追加操作列 + Dialog**
```vue
<!-- 在 el-table 末尾追加操作列 -->
<el-table-column label="状态" width="90">
  <template #default="{ row }">
    <el-switch
      v-model="row.status"
      :active-value="1"
      :inactive-value="0"
      @change="(v) => onStatusChange(row, v)"
    />
  </template>
</el-table-column>
<el-table-column label="操作" width="200">
  <template #default="{ row }">
    <el-button link type="primary" @click="openEdit(row.id)">编辑</el-button>
    <el-button link type="danger" @click="onDelete([row.id])">删除</el-button>
  </template>
</el-table-column>
```

```vue
<!-- 搜索栏右侧按钮 -->
<el-form-item>
  <el-button type="primary" @click="loadData">查询</el-button>
  <el-button @click="resetQuery">重置</el-button>
  <el-button type="success" @click="openAdd">新增</el-button>
  <el-button type="danger" :disabled="!selected.length" @click="onBatchDelete">批量删除</el-button>
</el-form-item>
```

```vue
<!-- Dialog -->
<el-dialog v-model="dialogVisible" :title="form.id ? '编辑会员' : '新增会员'" width="600px">
  <el-form :model="form" :rules="rules" ref="formRef" label-width="90px">
    <el-form-item label="姓名" prop="name">
      <el-input v-model="form.name" />
    </el-form-item>
    <el-form-item label="性别" prop="gender">
      <el-select v-model="form.gender" style="width:100%">
        <el-option label="男" value="男" />
        <el-option label="女" value="女" />
      </el-select>
    </el-form-item>
    <el-form-item label="年龄" prop="age">
      <el-input-number v-model="form.age" :min="0" :max="120" />
    </el-form-item>
    <el-form-item label="手机号" prop="phone">
      <el-input v-model="form.phone" />
    </el-form-item>
    <el-form-item label="身份证" prop="idCard">
      <el-input v-model="form.idCard" />
    </el-form-item>
    <el-form-item label="地址">
      <el-input v-model="form.address" />
    </el-form-item>
    <el-form-item label="紧急联系人">
      <el-input v-model="form.emergencyContact" />
    </el-form-item>
    <el-form-item label="健康状况">
      <el-input v-model="form.healthStatus" />
    </el-form-item>
    <el-form-item label="会员等级" prop="memberLevel">
      <el-select v-model="form.memberLevel" style="width:100%">
        <el-option label="金卡" value="GOLD" />
        <el-option label="银卡" value="SILVER" />
        <el-option label="普通" value="NORMAL" />
      </el-select>
    </el-form-item>
  </el-form>
  <template #footer>
    <el-button @click="dialogVisible = false">取消</el-button>
    <el-button type="primary" @click="submit">保存</el-button>
  </template>
</el-dialog>
```

```typescript
// script setup 补充
import { ElMessage, ElMessageBox, type FormInstance } from 'element-plus'
import {
  addMember, updateMember, deleteMembers,
  getMemberById, updateMemberStatus
} from '@/api/member'

const dialogVisible = ref(false)
const formRef = ref<FormInstance>()
const emptyForm = () => ({
  id: undefined as number | undefined,
  name: '', gender: '男', age: 60, phone: '', idCard: '',
  address: '', emergencyContact: '', healthStatus: '良好', memberLevel: 'NORMAL'
})
const form = reactive<any>(emptyForm())

const rules = {
  name: [
    { required: true, message: '姓名必填', trigger: 'blur' },
    { min: 2, max: 20, message: '姓名长度 2-20', trigger: 'blur' }
  ],
  gender: [{ required: true, message: '性别必填', trigger: 'change' }],
  age: [{ required: true, message: '年龄必填', trigger: 'blur' }],
  phone: [
    { required: true, message: '手机号必填', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
  ],
  idCard: [
    { required: true, message: '身份证必填', trigger: 'blur' },
    { pattern: /^\d{17}[0-9Xx]$/, message: '身份证格式不正确', trigger: 'blur' }
  ],
  memberLevel: [{ required: true, message: '等级必填', trigger: 'change' }]
}

const openAdd = () => {
  Object.assign(form, emptyForm())
  dialogVisible.value = true
}

const openEdit = async (id: number) => {
  const res: any = await getMemberById(id)
  Object.assign(form, emptyForm(), res.data)
  dialogVisible.value = true
}

const submit = async () => {
  await formRef.value?.validate()
  if (form.id) {
    await updateMember(form)
    ElMessage.success('修改成功')
  } else {
    await addMember(form)
    ElMessage.success('新增成功')
  }
  dialogVisible.value = false
  loadData()
}

const onDelete = async (ids: number[]) => {
  await ElMessageBox.confirm('确定删除吗？', '提示', { type: 'warning' })
  await deleteMembers(ids)
  ElMessage.success('删除成功')
  loadData()
}

const onBatchDelete = () => onDelete(selected.value.map(r => r.id))

const onStatusChange = async (row: any, v: 0 | 1) => {
  try {
    await updateMemberStatus({ id: row.id, status: v })
    ElMessage.success(v === 1 ? '已启用' : '已停用')
  } catch {
    row.status = v === 1 ? 0 : 1 // 回滚
  }
}
```

#### 4. 实操（10 分钟）
学生逐项联调：
- 新增：填入合法数据 → 表格里立刻看到。
- 修改：点编辑 → 表单回显 → 改姓名保存 → 表格刷新。
- 删除：单条 + 批量。
- 启停：点 switch → 数据库 status 立刻变化。

教师全程巡场，重点检查"手机号非法时后端返回 msg 是否在前端弹出"。这印证了 Day03 全天的双保险校验。

#### 5. 小结（3 分钟）
一天下来完成了 6 个后端接口 + 一整套前端 CRUD 页面。这就是企业标准运营页面的完整流水。明天进入客房管理，会加入图片上传、更复杂的表单。

### 四、课上提问
1. Dialog 复用为什么用 `form.id` 判断新增/修改，而不是新开一个 Dialog？
2. `formRef.value?.validate()` 抛错时应该怎么处理？
3. `el-switch` 请求失败后如何"回滚"UI？

### 五、课堂练习
1. 增加"重置"按钮：点击后清空整个表单。
2. 保存成功后，让弹窗自动关闭并高亮新增/修改的那一行。

### 六、课后思考
如果需要"批量修改会员等级"，前端和后端各需要怎么设计？

### 七、课后作业
1. 完整跑通 CRUD 后，把代码 push 到自己的 GitHub 仓库。
2. 补齐"操作列-详情"按钮，点击后弹出只读 Dialog 显示脱敏后的身份证。
3. 预习 Day04：客房管理，重点看 MultipartFile 上传。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  表单 & 联调                               │
├────────────────────────────────────────────┤
│ 1. Dialog + Form 复用（id 判定）           │
│ 2. rules 前端校验                          │
│ 3. ElMessageBox.confirm 二次确认           │
│ 4. el-switch 启停 + 失败回滚               │
│ 5. 全链路：DTO→Entity→VO→Vue               │
└────────────────────────────────────────────┘
```

---

**Day03 总结**：以"会员管理"为载体完成了一次 CRUD 的完整闭环——需求分析、接口约定、Mapper/Service/Controller 三层落地、参数校验、逻辑删除、VO 脱敏、Vue3 页面与前后端联调。学生应能在 Day04 客房模块中独立复用今天的骨架进行开发。
