# 《智能养老社区系统》- 教师教案 - Day07：AI 智能体开发（Agent + Function Calling + RAG）

**授课日：Day 07 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 9 - AI 智能体 · Function Calling · RAG · SimpleVectorStore · InMemoryChatMemory**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day05 Spring AI 集成 + ChatClient + SSE 流式，Day06 客房预约与 AI 意图抽取**

---

## 第 1 课时：AI Agent 概念与技术全景

### 一、教学目标
- 知识目标：理解**为什么单靠 LLM 不够**（时效性、幻觉、无法调工具、无长期记忆等 4 大天生缺陷）；理解 Agent 的核心闭环 ReAct（Reason → Act → Observe → Reason …）；掌握 Agent 四大能力——**Function Calling / Tools / RAG / Memory**——各自解决的问题与彼此的边界；能画出\"一次带工具调用的对话\"完整时序图。
- 能力目标：学生能用一句话说明 Function Calling 与 Prompt 传参的差异；能在白板上画出 Agent 与传统 Chat 的对比框图；能判断给定业务场景应该用哪一种能力（工具 or RAG or Memory）。

### 二、教学重难点
- 重点：Agent = LLM + Tool + Memory + Loop；ReAct 循环三步；四种能力表格化对比。
- 难点：Function Calling **不是** LLM 真的调了函数，而是 LLM 输出\"我要调用哪个函数、参数是什么\"的 JSON，由**框架**（Spring AI）执行后把结果再喂给 LLM。这个\"角色扮演\"的思想是所有 Agent 框架的核心。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问三连击：
1. \"上节课 AI 帮我们抽参数选客房，那我问它\"下周三是几号\"，它答对吗？\"（答：可能错，训练数据截止到 2024，不知道今天。）
2. \"我问它\"101 房现在还有没有人订\"，它能答对吗？\"（答：完全不知道，数据库里的东西它没有。）
3. \"我连问它 10 句，第 11 句让它总结前面 10 句，它记得吗？\"（答：默认不记得，每次调用都是无状态。）
由此引出：**LLM 天生只是一个\"输入 Prompt 输出 Token\"的函数**，要让它变成能查库存、能记住上下文、能实时执行动作的\"智能体\"，就需要今天的三样东西——**Function Calling / RAG / Memory**。

#### 2. 讲授（20 分钟）

（1）LLM 的 4 大天生缺陷
| 缺陷 | 说明 | 对应解法 |
|------|------|---------|
| 时效性 | 训练数据有截止日期，不知道\"今天\" | Function Calling（调时间/天气/股票 API） |
| 幻觉 | 不知道就编造，比如虚构条款 | RAG（从权威文档检索证据） |
| 无法执行动作 | 只能说，不能真下单、真发邮件 | Function Calling / Tools |
| 无长期记忆 | 每次请求上下文清零 | ChatMemory（内存/Redis/DB） |

（2）什么是 AI Agent
> Agent = **LLM（大脑）** + **Tools（手脚）** + **Memory（记忆）** + **Loop（循环）**

关键在**Loop**：不是问一次答一次就结束，而是 LLM 先 Reason（想\"我需要天气数据\"），然后 Act（决定调 GetWeather 工具，输出参数 JSON），框架 Observe（真的调 API 拿回天气），再喂回 LLM，LLM 继续 Reason（\"温度 15°C 有点凉\"），最终给出用户可见回答。这就是**ReAct** 模式。

（3）Function Calling 的\"角色扮演\"本质

传统写法：
```
用户 → 后端 → LLM → 返回文字 → 后端展示
```
Function Calling：
```
用户 → 后端 → LLM → 输出「要调 getWeather('北京')」JSON
      ↓
    后端识别到 → 真去调 getWeather → 返回 15°C
      ↓
    再喂给 LLM → LLM 加工成\"北京 15°C，建议穿薄外套\" → 展示
```
**结论：** 是 Spring AI（框架）在替 LLM \"跑腿\"，LLM 只出主意不干活。

（4）四大能力对比表
| 能力 | 解决问题 | 数据源 | Spring AI 组件 |
|------|---------|--------|----------------|
| Function Calling | 时效/动作 | 你自己写的 Java Bean | @Bean Function + @Description |
| RAG | 知识/幻觉 | 内部文档、知识库 | VectorStore + QuestionAnswerAdvisor |
| Memory | 多轮记忆 | 会话历史 | ChatMemory + MessageChatMemoryAdvisor |
| Prompt Engineering | 风格/人设 | System Message | .defaultSystem() |

#### 3. 演示（8 分钟）
教师打开浏览器演示豆包/文心一言的\"联网搜索\"开关：
- 关闭时问\"上海今天天气\"，AI 说不知道；
- 打开时问\"上海今天天气\"，AI 说 15°C。
让学生亲眼看到 Function Calling 的效果。再让 AI 记住\"我叫张三，我 68 岁\"，切换会话后问\"我几岁\"，AI 说不知道——直观展示无 Memory 的问题。

#### 4. 实操（10 分钟）
学生任务（不写代码，纯思考并填表）：
把下列 6 个业务需求分别归到 Function Calling / RAG / Memory 中的哪一类：
1. 查询会员李奶奶最近三次血压记录 → Function Calling
2. \"我上次问过什么？\" → Memory
3. 咨询养老社区收费标准 → RAG（费用文档入库）
4. 现在给 101 房下单一个 7 月 15 日的预约 → Function Calling
5. 询问\"跌倒后如何处理\" → RAG（应急处置手册）
6. \"继续上一个话题\" → Memory

同桌两两讨论，教师随机抽 3 组讲答案。

#### 5. 小结（3 分钟）
今天先把地图画清楚：Agent = LLM + Tool + Memory + Loop；Function Calling 让 AI 会\"动手\"，RAG 让 AI 会\"查资料\"，Memory 让 AI 会\"记事\"。下节课就动手写第一个可以让 AI 调用的 Function。

### 四、课上提问
1. 为什么说\"LLM 并没有真调函数\"？
2. ReAct 三个步骤分别是什么？
3. \"我问 AI 今天几号\"应该用哪种能力？

### 五、课堂练习
1. 用一段话（≤ 100 字）向朋友解释什么是 AI Agent。
2. 举 3 个养老社区场景各对应一种能力（Function/RAG/Memory）。

### 六、课后思考
如果只用 Prompt Engineering 也能\"骗\" AI 按 JSON 格式回答，为什么还要 Function Calling 机制？（引出可靠性 + 参数校验 + 类型安全）

### 七、课后作业
1. 阅读 Spring AI 官网 [Function Calling](https://docs.spring.io/spring-ai/reference/api/functions.html) 章节的引言部分（10 分钟）。
2. 在个人笔记中画出 ReAct 循环图并配 3 句话说明。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│  Day07-1  AI Agent 全景                      │
├──────────────────────────────────────────────┤
│ LLM 4 缺陷：时效/幻觉/不动手/无记忆          │
│                                              │
│  Agent = LLM + Tool + Memory + Loop          │
│                                              │
│  ReAct：Reason → Act → Observe → Reason ...  │
│                                              │
│  四能力：Function / RAG / Memory / Prompt    │
└──────────────────────────────────────────────┘
```

---

## 第 2 课时：Spring AI Function Calling 实战

### 一、教学目标
- 知识目标：掌握 Spring AI 1.0.0-M6 中通过 **`@Bean` 注册 `Function<Request, Response>`** 的方式暴露工具；掌握 `@Description` 注解如何告诉大模型\"这个函数是干嘛的、什么时候调它\"；理解请求/响应对象为什么用 record 或 POJO 并配合 `@JsonProperty("desc")`；掌握 `ChatClient.builder().defaultFunctions("beanName")` 的注册套路。
- 能力目标：学生能独立写出**三个**可被 AI 调用的 Function——`GetWeatherFunction`（教学用玩具）、`GetRoomAvailabilityFunction`（查客房占用）、`QueryMemberInfoFunction`（查会员基本资料），并在 Apifox 中观察 AI 自动路由到正确工具。

### 二、教学重难点
- 重点：Function Bean 的三要素——**Bean 名（工具名）+ @Description（工具说明）+ 参数对象字段的 @JsonProperty(description)**；三者共同构成\"暴露给 LLM 看\"的接口签名。
- 难点：为什么必须把描述写清楚？——LLM 是根据描述**语义匹配**用户 Query 才决定调不调该工具的。描述模糊 = 工具永远不会被调 / 或乱调。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
\"上节课我们说 Function Calling 是让 AI 会调工具。今天我们真的写一个工具给它。第一个工具最简单——查天气。虽然咱们养老社区业务用不上，但它是官方最经典的例子，能让我们看清整个流程。\"

#### 2. 讲授（16 分钟）

（1）Spring AI Function Calling 的三步走：
```
Step 1 定义 Request/Response 数据类（用 @JsonProperty 描述字段）
Step 2 @Bean 定义 Function<Request, Response>，配 @Description
Step 3 ChatClient 注册 defaultFunctions("bean 名") 或 .functions("bean 名") 单次生效
```

（2）为什么 @Description 决定生死
LLM 是通过阅读**函数名 + 函数描述 + 参数字段描述**三段文字来判断\"这句用户话，是不是应该调这个工具\"。所以描述必须：
- 使用完整语义、动词开头（\"查询/获取/计算\"）
- 明确\"什么情况下会用到我\"
- 参数字段单独描述用途 + 单位 + 取值范围

（3）业务清单（本课要写的 3 个工具）
| Bean 名 | 触发场景 | 参数 | 返回 |
|--------|---------|------|------|
| getWeather | 用户提到天气/温度/穿衣 | 城市 | 温度+建议 |
| getRoomAvailability | 用户询问客房是否可预约 | 房号/日期段 | 可用/已订 |
| queryMemberInfo | 用户询问某会员基本情况 | 会员ID/姓名 | 姓名/年龄/联系人 |

#### 3. 演示（16 分钟）

（1）教师先写第一个玩具工具 GetWeatherFunction：

```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.extern.slf4j.Slf4j;
import java.util.function.Function;

@Slf4j
public class GetWeatherFunction
        implements Function<GetWeatherFunction.Request, GetWeatherFunction.Response> {

    /** LLM 会看到的\"参数说明\" —— 决定它填什么给你 */
    public record Request(
            @JsonProperty(required = true, value = "city")
            @com.fasterxml.jackson.annotation.JsonPropertyDescription("城市名，如：北京、上海")
            String city
    ) {}

    /** LLM 会看到的\"返回结构\" —— 决定它怎么解读结果 */
    public record Response(String city, double temperature, String suggestion) {}

    @Override
    public Response apply(Request req) {
        log.info(\"[GetWeatherFunction] 被 AI 调用，参数：{}\", req);
        // 生产环境接真天气 API，这里用假数据
        double temp = 15 + Math.random() * 15;
        String suggestion = temp < 20 ? \"较凉，建议穿薄外套\" : \"较暖，可穿长袖\";
        return new Response(req.city(), Math.round(temp * 10) / 10.0, suggestion);
    }
}
```

（2）AgentConfig 里通过 @Bean 注册：

```java
package com.itcast.smart_elder.ai.config;

import com.itcast.smart_elder.ai.function.GetWeatherFunction;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;

@Configuration
public class AgentFunctionConfig {

    /**
     * @Description 是核心：LLM 看到\"当用户询问某城市天气或穿衣建议时使用\"
     * 才决定路由到本工具。Bean 名 = 工具名。
     */
    @Bean
    @Description(\"当用户询问某个城市的天气、温度或穿衣建议时调用，输入城市名，返回温度和建议\")
    public GetWeatherFunction getWeather() {
        return new GetWeatherFunction();
    }
}
```

（3）在 ChatClient 里挂载：

```java
@Bean
public ChatClient agentChatClient(ChatClient.Builder builder) {
    return builder
            .defaultSystem(\"你是养老社区智能助手，遇到需要查询实时数据或业务信息时主动调用工具。\")
            .defaultFunctions(\"getWeather\", \"getRoomAvailability\", \"queryMemberInfo\")
            .build();
}
```

（4）Apifox 联调：
- 请求 `GET /api/agent/chat?msg=北京今天多少度` → 观察 Console 打印 `[GetWeatherFunction] 被 AI 调用，参数：Request[city=北京]`；
- 请求 `GET /api/agent/chat?msg=你好呀` → 不调工具，直接闲聊；
- 请求 `GET /api/agent/chat?msg=帮我查一下 101 房间的入住情况` → 调 `getRoomAvailability`。

#### 4. 实操（8 分钟）
学生任务：仿照 GetWeatherFunction 完成 GetRoomAvailabilityFunction（先返回硬编码数据即可），并在 AgentFunctionConfig 里注册。教师巡视重点：
- @Description 写得像\"内部注释\"（\"查客房\"）→ LLM 命中率低 → 让学生改写成\"当用户询问某客房号在特定日期段是否可预约时调用\";
- 忘了 @JsonProperty description → 参数解析准确率下降；
- Bean 名和 defaultFunctions 里写的字符串不一致 → 启动报 \"Function not found\"。

#### 5. 小结（2 分钟）
Function Calling = 三步走：数据类 → @Bean + @Description → ChatClient 注册。**描述决定 LLM 会不会调你**，宁可写详细也别写简略。下节课接入真业务，让 AI 能查数据库。

### 四、课上提问
1. 为什么 @Description 里要写\"当用户询问 xxx 时调用\"？
2. 如果两个工具描述都写得像\"查询用户信息\"，会发生什么？
3. Function 的 Request 用 record 好还是普通类好？为什么？

### 五、课堂练习
1. 把 GetWeatherFunction 的 city 参数改成 required = false，观察 LLM 遇到\"今天几度\"（没给城市）时的表现。
2. 增加一个 GetTimeFunction，返回当前日期时间。

### 六、课后思考
如果 GetWeatherFunction 抛异常了（比如网络超时），LLM 收到什么？会不会把异常告诉用户？（引出错误处理与回退）

### 七、课后作业
1. 完成 3 个 Function：GetWeather / GetRoomAvailability / QueryMemberInfo（后两个可暂返回 mock 数据）。
2. 在 Apifox 用 5 句不同的话测试，用截图验证每个工具至少被命中一次。

### 八、板书设计
```
┌───────────────────────────────────────────────┐
│  Day07-2  Function Calling 三步走             │
├───────────────────────────────────────────────┤
│ ① Request/Response + @JsonPropertyDescription│
│ ② @Bean + @Description                       │
│ ③ ChatClient.defaultFunctions(\"beanName\")   │
│                                               │
│  Bean 名 = 工具名                             │
│  描述 = 触发条件，决定 LLM 会不会调你         │
└───────────────────────────────────────────────┘
```

---

## 第 3 课时：智能体：健康评测 Function + 多轮记忆

### 一、教学目标
- 知识目标：把 Function Calling 从\"玩具\"上升到\"业务智能体\"——**HealthAssessFunction** 接收血压、心率、睡眠、步数、慢性病等 5-6 个指标，内部按规则打分并返回评估报告；掌握 Spring AI 的**多轮对话**机制：`InMemoryChatMemory` + `MessageChatMemoryAdvisor`，让智能体记住上下文；掌握 `sessionId` 作为会话隔离键。
- 能力目标：学生能独立完成 HealthAssessFunction 及其 Request 数据类，能启动多轮对话让 AI 记住\"我 72 岁，血压 145/92\"，之后追问\"那我应该注意什么\" AI 仍能延续话题。

### 二、教学重难点
- 重点：健康评测函数的**规则打分模型**（血压 40% + 心率 20% + 睡眠 20% + 步数 10% + 慢性病 10%）；ChatMemory 的会话隔离（同一 sessionId 才拼上下文）。
- 难点：SystemMessage 中如何\"教\" AI 什么时候该调健康评测工具——必须写清\"当用户提供年龄、血压等指标时\"这类**触发语义**；InMemoryChatMemory 的默认容量与生产环境替换（Redis）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
\"上节课的天气工具是玩具，今天真做一个养老社区能用的工具——健康评测。想象一位家属说：\"我爸 75 岁，最近血压 150/95，晚上只睡 5 小时，走 2000 步。\"AI 直接调工具打个分：\"综合评分 62 分，血压偏高、睡眠不足、活动量偏低，建议……\"这才是养老社区真正需要的智能体。\"

#### 2. 讲授（15 分钟）

（1）健康评测函数的输入设计：
| 字段 | 类型 | 说明 | 取值范围 |
|------|------|------|---------|
| age | int | 年龄 | 50-120 |
| systolicBp | int | 收缩压 mmHg | 60-260 |
| diastolicBp | int | 舒张压 mmHg | 40-180 |
| heartRate | int | 静息心率 bpm | 30-200 |
| sleepHours | double | 昨夜睡眠小时 | 0-14 |
| steps | int | 昨日步数 | 0-40000 |
| diseases | String | 慢性病，逗号分隔 | \"高血压,糖尿病\" |

（2）规则打分表（教师板书）：
```
血压：120/80 → 满分 40；每偏 10 扣 5，最低 0
心率：60-100 → 20；<50 或 >110 → 5
睡眠：7-9h → 20；6-7 或 9-10 → 15；<5 或 >11 → 5
步数：>6000 → 10；3000-6000 → 6；<3000 → 2
慢性病：0种 10；1种 6；2种 3；3种+ 0
```

（3）多轮对话原理：
- `ChatMemory` 接口：`add(sessionId, msg)` / `get(sessionId, size)`；
- `InMemoryChatMemory`：内存 Map，key = sessionId，value = List&lt;Message&gt;；
- `MessageChatMemoryAdvisor`：Spring AI 提供的 Advisor（拦截器），自动在每次请求前**注入历史消息**、请求后**保存新消息**；
- sessionId 通常前端登录时生成 UUID，或后端拼\"会员ID + 时间戳\"；同一 sessionId = 同一会话。

#### 3. 演示（15 分钟）

教师现场写 HealthAssessFunction（学生跟随打字，代码稍长但结构清晰）：

```java
package com.itcast.smart_elder.ai.function;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import lombok.extern.slf4j.Slf4j;
import java.util.function.Function;

@Slf4j
public class HealthAssessFunction
        implements Function<HealthAssessFunction.Request, HealthAssessFunction.Response> {

    public record Request(
            @JsonProperty(required = true)
            @JsonPropertyDescription(\"老人年龄，单位岁，50-120\")
            int age,

            @JsonProperty(required = true)
            @JsonPropertyDescription(\"收缩压（高压），单位 mmHg\")
            int systolicBp,

            @JsonProperty(required = true)
            @JsonPropertyDescription(\"舒张压（低压），单位 mmHg\")
            int diastolicBp,

            @JsonProperty(required = true)
            @JsonPropertyDescription(\"静息心率，单位 bpm\")
            int heartRate,

            @JsonProperty(required = true)
            @JsonPropertyDescription(\"昨夜睡眠时长，单位小时，可为小数\")
            double sleepHours,

            @JsonProperty(required = true)
            @JsonPropertyDescription(\"昨日步数\")
            int steps,

            @JsonPropertyDescription(\"慢性病，逗号分隔，如：高血压,糖尿病；无则填 '无'\")
            String diseases
    ) {}

    public record Response(int totalScore, String level, String detail, String advice) {}

    @Override
    public Response apply(Request r) {
        log.info(\"[HealthAssessFunction] AI 触发健康评测：{}\", r);

        int bpScore = scoreBp(r.systolicBp(), r.diastolicBp());
        int hrScore = scoreHr(r.heartRate());
        int sleepScore = scoreSleep(r.sleepHours());
        int stepsScore = scoreSteps(r.steps());
        int diseaseScore = scoreDisease(r.diseases());

        int total = bpScore + hrScore + sleepScore + stepsScore + diseaseScore;
        String level = total >= 85 ? \"良好\" : total >= 70 ? \"关注\" : total >= 55 ? \"预警\" : \"危险\";

        String detail = String.format(
                \"血压 %d/%d(得分 %d) 心率 %d(得分 %d) 睡眠 %.1fh(得分 %d) 步数 %d(得分 %d) 慢病(得分 %d)\",
                r.systolicBp(), r.diastolicBp(), bpScore, r.heartRate(), hrScore,
                r.sleepHours(), sleepScore, r.steps(), stepsScore, diseaseScore);

        String advice = buildAdvice(bpScore, hrScore, sleepScore, stepsScore);
        return new Response(total, level, detail, advice);
    }

    private int scoreBp(int s, int d) {
        int deviation = Math.max(Math.abs(s - 120) / 10, Math.abs(d - 80) / 10);
        return Math.max(0, 40 - deviation * 5);
    }
    private int scoreHr(int hr) {
        if (hr >= 60 && hr <= 100) return 20;
        if (hr < 50 || hr > 110) return 5;
        return 12;
    }
    private int scoreSleep(double h) {
        if (h >= 7 && h <= 9) return 20;
        if ((h >= 6 && h < 7) || (h > 9 && h <= 10)) return 15;
        if (h < 5 || h > 11) return 5;
        return 10;
    }
    private int scoreSteps(int s) {
        return s >= 6000 ? 10 : s >= 3000 ? 6 : 2;
    }
    private int scoreDisease(String diseases) {
        if (diseases == null || diseases.isBlank() || \"无\".equals(diseases.trim())) return 10;
        int n = diseases.split(\"[,，]\").length;
        return n == 1 ? 6 : n == 2 ? 3 : 0;
    }
    private String buildAdvice(int bp, int hr, int sleep, int steps) {
        StringBuilder sb = new StringBuilder();
        if (bp < 25) sb.append(\"血压异常，建议每日测量并到社区卫生站就诊；\");
        if (hr < 15) sb.append(\"心率异常，建议休息 10 分钟后复测；\");
        if (sleep < 15) sb.append(\"睡眠不足，建议 22:30 前入睡，中午小憩 30 分钟；\");
        if (steps < 10) sb.append(\"活动量偏低，建议早晚各 15 分钟散步；\");
        if (sb.length() == 0) sb.append(\"整体良好，请保持当前生活习惯。\");
        return sb.toString();
    }
}
```

然后在 AgentFunctionConfig 中注册：
```java
@Bean
@Description(\"当用户提供年龄、血压、心率、睡眠、步数等健康指标，询问身体评估、健康分数或建议时调用；返回综合评分、等级和建议\")
public HealthAssessFunction healthAssess() {
    return new HealthAssessFunction();
}
```

再演示 InMemoryChatMemory 的多轮：
```java
@Bean
public ChatMemory chatMemory() { return new InMemoryChatMemory(); }
```
在 AgentController 里用 `MessageChatMemoryAdvisor(chatMemory, sessionId, 10)` 加载会话上下文。演示：先问\"我 72 岁血压 145/92 心率 88 睡了 6 小时走了 3500 步没慢性病\"，AI 调工具返回评分；再追问\"那我应该重点注意什么\"，AI 能延续上下文继续给建议。

#### 4. 实操（10 分钟）
学生任务：完成 HealthAssessFunction 与其规则打分方法；在 Postman 用 sessionId=zhangsan 连问 3 句，观察是否延续话题；再换 sessionId=lisi 问同一话题，观察是否\"失忆\"。

#### 5. 小结（2 分钟）
业务型智能体两大关键：**能干活的工具**（规则封装到 Function）+ **能记事的 Memory**（sessionId 隔离）。下节课我们让 AI 具备第三种能力——**读文档**。

### 四、课上提问
1. 为什么每次请求都要带 sessionId？
2. InMemoryChatMemory 有什么生产上的缺陷？
3. 健康评测函数为什么不让 AI 自己算分？

### 五、课堂练习
1. 增加\"血糖\"字段到 Request，扩展打分规则。
2. 把 InMemoryChatMemory 会话长度参数从默认改为 20，观察对上下文的影响。

### 六、课后思考
如果一个 sessionId 连问 100 句，历史消息会有多大？会撑爆 Token 吗？如何截断？（引出滑动窗口 + 摘要）

### 七、课后作业
1. 完成 HealthAssessFunction 全部代码 + 单元测试（评分正确性）。
2. 用 3 个不同 sessionId 分别做 5 轮对话，截图证明记忆隔离。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  Day07-3  业务智能体 = Function + Memory   │
├────────────────────────────────────────────┤
│ HealthAssess: 5 指标 × 权重 → 100 分       │
│   血压 40 + 心率 20 + 睡眠 20              │
│   + 步数 10 + 慢病 10                      │
│                                            │
│ InMemoryChatMemory + sessionId             │
│  Advisor 自动注入历史 & 保存新消息         │
└────────────────────────────────────────────┘
```

---

## 第 4 课时：向量数据库与 Embedding 基础

### 一、教学目标
- 知识目标：理解**向量（embedding）** 的直观含义——用一串数字表示一段文本，语义越近的文本向量越\"靠近\"；掌握**余弦相似度**公式并能徒手计算简单二维例子；对比主流向量库 Chroma / Milvus / PGVector / SimpleVectorStore 的适用场景；理解阿里百炼 `text-embedding-v2` 模型的作用与调用方式；掌握 Spring AI `DashScopeEmbeddingModel` 的注入。
- 能力目标：学生能用一句话解释\"embedding 是什么\"，能画出两个 2D 向量并算出余弦相似度，能在项目中注入 EmbeddingModel 并测试一段中文的向量长度（通常 1536 维）。

### 二、教学重难点
- 重点：向量的几何直觉；余弦相似度 = 点积 / (模 × 模)；SimpleVectorStore 作为教学首选（无外部依赖）。
- 难点：为什么用余弦而不是欧式距离？（因为余弦忽略向量长度，只看方向 = 语义方向）；为什么 embedding 一次就固定，不像 LLM 每次结果不同（同一模型下确定性输出）。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师写三句话：
```
① \"客房 101 每晚 300 元\"
② \"101 号房间的日均价格是三百块\"
③ \"今天下雨了\"
```
提问：\"哪两句意思最像？\"学生答①和②。\"计算机怎么知道？\"——把每句变成一串数字（向量），然后算距离。数字化后的文本，就是 **embedding**。

#### 2. 讲授（18 分钟）

（1）Embedding 直观图（板书）：
```
                ↑ y
   ①(0.9, 0.4) *
   ②(0.85, 0.5)*   两向量夹角小 → 相似度高
                    
   ③(0.1, 0.9) *   与 ①、② 夹角大 → 相似度低
                → x
```

（2）余弦相似度公式：
```
cos(A, B) = (A·B) / (|A| × |B|)
     A·B = Σ Aᵢ × Bᵢ
     |A| = √(Σ Aᵢ²)
```
现场算 ①·② = 0.9×0.85 + 0.4×0.5 = 0.965，|①| = √0.97 ≈ 0.985，|②| = √0.9725 ≈ 0.986，cos ≈ 0.995（几乎重合）。①·③ = 0.9×0.1 + 0.4×0.9 = 0.45，cos ≈ 0.51。学生亲眼看到\"语义近 → 数值近\"。

（3）主流向量库对比：
| 向量库 | 定位 | 部署 | 场景 |
|--------|------|------|------|
| Chroma | 轻量嵌入式 | pip 一装 | 单机原型 / 小项目 |
| Milvus | 分布式集群 | K8s / Docker | 千万级/生产 |
| PGVector | Postgres 扩展 | SQL 无缝 | 已有 PG 的团队 |
| Redis Stack | 内存高性能 | 已有 Redis | 需低延迟 |
| SimpleVectorStore | Spring AI 内置 | 无依赖 | **教学 / Demo** ← 本课选它 |

（4）阿里百炼 text-embedding-v2：
- 中文效果好，1536 维；
- 单次可传 batch（多段一起编码），减少网络往返；
- 调用方式和 ChatModel 类似，用 API-Key 认证。

Spring AI 引入：
```xml
<dependency>
    <groupId>com.alibaba.cloud.ai</groupId>
    <artifactId>spring-ai-alibaba-starter</artifactId>
    <version>1.0.0-M6.1</version>
</dependency>
```
配置：
```yaml
spring:
  ai:
    dashscope:
      api-key: ${DASHSCOPE_API_KEY}
      embedding:
        options:
          model: text-embedding-v2
```

#### 3. 演示（10 分钟）
教师现场写一个小工具接口验证向量：
```java
@RestController
@RequestMapping(\"/api/ai/embed\")
@RequiredArgsConstructor
public class EmbeddingDemoController {
    private final EmbeddingModel embeddingModel;

    @GetMapping
    public Result<Map<String, Object>> embed(@RequestParam String text) {
        float[] vec = embeddingModel.embed(text);
        Map<String, Object> r = new HashMap<>();
        r.put(\"dim\", vec.length);
        r.put(\"first10\", Arrays.copyOfRange(vec, 0, 10));
        return Result.success(r);
    }

    @GetMapping(\"/sim\")
    public Result<Double> sim(@RequestParam String a, @RequestParam String b) {
        float[] va = embeddingModel.embed(a);
        float[] vb = embeddingModel.embed(b);
        return Result.success(cos(va, vb));
    }

    private double cos(float[] a, float[] b) {
        double dot = 0, na = 0, nb = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            na += a[i] * a[i];
            nb += b[i] * b[i];
        }
        return dot / (Math.sqrt(na) * Math.sqrt(nb));
    }
}
```
Apifox 调 `/sim?a=101 房 300 元&b=一百零一号房间三百块` → 期望 0.9+；`/sim?a=101 房 300 元&b=今天下雨` → 期望 0.5 以下。

#### 4. 实操（10 分钟）
学生任务：
1. 引入 embedding 依赖 + yml 配置；
2. 复制 EmbeddingDemoController 代码，运行；
3. 至少测试 5 组\"意思相近\" / 5 组\"意思无关\"，把相似度写进笔记，直观感受阈值一般设 0.7-0.8。

#### 5. 小结（3 分钟）
向量 = 文本的\"数字指纹\"；余弦相似度 = 语义近似度。今天已经能算出\"两句话有多像\"，下节课把它接进真正的 RAG——**给我 100 篇内部资料，我从里面找 3 段最像用户问题的段落，喂给 AI 让它据此作答**。

### 四、课上提问
1. embedding 的维度是模型决定的还是文本决定的？
2. 为什么用余弦而不是欧氏距离？
3. SimpleVectorStore 为什么只适合教学，不适合生产？

### 五、课堂练习
1. 手算：A=(3,4)，B=(6,8)，C=(-3,-4)，两两余弦相似度分别是多少？（答：AB=1，AC=-1，BC=-1）
2. 用 `/sim` 接口测试 5 对句子，观察阈值分布。

### 六、课后思考
如果一个查询和 100 万文档做相似度对比，是否要 100 万次余弦计算？如何加速？（引出 HNSW / IVF 等 ANN 索引）

### 七、课后作业
1. 引入依赖 + 配置 embedding；
2. 完成 EmbeddingDemoController 并测试 10 组数据；
3. 用一段话总结\"embedding + 余弦\" 到底解决了什么问题。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  Day07-4  Embedding + 向量库              │
├───────────────────────────────────────────┤
│ embedding = 文本 → 向量（float[1536]）    │
│ 相似度 = A·B / (|A||B|)                   │
│                                           │
│ 向量库：Chroma / Milvus / PG / Simple     │
│ 本课：SimpleVectorStore（内存 + JSON）    │
│                                           │
│ text-embedding-v2  1536 维  中文优秀      │
└───────────────────────────────────────────┘
```

---

## 第 5 课时：RAG 检索增强生成实战

### 一、教学目标
- 知识目标：掌握 RAG（Retrieval-Augmented Generation）完整五步流程——**加载文档 → 切片 → 向量化 → 存入向量库 → 检索并拼 Prompt**；掌握 Spring AI `TextReader` / `TokenTextSplitter` / `VectorStore.add` / `QuestionAnswerAdvisor` 四个核心组件；能设计养老院内部知识库（日常护理 / 应急处置 / 收费标准 / 活动安排等）；掌握**启动时初始化**知识库的做法。
- 能力目标：学生能独立完成 KnowledgeInitializer，把 `resources/docs/*.md` 全部入库；在 ChatClient 上挂 QuestionAnswerAdvisor 后，问一句\"老人跌倒后如何处置\"，AI 能引用文档回答并且带出处。

### 二、教学重难点
- 重点：切片粒度（TokenTextSplitter 默认 800 token）；QuestionAnswerAdvisor 会在**每次**请求前自动做一次 topK 检索并拼进 Prompt；SimpleVectorStore 的 `save(File)` / `load(File)` 让重启不用重新入库。
- 难点：切片过大 → 信息稀释；切片过小 → 语义断裂；如何设 topK（一般 3-5）；chunk 之间需要**重叠**（默认 350 token）避免边界丢信息。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
\"上节课我们让 AI 会算相似度。今天让 AI 学会用它——把养老院内部的《日常护理手册》《应急处置流程》《收费明细》喂给它，之后老人家属问\"跌倒了怎么办\"，AI 不再是背通用知识，而是直接引用我们的文档来答。这就是 RAG。\"

#### 2. 讲授（17 分钟）

（1）RAG 五步流程图（板书）：
```
① 加载 Load    :  resources/docs/*.md  → TextReader → List<Document>
② 切片 Split   :  TokenTextSplitter    → 按 800 token 切，重叠 350
③ 向量化 Embed :  EmbeddingModel       → 每段变 float[1536]
④ 入库 Store   :  vectorStore.add(...) → 保存进 SimpleVectorStore
⑤ 检索 Retrieve:  用户提问 → embed → 找 topK → 拼 Prompt → LLM 回答
```

（2）为什么要切片
LLM 上下文虽然大（qwen-plus 8k / qwen-max 32k），但**塞进太多无关文档 = 更贵、更慢、还会稀释注意力**。切成小块，每次只检索最相关的 3-5 块，效果最好。

（3）QuestionAnswerAdvisor 自动化流水线
```
用户 Query 进来
   ↓
QuestionAnswerAdvisor 拦截
   ↓
把 Query 转 embedding
   ↓
vectorStore.similaritySearch(topK=3)
   ↓
把匹配到的文档段拼到 System Prompt 里，形如：
   \"以下资料可作为你回答的参考：
    [1] 跌倒处置：… … …
    [2] 心脏骤停：… … …\"
   ↓
LLM 生成回答（此时已见到资料）
```

（4）知识库分类（现场规划）
```
docs/care-daily.md      日常护理（起床 / 用药 / 三餐 / 洗漱）
docs/care-emergency.md  应急处置（跌倒 / 呛咳 / 胸痛 / 走失）
docs/fee-standard.md    收费标准（房型 / 护理级别 / 补贴）
docs/activity.md        活动安排（书法班 / 太极 / 生日会）
```

#### 3. 演示（17 分钟）

（1）SimpleVectorStore 配置（AgentConfig 里补上）：
```java
@Bean
public VectorStore vectorStore(EmbeddingModel embeddingModel) {
    return new SimpleVectorStore(embeddingModel);
}
```

（2）KnowledgeInitializer（启动时把 resources/docs/*.md 全部入库并持久化）：
```java
package com.itcast.smart_elder.ai.rag;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;
import java.io.File;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class KnowledgeInitializer implements CommandLineRunner {

    private final VectorStore vectorStore;
    @Value(\"${knowledge.store-path:./data/vector-store.json}\") String storePath;

    @Override
    public void run(String... args) throws Exception {
        SimpleVectorStore store = (SimpleVectorStore) vectorStore;
        File f = new File(storePath);

        // 已经持久化过就直接加载，避免每次启动都调 embedding 花钱
        if (f.exists()) {
            store.load(f);
            log.info(\"[Knowledge] 从 {} 加载现成向量库\", storePath);
            return;
        }

        Resource[] resources = new PathMatchingResourcePatternResolver()
                .getResources(\"classpath:docs/*.md\");

        TokenTextSplitter splitter = new TokenTextSplitter();
        int total = 0;
        for (Resource res : resources) {
            log.info(\"[Knowledge] 加载文档：{}\", res.getFilename());
            TextReader reader = new TextReader(res);
            reader.getCustomMetadata().put(\"source\", res.getFilename());
            List<Document> docs = reader.get();
            List<Document> chunks = splitter.apply(docs);
            store.add(chunks);
            total += chunks.size();
        }

        f.getParentFile().mkdirs();
        store.save(f);
        log.info(\"[Knowledge] 已入库共 {} 段，持久化到 {}\", total, storePath);
    }
}
```

（3）ChatClient 挂 QuestionAnswerAdvisor：
```java
@Bean
public ChatClient agentChatClient(ChatClient.Builder builder,
                                   VectorStore vectorStore,
                                   ChatMemory chatMemory) {
    return builder
            .defaultSystem(\"\"\"
                    你是\"金秋家园\"智能养老助手\"小金\"。
                    - 遇到需要查实时业务数据时使用工具（Function）
                    - 遇到护理/应急/收费/活动等问题优先引用检索到的知识
                    - 回答不超过 200 字，语气温柔耐心
                    \"\"\")
            .defaultFunctions(\"getWeather\", \"getRoomAvailability\",
                              \"queryMemberInfo\", \"healthAssess\")
            .defaultAdvisors(
                    new QuestionAnswerAdvisor(vectorStore,
                            SearchRequest.defaults().withTopK(3).withSimilarityThreshold(0.6)),
                    new MessageChatMemoryAdvisor(chatMemory)
            )
            .build();
}
```

（4）现场演示：
- 在 `resources/docs/care-emergency.md` 里塞进跌倒处置流程；
- 重启，看日志 `[Knowledge] 已入库共 12 段，持久化到 ./data/vector-store.json`；
- 请求 `?msg=老人跌倒后应该怎么办` → 观察 AI 回答包含 md 里写过的\"先判断意识、不轻易移动、立刻按呼叫铃……\"；
- 再问 `?msg=收费怎么算` → AI 引用 fee-standard.md 里的分级明细。

#### 4. 实操（5 分钟）
学生任务：至少写 2 篇 md（care-emergency.md / fee-standard.md），启动后用 3 个问题验证 RAG 生效；观察 `./data/vector-store.json` 是否生成。

#### 5. 小结（3 分钟）
RAG 五步：Load → Split → Embed → Store → Retrieve。QuestionAnswerAdvisor 已经把\"检索 + 拼 Prompt\"自动做好。SimpleVectorStore 用 JSON 持久化，避免每次启动烧 embedding 费用。下节课把这一切接到前端。

### 四、课上提问
1. 为什么切片要有\"重叠\"？
2. QuestionAnswerAdvisor 每次都会检索吗？topK 太大有什么坏处？
3. 项目重启后如何避免重复入库？

### 五、课堂练习
1. 把 TokenTextSplitter 的 chunkSize 从 800 改成 200，观察检索命中的差异。
2. 增加一篇\"活动安排.md\"，问\"下周有什么书法课\" 看看能否命中。

### 六、课后思考
如果新增了一份文档，如何**增量**入库而不重跑全部？如何删除已过期文档？（引出向量库的 CRUD 与文档指纹）

### 七、课后作业
1. 完成 4 篇知识库 md + KnowledgeInitializer 全代码；
2. 至少 5 个真实问题验证 RAG 回答，截图对比 RAG 关闭 vs 打开的差异。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│  Day07-5  RAG 五步流程                       │
├──────────────────────────────────────────────┤
│ Load  → TextReader                           │
│ Split → TokenTextSplitter(800/350)           │
│ Embed → EmbeddingModel                       │
│ Store → SimpleVectorStore.save(File)         │
│ Retrieve → QuestionAnswerAdvisor(topK=3)     │
│                                              │
│ 拦截器机制：自动前置检索 + 拼 Prompt         │
└──────────────────────────────────────────────┘
```

---

## 第 6 课时：智能体前端联调（agent.vue）

### 一、教学目标
- 知识目标：掌握前端**多轮对话** 页面的通用套路——sessionId 生成与保持、气泡列表、发送框、加载态；高亮\"AI 正在调用工具\"提示；RAG 回答后展示引用来源列表（source metadata）；与 Day05 的 chat.vue 区分为**另一条菜单**（\"智能助手\" vs \"AI 对话\"）。
- 能力目标：学生能独立完成 views/ai/agent.vue，端到端联调多轮对话 + 工具调用 + RAG 引用展示。

### 二、教学重难点
- 重点：sessionId 的前端管理（首次进入生成 UUID 存 Pinia，切换会话时按需重建）；后端返回结构除 content 外还带 `functionCalls`、`sources`（可选）以便前端渲染。
- 难点：工具调用的高亮时机（AI 输出的 content 里没有 tool 痕迹，需要靠后端 hook 把工具调用信息**旁路**返回）；SSE 与非 SSE 的取舍（本课教学用同步 JSON，简化调试）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
\"今天最后一步：把前端搭起来，让我们的智能体能被家属和客服真正用起来。它和 Day05 的 chat.vue 不同——那时它只会闲聊，现在它会查客房、会评估健康、会翻手册。我们要在 UI 上让用户看到\"AI 在动手\"。\"

#### 2. 讲授（14 分钟）

（1）AgentController 完整实现（后端已具备工具 + Memory + RAG，此处收口）：

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.ai.dto.AgentChatRequest;
import com.itcast.smart_elder.ai.dto.AgentChatResponse;
import com.itcast.smart_elder.common.Result;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.messages.Message;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping(\"/api/agent\")
@RequiredArgsConstructor
public class AgentController {

    private final ChatClient agentChatClient;

    @PostMapping(\"/chat\")
    public Result<AgentChatResponse> chat(@RequestBody AgentChatRequest req) {
        String sessionId = (req.getSessionId() == null || req.getSessionId().isBlank())
                ? UUID.randomUUID().toString() : req.getSessionId();

        var chatResp = agentChatClient
                .prompt()
                .user(req.getMsg())
                .advisors(a -> a
                        .param(MessageChatMemoryAdvisor.CHAT_MEMORY_CONVERSATION_ID_KEY, sessionId)
                        .param(MessageChatMemoryAdvisor.CHAT_MEMORY_RETRIEVE_SIZE_KEY, 10))
                .call()
                .chatResponse();

        String content = chatResp.getResult().getOutput().getContent();

        // 从 metadata 里提取本轮使用的工具与来源（Spring AI 会把它们放在 metadata）
        List<String> tools = chatResp.getResults().stream()
                .flatMap(r -> r.getOutput().getMetadata().entrySet().stream())
                .filter(e -> e.getKey().startsWith(\"functionCall\"))
                .map(e -> String.valueOf(e.getValue()))
                .toList();

        List<String> sources = (List<String>) chatResp.getMetadata()
                .getOrDefault(\"qa_retrieved_sources\", List.of());

        return Result.success(new AgentChatResponse(sessionId, content, tools, sources));
    }
}
```

（2）DTO：
```java
@Data
public class AgentChatRequest {
    private String sessionId;
    private String msg;
}

@Data @AllArgsConstructor
public class AgentChatResponse {
    private String sessionId;
    private String content;
    private List<String> functionCalls;
    private List<String> sources;
}
```

（3）前端 api 封装：
```ts
// src/api/agent.ts
import request from '@/utils/request'

export interface AgentReq { sessionId?: string; msg: string }
export interface AgentResp {
  sessionId: string
  content: string
  functionCalls: string[]
  sources: string[]
}
export const agentChat = (data: AgentReq) =>
  request.post<AgentResp>('/api/agent/chat', data)
```

（4）Vue 页面结构：
```
agent.vue
├── 顶部标题 + 新会话按钮
├── 中部气泡列表 messages[]
│   ├── 用户气泡（右）
│   └── AI 气泡（左）+ 工具徽章 + 来源列表
└── 底部输入框 + 发送按钮 + Loading
```

#### 3. 演示（20 分钟）

教师完整敲出 agent.vue：

```vue
<template>
  <div class=\"agent\">
    <div class=\"header\">
      <h2>🤖 智能助手·小金</h2>
      <el-button size=\"small\" @click=\"reset\">🔄 新会话</el-button>
    </div>

    <div class=\"chat-body\" ref=\"bodyRef\">
      <div v-for=\"(m, i) in messages\" :key=\"i\"
           :class=\"['bubble', m.role]\">
        <div class=\"avatar\">{{ m.role === 'user' ? '👤' : '🤖' }}</div>
        <div class=\"content\">
          <div v-if=\"m.tools?.length\" class=\"tag-line\">
            <el-tag v-for=\"t in m.tools\" :key=\"t\" size=\"small\" type=\"warning\">
              🔧 {{ t }}
            </el-tag>
          </div>
          <div class=\"text\" v-html=\"render(m.content)\"></div>
          <div v-if=\"m.sources?.length\" class=\"sources\">
            <div class=\"src-title\">📚 参考资料：</div>
            <ul>
              <li v-for=\"s in m.sources\" :key=\"s\">{{ s }}</li>
            </ul>
          </div>
        </div>
      </div>
      <div v-if=\"loading\" class=\"bubble ai\">
        <div class=\"avatar\">🤖</div>
        <div class=\"content\"><span class=\"dots\">思考中...</span></div>
      </div>
    </div>

    <div class=\"input-bar\">
      <el-input
          v-model=\"input\"
          type=\"textarea\"
          :rows=\"2\"
          resize=\"none\"
          placeholder=\"试试：帮我评估一下 72 岁血压 145/92 心率 88 睡了 6 小时\"
          @keydown.enter.exact.prevent=\"send\"/>
      <el-button type=\"primary\" :loading=\"loading\" @click=\"send\">发送</el-button>
    </div>
  </div>
</template>

<script setup lang=\"ts\">
import { ref, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import { agentChat } from '@/api/agent'

interface Msg {
  role: 'user' | 'ai'
  content: string
  tools?: string[]
  sources?: string[]
}

const messages = ref<Msg[]>([
  { role: 'ai', content: '您好，我是智能助手小金。可以询问健康评估、客房查询、护理知识等。' }
])
const input = ref('')
const sessionId = ref('')
const loading = ref(false)
const bodyRef = ref<HTMLElement>()

const scrollBottom = () => nextTick(() => {
  if (bodyRef.value) bodyRef.value.scrollTop = bodyRef.value.scrollHeight
})

const render = (text: string) => text.replace(/\\n/g, '<br/>')

const send = async () => {
  const msg = input.value.trim()
  if (!msg) return
  input.value = ''
  messages.value.push({ role: 'user', content: msg })
  scrollBottom()
  loading.value = true
  try {
    const { data } = await agentChat({ sessionId: sessionId.value, msg })
    sessionId.value = data.sessionId
    messages.value.push({
      role: 'ai',
      content: data.content,
      tools: data.functionCalls,
      sources: data.sources
    })
  } catch (e: any) {
    ElMessage.error(e?.message || '请求失败')
  } finally {
    loading.value = false
    scrollBottom()
  }
}

const reset = () => {
  sessionId.value = ''
  messages.value = [{ role: 'ai', content: '已开启新会话。' }]
}
</script>

<style scoped>
.agent { display: flex; flex-direction: column; height: calc(100vh - 60px); }
.header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-bottom: 1px solid #ebeef5; }
.chat-body { flex: 1; overflow-y: auto; padding: 16px; background: #f5f7fa; }
.bubble { display: flex; margin-bottom: 12px; }
.bubble.user { flex-direction: row-reverse; }
.avatar { width: 40px; text-align: center; font-size: 24px; }
.content { max-width: 70%; padding: 10px 14px; background: #fff; border-radius: 10px; box-shadow: 0 1px 2px rgba(0,0,0,.05); }
.bubble.user .content { background: #d9ecff; }
.tag-line { margin-bottom: 6px; }
.tag-line .el-tag { margin-right: 6px; }
.sources { margin-top: 8px; padding-top: 6px; border-top: 1px dashed #dcdfe6; font-size: 12px; color: #909399; }
.src-title { font-weight: 600; margin-bottom: 4px; }
.sources ul { padding-left: 18px; margin: 0; }
.dots::after { content: '...'; animation: blink 1s infinite; }
@keyframes blink { 50% { opacity: .3; } }
.input-bar { display: flex; gap: 8px; padding: 12px 16px; border-top: 1px solid #ebeef5; background: #fff; }
.input-bar .el-input { flex: 1; }
</style>
```

路由与菜单：
```ts
// src/router/index.ts 追加
{ path: '/ai/agent', name: 'AiAgent', component: () => import('@/views/ai/agent.vue'),
  meta: { title: '智能助手', icon: 'ChatDotRound' } }
```
菜单加一条\"智能助手\"，与 Day05 的\"AI 对话\"并列。

现场演示：
1. 打开 `/ai/agent`，输入\"72 岁血压 145/92 心率 88 睡了 6 小时 3500 步没慢性病\"；
2. 观察气泡中出现橙色标签 `🔧 healthAssess`；
3. AI 给出评分和建议；
4. 追问\"那我应该重点注意什么\"，验证多轮记忆；
5. 换话题问\"跌倒了怎么办\"，看气泡下方出现 📚 参考资料 care-emergency.md。

#### 4. 实操（6 分钟）
学生完成 agent.vue、路由、菜单，端到端联调 3 组问答；观察多轮 sessionId 是否保持。

#### 5. 小结（2 分钟）
本日闭环：Function（能干活）+ Memory（能记事）+ RAG（能查资料）+ 前端（能被用）。到此，我们的智能养老助手真正具备了 Agent 的完整形态。下一天进入 Day08 大屏可视化，把系统的运营数据可视化出来。

### 四、课上提问
1. 前端如何保证同一会话延续？切会话时怎么处理？
2. 工具徽章的信息从哪里来？
3. RAG 参考资料没命中时该显示什么？

### 五、课堂练习
1. 加一个\"清空当前会话\"按钮。
2. 让最后一条 AI 消息支持一键复制。

### 六、课后思考
把 POST /api/agent/chat 改为 SSE 流式，前端如何同时展示工具徽章和逐字输出？（引出流式事件设计）

### 七、课后作业
1. 完成 agent.vue + 路由 + 菜单，端到端验证；
2. 编写 Day07 项目总结 md，包含至少 5 个真实问答截图；
3. 把当天代码 Push 到 Git，PR 描述包含\"Function+RAG+Memory\"三张截图。

### 八、板书设计
```
┌─────────────────────────────────────────────┐
│  Day07-6  智能体前端                        │
├─────────────────────────────────────────────┤
│  agent.vue                                  │
│   ├─ 气泡列表（user / ai）                  │
│   ├─ 🔧 工具徽章                            │
│   ├─ 📚 参考资料                            │
│   └─ 输入框 + sessionId 保持                │
│                                             │
│  与 Day05 chat.vue 并列，独立菜单           │
└─────────────────────────────────────────────┘
```
