# 《智能养老社区系统》- 教师教案 - Day09：AOP 操作日志管理

**授课日：Day 09 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 11 - Spring AOP 切面 + 自定义注解 + 异步日志 + 全局异常**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01 已建 `operation_log` 表；Day02 已有 SpringBoot 骨架 + `Result` 封装；Day03 已引入 `GlobalExceptionHandler`（本日补齐错误码体系）；Day08 已有大屏统计页面。**

---

## 第 1 课时：AOP 原理与 Spring AOP

### 一、教学目标
- 知识目标：理解 AOP（Aspect Oriented Programming）诞生的动机——把\"横切关注点\"（日志、权限、事务、监控）从业务代码里抽出来；掌握 AOP 的 5 个核心术语（JoinPoint / Pointcut / Advice / Aspect / Weaving）；理解 Spring AOP 的实现基石是**动态代理**，能对比 JDK 动态代理与 CGLIB 代理的差异；掌握 Spring AOP 五种通知（`@Before`、`@After`、`@AfterReturning`、`@AfterThrowing`、`@Around`）的执行顺序与适用场景。
- 能力目标：能够在纸上画出\"业务方法调用被代理对象拦截\"的调用链；能对给定的一段横切代码说出它应当使用哪种通知；能在 IDEA 里创建一个最简 `HelloAspect` 打印方法名，并让它对某个 Controller 生效。

### 二、教学重难点
- 重点：AOP 五术语的准确定义；`@Around` 相较其他四种通知的独特能力——**决定是否执行、修改参数、修改返回值、包一层 try-catch**。
- 难点：JDK 代理与 CGLIB 代理的选择规则；\"切点表达式\"里 `execution(* com.itcast.smart_elder.controller..*.*(..))` 每一段含义。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问：\"从 Day03 到今天，我们已经写了几十个 Controller 方法。假设明天产品说：所有增删改的方法都要记录一条日志，写清楚 **谁、什么时间、做了什么、耗时多少**。请问你打算怎么做？\"

预设回答：在每个 Controller 方法开头写 `log.info(...)`，方法结尾再写一句。

追问：\"如果有 60 个 Controller 方法，每个方法头尾都写一遍，这段代码有几个缺点？\"
引出三个痛点：**重复、易漏、耦合**。这就是 AOP 要解决的问题——把重复的、和业务无关的\"横切代码\"抽出来。

#### 2. 讲授（18 分钟）

**（1）OOP 与 AOP 的对比**

板书画两张图：
```
OOP 纵向切：会员业务、客房业务、预约业务
             │
             ▼
             每个业务里都要写：日志/权限/事务/异常
             (这就是横切关注点)
```
AOP 的思路：把\"日志/权限/事务/异常\"这些横切关注点，独立成**切面(Aspect)**，运行期由框架自动\"织入\"到业务方法周围。

**（2）AOP 五术语**

| 术语 | 英文 | 通俗解释 | 本项目对应 |
|------|------|----------|-----------|
| 连接点 | JoinPoint | 程序执行中的一个具体位置（方法调用、异常抛出等） | 每一次 Controller 方法被调用 |
| 切点 | Pointcut | 筛选\"我关心哪些 JoinPoint\"的规则 | 打了 `@OperationLog` 的方法 |
| 通知 | Advice | 在切点匹配的位置**做什么** | 记录一条日志 |
| 切面 | Aspect | 切点 + 通知的封装类 | `OperationLogAspect` |
| 织入 | Weaving | 把 Advice 编入目标方法的过程 | Spring 启动时用动态代理完成 |

**（3）Spring AOP 的实现基石：动态代理**

Spring AOP 不修改字节码，也不改源码。它在容器启动时，为每个被切面命中的 Bean **生成一个代理对象**放进容器，业务代码拿到的其实是代理，而不是原始 Bean。当调用方法时，代理先执行 Advice，再决定是否调用真实方法。

两种代理实现：
| 代理方式 | 触发条件 | 特点 |
|----------|----------|------|
| JDK 动态代理 | 目标类**实现了接口** | 只能代理接口方法；速度快 |
| CGLIB 代理 | 目标类**没实现接口** | 生成子类；`final` 方法不能被代理 |

从 SpringBoot 2.x 起默认 `spring.aop.proxy-target-class=true`，一律用 CGLIB，避免\"接口内方法\"这一坑。

**（4）五种通知与执行顺序**

以 `@Around` 为中心，其它四种可以由它模拟：

```
     ┌──── @Around 前半段 ──────────┐
     │                              │
     │  @Before                     │
     │                              │ 
     │  ▼ 调用业务方法              │
     │                              │
     │  正常返回 → @AfterReturning  │
     │  抛出异常 → @AfterThrowing   │
     │                              │
     │  @After (无论成败)           │
     │                              │
     └──── @Around 后半段 ──────────┘
```

**注意：** `@Around` 是\"套住整个方法\"的通知，参数是 `ProceedingJoinPoint`，必须显式调用 `pjp.proceed()` 才会真正跑业务方法。本课程的操作日志用 `@Around`，因为要同时拿到\"入参 + 返回值 + 耗时 + 异常\"。

**（5）切点表达式速查**

`execution(修饰符? 返回类型 包名.类名.方法名(参数))`

例：`execution(* com.itcast.smart_elder.controller..*.*(..))`
- `*` 任意返回类型
- `com.itcast.smart_elder.controller..*` 该包及子包下任意类
- `.*` 任意方法名
- `(..)` 任意参数

本课程更推荐**注解切点**：`@annotation(com.itcast.smart_elder.annotation.OperationLog)`，只切打了注解的方法，粒度可控。

#### 3. 演示（10 分钟）

教师现场敲一个最简切面（不落库、只打印），让学生看到 AOP 的\"魔法\"：

**pom.xml 追加**（Day02 已有 spring-boot-starter-web，AOP 需要单独引入）：
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-aop</artifactId>
</dependency>
```

**HelloAspect.java**：
```java
package com.itcast.smart_elder.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Slf4j
public class HelloAspect {

    @Around(\"execution(* com.itcast.smart_elder.controller..*.*(..))\")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        log.info(\">>> 进入 {}\", pjp.getSignature().toShortString());
        try {
            Object result = pjp.proceed();
            log.info(\"<<< 完成 {} 耗时 {}ms\", pjp.getSignature().toShortString(),
                    System.currentTimeMillis() - start);
            return result;
        } catch (Throwable e) {
            log.error(\"!!! 异常 {} : {}\", pjp.getSignature().toShortString(), e.getMessage());
            throw e;
        }
    }
}
```

**启动项目 → 调用 Day08 大屏任意一个接口 → 观察控制台**：
```
>>> 进入 DashboardController.overview()
<<< 完成 DashboardController.overview() 耗时 12ms
```

学生的\"哇\"就在这里出来：**没有改任何业务代码**，就多了一份切面日志。

#### 4. 实操（10 分钟）

学生任务：
1. pom 添加 aop 依赖，刷新 Maven。
2. 复制 `HelloAspect`，把切点改成 `execution(* com.itcast.smart_elder.service..*.*(..))`，观察 Service 方法进出。
3. 在浏览器/Postman 调用任一接口，截图控制台粘贴到组内群里打卡。

教师巡视，重点纠正三种典型错误：
- 忘记加 `@Component`：切面没被容器管理，不生效。
- 忘记加 `@Aspect`：Spring 认不出这是切面。
- 切点表达式包名拼错（`smart_elder` 少写下划线）：切面\"静默失效\"，学生百思不得其解。

#### 5. 小结（3 分钟）
一句话回顾：AOP = **把重复的横切代码抽出来，用注解声明\"切哪里+做什么\"，Spring 用动态代理在运行期织入**。
预告：下节课我们不用包名匹配切点，改用一个**自定义注解**当\"贴纸\"，贴哪切哪，粒度最精。

### 四、课上提问
1. Spring AOP 采用的是编译期织入还是运行期织入？为什么？
2. 一个类没实现接口，Spring 会给它用哪种代理？
3. `@Around` 相比 `@Before + @AfterReturning + @AfterThrowing` 组合，唯一的\"超能力\"是什么？

### 五、课堂练习
1. 用一句切点表达式，只切位于 `controller` 包下、方法名以 `list`、`page`、`detail` 结尾的方法。
2. 写一个 `@Before` 通知，打印\"当前用户 IP\"（IP 用 `RequestContextHolder` 取），只切 `save`、`update`、`delete` 开头的方法。

### 六、课后思考
如果一个 Service 方法 A 里调用了同类的 Service 方法 B，B 上有切面，B 会被切到吗？（引出\"AOP 自调用失效\"经典陷阱，为讲义附录做铺垫。）

### 七、课后作业
1. 把今天的 `HelloAspect` 迁移到 IDEA，跑通并把控制台日志截图交到班级群。
2. 在草稿本上写出 AOP 五术语的中英文与一句话解释。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  AOP 原理与 Spring AOP                   │
├──────────────────────────────────────────┤
│ 术语：JoinPoint/Pointcut/Advice          │
│       Aspect/Weaving                     │
│ 基石：动态代理（JDK / CGLIB）            │
│ 通知：@Before @After @AfterReturning     │
│       @AfterThrowing @Around ★           │
│ 切点：execution(...) / @annotation(...)  │
└──────────────────────────────────────────┘
```

---

## 第 2 课时：自定义注解 @OperationLog

### 一、教学目标
- 知识目标：掌握 Java 注解三要素（`@Target`、`@Retention`、`@Documented`）；理解元注解与自定义注解的关系；掌握注解字段（元素）的声明语法与 `default` 默认值；理解为什么日志切面必须使用 `@Retention(RUNTIME)`；能够为一个自定义注解设计合理的字段集合（module / operation / saveParams / saveResult）。
- 能力目标：能独立完成 `@OperationLog` 注解代码；能在 Controller 方法上正确使用注解，写出 `@OperationLog(module=\"会员管理\", operation=\"新增\")` 这样的元数据。

### 二、教学重难点
- 重点：`@Target(ElementType.METHOD)` 与 `@Retention(RetentionPolicy.RUNTIME)` 两条元注解的必然性；`saveParams` / `saveResult` 布尔字段的用途（控制是否入库敏感字段）。
- 难点：`SOURCE / CLASS / RUNTIME` 三种保留策略的差异；\"注解本身不做任何事，做事的是切面\"这个认知。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师展示上节课的切点表达式 `execution(* com.itcast.smart_elder.controller..*.*(..))`，问：\"如果我只想给\'新增会员\'\'删除客房\'这些写操作打日志，读操作不打，怎么办？在表达式里堆一大串 `||` 吗？\"

引出解决方案：**做一个自定义注解 `@OperationLog`，需要打日志的方法就贴一张\"贴纸\"，切面只切贴了纸的方法**。

#### 2. 讲授（18 分钟）

**（1）Java 注解是什么**

注解本质是一个\"打了标记的接口\"，它自己不做任何事。真正读取注解并采取行动的，是反射代码或框架（例如 Spring、我们的 AOP 切面）。

**（2）元注解**

元注解 = 用来给\"注解\"打标签的注解，共 5 个常用：

| 元注解 | 作用 | 常用值 |
|--------|------|--------|
| @Target | 注解能贴在什么位置 | METHOD / TYPE / FIELD / PARAMETER |
| @Retention | 注解保留到什么阶段 | SOURCE / CLASS / RUNTIME |
| @Documented | 生成 Javadoc 时是否保留 | 通常加上 |
| @Inherited | 子类是否继承父类的注解 | 少用 |
| @Repeatable | 是否可重复贴在同一元素上 | JDK 8+ |

**Retention 三阶段对比**：

| 阶段 | 存在于 | 典型例子 |
|------|--------|----------|
| SOURCE | 只在 .java 源码 | `@Override`（编译后就丢了） |
| CLASS | 编译到 .class 但运行时反射看不到 | 默认值 |
| RUNTIME | 运行时反射可读 | 所有需要框架处理的注解 |

**结论：** 日志切面在运行时用反射读注解，必须 `RUNTIME`。

**（3）字段设计**

给 `@OperationLog` 定义 4 个字段，覆盖\"日志记录什么\"的所有场景：

| 字段 | 类型 | 默认值 | 用途 |
|------|------|--------|------|
| module | String | \"\" | 业务模块名（会员管理/客房管理/预约管理） |
| operation | String | \"\" | 具体动作（新增/删除/修改/查询） |
| saveParams | boolean | true | 是否把入参 JSON 存进日志 |
| saveResult | boolean | false | 是否把返回值存进日志 |

**为什么 `saveResult` 默认 false？** 返回值可能非常大（比如分页列表 100 条），全部落库既撑爆日志表，也没什么价值。默认关，需要时手动开。

#### 3. 演示（12 分钟）

教师现场敲注解定义与使用：

**`src/main/java/com/itcast/smart_elder/annotation/OperationLog.java`**：
```java
package com.itcast.smart_elder.annotation;

import java.lang.annotation.*;

/**
 * 操作日志注解。
 * 贴在 Controller 或 Service 的方法上，
 * 由 OperationLogAspect 拦截并异步入库。
 */
@Target(ElementType.METHOD)      // 只能贴方法
@Retention(RetentionPolicy.RUNTIME) // 运行期可反射读取
@Documented
public @interface OperationLog {

    /** 业务模块（会员管理 / 客房管理 / 预约管理 / 大屏统计 ...） */
    String module() default \"\";

    /** 具体操作（新增 / 修改 / 删除 / 查询 / 导出 ...） */
    String operation() default \"\";

    /** 是否记录入参 JSON，默认 true */
    boolean saveParams() default true;

    /** 是否记录返回结果 JSON，默认 false（大响应可能撑爆库） */
    boolean saveResult() default false;
}
```

**使用示例**——教师翻开 Day03 的 `MemberController`，在几个方法上贴注解：

```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.annotation.OperationLog;
import com.itcast.smart_elder.dto.MemberDTO;
import com.itcast.smart_elder.service.MemberService;
import com.itcast.smart_elder.common.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(\"/api/members\")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @OperationLog(module = \"会员管理\", operation = \"新增\")
    @PostMapping
    public Result<Void> save(@RequestBody MemberDTO dto) {
        memberService.save(dto);
        return Result.success();
    }

    @OperationLog(module = \"会员管理\", operation = \"修改\")
    @PutMapping
    public Result<Void> update(@RequestBody MemberDTO dto) {
        memberService.update(dto);
        return Result.success();
    }

    @OperationLog(module = \"会员管理\", operation = \"删除\", saveParams = true)
    @DeleteMapping(\"/{id}\")
    public Result<Void> delete(@PathVariable Long id) {
        memberService.delete(id);
        return Result.success();
    }

    // 只读接口，不打日志：不贴注解即可
    @GetMapping(\"/page\")
    public Result<?> page(Integer page, Integer size) {
        return Result.success(memberService.page(page, size));
    }
}
```

教师强调：**注解贴上后，运行项目并不会有任何变化**，因为切面还没写。这是为了让学生亲眼看到\"注解本身不做事\"这个认知。

#### 4. 实操（9 分钟）

学生任务：
1. 在自己项目里创建 `annotation` 包，敲入 `@OperationLog` 定义。
2. 在 Day03 会员 CRUD、Day04 客房 CRUD 的写操作方法上贴注解（至少 6 个方法），`module` 和 `operation` 写具体中文。
3. 重启项目，调用一次\"新增会员\"接口，观察控制台——**不会有日志**。教师引导：\"这正说明我们需要下节课的切面。\"

#### 5. 小结（3 分钟）
- 元注解决定了自定义注解的**行为边界**。
- `@Target(METHOD) + @Retention(RUNTIME)` 是所有\"给方法贴标签、运行期切面消费\"的固定组合。
- 注解本身不做事——切面才是执行者。

### 四、课上提问
1. `@Retention(CLASS)` 的注解，为什么 AOP 切面读不到？
2. 如果我想让 `@OperationLog` 也能贴在\"类\"上（表示类下所有方法都记录），该如何改？
3. `saveResult` 为什么默认 false？

### 五、课堂练习
1. 给 Day04 客房管理的所有写操作贴上注解，`module=\"客房管理\"`。
2. 新增一个方法\"批量删除\"，注解写成 `@OperationLog(module=\"客房管理\", operation=\"批量删除\", saveParams=true, saveResult=true)`。

### 六、课后思考
如果注解里想加一个\"耗时阈值\"字段（超过多少毫秒才记录），字段类型该是什么？默认值给多少合理？

### 七、课后作业
在草稿本上画出\"注解 - 反射 - 切面\"三者的关系图，明天课前互相讲一遍。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  自定义注解 @OperationLog                │
├──────────────────────────────────────────┤
│ 元注解：@Target(METHOD)                  │
│        @Retention(RUNTIME)               │
│        @Documented                       │
│ 字段：module / operation                 │
│      saveParams(默认true)                │
│      saveResult(默认false)               │
│ 认知：注解本身不做事，切面才做事         │
└──────────────────────────────────────────┘
```

---

## 第 3 课时：环绕通知与参数解析

### 一、教学目标
- 知识目标：掌握 `@Around` 通知的完整写法与 `ProceedingJoinPoint` 用法；掌握从 `MethodSignature` 反射拿到方法上的 `@OperationLog` 注解；理解为什么要用 Jackson 而不是 `toString()` 序列化参数；掌握过滤 `HttpServletRequest` / `MultipartFile` / `HttpServletResponse` 等\"不可序列化\"参数的必要性；掌握从请求头 `X-User-Id` 读取当前用户 ID 的简化方案；掌握获取真实客户端 IP 的技巧（`X-Forwarded-For` / `X-Real-IP` / `RemoteAddr`）。
- 能力目标：能独立完成 `OperationLogAspect` 骨架代码；能在 Postman 里带上 `X-User-Id: 1` 请求头触发一次接口，切面控制台打印\"user=1 module=会员管理 operation=新增 params={...} ip=127.0.0.1 cost=15ms\"。

### 二、教学重难点
- 重点：`ProceedingJoinPoint.proceed()` 的调用位置和异常处理；反射拿注解的三行代码；参数序列化时过滤特殊类型。
- 难点：\"耗时统计\"必须放在 try/finally 中确保异常也计入耗时；\"IP 获取\"多层代理场景的取值顺序。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
上节课贴了注解，运行项目没反应。今天我们让\"贴纸\"真正生效——写一个专门盯住 `@OperationLog` 的切面。

#### 2. 讲授（18 分钟）

**（1）切面骨架**

一个操作日志切面必须完成 6 件事：
1. 通过 `@annotation(...)` 只匹配打了注解的方法。
2. 记录**开始时间**（`long start = System.currentTimeMillis()`）。
3. 反射取出注解的 `module` / `operation` / `saveParams` / `saveResult`。
4. 拿到入参 JSON、返回值 JSON、异常信息。
5. 拿到当前登录用户 ID 与客户端 IP。
6. 组装 `OperationLog` 实体，**异步**入库（下节课细讲，本课时先只 log.info 打印占位）。

**（2）反射取注解的三行代码**

```java
MethodSignature signature = (MethodSignature) pjp.getSignature();
Method method = signature.getMethod();
OperationLog opLog = method.getAnnotation(OperationLog.class);
```

**（3）参数序列化为什么用 Jackson**

`pjp.getArgs()` 返回 `Object[]`，直接 `Arrays.toString()` 会得到\"MemberDTO@1a2b\"这种毫无价值的字符串。用 Jackson `ObjectMapper.writeValueAsString(args)` 可以还原成真正的 JSON。但要小心以下类型：

| 危险类型 | 为什么危险 | 处理 |
|----------|-----------|------|
| HttpServletRequest / Response | 循环引用，直接抛栈溢出 | 过滤跳过 |
| MultipartFile | 二进制流，序列化即失败 | 过滤跳过 |
| BindingResult | Spring 校验对象，含 target 反引用自身 | 过滤跳过 |

过滤办法：把 `args` 里\"值得序列化\"的元素挑出来放到 `List` 再转 JSON。

**（4）当前用户 ID 的简化方案**

Day03 讲会员时我们**没有实现完整登录鉴权**。本课程为教学简化，约定前端所有请求都带 `X-User-Id: 1` 请求头，切面直接从 header 里读。生产项目会用 JWT + Interceptor 解析出用户 ID 存 `ThreadLocal` — 这个升级我们放到 Day10。

**（5）真实客户端 IP**

单机部署直接 `request.getRemoteAddr()` 就够了。但 Nginx 反代场景下 `getRemoteAddr()` 拿到的是 Nginx 的 IP，真实 IP 藏在请求头里：

```java
String ip = request.getHeader(\"X-Forwarded-For\");
if (ip == null || ip.isEmpty() || \"unknown\".equalsIgnoreCase(ip)) {
    ip = request.getHeader(\"X-Real-IP\");
}
if (ip == null || ip.isEmpty()) {
    ip = request.getRemoteAddr();
}
// X-Forwarded-For 可能是\"clientA, proxyB, proxyC\"，第一个才是客户端
if (ip != null && ip.contains(\",\")) {
    ip = ip.split(\",\")[0].trim();
}
```

#### 3. 演示（14 分钟）

教师先建 `OperationLog` 实体（下节课要复用），再写切面骨架。

**`entity/OperationLog.java`**（映射 Day01 已建的 `operation_log` 表）：
```java
package com.itcast.smart_elder.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@TableName(\"operation_log\")
public class OperationLog {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private String module;
    private String operation;
    private String method;      // 全限定方法名
    private String params;      // 入参 JSON
    private String result;      // 返回值 JSON（可空）
    private String ip;
    private Long costTime;      // 毫秒
    private LocalDateTime createTime;
}
```

**`aspect/OperationLogAspect.java`**（本课时先只打印，日志入库放到下节课）：
```java
package com.itcast.smart_elder.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itcast.smart_elder.annotation.OperationLog;
import com.itcast.smart_elder.entity.OperationLog;   // 注意：实体类同名，需类型别名或换名。演示时把注解 import 改成 as：
// 为避免混淆，把\"实体\"改名 OperationLogEntity，见下方注释
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
```

**教师现场重构：** 由于\"注解\"和\"实体\"同名会冲突，教师把实体类改名为 `OperationLogEntity`（推荐做法）。改名后：

```java
package com.itcast.smart_elder.entity;
// ...
@Data
@TableName(\"operation_log\")
public class OperationLogEntity { /* 同上 */ }
```

**`aspect/OperationLogAspect.java`**（完整版）：
```java
package com.itcast.smart_elder.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itcast.smart_elder.annotation.OperationLog;
import com.itcast.smart_elder.entity.OperationLogEntity;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Aspect
@Component
@Slf4j
public class OperationLogAspect {

    @Autowired
    private ObjectMapper objectMapper;   // SpringBoot 已自动装配

    @Around(\"@annotation(operationLog)\")
    public Object around(ProceedingJoinPoint pjp, OperationLog operationLog) throws Throwable {
        long start = System.currentTimeMillis();
        Throwable throwable = null;
        Object result = null;
        try {
            result = pjp.proceed();
            return result;
        } catch (Throwable e) {
            throwable = e;
            throw e;
        } finally {
            long cost = System.currentTimeMillis() - start;
            try {
                OperationLogEntity entity = buildLog(pjp, operationLog, result, throwable, cost);
                // 本课时先打印，下节课换成异步入库
                log.info(\"[OperationLog] {}\", objectMapper.writeValueAsString(entity));
            } catch (Exception ignore) {
                log.warn(\"记录操作日志失败: {}\", ignore.getMessage());
            }
        }
    }

    private OperationLogEntity buildLog(ProceedingJoinPoint pjp, OperationLog op,
                                        Object result, Throwable throwable, long cost) throws Exception {
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();

        OperationLogEntity entity = new OperationLogEntity();
        entity.setModule(op.module());
        entity.setOperation(op.operation());
        entity.setMethod(method.getDeclaringClass().getSimpleName() + \".\" + method.getName());
        entity.setCostTime(cost);
        entity.setCreateTime(LocalDateTime.now());

        // 入参
        if (op.saveParams()) {
            entity.setParams(serializeArgs(pjp.getArgs()));
        }
        // 返回值
        if (op.saveResult() && throwable == null) {
            entity.setResult(safeSerialize(result));
        }
        if (throwable != null) {
            entity.setResult(\"Exception: \" + throwable.getMessage());
        }

        // 从请求头取用户与 IP
        HttpServletRequest request = getRequest();
        if (request != null) {
            String uid = request.getHeader(\"X-User-Id\");
            if (uid != null && !uid.isEmpty()) {
                try { entity.setUserId(Long.parseLong(uid)); } catch (Exception ignored) {}
            }
            entity.setIp(getClientIp(request));
        }
        return entity;
    }

    /** 过滤不可序列化参数后再转 JSON */
    private String serializeArgs(Object[] args) {
        if (args == null || args.length == 0) return \"[]\";
        List<Object> safe = new ArrayList<>();
        for (Object a : args) {
            if (a == null) { safe.add(null); continue; }
            if (a instanceof HttpServletRequest) continue;
            if (a instanceof HttpServletResponse) continue;
            if (a instanceof MultipartFile) { safe.add(\"[MultipartFile:\" + ((MultipartFile) a).getOriginalFilename() + \"]\"); continue; }
            if (a instanceof byte[]) { safe.add(\"[bytes:\" + ((byte[]) a).length + \"]\"); continue; }
            safe.add(a);
        }
        return safeSerialize(safe);
    }

    private String safeSerialize(Object obj) {
        try {
            String json = objectMapper.writeValueAsString(obj);
            // 防止超大响应撑爆 TEXT，截断
            return json.length() > 2000 ? json.substring(0, 2000) + \"...(truncated)\" : json;
        } catch (Exception e) {
            return \"[serialize error: \" + e.getMessage() + \"]\";
        }
    }

    private HttpServletRequest getRequest() {
        try {
            ServletRequestAttributes attrs = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            return attrs != null ? attrs.getRequest() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String getClientIp(HttpServletRequest req) {
        String ip = req.getHeader(\"X-Forwarded-For\");
        if (ip == null || ip.isEmpty() || \"unknown\".equalsIgnoreCase(ip)) ip = req.getHeader(\"X-Real-IP\");
        if (ip == null || ip.isEmpty()) ip = req.getRemoteAddr();
        if (ip != null && ip.contains(\",\")) ip = ip.split(\",\")[0].trim();
        return ip;
    }
}
```

启动项目，Postman 调用**新增会员**接口，带 `X-User-Id: 1` header，预期控制台输出：
```
[OperationLog] {\"userId\":1,\"module\":\"会员管理\",\"operation\":\"新增\",\"method\":\"MemberController.save\",\"params\":\"[{\\\"name\\\":\\\"张三\\\",...}]\",\"ip\":\"127.0.0.1\",\"costTime\":38,\"createTime\":\"...\"}
```

#### 4. 实操（8 分钟）

学生任务：
1. 把 `OperationLog` 实体改名为 `OperationLogEntity`（Idea 右键 Refactor → Rename 一步到位）。
2. 敲入 `OperationLogAspect`，重启项目。
3. Postman 调用会员新增，观察日志。特意漏掉 `X-User-Id`，看 `userId` 为 null 时不报错。
4. 尝试触发一次异常（比如 `name` 传 null 让校验失败），观察日志里 `result` 变成 `Exception: ...`。

#### 5. 小结（3 分钟）
一句话回顾：**`@Around` + 反射取注解 + Jackson 序列化 + 过滤特殊参数 + try/finally 保耗时 = 通用操作日志切面**。
下节课把 `log.info` 换成**异步入库**。

### 四、课上提问
1. `pjp.proceed()` 如果不调用会怎样？
2. `finally` 中为什么要外层 try/catch？
3. 为什么用 `System.currentTimeMillis()` 而不是 `System.nanoTime()`？

### 五、课堂练习
1. 修改切面，`saveResult=true` 时，若返回的是 `Result<PageBean>`，只记录 `total` 字段不记录 `rows`。（提示：反射判断字段。）
2. 在 `params` 里额外加入请求 URL：`request.getRequestURI()`。

### 六、课后思考
如果同一个方法上同时有 `@OperationLog` 和 `@Transactional`，两个切面谁先执行？（引出 `@Order` 与 `Ordered.HIGHEST_PRECEDENCE`。）

### 七、课后作业
把切面代码整理进项目，Git 提交 `feat(aop): operation log aspect skeleton`。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  环绕通知与参数解析                       │
├───────────────────────────────────────────┤
│ 切点：@annotation(operationLog)           │
│ 骨架：try { proceed } catch { rethrow }   │
│       finally { 组装+入库 }               │
│ 参数：Jackson + 过滤 Request/File         │
│ 用户：header X-User-Id                    │
│ IP  ：X-Forwarded-For > X-Real-IP > Remote│
└───────────────────────────────────────────┘
```

---

## 第 4 课时：日志异步落库

### 一、教学目标
- 知识目标：理解为什么日志必须异步——**不阻塞主业务、不影响接口响应时间**；掌握 `@EnableAsync` 与 `@Async` 的成对使用；理解默认 `SimpleAsyncTaskExecutor` 每次 new 线程的隐患，掌握自定义 `ThreadPoolTaskExecutor` 的 6 个核心参数（core / max / queue / keepAlive / threadName / rejectPolicy）；理解异步方法在\"自调用\"场景失效的经典陷阱；掌握 `try/catch` 保护写日志失败不影响主业务的原则；了解 Spring Event 作为替代方案（拓展阅读）。
- 能力目标：能独立完成 `AsyncConfig` 配置类、`OperationLogService.saveAsync` 与 `OperationLogMapper`；启动项目后能观察到日志在异步线程 `elder-log-1` 中入库。

### 二、教学重难点
- 重点：`@EnableAsync` 位置（放在启动类或配置类）；线程池参数的经验值；`@Async` 方法必须**通过 Bean 调用**才生效。
- 难点：拒绝策略的四种取舍（AbortPolicy / CallerRunsPolicy / DiscardPolicy / DiscardOldestPolicy）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师提问：\"上节课日志一条 `INSERT` 大约 5 ms。如果我们的接口本身只要 15 ms，加上日志就变 20 ms，性能下降 33%。有没有办法让日志\'走后门\'？\"引出**异步**。

#### 2. 讲授（18 分钟）

**（1）Spring 异步执行的两把钥匙**
- `@EnableAsync`：一把总开关，放在启动类或任一 `@Configuration` 上。
- `@Async`：贴在方法上，Spring 会用**代理**把方法调用扔到线程池。

**（2）默认线程池的坑**
不指定 executor 时，SpringBoot 使用一个简单的 `SimpleAsyncTaskExecutor`：每次任务都 **new Thread**，不复用、无上限。并发一高，线程飙升，OOM 或者 CPU 打满。**生产必须自定义线程池**。

**（3）线程池 6 参数**

| 参数 | 含义 | 日志场景推荐值 |
|------|------|--------------|
| corePoolSize | 常驻线程数 | 2 |
| maxPoolSize | 最大线程数 | 10 |
| queueCapacity | 队列容量 | 500 |
| keepAliveSeconds | 空闲线程存活时间 | 60 |
| threadNamePrefix | 线程名前缀（好排查） | \"elder-log-\" |
| rejectedExecutionHandler | 拒绝策略 | `CallerRunsPolicy` |

**为什么选 `CallerRunsPolicy`？** 日志不能丢，但也不能拖垮主业务：队列满时让\"提交任务的线程\"（主线程）自己跑一次，起到降级+背压效果。

**（4）自调用陷阱**
```java
@Service
public class FooService {
    public void a() {
        this.b();       // ❌ this 不是代理，@Async 失效
    }
    @Async
    public void b() { ... }
}
```
本项目里我们把 `saveAsync` 单独放在 `OperationLogService` 里，由**切面**调用，走的是 Spring 容器里的代理对象，天然规避这个坑。

**（5）失败不影响主业务**
切面调用 `saveAsync` 的位置已经在业务方法执行**之后**的 `finally` 块里，即便日志线程报错（比如 DB 挂了），主业务已经返回给了前端，只是日志漏一条——用 `try/catch` 吞掉日志异常即可。

**（6）拓展阅读：Spring Event 替代方案**
另一种做法：切面发布 `OperationLogEvent`，`@EventListener(condition, ...) @Async` 消费。优点是解耦，缺点是学生第一次接触事件模型容易懵。**本课程主写线程池方案，Spring Event 作为课后自选拓展。**

#### 3. 演示（14 分钟）

**`config/AsyncConfig.java`**：
```java
package com.itcast.smart_elder.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
@Slf4j
public class AsyncConfig {

    @Bean(\"logTaskExecutor\")
    public Executor logTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(500);
        executor.setKeepAliveSeconds(60);
        executor.setThreadNamePrefix(\"elder-log-\");
        // 队列满时降级：交给提交线程自己执行
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        // JVM 退出前跑完队列里的任务
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();
        log.info(\"日志异步线程池初始化完成\");
        return executor;
    }
}
```

**`mapper/OperationLogMapper.java`**：
```java
package com.itcast.smart_elder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.itcast.smart_elder.entity.OperationLogEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OperationLogMapper extends BaseMapper<OperationLogEntity> {
}
```

**`service/OperationLogService.java`**：
```java
package com.itcast.smart_elder.service;

import com.itcast.smart_elder.entity.OperationLogEntity;
import com.itcast.smart_elder.mapper.OperationLogMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OperationLogService {

    @Autowired
    private OperationLogMapper operationLogMapper;

    /** 异步落库，走 logTaskExecutor 线程池 */
    @Async(\"logTaskExecutor\")
    public void saveAsync(OperationLogEntity entity) {
        try {
            operationLogMapper.insert(entity);
        } catch (Exception e) {
            // 日志失败不能影响主业务，吞掉异常
            log.error(\"操作日志入库失败: {}\", e.getMessage(), e);
        }
    }
}
```

**改造 `OperationLogAspect`**：把上节课的 `log.info` 换成调用 service。

```java
// 新增字段
@Autowired
private OperationLogService operationLogService;

// 在 finally 里
OperationLogEntity entity = buildLog(pjp, operationLog, result, throwable, cost);
operationLogService.saveAsync(entity);   // ← 异步入库
```

启动项目，Postman 调用**新增会员**，观察三点：
1. 主线程线程名是 `http-nio-8080-exec-1`。
2. 日志线程名是 `elder-log-1`。
3. 打开 Navicat 查询 `operation_log` 表，多了一条记录。

**制造队列满**：临时把 `queueCapacity` 改成 2，`maxPoolSize` 改成 2，`corePoolSize` 改成 1，然后 for 循环 20 次调接口，观察部分日志\"意外地\"跑在 `http-nio-...` 线程里——这就是 `CallerRunsPolicy` 在起作用。改完后再把参数改回去。

#### 4. 实操（8 分钟）

学生任务：
1. 敲入 `AsyncConfig`、`OperationLogService`、`OperationLogMapper`，改造切面。
2. 调用一次新增会员，在数据库看到一条日志。
3. **拔网**（临时改 `application.yml` 里数据库密码为错的），再调用一次接口，观察：接口正常返回 200，但控制台报\"操作日志入库失败\"，验证\"日志失败不影响主业务\"。改完记得把密码改回来。

#### 5. 小结（3 分钟）
- `@EnableAsync + @Async` 是标配。
- 生产必须自定义线程池，参数以 `elder-log-` 为前缀便于问题定位。
- 日志失败必须吞异常。

### 四、课上提问
1. `@Async` 为什么在同类自调用下失效？
2. 如果日志入库比主业务还慢，会发生什么？（队列满、拒绝策略被触发）
3. `CallerRunsPolicy` 相比 `AbortPolicy` 的优势是什么？

### 五、课堂练习
1. 把 `threadNamePrefix` 改成 `elder-oplog-`，重启后查看日志线程名。
2. 触发 20 次并发接口调用，观察 `elder-log-1` 到 `elder-log-2` 是否复用。

### 六、课后思考
如果一个操作日志必须\"事务级可靠\"（比如金融合规），线程池方案够用吗？（引出 MQ 持久化、事务性发件箱等下一层设计。）

### 七、课后作业
Git 提交 `feat(aop): async persist operation log`；调用 20 次会员接口，截图 `operation_log` 表最新 20 行。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  日志异步落库                             │
├───────────────────────────────────────────┤
│ @EnableAsync + @Async(\"logTaskExecutor\")│
│ 线程池: core=2 max=10 queue=500           │
│ 拒绝策略: CallerRunsPolicy                │
│ 日志失败 → try/catch 吞掉                 │
│ 陷阱: 自调用失效（走代理）                │
└───────────────────────────────────────────┘
```

---

## 第 5 课时：全局异常处理 + 统一响应

### 一、教学目标
- 知识目标：回顾 Day03 引入的 `GlobalExceptionHandler`；掌握错误码枚举 `ErrorCode` 的设计与命名规则（4 位数分段：1xxx 客户端 / 2xxx 权限 / 3xxx 业务 / 4xxx 数据 / 5xxx 系统）；掌握 `BusinessException` 的正确使用姿势（Service 层\"业务不通\"直接抛，Controller 不需要 try/catch）；掌握 `MethodArgumentNotValidException`（`@Valid` 校验失败）与 `ConstraintViolationException`（`@Validated` 参数校验失败）的差异；掌握系统级异常 fallback 的必要性。
- 能力目标：能独立完成 `ErrorCode` 枚举、`BusinessException` 类、`GlobalExceptionHandler` 完整代码；能主动在 Service 层抛 `BusinessException(ErrorCode.MEMBER_NOT_FOUND)`，前端拿到 `{code:3001, msg:\"会员不存在\"}` 的标准响应。

### 二、教学重难点
- 重点：错误码分段规则；`@RestControllerAdvice` + `@ExceptionHandler` 的匹配顺序。
- 难点：`MethodArgumentNotValidException.getBindingResult().getFieldErrors()` 组装多字段错误消息；系统异常 `Exception.class` fallback 的位置（放最后）。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师展示一段真实报错场景：调用\"删除会员\"接口，会员不存在时前端拿到：
```
500 Internal Server Error
{ \"timestamp\": ..., \"trace\": \"NullPointerException at ...\" }
```
问：\"前端同学看到 500 一头雾水，还得跑来问后端\'到底哪里错了\'。有没有更好的做法？\"引出**统一错误码 + 全局异常处理**。

#### 2. 讲授（16 分钟）

**（1）错误码命名规则**

| 段 | 范围 | 含义 | 示例 |
|----|------|------|------|
| 0xxx | 0000 | 成功 | 0000 |
| 1xxx | 1001-1999 | 客户端参数错误 | 1001 参数校验失败 / 1002 参数缺失 |
| 2xxx | 2001-2999 | 认证/授权 | 2001 未登录 / 2003 无权限 |
| 3xxx | 3001-3999 | 业务规则 | 3001 会员不存在 / 3002 客房已被预约 |
| 4xxx | 4001-4999 | 数据库/资源 | 4001 唯一约束冲突 |
| 5xxx | 5001-5999 | 系统级 | 5000 服务器内部错误 |

分段的好处：**看到 code 前缀就知道大类**，运维、前端、后端沟通瞬间对齐。

**（2）BusinessException 的使用姿势**

Service 层遇到\"业务不通\"（会员不存在、库存不足、状态非法）不应 `return null` 或 `return false`，而是**抛 `BusinessException`**。Controller 里**不要 try/catch**，让全局处理器统一响应。

**（3）Validation 校验失败**

Day03 我们在 `MemberDTO` 上用了 `@NotBlank` `@Email` 等注解，配合 Controller 的 `@Valid`。当校验失败时 Spring 抛：
- `MethodArgumentNotValidException`（`@RequestBody` 场景）
- `BindException`（`@ModelAttribute` 场景）
- `ConstraintViolationException`（`@Validated` 单参数场景）

全局处理器需要覆盖这三类，把多个字段的错误拼成\"name 不能为空; email 格式错误\"这样的可读消息。

**（4）系统异常 fallback**

任何没被具体 handler 匹配到的异常，最后由 `Exception.class` 兜底。这里返回 5000 系统错误，**不要把堆栈直接抛给前端**，只 log.error 记录堆栈、response 只给出\"服务器内部错误\"字样。

#### 3. 演示（15 分钟）

**`common/ErrorCode.java`**：
```java
package com.itcast.smart_elder.common;

import lombok.Getter;

@Getter
public enum ErrorCode {
    SUCCESS(0, \"成功\"),

    // 1xxx 客户端参数
    PARAM_INVALID(1001, \"参数校验失败\"),
    PARAM_MISSING(1002, \"参数缺失\"),
    PARAM_TYPE_MISMATCH(1003, \"参数类型错误\"),

    // 2xxx 认证/授权
    UNAUTHORIZED(2001, \"未登录或登录已过期\"),
    FORBIDDEN(2003, \"无权限访问\"),

    // 3xxx 业务
    MEMBER_NOT_FOUND(3001, \"会员不存在\"),
    ROOM_NOT_FOUND(3002, \"客房不存在\"),
    ROOM_OCCUPIED(3003, \"客房已被占用\"),
    RESERVATION_NOT_FOUND(3004, \"预约单不存在\"),
    RESERVATION_STATUS_ILLEGAL(3005, \"预约状态不合法\"),
    OPERATION_LOG_NOT_FOUND(3006, \"操作日志不存在\"),

    // 4xxx 数据
    DATA_DUPLICATE(4001, \"数据重复，请检查唯一字段\"),
    DATA_NOT_FOUND(4002, \"数据不存在\"),

    // 5xxx 系统
    SYSTEM_ERROR(5000, \"服务器内部错误，请稍后重试\");

    private final int code;
    private final String msg;

    ErrorCode(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
```

**`common/BusinessException.java`**：
```java
package com.itcast.smart_elder.common;

import lombok.Getter;

@Getter
public class BusinessException extends RuntimeException {
    private final int code;

    public BusinessException(ErrorCode errorCode) {
        super(errorCode.getMsg());
        this.code = errorCode.getCode();
    }

    public BusinessException(ErrorCode errorCode, String msgOverride) {
        super(msgOverride);
        this.code = errorCode.getCode();
    }
}
```

**`common/Result.java`**（如 Day02 已有则补齐 `error(code, msg)` 静态方法）：
```java
package com.itcast.smart_elder.common;

import lombok.Data;

@Data
public class Result<T> {
    private int code;
    private String msg;
    private T data;

    public static <T> Result<T> success() { return success(null); }
    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.code = ErrorCode.SUCCESS.getCode();
        r.msg = ErrorCode.SUCCESS.getMsg();
        r.data = data;
        return r;
    }
    public static <T> Result<T> error(ErrorCode ec) { return error(ec.getCode(), ec.getMsg()); }
    public static <T> Result<T> error(int code, String msg) {
        Result<T> r = new Result<>();
        r.code = code;
        r.msg = msg;
        return r;
    }
}
```

**`handler/GlobalExceptionHandler.java`**（Day03 骨架 + 本课时补齐）：
```java
package com.itcast.smart_elder.handler;

import com.itcast.smart_elder.common.BusinessException;
import com.itcast.smart_elder.common.ErrorCode;
import com.itcast.smart_elder.common.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.stream.Collectors;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /** 业务异常：Service 主动抛出 */
    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBusiness(BusinessException e) {
        log.warn(\"业务异常: code={} msg={}\", e.getCode(), e.getMessage());
        return Result.error(e.getCode(), e.getMessage());
    }

    /** @Valid @RequestBody 校验失败 */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<?> handleValid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + \" \" + fe.getDefaultMessage())
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    /** @ModelAttribute 表单绑定校验失败 */
    @ExceptionHandler(BindException.class)
    public Result<?> handleBind(BindException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + \" \" + fe.getDefaultMessage())
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    /** @Validated 单参数校验失败 */
    @ExceptionHandler(ConstraintViolationException.class)
    public Result<?> handleConstraint(ConstraintViolationException e) {
        String msg = e.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining(\"; \"));
        return Result.error(ErrorCode.PARAM_INVALID.getCode(), msg);
    }

    /** 兜底：任何其它异常 */
    @ExceptionHandler(Exception.class)
    public Result<?> handleAny(Exception e) {
        log.error(\"未预期异常: \", e);
        return Result.error(ErrorCode.SYSTEM_ERROR);
    }
}
```

**在 `MemberService.getById` 里演示业务抛异常**：
```java
public MemberVO getById(Long id) {
    Member m = memberMapper.selectById(id);
    if (m == null) throw new BusinessException(ErrorCode.MEMBER_NOT_FOUND);
    return convert(m);
}
```

Postman 调 `/api/members/9999` → 拿到 `{code:3001, msg:\"会员不存在\", data:null}`，HTTP 状态码依然 200（业务错误不用非要 500）。

#### 4. 实操（8 分钟）

学生任务：
1. 敲入 `ErrorCode`、`BusinessException`、补齐 `Result.error`。
2. 完善 `GlobalExceptionHandler` 五个 handler。
3. 在会员详情接口里主动抛业务异常，Postman 拿到 3001 错误码。
4. 在新增会员接口里故意漏 `name` 字段，观察拿到 `{code:1001, msg:\"name 不能为空\"}`。

#### 5. 小结（3 分钟）
- 错误码分段是团队协作的\"通用语言\"。
- Service 抛异常、Controller 不 catch、GlobalExceptionHandler 统一响应。
- 系统异常 fallback **必须**放在最后。

### 四、课上提问
1. `@RestControllerAdvice` 相比 `@ControllerAdvice` 多做了什么？（自动加 `@ResponseBody`）
2. 如果同一个异常被两个 `@ExceptionHandler` 匹配，谁优先？（子类优先）
3. 前端如何区分\"业务失败\"与\"系统失败\"？（code 前缀 3xxx vs 5xxx）

### 五、课堂练习
1. 新增错误码 `ROOM_STATUS_ILLEGAL(3007, \"客房状态不合法\")`。
2. 在客房下架接口中判断，如已有活跃预约就抛该异常。

### 六、课后思考
如果一个错误码需要国际化（中文/英文两个 msg），当前 enum 设计还够用吗？如何扩展？

### 七、课后作业
Git 提交 `feat(common): unified error code and global exception handler`；把 Day03/Day04/Day06 里遗留的\"if null return\"改成\"抛业务异常\"。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  全局异常处理 + 统一响应                  │
├───────────────────────────────────────────┤
│ ErrorCode enum: 1xxx参 2xxx权 3xxx业      │
│                4xxx数据 5xxx系统          │
│ BusinessException(ErrorCode)              │
│ @RestControllerAdvice                     │
│  ├ BusinessException                      │
│  ├ MethodArgumentNotValidException        │
│  ├ BindException                          │
│  ├ ConstraintViolationException           │
│  └ Exception ← fallback                   │
└───────────────────────────────────────────┘
```

---

## 第 6 课时：前端日志查询页面 + 联调

### 一、教学目标
- 知识目标：设计操作日志分页查询接口的 URL 与参数（时间区间 / 模块 / 用户 ID）；掌握 Vue3 组合式 API 下用 `ref` 管理表格数据、加载状态、查询表单；掌握 `el-table` 的\"展开行\"用法（查看完整 params/result）；掌握**前端方式导出 CSV**——将 rows 拼字符串 → `Blob` → `URL.createObjectURL` → `a.download`；理解为什么小数据量场景前端导出比后端更快。
- 能力目标：能独立完成 `LogController` 分页查询接口、`api/log.ts` 请求封装、`views/log/list.vue` 完整页面；能在浏览器里筛选\"过去 7 天 会员管理\"看到对应日志、点击\"导出 CSV\"下载文件。

### 二、教学重难点
- 重点：后端 `pageQuery` 的 Mapper XML 动态 SQL；前端 `el-date-picker` 双向绑定 `[startTime, endTime]`；`el-table` 展开行 `<template #expand>`。
- 难点：CSV 导出时的**转义**（值里含逗号/引号/换行的处理）；时间戳格式化。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
5 天的努力今天要\"给管理员一个交代\"——建一个后台页面，让他能筛选、查看、导出所有操作日志。

#### 2. 讲授（15 分钟）

**（1）后端接口设计**

| 动作 | 方法 | URL | 备注 |
|------|------|-----|------|
| 分页查询 | GET | /api/logs/page | 参数：page/size/startTime/endTime/module/userId |
| 详情 | GET | /api/logs/{id} | 单条完整查询（前端展开行可复用） |

**（2）Mapper 动态 SQL 要点**

```xml
<select id=\"pageQuery\" resultType=\"...\">
    SELECT * FROM operation_log
    <where>
        <if test=\"startTime != null\">AND create_time &gt;= #{startTime}</if>
        <if test=\"endTime != null\">AND create_time &lt;= #{endTime}</if>
        <if test=\"module != null and module != ''\">AND module = #{module}</if>
        <if test=\"userId != null\">AND user_id = #{userId}</if>
    </where>
    ORDER BY create_time DESC
</select>
```

**（3）前端\"展开行\"用法**

`el-table` 的每行左侧一个三角图标，点开展示 `params` / `result` 的完整 JSON，避免主表格被超长字段撑爆。

**（4）CSV 前端导出思路**
```
rows → 每行拼成 \"col1,col2,col3\\n\"
含逗号/引号 → 用双引号包起来，内部引号变成 \"\"
拼完整字符串 → new Blob([str], {type: 'text/csv;charset=utf-8'})
→ createObjectURL → 创建 <a> 触发下载 → revokeObjectURL 释放
```

#### 3. 演示（15 分钟）

**后端 `LogController`**：
```java
package com.itcast.smart_elder.controller;

import com.itcast.smart_elder.common.Result;
import com.itcast.smart_elder.common.PageBean;
import com.itcast.smart_elder.entity.OperationLogEntity;
import com.itcast.smart_elder.service.OperationLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping(\"/api/logs\")
public class LogController {

    @Autowired
    private OperationLogService operationLogService;

    @GetMapping(\"/page\")
    public Result<PageBean<OperationLogEntity>> page(
            @RequestParam(defaultValue = \"1\") Integer page,
            @RequestParam(defaultValue = \"20\") Integer size,
            @RequestParam(required = false) String module,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) @DateTimeFormat(pattern = \"yyyy-MM-dd HH:mm:ss\") LocalDateTime startTime,
            @RequestParam(required = false) @DateTimeFormat(pattern = \"yyyy-MM-dd HH:mm:ss\") LocalDateTime endTime
    ) {
        return Result.success(operationLogService.pageQuery(page, size, module, userId, startTime, endTime));
    }

    @GetMapping(\"/{id}\")
    public Result<OperationLogEntity> detail(@PathVariable Long id) {
        return Result.success(operationLogService.getById(id));
    }
}
```

Service 追加：
```java
public PageBean<OperationLogEntity> pageQuery(Integer page, Integer size, String module,
                                              Long userId, LocalDateTime start, LocalDateTime end) {
    Page<OperationLogEntity> p = new Page<>(page, size);
    LambdaQueryWrapper<OperationLogEntity> qw = new LambdaQueryWrapper<>();
    if (module != null && !module.isEmpty()) qw.eq(OperationLogEntity::getModule, module);
    if (userId != null) qw.eq(OperationLogEntity::getUserId, userId);
    if (start != null) qw.ge(OperationLogEntity::getCreateTime, start);
    if (end != null) qw.le(OperationLogEntity::getCreateTime, end);
    qw.orderByDesc(OperationLogEntity::getCreateTime);
    IPage<OperationLogEntity> result = operationLogMapper.selectPage(p, qw);
    PageBean<OperationLogEntity> pb = new PageBean<>();
    pb.setTotal(result.getTotal());
    pb.setRows(result.getRecords());
    return pb;
}

public OperationLogEntity getById(Long id) {
    OperationLogEntity e = operationLogMapper.selectById(id);
    if (e == null) throw new BusinessException(ErrorCode.OPERATION_LOG_NOT_FOUND);
    return e;
}
```

**前端 `src/api/log.ts`**：
```typescript
import request from '@/utils/request'

export interface LogQuery {
  page: number
  size: number
  module?: string
  userId?: number
  startTime?: string
  endTime?: string
}

export const pageLog = (params: LogQuery) =>
  request.get('/api/logs/page', { params })

export const detailLog = (id: number) =>
  request.get(`/api/logs/${id}`)
```

**前端 `src/views/log/list.vue`**：
```vue
<template>
  <div class=\"log-page\">
    <el-card class=\"filter-card\">
      <el-form :inline=\"true\" :model=\"query\">
        <el-form-item label=\"时间区间\">
          <el-date-picker
            v-model=\"query.range\"
            type=\"datetimerange\"
            range-separator=\"至\"
            start-placeholder=\"开始时间\"
            end-placeholder=\"结束时间\"
            value-format=\"YYYY-MM-DD HH:mm:ss\"
          />
        </el-form-item>
        <el-form-item label=\"模块\">
          <el-select v-model=\"query.module\" placeholder=\"全部\" clearable style=\"width:150px\">
            <el-option label=\"会员管理\" value=\"会员管理\" />
            <el-option label=\"客房管理\" value=\"客房管理\" />
            <el-option label=\"预约管理\" value=\"预约管理\" />
            <el-option label=\"大屏统计\" value=\"大屏统计\" />
          </el-select>
        </el-form-item>
        <el-form-item label=\"用户ID\">
          <el-input v-model.number=\"query.userId\" placeholder=\"用户ID\" clearable style=\"width:120px\" />
        </el-form-item>
        <el-form-item>
          <el-button type=\"primary\" @click=\"onSearch\">查询</el-button>
          <el-button @click=\"onReset\">重置</el-button>
          <el-button type=\"success\" @click=\"onExport\">导出 CSV</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card>
      <el-table :data=\"rows\" v-loading=\"loading\" border stripe>
        <el-table-column type=\"expand\">
          <template #default=\"{ row }\">
            <div class=\"expand-detail\">
              <p><b>入参 params：</b></p>
              <pre>{{ row.params }}</pre>
              <p><b>返回 result：</b></p>
              <pre>{{ row.result || '（未记录）' }}</pre>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop=\"id\" label=\"ID\" width=\"70\" />
        <el-table-column prop=\"userId\" label=\"用户\" width=\"80\" />
        <el-table-column prop=\"module\" label=\"模块\" width=\"110\" />
        <el-table-column prop=\"operation\" label=\"操作\" width=\"90\" />
        <el-table-column prop=\"method\" label=\"方法\" min-width=\"200\" show-overflow-tooltip />
        <el-table-column prop=\"ip\" label=\"IP\" width=\"130\" />
        <el-table-column prop=\"costTime\" label=\"耗时(ms)\" width=\"90\" />
        <el-table-column prop=\"createTime\" label=\"时间\" width=\"170\" />
      </el-table>

      <el-pagination
        class=\"pagination\"
        v-model:current-page=\"query.page\"
        v-model:page-size=\"query.size\"
        :total=\"total\"
        :page-sizes=\"[10, 20, 50, 100]\"
        layout=\"total, sizes, prev, pager, next, jumper\"
        @size-change=\"loadData\"
        @current-change=\"loadData\"
      />
    </el-card>
  </div>
</template>

<script setup lang=\"ts\">
import { ref, reactive, onMounted } from 'vue'
import { pageLog } from '@/api/log'
import { ElMessage } from 'element-plus'

const rows = ref<any[]>([])
const total = ref(0)
const loading = ref(false)

const query = reactive({
  page: 1,
  size: 20,
  module: '',
  userId: undefined as number | undefined,
  range: [] as string[]
})

const loadData = async () => {
  loading.value = true
  try {
    const res: any = await pageLog({
      page: query.page,
      size: query.size,
      module: query.module || undefined,
      userId: query.userId,
      startTime: query.range?.[0],
      endTime: query.range?.[1]
    })
    rows.value = res.data.rows
    total.value = res.data.total
  } catch (e: any) {
    ElMessage.error(e.message || '查询失败')
  } finally {
    loading.value = false
  }
}

const onSearch = () => { query.page = 1; loadData() }
const onReset = () => {
  query.module = ''
  query.userId = undefined
  query.range = []
  query.page = 1
  loadData()
}

// —— CSV 导出：前端拼接方式 ——
const csvEscape = (v: any) => {
  if (v === null || v === undefined) return ''
  const s = String(v)
  if (/[\",\\n\\r]/.test(s)) return '\"' + s.replace(/\"/g, '\"\"') + '\"'
  return s
}
const onExport = () => {
  if (rows.value.length === 0) { ElMessage.warning('当前没有数据可导出'); return }
  const header = ['ID','用户','模块','操作','方法','IP','耗时(ms)','时间','入参','返回']
  const lines = [header.join(',')]
  rows.value.forEach(r => {
    lines.push([r.id, r.userId, r.module, r.operation, r.method, r.ip,
                r.costTime, r.createTime, r.params, r.result]
      .map(csvEscape).join(','))
  })
  // 加 BOM 让 Excel 正确识别 UTF-8
  const blob = new Blob(['\\uFEFF' + lines.join('\\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `operation_log_${new Date().getTime()}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

onMounted(loadData)
</script>

<style scoped>
.log-page { padding: 16px; }
.filter-card { margin-bottom: 16px; }
.expand-detail pre { background: #f5f7fa; padding: 8px; border-radius: 4px; max-height: 300px; overflow: auto; }
.pagination { margin-top: 16px; text-align: right; }
</style>
```

**注册路由**（在 `router/index.ts` 追加）：
```typescript
{ path: '/log', name: 'Log', component: () => import('@/views/log/list.vue'), meta: { title: '操作日志' } }
```

**联调步骤**：
1. 启动后端。
2. `pnpm dev` 启动前端。
3. 访问 `/log`，看到已有的日志列表。
4. 筛选\"过去 1 小时 会员管理\"，观察 SQL where 生效。
5. 点击\"导出 CSV\"，下载文件，用 WPS 打开，检查中文与逗号是否正确显示。

#### 4. 实操（9 分钟）

学生任务：
1. 敲入后端 `LogController`、Service `pageQuery`、Mapper XML。
2. 前端敲入 `api/log.ts`、`views/log/list.vue`，注册路由。
3. 从 Day03 起把\"新增/删除/修改\"接口各调 3-5 次制造真实数据，然后打开日志页面。
4. 展开某一行看 params，验证\"删除会员\"的入参是 `[1]` 这样的路径参数。
5. 尝试筛选\"用户 ID=1 + 客房管理 + 最近 24 小时\"，导出 CSV。

#### 5. 小结（3 分钟）
Day09 完整闭环：**注解 → 切面 → 异步入库 → 全局异常 → 前端展示与导出**。至此我们的项目从\"业务能跑\"升级为\"可运维、可追溯\"。

### 四、课上提问
1. `el-date-picker` 双向绑定的值格式为什么要显式指定 `value-format`？
2. CSV 里含中文时为什么要加 `\\uFEFF`（BOM）？
3. 前端 CSV 导出的天花板是什么？（浏览器内存、Blob 大小 ~几百 MB）

### 五、课堂练习
1. 增加\"操作\"筛选下拉（新增/修改/删除/查询/导出）。
2. 增加\"耗时>1000ms\"的复选框过滤慢操作。

### 六、课后思考
如果一天日志量到 100 万条，前端导出显然不行，怎么改？（后端流式生成 CSV / 定时归档 / 冷热表分离，为 Day10 系统优化埋伏笔。）

### 七、课后作业
1. Git 提交 `feat(log): admin operation log page`。
2. 录一段 1-2 分钟的操作视频：贴注解→调接口→前端页面查看→导出 CSV，作为项目\"运维能力\"亮点素材（Day12 面试用）。

### 八、板书设计
```
┌──────────────────────────────────────────────┐
│  日志查询页面 + 联调                         │
├──────────────────────────────────────────────┤
│ 后端：GET /api/logs/page                     │
│      参数 page/size/module/userId/时间区间   │
│ 前端：el-form 筛选 + el-table 展开行         │
│ 导出：Blob + createObjectURL + a.download    │
│ BOM：\\uFEFF 让 Excel 正确识别 UTF-8         │
└──────────────────────────────────────────────┘
```

---

## Day09 教学总结

至此我们完成了**操作日志**完整闭环：
1. `@OperationLog` 注解贴哪切哪，粒度精细。
2. `OperationLogAspect` 用 `@Around` 拿参数、拿返回、拿耗时、拿异常。
3. `AsyncConfig` + `OperationLogService.saveAsync` 保证不影响主业务响应。
4. `ErrorCode` + `BusinessException` + `GlobalExceptionHandler` 统一响应格式。
5. `LogController` + `views/log/list.vue` 给管理员一个可查、可筛、可导出的运维视图。

**串课线索：** Day09 的 AOP + 异常处理 + 异步落库，是绝大多数面试官考察 Spring 深度的高频点。请务必把源码敲进大脑，Day12 面试指导会重点讲解这块的话术与陷阱题。
