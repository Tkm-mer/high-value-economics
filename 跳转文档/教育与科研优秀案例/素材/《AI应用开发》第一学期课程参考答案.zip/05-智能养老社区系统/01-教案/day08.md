# 《智能养老社区系统》- 教师教案 - Day08：Echarts 统计大屏（复杂报表 SQL + 可视化）

**授课日：Day 08 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 10 - 复杂报表 SQL + Echarts 可视化 + 大屏适配**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01 建表脚本（member/room/room_reservation）、Day03-04 CRUD、Day06 预约业务与 Redis 缓存**

---

## 第 1 课时：报表需求与大屏原型

### 一、教学目标
- 知识目标：理解"运营大屏"在真实项目中的定位（面向老板与运营的驾驶舱视图，而非面向业务操作），能列出 AI 智能养老社区系统的 5 个核心指标与 4 类图表；掌握 Dashboard 的三栏（顶部 KPI - 中间图表 - 底部明细/仪表盘）经典布局；了解深色科技风大屏的色彩体系与视觉规范。
- 能力目标：能对着需求文档独立画出低保真原型图（用纸笔或 Excalidraw），能说明每一个数字与每一张图对应的数据来源表；能用一句话讲清楚"大屏与后台管理页有什么本质区别"。

### 二、教学重难点
- 重点：5 大指标（总会员数、总客房数、入住率、总收入、今日预约数）+ 4 类图表（近 7 日预约趋势折线、房型入住占比饼图、近 6 月收入柱状图、客房状态仪表盘）；三栏布局的比例（顶部 20%、中间 55%、底部 25%）。
- 难点：入住率 = 已入住/已确认 房数 ÷ 总房数，学生常错误理解为"订单数 ÷ 房数"；如何用最少的 SQL 语句 + 最合理的接口聚合把这些指标一次拿出来，而不是前端调 8 个接口。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师抛出场景："假设你是这家智能养老社区的 CEO，早上 8 点走进办公室，一屏投影上面能立刻看到今天来了多少家属、还剩多少空床、这个月收入是不是达标——你希望看到什么？"引导学生说出 3-5 个关心的数字，把学生的回答板书出来，再对齐我们的 5 大指标，指出这就是"大屏思维"——**汇总、对比、趋势**三大关键词。

#### 2. 讲授（16 分钟）
（1）**大屏 vs 管理页**：管理页面向"运营人员"操作数据，大屏面向"决策层"观察数据；管理页强调 CRUD、筛选、导出，大屏强调可视化、实时、震撼视觉。二者的技术差异集中在：分辨率固定（大屏通常 1920×1080 或 3840×2160）、颜色深色系（长时间看不刺眼、投影效果好）、自动刷新（30 秒~1 分钟一次）。

（2）**5 大指标定义**：

| 指标 | 数据来源 | 计算方式 |
|------|---------|---------|
| 总会员数 | member 表 | `SELECT COUNT(*) FROM member WHERE deleted = 0` |
| 总客房数 | room 表 | `SELECT COUNT(*) FROM room WHERE deleted = 0` |
| 入住率 | room 表 | `已预约/已入住房数 ÷ 总房数 × 100%` |
| 总收入 | room_reservation 表 | `SUM(total_price) WHERE status IN (1,2,3)` |
| 今日预约数 | room_reservation 表 | `WHERE DATE(create_time) = CURDATE()` |

强调：入住率**不是**"活跃订单数除以房数"，因为一间房可能有多条历史订单，正确口径是"当前处于占用状态的房间数 ÷ 总房间数"。

（3）**4 类图表原型草图**（板书 4 个矩形）：
- 折线图：横轴 = 近 7 天日期，纵轴 = 每日预约单量，1 条平滑曲线；
- 饼图：4-5 块（豪华间/标准间/单人间/亲情套房），显示占比；
- 柱状图：横轴 = 近 6 个月，纵轴 = 收入（元）；
- 仪表盘：0-100% 表盘，指针指向当前入住率。

（4）**三栏布局**：顶部一排 5 个 KPI 卡（每个约 300×150px），中间一行 3 张图表（折线 + 饼图 + 柱状图，各占 1/3），底部 2 张（仪表盘 + 今日新预约列表）。整体使用 CSS Grid，列宽 `1fr 1fr 1fr`。

（5）**深色科技风色板**：主背景 `#0a1128`、卡片背景 `#1a2555`、主文字 `#ffffff`、辅助文字 `#a0b3d6`、点缀色（图表）`#4facfe`（蓝）`#00f2fe`（青）`#43e97b`（绿）`#fa709a`（粉）。

#### 3. 演示（10 分钟）
教师用 Excalidraw 或 draw.io 现场画出 Dashboard 的低保真原型：先画 1920×1080 的外框，再拉出三栏分隔线，标注每一格的图表类型和指标名。演示的重点是让学生看到"从数字→图表→布局"这条思考路径，而不是急着写代码。

#### 4. 实操（10 分钟）
学生任务：分小组（2-3 人）用纸和笔画出自己的大屏原型，可以自由发挥（比如把今日新预约列表换成"高频客户 TOP5"）。教师巡视，抽 2 组上台讲 30 秒。要求每张图必须写清"取哪张表的哪个字段、怎么聚合"。

#### 5. 小结（2 分钟）
回顾 5 指标、4 图表、三栏布局、深色科技色板。预告下节课开始把这些指标翻译成 SQL。

### 四、课上提问
1. 为什么大屏一般不做筛选与 CRUD？
2. 入住率的正确分母是什么？
3. 为什么大屏偏好深色背景而不是白底？

### 五、课堂练习
1. 用一句话给"总收入"指标下定义（含时间口径与状态口径）。
2. 用铅笔画出你心目中的大屏，至少包含 3 张不同类型的图。

### 六、课后思考
如果客户提出"再加一个当月新增会员漏斗图"，你会加在三栏的哪个位置？为什么？

### 七、课后作业
1. 把 5 指标与 4 图表整理成 Markdown 表格，列出数据来源与刷新频率。
2. 用 Figma 或 Excalidraw 画出高保真原型（可选）。

### 八、板书设计
```
┌────────────────────────────────────────────────┐
│  报表需求与大屏原型                            │
├────────────────────────────────────────────────┤
│ 5 指标: 会员/客房/入住率/总收入/今日预约       │
│ 4 图表: 折线/饼图/柱状/仪表盘                  │
│ 布局:   顶 KPI + 中图表 + 底明细               │
│ 色板:   #0a1128 深蓝科技风                     │
└────────────────────────────────────────────────┘
```

---

## 第 2 课时：复杂报表 SQL——分组与时间维度

### 一、教学目标
- 知识目标：掌握 `GROUP BY` 的执行顺序与常见误区（SELECT 中非聚合列必须出现在 GROUP BY 里）；熟练使用 `DATE_FORMAT` / `DATE` / `CURDATE` / `DATE_SUB` 四个日期函数；理解 `CASE WHEN` 在报表分类统计中的作用；能写出"近 7 天预约趋势"的完整 SQL。
- 能力目标：能独立写出 3 条报表 SQL（近 7 日预约趋势、房型入住占比、入住率），并在 Navicat 里验证结果与"手工计数"一致。

### 二、教学重难点
- 重点：`GROUP BY DATE(create_time)` 与 `DATE_FORMAT(create_time, '%Y-%m-%d')` 的差别；日期区间 `WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)` 的写法。
- 难点：**填补零值日期**——如果某一天没有预约，SQL 查不出这一天，前端折线图会断线；如何在 SQL 端或 Java 端补 0。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上一课时我们画完了原型，现在的任务是把纸上的数字变成 SQL 结果集。今天我们只做单表 SQL，聚焦分组和时间维度。"

#### 2. 讲授（17 分钟）
（1）**GROUP BY 执行顺序**：`FROM → WHERE → GROUP BY → HAVING → SELECT → ORDER BY`。强调 `WHERE` 是行过滤（分组前），`HAVING` 是组过滤（分组后）。

（2）**常用日期函数速查**：

| 函数 | 作用 | 示例 |
|------|------|------|
| `CURDATE()` | 当前日期 | `2026-07-09` |
| `NOW()` | 当前时间戳 | `2026-07-09 14:23:11` |
| `DATE(dt)` | 只取日期部分 | `DATE('2026-07-09 14:00') = '2026-07-09'` |
| `DATE_FORMAT(dt, '%Y-%m')` | 格式化 | `2026-07` |
| `DATE_SUB(d, INTERVAL 7 DAY)` | 日期减 | 7 天前 |
| `DATEDIFF(a, b)` | 天数差 | |
| `MONTH(dt)` / `YEAR(dt)` | 提取月/年 | |

（3）**近 7 天预约趋势 SQL**：
```sql
SELECT DATE_FORMAT(create_time, '%Y-%m-%d') AS date, COUNT(*) AS cnt
FROM room_reservation
WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
  AND deleted = 0
GROUP BY DATE_FORMAT(create_time, '%Y-%m-%d')
ORDER BY date ASC;
```
讲解"6 DAY"为什么是 6 而不是 7：CURDATE() 本身占第 7 天。

（4）**房型入住占比 SQL**：
```sql
SELECT r.room_type, COUNT(*) AS cnt
FROM room r
WHERE r.status IN (1, 2)      -- 1 已预约 / 2 已入住
  AND r.deleted = 0
GROUP BY r.room_type;
```

（5）**入住率 SQL**（用 CASE WHEN 一句话搞定）：
```sql
SELECT
    ROUND(
        SUM(CASE WHEN status IN (1,2) THEN 1 ELSE 0 END) * 100.0
        / COUNT(*), 2
    ) AS occupancy_rate
FROM room
WHERE deleted = 0;
```
强调 `SUM(CASE WHEN ...)` 是把布尔条件转为 0/1 求和的经典技巧，比 `COUNT + WHERE` 更灵活（可一次求多个口径）。

（6）**零值填补问题**：若近 7 天有 2 天完全没预约，SQL 结果就少 2 行。演示两种解法：① SQL 用 `LEFT JOIN` 一张日期表；② Java 端遍历 7 天，Map 查找补 0（推荐，简单）。

#### 3. 演示（10 分钟）
教师在 Navicat 依次跑 3 条 SQL，观察结果。为了让"近 7 日"有数据，先手动 `INSERT` 几条历史预约。演示零值补齐时，故意删掉某一天的订单，展示"结果少一行"的现象，再打开后端 Java 代码演示补 0（Day08 第 4 课时详细写代码，本课先展示效果）。

#### 4. 实操（12 分钟）
学生任务：
- 任务 1：写 SQL 统计"每个月新增会员数"（用 member.create_time + DATE_FORMAT '%Y-%m'）；
- 任务 2：改写房型占比 SQL，让它同时输出百分比（用 `CONCAT(ROUND(cnt/total*100,2), '%')`）；
- 任务 3：写出"近 30 天总收入"SQL。

教师巡视，重点纠正两个常见错误：SELECT 中出现 GROUP BY 之外的非聚合列；对 datetime 直接用 `= '2026-07-09'` 而没有先 DATE() 转换。

#### 5. 小结（3 分钟）
回顾三条核心 SQL 与日期函数速查表，预告下节课加入 JOIN 与 EXPLAIN。

### 四、课上提问
1. `WHERE` 和 `HAVING` 的执行顺序谁先？
2. `DATE_SUB(CURDATE(), INTERVAL 6 DAY)` 得到几天前？
3. `SUM(CASE WHEN ... THEN 1 ELSE 0 END)` 和 `COUNT(*)` 结合使用能计算什么？

### 五、课堂练习
1. 写出"本月每日预约数"的 SQL。
2. 写出"近 3 个月各房型收入"的 SQL（含 CASE WHEN）。

### 六、课后思考
如果客户要看"过去 12 个月每月新增会员，即使某月为 0 也要出现在结果里"，你会怎么处理？

### 七、课后作业
1. 在自己的数据库里跑通今天讲的 3 条主 SQL，把结果截图保存。
2. 写一条 SQL，输出"本月订单总数、已完成、已取消"三个数字（一行输出）。

### 八、板书设计
```
┌─────────────────────────────────────────────┐
│  分组 + 时间维度 SQL                        │
├─────────────────────────────────────────────┤
│ GROUP BY DATE(create_time)                  │
│ CASE WHEN status IN (1,2) THEN 1 ELSE 0 END │
│ DATE_SUB(CURDATE(), INTERVAL 6 DAY)         │
│ 零值 → 后端补 0                             │
└─────────────────────────────────────────────┘
```

---

## 第 3 课时：复杂报表 SQL——多表联合与优化

### 一、教学目标
- 知识目标：掌握 `LEFT JOIN` / `INNER JOIN` 在报表中的场景（明细报表往往需要跨 2-3 张表）；能对比"子查询 vs JOIN"两种写法的可读性与性能差异；能读懂 `EXPLAIN` 输出的 `type` / `rows` / `Extra` 三个关键列；了解覆盖索引（covering index）与 using index 优化提示。
- 能力目标：能写出"近 6 月各房型收入"的 JOIN SQL，并用 `EXPLAIN` 观察是否走索引；能改写一条低效子查询为等价 JOIN。

### 二、教学重难点
- 重点：`LEFT JOIN + GROUP BY` 是报表最常见范式；`EXPLAIN` 中 `type = ref/range/index` 表示走了索引，`ALL` 表示全表扫；`Extra` 出现 `Using index` 是覆盖索引，性能最优。
- 难点：JOIN 时 `ON` 条件与 `WHERE` 条件位置差异（对 LEFT JOIN 结果影响不同）；子查询能被优化器改写成 JOIN，但不能所有情况都行。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们的 SQL 都是单表的，但客户想要一张'房型 - 月份 - 收入'的三维报表——房型信息在 room 表，收入信息在 room_reservation 表，就必须 JOIN。"

#### 2. 讲授（18 分钟）
（1）**四种 JOIN 一句话概括**：

| JOIN | 结果集 | 场景 |
|------|--------|------|
| INNER JOIN | 两边都匹配 | 严格要求两张表都有关联记录 |
| LEFT JOIN | 保留左表全部 | 报表兜底：即使右表无匹配也要显示 |
| RIGHT JOIN | 保留右表全部 | 一般用 LEFT 写法替代 |
| CROSS JOIN | 笛卡尔积 | 生成日期序列时用 |

（2）**多表 JOIN 报表 SQL**（近 6 月各房型收入）：
```sql
SELECT
    r.room_type,
    DATE_FORMAT(rr.create_time, '%Y-%m') AS month,
    SUM(rr.total_price) AS revenue
FROM room_reservation rr
INNER JOIN room r ON rr.room_id = r.id
WHERE rr.create_time >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
  AND rr.status IN (1, 2, 3)
  AND rr.deleted = 0
GROUP BY r.room_type, DATE_FORMAT(rr.create_time, '%Y-%m')
ORDER BY month, r.room_type;
```

（3）**子查询 vs JOIN 对比**：例题——"查出预约过豪华间的会员姓名"。

子查询版：
```sql
SELECT name FROM member
WHERE id IN (
    SELECT member_id FROM room_reservation
    WHERE room_id IN (SELECT id FROM room WHERE room_type = '豪华间')
);
```
JOIN 版：
```sql
SELECT DISTINCT m.name
FROM member m
INNER JOIN room_reservation rr ON m.id = rr.member_id
INNER JOIN room r ON rr.room_id = r.id
WHERE r.room_type = '豪华间';
```
JOIN 版可读性略高，且更容易走索引。**结论：报表能用 JOIN 就用 JOIN，避免 3 层以上嵌套子查询。**

（4）**EXPLAIN 三大关键列**：

| 列 | 含义 | 好/坏 |
|----|------|-------|
| type | 访问类型 | `const > eq_ref > ref > range > index > ALL`，越左越好 |
| rows | 扫描行数估算 | 越少越好 |
| Extra | 附加信息 | `Using index`（覆盖索引） 好；`Using filesort`/`Using temporary` 差 |

（5）**覆盖索引**：如果 SELECT 的字段都在索引里，MySQL 就不用回表——`Extra: Using index`。例子：`room(room_type, id)` 的联合索引可以覆盖 `SELECT room_type FROM room WHERE room_type = ?`。

#### 3. 演示（10 分钟）
教师在 Navicat 里跑：
```sql
EXPLAIN SELECT * FROM room_reservation WHERE room_id = 101;
```
观察 `type = ref`（若有索引）或 `ALL`（若无）。再演示：
```sql
ALTER TABLE room_reservation ADD INDEX idx_room_id (room_id);
```
重新 EXPLAIN，看到 `type` 从 `ALL` 变 `ref`，`rows` 从上万降到几十。

#### 4. 实操（10 分钟）
学生任务：
- 任务 1：为 `room_reservation.create_time` 建索引，对比 EXPLAIN 前后变化；
- 任务 2：把"预约过豪华间的会员"的子查询版改写为 JOIN 版，跑通并对比结果集。

#### 5. 小结（4 分钟）
今日 3 张主 SQL 已全部就绪：
- 近 7 日趋势（单表）
- 房型占比（单表）
- 近 6 月各房型收入（多表 JOIN）

预告下节课把它们打包成一个 Controller 接口。

### 四、课上提问
1. `LEFT JOIN` 与 `INNER JOIN` 的差别？
2. `EXPLAIN` 的 `type` 出现 `ALL` 意味着什么？
3. 什么是覆盖索引？

### 五、课堂练习
1. 用 EXPLAIN 分析你上节课写的 3 条 SQL，把 type 与 Extra 列截图。
2. 找一条你项目里的慢 SQL，改写为 JOIN 或加索引。

### 六、课后思考
如果 `room_reservation` 表数据量到 100 万，只在 `create_time` 上建单列索引是否够用？

### 七、课后作业
1. 完成"近 6 月各房型收入" SQL 的编写与 EXPLAIN。
2. 补一篇简短笔记：`docs/db/explain-cheatsheet.md`，把 type/rows/Extra 常见值整理成表。

### 八、板书设计
```
┌───────────────────────────────────────┐
│  多表 JOIN 与 EXPLAIN                 │
├───────────────────────────────────────┤
│ INNER / LEFT JOIN ... ON ...          │
│ 子查询 → JOIN 改写                    │
│ EXPLAIN: type / rows / Extra          │
│ 覆盖索引 → Using index                │
└───────────────────────────────────────┘
```

---

## 第 4 课时：报表接口聚合与 DTO 设计

### 一、教学目标
- 知识目标：掌握"一次接口返回多指标"的设计模式（避免前端调 8 个接口）；理解 VO 分层（DashboardVO 聚合类 + TrendVO/PieItemVO 明细类）的意义；掌握 Redis 缓存作为报表兜底的时机与 TTL 选择（30 分钟）；了解 CompletableFuture 并发查询的思路（提及而不深入）。
- 能力目标：能编写 StatisticsController / StatisticsService / StatisticsMapper 三层完整代码，能在 Postman 里一次拿到所有大屏数据，能观察 Redis 里缓存的 JSON。

### 二、教学重难点
- 重点：DashboardVO 结构设计（KPI + trend + pie + bar）；Mapper 使用 `@Select` 或 XML 手写 SQL；Service 层负责补 0 与拼装。
- 难点：日期补 0 的循环写法（Map + LinkedHashMap 保序）；Redis 缓存 Key 规范与序列化陷阱（Jackson 默认无法序列化 LocalDate，需要 JavaTimeModule）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"想象前端页面初始化时要发 8 个 HTTP 请求，一次刷屏出现 8 个 loading 圈——用户体验差、后端连接资源也浪费。我们今天把这些数据合成一个接口。"

#### 2. 讲授（15 分钟）
（1）**接口约定**：
```
GET /api/statistics/dashboard
Response: Result<DashboardVO>
```

（2）**DashboardVO 结构**：
```java
@Data
public class DashboardVO {
    // 五大 KPI
    private Long totalMembers;
    private Long totalRooms;
    private BigDecimal occupancyRate;
    private BigDecimal totalRevenue;
    private Long todayReservations;

    // 折线：近 7 日预约趋势
    private List<TrendVO> weekTrend;
    // 饼图：房型入住占比
    private List<PieItemVO> roomTypePie;
    // 柱状：近 6 月收入
    private List<TrendVO> monthRevenue;
}
```

（3）**Redis 缓存策略**：Key = `dashboard:stats`，TTL = 30 分钟，Value = JSON。第一次调用 → 查库 → 回写 Redis；30 分钟内所有调用直接读 Redis。缓存击穿风险不高（大屏访问频率低），无需分布式锁。

（4）**并发查询（选讲）**：如果 4 个查询独立，可用 `CompletableFuture.allOf(...)` 并行执行，把总耗时从 4×100ms 压到 100ms。但**首选同步实现**（简单、便于排错），并发是优化项。

#### 3. 演示（15 分钟）
教师依次敲代码（学生跟做）：

**Mapper 接口**：
```java
// com.itcast.smart_elder.mapper.StatisticsMapper
@Mapper
public interface StatisticsMapper {

    @Select("SELECT COUNT(*) FROM member WHERE deleted = 0")
    Long countMembers();

    @Select("SELECT COUNT(*) FROM room WHERE deleted = 0")
    Long countRooms();

    @Select("SELECT ROUND(SUM(CASE WHEN status IN (1,2) THEN 1 ELSE 0 END) * 100.0 " +
            "/ COUNT(*), 2) FROM room WHERE deleted = 0")
    BigDecimal occupancyRate();

    @Select("SELECT IFNULL(SUM(total_price),0) FROM room_reservation " +
            "WHERE status IN (1,2,3) AND deleted = 0")
    BigDecimal totalRevenue();

    @Select("SELECT COUNT(*) FROM room_reservation " +
            "WHERE DATE(create_time) = CURDATE() AND deleted = 0")
    Long todayReservations();

    @Select("SELECT DATE_FORMAT(create_time,'%Y-%m-%d') AS `date`, COUNT(*) AS cnt " +
            "FROM room_reservation " +
            "WHERE create_time >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) AND deleted = 0 " +
            "GROUP BY DATE_FORMAT(create_time,'%Y-%m-%d') " +
            "ORDER BY `date`")
    List<TrendVO> weekTrend();

    @Select("SELECT room_type AS name, COUNT(*) AS value FROM room " +
            "WHERE status IN (1,2) AND deleted = 0 GROUP BY room_type")
    List<PieItemVO> roomTypePie();

    @Select("SELECT DATE_FORMAT(rr.create_time,'%Y-%m') AS `date`, " +
            "IFNULL(SUM(rr.total_price),0) AS cnt " +
            "FROM room_reservation rr " +
            "WHERE rr.create_time >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) " +
            "  AND rr.status IN (1,2,3) AND rr.deleted = 0 " +
            "GROUP BY DATE_FORMAT(rr.create_time,'%Y-%m') " +
            "ORDER BY `date`")
    List<TrendVO> monthRevenue();
}
```

**Service 实现**：
```java
// com.itcast.smart_elder.service.impl.StatisticsServiceImpl
@Service
@RequiredArgsConstructor
public class StatisticsServiceImpl implements StatisticsService {

    private final StatisticsMapper statisticsMapper;
    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;
    private static final String CACHE_KEY = "dashboard:stats";

    @Override
    @SneakyThrows
    public DashboardVO getDashboard() {
        String cache = redisTemplate.opsForValue().get(CACHE_KEY);
        if (cache != null) {
            return objectMapper.readValue(cache, DashboardVO.class);
        }
        DashboardVO vo = new DashboardVO();
        vo.setTotalMembers(statisticsMapper.countMembers());
        vo.setTotalRooms(statisticsMapper.countRooms());
        vo.setOccupancyRate(statisticsMapper.occupancyRate());
        vo.setTotalRevenue(statisticsMapper.totalRevenue());
        vo.setTodayReservations(statisticsMapper.todayReservations());
        vo.setWeekTrend(fillZeroForWeek(statisticsMapper.weekTrend()));
        vo.setRoomTypePie(statisticsMapper.roomTypePie());
        vo.setMonthRevenue(fillZeroForMonth(statisticsMapper.monthRevenue()));

        redisTemplate.opsForValue().set(CACHE_KEY,
                objectMapper.writeValueAsString(vo),
                30, TimeUnit.MINUTES);
        return vo;
    }

    /** 近 7 天补 0 */
    private List<TrendVO> fillZeroForWeek(List<TrendVO> raw) {
        Map<String, Long> map = raw.stream()
                .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt));
        List<TrendVO> result = new ArrayList<>(7);
        LocalDate today = LocalDate.now();
        for (int i = 6; i >= 0; i--) {
            String d = today.minusDays(i).toString();  // yyyy-MM-dd
            result.add(new TrendVO(d, map.getOrDefault(d, 0L)));
        }
        return result;
    }

    /** 近 6 月补 0 */
    private List<TrendVO> fillZeroForMonth(List<TrendVO> raw) {
        Map<String, Long> map = raw.stream()
                .collect(Collectors.toMap(TrendVO::getDate, TrendVO::getCnt));
        List<TrendVO> result = new ArrayList<>(6);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM");
        LocalDate today = LocalDate.now();
        for (int i = 5; i >= 0; i--) {
            String m = today.minusMonths(i).format(fmt);
            result.add(new TrendVO(m, map.getOrDefault(m, 0L)));
        }
        return result;
    }
}
```

**Controller**：
```java
// com.itcast.smart_elder.controller.StatisticsController
@RestController
@RequestMapping("/api/statistics")
@RequiredArgsConstructor
public class StatisticsController {

    private final StatisticsService statisticsService;

    @GetMapping("/dashboard")
    public Result<DashboardVO> dashboard() {
        return Result.success(statisticsService.getDashboard());
    }
}
```

**VO 定义**：
```java
@Data @AllArgsConstructor @NoArgsConstructor
public class TrendVO {
    private String date;
    private Long cnt;
}

@Data @AllArgsConstructor @NoArgsConstructor
public class PieItemVO {
    private String name;
    private Long value;
}
```

#### 4. 实操（10 分钟）
学生任务：把上面代码敲进项目，启动后在 Postman 里请求 `GET http://localhost:8080/api/statistics/dashboard`，观察 JSON 结构。同时用 RedisInsight 查看 `dashboard:stats` 是否被写入。教师巡视纠错，重点关注：Long 与 BigDecimal 序列化、`@RequiredArgsConstructor` 忘写、Redis 未启动。

#### 5. 小结（2 分钟）
一个接口打包 8 个数据；Redis 30 分钟兜底；补 0 让前端图表连续。预告下节课接入前端 Echarts。

### 四、课上提问
1. 为什么用一个接口而不是 8 个？
2. Redis 缓存的 TTL 为什么选 30 分钟而不是 5 秒？
3. Java 端补 0 的核心思路是什么？

### 五、课堂练习
1. 加一个"本月新增会员数"KPI 到 DashboardVO。
2. 用 Postman 请求接口，把 JSON 结果贴到 Markdown 里。

### 六、课后思考
如果客户希望"实时"而不是 30 分钟缓存，你会怎么改？（引出：SSE 推送 / 短 TTL + 主动刷新）

### 七、课后作业
1. 完成 StatisticsController/Service/Mapper 三层代码并联调成功。
2. 用 Arthas 或日志观察接口第一次 vs 第二次的耗时差异（应显著缩短）。

### 八、板书设计
```
┌──────────────────────────────────────┐
│  报表接口聚合                        │
├──────────────────────────────────────┤
│ DashboardVO { KPI + 3 Chart }        │
│ Mapper @Select 手写 SQL              │
│ Redis 缓存 30min                     │
│ Service 端补 0                       │
└──────────────────────────────────────┘
```

---

## 第 5 课时：Echarts 集成——折线/柱状/饼图

### 一、教学目标
- 知识目标：掌握 Echarts 5 在 Vue3 项目里的安装与初始化流程；理解"按需引入 vs 全量引入"的取舍；能封装 `useChart` composable 复用初始化 / 销毁 / resize 逻辑；能读懂折线图/柱状图/饼图的 option 结构（title/tooltip/grid/xAxis/yAxis/series/color）。
- 能力目标：能独立在 Vue3 页面渲染 3 张图表，能改颜色、改坐标轴文字、改 tooltip 格式，能监听窗口 resize 使图表跟着变化。

### 二、教学重难点
- 重点：`echarts.init(dom).setOption(option)` 三步走；`series[0].data` 与后端接口数据格式的对齐；`onMounted` 里初始化，`onUnmounted` 里 `dispose()` 防内存泄漏。
- 难点：容器高度必须显式设置（`height: 300px`），否则图表看不见；resize 事件必须在 unmount 时 removeEventListener。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"数据准备好了。现在的问题是：怎么把 JSON 变成好看的折线？答案是 Echarts——业界最主流的开源可视化库，百度出的，中文文档极好。"

#### 2. 讲授（15 分钟）
（1）**安装**：
```bash
pnpm install echarts
```
Vue3 项目已经用 pnpm，安装完 `package.json` 会新增 `"echarts": "^5.5.0"`。

（2）**引入方式**：

| 方式 | 写法 | 适用 |
|------|------|------|
| 全量 | `import * as echarts from 'echarts'` | 快速开发，包体积 ~1MB |
| 按需 | `import { LineChart } from 'echarts/charts'` + `use(...)` | 生产环境，最少 200KB |

课堂选**全量**：简单直接，学生零心智负担；讲义附录会给按需的完整模板。

（3）**Echarts 使用三步**：
```javascript
// 第 1 步：拿到 DOM
const chart = echarts.init(document.getElementById('lineChart'))
// 第 2 步：写 option
const option = { xAxis: {...}, yAxis: {...}, series: [...] }
// 第 3 步：设置
chart.setOption(option)
```

（4）**封装 useChart**：把这三步 + resize + dispose 抽成 composable。

（5）**API 层封装** `src/api/statistics.ts`：
```typescript
import request from '@/utils/request'
export interface DashboardVO {
  totalMembers: number
  totalRooms: number
  occupancyRate: number
  totalRevenue: number
  todayReservations: number
  weekTrend: { date: string; cnt: number }[]
  roomTypePie: { name: string; value: number }[]
  monthRevenue: { date: string; cnt: number }[]
}
export const getDashboard = () => request.get<DashboardVO>('/api/statistics/dashboard')
```

#### 3. 演示（17 分钟）
教师现场敲 `useChart.ts`：
```typescript
// src/composables/useChart.ts
import * as echarts from 'echarts'
import { onMounted, onUnmounted, ref, type Ref } from 'vue'

export function useChart(el: Ref<HTMLElement | null>, option: any) {
  let chart: echarts.ECharts | null = null

  const init = () => {
    if (!el.value) return
    chart = echarts.init(el.value)
    chart.setOption(option)
  }

  const setOption = (opt: any) => chart?.setOption(opt)

  const resize = () => chart?.resize()

  onMounted(() => {
    init()
    window.addEventListener('resize', resize)
  })

  onUnmounted(() => {
    window.removeEventListener('resize', resize)
    chart?.dispose()
    chart = null
  })

  return { setOption, resize }
}
```

然后示范 3 张图的完整 option：

**折线图 option**：
```typescript
const lineOption = {
  title: { text: '近 7 日预约趋势', textStyle: { color: '#fff' } },
  tooltip: { trigger: 'axis' },
  grid: { left: '10%', right: '5%', top: '20%', bottom: '15%' },
  xAxis: {
    type: 'category',
    data: dashboard.value.weekTrend.map(t => t.date),
    axisLabel: { color: '#a0b3d6' },
    axisLine: { lineStyle: { color: '#3d5a80' } }
  },
  yAxis: {
    type: 'value',
    axisLabel: { color: '#a0b3d6' },
    splitLine: { lineStyle: { color: '#22345f' } }
  },
  series: [{
    type: 'line',
    smooth: true,
    data: dashboard.value.weekTrend.map(t => t.cnt),
    itemStyle: { color: '#4facfe' },
    areaStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: 'rgba(79,172,254,0.6)' },
          { offset: 1, color: 'rgba(79,172,254,0)' }
        ]
      }
    }
  }]
}
```

**饼图 option**：
```typescript
const pieOption = {
  title: { text: '房型入住占比', textStyle: { color: '#fff' } },
  tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
  legend: { bottom: 0, textStyle: { color: '#a0b3d6' } },
  color: ['#4facfe', '#00f2fe', '#43e97b', '#fa709a'],
  series: [{
    type: 'pie',
    radius: ['40%', '65%'],
    data: dashboard.value.roomTypePie,
    label: { color: '#fff' }
  }]
}
```

**柱状图 option**：
```typescript
const barOption = {
  title: { text: '近 6 月收入 (元)', textStyle: { color: '#fff' } },
  tooltip: { trigger: 'axis' },
  grid: { left: '12%', right: '5%', top: '20%', bottom: '15%' },
  xAxis: {
    type: 'category',
    data: dashboard.value.monthRevenue.map(m => m.date),
    axisLabel: { color: '#a0b3d6' }
  },
  yAxis: {
    type: 'value',
    axisLabel: { color: '#a0b3d6' },
    splitLine: { lineStyle: { color: '#22345f' } }
  },
  series: [{
    type: 'bar',
    data: dashboard.value.monthRevenue.map(m => m.cnt),
    itemStyle: {
      color: {
        type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
        colorStops: [
          { offset: 0, color: '#4facfe' },
          { offset: 1, color: '#00f2fe' }
        ]
      },
      borderRadius: [6, 6, 0, 0]
    }
  }]
}
```

#### 4. 实操（8 分钟）
学生任务：把 `useChart.ts` 与 3 段 option 敲到项目里，创建一个测试页面 `views/test-chart.vue` 只渲染 1 张折线图（数据先写死 mock）。跑通后再对接真实接口。

#### 5. 小结（2 分钟）
Echarts 三步走 + useChart 封装 + 3 张 option。下节课把它们放进大屏整体布局并适配 1920×1080。

### 四、课上提问
1. `echarts.init` 之前为什么容器 div 必须有高度？
2. onUnmounted 里 dispose 的作用？
3. 全量引入的缺点是什么？

### 五、课堂练习
1. 把折线图颜色改为绿色渐变。
2. 给饼图加一个"点击选中放大"的效果（Echarts option: `selectedMode: 'single'`）。

### 六、课后思考
如果同时有 20 个图表，全量引入会带来什么问题？

### 七、课后作业
1. 完成 3 张图的独立渲染，每张能单独运行。
2. 用真实接口数据替换 mock 数据。

### 八、板书设计
```
┌────────────────────────────────────┐
│  Echarts 三步走                    │
├────────────────────────────────────┤
│ init(dom) → setOption(opt)         │
│ useChart: mount/unmount/resize     │
│ 3 图: line / pie / bar             │
└────────────────────────────────────┘
```

---

## 第 6 课时：大屏适配与自动刷新

### 一、教学目标
- 知识目标：理解"设计稿 1920×1080，实际屏 4K/2K/笔记本"的多分辨率难题；掌握两种主流适配方案（rem/flex 自适应 vs transform:scale 缩放）；能用 `setInterval + onUnmounted` 实现 30 秒自动轮询；能用 CSS Grid 实现三栏 Dashboard 布局。
- 能力目标：能独立完成 `views/dashboard/index.vue` 完整代码（含 3 图 + 5 KPI + 自动刷新 + 缩放适配），能在不同分辨率浏览器窗口下大屏内容不错位。

### 二、教学重难点
- 重点：CSS Grid 三栏布局；transform:scale 缩放公式 `scale(min(w/1920, h/1080))`；setInterval 与 onUnmounted 清理配对。
- 难点：scale 缩放后 hover 命中区域偏移的坑；轮询请求"上一次没回来又发下一次"导致的并发脏读，需要用 `loading flag` 控制。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上一节 3 张图已经跑起来了，但在 1366×768 的笔记本上打开会挤成一团。真实大屏是 1920×1080 甚至 4K，我们要让页面自己缩放。"

#### 2. 讲授（14 分钟）
（1）**两种适配方案**：

| 方案 | 优点 | 缺点 |
|------|------|------|
| rem/flex 弹性布局 | 语义正确、hover 精准 | 每个尺寸都要重写，工作量大 |
| transform: scale | 一次搞定所有分辨率 | hover 命中区偏移、字体可能糊 |

本项目**首选 scale**——大屏几乎不 hover 交互，缩放更简单。

（2）**scale 公式**：
```javascript
const scale = Math.min(window.innerWidth / 1920, window.innerHeight / 1080)
container.style.transform = `scale(${scale}) translate(-50%, -50%)`
```
容器固定为 1920×1080，通过 scale 缩放，同时 translate 让它居中。

（3）**CSS Grid 三栏布局**：
```css
.dashboard {
  width: 1920px;
  height: 1080px;
  display: grid;
  grid-template-rows: 200px 1fr 260px;
  gap: 20px;
  padding: 20px;
  background: #0a1128;
}
.top-row  { display: grid; grid-template-columns: repeat(5, 1fr); gap: 20px; }
.mid-row  { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.bot-row  { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
```

（4）**setInterval 轮询**：
```javascript
let timer: number | null = null
onMounted(() => {
  loadData()
  timer = window.setInterval(loadData, 30_000)
})
onUnmounted(() => { if (timer) clearInterval(timer) })
```
必须清理，否则页面切走后仍在偷偷发请求，浪费资源。

（5）**防重入**：加 `loading` 标志，正在请求时不再发新请求。

#### 3. 演示（16 分钟）
教师完整敲出 `views/dashboard/index.vue`（全文见讲义附录），核心结构：
```vue
<template>
  <div class="dashboard-wrapper">
    <div class="dashboard" ref="scaleBox">
      <!-- 顶部 5 KPI -->
      <div class="top-row">
        <div class="kpi-card" v-for="k in kpis" :key="k.label">
          <div class="kpi-label">{{ k.label }}</div>
          <div class="kpi-value">{{ k.value }}</div>
        </div>
      </div>
      <!-- 中间 3 图 -->
      <div class="mid-row">
        <div class="chart-card" ref="lineEl"></div>
        <div class="chart-card" ref="pieEl"></div>
        <div class="chart-card" ref="barEl"></div>
      </div>
      <!-- 底部 -->
      <div class="bot-row">
        <div class="chart-card" ref="gaugeEl"></div>
        <div class="chart-card recent">今日新预约（TODO）</div>
      </div>
    </div>
  </div>
</template>
```

演示 scale 适配 JavaScript：
```typescript
const scaleBox = ref<HTMLElement | null>(null)
const applyScale = () => {
  if (!scaleBox.value) return
  const s = Math.min(window.innerWidth / 1920, window.innerHeight / 1080)
  scaleBox.value.style.transform = `scale(${s})`
}
onMounted(() => {
  applyScale()
  window.addEventListener('resize', applyScale)
})
onUnmounted(() => window.removeEventListener('resize', applyScale))
```

#### 4. 实操（10 分钟）
学生任务：
1. 把讲义附录的 `views/dashboard/index.vue` 完整代码敲进项目；
2. 在路由 `src/router/index.ts` 加一条 `/dashboard`；
3. 启动前端 `pnpm dev`，浏览器全屏访问 `/dashboard`；
4. 修改浏览器窗口大小，观察内容是否随窗口缩放；
5. 打开 Network 面板，验证 30 秒发起一次新请求。

教师巡视，常见 3 个错误：容器忘写宽高、transform 忘 origin、interval 未清理。

#### 5. 小结（2 分钟）
Day08 完整闭环：SQL → 接口 → 前端 → 大屏。祝贺学生完成本课程最"炫"的一天。

### 四、课上提问
1. 为什么 `transform:scale` 比 rem 简单？
2. `setInterval` 不清理会有什么后果？
3. CSS Grid 三栏用了什么核心属性？

### 五、课堂练习
1. 把轮询间隔改为 10 秒，观察 Redis 缓存是否生效（依旧走缓存）。
2. 修改 KPI 卡片背景颜色为不同渐变。

### 六、课后思考
真实公司里，"大屏"通常投在什么地方？如果投放在会议室 4K 屏上，我们的缩放公式是否仍成立？

### 七、课后作业
1. 完成 Dashboard 页面，录 30 秒视频演示大屏效果。
2. 尝试给底部"今日新预约"区域接入真实数据（复用 room_reservation 表）。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  大屏适配 + 自动刷新                      │
├───────────────────────────────────────────┤
│ CSS Grid 三栏 (rows 200/1fr/260)          │
│ transform:scale(min(w/1920, h/1080))      │
│ setInterval(loadData, 30_000)             │
│ onUnmounted clearInterval                 │
└───────────────────────────────────────────┘
```

---

## 本日总结

Day08 完整闭环：**需求原型 → 单表 SQL → 多表 JOIN 与 EXPLAIN 优化 → 接口聚合与 Redis 缓存 → Echarts 集成 → 大屏适配与自动刷新**。学生今日交付物：3 条报表 SQL、1 个 `/api/statistics/dashboard` 接口、1 个 `useChart` composable、1 个可运行的 Dashboard 页面。明天进入 AOP 操作日志管理（Day09）。
