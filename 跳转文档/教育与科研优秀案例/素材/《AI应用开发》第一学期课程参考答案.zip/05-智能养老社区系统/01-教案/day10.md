# 《智能养老社区系统》- 教师教案 - Day10：系统优化

**授课日：Day 10 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 12 - 慢 SQL 定位 + 索引优化 + 缓存三兄弟 + JVM/Arthas + JMeter 压测 + 性能报告**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day01 建表完成（`elder_member` / `room_info` / `room_reservation` / `operation_log`）；Day03 已有会员分页查询接口 `/api/members/page`；Day06 已有预约接口 `/api/reservations` 并接入 Redis；Day08 已有报表 SQL；Day09 已有 AOP 日志与全局异常。**

---

## 第 1 课时：慢 SQL 定位与执行计划

### 一、教学目标
- 知识目标：理解"慢 SQL"这一线上性能问题的头号来源；掌握 MySQL 慢查询日志（slow query log）的开启方式与三个关键参数 `slow_query_log`、`long_query_time`、`log_queries_not_using_indexes`；会用 `mysqldumpslow` 从大量慢 SQL 里聚合出"TOP 10 罪魁"；能读懂 `EXPLAIN` 输出的 12 个字段，重点掌握 `id` / `select_type` / `type` / `possible_keys` / `key` / `key_len` / `rows` / `Extra`；理解 B+ 树索引的高扇出、低高度、叶子节点双向链表结构，明白"为什么加索引就快"。
- 能力目标：能够在自己的 MySQL 上开启慢日志，制造一条真实的慢查询并从日志里定位到它；能给出的 SQL 跑 `EXPLAIN` 并说出访问类型、是否用了索引、扫描了多少行；能对着 `Extra` 里的 `Using filesort` / `Using temporary` / `Using where` / `Using index` 说出各自含义。

### 二、教学重难点
- 重点：`EXPLAIN` 的 `type` 等级（`system` > `const` > `eq_ref` > `ref` > `range` > `index` > `ALL`）以及"低于 range 都算问题"；`rows` 字段的物理意义（预估要读取的行数）。
- 难点：`select_type` 里 `SIMPLE` / `PRIMARY` / `SUBQUERY` / `DERIVED` / `UNION` 的区分；B+ 树高度为什么通常只有 3-4 层（对应 2000 万行以内的表）。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："Day03 我们写会员分页查询的时候，测试库只放了 20 条数据，查询秒回。假设明天运营告诉你，会员表已经涨到 **500 万行**，同一个 SQL 变成 6 秒才回来，你打算怎么办？"

预设回答：加索引 / 分页 / 用 Redis。

教师点评："这些都对。但**在动手加索引之前**，最重要的一步是——**找到到底哪一条 SQL 慢**，以及**它究竟慢在哪一步**。今天前两节课我们学的是'诊断'，索引/缓存/压测都是后续的'治疗'。诊断错了，加再多索引也是白加。"

#### 2. 讲授（18 分钟）

**（1）线上性能问题的分布**

根据阿里、美团公开的复盘数据，一个 Java Web 系统 80% 以上的性能故障 = **慢 SQL**。剩下 20% 分给：缓存不命中、GC 频繁、外部 API 抖动、锁竞争。所以优化的第一枪永远打向数据库。

**（2）开启 MySQL 慢查询日志**

MySQL 自带慢日志功能，默认关闭。开启三步走：

```sql
-- 1) 查当前状态
SHOW VARIABLES LIKE 'slow_query_log%';
SHOW VARIABLES LIKE 'long_query_time';

-- 2) 临时开启（重启失效）
SET GLOBAL slow_query_log = ON;
SET GLOBAL long_query_time = 1;                -- 超过 1 秒算慢
SET GLOBAL log_queries_not_using_indexes = ON; -- 不走索引也记
SET GLOBAL slow_query_log_file = '/var/log/mysql/slow.log';

-- 3) 永久开启：写入 my.cnf 的 [mysqld] 节
-- slow_query_log = 1
-- long_query_time = 1
-- slow_query_log_file = /var/log/mysql/slow.log
```

> **教师强调：** `long_query_time` 默认 10 秒，太宽松了。**开发/测试环境建议设 1 秒，生产环境 2-3 秒**。写业务代码时你自己都嫌 1 秒慢，何况用户？

**（3）mysqldumpslow：慢日志聚合利器**

原始慢日志一天可能几十万行，直接 `less` 看不过来。`mysqldumpslow` 是 MySQL 自带的 Perl 脚本，把"结构相同、参数不同"的 SQL 聚合成同一条并按次数/耗时排序：

```bash
# TOP 10 平均耗时最长
mysqldumpslow -s at -t 10 /var/log/mysql/slow.log

# TOP 10 总耗时最长（更关注真正吃掉时间的）
mysqldumpslow -s t -t 10 /var/log/mysql/slow.log

# TOP 10 执行次数最多
mysqldumpslow -s c -t 10 /var/log/mysql/slow.log
```

输出示例：
```
Count: 2843  Time=3.42s (9721s)  Lock=0.00s (2s)  Rows=1.0 (2843)  root[root]@localhost
SELECT * FROM elder_member WHERE phone = 'S' ORDER BY create_time DESC LIMIT N
```
"`Count=2843` 次、总耗时 9721 秒" 一目了然——这就是要优先优化的对象。

**（4）EXPLAIN 十二字段速览**

```sql
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800000001';
```

| 字段 | 含义 | 关注点 |
|------|------|--------|
| id | 查询序号 | 数字大的先执行；相同则从上到下 |
| select_type | 查询类型 | SIMPLE 简单 / PRIMARY 主 / SUBQUERY 子 / DERIVED 派生 / UNION 联合 |
| table | 涉及表 | 派生表显示 `<derivedN>` |
| partitions | 分区 | 未分区显示 NULL |
| **type** ★ | **访问类型** | **本行最重要** |
| possible_keys | 可能用到的索引 | 优化器"考虑过"的候选 |
| **key** ★ | **实际用到的索引** | NULL 表示没走索引 |
| key_len | 索引使用长度 | 联合索引用了几个字段可算出 |
| ref | 与索引对比的列/常量 | `const` / 表.列 |
| **rows** ★ | **预估扫描行数** | 越小越好；量级即效率 |
| filtered | 过滤后剩余百分比 | 100 表示条件几乎没过滤 |
| **Extra** ★ | **附加信息** | Using index / Using filesort / Using temporary |

**（5）type 等级从优到差**

```
system > const > eq_ref > ref > range > index > ALL
                                              ↑
                                        全表扫描（灾难）
```

- `const`：主键或唯一索引等值。`WHERE id = 1`
- `eq_ref`：join 时用主键或唯一索引等值。`ON a.id = b.aid`
- `ref`：普通索引等值。`WHERE phone = ?`
- `range`：范围。`WHERE create_time > '2024-01-01'`
- `index`：全索引扫描（不回表）。比 ALL 好但仍要警惕。
- `ALL`：全表扫描。**生产上但凡 rows > 1 万还是 ALL，就是慢 SQL 前兆。**

**（6）Extra 的四大警告**

| Extra 值 | 含义 | 是否需要优化 |
|----------|------|-------------|
| Using index | 覆盖索引，不回表 | ✅ 好 |
| Using where | Server 层再过滤 | 中性 |
| Using filesort | 无法用索引排序 | ⚠️ 要优化 |
| Using temporary | 用了临时表 | ⚠️ 高危 |
| Using join buffer | 无索引 join | ⚠️ 慢 |

**（7）B+ 树索引：为什么加索引就快**

板书画简图：
```
         [30 | 60]                    ← 根节点（1 次 IO）
        /    |    \
   [10|20][40|50][70|80]             ← 中间层（1 次 IO）
     |      |      |
  叶子链表 ← 双向链表串起所有数据 →    ← 叶子节点（1 次 IO）
```

一句话：**B+ 树把 O(n) 查找降为 O(log n)**，一张 500 万行表通常 3 层就够。加索引 = 让 MySQL 从"翻 500 万页"变成"翻 3 页"。

#### 3. 演示（10 分钟）

**（1）造 100 万行数据（一次性）**：

```sql
-- 用递归 CTE + INSERT ... SELECT 造数据，MySQL 8.0+
INSERT INTO elder_member (name, gender, age, phone, id_card, address,
                          member_level, create_time)
SELECT
  CONCAT('会员', LPAD(seq, 7, '0')),
  IF(seq % 2 = 0, 1, 2),
  60 + seq % 30,
  CONCAT('138', LPAD(seq, 8, '0')),
  CONCAT('4101', LPAD(seq, 14, '0')),
  '河南省郑州市金水区',
  1 + seq % 4,
  DATE_ADD('2020-01-01', INTERVAL seq MINUTE)
FROM (
  WITH RECURSIVE t(seq) AS (
    SELECT 1 UNION ALL SELECT seq+1 FROM t WHERE seq < 1000000
  )
  SELECT seq FROM t
) x;
```

**（2）临时删掉 `idx_phone` 索引，模拟慢查询**：
```sql
ALTER TABLE elder_member DROP INDEX idx_phone;

SELECT * FROM elder_member WHERE phone = '13800500000';  -- 观察耗时
```
教师现场执行，MySQL Workbench 或 DataGrip 里会看到 **执行时间 2-3 秒**。

**（3）EXPLAIN 观察**：
```sql
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800500000';
```
输出关键行：`type=ALL, key=NULL, rows≈1000000, Extra=Using where`
——这就是全表扫描的教科书案例。

**（4）加回索引 → 再 EXPLAIN**：
```sql
ALTER TABLE elder_member ADD INDEX idx_phone (phone);
EXPLAIN SELECT * FROM elder_member WHERE phone = '13800500000';
```
输出：`type=ref, key=idx_phone, rows=1, Extra=Using where` —— **1 行 vs 100 万行**，学生直观感受索引威力。

#### 4. 实操（10 分钟）

学生任务：
1. 在自己的 MySQL 里执行 `SET GLOBAL slow_query_log = ON; SET GLOBAL long_query_time = 0.1;`（把阈值调到 0.1 秒方便复现）。
2. 造 10 万行 `elder_member` 数据（造 100 万太慢，改用 `WHILE < 100000`）。
3. 对以下 3 条 SQL 分别 `EXPLAIN`，把 `type` / `key` / `rows` / `Extra` 抄到 word 表格里：
   - `SELECT * FROM elder_member WHERE id = 1;`
   - `SELECT * FROM elder_member WHERE name = '会员0000001';`
   - `SELECT * FROM elder_member ORDER BY create_time DESC LIMIT 20;`

教师巡视，重点关注：
- 学生忘记 `FLUSH LOGS` 后再看 slow log，导致以为没生效。
- 部分学生装的 MySQL 5.7，`WITH RECURSIVE` 不支持，改用存储过程或 Navicat 造数据工具。

#### 5. 小结（3 分钟）
一句话回顾：**慢日志找到"慢在哪条"，EXPLAIN 找到"慢在哪步"**——这套组合拳是所有 DBA 和后端开发的基本功。下节课我们拿今天定位到的慢 SQL 动手改，看看索引怎么加、SQL 怎么写才能让 `type` 从 `ALL` 走到 `ref`。

### 四、课上提问
1. `long_query_time` 单位是什么？可以设成小数吗？
2. `EXPLAIN` 输出里 `type=index` 和 `type=ALL` 哪个更好？为什么？
3. `Extra` 里出现 `Using filesort` 意味着什么问题？

### 五、课堂练习
1. 写一条 SQL 让 EXPLAIN 输出 `type=const`。
2. 写一条 SQL 让 EXPLAIN 输出 `Extra=Using index`（提示：覆盖索引）。

### 六、课后思考
如果一张表 3 亿行、B+ 树高度会不会超过 4 层？（引出主键长度、页大小 16KB 对索引高度的影响。）

### 七、课后作业
1. 把慢日志开启并跑一天，第二天用 `mysqldumpslow -s t -t 10` 截图给组长。
2. 对 Day03 会员分页接口执行的完整 SQL 跑一次 `EXPLAIN`，把结果贴到日报里。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  慢 SQL 定位与执行计划                   │
├──────────────────────────────────────────┤
│ 三参数：slow_query_log / long_query_time │
│         / log_queries_not_using_indexes  │
│ 工具：mysqldumpslow -s at/t/c -t 10      │
│ 核心：EXPLAIN 四字段                     │
│      type / key / rows / Extra           │
│ type 等级：system > const > eq_ref       │
│           > ref > range > index > ALL    │
└──────────────────────────────────────────┘
```

---

## 第 2 课时：索引优化与 SQL 改写

### 一、教学目标
- 知识目标：掌握联合索引的**最左前缀原则**——建立 `(a, b, c)` 索引时，`WHERE a=?`、`WHERE a=? AND b=?`、`WHERE a=? AND b=? AND c=?` 都能命中，但 `WHERE b=?`、`WHERE c=?`、`WHERE a=? AND c=?` 会跳过后段字段；理解**覆盖索引**（select 的列全在索引里）能避免"回表"从而只走辅助索引；熟练识别 10 大**索引失效场景**：函数计算、隐式类型转换、`OR` 混用非索引列、`LIKE '%xxx'`、`!=` 与 `<>`、`IS NULL` 视版本而定、字符集不一致、优化器估算失误、联合索引跳跃列、`ORDER BY` 与索引方向不一致。
- 能力目标：能够对给定的一段 SQL 写出 3 种以上的改写方案；能针对 Day03 会员分页和 Day06 预约表两个高频 SQL 各设计 1-2 条最合理的索引；能解释"为什么某条索引会被优化器抛弃"。

### 二、教学重难点
- 重点：最左前缀 + 覆盖索引 + 回表三个概念的联动理解；`ORDER BY` 想用索引排序必须"排序字段 = 联合索引后缀，且方向一致"。
- 难点：**索引下推 (Index Condition Pushdown, ICP)** 与覆盖索引的区别；`filesort` 到底发生在 Server 层还是引擎层。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师放上节课学生的作业截图：Day03 会员分页 SQL 的 EXPLAIN 大多是 `type=ALL`。提问："我们上节课已经把 `idx_phone` 加回去了，为什么这条 SQL 还是全表扫描？"

引导观察 SQL：
```sql
SELECT id, name, phone, member_level, create_time
FROM elder_member
WHERE member_level = 3 AND phone LIKE '138%'
ORDER BY create_time DESC
LIMIT 0, 20;
```
"这条 SQL 涉及 `member_level`、`phone`、`create_time` 三个字段。加什么索引？加几个？加在谁上？——这就是今天要解决的问题。"

#### 2. 讲授（20 分钟）

**（1）单列索引 vs 联合索引**

单列索引：`KEY idx_a (a)` —— 只对 `a` 起作用。
联合索引：`KEY idx_a_b_c (a, b, c)` —— 一个索引管三列，前提是遵守**最左前缀**。

**最左前缀原则示意**：
```
idx_a_b_c (a, b, c)
── WHERE a=?           ✅ 命中 idx_a_b_c(a)
── WHERE a=? AND b=?    ✅ 命中 idx_a_b_c(a,b)
── WHERE a=? AND b=? AND c=?  ✅ 全命中
── WHERE b=?           ❌ 跳过 a，索引失效
── WHERE a=? AND c=?    ⚠️ 只命中 a，c 用不到索引
```

**（2）回表 vs 覆盖索引**

InnoDB 主键索引（聚簇索引）叶子节点存**整行数据**；辅助索引（普通索引）叶子节点存**主键值**。

- 通过辅助索引找到主键 → 再回聚簇索引查完整行 = **回表**（两次 IO）
- 如果 select 的列**全在辅助索引里**，不需要回表 = **覆盖索引**（一次 IO）

```sql
-- 回表：select * ，字段不在索引里
SELECT * FROM elder_member WHERE phone = '13800000001';

-- 覆盖索引：只 select 索引本身的列 + 主键
SELECT id, phone FROM elder_member WHERE phone = '13800000001';
-- EXPLAIN 会看到 Extra=Using index
```

**（3）索引失效 10 大场景（速记版）**

| 序号 | 场景 | 反例 | 正例 |
|------|------|------|------|
| 1 | 函数计算 | `WHERE DATE(create_time)='2024-01-01'` | `WHERE create_time >= '2024-01-01' AND create_time < '2024-01-02'` |
| 2 | 隐式类型转换 | `WHERE phone = 13800000001` | `WHERE phone = '13800000001'` |
| 3 | `OR` 混用非索引列 | `WHERE phone=? OR address=?` | 用 UNION 或给 address 加索引 |
| 4 | `LIKE '%xxx'` | `WHERE name LIKE '%张'` | `WHERE name LIKE '张%'` 或用 ES/前缀索引 |
| 5 | `!=` `<>` `NOT IN` | `WHERE status != 0` | 改用 `IN (1,2,3)` |
| 6 | `IS NULL` 全表扫 | 老版本 MySQL 上 | 建索引时给 NOT NULL DEFAULT '' |
| 7 | 字符集/校对规则不一致 | join 两表字符集不同 | 统一 utf8mb4_general_ci |
| 8 | 优化器估算失误（数据分布倾斜） | 优化器算出扫全表更划算 | `FORCE INDEX(idx_x)` |
| 9 | 联合索引跳列 | `(a,b,c)` 索引 `WHERE a=? AND c=?` | 加 `b=?` 或换索引顺序 |
| 10 | `ORDER BY` 方向不一致 | idx `(a ASC, b DESC)` 查 `ORDER BY a ASC, b ASC` | 建索引时按查询方向 |

**（4）实战：分析导入时那条 SQL**

```sql
SELECT id, name, phone, member_level, create_time
FROM elder_member
WHERE member_level = 3 AND phone LIKE '138%'
ORDER BY create_time DESC
LIMIT 0, 20;
```

分析：
- 等值：`member_level`
- 范围：`phone LIKE '138%'`（前缀，可用索引）
- 排序：`create_time DESC`
- 输出：`id, name, phone, member_level, create_time`

联合索引设计原则："**等值列在前，排序列在中，范围列在最后**"。因此：
```sql
CREATE INDEX idx_level_ctime_phone
ON elder_member (member_level, create_time, phone);
```
- `member_level = 3` 走等值 → 精确定位
- `create_time DESC` → 沿索引反向扫（MySQL 8.0 起支持索引降序）
- `phone LIKE '138%'` → 范围过滤，用索引下推（ICP）继续过滤，不必回表
- 输出列除了 `name` 需要回表，其余都在索引里

**（5）Day06 预约表 SQL 分析**

会员端"我的预约"列表：
```sql
SELECT id, room_id, check_in_date, check_out_date, status, total_price
FROM room_reservation
WHERE member_id = ? AND status IN (0, 1, 2)
ORDER BY check_in_date DESC
LIMIT 0, 10;
```
索引设计：
```sql
CREATE INDEX idx_member_status_date
ON room_reservation (member_id, status, check_in_date);
```
- `member_id = ?` 等值
- `status IN (...)` 范围
- `check_in_date DESC` 排序

管理端"某日期待入住"列表：
```sql
SELECT id, member_id, room_id, status
FROM room_reservation
WHERE check_in_date = ? AND status = 1;
```
索引：
```sql
CREATE INDEX idx_date_status ON room_reservation (check_in_date, status);
```

#### 3. 演示（10 分钟）

教师现场对导入 SQL 完成三步演示：

**Step 1：不加新索引，先看现状**
```sql
EXPLAIN SELECT id, name, phone, member_level, create_time
FROM elder_member
WHERE member_level = 3 AND phone LIKE '138%'
ORDER BY create_time DESC LIMIT 0, 20;
```
预期：`type=ref, key=idx_member_level, rows=250000, Extra=Using where; Using filesort`

**Step 2：加联合索引**
```sql
CREATE INDEX idx_level_ctime_phone
ON elder_member (member_level, create_time, phone);
```

**Step 3：再 EXPLAIN**
```
type=range, key=idx_level_ctime_phone, key_len=8, rows≈100, Extra=Using where; Using index condition
```
`Using filesort` 消失、`rows` 从 25 万降到 100 —— **性能提升 2500 倍**。

再对预约表演示一次，学生亲眼看到 `type=ALL → type=range`。

#### 4. 实操（10 分钟）

学生任务：
1. 对本节课给出的 4 个 CREATE INDEX 全部执行（先删旧的，再建新的）。
2. 用同样的 SQL 前后 EXPLAIN 两次，把 `type` / `key` / `rows` / `Extra` 记录到 Excel。
3. 挑一条 `EXPLAIN` 结果里含 `Using filesort` 的 SQL（推荐 Day08 报表 SQL），尝试设计索引让 filesort 消失。

教师巡视，纠正三种常见错误：
- 联合索引字段顺序错乱（等值/排序/范围原则没记住）。
- `LIKE '%xxx%'` 硬要建索引，白搭。
- `SELECT *` 时不理解为什么覆盖索引失效——因为不是所有列都在索引里。

#### 5. 小结（3 分钟）
一句话回顾：**索引优化 = 联合索引字段顺序 + 覆盖索引避免回表 + 十种失效场景绕开**。数据库层优化到这里基本触顶，再快就要靠缓存了——下节课上 Redis + Caffeine 多级缓存。

### 四、课上提问
1. `KEY idx (a, b, c)` 联合索引，`WHERE b=1 AND a=2` 能走索引吗？
2. 什么叫"回表"？什么情况下会发生？
3. `Extra=Using index condition` 是什么？（引出 ICP）

### 五、课堂练习
1. 给定 SQL：`SELECT id, name FROM elder_member WHERE age > 70 ORDER BY member_level`，写出最合适的索引 DDL。
2. 说出下列语句为什么索引失效，并改写：
   - `SELECT * FROM elder_member WHERE SUBSTRING(phone, 1, 3) = '138'`
   - `SELECT * FROM room_reservation WHERE status + 1 = 2`

### 六、课后思考
如果 `member_level` 只有 4 种取值（区分度极低），单独给 `member_level` 建索引有意义吗？（引出"低基数列不建单列索引"经验。）

### 七、课后作业
1. 对 Day08 大屏所有 SQL 跑一遍 EXPLAIN，把 `type=ALL` 或 `Using filesort` 的 SQL 找出来，为每条设计一条改进索引。
2. 阅读文档《MySQL 索引下推》并写 200 字心得。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  索引优化与 SQL 改写                     │
├──────────────────────────────────────────┤
│ 三大武器：                               │
│  1. 最左前缀（联合索引）                 │
│  2. 覆盖索引（避免回表）                 │
│  3. 索引下推 ICP                         │
│ 字段顺序：等值 → 排序 → 范围             │
│ 失效 10 条：函数/类型/OR/LIKE%/!=/NULL/  │
│           字符集/估算/跳列/方向          │
└──────────────────────────────────────────┘
```

---

## 第 3 课时：缓存优化——热点数据与穿透雪崩击穿

### 一、教学目标
- 知识目标：理解缓存三兄弟的**准确定义与差异**——**缓存穿透**（查询根本不存在的数据）、**缓存雪崩**（大量 key 同时失效或 Redis 宕机）、**缓存击穿**（单个热点 key 失效瞬间被高并发打穿）；掌握每种情况的对策——穿透用空值缓存 / 布隆过滤器，雪崩用随机 TTL / 集群 / 熔断降级，击穿用互斥锁（分布式锁）/ 逻辑过期；理解**多级缓存**（Caffeine 本地 → Redis 集中 → 数据库）的调用顺序与失效级联；能熟练使用 Google Guava 的 `BloomFilter`。
- 能力目标：能画出多级缓存查询流程图；能给会员详情接口加上"穿透+击穿"双保险；能为 Day06 预约的房型缓存加随机 TTL 防雪崩。

### 二、教学重难点
- 重点：三兄弟的正确定义与对策一一对应；`BloomFilter.create(funnel, expectedInsertions, fpp)` 的三个参数含义。
- 难点：布隆过滤器"假阳性"的概率原理与 `fpp=0.01` 对空间的影响；击穿场景下"互斥锁"必须用 Redis 分布式锁而不能用 JVM 内的 `synchronized`。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师放一张真实事故截图（脱敏）："某电商大促时凌晨 2 点，Redis 集群里 3 万个商品缓存同时失效——因为它们的 TTL 都设成整点 2:00，同一秒所有请求打到数据库，MySQL 连接池爆掉，网站 502 半小时。"这就是**缓存雪崩**。今天课要保证：Day10 之后我们的项目**不会再犯这种低级错误**。

#### 2. 讲授（18 分钟）

**（1）三兄弟准确定义**

| 名称 | 触发条件 | 危害 | 对策 |
|------|---------|------|------|
| 缓存穿透 | 查询"根本不存在的数据"，缓存永远命中不了，每次都打库 | 恶意攻击可打死 DB | 空值缓存 + 布隆过滤器 |
| 缓存雪崩 | 大量 key 同一时间失效 / Redis 宕机 | 数据库瞬时压力剧增 | 随机 TTL + 集群 + 熔断 |
| 缓存击穿 | 一个"热点 key"失效瞬间被高并发打穿 | 单点数据库压力剧增 | 互斥锁 + 逻辑过期 |

**（2）穿透对策 1：空值缓存**

```java
public MemberDTO getMember(Long id) {
    String key = "member:" + id;
    String cached = redis.opsForValue().get(key);
    if (cached != null) {
        if ("NULL".equals(cached)) return null;   // 空对象标记
        return JSON.parseObject(cached, MemberDTO.class);
    }
    MemberDTO db = memberMapper.selectById(id);
    if (db == null) {
        // 空值也缓存，TTL 短一点，防止占用内存
        redis.opsForValue().set(key, "NULL", 60, TimeUnit.SECONDS);
        return null;
    }
    redis.opsForValue().set(key, JSON.toJSONString(db), 30, TimeUnit.MINUTES);
    return db;
}
```

**（3）穿透对策 2：布隆过滤器**

布隆过滤器（Bloom Filter）是一种"**空间高效的概率数据结构**"，可以在 O(1) 时间内判断"某元素**一定不在**集合里"或"**可能在**集合里"（有假阳性，无假阴性）。

```java
// 引入 Guava
BloomFilter<Long> memberBloom = BloomFilter.create(
    Funnels.longFunnel(),
    1_000_000L,   // 预期元素数量
    0.01          // 假阳性率 1%
);

// 项目启动时把所有 member.id 装进去
for (Long id : memberMapper.selectAllIds()) {
    memberBloom.put(id);
}

// 查询前先问布隆
public MemberDTO getMember(Long id) {
    if (!memberBloom.mightContain(id)) {
        return null;   // 一定不存在，直接返回
    }
    // ... 之后才走 Redis + DB
}
```
优点：占用极小（100 万元素 fpp=1% 只需 1.2 MB），99% 恶意 id 直接挡住。
缺点：需要"新增元素"时同步 `put`；不支持删除。

**（4）雪崩对策：随机 TTL + 集群**

```java
// 错误示范：所有 key 都是 30 分钟
redis.opsForValue().set(key, val, 30, TimeUnit.MINUTES);

// 正确示范：基础 30 分钟 + 0~5 分钟随机
long ttlSec = 30 * 60 + ThreadLocalRandom.current().nextInt(300);
redis.opsForValue().set(key, val, ttlSec, TimeUnit.SECONDS);
```
加上 Redis 主从/Cluster，即使一台宕机也不至于全部失效。

**（5）击穿对策：互斥锁**

```java
public RoomTypeDTO getRoomType(Long id) {
    String key = "room:type:" + id;
    String cached = redis.opsForValue().get(key);
    if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);

    // 缓存不存在，尝试拿分布式锁
    String lockKey = "lock:" + key;
    String reqId = UUID.randomUUID().toString();
    Boolean got = redis.opsForValue().setIfAbsent(lockKey, reqId, 10, TimeUnit.SECONDS);
    if (!Boolean.TRUE.equals(got)) {
        // 没拿到锁，睡一会儿再查缓存
        try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        return getRoomType(id);
    }
    try {
        cached = redis.opsForValue().get(key);   // 双重检查
        if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);
        RoomTypeDTO db = roomTypeMapper.selectById(id);
        redis.opsForValue().set(key, JSON.toJSONString(db), 30, TimeUnit.MINUTES);
        return db;
    } finally {
        // Lua 脚本释放锁（防误删）
        String lua = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
        redis.execute(new DefaultRedisScript<>(lua, Long.class),
                      Collections.singletonList(lockKey), reqId);
    }
}
```

**（6）多级缓存：Caffeine + Redis**

```
用户请求
   │
   ▼
Caffeine (JVM 内 100ms 级)  ────  命中直接返回
   │ 未命中
   ▼
Redis (集中式 1-2ms)  ────  命中回写 Caffeine
   │ 未命中
   ▼
MySQL
```
Caffeine 是 Google 出品的高性能本地缓存，性能是 Guava Cache 的 2-3 倍：

```java
Cache<String, MemberDTO> local = Caffeine.newBuilder()
    .maximumSize(10_000)
    .expireAfterWrite(2, TimeUnit.MINUTES)
    .build();

public MemberDTO getMember(Long id) {
    return local.get("m:" + id, k -> getFromRedisOrDb(id));
}
```

#### 3. 演示（10 分钟）

教师现场给 Day06 预约模块的 `RoomTypeService` 加上"多级缓存 + 击穿保护"：

```java
// service/impl/RoomTypeServiceImpl.java
@Service
@RequiredArgsConstructor
public class RoomTypeServiceImpl implements RoomTypeService {
    private final RoomTypeMapper roomTypeMapper;
    private final StringRedisTemplate redis;
    private final Cache<String, RoomTypeDTO> localCache = Caffeine.newBuilder()
            .maximumSize(1_000)
            .expireAfterWrite(2, TimeUnit.MINUTES)
            .build();

    private static final String LOCK_LUA =
        "if redis.call('get', KEYS[1]) == ARGV[1] " +
        "then return redis.call('del', KEYS[1]) else return 0 end";

    @Override
    public RoomTypeDTO getById(Long id) {
        String key = "room:type:" + id;
        // 1) Caffeine
        RoomTypeDTO local = localCache.getIfPresent(key);
        if (local != null) return local;

        // 2) Redis
        String cached = redis.opsForValue().get(key);
        if (cached != null) {
            if ("NULL".equals(cached)) return null;
            RoomTypeDTO r = JSON.parseObject(cached, RoomTypeDTO.class);
            localCache.put(key, r);
            return r;
        }

        // 3) 加锁访问 DB
        String lockKey = "lock:" + key;
        String reqId = UUID.randomUUID().toString();
        Boolean got = redis.opsForValue().setIfAbsent(lockKey, reqId, 10, TimeUnit.SECONDS);
        if (!Boolean.TRUE.equals(got)) {
            try { Thread.sleep(50); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            return getById(id);
        }
        try {
            cached = redis.opsForValue().get(key);
            if (cached != null) return JSON.parseObject(cached, RoomTypeDTO.class);
            RoomTypeDTO db = roomTypeMapper.selectDtoById(id);
            long ttl = 30 * 60 + ThreadLocalRandom.current().nextInt(300);
            if (db == null) {
                redis.opsForValue().set(key, "NULL", 60, TimeUnit.SECONDS);
                return null;
            }
            redis.opsForValue().set(key, JSON.toJSONString(db), ttl, TimeUnit.SECONDS);
            localCache.put(key, db);
            return db;
        } finally {
            redis.execute(new DefaultRedisScript<>(LOCK_LUA, Long.class),
                          Collections.singletonList(lockKey), reqId);
        }
    }
}
```

用 `curl` 连续打 20 次 `GET /api/room-types/1`，通过日志观察 SQL 只查一次，其余全部 Caffeine + Redis 命中。

#### 4. 实操（10 分钟）

学生任务：
1. 把 `caffeine` 依赖加入 pom：`com.github.ben-manes.caffeine:caffeine:3.1.8`。
2. 参考演示代码，给 `MemberServiceImpl.getById` 加上多级缓存。
3. 在 `MemberServiceImpl` 里加一个 `BloomFilter<Long>`，`@PostConstruct` 时装载所有会员 id；`getById` 首行判断 `mightContain`，不在则直接返回 null。

教师巡视：常见问题是 Caffeine 依赖冲突（Spring Boot 已内置 Caffeine 3.x，注意版本对齐）；有的学生把 BloomFilter 定义为方法内局部变量导致每次都重建——要放 `@Bean` 或字段。

#### 5. 小结（3 分钟）
一句话回顾：**三兄弟三对策——穿透布隆挡、雪崩 TTL 抖、击穿分布式锁**。多级缓存把性能压到微秒级。下节课我们不动数据库、不动 Redis，看看 JVM 层还能挤出多少性能。

### 四、课上提问
1. 缓存穿透与缓存击穿的关键区别是什么？
2. 为什么击穿场景不能用 `synchronized` 而必须用分布式锁？
3. `BloomFilter` 的 `mightContain` 返回 true 一定说明数据存在吗？

### 五、课堂练习
1. 写一段代码：设置 `member:*` 的 TTL 为 `1800 + Random(0, 300)` 秒。
2. 给 `RoomTypeService.getById` 加一个"逻辑过期"版本（value 里带 expireTime 字段，永不主动过期，异步刷新）。

### 六、课后思考
布隆过滤器不支持删除，那我们删掉一个会员后，布隆里那个 bit 位怎么办？（引出 Counting Bloom Filter / Cuckoo Filter。）

### 七、课后作业
1. 把项目里所有"缓存 key 相同 TTL"的代码全部改成加随机偏移。
2. 阅读一篇布隆过滤器的博客并写一段"为什么 fpp 越小内存越大"的推导。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  缓存优化：三兄弟对策                    │
├──────────────────────────────────────────┤
│ 穿透 ← 空值缓存 + 布隆过滤器             │
│ 雪崩 ← 随机 TTL + 集群 + 熔断            │
│ 击穿 ← 互斥锁 + 逻辑过期                 │
│ 多级：Caffeine → Redis → MySQL           │
│ 工具：Guava BloomFilter / Caffeine       │
└──────────────────────────────────────────┘
```

---

## 第 4 课时：JVM 调优与 GC 观察（Arthas）

### 一、教学目标
- 知识目标：了解 JVM 内存区域划分（堆 / 方法区 / 栈 / 本地方法栈 / 程序计数器）；掌握"堆"内部的分代结构（新生代 = Eden + S0 + S1，老年代，元空间）；能读懂常用启动参数 `-Xms` / `-Xmx` / `-Xmn` / `-XX:MetaspaceSize` / `-XX:MaxMetaspaceSize`；理解 **G1 与 ParNew+CMS** 两种收集器的差异（G1 支持大堆、可预测停顿；CMS 已在 JDK 9 弃用、JDK 14 移除）；能开启 `-Xlog:gc*` 输出 GC 日志；掌握 **Arthas** 常用命令（`dashboard` / `thread` / `jvm` / `watch` / `trace` / `heapdump`）用于线上排障。
- 能力目标：能给自己项目的 SpringBoot 启动加上合理的 JVM 参数；能用 Arthas attach 到进程；能用 `watch` 观察一个 Controller 方法的入参和返回值；能用 `dashboard` 判断线上进程"是不是 GC 太频繁"。

### 二、教学重难点
- 重点：Arthas 的四个救命命令（`dashboard` / `thread -n 3` / `watch` / `trace`）；G1 与 CMS 何时选哪个。
- 难点：Young GC 和 Full GC 的触发时机与危害对比（本课程只讲工具与观察，不深入调参理论）。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师："大家写了两周代码，`java -jar smart-elder.jar` 直接就跑起来了。但线上你会遇到这些情况：进程内存持续上涨、CPU 打到 100%、接口偶尔卡 5 秒。你**登不上机器改代码、不能加日志重启**——只能远程连进去看。这节课的主角 Arthas 就是解决这种'活体诊断'问题的。JVM 参数与 GC 观察是背景知识，Arthas 才是主菜。"

#### 2. 讲授（18 分钟）

**（1）JVM 内存区域**

```
      ┌──── JVM 进程 ─────────────────────────┐
      │                                       │
      │  堆 Heap (线程共享，最大)             │
      │  ┌───────┬────┬────┬─────────┐        │
      │  │ Eden  │ S0 │ S1 │ 老年代   │       │
      │  └───────┴────┴────┴─────────┘        │
      │  方法区 / 元空间 (类元数据)           │
      │  程序计数器 / 虚拟机栈 / 本地方法栈   │
      │                                       │
      └───────────────────────────────────────┘
```

**（2）核心启动参数**

| 参数 | 含义 | 示例（生产 4G 机器） |
|------|------|---------------------|
| `-Xms` | 堆初始大小 | `-Xms2g` |
| `-Xmx` | 堆最大大小 | `-Xmx2g`（建议与 Xms 相等） |
| `-Xmn` | 新生代大小 | `-Xmn768m` |
| `-XX:MetaspaceSize` | 元空间初始 | `256m` |
| `-XX:MaxMetaspaceSize` | 元空间上限 | `512m` |
| `-XX:+UseG1GC` | 用 G1 收集器 | JDK 17 默认 |
| `-Xlog:gc*:file=gc.log` | GC 日志 | 排障必备 |

推荐（JDK 17）：
```bash
java -Xms1g -Xmx1g -Xmn384m -XX:MetaspaceSize=256m -XX:MaxMetaspaceSize=512m \
     -XX:+UseG1GC -XX:MaxGCPauseMillis=200 \
     -Xlog:gc*:file=/var/log/smart-elder/gc.log:time,tags:filecount=10,filesize=10M \
     -jar smart-elder.jar
```

**（3）ParNew+CMS vs G1（简明对比）**

| 维度 | ParNew+CMS | G1 |
|------|-----------|----|
| 分代 | 显式（新/老） | Region 化，逻辑分代 |
| 停顿目标 | 无 | 可指定 `MaxGCPauseMillis` |
| 堆大小上限 | 4-8G 较合适 | 数十 GB |
| 状态 | JDK 9 弃用、14 移除 | JDK 9 默认（server）、17 默认 |
| 结论 | 只在维护老项目时接触 | **新项目直接用 G1** |

**（4）Arthas：JVM 神器**

Arthas 是阿里开源的 Java 线上诊断工具，无需重启进程即可 attach。安装：

```bash
# 下载
curl -O https://arthas.aliyun.com/arthas-boot.jar

# 启动（选择要 attach 的 Java 进程）
java -jar arthas-boot.jar
```

启动后会列出 JVM 进程，输入序号回车即可。

**（5）救命命令四件套**

1. `dashboard` —— 实时仪表盘（GC / 线程 / 内存 / 磁盘）
```
Memory used total max usage GC
heap 320M 512M 1024M 31.25% gc.g1_young_generation.count 12
```
2. `thread` —— 线程视图
```
thread                # 所有线程
thread -n 3          # CPU TOP3 线程
thread --state BLOCKED   # 查看阻塞线程
thread -b            # 查找死锁
```
3. `jvm` —— 打印 JVM 信息（版本、启动参数、GC 情况）
4. `watch` / `trace` —— 观察方法
```
watch com.itcast.smart_elder.controller.MemberController page '{params,returnObj}' -x 2
trace com.itcast.smart_elder.service.impl.MemberServiceImpl page
```

**（6）Arthas 三种"神操作"**

- `heapdump /tmp/dump.hprof` —— 一键堆转储
- `jad com.itcast.smart_elder.controller.MemberController` —— 反编译线上运行中的类（确认是不是"新代码没生效"）
- `redefine /tmp/HelloController.class` —— 热加载修改后的类（谨慎）

#### 3. 演示（12 分钟）

**（1）启动项目带 GC 日志**：
```bash
java -Xms256m -Xmx256m -Xmn96m -XX:+UseG1GC \
     -Xlog:gc*:file=gc.log:time,tags:filecount=5,filesize=5M \
     -jar smart-elder.jar
```

**（2）压一波**：
```bash
# 用简单循环调 200 次接口
for i in $(seq 1 200); do curl -s "http://localhost:8080/api/members/page?page=1&size=20" > /dev/null; done
```

**（3）Arthas attach**：
```bash
java -jar arthas-boot.jar
# 选进程号 → dashboard
```
观察 G1 Young GC 次数在爬升，堆内存曲线呈锯齿。

**（4）watch 观察方法**：
```
watch com.itcast.smart_elder.controller.MemberController page '{params,returnObj}' -x 2
```
学生看到实时打印的入参和返回值。

**（5）thread -n 3**：
```
"http-nio-8080-exec-4" ... cpuUsage=78.4%
```
现场分析——大部分时间在 JSON 序列化，与业务代码无关。

#### 4. 实操（8 分钟）

学生任务：
1. 下载 arthas-boot.jar，attach 到自己的 smart-elder 进程。
2. 依次执行 `dashboard`、`thread -n 3`、`jvm`，每条命令截图。
3. 使用 `watch` 观察 `MemberController.page` 的入参和返回值。
4. `quit` 退出（不要 `stop`——`stop` 会关闭 Arthas Server，同学之间就用不了了）。

教师巡视，常见问题：
- Windows 上路径含空格：把 arthas-boot.jar 放到 `D:\arthas` 这种简单路径。
- attach 失败：JDK 版本不一致，Arthas 必须与目标进程同一 JDK。
- 命令写错报错很长：`watch` 后面必须至少 3 个参数（类、方法、表达式）。

#### 5. 小结（3 分钟）
一句话回顾：**JVM 层参数几行搞定，Arthas 才是线上救命的关键**。dashboard / thread / watch / trace / heapdump 五个命令覆盖 90% 排障场景。下节课我们用 JMeter **主动**给系统加压，验证优化是否真的到位。

### 四、课上提问
1. `-Xmx` 与 `-Xms` 一般设成相等还是不等？为什么？
2. Arthas 的 `watch` 与 `trace` 有什么区别？
3. `jad` 命令有什么用途？

### 五、课堂练习
1. 写出一个 JDK 17 的推荐启动命令，堆 2G、G1、GC 日志滚动 10 个 20M。
2. 用一句 `watch` 只打印 `MemberService.page` 耗时（提示：`#cost`）。

### 六、课后思考
如果 Arthas 的 `thread -n 3` 显示 CPU TOP3 全是 `GC Thread`，说明什么问题？

### 七、课后作业
1. 阅读 Arthas 官方 5 分钟入门，跑通 `getstatic` / `stack` 两个命令。
2. 把项目 JVM 参数写死到启动脚本 `start.sh` 里，交到 Git 仓库 `deploy/` 目录。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  JVM 调优与 Arthas                       │
├──────────────────────────────────────────┤
│ 参数：-Xms / -Xmx / -Xmn                 │
│       -XX:+UseG1GC -XX:MaxGCPauseMillis  │
│       -Xlog:gc*:file=gc.log              │
│ Arthas：dashboard / thread / jvm         │
│         watch / trace / jad / heapdump   │
│ 记住四招够用 90%                         │
└──────────────────────────────────────────┘
```

---

## 第 5 课时：接口性能压测（JMeter）

### 一、教学目标
- 知识目标：理解"压测"在系统上线前的意义——**用最短时间发现最大瓶颈**；掌握 JMeter 的安装与主界面组成；熟练使用 4 个核心组件：**Thread Group（线程组）**、**HTTP Request（HTTP 请求）**、**View Results Tree（查看结果树）**、**Aggregate Report（聚合报告）**；能读懂三大核心指标 **TPS（吞吐量）**、**RT（响应时间 avg/median/p95/p99）**、**Error%（错误率）** 及其相互关系；熟悉 JMeter 命令行模式（`-n -t -l -e -o`）用于服务器上无界面压测。
- 能力目标：能亲手用 JMeter 图形界面搭出一个"100 并发 × 10 轮循环 = 1000 个请求"的压测脚本；能对 Day03 会员分页接口跑出真实 TPS/RT 报告；能对不同并发数做阶梯压测并绘制曲线。

### 二、教学重难点
- 重点：Thread Group 三个参数（线程数、Ramp-up、循环次数）的物理含义；Aggregate Report 每一列的字段意义（Samples / Average / Median / 90%Line / 95%Line / 99%Line / Min / Max / Error% / Throughput）。
- 难点："TPS 不再上升但 RT 直线上升"背后的"性能拐点"识别；HTML 报告的解读顺序。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师："上节课我们用 Arthas 观察系统的'当前状态'，但那是**被动**的——问题出现了才看。今天要学的 JMeter 是**主动**的——**没出问题就主动制造问题**，把系统压到崩溃边缘看看到底能扛多少。产品说'我们要支持 1000 并发'，你怎么知道系统能不能扛？跑一遍 JMeter 就知道。"

#### 2. 讲授（18 分钟）

**（1）压测的三大核心指标**

| 指标 | 全称 | 定义 | 好坏参考 |
|------|------|------|---------|
| TPS | Transactions Per Second | 每秒事务数 | 一般 web 接口 100-1000 |
| RT | Response Time | 单次请求耗时 | p99 一般要求 < 500ms |
| Error% | 错误率 | 失败请求占比 | 生产要求 < 0.1% |

关系：**TPS × RT ≈ 并发数**（Little 定律）。当并发上升到某点，TPS 不再涨，RT 反而暴涨——即"拐点"，是系统真实的容量上限。

**（2）JMeter 安装**

从 https://jmeter.apache.org/download_jmeter.cgi 下载 zip，解压即可。启动：
- Windows：`bin\jmeter.bat`（GUI）
- Linux/Mac：`bin/jmeter.sh`
- 命令行：`bin/jmeter -n -t plan.jmx -l result.jtl -e -o report/`

> **教师强调：** 图形界面**只用来编写与调试脚本**，正式压测一律走命令行 —— GUI 本身很吃内存，会污染压测结果。

**（3）JMeter 主要组件**

| 组件类别 | 常用元件 | 作用 |
|---------|--------|------|
| 线程 | Thread Group | 控制并发用户数与循环 |
| 取样器 | HTTP Request | 发起 HTTP 请求 |
| 配置元件 | HTTP Header Manager / HTTP Request Defaults | 全局请求头、默认地址 |
| 前置处理器 | User Parameters | 参数化 |
| 定时器 | Constant Timer / Uniform Random Timer | 加思考时间 |
| 断言 | Response Assertion / JSON Assertion | 断言返回值 |
| 监听器 | View Results Tree / Aggregate Report / Summary Report | 结果展示 |

**（4）Thread Group 三大参数**

```
线程数 (Number of Threads)  = 并发用户数 = 100
Ramp-up (秒)                = 100 个线程在多少秒内全部启动 = 5 秒
循环次数 (Loop Count)         = 每个线程跑几遍 = 10
```
总请求数 = 100 × 10 = 1000。Ramp-up 用于避免瞬时打满 —— 5 秒内每秒起 20 个用户。

**（5）Aggregate Report 字段详解**

| 字段 | 含义 |
|------|------|
| Label | 请求名（对应 HTTP Request 元件） |
| # Samples | 总请求数 |
| Average | 平均响应时间 (ms) |
| Median | 50% 分位 |
| 90% Line | 90% 分位（90% 请求 ≤ 该值） |
| 95% Line | 95% 分位 |
| 99% Line | 99% 分位（面试常问） |
| Min / Max | 最短/最长 |
| Error% | 错误率 |
| Throughput | 每秒请求数（即 TPS） |
| Received / Sent KB/sec | 带宽 |

> **教师强调：** 面试和线上运维**只看 p99 和 p95**，不看 Average——因为长尾请求才是用户抱怨"太卡"的元凶。

#### 3. 演示（12 分钟）

**（1）新建测试计划**：
- 右键 Test Plan → Add → Threads (Users) → Thread Group
  - Number of Threads: 100
  - Ramp-up period: 5
  - Loop Count: 10
- Thread Group 右键 → Add → Sampler → HTTP Request
  - Server Name: `localhost`
  - Port: `8080`
  - Method: GET
  - Path: `/api/members/page`
  - Parameters: `page=1`、`size=20`
- Thread Group 右键 → Add → Config Element → HTTP Header Manager
  - `Content-Type: application/json`
  - `Authorization: Bearer xxx`（如需登录）
- Thread Group 右键 → Add → Listener → View Results Tree
- Thread Group 右键 → Add → Listener → Aggregate Report

**（2）保存为 `member-page.jmx`，先 GUI 跑一次**：
点绿色播放按钮，观察 Aggregate Report：
```
Label        Samples  Average  Median  95%Line  99%Line  Error%  Throughput
member/page  1000     52ms     45ms    120ms    180ms    0.00%   190.5/sec
```
**TPS ≈ 190、p99 = 180ms、错误率 0%**，这是**基线数据**。

**（3）命令行跑一次并生成 HTML 报告**：
```bash
bin/jmeter -n -t member-page.jmx -l result.jtl -e -o report/
open report/index.html
```
HTML 报告包含 APDEX、响应时间分位曲线、每秒事务数等图表。

**（4）阶梯压测（重点）**：
把 Number of Threads 依次改为 50/100/200/300/500，各跑一次，把 TPS 和 p99 记在 Excel 里：

| 并发 | TPS | p99 | Error% |
|------|-----|-----|--------|
| 50 | 190 | 65ms | 0% |
| 100 | 380 | 120ms | 0% |
| 200 | 620 | 380ms | 0% |
| 300 | 680 | 950ms | 0.3% |
| 500 | 690 | 2200ms | 2.5% |

从 200 → 300 并发 TPS 只涨了 60，p99 却从 380ms 飙到 950ms —— **性能拐点在 200 附近**。

#### 4. 实操（8 分钟）

学生任务：
1. 下载 JMeter 并启动 GUI。
2. 复刻演示步骤，建一个针对 `/api/members/page` 的压测脚本 `member-page.jmx`。
3. 100 并发 × 10 轮跑一次，把 Aggregate Report 数据截图。
4. 用 `-n -t -l -e -o` 命令行模式跑一次并打开 HTML 报告。

教师巡视，重点提醒：
- 忘了 HTTP Request Defaults 导致每个请求都要重填 host/port —— 用 Defaults 元件简化。
- 忘勾"Retrieve All Embedded Resources" 导致压测把 JS/CSS 也拉了 —— 后端 API 压测不需要勾。
- GUI 跑几千个请求内存会撑爆 —— 一定用命令行。

#### 5. 小结（3 分钟）
一句话回顾：**JMeter = 线程组 × HTTP Request × 结果监听器**。看 TPS 和 p99，找性能拐点。命令行才是正式压测方式，GUI 只用来编脚本。下节课我们把今天获得的**基线数据**与前几节课做的**索引/缓存优化**做对比，产出一份漂亮的**性能优化报告**——就是简历上你最亮眼的一段。

### 四、课上提问
1. 平均响应时间和 p99 响应时间，哪个更能反映用户真实感受？
2. 100 并发、Ramp-up = 5 秒，第 3 秒时并发用户数大约是多少？
3. 为什么正式压测要用命令行而不是 GUI？

### 五、课堂练习
1. 写一个 `Uniform Random Timer` 让每个请求间隔 100-300ms（模拟真实用户思考时间）。
2. 增加 `Response Assertion`，如果响应体不包含 `"code":0` 则视为失败。

### 六、课后思考
如果 Error% > 1% 之后再继续加压，压测数据还有意义吗？

### 七、课后作业
1. 对 Day06 预约下单接口 `POST /api/reservations` 做一次 100 并发压测（注意登录 token）。
2. 阅读文档《JMeter 分布式压测》，简述为什么单机压测存在瓶颈。

### 八、板书设计
```
┌──────────────────────────────────────────┐
│  JMeter 接口压测                         │
├──────────────────────────────────────────┤
│ 组件：ThreadGroup + HTTPRequest          │
│      + ViewResultsTree + AggregateReport │
│ 指标：TPS / RT (p95/p99) / Error%        │
│ 关系：TPS × RT ≈ 并发数                  │
│ 模式：GUI 编辑 → CLI 压测 → HTML 报告    │
│ 阶梯：50/100/200/300/500 找拐点          │
└──────────────────────────────────────────┘
```

---

## 第 6 课时：优化前后对比与报告输出

### 一、教学目标
- 知识目标：理解"性能报告"是把前 5 节课的成果**沉淀为可复用文档**的最后一步；掌握性能报告的**五段式结构**——**背景 / 问题 / 方案 / 数据 / 结论**；能选出合适的指标口径（TPS、p95、p99、CPU、GC 次数、慢 SQL 计数、缓存命中率）；能用 Markdown 表格做优化前后对比；能提炼"三条最有价值的改动"作为报告 Highlights。
- 能力目标：能独立完成《AI 智能养老社区系统 v1.0 性能优化报告》的完整撰写；能把报告贴进个人简历"项目经历"栏作为量化证据。

### 二、教学重难点
- 重点：数据的**可比性**——同机器、同数据量、同压测脚本，只改变待验证的变量；报告最后一定要有一句**可复现指标**（如"p99 从 950ms → 180ms，下降 81%"）。
- 难点：如何避免"数据美化"——真实项目里有时优化后 TPS 反而下降（如加了缓存击穿保护，缓存 miss 时确实慢一点），要如实写。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师："前 5 节课我们做了慢 SQL 诊断、索引优化、缓存改造、JVM 调参、JMeter 压测。这些工作**你自己知道很牛**，但**别人看不到**。今天最后一节课，我们把它们写成一份**产品级的性能优化报告**——将来这份报告是你面试时最硬的证据。"

#### 2. 讲授（12 分钟）

**（1）性能报告的五段式结构**

```
1. 背景 (Context)     系统是什么？为什么要优化？——3-5 行
2. 问题 (Problem)     发现的核心瓶颈 —— TOP3
3. 方案 (Solution)    针对每个问题的具体改动 —— 表格
4. 数据 (Data)        优化前后对比 —— 关键表 + 图
5. 结论 (Conclusion)  量化收益 + 后续 Roadmap
```

**（2）指标口径统一**

| 指标 | 单位 | 优化目标 |
|------|------|---------|
| TPS | req/s | 越大越好 |
| p99 RT | ms | 越小越好 |
| p95 RT | ms | 越小越好 |
| CPU 使用率 | % | 保持 60-70% 为宜 |
| GC 频次 | 次/分钟 | 越少越好 |
| 慢 SQL 计数 | 条/天 | 归零 |
| 缓存命中率 | % | > 95% |

**（3）Markdown 对比表推荐格式**

```markdown
| 接口 | 指标 | 优化前 | 优化后 | 提升 |
|------|------|--------|--------|------|
| 会员分页 | TPS | 190 | 850 | +347% |
| 会员分页 | p99 | 950ms | 130ms | -86% |
| 房型详情 | 缓存命中率 | 0% | 98.5% | — |
```

**（4）报告模板（拷贝即用）**

见"演示"环节完整贴出。

#### 3. 演示（20 分钟）

教师现场把整份报告一节一节打出来，学生跟着抄：

**`docs/performance-report-v1.md`**：

````markdown
# AI 智能养老社区系统 v1.0 性能优化报告

## 1. 背景

AI 智能养老社区系统于 2026-06 上线，一期覆盖会员管理、客房预约、AI 智能问答等模块。上线 3 周后运维反馈：**会员分页接口日均峰值 QPS 200，p99 达 1s；房型详情接口 Redis 命中率 0%（未接入缓存）**。本报告记录 Day10 优化前后关键指标对比。

## 2. 发现的核心问题（TOP3）

| # | 问题 | 表现 | 根因 |
|---|------|------|------|
| 1 | 会员分页慢 | p99 = 950ms | `WHERE member_level=? AND phone LIKE '138%' ORDER BY create_time` 缺联合索引，`Using filesort` |
| 2 | 房型详情缓存缺失 | 命中率 0% | `RoomTypeService.getById` 直查 DB |
| 3 | 缓存击穿风险 | 单点热点 key 失效瞬间打库 | 无互斥锁 |

## 3. 优化方案

### 3.1 慢 SQL 索引优化
```sql
CREATE INDEX idx_level_ctime_phone ON elder_member(member_level, create_time, phone);
CREATE INDEX idx_member_status_date ON room_reservation(member_id, status, check_in_date);
CREATE INDEX idx_date_status ON room_reservation(check_in_date, status);
```

### 3.2 缓存三兄弟改造
- 穿透：`MemberService` 加入 Guava BloomFilter，`@PostConstruct` 装载全部 id
- 雪崩：所有 `member:*`、`room:type:*` key TTL = `1800 + Random(0,300)` 秒
- 击穿：`RoomTypeServiceImpl` 加分布式锁 + 双重检查 + Lua 释放锁
- 多级：Caffeine + Redis + MySQL

### 3.3 JVM 参数
```
-Xms1g -Xmx1g -Xmn384m -XX:+UseG1GC -XX:MaxGCPauseMillis=200
```

## 4. 数据对比

### 4.1 会员分页接口（100 并发 × 10 轮）

| 指标 | 优化前 | 优化后 | 变化 |
|------|--------|--------|------|
| TPS | 190 req/s | 850 req/s | **+347%** |
| p95 | 620ms | 95ms | **-85%** |
| p99 | 950ms | 130ms | **-86%** |
| CPU 峰值 | 92% | 55% | -37pt |
| MySQL 慢查询 | 32 条 | 0 条 | -100% |

### 4.2 房型详情接口（500 并发 × 5 轮）

| 指标 | 优化前 | 优化后 | 变化 |
|------|--------|--------|------|
| TPS | 320 | 4200 | **+1213%** |
| p99 | 780ms | 12ms | **-98%** |
| Redis 命中率 | 0% | 98.5% | +98.5pt |
| DB 每秒查询 | 320 | 4.6 | -98.5% |

### 4.3 GC 观察

| 指标 | 优化前 | 优化后 |
|------|--------|--------|
| Young GC 次数/分钟 | 24 | 8 |
| Full GC 次数/小时 | 3 | 0 |
| GC 平均停顿 | 180ms | 45ms |

## 5. 结论

- **TPS 综合提升 4-12 倍**；**p99 全部降至 200ms 以内**；**慢 SQL 归零**；**GC 频次减半**。
- 关键手段：**联合索引 3 条 + Caffeine 多级缓存 + 分布式锁防击穿 + G1 GC**。
- 遗留 & 下一步：
  1. 预约下单接口尚未做压测（Day11 待补）
  2. Redis Cluster 尚未上（Day11 部署时切）
  3. AI 接口的流式响应压测方式待研究

---

**报告作者：** 你的名字
**报告日期：** 2026-07-09
**测试机器：** 4C8G / MySQL 8.0.34 / Redis 7.2 / JDK 17
**测试脚本：** `perf/*.jmx`（已提交到 Git 仓库 `deploy/perf/`）
````

**演示第二步**：把上面的 Markdown 用 `pandoc report.md -o report.pdf` 导成 PDF，让学生看到最终交付物。

#### 4. 实操（8 分钟）

学生任务：
1. 在项目根目录新建 `docs/performance-report-v1.md`，把老师演示的报告模板 copy 一份。
2. 用**自己昨天课上的真实压测数据**替换所有数字。
3. 提交到 Git：`git add docs/ && git commit -m "docs: performance optimization report v1"`。
4. （挑战）用 pandoc 或 Typora 导出 PDF 存到 `docs/pdf/`。

教师巡视，重点纠正：
- 学生把"优化后"数据写得过于夸张 —— 提醒诚实。
- 表格里忘了写"环境版本"—— 报告没有环境就无法复现。
- 关键截图（Aggregate Report、Arthas dashboard）没贴 —— 建议在 `docs/img/` 里存 PNG。

#### 5. 小结（2 分钟）
Day10 六节课完整走完了性能优化的完整闭环：**慢日志找问题 → EXPLAIN 定位 → 索引改写 → 缓存加固 → JVM 调参 → JMeter 压测 → 报告输出**。这份报告一定要写好——**它比十行代码更能证明你的能力**。下一天 Day11 我们把项目部署到 Linux 服务器上，Nginx + Docker 一条龙，让别人也能访问。

### 四、课上提问
1. 性能报告最能打动面试官的是哪一部分？
2. 优化前后对比时，"变量控制"要保证哪些不变？
3. 为什么要在报告里写"遗留问题"？

### 五、课堂练习
1. 修改报告模板，加入一节"缓存命中率随时间变化"的图（可以用 `mermaid` 语法）。
2. 给自己项目再选一个**未被优化**的接口，用同样格式写一段简短对比。

### 六、课后思考
如果优化后某个接口的 TPS 反而下降了，报告里怎么写才既诚实又不给自己挖坑？

### 七、课后作业
1. 完善你的性能报告，做到"背景、问题、方案、数据、结论"五段齐全。
2. 更新简历的项目经历，把量化数据（TPS 850、p99 130ms、GC 减半）加进去。

### 八、板书设计
```
┌────────────────────────────────────────────┐
│  优化前后对比与报告输出                    │
├────────────────────────────────────────────┤
│ 五段式：背景/问题/方案/数据/结论           │
│ 指标：TPS / p95 / p99 / CPU / GC / 命中率  │
│ 表格 + 图 + 环境 + 脚本 = 可复现           │
│ Highlights：TPS +347% / p99 -86%           │
│ 简历：量化 > 描述                          │
└────────────────────────────────────────────┘
```

---

## Day10 全天小结

Day10 是**能力质变的一天**：
- 前 9 天你会**写业务**；
- Day10 你会**优化业务**——发现问题、定位问题、解决问题、量化收益。

**技能地图：**
1. **诊断力**：慢日志 / EXPLAIN / Arthas dashboard
2. **改造力**：联合索引 / 覆盖索引 / 缓存三兄弟 / 多级缓存
3. **观察力**：JMeter TPS/p99 / GC 日志
4. **表达力**：性能报告五段式

**后续衔接：**
- Day11：把优化后的项目**部署上线**（Nginx + Docker）。
- Day12：把这份**性能优化报告**变成面试稿的一部分。

**推荐扩展阅读：**
- 《高性能 MySQL》第 3-6 章
- 《Redis 设计与实现》缓存篇
- Arthas 官方 GitHub Wiki
- Apache JMeter 官方 User Manual

至此 Day10 完成。恭喜你，从今天起你的项目**已具备生产可运维能力**。
