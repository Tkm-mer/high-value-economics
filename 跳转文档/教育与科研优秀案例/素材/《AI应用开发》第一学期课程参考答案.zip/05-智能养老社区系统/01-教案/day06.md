# 《智能养老社区系统》- 教师教案 - Day06：客房智能预约管理

**授课日：Day 06 / 共 12 天**
**课时安排：6 课时 × 45 分钟**
**技术点覆盖：技术点 8 - 客房预约业务 + Redis 缓存与分布式锁 + AI 智能推荐**
**授课对象：Java 全栈方向初学者**
**项目案例：AI 智能养老社区系统**
**前置知识：Day03 会员 CRUD、Day04 客房管理、Day05 Spring AI 通义千问对接（ChatClient / SSE 流式响应）**

---

## 第 1 课时：预约业务分析与状态机

### 一、教学目标
- 知识目标：理解养老社区客房预约的完整业务链路（选房 → 下单 → 支付 → 入住 → 完成/取消）；掌握状态机的思想及 5 个状态的迁移规则；理解并发场景下"同一房、同时段被两个人订走"这一典型超卖问题为何必须用分布式锁而非本地锁；掌握时间区间重叠判定的 SQL 表达式。
- 能力目标：能画出预约状态迁移图，能用一句 SQL 判断某间客房在指定日期段是否已被占用，能用一句话讲清楚"为什么单机 synchronized 不够用"。

### 二、教学重难点
- 重点：预约 5 个状态（0 待支付 / 1 已确认 / 2 已入住 / 3 已完成 / 4 已取消）的合法迁移路径；时间重叠 SQL：`check_in_date < ? AND check_out_date > ?`。
- 难点：为什么"入住日期 < 已存入住日期 且 退房日期 > 已存退房日期"不是重叠的正确写法；分布式锁与数据库悲观锁的取舍。

### 三、教学过程（45 分钟）

#### 1. 导入（4 分钟）
教师提问："过年抢高铁票时，你和你朋友同一秒点击同一张座位，谁能抢到？"引导学生想到"数据库层要有防护"。再类比："我们社区的 101 房本周只剩一个空档，两位家属同一秒下单，会不会双双成功？"由此引出今天的核心矛盾——**并发下单**与**状态机**。

#### 2. 讲授（18 分钟）
（1）先复习 Day01 建的 `room_reservation` 表字段：id、member_id、room_id、check_in_date、check_out_date、status、total_price、create_time。逐字段解释业务含义，尤其强调 `status` 是 tinyint、`total_price` 是 decimal(10,2)。

（2）画出状态迁移图（板书）：
```
[创建] --下单成功--> 0待支付
0待支付 --支付--> 1已确认
0待支付 --超时/主动取消--> 4已取消
1已确认 --到店办入住--> 2已入住
1已确认 --取消--> 4已取消
2已入住 --退房--> 3已完成
```
强调："已完成"和"已取消"是终态，一旦到达不可再变。

（3）讲解**时间重叠**的正确 SQL 表达。设已有一条预约 [A_in, A_out)，新预约 [B_in, B_out)，**重叠**当且仅当 `B_in < A_out AND B_out > A_in`。用画数轴的方式演示 4 种关系（完全包含/半包含/相邻不重叠/完全分离），让学生自己判断哪几种是"重叠"。

（4）讲解并发问题：即便有重叠 SQL，如果两个线程"同时查询-都发现没冲突-同时插入"，仍会双写成功。本地锁 synchronized 只在单个 JVM 内有效，一旦部署两台机器就失效，所以必须使用**分布式锁**（下节课用 Redis 实现）。

#### 3. 演示（10 分钟）
教师打开 Navicat，在 `room_reservation` 表插入两条示例数据：
```sql
INSERT INTO room_reservation(member_id, room_id, check_in_date, check_out_date, status, total_price)
VALUES (1, 101, '2026-07-15', '2026-07-18', 1, 900.00);
```
然后现场敲一句冲突检测：
```sql
SELECT COUNT(*) FROM room_reservation
WHERE room_id = 101
  AND status IN (0, 1, 2)      -- 只有活跃订单参与冲突判定
  AND check_in_date < '2026-07-20'
  AND check_out_date > '2026-07-16';
```
让学生观察 count = 1，证明重叠命中。

#### 4. 实操（10 分钟）
学生任务：以两人一组，在自己的 MySQL 里造 3 条不同的预约数据，然后写 3 条 SQL 分别验证"完全包含""半重叠""完全分离"。教师巡视并纠正学生把 `<` 误写为 `<=` 的常见错误（提醒边界：退房日 = 下一位入住日 视为不重叠）。

#### 5. 小结（3 分钟）
回顾状态机 5 个状态、时间重叠 SQL、并发问题为何必须分布式锁。预告下节课把这些规则代码化。

### 四、课上提问
1. `status = 4 已取消`的订单还需要参与冲突检测吗？为什么？
2. 时间重叠 SQL 里的 `<` 能改成 `<=` 吗？后果是什么？
3. synchronized 为什么在集群环境失效？

### 五、课堂练习
1. 画出预约状态迁移图，标注每条边对应的接口。
2. 写出 SQL 判断"2026-08-01 至 2026-08-05"是否与已有订单重叠。

### 六、课后思考
如果允许"提前 30 分钟自动取消未支付订单"，需要哪些额外机制？（引出定时任务/延迟队列）

### 七、课后作业
1. 用 Markdown 把 5 个状态、6 条迁移边整理成表格。
2. 在 `docs/api/reservation.md` 起草 4 个接口的 URL 与请求参数占位。

### 八、板书设计
```
┌─────────────────────────────────────────────┐
│  预约业务与状态机                           │
├─────────────────────────────────────────────┤
│ 状态：0待支付 1已确认 2已入住 3完成 4取消   │
│ 冲突 SQL：in < ? AND out > ?                │
│ 并发保护：分布式锁（下节课）                │
└─────────────────────────────────────────────┘
```

---

## 第 2 课时：预约接口开发（下单/取消）

### 一、教学目标
- 知识目标：掌握预约核心业务方法 `createReservation` 的完整流程（参数校验 → 时间冲突 → 计算总价 → 落库 → 更新客房状态）；理解 Spring 声明式事务 `@Transactional` 的传播与回滚规则；掌握取消订单的合法状态判定。
- 能力目标：能独立完成 ReservationController / Service / Mapper / XML 四层代码，能在 Postman 联调出"新增成功""重叠拒绝""重复取消拒绝"三种情况。

### 二、教学重难点
- 重点：Service 方法内的顺序（先校验后落库、事务包裹）；`total_price = 日均价 × 入住天数` 的计算逻辑。
- 难点：状态迁移的白名单校验（不能从 已完成 回退到 已确认）；客房 `room.status` 与预约状态的同步更新。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
承接上节课："规则已经说清楚，今天把它变成 Java 代码。看看能不能一次跑通。"

#### 2. 讲授（15 分钟）
（1）分析接口清单：
| 动作 | 方法 | URL |
|------|------|-----|
| 下单 | POST | /api/reservations |
| 取消 | PUT | /api/reservations/{id}/cancel |
| 详情 | GET | /api/reservations/{id} |
| 分页 | GET | /api/reservations/page |

（2）讲解 DTO 设计：`ReservationDTO` 只装前端传入的 memberId、roomId、checkInDate、checkOutDate，**不能**让前端传 status 和 totalPrice（安全）。

（3）讲解事务边界：`createReservation` 从校验开始整体包 `@Transactional`，任一步骤抛异常整体回滚。

#### 3. 演示（15 分钟）
教师依次敲以下代码（学生跟随）：

```java
// ReservationController.java
@RestController
@RequestMapping("/api/reservations")
@RequiredArgsConstructor
public class ReservationController {
    private final ReservationService reservationService;

    @PostMapping
    public Result<Long> create(@RequestBody @Valid ReservationDTO dto) {
        Long id = reservationService.createReservation(dto);
        return Result.success(id);
    }

    @PutMapping("/{id}/cancel")
    public Result<Void> cancel(@PathVariable Long id) {
        reservationService.cancelReservation(id);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result<ReservationVO> detail(@PathVariable Long id) {
        return Result.success(reservationService.getDetail(id));
    }

    @GetMapping("/page")
    public Result<PageBean<ReservationVO>> page(ReservationQuery query) {
        return Result.success(reservationService.pageQuery(query));
    }
}
```

```java
// ReservationServiceImpl.java (核心方法)
@Override
@Transactional(rollbackFor = Exception.class)
public Long createReservation(ReservationDTO dto) {
    // 1. 参数校验
    if (!dto.getCheckInDate().isBefore(dto.getCheckOutDate())) {
        throw new BizException("退房日期必须晚于入住日期");
    }
    // 2. 客房存在性与状态校验
    Room room = roomMapper.selectById(dto.getRoomId());
    if (room == null || room.getStatus() != 1) {
        throw new BizException("客房不可用");
    }
    // 3. 时间冲突校验
    int conflict = reservationMapper.countConflict(
        dto.getRoomId(), dto.getCheckInDate(), dto.getCheckOutDate());
    if (conflict > 0) {
        throw new BizException("该时段已被预订");
    }
    // 4. 计算总价
    long days = ChronoUnit.DAYS.between(dto.getCheckInDate(), dto.getCheckOutDate());
    BigDecimal total = room.getDailyPrice().multiply(BigDecimal.valueOf(days));
    // 5. 落库
    RoomReservation entity = new RoomReservation();
    BeanUtils.copyProperties(dto, entity);
    entity.setStatus(0); // 待支付
    entity.setTotalPrice(total);
    entity.setCreateTime(LocalDateTime.now());
    reservationMapper.insert(entity);
    return entity.getId();
}
```

```xml
<!-- ReservationMapper.xml -->
<select id="countConflict" resultType="int">
    SELECT COUNT(*) FROM room_reservation
    WHERE room_id = #{roomId}
      AND status IN (0, 1, 2)
      AND check_in_date &lt; #{checkOut}
      AND check_out_date &gt; #{checkIn}
</select>
```

演示 Postman 调用 POST 接口，第一次成功，第二次相同参数报"该时段已被预订"。

#### 4. 实操（9 分钟）
学生实现 `cancelReservation` 方法：只允许 `status = 0 或 1` 的订单被取消，取消后 `status = 4`，其他情况抛"当前状态不允许取消"。教师巡视，检查是否使用了行锁 `SELECT ... FOR UPDATE`（本节先不做，作为下节课优化点）。

#### 5. 小结（3 分钟）
回顾"下单五步"：校验 → 存在 → 冲突 → 计算 → 落库；提醒下节课引入 Redis 解决并发。

### 四、课上提问
1. `@Transactional` 加在 Controller 还是 Service？为什么？
2. 冲突 SQL 里为什么把 status IN (0,1,2)？
3. `total_price` 为什么不允许前端传？

### 五、课堂练习
1. 补齐 `cancelReservation`，只允许 0/1 状态取消。
2. 在 Postman 用同一时段连续下两单，观察第二单是否报错。

### 六、课后思考
两个用户"精确同一毫秒"下单，虽然事务能保证一致性，但 SQL 冲突判定发生在两个事务查询阶段，能否 100% 拦截？

### 七、课后作业
1. 完成分页查询 `pageQuery`，支持按 memberId、status 过滤。
2. 用 Postman 造 5 条测试数据，覆盖 4 种状态。

### 八、板书设计
```
┌───────────────────────────────────────────┐
│  下单五步走                               │
├───────────────────────────────────────────┤
│ ①校验 ②房存 ③冲突 ④算价 ⑤落库          │
│ 事务：@Transactional(rollbackFor=Ex.)     │
│ 取消：只允许 0/1 → 4                      │
└───────────────────────────────────────────┘
```

---

## 第 3 课时：Redis 基础与集成

### 一、教学目标
- 知识目标：理解 Redis 的定位（内存 KV 数据库、支持 5 大数据结构）；掌握 Spring Boot 集成 Redis 的完整步骤（依赖 → 配置 → 自定义 RedisTemplate）；掌握 5 大类型（String / Hash / List / Set / ZSet）在 Java 端的操作 API。
- 能力目标：能在项目中配好 Redis、能写出 6 种基础操作代码、能通过 redis-cli 验证结果。

### 二、教学重难点
- 重点：`RedisConfig` 中为什么必须替换默认的 JdkSerializationRedisSerializer 为 Jackson2JsonRedisSerializer + StringRedisSerializer。
- 难点：序列化不一致导致 redis-cli 中看到"\xac\xed\x00\x05t..."乱码的排查思路。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师在黑板画一张对比表：MySQL（磁盘、10ms 级）vs Redis（内存、微秒级）。问："如果客房列表 1 秒被访问 500 次，MySQL 会累趴吗？" 引出缓存必要性。

#### 2. 讲授（18 分钟）
（1）依赖：
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```
说明 spring-boot-starter-data-redis 默认已经引入 Lettuce 连接池。

（2）配置文件：
```yaml
spring:
  data:
    redis:
      host: 127.0.0.1
      port: 6379
      password:
      database: 0
      lettuce:
        pool:
          max-active: 8
          max-idle: 8
          min-idle: 0
```

（3）自定义 `RedisTemplate`：默认的 JdkSerializer 存进去是乱码，替换成 Jackson + StringSerializer。

（4）5 大类型 API 一览：
| 类型 | 操作对象 | 常用方法 |
|------|----------|----------|
| String | opsForValue | set / get / setIfAbsent / increment |
| Hash | opsForHash | put / get / entries |
| List | opsForList | leftPush / rightPop / range |
| Set | opsForSet | add / members / isMember |
| ZSet | opsForZSet | add(带 score) / rangeByScore |

#### 3. 演示（12 分钟）
```java
// RedisConfig.java
@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory cf) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(cf);

        StringRedisSerializer stringSer = new StringRedisSerializer();
        Jackson2JsonRedisSerializer<Object> jsonSer =
            new Jackson2JsonRedisSerializer<>(Object.class);
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        mapper.activateDefaultTyping(LaissezFaireSubTypeValidator.instance,
            ObjectMapper.DefaultTyping.NON_FINAL);
        jsonSer.setObjectMapper(mapper);

        template.setKeySerializer(stringSer);
        template.setHashKeySerializer(stringSer);
        template.setValueSerializer(jsonSer);
        template.setHashValueSerializer(jsonSer);
        template.afterPropertiesSet();
        return template;
    }
}
```

```java
// CacheDemoService.java - 五种类型演示
@Service
@RequiredArgsConstructor
public class CacheDemoService {
    private final RedisTemplate<String, Object> redisTemplate;

    public void demo() {
        // String
        redisTemplate.opsForValue().set("k1", "hello", 60, TimeUnit.SECONDS);
        Object v1 = redisTemplate.opsForValue().get("k1");

        // Hash
        redisTemplate.opsForHash().put("user:1", "name", "张桂芳");
        redisTemplate.opsForHash().put("user:1", "age", 78);

        // List (最近浏览记录)
        redisTemplate.opsForList().leftPush("recent:1", "101");
        redisTemplate.opsForList().leftPush("recent:1", "202");

        // Set (客房标签)
        redisTemplate.opsForSet().add("room:101:tags", "安静", "南向", "花园");

        // ZSet (客房热度排行)
        redisTemplate.opsForZSet().incrementScore("room:hot", "101", 1);
    }
}
```

现场用 `redis-cli` 敲 `KEYS *`、`HGETALL user:1` 验证。

#### 4. 实操（9 分钟）
学生调用 `demo()` 后打开 redis-cli 验证 5 大结构，如果值显示为 JSON 字符串就通过，如果是 `"\xac\xed..."` 说明 RedisConfig 未生效。

#### 5. 小结（3 分钟）
Redis 集成三件事：依赖、yml、Config。序列化必须自定义。

### 四、课上提问
1. 为什么 KeySerializer 用 String 而不是 Jackson？
2. Redis 默认端口是多少？
3. 5 种数据结构分别适合哪类业务？

### 五、课堂练习
1. 用 String 类型缓存"当前登录用户"，5 分钟过期。
2. 用 ZSet 记录客房浏览次数排行榜。

### 六、课后思考
如果不用自定义 Config，直接 `@Autowired StringRedisTemplate` 行不行？两者区别？

### 七、课后作业
1. 在 CacheDemoService 中新增 `zsetRank(String key, int topN)` 返回 ZSet 前 N 名。
2. 用 redis-cli 观察 List 的入队顺序。

### 八、板书设计
```
┌───────────────────────────────────────┐
│  Redis 集成三件事                     │
├───────────────────────────────────────┤
│ ①依赖 spring-boot-starter-data-redis │
│ ②yml 配 host/port/pool               │
│ ③RedisConfig 换序列化                │
└───────────────────────────────────────┘
```

---

## 第 4 课时：Redis 实战：缓存与分布式锁

### 一、教学目标
- 知识目标：掌握 Cache-Aside 模式（先查缓存、缓存无则查库并回填）；理解缓存雪崩与"随机 TTL"抖动；掌握 `setIfAbsent`（SETNX）实现分布式锁的原理与 try-finally 释放规范；理解为什么不引入重入锁。
- 能力目标：能给客房列表加缓存、能给下单接口加分布式锁、能验证并发下单只有一单成功。

### 二、教学重难点
- 重点：`Cache-Aside` 的三步走；分布式锁 `setIfAbsent(key, value, ttl, unit)` 的原子性；try-finally 释放。
- 难点：为什么锁一定要设置过期时间；释放锁前先校验 value（避免释放别人的锁）。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"上节课我们把 Redis 装好了。今天用它做两件真正救命的事：给客房列表加缓存、给下单加锁防超卖。"

#### 2. 讲授（15 分钟）
（1）Cache-Aside 三步走：
```
查询：先查 Redis → 命中直接返回；未命中 → 查 DB → 回填 Redis → 返回
更新：先更新 DB → 删缓存（不是改，避免脏写）
```

（2）**雪崩防护**：批量 key 同时到期会瞬间击穿到 DB。做法：TTL = 基础值 + 随机 30~120 秒。

（3）**分布式锁核心 API**：
```java
Boolean ok = redisTemplate.opsForValue().setIfAbsent(key, uuid, 10, TimeUnit.SECONDS);
```
`setIfAbsent` 在 Redis 内部是原子的 SET NX EX。

（4）为什么必须带过期时间：万一持锁者宕机不释放，锁就是死锁。带 TTL 就是兜底。

（5）**释放锁**：必须先判断 value 是不是自己的 uuid，避免释放了别人续期后的锁。本节只用简单的判断-删除两步（有并发风险，但对养老场景可接受），提醒学生生产环境改 Lua 脚本原子释放（不展开）。

#### 3. 演示（15 分钟）
```java
// RoomCacheService.java —— Cache-Aside
@Service
@RequiredArgsConstructor
public class RoomCacheService {
    private final RedisTemplate<String, Object> redisTemplate;
    private final RoomMapper roomMapper;
    private static final String KEY_ROOM_LIST = "room:list:available";

    @SuppressWarnings("unchecked")
    public List<Room> listAvailable() {
        Object cached = redisTemplate.opsForValue().get(KEY_ROOM_LIST);
        if (cached != null) {
            return (List<Room>) cached;
        }
        List<Room> list = roomMapper.selectAvailable();
        int ttl = 300 + new Random().nextInt(60); // 5-6 分钟随机
        redisTemplate.opsForValue().set(KEY_ROOM_LIST, list, ttl, TimeUnit.SECONDS);
        return list;
    }

    public void evict() {
        redisTemplate.delete(KEY_ROOM_LIST);
    }
}
```

```java
// RedisLock.java —— 分布式锁工具
@Component
@RequiredArgsConstructor
public class RedisLock {
    private final RedisTemplate<String, Object> redisTemplate;

    public String tryLock(String key, long ttlSeconds) {
        String value = UUID.randomUUID().toString();
        Boolean ok = redisTemplate.opsForValue()
            .setIfAbsent(key, value, ttlSeconds, TimeUnit.SECONDS);
        return Boolean.TRUE.equals(ok) ? value : null;
    }

    public void unlock(String key, String value) {
        Object current = redisTemplate.opsForValue().get(key);
        if (value != null && value.equals(current)) {
            redisTemplate.delete(key);
        }
    }
}
```

改造 `createReservation` 加锁：

```java
public Long createReservation(ReservationDTO dto) {
    String lockKey = "lock:reservation:room:" + dto.getRoomId();
    String token = redisLock.tryLock(lockKey, 10);
    if (token == null) {
        throw new BizException("操作过于频繁，请稍后再试");
    }
    try {
        // 原有下单五步（校验/冲突/计算/落库）
        return doCreate(dto);
    } finally {
        redisLock.unlock(lockKey, token);
    }
}
```

演示：开两个 Postman 标签，几乎同时点两次同参数下单，只有一单成功。

#### 4. 实操（9 分钟）
学生实现"新增/取消客房"时调用 `roomCacheService.evict()` 清缓存，观察下次列表接口是否从 DB 重新加载。

#### 5. 小结（3 分钟）
缓存：Cache-Aside + 随机 TTL；锁：setIfAbsent + try-finally + TTL 兜底。

### 四、课上提问
1. 为什么用"删缓存"而不是"改缓存"？
2. 锁不设过期时间会怎样？
3. 释放锁前为什么要 check value？

### 五、课堂练习
1. 给"客房详情"接口加缓存，key = `room:detail:{id}`。
2. 压测：两个 Postman 同时下单，只有一单成功。

### 六、课后思考
如果业务逻辑执行了 15 秒但锁 TTL 只有 10 秒，会发生什么？如何补救？

### 七、课后作业
1. 客房增删改后主动调用 evict()。
2. 抓一次 redis-cli 上锁记录的截图。

### 八、板书设计
```
┌───────────────────────────────────────┐
│  Cache-Aside + 分布式锁               │
├───────────────────────────────────────┤
│ 查询：Redis → DB → 回填               │
│ 写入：DB → 删缓存                     │
│ 锁：setIfAbsent + TTL + 校验删除      │
└───────────────────────────────────────┘
```

---

## 第 5 课时：基于 AI 的智能预约推荐

### 一、教学目标
- 知识目标：理解"自然语 → 结构化参数"的核心思路；掌握 Prompt 强约束 JSON 输出的写法；掌握 Jackson `ObjectMapper` 将模型返回文本反序列化为 Java 对象；能把 AI 抽出的关键字复用到客房搜索。
- 能力目标：能实现 `POST /api/ai/recommend`，让用户输入"下周末两个人入住希望安静靠近花园"就能自动匹配客房。

### 二、教学重难点
- 重点：Prompt 中给出严格 JSON schema 与"仅输出 JSON 不要解释"约束。
- 难点：模型偶尔仍会输出 ```json ...``` 代码块，需要预处理剥离；日期"下周末"需要基于服务器当天推算。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
教师说："想象老人的女儿在手机上说'我妈这周五进来住三天希望安静有花园'。今天让 AI 听懂这句话并自动搜出合适的房间。"

#### 2. 讲授（15 分钟）
（1）整体链路：
```
用户说人话 → Controller 收到 → 拼 Prompt → ChatClient 调通义千问
        → 拿到 JSON → Jackson 反序列化 → 调 RoomService.search → 返回推荐列表
```

（2）**Prompt 设计三要素**：
- 角色："你是养老社区智能预约助手"
- 任务："从用户输入中提取入住日期、离店日期、人数、偏好关键字"
- 输出格式：给出 JSON schema，明确要求"只输出 JSON，不要 markdown 代码块，不要多余文字"，并给出示例。

（3）示例：
```
输入：下周末两个人入住希望安静靠近花园
输出：{"checkIn":"2026-07-17","checkOut":"2026-07-19","guestNum":2,"keywords":["安静","花园"]}
```

（4）容错策略：若模型仍带 ```json 前缀，用正则去掉；反序列化失败则返回"请描述更清楚"。

#### 3. 演示（15 分钟）
```java
// AiRecommendController.java
@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AiRecommendController {
    private final AiRecommendService aiRecommendService;

    @PostMapping("/recommend")
    public Result<List<Room>> recommend(@RequestBody Map<String, String> body) {
        String text = body.get("text");
        return Result.success(aiRecommendService.recommend(text));
    }
}
```

```java
// AiRecommendService.java
@Service
@RequiredArgsConstructor
@Slf4j
public class AiRecommendService {
    private final ChatClient chatClient;    // Day05 已注入
    private final RoomMapper roomMapper;
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final String PROMPT_TEMPLATE = """
        你是"AI 智能养老社区系统"的预约助手。
        请从用户下面这句话中，提取入住/离店日期、人数、偏好关键字。
        今天日期是 {today}，请把"下周""周末"等相对时间换算为具体日期(yyyy-MM-dd)。
        必须只输出一个 JSON 对象，不要任何解释，不要 markdown 代码块。
        JSON 字段：
          checkIn(string,yyyy-MM-dd)、checkOut(string,yyyy-MM-dd)、
          guestNum(int)、keywords(string[])
        用户输入：{userText}
        """;

    public List<Room> recommend(String userText) {
        String prompt = PROMPT_TEMPLATE
            .replace("{today}", LocalDate.now().toString())
            .replace("{userText}", userText);

        String raw = chatClient.prompt().user(prompt).call().content();
        String json = stripCodeFence(raw);
        RecommendParam param;
        try {
            param = objectMapper.readValue(json, RecommendParam.class);
        } catch (Exception e) {
            log.warn("AI 输出解析失败：{}", raw, e);
            throw new BizException("请把您的需求描述得更清楚一些");
        }
        return roomMapper.searchByKeywords(param.getKeywords());
    }

    private String stripCodeFence(String s) {
        s = s.trim();
        if (s.startsWith("```")) {
            s = s.replaceAll("(?s)^```(json)?", "").replaceAll("```$", "").trim();
        }
        return s;
    }

    @Data
    public static class RecommendParam {
        private String checkIn;
        private String checkOut;
        private Integer guestNum;
        private List<String> keywords;
    }
}
```

Mapper 侧新增关键字匹配：
```xml
<select id="searchByKeywords" resultType="Room">
    SELECT * FROM room WHERE status = 1
    <if test="list != null and list.size() > 0">
      AND (
        <foreach collection="list" item="kw" separator=" OR ">
          tags LIKE CONCAT('%', #{kw}, '%')
        </foreach>
      )
    </if>
    LIMIT 10
</select>
```

Postman 测试：body 传 `{"text":"下周末两个人入住希望安静靠近花园"}`，观察返回列表。

#### 4. 实操（9 分钟）
学生自行构造 3 句不同表述（如"这周四想住豪华套房带阳台"），观察 AI 抽取效果，若偶尔跑偏则修改 Prompt 添加更多 few-shot 示例。

#### 5. 小结（3 分钟）
AI 抽参三步：**Prompt → JSON → 反序列化**。给 AI"标准答题格式"，AI 出错率会大幅下降。

### 四、课上提问
1. 为什么要让模型输出 JSON 而不是自由文本？
2. 相对时间"下周末"如何被 AI 解决？
3. 如果模型输出多个 JSON 怎么办？

### 五、课堂练习
1. 修改 Prompt 让 AI 额外抽取"预算区间"。
2. 用 3 句不同表述测试鲁棒性。

### 六、课后思考
如果 AI 抽取的日期与已有订单冲突，应该由 AI 层过滤还是搜索层过滤？

### 七、课后作业
1. 把关键字改成"AND"匹配，对比召回率。
2. 记录 5 次模型输出的原始文本，观察格式稳定性。

### 八、板书设计
```
┌───────────────────────────────────────┐
│  AI 智能预约推荐                      │
├───────────────────────────────────────┤
│ Prompt: 角色+任务+JSON schema+示例    │
│ 剥壳: 去 ``` json 前缀                │
│ 反序: ObjectMapper.readValue          │
│ 落地: RoomMapper.searchByKeywords     │
└───────────────────────────────────────┘
```

---

## 第 6 课时：前端预约页面与日历组件

### 一、教学目标
- 知识目标：掌握 el-date-picker 的 daterange 用法；掌握 el-card 卡片列表渲染；掌握把 AI 推荐结果回填到预约表单；理解表单校验 rules。
- 能力目标：能独立完成 `views/reservation/booking.vue`，实现选日期 → 选客房 → 提交预约的完整闭环，并可选择通过智能推荐按钮唤起 AI。

### 二、教学重难点
- 重点：daterange 返回值格式（数组 [start, end]）；卡片选中态；表单提交后清空并刷新。
- 难点：AI 推荐结果回填时日期字符串与 Date 对象的转换。

### 三、教学过程（45 分钟）

#### 1. 导入（3 分钟）
"后端 4 个接口都通了。今天做前端页面，让家属打开就能给老人下单。"

#### 2. 讲授（12 分钟）
（1）页面区块规划：
```
┌── 上部：日期范围选择 + 智能推荐输入框 + [智能推荐] 按钮
├── 中部：客房卡片列表（可选中）
└── 下部：订单摘要 + [立即预约] 按钮
```

（2）关键 API 封装：
```ts
// src/api/reservation.ts
export const listAvailableRooms = () =>
  request.get('/api/rooms/available')
export const createReservation = (data) =>
  request.post('/api/reservations', data)
export const aiRecommend = (text) =>
  request.post('/api/ai/recommend', { text })
```

#### 3. 演示（18 分钟）
```vue
<!-- src/views/reservation/booking.vue -->
<template>
  <div class="booking">
    <el-card>
      <el-form :model="form" label-width="90px">
        <el-form-item label="入住日期">
          <el-date-picker
            v-model="form.dateRange"
            type="daterange"
            value-format="YYYY-MM-DD"
            range-separator="至"
            start-placeholder="入住"
            end-placeholder="离店" />
        </el-form-item>
        <el-form-item label="智能推荐">
          <el-input v-model="aiText" placeholder="例：下周末两人入住希望安静靠近花园" />
          <el-button type="primary" @click="handleRecommend" style="margin-top:8px;">
            智能推荐
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-row :gutter="12" class="room-list">
      <el-col :span="8" v-for="r in rooms" :key="r.id">
        <el-card
          :class="['room-card', { active: form.roomId === r.id }]"
          @click="form.roomId = r.id">
          <h3>{{ r.roomNo }} · {{ r.roomType }}</h3>
          <p>￥{{ r.dailyPrice }} / 晚</p>
          <p class="tags">{{ r.tags }}</p>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="summary">
      <p>已选客房：{{ selectedRoom?.roomNo || '未选择' }}</p>
      <p>预计总价：￥{{ totalPrice }}</p>
      <el-button type="success" size="large" @click="submit">立即预约</el-button>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { listAvailableRooms, createReservation, aiRecommend } from '@/api/reservation'
import { useUserStore } from '@/stores/user'

const userStore = useUserStore()
const form = ref({ dateRange: [], roomId: null })
const aiText = ref('')
const rooms = ref([])

const loadRooms = async () => {
  const { data } = await listAvailableRooms()
  rooms.value = data
}
loadRooms()

const selectedRoom = computed(() =>
  rooms.value.find(r => r.id === form.value.roomId))

const totalPrice = computed(() => {
  if (!selectedRoom.value || form.value.dateRange.length !== 2) return 0
  const [s, e] = form.value.dateRange
  const days = (new Date(e) - new Date(s)) / 86400000
  return (selectedRoom.value.dailyPrice * days).toFixed(2)
})

const handleRecommend = async () => {
  if (!aiText.value) return ElMessage.warning('请先输入需求')
  const { data } = await aiRecommend(aiText.value)
  rooms.value = data
  ElMessage.success(`AI 推荐了 ${data.length} 间客房`)
}

const submit = async () => {
  if (!form.value.roomId) return ElMessage.warning('请选择客房')
  if (form.value.dateRange.length !== 2) return ElMessage.warning('请选择日期')
  await createReservation({
    memberId: userStore.memberId,
    roomId: form.value.roomId,
    checkInDate: form.value.dateRange[0],
    checkOutDate: form.value.dateRange[1]
  })
  ElMessage.success('预约成功')
  form.value = { dateRange: [], roomId: null }
  loadRooms()
}
</script>

<style scoped>
.room-list { margin-top: 12px; }
.room-card { cursor: pointer; transition: all .2s; }
.room-card.active { border: 2px solid #409eff; }
.summary { margin-top: 16px; text-align: center; }
</style>
```

现场浏览器演示：先手动选房，再点智能推荐让 AI 换一批。

#### 4. 实操（9 分钟）
学生完成页面，联调"下单 → 列表刷新 → 已订日期不再可选"。

#### 5. 小结（3 分钟）
本日闭环：AI 抽参 → 缓存加速 → 分布式锁保并发 → 日历选择 → 下单成功。

### 四、课上提问
1. daterange 的 value-format 不设会怎样？
2. 卡片选中态怎么实现？
3. 智能推荐失败时前端如何降级？

### 五、课堂练习
1. 增加"取消预约"页面。
2. 给已选客房日期加禁用日期集合（进阶）。

### 六、课后思考
如果客房图片需要预览，应该用哪个 Element Plus 组件？

### 七、课后作业
1. 完成"我的预约"列表页 `views/reservation/mine.vue`。
2. 提交本日代码到 Git，PR 描述包含并发下单截图。

### 八、板书设计
```
┌───────────────────────────────────────┐
│  预约页面三段式                       │
├───────────────────────────────────────┤
│ 上：日期 + AI 推荐输入                │
│ 中：客房卡片选择                      │
│ 下：摘要 + 立即预约                   │
└───────────────────────────────────────┘
```

---

**Day06 结束：完成客房智能预约管理，Redis 与 Spring AI 联合上阵，Day07 将升级到 AI Agent（Function Calling + RAG）。**
