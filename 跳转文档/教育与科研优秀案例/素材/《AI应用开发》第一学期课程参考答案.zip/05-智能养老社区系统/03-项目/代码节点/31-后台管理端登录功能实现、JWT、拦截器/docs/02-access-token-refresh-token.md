# Access Token 与 Refresh Token 详解（Java 后端视角）

> 本文面向 Java 后端开发，介绍 OAuth2 / JWT 认证体系中 `access_token` 与 `refresh_token` 的作用、原理、生命周期管理，以及典型落地实现。

---

## 1. 为什么需要两套 Token？

传统的**会话（Session）认证**流程：

```
客户端 --登录--> 服务器(保存 Session)
                服务器 --Set-Cookie: JSESSIONID--> 客户端
```

这种方式的问题：

- 服务端需要维护会话状态（内存 / Redis），**无状态**扩展困难。
- 多实例 / 微服务场景下，Session 共享复杂。
- 难以支持移动端、第三方应用等非浏览器客户端。

**Token 认证**（尤其 JWT）让服务端不再保存状态：

```
客户端 --登录--> 认证服务器
                认证服务器 --签发 access_token--> 客户端
客户端 --请求(带 access_token)--> 资源服务器(本地验签, 无需查库)
```

但单纯一个 access token 也有矛盾：

- **过期时间短**（如 15 分钟）→ 安全，但用户频繁重新登录，体验差。
- **过期时间长**（如 7 天）→ 体验好，但 token 一旦泄露，长期有效，风险大。

于是引入 **双 Token 机制**：短命、高频使用的 access token + 长命、低频使用的 refresh token，在安全与体验之间取得平衡。

---

## 2. 两种 Token 的角色对比

| 维度 | Access Token | Refresh Token |
|------|--------------|---------------|
| **作用** | 访问受保护资源（调用 API） | 换取新的 access token |
| **生命周期** | 短（几分钟 ~ 1 小时） | 长（几小时 ~ 30 天，甚至更长） |
| **使用频率** | 每次请求都会携带 | 仅当 access token 过期时使用 |
| **存储位置** | 客户端（内存 / localStorage） | 客户端（更安全的位置，如 HttpOnly Cookie） |
| **传输范围** | 随业务请求发给资源服务器 | 仅发送给**认证服务器**的刷新端点 |
| **泄露风险** | 泄露后影响范围小（时间短） | 泄露后影响大，需支持吊销/轮换 |
| **是否携带业务信息** | 可携带用户信息、权限、声明 | 通常只是一个凭据，不携带业务声明 |

---

## 3. 工作流程（时序）

```
┌───────┐ 1.用户名密码         ┌────────────────────┐
│客户端 │ ──────────────────>  │  认证服务器        │
│       │                      │  (授权服务)        │
│       │ 2.签发               │                    │
│       │ <──────────────────  │ access + refresh   │
└───────┘                      └────────────────────┘
   │
   │ 3.请求业务 API（携带 access_token）
   ▼
┌───────┐                      ┌────────────────┐
│客户端 │ ──────────────────>  │  资源服务器    │
│       │ 4.验签 + 鉴权        │ (业务服务)     │
│       │ <──────────────────  │ 返回数据       │
└───────┘                      └────────────────┘

   access token 过期后（如 401）：
┌────────┐ 5.refresh_token      ┌──────────────────────────┐
│ 客户端 │ ──────────────────>  │  认证服务器              │
│        │ 6.校验并签发新的     │                          │
│        │  <────────────────── │ access + (新的) refresh  │
└────────┘                      └──────────────────────────┘
```

**核心时序步骤：**

1. 客户端提交凭据（用户名/密码、授权码、客户端凭证等）换取令牌。
2. 认证服务器验证通过，签发 `access_token` 和 `refresh_token`。
3. 客户端携带 `access_token` 访问资源服务器。
4. 资源服务器本地验证 token（签名、有效期、权限），通过则返回数据。
5. 当 `access_token` 过期，资源服务器返回 `401 Unauthorized`。
6. 客户端改用 `refresh_token` 请求认证服务器的刷新端点。
7. 认证服务器验证 refresh token 有效性，签发一组**新的**令牌。
8. 客户端用新令牌继续业务请求，全程对用户无感。

---

## 4. 原理剖析

### 4.1 JWT 的结构

JWT（JSON Web Token）是最常见的 access token 形式，由三段 Base64URL 组成：

```
header.payload.signature
```

- **Header**：算法与类型。`{"alg":"HS256","typ":"JWT"}`
- **Payload**：声明（claims），如 `sub`(用户ID)、`exp`(过期时间)、`iat`(签发时间)、`scope`/`roles`(权限)。
- **Signature**：对前两段做签名，防止篡改。

```java
// 示例 Payload
{
  "sub": "user-12345",
  "iss": "auth-service",
  "exp": 1718200000,
  "iat": 1718199100,
  "roles": ["ROLE_ADMIN"]
}
```

### 4.2 为什么 access token 可以"无状态"验证？

资源服务器只需：

1. 拿到 JWT 后，用共享密钥（HMAC）或公钥（RSA/EC）**验签**。
2. 校验 `exp` 是否过期。
3. 校验 `iss` / `aud` 是否匹配。
4. 解析 claims 做授权判断。

整个过程**不查询数据库**，因此天然支持水平扩展——这就是 JWT 相对 Session 的核心优势。

### 4.3 Refresh Token 的本质

refresh token **不要求**是 JWT，很多实现中它就是一把**随机的、存于服务端（数据库 / Redis）的字符串**（Opaque Token）。

- 生成：`SecureRandom` 生成高熵随机串，或 UUID。
- 存储：服务端保存其**哈希**及其有效期、所属用户、设备/客户端标识。
- 校验：刷新时比对存储记录，而不是验签。

这种做法让 refresh token 可被**撤销**（删除记录即可），这是 JWT 无法直接做到的。

### 4.4 为什么不能只用 access token？

- JWT 一旦签发，在 `exp` 之前**无法主动失效**（除非引入黑名单，那又回到了状态化）。
- 若把 JWT 设成长期有效，泄密窗口太大。
- 双 token 让**高频访问**用短命 token，把泄露影响控制在分钟级；长命凭据只出现在低频、受控的刷新环节。

---

## 5. 关键设计点与最佳实践

### 5.1 过期时间设置

| 场景 | Access Token | Refresh Token |
|------|--------------|---------------|
| Web 应用 | 15 ~ 60 分钟 | 7 ~ 30 天 |
| 移动端 | 1 ~ 24 小时 | 30 ~ 90 天 |
| 高安全场景 | 5 ~ 15 分钟 | 数小时 ~ 数天 |

原则：**access 越短越安全，refresh 越长越需配套吊销与轮换机制。**

### 5.2 Refresh Token 轮换（Rotation）

每次刷新时**同时更换 refresh token**，旧 token 立即失效：

```
旧 refresh_token  ──>  认证服务器签发  ──>  新 access_token + 新 refresh_token
                    (旧 refresh_token 作废)
```

好处：

- 若旧 refresh token 被窃取后仍被使用，可检测到 **token 重用**，触发安全告警并吊销整组令牌。
- 缩小凭据泄露的持续影响面。

### 5.3 存储安全

**客户端侧：**

- Access token：内存（单页应用内存中）优于 localStorage（易受 XSS 窃取）。
- Refresh token：建议放 **HttpOnly + Secure + SameSite** Cookie，降低 XSS 窃取风险。

**服务端侧：**

- refresh token 存**哈希**而非明文（防止数据库泄露后直接可用）。
- 支持按用户/设备**吊销**（黑名单、版本号、失效时间）。

### 5.4 吊销（Revocation）策略

refresh token 因存储于服务端，天然支持吊销。常见触发：

- 用户登出。
- 修改密码 / 强制下线。
- 检测到异常设备 / token 重用。
- 管理员操作。

access token（JWT）吊销较难，常用方案：
- 短过期时间 + refresh 续期（最常用）。
- 服务端维护 JWT `jti`（JWT ID）黑名单。
- 引入版本号（`ver` claim），版本变更即全部失效。

### 5.5 并发刷新与竞态

多个请求同时发现 access token 过期，会并发调用刷新端点，可能导致旧 refresh token 被轮换失效后互相挤掉线。解决方案：

- **一次性刷新** + 客户端侧**刷新互斥锁**（并发请求共享一次刷新，其余等待结果）。
- 服务端使用**事务/原子更新**保证轮换的幂等。

---

## 6. Java 落地实现示例

### 6.1 依赖（Spring Boot + jjwt）

```xml
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-api</artifactId>
    <version>0.12.5</version>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-impl</artifactId>
    <version>0.12.5</version>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt-jackson</artifactId>
    <version>0.12.5</version>
    <scope>runtime</scope>
</dependency>
```

### 6.2 签发 Token（Access + Refresh）

```java
@Service
public class TokenService {

    @Value("${jwt.secret}")       private String secret;
    @Value("${jwt.access.expire}") private long accessExpireSec;   // 例如 900
    @Value("${jwt.refresh.expire}")private long refreshExpireSec;  // 例如 2592000 (30天)

    private final SecretKey key() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    // 签发 access token（JWT）
    public String createAccessToken(Long userId, List<String> roles) {
        Instant now = Instant.now();
        return Jwts.builder()
                .subject(String.valueOf(userId))
                .claim("roles", roles)
                .issuedAt(Date.from(now))
                .expiration(Date.from(now.plusSeconds(accessExpireSec)))
                .signWith(key())
                .compact();
    }

    // 签发 refresh token（随机串，服务端保存哈希）
    public String createRefreshToken(Long userId, String deviceId) {
        String raw = UUID.randomUUID().toString().replace("-", "")
                         + UUID.randomUUID().toString().replace("-", "");
        // 服务端存储：userId + deviceId -> sha256(raw) + expireAt
        refreshTokenStore.save(userId, deviceId, sha256(raw),
                               Instant.now().plusSeconds(refreshExpireSec));
        return raw;
    }
}
```

### 6.3 验证 Access Token（资源服务器）

```java
@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            try {
                Claims claims = Jwts.parser()
                        .verifyWith(key())
                        .build()
                        .parseSignedClaims(token)
                        .getPayload();
                // 将用户信息放入 SecurityContext / 请求上下文
                request.setAttribute("userId", claims.getSubject());
            } catch (JwtException e) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }
        }
        chain.doFilter(request, response);
    }
}
```

### 6.4 刷新端点

```java
@RestController
public class AuthController {

    @PostMapping("/refresh")
    public TokenResponse refresh(@RequestBody RefreshRequest req) {
        String rawRefresh = req.refreshToken();

        // 1. 校验 refresh token 哈希是否存在且未过期
        RefreshRecord rec = refreshTokenStore.findByHash(sha256(rawRefresh));
        if (rec == null || rec.isExpired()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "refresh token 无效");
        }

        // 2. 刷新轮换：删除旧记录，签发新的 access + refresh
        refreshTokenStore.delete(rec.getId());
        String newAccess  = tokenService.createAccessToken(rec.getUserId(), rec.getRoles());
        String newRefresh = tokenService.createRefreshToken(rec.getUserId(), rec.getDeviceId());

        return new TokenResponse(newAccess, newRefresh);
    }
}
```

---

## 7. 常见问题（FAQ）

**Q1：为什么 access token 用 JWT，而 refresh token 常常不用？**
JWT 支持无状态验签，适合高频访问；refresh token 需要能被吊销/轮换，存于服务端更合适，因此常用 Opaque 随机串。

**Q2：JWT 泄露了怎么办？**
受限于 `exp`，泄露影响是时间窗内的。配合短过期 + 黑名单（`jti`）可进一步降低风险。refresh token 泄露则应立即吊销其记录并轮换。

**Q3：refresh token 被盗用如何发现？**
开启**轮换 + 重用检测**：若同一 refresh token 被第二次使用，判定为泄露，吊销该用户全部令牌并告警。

**Q4：是否需要 refresh token？**
如果你的 access token 很短（分钟级）且交互不频繁，可以不引入。但绝大多数生产系统需要 refresh token 以维持无感续期与良好体验。

**Q5：Session 和 JWT 怎么选？**
需要服务端主动注销、实时控制权 → Session（或带黑名单的 token）。追求无状态、跨端、分布式扩展 → JWT + refresh token。

---

## 8. 小结

- **Access token**：短命、高频、无状态验证，负责访问受保护资源；泄露影响面小。
- **Refresh token**：长命、低频、服务端可吊销，负责在 access 过期时换取新令牌；是安全与体验的平衡器。
- 二者配合，既保证了**无状态的水平扩展**，又通过**短过期 + 轮换 + 吊销**控制了安全风险。
- Java 侧典型实现：`jjwt`（签发/验证 access）+ Redis/数据库（存储、校验、吊销 refresh）。

> 推荐阅读：OAuth 2.0 RFC 6749、JWT RFC 7519、Spring Security 官方文档（OAuth2 资源服务器 / 授权服务器模块）。
