# 02-AccessToken + RefreshToken

1. 编写模型类实体，可存储在数据库或 Redis 中。

```java
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = false)
@Data
public class AdminRefreshToken {

    /**
     * 记录 ID
     */
    @EqualsAndHashCode.Include
    private Long id;

    /**
     * 管理员 ID
     */
    @NotNull
    private Long adminId;

    /**
     * Refresh Token 值
     */
    @NotBlank
    private String token;

    /**
     * 过期时间
     */
    @NotNull
    private LocalDateTime expireTime;
}
```

2. 编写登录逻辑，颁发双 Token。

```java
//提交登录
@PostMapping("/login")
public JsonResp login(@Validated @RequestBody Account account, HttpServletResponse resp) {
    var answer = this.redisTemplate.opsForValue().get("captcha-" + account.getCaptchaId());
    if (!account.getCaptchaAnswer().equals(answer)) {
        return JsonResp.fail(400, "验证码不正确");
    }

    RbacUser user = this.rbacUserService.findByUsername(account.getUsername());

    if (user == null) {
        return JsonResp.fail(404, "用户名不存在");
    }

    if (!PE.checkPassword(account.getPassword(), user.getPassword())) {
        return JsonResp.fail(400, "密码不正确");
    }

    //颁发jwt，默认有效期15分钟
    String accessToken = WebUtils.buildJwt(user, Map.of(),
                                           Instant.now().plus(accessTokenTtl, ChronoUnit.MINUTES), accessTokenSecret);
    resp.setHeader("access-token", accessToken);

    String refreshToken = WebUtils.buildJwt(user, Map.of(),
                                            Instant.now().plus(refreshTokenTtl, ChronoUnit.DAYS), refreshTokenSecret);

    AdminRefreshToken art = new AdminRefreshToken();
    art.setAdminId(user.getId());
    art.setToken(refreshToken);
    art.setExpireTime(LocalDateTime.now().plusDays(refreshTokenTtl));
    this.adminRefreshTokenService.save(art);

    Cookie cookie = new Cookie("refresh_token", refreshToken);
    cookie.setHttpOnly(true);
    cookie.setPath("/");
    resp.addCookie(cookie);

    return JsonResp.success(user);
}
```

2. 编写拦截器，仅拦截 access-token。

```java
@Slf4j
@Component
public class AuthorizationInterceptor implements HandlerInterceptor {
    @Value("${my.access-token.secret}")
    private String accessToken;

    @Override
    public boolean preHandle(@NonNull HttpServletRequest req, @NonNull HttpServletResponse resp, @NonNull Object handler) throws Exception {
        String accessToken = req.getHeader("Authorization");
        if (accessToken == null || accessToken.isBlank()) {
            accessToken = req.getParameter("AccessToken");
        } else {
            accessToken = accessToken.replaceFirst("Bearer ", "");
        }

        if (accessToken == null || accessToken.isBlank()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return false;
        }

        try {
            JWTVerifier verifier = JWT.require(Algorithm.HMAC256(this.accessToken)).build();
            DecodedJWT dj = verifier.verify(accessToken);
            Long userId = dj.getClaim("userId").asLong();
            String username = dj.getSubject();

            RbacUser user = new RbacUser();
            user.setId(userId);
            user.setUsername(username);
            Global.setCurrentUser(user);

            return true;
        } catch (Exception e) {
            log.error("jwt无效", e);
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return false;
        }
    }
}
```

3. 前端编写拦截器。

```javascript
//响应拦截器
api.interceptors.response.use(resp => {
    let accessToken = resp.headers["access-token"];
    if (accessToken) {
        UserApi.setAccessToken(accessToken);
    }
    return resp.data;
}, error => {
    let resp = error.response;

    if (resp.status === 401) {
        let userId = UserApi.getLoginUser().id;

        //刷新新的accessToken
        UserApi.refreshAccessToken(userId).then(resp => {
            console.log(resp);
        });

        return {
            code: 500,
            success: false,
            msg: "请稍候再试"
        }
    }

    if (resp.status === 10401) {
        UserApi.removeAccessToken();
        router.push("/login");
        return;
    }

    return {
        code: 500,
        success: false,
        msg: "服务器异常，请稍候再试"
    }
});
```



---













---

