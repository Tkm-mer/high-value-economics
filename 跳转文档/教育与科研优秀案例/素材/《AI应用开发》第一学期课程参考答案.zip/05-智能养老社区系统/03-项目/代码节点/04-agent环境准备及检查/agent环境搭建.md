

## 一、Windows 开发环境

### 1.1 Java 25.0.4

下载地址：https://www.oracle.com/java/technologies/downloads/

### 1.2 Maven 3.9.16

下载地址：https://maven.apache.org/download.cgi

配置镜像和本地仓库：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
	xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
	xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0 http://maven.apache.org/xsd/settings-1.0.0.xsd">

	<!-- 配置本地仓库路径，默认在“{用户目录}/.m2/repository”路径下 -->
	<localRepository>d:/.m2/repository</localRepository>

	<mirrors>
		<!-- 配置中央仓库的阿里云镜像 -->
		<mirror>
			<id>aliyun</id>
			<mirrorOf>central</mirrorOf>
			<name>阿里云maven镜像</name>
			<url>https://maven.aliyun.com/repository/public</url>
		</mirror>
	</mirrors>
</settings>
```

### 1.3 MySQL 9.7.2 LTS + Navicat 17.3.9

下载地址：https://dev.mysql.com/downloads/mysql/

下载地址：https://www.navicat.com.cn/products/navicat-for-mysql

### 1.4 Redis 8.8.0 + TinyRDM

下载地址：https://github.com/zkteco-home/redis-windows/releases

下载地址：https://github.com/tiny-craft/tiny-rdm/releases

注意：Windows 版本的 Redis 没有 redisearch 模块，不支持向量存储，不能用做 Spring AI 的向量库使用，也不能用于存储 Spring AI 有聊天会话记忆。

### 1.5 IDEA 2026.2

下载地址：https://www.jetbrains.com.cn/idea/download/?section=windows

### 1.6 接口调试工具 Reqable 3.2.23

下载地址：https://github.com/reqable/reqable-app/releases

### 1.7 Node.js 24.19 + pnpm 11.21

下载地址：https://nodejs.org/zh-cn/download

### 1.8 Vue 3 + Vite + Element-Plus

Element-Plus：https://cn.element-plus.org/zh-CN/

## 二、Linux（WSL 2）运行环境

1. node.js + pnpm
2. python + uv
3. java
4. maven
5. redis
6. mysql
7. docker
8. claude code 
9. hermes





## 三、Docker 运行环境

mysql

redis







---

